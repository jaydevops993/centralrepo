package com.BisagN.dao.officer.report;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;

@Service
public class PartB_ReportDaoImpl implements PartB_ReportDAO {
	@Autowired
    private DataSource dataSource;
	
	
	CommonController comm = new CommonController();
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;


public ArrayList<ArrayList<String>> getFullyPassedForPartB(int es_id, String oa_application_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String whr = "";
	String whr1 = "";
	String whr2 = "";
if(!oa_application_id.equals("")) {
	
	whr+= "and oapp.oa_application_id=?";
}
	

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
		
		
		q="select DISTINCT pfd.ser_no, pfd.es_id,\n"
				+ "    vw.opd_personal_id,\n"
				+ "    vw.opc_personal_code,  vw.opc_suffix_code,\n"
				+ "    vw.rc_rank_name,\n"
				+ "    vw.opd_officer_name,\n"
				+ "    vw.ac_arm_description,pfd.oa_app_id,\n"
				+ "    vw.ac_arm_code from tb_partpass_fullpass_dtl pfd\n"
				+ "inner join vw_personal_details vw on pfd.opd_personal_id = vw.opd_personal_id \n"
				+ "inner join officer_application oapp on vw.opd_personal_id = oapp.opd_personal_id \n"
				+ "where pfd.es_id=? and pfd.result=1 "+whr+" order by pfd.ser_no asc , vw.opc_personal_code ";


	
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
		if(!oa_application_id.equals("")) {
			stmt.setInt(2,Integer.parseInt(oa_application_id));
		}
		
		System.err.println("smt====fu===="+stmt);
		ResultSet rs = stmt.executeQuery();
int i=1;
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			String Data=rs.getString("opc_personal_code");
			String ArmCode = rs.getString("ac_arm_code");
			int ArmCodeStringSize= ArmCode.length();
			//System.out.println("Fully Passed Data========="+Data);
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			
			Data=DataPre+DataM;
			//System.out.println("Fully Passed Data2========="+Data);
			
			list.add(String.valueOf(i));
			list.add(Data+"  "+(rs.getString("opc_suffix_code")));
			list.add(rs.getString("rc_rank_name"));
			list.add(rs.getString("opd_officer_name"));
			if (ArmCodeStringSize == 1) {
				list.add(rs.getString("ac_arm_description")+" "+"(0"+(rs.getString("ac_arm_code")+")"));
			}
			else {
				list.add(rs.getString("ac_arm_description")+" "+"("+(rs.getString("ac_arm_code")+")"));
			}
			list.add(rs.getString("opd_personal_id"));
			list.add(rs.getString("oa_app_id"));
			alist.add(list);
			i++;
			//System.err.println("list============"+list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}


public ArrayList<ArrayList<String>> getdetailsResultWithHeld(int es_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String whr = "";
	String whr1 = "";
	String whr2 = "";

	

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

//		q = "select mrw.* from mv_result_withheld mrw where mrw.es_id=?";
		
		q="SELECT DISTINCT oapp.es_id,\n"
				+ "    vw.opc_personal_code,\n"
				+ "    vw.rc_rank_name,\n"
				+ "    vw.opd_officer_name,\n"
				+ "    vw.ac_arm_description,\n"
				+ "    vw.ac_arm_code\n"
				+ "   FROM results_withheld rw\n"
				+ "     JOIN vw_personal_details vw ON vw.opc_personal_code::text = rw.personal_no::text\n"
				+ "     JOIN officer_application oapp ON oapp.opd_personal_id = vw.opd_personal_id where rw.res_status_id=1  and oapp.es_id=? order by vw.opc_personal_code";

	
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
		ResultSet rs = stmt.executeQuery();
System.err.println("res---------"+stmt);
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("opc_personal_code"));
			list.add(rs.getString("rc_rank_name"));
			list.add(rs.getString("opd_officer_name"));
			list.add(rs.getString("ac_arm_description")+"("+(rs.getString("ac_arm_code")+")"));
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}





public ArrayList<ArrayList<String>> getArmsubsummaryresult(int es_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	List<SUBJECT_CODE_M> sublist= comm.getsubjectlist(sessionFactory, 1);
	try {
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
		String qbuilder="";

		for (SUBJECT_CODE_M subject_CODE_M : sublist) {
			qbuilder+="COUNT(distinct ismn.is_ism_id) filter (where ismn.is_sc_subject_id="+subject_CODE_M.getSc_subject_id()+" and  ism.ism_es_id=? ) as appd_"+subject_CODE_M.getSc_form_caption().toLowerCase()+",\n"
					+ "COUNT(distinct ofr.opd_personal_id) filter (where ofr.sc_subject_id="+subject_CODE_M.getSc_subject_id()+" and ofr.or_subject_pass='1' and ofr.es_id=?) as pass_"+subject_CODE_M.getSc_form_caption().toLowerCase()+" , ";
		}
		qbuilder = qbuilder.substring(0,qbuilder.length()-3);
		q = "select * from(select vw.ac_arm_description ,vw.ac_arm_order, \n"
				+qbuilder
				+ "\n"
				+ "from officer_results ofr\n"
				+ "		inner join officer_application ofres on ofres.opd_personal_id=ofr.opd_personal_id  \n"
				+ "			inner join vw_personal_details vw on vw.opd_personal_id = ofr.opd_personal_id \n"
				+ "				inner join index_slip_master ism on ism.ism_armyno=vw.opc_personal_code \n"
				+ "				inner join index_slip_manual ismn on ism.ism_id=ismn.is_ism_id\n"
				+ "				where ism.ism_es_id=? group by 1,vw.ac_arm_order\n"
				+ "UNION all \n"
				+ "select 'Total', '999', \n"
				+qbuilder
				+"\n"
				+ "from officer_results ofr\n"
				+ "		inner join officer_application ofres on ofres.opd_personal_id=ofr.opd_personal_id  \n"
				+ "			inner join vw_personal_details vw on vw.opd_personal_id = ofr.opd_personal_id \n"
				+ "				inner join index_slip_master ism on ism.ism_armyno=vw.opc_personal_code \n"
				+ "				inner join index_slip_manual ismn on ism.ism_id=ismn.is_ism_id\n"
				+ "				where ism.ism_es_id=? group by 1) a order by a.ac_arm_order";
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
		stmt.setInt(2, es_id);
		stmt.setInt(3, es_id);
		stmt.setInt(4, es_id);
		stmt.setInt(5, es_id);
		stmt.setInt(6, es_id);
		stmt.setInt(7, es_id);
		stmt.setInt(8, es_id);
		stmt.setInt(9, es_id);
		stmt.setInt(10, es_id);
		stmt.setInt(11, es_id);
		stmt.setInt(12, es_id);
		stmt.setInt(13, es_id);
		stmt.setInt(14, es_id);
		stmt.setInt(15, es_id);
		stmt.setInt(16, es_id);
		stmt.setInt(17, es_id);
		stmt.setInt(18, es_id);
		stmt.setInt(19, es_id);
		stmt.setInt(20, es_id);
		stmt.setInt(21, es_id);
		stmt.setInt(22, es_id);
		
		
		
		System.err.println("sub--------"+stmt);
		ResultSet rs = stmt.executeQuery();
		DecimalFormat df_double = new DecimalFormat("0.00");

		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("ac_arm_description"));
			for (SUBJECT_CODE_M subject_CODE_M : sublist) {
				double passed_whole_exam = Integer.parseInt(rs.getString("appd_"+subject_CODE_M.getSc_form_caption().toLowerCase()));
				double total_candidate_appeared = Integer.parseInt(rs.getString("pass_"+subject_CODE_M.getSc_form_caption().toLowerCase()));				
				list.add(rs.getString("appd_"+subject_CODE_M.getSc_form_caption().toLowerCase()));
				list.add(rs.getString("pass_"+subject_CODE_M.getSc_form_caption().toLowerCase()));
				if(passed_whole_exam==0) {
					passed_whole_exam=1;
				}	
				
				
								double pers_passed_whole_exam = (total_candidate_appeared * 100)/passed_whole_exam;
				list.add(df_double.format(pers_passed_whole_exam));
			}
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

public ArrayList<ArrayList<String>> getArmServiceAnalysisResultsPartB(int es_id, String es_year) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String whr = "";
	String whr1 = "";
	String whr2 = "";

	

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
		q="select  ar.ac_arm_description , \n"
				+ "COUNT(distinct ofr.oa_application_id)filter (where ofr.in_index_id != 0 and ofr.es_id=? )as total_candidate_appeared,\n"
				+ "count(distinct vw.opd_personal_id)filter (where  vw.opd_partb = ? ) as passed_whole_exam,\n"
				+ "\n"
				+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and vw.opd_partb = 0 and pbd.pbda_subjects != vw.pbda_sub_code and ofr.es_id=?) as partially_passed_exam,\n"
				+ " count(DISTINCT vw.opd_personal_id )filter(where ofr.in_index_id != 0  and pbd.pbda_subjects = vw.pbda_sub_code and ofr.es_id=?  ) as failed_subject,\n"
				+ " \n"
				+ "\n"
				+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5')  as app_total_candidate_appeared,\n"
				+ "\n"
				+ "\n"
				+ "\n"
				+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'  and ors.es_id=?)='5') as all,\n"
				+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
				+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'  and ors.es_id=?)='4' and \n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5'))  as four,\n"
				+ "  count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
				+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id=?)='3'\n"
				+ "and(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5') ) as three,\n"
				+ "   count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
				+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id=?)='2' and\n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5')) as two,\n"
				+ " \n"
				+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
				+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id=?)='1' and\n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5')) as one,\n"
				+ "\n"
				+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
				+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='0'   and ors.es_id=?)='5' and\n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5')) as none\n"
				+ "from officer_application ofr\n"
				+ "inner join officer_personal_details vw on vw.opd_personal_id = ofr.opd_personal_id and vw.opd_status_id=1 \n"
				+ "inner join officer_arm ofarm on ofarm.opd_personal_id = vw.opd_personal_id and ofarm.oa_status_id=1\n"
				+ "inner join arm_codes ar ON ar.ac_arm_id = ofarm.ac_arm_id and ar.ac_status_id=1 \n"
				+ "inner join partb_d_application pbd on pbd.oa_application_id = ofr.oa_application_id where ofr.oa_status_id=1 \n"
				+ "and ofr.es_id=? and ar.ac_arm_order != '0'\n"
				+ "  group by 1,ar.ac_arm_order order by  ar.ac_arm_order";
	
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
		stmt.setInt(2,Integer.parseInt(es_year));
		stmt.setInt(3, es_id);
		
		stmt.setInt(4, es_id);
		
		stmt.setInt(5, es_id);
		stmt.setInt(6, es_id);
		
		stmt.setInt(7, es_id);
		stmt.setInt(8, es_id);
		
		stmt.setInt(9, es_id);
		stmt.setInt(10, es_id);
		
		stmt.setInt(11, es_id);
		
		stmt.setInt(12, es_id);
		stmt.setInt(13, es_id);
		stmt.setInt(14, es_id);
		stmt.setInt(15, es_id);
		
		stmt.setInt(16, es_id);
		stmt.setInt(17, es_id);
		
		
		
		
		ResultSet rs = stmt.executeQuery();
		System.out.println("armRs ------------------"+stmt);
		///////////////
		double total_candidate_appeared_t = 0;
		double passed_whole_exam_t = 0;
		double pers_passed_whole_exam_t = 0;
		double partially_passed_exam_t = 0;
		double pers_partially_passed_exam_t =0;
		double failed_subject_t = 0;
		double pers_failed_subject_t =0;
		
		double app_total_candidate_appeared_t =0;
		double all_t =0;
		double pers_all_t =0;
		double four_t =0;
		double pers_four_t =0;
		double three_t =0;
		double pers_three_t =0;
		double two_t=0;
		double pers_two_t =0;
		double one_t =0;
		double pers_one_t =0;
		double none_t =0;
		double pers_none_t =0;
		
		DecimalFormat df_double = new DecimalFormat("0.00");
		DecimalFormat df_int = new DecimalFormat("0");
		
		////////////
		while (rs.next()) {
			
			
			double total_candidate_appeared = Integer.parseInt(rs.getString("total_candidate_appeared"));
			total_candidate_appeared_t +=total_candidate_appeared;
			double passed_whole_exam = Integer.parseInt(rs.getString("passed_whole_exam"));
			passed_whole_exam_t +=passed_whole_exam;
			if(total_candidate_appeared==0) {
				total_candidate_appeared=1;
			}

			double pers_passed_whole_exam = (passed_whole_exam * 100)/total_candidate_appeared;
			
			double partially_passed_exam = Integer.parseInt(rs.getString("partially_passed_exam"));
			partially_passed_exam_t +=partially_passed_exam;
			double pers_partially_passed_exam = (partially_passed_exam * 100)/total_candidate_appeared;
			
			double failed_subject = Integer.parseInt(rs.getString("failed_subject"));
			failed_subject_t +=failed_subject;
			double pers_failed_subject = (failed_subject * 100)/total_candidate_appeared;
			
			double app_total_candidate_appeared = Integer.parseInt(rs.getString("app_total_candidate_appeared"));
			app_total_candidate_appeared_t +=app_total_candidate_appeared;
			double all = Integer.parseInt(rs.getString("all"));
			all_t +=all; 
			if(app_total_candidate_appeared==0) {
				app_total_candidate_appeared=1;
			}
			
			double pers_all = (all * 100)/app_total_candidate_appeared;
			double four = Integer.parseInt(rs.getString("four"));
			four_t += four;
			double pers_four = (four * 100)/app_total_candidate_appeared;
			double three = Integer.parseInt(rs.getString("three"));
			three_t +=three;
			double pers_three = (three * 100)/app_total_candidate_appeared;
			double two = Integer.parseInt(rs.getString("two"));
			two_t +=two;
			double pers_two = (two * 100)/app_total_candidate_appeared;
			double one = Integer.parseInt(rs.getString("one"));
			one_t += one;
			double pers_one = (one * 100)/app_total_candidate_appeared;
			double none = Integer.parseInt(rs.getString("none"));
			none_t += none;
			double pers_none = (none * 100)/app_total_candidate_appeared;
			
			
			
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("ac_arm_description"));
			list.add(rs.getString("total_candidate_appeared"));
			list.add(rs.getString("passed_whole_exam"));
			list.add(df_double.format(pers_passed_whole_exam));
			list.add(rs.getString("partially_passed_exam"));
			list.add(df_double.format(pers_partially_passed_exam));
			list.add(rs.getString("failed_subject"));
			list.add(df_double.format(pers_failed_subject));
			list.add(rs.getString("app_total_candidate_appeared"));
			list.add(rs.getString("all"));
			list.add(df_double.format(pers_all));
			list.add(rs.getString("four"));
			list.add(df_double.format(pers_four));
			list.add(rs.getString("three"));
			list.add(df_double.format(pers_three));
			list.add(rs.getString("two"));
			list.add(df_double.format(pers_two));
			list.add(rs.getString("one"));
			list.add(df_double.format(pers_one));
			list.add(rs.getString("none"));
			list.add(df_double.format(pers_none));
			alist.add(list);
		}
		
		/////////////
		pers_passed_whole_exam_t = (passed_whole_exam_t * 100)/total_candidate_appeared_t;
		pers_partially_passed_exam_t = (partially_passed_exam_t * 100)/total_candidate_appeared_t;
		pers_failed_subject_t = (failed_subject_t * 100)/total_candidate_appeared_t;
		pers_all_t = (all_t * 100)/app_total_candidate_appeared_t;
		pers_four_t = (four_t * 100)/app_total_candidate_appeared_t;
		pers_three_t = (three_t * 100)/app_total_candidate_appeared_t;
		pers_two_t = (two_t * 100)/app_total_candidate_appeared_t;
		pers_one_t = (one_t * 100)/app_total_candidate_appeared_t;
		pers_none_t = (none_t * 100)/app_total_candidate_appeared_t;
		/////////
		
		
		
		ArrayList<String> list = new ArrayList<String>();
		list.add("Total");
		list.add(df_int.format(total_candidate_appeared_t));
		list.add(df_int.format(passed_whole_exam_t));
		list.add(df_double.format(pers_passed_whole_exam_t));
		list.add(df_int.format(partially_passed_exam_t));
		list.add(df_double.format(pers_partially_passed_exam_t));
		list.add(df_int.format(failed_subject_t));
		list.add(df_double.format(pers_failed_subject_t));
		list.add(df_int.format(app_total_candidate_appeared_t));
		list.add(df_int.format(all_t));
		list.add(df_double.format(pers_all_t));
		list.add(df_int.format(four_t));
		list.add(df_double.format(pers_four_t));
		list.add(df_int.format(three_t));
		list.add(df_double.format(pers_three_t));
		list.add(df_int.format(two_t));
		list.add(df_double.format(pers_two_t));
		list.add(df_int.format(one_t));
		list.add(df_double.format(pers_one_t));
		list.add(df_int.format(none_t));
		list.add(df_double.format(pers_none_t));
		alist.add(list);
		
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

public ArrayList<ArrayList<String>> getCommandAnalysisResultsPartB(int es_id, String es_year) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String whr = "";
	String whr1 = "";
	String whr2 = "";

	

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		
		
		q="select cc.cc_command_name,  \n"
				+ "COUNT(distinct ofr.oa_application_id)filter (where ofr.in_index_id != 0 and ofr.es_id=? and ofr.es_id=ism.ism_es_id )as total_candidate_appeared,\n"
				+ "count(distinct vw.opd_personal_id)filter (where  vw.opd_partb = "+es_year+" ) as passed_whole_exam,\n"
				+ "\n"
				+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and vw.opd_partb = 0 and pbd.pbda_subjects != vw.pbda_sub_code and ofr.es_id=?) as partially_passed_exam,\n"
				+ " count(DISTINCT vw.opd_personal_id )filter(where ofr.in_index_id != 0  and pbd.pbda_subjects = vw.pbda_sub_code and ofr.es_id=?  ) as failed_subject,\n"
				+ " \n"
				+ "\n"
				+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5')  as app_total_candidate_appeared,\n"
				+ "\n"
				+ "\n"
				+ "\n"
				+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'  and ors.es_id=?)='5') as all,\n"
				+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
				+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'  and ors.es_id=?)='4' and \n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5'))  as four,\n"
				+ "  count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
				+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id=?)='3'\n"
				+ "and(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5') ) as three,\n"
				+ "   count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
				+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id=?)='2' and\n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5')) as two,\n"
				+ " \n"
				+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
				+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id=?)='1' and\n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5')) as one,\n"
				+ "\n"
				+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
				+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='0'   and ors.es_id=?)='5' and\n"
				+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)='5')) as none\n"
				+ "from officer_application ofr\n"
				+ "inner join vw_personal_details vw on vw.opd_personal_id = ofr.opd_personal_id and vw.opd_status_id=1 \n"
				+ "inner join partb_d_application pbd on pbd.oa_application_id = ofr.oa_application_id\n"
				+ "inner join index_slip_master ism on ism.ism_armyno = vw.opc_personal_code and ofr.es_id=ism.ism_es_id \n"
				+ "inner join command_code cc on cc.cc_command_id = ism.command_id where ofr.oa_status_id=1 and ofr.es_id=? \n"
				+ " group by 1,cc.cc_command_order order by cc.cc_command_order";

	
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
		stmt.setInt(2, es_id);
		
		stmt.setInt(3, es_id);
		stmt.setInt(4, es_id);
		
		stmt.setInt(5, es_id);
		stmt.setInt(6, es_id);
		
		stmt.setInt(7, es_id);
		stmt.setInt(8, es_id);
		
		stmt.setInt(9, es_id);
		stmt.setInt(10, es_id);
stmt.setInt(11, es_id);
		
		stmt.setInt(12, es_id);
		stmt.setInt(13, es_id);
		stmt.setInt(14, es_id);
		stmt.setInt(15, es_id);
		stmt.setInt(16, es_id);
		
		ResultSet rs = stmt.executeQuery();
		System.err.println("coomand-------"+stmt);
		double total_candidate_appeared_t = 0;
		double passed_whole_exam_t = 0;
		double pers_passed_whole_exam_t = 0;
		double partially_passed_exam_t = 0;
		double pers_partially_passed_exam_t =0;
		double failed_subject_t = 0;
		double pers_failed_subject_t =0;
		
		double app_total_candidate_appeared_t =0;
		double all_t =0;
		double pers_all_t =0;
		double four_t =0;
		double pers_four_t =0;
		double three_t =0;
		double pers_three_t =0;
		double two_t=0;
		double pers_two_t =0;
		double one_t =0;
		double pers_one_t =0;
		double none_t =0;
		double pers_none_t =0;
		DecimalFormat df_double = new DecimalFormat("0.00");
		DecimalFormat df_int = new DecimalFormat("0");
		////////////
		while (rs.next()) {
			double total_candidate_appeared = Integer.parseInt(rs.getString("total_candidate_appeared"));
			total_candidate_appeared_t +=total_candidate_appeared;
			double passed_whole_exam = Integer.parseInt(rs.getString("passed_whole_exam"));
			passed_whole_exam_t +=passed_whole_exam;
			double pers_passed_whole_exam = (passed_whole_exam * 100)/total_candidate_appeared;
			
			double partially_passed_exam = Integer.parseInt(rs.getString("partially_passed_exam"));
			partially_passed_exam_t +=partially_passed_exam;
			double pers_partially_passed_exam = (partially_passed_exam * 100)/total_candidate_appeared;
			
			double failed_subject = Integer.parseInt(rs.getString("failed_subject"));
			failed_subject_t +=failed_subject;
			double pers_failed_subject = (failed_subject * 100)/total_candidate_appeared;
			
			double app_total_candidate_appeared = Integer.parseInt(rs.getString("app_total_candidate_appeared"));
			app_total_candidate_appeared_t +=app_total_candidate_appeared;
			int all = Integer.parseInt(rs.getString("all"));
			all_t +=all; 
			
			double pers_all = (all * 100)/app_total_candidate_appeared;
			double four = Integer.parseInt(rs.getString("four"));
			four_t += four;
			double pers_four = (four * 100)/app_total_candidate_appeared;
			double three = Integer.parseInt(rs.getString("three"));
			three_t +=three;
			double pers_three = (three * 100)/app_total_candidate_appeared;
			double two = Integer.parseInt(rs.getString("two"));
			two_t +=two;
			double pers_two = (two * 100)/app_total_candidate_appeared;
			double one = Integer.parseInt(rs.getString("one"));
			one_t += one;
			double pers_one = (one * 100)/app_total_candidate_appeared;
			double none = Integer.parseInt(rs.getString("none"));
			none_t += none;
			double pers_none = (none * 100)/app_total_candidate_appeared;
			
			
			
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("cc_command_name"));
			list.add(rs.getString("total_candidate_appeared"));
			list.add(rs.getString("passed_whole_exam"));
			list.add(df_double.format(pers_passed_whole_exam));
			list.add(rs.getString("partially_passed_exam"));
			list.add(df_double.format(pers_partially_passed_exam));
			list.add(rs.getString("failed_subject"));
			list.add(df_double.format(pers_failed_subject));
			list.add(rs.getString("app_total_candidate_appeared"));
			list.add(rs.getString("all"));
			list.add(df_double.format(pers_all));
			list.add(rs.getString("four"));
			list.add(df_double.format(pers_four));
			list.add(rs.getString("three"));
			list.add(df_double.format(pers_three));
			list.add(rs.getString("two"));
			list.add(df_double.format(pers_two));
			list.add(rs.getString("one"));
			list.add(df_double.format(pers_one));
			list.add(rs.getString("none"));
			list.add(df_double.format(pers_none));
			alist.add(list);
		}
	
		/////////////
		pers_passed_whole_exam_t = (passed_whole_exam_t * 100)/total_candidate_appeared_t;
		pers_partially_passed_exam_t = (partially_passed_exam_t * 100)/total_candidate_appeared_t;
		pers_failed_subject_t = (failed_subject_t * 100)/total_candidate_appeared_t;
		pers_all_t = (all_t * 100)/app_total_candidate_appeared_t;
		pers_four_t = (four_t * 100)/app_total_candidate_appeared_t;
		pers_three_t = (three_t * 100)/app_total_candidate_appeared_t;
		pers_two_t = (two_t * 100)/app_total_candidate_appeared_t;
		pers_one_t = (one_t * 100)/app_total_candidate_appeared_t;
		pers_none_t = (none_t * 100)/app_total_candidate_appeared_t;
		/////////
		
		
		
		ArrayList<String> list = new ArrayList<String>();
		list.add("Total");
		list.add(df_int.format(total_candidate_appeared_t));
		list.add(df_int.format(passed_whole_exam_t));
		list.add(df_double.format(pers_passed_whole_exam_t));
		list.add(df_int.format(partially_passed_exam_t));
		list.add(df_double.format(pers_partially_passed_exam_t));
		list.add(df_int.format(failed_subject_t));
		list.add(df_double.format(pers_failed_subject_t));
		list.add(df_int.format(app_total_candidate_appeared_t));
		list.add(df_int.format(all_t));
		list.add(df_double.format(pers_all_t));
		list.add(df_int.format(four_t));
		list.add(df_double.format(pers_four_t));
		list.add(df_int.format(three_t));
		list.add(df_double.format(pers_three_t));
		list.add(df_int.format(two_t));
		list.add(df_double.format(pers_two_t));
		list.add(df_int.format(one_t));
		list.add(df_double.format(pers_one_t));
		list.add(df_int.format(none_t));
		list.add(df_double.format(pers_none_t));
		alist.add(list);
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

public ArrayList<ArrayList<String>> Candidate25PersmarksDetails(int es_id, String f_percntg1, String t_percntg1,String marks1, String subject_id1) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	System.err.println("marks1=d====="+marks1);
	
	if(f_percntg1.equals("0") && t_percntg1.equals("0")) {
	//if(!marks1.equals("")) {
		
		q= "and ab.ab_marks_obtained <= '"+Integer.parseInt(marks1)+"'";
	//}
	
	}
	
	if(marks1.equals("")) {
	if(!f_percntg1.equals("") && !t_percntg1.equals("") ) {
		
		q="and (ab.ab_marks_obtained ::float / sc.sc_max_marks::float) * 100 between '"+f_percntg1+"' and  '"+t_percntg1+"' ";
	}
	}
	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q = "SELECT DISTINCT oapp.es_id,\n"
				+ "    vw.opd_personal_id,vw.opc_suffix_code,\n"
				+ "    vw.opc_personal_code,\n"
				+ "    vw.rc_rank_name,\n"
				+ "    vw.opd_officer_name,\n"
				+ "    vw.ac_arm_description,\n"
				+ "    vw.ac_arm_code,sc.sc_subject_name,\n"
				+ "	(ab.ab_marks_obtained ::float / \n"
				+ "sc.sc_max_marks::float) * 100 as percentage\n"
				+ "   FROM vw_personal_details vw\n"
				+ "     JOIN officer_application oapp ON oapp.opd_personal_id = vw.opd_personal_id and oapp.oa_status_id=1 \n"
				+ "	 inner join answer_book ab on ab.oa_application_id = oapp.oa_application_id\n"
				+ "	 inner join subject_code sc on ab.sc_subject_id = sc.sc_subject_id\n"
				+ "  WHERE oapp.es_id=?  AND oapp.in_index_id != 0  AND vw.opd_status_id = 1 and ab.sc_subject_id=?  "+q+" order by vw.opc_personal_code "   ;

	
		stmt = conn.prepareStatement(q);

		stmt.setInt(1, es_id);
		stmt.setInt(2, Integer.parseInt(subject_id1));
		
	
		ResultSet rs = stmt.executeQuery();
		System.err.println("stmt---marks----"+stmt);
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			
			String ArmCode = rs.getString("ac_arm_code");
			int ArmCodeStringSize= ArmCode.length();
			
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			//System.err.println("DataPre "+ DataPre);
			//System.err.println("DataM "+ DataM);
			
			Data=DataPre+DataM;
			
			
			
			//System.err.println("pers_cde==rrrrr====="+Data);
			list.add(Data +rs.getString("opc_suffix_code"));
			list.add(rs.getString("rc_rank_name"));
			list.add(rs.getString("opd_officer_name"));
			if (ArmCodeStringSize == 1) {
				list.add(rs.getString("ac_arm_description")+" "+"(0"+(rs.getString("ac_arm_code")+")"));
			}
			else {
				list.add(rs.getString("ac_arm_description")+" "+"("+(rs.getString("ac_arm_code")+")"));
			}
//			list.add(rs.getString("ac_arm_description")+"("+(rs.getString("ac_arm_code")+")"));
			list.add(rs.getString("sc_subject_name"));
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

public ArrayList<ArrayList<String>> IndexagainstPersAndname(int es_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String whr = "";
	String whr1 = "";
	String whr2 = "";

	

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q = "select DISTINCT of_app.in_index_id, vw.opc_personal_code,  vw.opd_officer_name, vw.ac_arm_description,vw.opc_suffix_code,\n"
				+ "vw.ac_arm_code from vw_personal_details vw\n"
				+ "inner join officer_application of_app on of_app.opd_personal_id = vw.opd_personal_id and of_app.oa_status_id=1\n"
				+ "where of_app.es_id=? and vw.opd_status_id=1 order by of_app.in_index_id" ;

	
		stmt = conn.prepareStatement(q);
	
		stmt.setInt(1, es_id);
		System.err.println("indx====="+stmt);
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			
			String ArmCode = rs.getString("ac_arm_code");
			int ArmCodeStringSize= ArmCode.length();
			
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			//System.err.println("DataPre "+ DataPre);
			//System.err.println("DataM "+ DataM);
			
			Data=DataPre+DataM;
			
			//System.err.println("pers_cde==rrrrr====="+Data);
			
			list.add(rs.getString("in_index_id"));
			list.add(Data +rs.getString("opc_suffix_code"));
			list.add(rs.getString("opd_officer_name"));
			
			if (ArmCodeStringSize == 1) {
				list.add(rs.getString("ac_arm_description")+" "+"(0"+(rs.getString("ac_arm_code")+")"));
			}
			else {
				list.add(rs.getString("ac_arm_description")+" "+"("+(rs.getString("ac_arm_code")+")"));
			}
			//list.add(rs.getString("ac_arm_description")+"("+(rs.getString("ac_arm_code")+")"));
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}



public ArrayList<ArrayList<String>> IndexagainstmarksObtained(int es_id, int subject_id1) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String whr = "";
	String whr1 = "";
	String whr2 = "";

	

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q = "select  vw.opc_personal_code, of_app.in_index_id,ab.ab_marks_obtained from vw_personal_details vw\n"
				+ "inner join officer_application of_app on of_app.opd_personal_id = vw.opd_personal_id and of_app.oa_status_id=1 \n"
				+ "inner join answer_book ab on ab.oa_application_id = of_app.oa_application_id\n"
				+ "where of_app.es_id=?  and ab.sc_subject_id=? and vw.opd_status_id=1 order by of_app.in_index_id \n"
				+ "" ;

	
		stmt = conn.prepareStatement(q);
	
		stmt.setInt(1, es_id);
		stmt.setInt(2, subject_id1);
		ResultSet rs = stmt.executeQuery();
		System.out.println("stmt ---------jjjj---------"+stmt);
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("in_index_id"));
			list.add(rs.getString("ab_marks_obtained"));
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}
public ArrayList<ArrayList<String>> getPartPassedandFailures(String es_year,String oa_application_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	try {
		List<SUBJECT_CODE_M> sublist= comm.getsubjectlist(sessionFactory, 1);
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
		String qbuilder="";
		
		String whr="";
		
		
		if(!oa_application_id.equals("")) {
			
		whr+="where cy.oa_application_id=?";
		}

		
		
		
//		for (SUBJECT_CODE_M subject_CODE_M : sublist) {
//			qbuilder+= "string_agg(case when ab.ab_marks_obtained>200 then 'NP' else ab.ab_marks_obtained::text end, ','::text) filter (where ab.sc_subject_id::text = "+subject_CODE_M.getSc_subject_id()+"::text) as ta_"+subject_CODE_M.getSc_form_caption().toLowerCase()+" "+" ,\n";
//		}
//		qbuilder = qbuilder.substring(0,qbuilder.length()-3);
//		
//		q =  "select oa.oa_application_id,opc.opc_personal_code, opc.opc_suffix_code,opd.opd_officer_name,rc.rc_rank_name, ar.ac_arm_description,ar.ac_arm_code,\n"
//				+qbuilder
//				+ "from officer_application oa\n"
//				+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
//				+ "left join exam_schedule es on es.es_id = oa.es_id\n"
//				+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id\n"
//				+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
//				+ "left join officer_rank ofr on ofr.opd_personal_id = opd.opd_personal_id\n"
//				+ "left join officer_arm ofar on ofar.opd_personal_id = opd.opd_personal_id\n"
//				+ "inner join rank_code rc on rc.rc_rank_id = ofr.rc_rank_id\n"
//				+ "inner join arm_codes ar on ar.ac_arm_id = ofar.ac_arm_id\n"
//				+ "where extract (year from es.es_begin_date) = 2023 and \n"
//				+ "es.ec_exam_id=1\n"
//				+ "group by oa.oa_application_id,opc.opc_personal_code, opc.opc_suffix_code,opd.opd_officer_name,rc.rc_rank_name,ar.ac_arm_description,ar.ac_arm_code";
//	
		
q="select distinct cy.opc_personal_code||'  '||cy.opc_suffix_code as opc_personal_code, cy.pbda_sub_code, cy.oa_application_id,cy.opd_officer_name,cy.opc_suffix_code,cy.opd_officer_name,\n"
		+ "rc.rc_rank_name, ar.ac_arm_description,ar.ac_arm_code,cy.opd_personal_id,\n"
		+ "	case when cy.ta_a is null and py.ta_a is null then 'ABS' when cy.ta_a is null and py.ta_a is not null then py.ta_a else cy.ta_a end as ta_a,\n"
		+ "		case when cy.ta_l is null and py.ta_l is null then 'ABS' when cy.ta_l is null and py.ta_l is not null then py.ta_l else cy.ta_l end as ta_l,\n"
		+ "			case when cy.ta_h is null and py.ta_h is null then 'ABS' when cy.ta_h is null and py.ta_h is not null then py.ta_h else cy.ta_h end as ta_h,\n"
		+ "	case when cy.ta_c is null and py.ta_c is null then 'ABS' when cy.ta_c is null and py.ta_c is not null then py.ta_c else cy.ta_c end as ta_c,\n"
		+ "	case when cy.ta_t is null and py.ta_t is null then 'ABS' when cy.ta_t is null and py.ta_t is not null then py.ta_t else cy.ta_t end as ta_t,\n"
		+ "	string_agg(distinct getsubjectnamefromcode(cy.pbda_sub_code,1),',') filter (where cy.opd_partb =0)  as yettopass\n"
		+ "from\n"
		+ "(select opc.opc_personal_code,opc.opc_suffix_code,opd.opd_officer_name,opd.opd_partb,opd.pbda_sub_code,opd.opd_personal_id,oa.oa_application_id,ab.ab_status_id,\n"
		+ "string_agg(case when ab.ab_status_id=3 then 'UFM' when ab.ab_marks_obtained>= 200 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 51::text) as ta_a,\n"
		+ "string_agg(case  when ab.ab_status_id=3 then 'UFM' when ab.ab_marks_obtained>= 200 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 52::text) as ta_l,\n"
		+ "string_agg(case  when ab.ab_status_id=3 then 'UFM' when ab.ab_marks_obtained>= 200 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 53::text) as ta_h,\n"
		+ "string_agg(case  when ab.ab_status_id=3 then 'UFM' when ab.ab_marks_obtained>= 200 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 54::text) as ta_c,\n"
		+ "string_agg(case  when ab.ab_status_id=3 then 'UFM' when ab.ab_marks_obtained>= 200 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 55::text) as ta_t \n"
		+ "from officer_application oa\n"
		+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
		+ "left join exam_schedule es on es.es_id = oa.es_id\n"
		+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id and opd.opd_status_id != 0\n"
		+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
		+ "where oa.oa_status_id=1 and extract (year from es.es_begin_date) = "+es_year+" and es.ec_exam_id=1 and opd.opd_partb =0\n"
		+ "group by opc.opc_personal_code,opc.opc_suffix_code,opd.opd_officer_name,opd.opd_partb,opd.pbda_sub_code,opd.opd_personal_id,oa.oa_application_id,ab.ab_status_id) as cy\n"
		+ "left join \n"
		+ "(select opc.opc_personal_code,\n"
		+ "string_agg(case when ab.ab_marks_obtained>= 200 then 'PP' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 51::text) as ta_a,\n"
		+ "string_agg(case when ab.ab_marks_obtained>= 200 then 'PP' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 52::text) as ta_l,\n"
		+ "string_agg(case when ab.ab_marks_obtained>= 200 then 'PP' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 53::text) as ta_h,\n"
		+ "string_agg(case when ab.ab_marks_obtained>= 200 then 'PP' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 54::text) as ta_c,\n"
		+ "string_agg(case when ab.ab_marks_obtained>= 200 then 'PP' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 55::text) as ta_t \n"
		+ "from officer_application oa\n"
		+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
		+ "left join exam_schedule es on es.es_id = oa.es_id\n"
		+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id and opd.opd_status_id != 0 \n"
		+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
		+ "where oa.oa_status_id=1 and extract (year from es.es_begin_date) != "+es_year+" and es.ec_exam_id=1 and (opd.opd_partb =0 or opd.opd_partb ="+es_year+") \n"
		+ "group by opc.opc_personal_code\n"
		+ "order by 1) py on cy.opc_personal_code=py.opc_personal_code\n"
		+ "left join officer_rank ofr on ofr.opd_personal_id = cy.opd_personal_id and ofr.or_status_id=1 \n"
		+ "left join officer_arm ofar on ofar.opd_personal_id = cy.opd_personal_id and ofar.oa_status_id=1 \n"
		+ "inner join rank_code rc on rc.rc_rank_id = ofr.rc_rank_id\n"
		+ "inner join arm_codes ar on ar.ac_arm_id = ofar.ac_arm_id\n"
		+ " "+whr+"\n"
		+ "group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15\n"
		+ "order by 1";
		
		stmt = conn.prepareStatement(q);
		if(!oa_application_id.equals("")) {
			stmt.setInt(1,Integer.parseInt(oa_application_id));
		}
		System.out.println("stmt -------gggg-----------"+stmt);
		ResultSet rs = stmt.executeQuery();
int i=1;
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			String Data=rs.getString("opc_personal_code");
			String ArmCode = rs.getString("ac_arm_code");
			int ArmCodeStringSize= ArmCode.length();
			
			
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			
			Data=DataPre+DataM;
			list.add(String.valueOf(i));
			list.add(Data);
			list.add(rs.getString("rc_rank_name"));
			list.add(rs.getString("opd_officer_name"));
			if (ArmCodeStringSize == 1) {
				list.add(rs.getString("ac_arm_description")+" "+"(0"+(rs.getString("ac_arm_code")+")"));
			}
			else {
				list.add(rs.getString("ac_arm_description")+" "+"("+(rs.getString("ac_arm_code")+")"));
			}
//			list.add(rs.getString("ac_arm_description")+"("+(rs.getString("ac_arm_code")+")"));
//			list.add(rs.getString("ac_arm_description")+"("+(rs.getString("ac_arm_code")+")"));
			for (SUBJECT_CODE_M subject_CODE_M : sublist) {
				list.add(rs.getString("ta_"+subject_CODE_M.getSc_form_caption().toLowerCase()));			
			}
			list.add(rs.getString("yettopass"));
			
			
			list.add(rs.getString("opd_personal_id"));
			list.add(rs.getString("pbda_sub_code"));
			list.add(rs.getString("oa_application_id"));
			list.add(Data);
			alist.add(list);
			//System.out.println("list ------------------"+list);
			i++;

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}





public ArrayList<ArrayList<String>> IndexagainstPersonNo(int es_id, int ssd_subject_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	
	


	Connection conn = null;
	String q = "";
	String whr = "";
	String whr1 = "";
	String whr2 = "";

	

	
	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;


	
		
//		q="select vpd.opc_personal_code,ofa.in_index_id, ecc.ecc_name,vpd.opc_suffix_code from officer_application ofa\n"
//				+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id and vpd.opd_status_id=1\n"
//				+ "inner join exam_center_code ecc on ecc.ecc_center_code= ofa.oa_center_granted\n"
//				+ "where ofa.es_id=? and ofa.in_index_id !=0 and ofa.oa_center_granted=? and ofa.oa_status_id=1 order by vpd.opc_personal_code";
//		
		q="select distinct vpd.opc_personal_code,ofa.in_index_id, ecc.ecc_name,vpd.opc_suffix_code\n"
				+ "from officer_application ofa\n"
				+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id and vpd.opd_status_id=1\n"
				+ "inner join exam_center_code ecc on ecc.ecc_center_code= ofa.oa_center_granted\n"
				+ "inner join index_slip_master ism on ism.ism_indexno=ofa.in_index_id\n"
				+ "inner join index_slip_manual ismn on ism.ism_id=ismn.is_ism_id\n"
				+ "where ofa.es_id=? and ofa.in_index_id !=0  and \n"
				+ "ofa.oa_status_id=1 and vpd.opd_isactive='yes' \n"
				+ "and ofa.oa_center_granted=?\n"
				+ "order by ofa.in_index_id";
		stmt = conn.prepareStatement(q);
		

		stmt.setInt(1, es_id);
		stmt.setInt(2, ssd_subject_id);
	
		
		ResultSet rs = stmt.executeQuery();
		System.out.println("stmt ---------persno---------"+stmt);


		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			//System.err.println("DataPre "+ DataPre);
			//System.err.println("DataM "+ DataM);
			
			Data=DataPre+DataM;
			
			//System.err.println("pers_cde==rrrrr====="+Data);
			
			list.add(Data +rs.getString("opc_suffix_code"));
			list.add(rs.getString("in_index_id"));
			list.add(rs.getString("ecc_name"));

			alist.add(list);

		}

	
	
		rs.close();
		stmt.close();
		conn.close();
		
	
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}


//===========================CHANCE WISE ANALYSIS REPORT=======================//

public ArrayList<ArrayList<String>> ChanceWisAnalysisReport(String fr_chnace1, String t_chnace1) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q1 = "";
	String q = "";
	
	try {
		
		if(!fr_chnace1.equals("") && !t_chnace1.equals("")) {
			
			q1="where a.chance  between "+fr_chnace1+" and  "+t_chnace1+"";
		}
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		
		q="select * from (select count(vpd.opd_personal_id) as chance,vpd.opc_personal_code,vpd.opd_officer_name,vpd.ac_arm_description,vpd.ac_arm_code,\n"
				+ "case when opd_partb=0 then 'Fail' else 'Pass' end as status \n"
				+ "from officer_results ofr\n"
				+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofr.opd_personal_id  and vpd.opd_status_id=1\n"
//				+ "where ofr.es_id=? \n"
				+ "group by vpd.opc_personal_code,vpd.opd_officer_name,vpd.ac_arm_description,opd_partb,vpd.ac_arm_code) a\n"
				+ ""+q1+" order by a.opc_personal_code  ";

	
		stmt = conn.prepareStatement(q);
		ResultSet rs = stmt.executeQuery();
System.err.println("chan==========="+stmt);
       int i=1;
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(String.valueOf(i));
			list.add(rs.getString("opc_personal_code"));
			list.add(rs.getString("opd_officer_name"));
			list.add(rs.getString("ac_arm_description")+"("+(rs.getString("ac_arm_code")+")"));
			list.add(rs.getString("chance"));
			list.add(rs.getString("status"));
	
			alist.add(list);
			i++;
           
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}


//===========================PART ABSENTEES=======================//

public ArrayList<ArrayList<String>> PartAbsentees(int es_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q="select DISTINCT vpd.opc_personal_code,a.opd_personal_id,vpd.rc_rank_name , vpd.opd_officer_name,string_agg(sub,',')as subject,vpd.opc_suffix_code from (select oa.opd_personal_id,'A' as sub												\n"
				+ "	from officer_application oa, partb_d_application pbd											\n"
				+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
				+ "	and (pbd.pbda_subjects & 2)= 2											\n"
				+ "	and es_id = ?											\n"
				+ "	and oa.in_index_id<>0											\n"
				+ "	and oa.oa_status_id=1											\n"
				+ "	and (oa.oa_application_id not in											\n"
				+ "		(select oa_application_id from answer_book where sc_subject_id =51)or 										\n"
				+ "	oa.oa_application_id in											\n"
				+ "		(select oa_application_id from answer_book where sc_subject_id= 51 and ab_marks_obtained is null))										\n"
				+ "union all												\n"
				+ "	select oa.opd_personal_id,'L' as sub											\n"
				+ "	from officer_application oa, partb_d_application pbd											\n"
				+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
				+ "	and (pbd.pbda_subjects & 4)= 4											\n"
				+ "	and es_id = ?											\n"
				+ "	and oa.in_index_id<>0											\n"
				+ "	and oa.oa_status_id=1											\n"
				+ "	and 											\n"
				+ "	(oa.oa_application_id not in											\n"
				+ "		(select oa_application_id from answer_book where sc_subject_id =52)or 										\n"
				+ "	oa.oa_application_id in											\n"
				+ "		(select oa_application_id from answer_book where sc_subject_id= 52 and ab_marks_obtained is null))										\n"
				+ "union all												\n"
				+ "	select oa.opd_personal_id,'H' as sub											\n"
				+ "	from officer_application oa, partb_d_application pbd											\n"
				+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
				+ "	and (pbd.pbda_subjects & 8)= 8											\n"
				+ "	and es_id = ?											\n"
				+ "	and oa.in_index_id<>0											\n"
				+ "	and oa.oa_status_id=1											\n"
				+ "	and 											\n"
				+ "	(oa.oa_application_id not in											\n"
				+ "		(select oa_application_id from answer_book where sc_subject_id =53)or 										\n"
				+ "	oa.oa_application_id in											\n"
				+ "		(select oa_application_id from answer_book where sc_subject_id= 53 and ab_marks_obtained is null))										\n"
				+ "												   union all\n"
				+ "	select oa.opd_personal_id,'T' as sub											\n"
				+ "	from officer_application oa, partb_d_application pbd											\n"
				+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
				+ "	and (pbd.pbda_subjects & 32)= 32											\n"
				+ "	and es_id = ?											\n"
				+ "	and oa.in_index_id<>0											\n"
				+ "	and oa.oa_status_id=1											\n"
				+ "	and 											\n"
				+ "	(oa.oa_application_id not in											\n"
				+ "		(select oa_application_id from answer_book where sc_subject_id =55)or 										\n"
				+ "	oa.oa_application_id in											\n"
				+ "		(select oa_application_id from answer_book where sc_subject_id= 55 and ab_marks_obtained is null))										\n"
				+ "												   union all\n"
				+ "	select oa.opd_personal_id,'C' as sub											\n"
				+ "	from officer_application oa, partb_d_application pbd											\n"
				+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
				+ "	and (pbd.pbda_subjects & 16)= 16											\n"
				+ "	and es_id = ?											\n"
				+ "	and oa.in_index_id<>0											\n"
				+ "	and oa.oa_status_id=1											\n"
				+ "	and 											\n"
				+ "	(oa.oa_application_id not in											\n"
				+ "		(select oa_application_id from answer_book where sc_subject_id =54)or 										\n"
				+ "	oa.oa_application_id in											\n"
				+ "		(select oa_application_id from answer_book where sc_subject_id= 54 and ab_marks_obtained is null))) a		\n"
				+ "	inner join vw_personal_details vpd on vpd.opd_personal_id=a.opd_personal_id and vpd.opd_status_id=1  \n"
				+ "	group by 1,2,3,4,vpd.opc_suffix_code order by 1								\n"
				+ "\n"
				+ "";
		
	

	
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
		stmt.setInt(2, es_id);
		stmt.setInt(3, es_id);
		stmt.setInt(4, es_id);
		stmt.setInt(5, es_id);
		ResultSet rs = stmt.executeQuery();
		
		System.err.println("absentees=============="+stmt);
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			
			Data=DataPre+DataM;
			
			
			list.add(Data +rs.getString("opc_suffix_code"));
			list.add(rs.getString("rc_rank_name")+" "+(rs.getString("opd_officer_name")+" "));
			list.add(rs.getString("subject"));
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}



public ArrayList<ArrayList<String>> CenterWiseListOfSubject(int es_id,int sub_id, int centre_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String q1 = "";
	
	try {
		
		if(centre_id != 0) {
			q1+="and ismn.is_ecc_center_code=?";
		}

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q="select vpd.opc_personal_code, vpd.opd_officer_name, vpd.ac_arm_description, vpd.ac_arm_code,sc.sc_subject_name, ismn.is_ecc_center_code, ecc.ecc_name,vpd.opc_suffix_code \n"
				+ "from index_slip_manual ismn\n"
				+ "inner join index_slip_master ismr on ismr.ism_id=ismn.is_ism_id\n"
				+ "inner join vw_personal_details vpd on vpd.opc_personal_code=ismr.ism_armyno and vpd.opd_status_id=1\n"
				+ "inner join subject_code sc on sc.sc_subject_id=ismn.is_sc_subject_id\n"
				+ "inner join exam_center_code ecc on ecc.ecc_center_code= ismn.is_ecc_center_code\n"
				+ "where ismr.ism_es_id=? and ismn.is_sc_subject_id=? and   ismr.ism_indexno !=0 "+q1+"	order by ismn.is_ecc_center_code,vpd.opc_personal_code ";

	
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
		stmt.setInt(2, sub_id);
		
		
		if(centre_id != 0) {
			stmt.setInt(3, centre_id);
		}
		ResultSet rs = stmt.executeQuery();
System.err.println("stmt==========="+stmt);
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			
			String ArmCode = rs.getString("ac_arm_code");
			int ArmCodeStringSize= ArmCode.length();
			
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			
			Data=DataPre+DataM;
			
			
			list.add(Data +rs.getString("opc_suffix_code"));
			list.add(rs.getString("opd_officer_name"));
			if (ArmCodeStringSize == 1) {
				list.add(rs.getString("ac_arm_description")+" "+"(0"+(rs.getString("ac_arm_code")+")"));
			}
			else {
				list.add(rs.getString("ac_arm_description")+" "+"("+(rs.getString("ac_arm_code")+")"));
			}
			//list.add(rs.getString("ac_arm_description")+"("+(rs.getString("ac_arm_code")+")"));
			list.add(rs.getString("sc_subject_name"));
			list.add(Data +rs.getString("opc_suffix_code"));
			list.add(rs.getString("ecc_name"));
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}




public ArrayList<ArrayList<String>> SummaryPartB(int es_id,int exam_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;


		
		q="select sc.sc_subject_code,sc.sc_subject_name, count(ofa.oa_application_id) as had_to_apear, \n"
				+ "count(ofa.oa_application_id) filter(where ofa.in_index_id !=0) as appear,"
				+ "count(ofa.oa_application_id) filter(where ofa.in_index_id =0) as abs\n"
				+ "from officer_application ofa \n"
				+ "inner join officer_personal_code ofc on ofc.opd_personal_id = ofa.opd_personal_id and ofc.opc_status_id=1\n"
				+ "inner join index_slip_master ism on ism.ism_armyno= ofc.opc_personal_code\n"
				+ "inner join index_slip_manual ismn on ismn.is_ism_id=ism.ism_id\n"
				+ "inner join subject_code sc on sc.sc_subject_id=ismn.is_sc_subject_id\n"
				+ "where ofa.es_id=? and ofa.oa_status_id=1 and sc.ec_exam_id=? group by 1,2 order by 1\n";

	
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
		stmt.setInt(2, exam_id);
		System.err.println("summary==========="+stmt);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("sc_subject_name"));
			list.add(rs.getString("had_to_apear"));
			list.add(rs.getString("appear"));
			list.add(rs.getString("abs"));
			
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}


public ArrayList<ArrayList<String>> ResultApprovalSheet(String es_year) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	
	
	int es_year1= Integer.parseInt(es_year)-1;
	int es_year2= Integer.parseInt(es_year)-2;
	int es_year3= Integer.parseInt(es_year)-3;
	
	
	
	
	
	
	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
q="select sc.sc_subject_name,\n"
		+ "((count(*) filter(where ab.ab_marks_obtained>200 and extract (year from es.es_begin_date) = "+es_year3+"))*100/\n"
		+ "(NULLIF(count(*) filter(where extract (year from es.es_begin_date) = "+es_year3+"),0))) as per2020,\n"
		+ "((count(*) filter(where ab.ab_marks_obtained>200 and extract (year from es.es_begin_date) = "+es_year2+"))*100/\n"
		+ "(NULLIF(count(*) filter(where extract (year from es.es_begin_date) = "+es_year2+"),0))) as per2021,\n"
		+ "((count(*) filter(where ab.ab_marks_obtained>200 and extract (year from es.es_begin_date) = "+es_year1+"))*100/\n"
		+ "(NULLIF(count(*) filter(where extract (year from es.es_begin_date) = "+es_year1+"),0))) as per2022,\n"
		+ "count(*) filter(where extract (year from es.es_begin_date) = "+es_year+") as total2023,\n"
		+ "\n"
		+ "((count(*) filter(where ab.ab_marks_obtained>201 and extract (year from es.es_begin_date) = "+es_year+"))*100::float/\n"
		+ "(NULLIF(count(*) filter(where extract (year from es.es_begin_date) = "+es_year+")::float,0))) as per201,\n"
		+ "((count(*) filter(where (ab.ab_marks_obtained between 200  and 190) and extract (year from es.es_begin_date) = "+es_year+"))*100::float/\n"
		+ "(NULLIF(count(*) filter(where extract (year from es.es_begin_date) = "+es_year+")::float,0))) as per190,\n"
		+ "((count(*) filter(where (ab.ab_marks_obtained between 180  and 189)and extract (year from es.es_begin_date) = "+es_year+"))*100::float/\n"
		+ "(NULLIF(count(*) filter(where extract (year from es.es_begin_date) = "+es_year+")::float,0))) as per180,\n"
		+ "((count(*) filter(where (ab.ab_marks_obtained between 170  and 179) and extract (year from es.es_begin_date) = "+es_year+"))*100::float/\n"
		+ "(NULLIF(count(*) filter(where extract (year from es.es_begin_date) = "+es_year+")::float,0))) as per170,\n"
		+ "((count(*) filter(where ab.ab_marks_obtained<170 and extract (year from es.es_begin_date) = "+es_year+"))*100::float/\n"
		+ "(NULLIF(count(*) filter(where extract (year from es.es_begin_date) = "+es_year+")::float,0))) as per160\n"
		+ "\n"
		+ "from officer_application oa\n"
		+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
		+ "left join exam_schedule es on es.es_id = oa.es_id\n"
		+ "inner join subject_code sc on sc.sc_subject_id = ab.sc_subject_id where oa.oa_status_id=1 and es.ec_exam_id=1 \n"
		+ "group by sc.sc_subject_name order by sc.sc_subject_name";

	
		stmt = conn.prepareStatement(q);
		System.err.println("es_year=========="+stmt);
		ResultSet rs = stmt.executeQuery();
		
		DecimalFormat df_double = new DecimalFormat("0.00");
		DecimalFormat df_int = new DecimalFormat("0");
	
		
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			
		
			double per201 =Double.parseDouble(rs.getString("per201"));
			double per190 =Double.parseDouble(rs.getString("per190"));
			double per180 =Double.parseDouble(rs.getString("per180"));
			double per170 =Double.parseDouble(rs.getString("per170"));
			double per160 =Double.parseDouble(rs.getString("per160"));
			
			
			if(per201==0) {
				per201=1;
			}
			if(per190==0) {
				per190=1;
			}
			if(per180==0) {
				per180=1;
			}
			if(per170==0) {
				per170=1;
			}
			if(per160==0) {
				per160=1;
			}
			System.err.println("per201-------------"+per201);
			
			list.add(rs.getString("sc_subject_name"));
			list.add(rs.getString("per2020"));
			list.add(rs.getString("per2021"));
			list.add(rs.getString("per2022"));
			list.add(rs.getString("total2023"));
			list.add(df_double.format(per201));
			list.add(df_double.format(per190));
			list.add(df_double.format(per180));
			list.add(df_double.format(per170));
			list.add(df_double.format(per160));
			
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

public ArrayList<ArrayList<String>> getparamountcardlist(int ec_exam_id2) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	try {
		List<SUBJECT_CODE_M> sublist= comm.getsubjectlist(sessionFactory, 1);
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
		String qbuilder="";

		if(ec_exam_id2 == 1) {
q="select cy.opc_personal_code||''||cy.opc_suffix_code as opc_personal_code,cy.opd_officer_name,cy.opc_suffix_code,cy.opd_officer_name,rc.rc_rank_name, ar.ac_arm_description,ar.ac_arm_code,\n"
		+ "	case when cy.ta_a is null and py.ta_a is null then 'F' when cy.ta_a is null and py.ta_a is not null then py.ta_a else cy.ta_a end as ta_a,\n"
		+ "		case when cy.ta_l is null and py.ta_l is null then 'F' when cy.ta_l is null and py.ta_l is not null then py.ta_l else cy.ta_l end as ta_l,\n"
		+ "			case when cy.ta_h is null and py.ta_h is null then 'F' when cy.ta_h is null and py.ta_h is not null then py.ta_h else cy.ta_h end as ta_h,\n"
		+ "	case when cy.ta_c is null and py.ta_c is null then 'F' when cy.ta_c is null and py.ta_c is not null then py.ta_c else cy.ta_c end as ta_c,\n"
		+ "	case when cy.ta_t is null and py.ta_t is null then 'F' when cy.ta_t is null and py.ta_t is not null then py.ta_t else cy.ta_t end as ta_t\n"
		+ "\n"
		+ "from\n"
		+ "(select opc.opc_personal_code,opc.opc_suffix_code,opd.opd_officer_name,opd.opd_partb,opd.pbda_sub_code,opd.opd_personal_id,\n"
		+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 51::text) as ta_a,\n"
		+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 52::text) as ta_l,\n"
		+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 53::text) as ta_h,\n"
		+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 54::text) as ta_c,\n"
		+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 55::text) as ta_t \n"
		+ "from officer_application oa\n"
		+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
		+ "left join exam_schedule es on es.es_id = oa.es_id\n"
		+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id and opd.opd_status_id=1\n"
		+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
		+ "where oa.oa_status_id=1 and opd.opd_isactive='yes' and es.ec_exam_id=1\n"
		+ "group by opc.opc_personal_code,opc.opc_suffix_code,opd.opd_officer_name,opd.opd_partb,opd.pbda_sub_code,opd.opd_personal_id) as cy\n"
		+ "left join \n"
		+ "(select opc.opc_personal_code,\n"
		+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 51::text) as ta_a,\n"
		+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 52::text) as ta_l,\n"
		+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 53::text) as ta_h,\n"
		+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 54::text) as ta_c,\n"
		+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
		+ "		  ) filter (where ab.sc_subject_id::text = 55::text) as ta_t \n"
		+ "from officer_application oa\n"
		+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
		+ "left join exam_schedule es on es.es_id = oa.es_id\n"
		+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id and opd.opd_status_id=1\n"
		+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
		+ "where oa.oa_status_id=1 and opd.opd_isactive='yes'  and es.ec_exam_id=1 and (opd.opd_partb =0 or opd.opd_partb != 0)\n"
		+ "group by opc.opc_personal_code\n"
		+ "order by 1) py on cy.opc_personal_code=py.opc_personal_code\n"
		+ "left join officer_rank ofr on ofr.opd_personal_id = cy.opd_personal_id\n"
		+ "left join officer_arm ofar on ofar.opd_personal_id = cy.opd_personal_id\n"
		+ "inner join rank_code rc on rc.rc_rank_id = ofr.rc_rank_id\n"
		+ "inner join arm_codes ar on ar.ac_arm_id = ofar.ac_arm_id\n"
		+ "group by 1,2,3,4,5,6,7,8,9,10,11,12\n"
		+ "order by 1\n"
		+ "";
		}
		if(ec_exam_id2 == 2) {
			q="select cy.opc_personal_code||''||cy.opc_suffix_code as opc_personal_code,cy.opd_officer_name,cy.opc_suffix_code,cy.opd_officer_name,rc.rc_rank_name, ar.ac_arm_description,ar.ac_arm_code,\n"
					+ "	case when cy.ta_a is null and py.ta_a is null then 'F' when cy.ta_a is null and py.ta_a is not null then py.ta_a else cy.ta_a end as ta_a,\n"
					+ "		case when cy.ta_l is null and py.ta_l is null then 'F' when cy.ta_l is null and py.ta_l is not null then py.ta_l else cy.ta_l end as ta_l,\n"
					+ "			case when cy.ta_h is null and py.ta_h is null then 'F' when cy.ta_h is null and py.ta_h is not null then py.ta_h else cy.ta_h end as ta_h,\n"
					+ "	case when cy.ta_c is null and py.ta_c is null then 'F' when cy.ta_c is null and py.ta_c is not null then py.ta_c else cy.ta_c end as ta_c,\n"
					+ "	case when cy.ta_t is null and py.ta_t is null then 'F' when cy.ta_t is null and py.ta_t is not null then py.ta_t else cy.ta_t end as ta_t,\n"
					+ "	case when cy.ta_s is null and py.ta_s is null then 'F' when cy.ta_s is null and py.ta_s is not null then py.ta_s else cy.ta_s end as ta_s\n"
					+ "\n"
					+ "from\n"
					+ "(select opc.opc_personal_code,opc.opc_suffix_code,opd.opd_officer_name,opd.opd_partb,opd.pbda_sub_code,opd.opd_personal_id,\n"
					+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 56::text) as ta_a,\n"
					+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 57::text) as ta_l,\n"
					+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 58::text) as ta_h,\n"
					+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 59::text) as ta_c,\n"
					+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 60::text) as ta_t ,\n"
					+ " string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 61::text) as ta_s \n"
					+ "from officer_application oa\n"
					+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
					+ "left join exam_schedule es on es.es_id = oa.es_id\n"
					+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id and opd.opd_status_id=1\n"
					+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
					+ "where oa.oa_status_id=1 and opd.opd_isactive='yes' and es.ec_exam_id=1\n"
					+ "group by opc.opc_personal_code,opc.opc_suffix_code,opd.opd_officer_name,opd.opd_partb,opd.pbda_sub_code,opd.opd_personal_id) as cy\n"
					+ "left join \n"
					+ "(select opc.opc_personal_code,\n"
					+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 56::text) as ta_a,\n"
					+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 57::text) as ta_l,\n"
					+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 58::text) as ta_h,\n"
					+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 59::text) as ta_c,\n"
					+ "string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 60::text) as ta_t ,\n"
					+ " string_agg(case when ab.ab_marks_obtained>=200 then 'P' else 'F' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 61::text) as ta_s \n"
					+ "from officer_application oa\n"
					+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
					+ "left join exam_schedule es on es.es_id = oa.es_id\n"
					+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id and opd.opd_status_id=1\n"
					+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
					+ "where oa.oa_status_id=1 and opd.opd_isactive='yes'  and es.ec_exam_id=2 and (opd.opd_partd =0 or opd.opd_partd != 0)\n"
					+ "group by opc.opc_personal_code\n"
					+ "order by 1) py on cy.opc_personal_code=py.opc_personal_code\n"
					+ "left join officer_rank ofr on ofr.opd_personal_id = cy.opd_personal_id\n"
					+ "left join officer_arm ofar on ofar.opd_personal_id = cy.opd_personal_id\n"
					+ "inner join rank_code rc on rc.rc_rank_id = ofr.rc_rank_id\n"
					+ "inner join arm_codes ar on ar.ac_arm_id = ofar.ac_arm_id\n"
					+ "group by 1,2,3,4,5,6,7,8,9,10,11,12,13\n"
					+ "order by 1";
		}
		
		if(ec_exam_id2 != 3) {
		stmt = conn.prepareStatement(q);
		
		ResultSet rs = stmt.executeQuery();
		
		System.out.println("paramount ------------------"+stmt);
		 int i=1;
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(String.valueOf(i));
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			//System.err.println("DataPre "+ DataPre);
			//System.err.println("DataM "+ DataM);
			
			Data=DataPre+DataM;
			
			//System.err.println("pers_cde==rrrrr====="+Data);
			
			list.add(Data);
			list.add(rs.getString("rc_rank_name"));
			list.add(rs.getString("opd_officer_name"));
			list.add(rs.getString("ta_a")+" "+(rs.getString("ta_l"))+" "+ (rs.getString("ta_h"))+" "+(rs.getString("ta_c"))+" "+(rs.getString("ta_t")));
			
			
			alist.add(list);
i++;
		}
		
	
		rs.close();
		stmt.close();
		conn.close();
		}
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

public ArrayList<ArrayList<String>> getdetailsResultWithHeld(int es_id,int oa_application_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String whr = "";
	String whr1 = "";
	String whr2 = "";

	

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		if (oa_application_id != 0) {
			whr += "and oapp.oa_application_id=?";
		}
//		q = "select mrw.* from mv_result_withheld mrw where mrw.es_id=?";
		
		q="SELECT DISTINCT oapp.es_id,\n"
				+ "    vw.opc_personal_code,\n"
				+ "    vw.rc_rank_name,\n"
				+ "    vw.opd_officer_name,\n"
				+ "    vw.ac_arm_description,\n"
				+ "    vw.ac_arm_code\n"
				+ "   FROM results_withheld rw\n"
				+ "     JOIN vw_personal_details vw ON vw.opc_personal_code::text = rw.personal_no::text\n"
				+ "     JOIN officer_application oapp ON oapp.opd_personal_id = vw.opd_personal_id where rw.res_status_id=1  and oapp.es_id=? "+whr+" order by vw.opc_personal_code";

	
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
		if (oa_application_id != 0) {
		stmt.setInt(2, oa_application_id);
		}
		ResultSet rs = stmt.executeQuery();
System.err.println("res---------"+stmt);
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("opc_personal_code"));
			list.add(rs.getString("rc_rank_name"));
			list.add(rs.getString("opd_officer_name"));
			list.add(rs.getString("ac_arm_description")+"("+(rs.getString("ac_arm_code")+")"));
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}


}
