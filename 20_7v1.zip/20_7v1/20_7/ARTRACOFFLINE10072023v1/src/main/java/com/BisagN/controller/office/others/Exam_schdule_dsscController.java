package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.trans.Examination_centreController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.others.ExaminationschedulepartdDao;
import com.BisagN.models.officers.masters.CHOICE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.DSSC_COURSE_VACANCY_RESERVE;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.EXAM_SCHEDULE_DETAIL_M;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Exam_schdule_dsscController {


	@Autowired
	Examination_centreController exmCon = new Examination_centreController();
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	 @Autowired
		private RoleBaseMenuDAO roledao; 
	
	@Autowired
	CommonController comm= new CommonController();
	
	@Autowired
	private ExaminationschedulepartdDao objDAO;
	
	
	
		
		 @RequestMapping(value = "exam_schedule_Url", method = RequestMethod.POST)
		  public ModelAndView exam_schedule_Url(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg,String Subjectid) {
		  
		  
			 Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
			 Mmap.put("getChoicemstListDDL", comm.getChoicemstListDDL( sessionFactory));
			 Mmap.put("getChoicemstListsize", comm.getChoicemstListDDL( sessionFactory).size());
			 
			 if(request.getHeader("Referer") == null ) { 
    			 session.invalidate();
    			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
    			 return new ModelAndView("redirect:/login");
    		 }

        	 String roleid1 = session.getAttribute("roleid").toString();
    		 Boolean val = roledao.ScreenRedirect("Search_exam_schedule_Url", roleid1);		
    			if(val == false) {
    				return new ModelAndView("AccessTiles");
    		}
			 
			 
			 
	          Mmap.put("msg", msg);
	      return new ModelAndView("exam_schedule_dscc_tile");
	}
		  
		
		
		@RequestMapping(value = "/DSSCexam_scheduleACtion", method = RequestMethod.POST)
		public ModelAndView DSSCexam_scheduleACtion(ModelMap Mmap, HttpSession session,
				@RequestParam(value = "msg", required = false) String msg, HttpServletRequest request)
				throws ParseException {
			
			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
		
			try {
		
			EXAM_SCHEDULE exmgmt = new EXAM_SCHEDULE();
		
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			

			int id = exmgmt.getEs_id() > 0 ? exmgmt.getEs_id() : 0;
			 String username = session.getAttribute("username").toString();
			Date date = new Date();
			
			DateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
			String ec_exam_id = request.getParameter("ec_exam_id1");
			
			
			
			
               if(request.getParameter("ec_exam_id1").equals("0") ){
				
	             Mmap.put("msg","Please select Exam Name.");
				 return new ModelAndView("redirect:Search_exam_schedule_Url");	
			} 

			if(request.getParameter("es_begin_date").equals("DD/MM/YYYY") ){
				Mmap.put("msg","Please select Begin Date.");
				 return new ModelAndView("redirect:Search_exam_schedule_Url");	
			} 
			
			if(ec_exam_id == "1")
			{
 
				if(request.getParameter("min_year").equals("") ){
					Mmap.put("msg","Please Enter Minimum Eligibility.");
					 return new ModelAndView("redirect:Search_exam_schedule_Url");	
				} 

				if(request.getParameter("es_max_year").equals("") ){
					Mmap.put("msg","Please Enter Maximum Eligibility.");
					 return new ModelAndView("redirect:Search_exam_schedule_Url");	
				}
				
				
				
			}

			if(ec_exam_id == "3")
			{
				
				 List<CHOICE_M>count_vali1=comm.getChoicemstListDDL(sessionFactory) ;
				
				for(int k=1;k<=count_vali1.size();k++){

					if(request.getParameter("dssc_course_date"+k).equals("DD/MM/YYYY") ){
						
						Mmap.put("msg","Please Enter Date.");
						 return new ModelAndView("redirect:Search_exam_schedule_Url");	
					} 

					if(request.getParameter("dssc_course_no"+k).equals("0") ){
					 
						Mmap.put("msg","Please Enter Course No.");
						 return new ModelAndView("redirect:Search_exam_schedule_Url");	
					}

					if(request.getParameter("vacancy"+k).equals("") ){
						 
						Mmap.put("msg","Please Enter Vacancy.");
						 return new ModelAndView("redirect:Search_exam_schedule_Url");	
					} 

					if(request.getParameter("reserve"+k).equals("") ){
						 
						Mmap.put("msg","Please Enter Reserve.");
						 return new ModelAndView("redirect:Search_exam_schedule_Url");	
					}		
				
				
				}
				}

			
			int count_vali = Integer.parseInt(request.getParameter("count_vali"));
			
		
			for(int k=1;k<=count_vali;k++){
				
				if(request.getParameter("esd_date"+k).equals("DD/MM/YYYY") ){
					 	
					Mmap.put("msg","Please Enter Date.");
					 return new ModelAndView("redirect:Search_exam_schedule_Url");	
				} 

				if(request.getParameter("esd_cutoff"+k).equals("0") ){
					 	
					Mmap.put("msg","Please Enter Minimun Marks.");
					 return new ModelAndView("redirect:Search_exam_schedule_Url");	
				}

			}
			
			
			
			
			
			
			
			
				
				
	if(id == 0) {
		
		if(ec_exam_id.equals("1") ) {
			int year =Integer.parseInt(request.getParameter("min_year"));
			String dimandingYear=request.getParameter("es_begin_date").split("/")[0]+"/"+request.getParameter("es_begin_date").split("/")[1]+"/"+String.valueOf(Integer.parseInt(request.getParameter("es_begin_date").split("/")[2])-year);
			exmgmt.setEs_to_year(comm.convertStringToDate(dimandingYear));
			
			int es_max_year =Integer.parseInt( request.getParameter("es_max_year"));
			exmgmt.setEs_max_year(es_max_year);
		
		}
		
		if(ec_exam_id.equals("2") ) {
			int year =Integer.parseInt(request.getParameter("min_year"));
			String dimandingYear=request.getParameter("es_begin_date").split("/")[0]+"/"+request.getParameter("es_begin_date").split("/")[1]+"/"+String.valueOf(Integer.parseInt(request.getParameter("es_begin_date").split("/")[2])-year);
			exmgmt.setEs_to_year(comm.convertStringToDate(dimandingYear));
			
			int es_max_year =Integer.parseInt( request.getParameter("es_max_year"));
			exmgmt.setEs_max_year(es_max_year);
		
		}
		
			
			
		
			
		
			  
			String es_consider_date = request.getParameter("es_consider_date");
		
			
			
			String es_begin_date= request.getParameter("es_begin_date");
			//String es_begin_todate= request.getParameter("es_begin_todate");
			String es_sub_date = request.getParameter("exam_schedule_dt1");
			
		
			
			List<Map<String, Object>> list2= objDAO.getdatafromsubmst(ec_exam_id);
				String exam_id =String.valueOf(list2.get(0).get("ec_exam_id"));
				
				
		    exmgmt.setEc_exam_id(Integer.parseInt(exam_id));
			
		
			
		
			
			exmgmt.setEs_begin_date(comm.convertStringToDate(es_begin_date));
			//exmgmt.setEs_begin_todate(comm.convertStringToDate(es_begin_todate));
			
			
		//	exmgmt.setEs_index_mode(request.getParameter("es_index_mode"));
			exmgmt.setEs_created_by(username);
			exmgmt.setEs_creation_date(date);
			exmgmt.setEs_part_b(request.getParameter("es_part_b"));
			exmgmt.setEs_part_d(request.getParameter("es_part_d"));
			exmgmt.setEs_compensatory(request.getParameter("es_compensatory"));
			exmgmt.setEs_consider_date(es_consider_date);
	
			   
			
			
			if(ec_exam_id.equals("3")) {
				int min_year_dssc=0;
				 min_year_dssc =Integer.parseInt(request.getParameter("min_year_dssc_dos"));
				String dssc_year=request.getParameter("es_dssc_check_year").split("/")[0]+"/"+request.getParameter("es_dssc_check_year").split("/")[1]+"/"+String.valueOf(Integer.parseInt(request.getParameter("es_dssc_check_year").split("/")[2])-min_year_dssc);
				  
				exmgmt.setEs_to_year(comm.convertStringToDate(dssc_year));
				String es_dssc_chance=request.getParameter("es_dssc_chance");
				exmgmt.setEs_dssc_chance(Integer.parseInt(es_dssc_chance));
				exmgmt.setEs_dssc_month(Integer.parseInt(request.getParameter("es_dssc_month")));
				
			}
			String es_dssc_check_year=request.getParameter("es_dssc_check_year");
			exmgmt.setEs_dssc_check_year(comm.convertStringToDate(es_dssc_check_year));
		
			exmgmt.setEs_status_id(0);
			int mid = (int)sessionHQL.save(exmgmt);
			
				sessionHQL.save(exmgmt);
				sessionHQL.flush();
				sessionHQL.clear();
				tx.commit();
				
					
					
      		if(ec_exam_id.equals("3")) {
						
						
      			for (int i = 0; i < list2.size(); i++) {
					int i2=i+1;
							
							
						
						EXAM_SCHEDULE_DETAIL_M sub_ch = new EXAM_SCHEDULE_DETAIL_M();

						Session sessionHQL23 = this.sessionFactory.openSession();
						Transaction tx23 = sessionHQL23.beginTransaction();
						
						String subject_id = String.valueOf(list2.get(i).get("sc_subject_id"));
						
						System.err.println("subject_id==========="+subject_id);
						sub_ch.setSc_subject_id(Integer.parseInt(subject_id));

						String sc_is_tsoc_applicable = request.getParameter("sc_is_tsoc_applicable"+i2);
						String sc_ic_dssc_applicable = request.getParameter("sc_ic_dssc_applicable"+i2);
						
					
						String esd_date = request.getParameter("esd_date"+i2);
						int esd_final_cutoff_dssc=Integer.parseInt(request.getParameter("esd_cutoff"+i2));
						sub_ch.setEsd_final_cutoff_dssc(esd_final_cutoff_dssc);
						sub_ch.setEsd_cutoff(esd_final_cutoff_dssc);
						sub_ch.setEsd_final_cutoff_tsoc(esd_final_cutoff_dssc);
						sub_ch.setSc_dssc_applicable(sc_ic_dssc_applicable);
						sub_ch.setSc_tsoc_applicable(sc_is_tsoc_applicable);
						sub_ch.setEsd_status_id(1);
						sub_ch.setEsd_date(comm.convertStringToDate(esd_date));
						
						

						 

							
						sub_ch.setEs_id(mid);
						sub_ch.setEsd_created_by(username);
						sub_ch.setEsd_creation_date(date);
						sessionHQL23.save(sub_ch);
						tx23.commit();
						
						}	
						
				
						
      			DSSC_COURSE_VACANCY_RESERVE dsc_date= new DSSC_COURSE_VACANCY_RESERVE();
						
						
						
						 List<CHOICE_M>choicelist=comm.getChoicemstListDDL(sessionFactory) ;
						 for (int i9=0;i9<choicelist.size();i9++) {
							 Session sessionHQL4 = this.sessionFactory.openSession();
								Transaction tx4 = sessionHQL4.beginTransaction();
							 int i8=i9+1;
							 int choice_id=choicelist.get(i9).getId();
						
						String  dssc_course_date= request.getParameter("dssc_course_date" +i8);
						dsc_date.setCreated_by(username);
						dsc_date.setCreated_date(date);
						dsc_date.setEs_id(mid);
						String reserve= request.getParameter("reserve"+i8);
						String vacancy= request.getParameter("reserve"+i8);
						if(!reserve.equals("")) {
							dsc_date.setReserve(Integer.parseInt(request.getParameter("reserve"+i8)));
						}else {
							dsc_date.setReserve(0);
						}
						
						if(!vacancy.equals("")) {
							dsc_date.setVacancy(Integer.parseInt(request.getParameter("vacancy"+i8)));
						}else {
							dsc_date.setVacancy(0);
						}
						dsc_date.setDssc_course_date(comm.convertStringToDate(dssc_course_date));
						dsc_date.setDssc_course_no(request.getParameter("dssc_course_no"+i8));
						dsc_date.setCourse_id(choice_id);
						
						dsc_date.setEs_id(mid);
						sessionHQL4.save(dsc_date);
						
						tx4.commit();
						 }
					}
						
				
					if(ec_exam_id.equals("1") ) {
						
						
						for (int i = 0; i < list2.size(); i++) {
							int i2=i+1;
							Session sessionHQL5 = this.sessionFactory.openSession();
							Transaction tx5 = sessionHQL5.beginTransaction();
						EXAM_SCHEDULE_DETAIL_M sub_ch = new EXAM_SCHEDULE_DETAIL_M();
						String subject_id = String.valueOf(list2.get(i).get("sc_subject_id"));
						sub_ch.setSc_subject_id(Integer.parseInt(subject_id));
						
						String sc_is_applicable = request.getParameter("sc_is_applicable" +i2);
						String esd_date= request.getParameter("esd_date" +i2);
						
					
					
						int esd_marks=Integer.parseInt(request.getParameter("esd_cutoff"+i2));
						sub_ch.setSc_is_applicable(sc_is_applicable);
					
						sub_ch.setEsd_cutoff(esd_marks);
						sub_ch.setEs_id(mid);
						sub_ch.setEsd_created_by(username);
						sub_ch.setEsd_creation_date(date);
						sub_ch.setEsd_status_id(1);
						sub_ch.setEsd_date(comm.convertStringToDate(esd_date));
						
						//sub_ch.setSc_is_applicable(list2.get(0).get(0))
						sessionHQL5.save(sub_ch);
						
						tx5.commit();
						
						}
					}
					
					
                   if(ec_exam_id.equals("2") ) {
						
                	   for (int i = 0; i < list2.size(); i++) {
							int i2=i+1;
							
							
						
							Session sessionHQL6 = this.sessionFactory.openSession();
							Transaction tx6 = sessionHQL6.beginTransaction();
							EXAM_SCHEDULE_DETAIL_M sub_ch = new EXAM_SCHEDULE_DETAIL_M();
							

						
						String sc_is_applicable = request.getParameter("sc_is_applicable" +i2);
						String esd_date= request.getParameter("esd_date" +i2);
						
						System.err.println("--------------"+request.getParameter("esd_cutoff"+i2));
						int esd_marks=Integer.parseInt(request.getParameter("esd_cutoff"+i2));

						String subject_id = String.valueOf(list2.get(i).get("sc_subject_id"));
						
						System.err.println("subject_id==========="+subject_id);
						sub_ch.setSc_subject_id(Integer.parseInt(subject_id));
						
							sub_ch.setSc_is_applicable(sc_is_applicable);
						
						
						sub_ch.setEsd_status_id(1);
						sub_ch.setEsd_cutoff(esd_marks);
						sub_ch.setEs_id(mid);
						sub_ch.setEsd_created_by(username);
						sub_ch.setEsd_creation_date(date);
						sub_ch.setEsd_date(comm.convertStringToDate(esd_date));
						sessionHQL6.save(sub_ch);
						
						tx6.commit();
						
						}
					}
					
					msg = "Data Saved Successfully";
					Mmap.put("msg", msg);
					
				}
		
					
			}	catch (RuntimeException e) {
	try {
		tx.rollback();
		Mmap.put("msg", "roll back transaction");
	} catch (RuntimeException rbe) {
		Mmap.put("msg", "Couldn�t roll back transaction " + rbe);
	}
	throw e;
} finally {
	if (sessionHQL != null) {
		sessionHQL.close();
	}
}

return new ModelAndView("redirect:Search_exam_schedule_Url");
}
		
		
		@RequestMapping(value = "/getsubjectlistfrmmaster", method = RequestMethod.POST)
		@ResponseBody public List<Map<String, Object>>getdatafromsubmst(String exam_id) { 
			
			
			List<Map<String, Object>>list2= objDAO.getdatafromsubmst(exam_id);
		
			
		return list2; 
		}
		
		
		@RequestMapping(value = "/getsubjectlistfrmmaster11", method = RequestMethod.POST)
		@ResponseBody public List<Map<String, Object>>getsubjectlistfrmmaster11(String exmmm) { 
			
			
			List<Map<String, Object>> list2= objDAO.editgetdatafromsubmst(exmmm);
			
		System.err.println("list2===="+list2);
			
		return list2; 
		}
		
		@RequestMapping(value = "/Search_exam_schedule_Url", method = RequestMethod.GET)
	    public ModelAndView Search_exam_schedule_Url(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) 
	   		 throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
	NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

			 Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
			
			 ArrayList<ArrayList<String>>list2= objDAO.getactivebegindate("");
			 if(!list2.isEmpty()) {
				 Mmap.put("ActiveExamName", list2.get(0).get(2));
			 }
			
	        Mmap.put("msg", msg);
	    return new ModelAndView("Search_exam_schedule_dscc_tile");
	}
		
		
		 @RequestMapping(value = "/getExaminationScheduleReportList", method = RequestMethod.POST)
		  public @ResponseBody List<Map<String, Object>> getExaminationScheduleReportList(int startPage,String pageLength,String Search,String orderColunm,String orderType,
				  String exam,String es_id,HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
			  
			 System.err.println("es_id--------------------"+es_id);
			 System.err.println("exam----------"+exam);
			  return objDAO.getExaminationScheduleList(startPage,pageLength,Search,orderColunm,orderType,exam,es_id,sessionUserId);
			  
		 }

		  @RequestMapping(value = "/getExaminationScheduleReportTotalCount", method = RequestMethod.POST)
		 public @ResponseBody long getExaminationScheduleReportTotalCount(String Search,String exam,String es_id){
			  System.err.println("es_id--------------------"+es_id);
				 System.err.println("exam----------"+exam);
			  
			  return objDAO.getExaminationScheduleTotalCount(Search,exam,es_id);
		 }
		  
		  
		  @RequestMapping(value = "EditExamSchedule_masterUrl", method = RequestMethod.POST)
	      public ModelAndView EditExamSchedule_masterUrl(ModelMap Mmap,HttpSession session,
	    		  @RequestParam(value = "msg", required = false) String msg,String updateid) {

			  	System.err.print("updateid==="+updateid);
	             Session s1 = this.sessionFactory.openSession();
	             Transaction tx = s1.beginTransaction();
	            // String enckey = "commonPwdEncKeys";  
	            // String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
	             
	             Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
	             int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0": session.getAttribute("ec_exam_id").toString());
	             if(ec_exam_id != 0) {
	             List<SUBJECT_CODE_M> sublist=comm.getsubjectlist(sessionFactory,ec_exam_id);
	           
	         
	             for(int i=0;i<sublist.size();i++) {
	            	    int subject_id= sublist.get(i).getSc_subject_id();
	                   
	          		 Mmap.put("EditExamScheduleDetailsCMD2", objDAO.getexamscheduledetails2(Integer.parseInt(updateid),subject_id));
	          		 Mmap.put("exmdetailsSize", objDAO.getexamscheduledetails2(Integer.parseInt(updateid), subject_id).size());
	             }
	           
              
	    		 Mmap.put("EditExamScheduleDetailsCMD", objDAO.getexamscheduleDetails(Integer.parseInt(updateid), ec_exam_id));
	    		 
	    		 
	
	    		 Mmap.put("getChoicemstListDDL", comm.getChoicemstListDDL( sessionFactory));
				 Mmap.put("getChoicemstListsize", comm.getChoicemstListDDL( sessionFactory).size());
	    		 Mmap.put("EditExamScheduledVacancyReserveCMD2", objDAO.getvacancyReserveDetailsbyExmsch(Integer.parseInt(updateid)));
	    		 
	    		 
	    		 
	    		 Mmap.put("DcryptedPk", updateid);
	    		 
	    		 Mmap.put("es_id", Integer.parseInt(updateid));

	             }
	            
	      return new ModelAndView("Edit_exam_schedule_dscc_tile","Edit_exam_scheduleACtion",new EXAM_SCHEDULE());
	      
	}
  
		  
		  
		  
		  
		  @RequestMapping(value = "/Edit_exam_scheduleACtion" ,method = RequestMethod.POST) 
		  public ModelAndView Edit_exam_scheduleACtion(@Valid @ModelAttribute("Edit_exam_scheduleCMD") EXAM_SCHEDULE es, BindingResult result, 
		  HttpServletRequest request, ModelMap model, HttpSession session){ 

		 
		 

		 
		    Session sessionHQL = this.sessionFactory.openSession(); 
		    Transaction tx = sessionHQL.beginTransaction(); 
		    
		    Date date = new Date();
			String username = session.getAttribute("username").toString();
			

			
			
			String exam_id= request.getParameter("ec_exam_id1");
			System.err.println("exam_id========="+exam_id);
		    String es_begin_date= request.getParameter("es_begin_date");
			int year =Integer.parseInt( request.getParameter("min_year"));
			
			int es_max_year =Integer.parseInt( request.getParameter("es_max_year"));
			
			
			
		    String es_consider_date= request.getParameter("es_consider_date");
		    String es_dssc_check_year= request.getParameter("es_dssc_check_year");
		  //  String es_index_mode= request.getParameter("es_index_mode");
		    String es_part_d= request.getParameter("es_part_d");
		    String es_compensatory= request.getParameter("es_compensatory");
			int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());		    
		  
		    
		    int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0": session.getAttribute("ec_exam_id").toString());
		    List<SUBJECT_CODE_M> sublist=comm.getsubjectlist(sessionFactory,ec_exam_id);
            
            
		    
		    
		    
			String dimandingYear=request.getParameter("es_begin_date").split("/")[0]+"/"+request.getParameter("es_begin_date").split("/")[1]+"/"+String.valueOf(Integer.parseInt(request.getParameter("es_begin_date").split("/")[2])-year);
			  
			
			
			
if(request.getParameter("ec_exam_id1").equals("0") ){
				
				model.put("msg","Please select Exam Name.");
				 return new ModelAndView("redirect:Search_exam_schedule_Url");	
			} 

			if(request.getParameter("es_begin_date").equals("DD/MM/YYYY") ){
				model.put("msg","Please select Begin Date.");
				 return new ModelAndView("redirect:Search_exam_schedule_Url");	
			} 
			
			if(ec_exam_id == 1)
			{
 
				if(request.getParameter("min_year").equals("") ){
					model.put("msg","Please Enter Minimum Eligibility.");
					 return new ModelAndView("redirect:Search_exam_schedule_Url");	
				} 

				if(request.getParameter("es_max_year").equals("") ){
					model.put("msg","Please Enter Maximum Eligibility.");
					 return new ModelAndView("redirect:Search_exam_schedule_Url");	
				}
				
				
				
			}

			if(ec_exam_id == 3)
			{
				 List<CHOICE_M>count_vali1=comm.getChoicemstListDDL(sessionFactory) ;
					
					for(int k=1;k<=count_vali1.size();k++){
					if(request.getParameter("dssc_course_date"+k).equals("DD/MM/YYYY") ){
						
						model.put("msg","Please Enter Date.");
						 return new ModelAndView("redirect:Search_exam_schedule_Url");	
					} 

					if(request.getParameter("dssc_course_no"+k).equals("0") ){
					 
						model.put("msg","Please Enter Course No.");
						 return new ModelAndView("redirect:Search_exam_schedule_Url");	
					}

					if(request.getParameter("vacancy"+k).equals("") ){
						 
						model.put("msg","Please Enter Vacancy.");
						 return new ModelAndView("redirect:Search_exam_schedule_Url");	
					} 

					if(request.getParameter("reserve"+k).equals("") ){
						 
						model.put("msg","Please Enter Reserve.");
						 return new ModelAndView("redirect:Search_exam_schedule_Url");	
					}		
				
				
				}
				}

			
			int count_vali = Integer.parseInt(request.getParameter("count_vali"));
			
		
			for(int k=1;k<=count_vali;k++){
				
				if(request.getParameter("esd_date"+k).equals("DD/MM/YYYY") ){
					 	
					model.put("msg","Please Enter Date.");
					 return new ModelAndView("redirect:Search_exam_schedule_Url");	
				} 

				
				if(request.getParameter("esd_cutoff"+k).equals("") ){
					 	
					model.put("msg","Please Enter Minimun Marks.");
					 return new ModelAndView("redirect:Search_exam_schedule_Url");	
				}

			}
			
			
			
			
			
			
		    
			try {
				
				if(exam_id.equals("1") ) {
			String hql = "update EXAM_SCHEDULE set es_begin_date=:es_begin_date, es_max_year=:es_max_year, es_to_year=:es_to_year,es_part_b=:es_part_b,"
					+ "es_part_d=:es_part_d,es_compensatory=:es_compensatory,es_consider_date=:es_consider_date,es_status_id=:es_status_id,es_modified_by=:es_modified_by,es_modification_date=:es_modification_date  where es_id=:es_id  ";
			Query query = sessionHQL.createQuery(hql)
						.setParameter("es_begin_date", comm.convertStringToDate(es_begin_date))
						//.setParameter("es_begin_todate", comm.convertStringToDate(es_begin_todate))
						.setParameter("es_max_year", es_max_year)		
						.setParameter("es_to_year", comm.convertStringToDate(dimandingYear))
						.setParameter("es_part_b", request.getParameter("es_part_b"))		
						.setParameter("es_part_d", es_part_d)		
						.setParameter("es_compensatory", es_compensatory)		
						.setParameter("es_consider_date", es_consider_date)		
						.setParameter("es_status_id", 1)	
						.setParameter("es_modified_by", username)	
						.setParameter("es_modification_date", date)	
						.setParameter("es_id", es_id);
		
				query.executeUpdate();
				
				System.err.println(sublist.size()+"============");
				
				  for(int i1=1;i1<sublist.size();i1++) {
//					int i1=i+1;
					   int subject_id= sublist.get(i1).getSc_subject_id();
				
					  String esd_date=request.getParameter("esd_date"+i1);
					  
					  System.err.println("marks========="+request.getParameter("esd_cutoff"+i1));
				
				    
				String hq1l = "update EXAM_SCHEDULE_DETAIL_M set esd_cutoff=:esd_cutoff,"
						+ "sc_is_applicable=:sc_is_applicable,esd_date=:esd_date, "
						+ "esd_status_id=:esd_status_id,esd_modified_by=:esd_modified_by,esd_modification_date=:esd_modification_date where es_id=:es_id and sc_subject_id=:sc_subject_id";
				Query query1 = sessionHQL.createQuery(hq1l)
							.setParameter("esd_cutoff",Integer.parseInt(request.getParameter("esd_cutoff"+i1)))
							.setParameter("sc_is_applicable", request.getParameter("sc_is_applicable"+i1))
							.setParameter("esd_date", comm.convertStringToDate(esd_date))
							.setParameter("esd_status_id", 1)	
							.setParameter("esd_modified_by", username)	
							.setParameter("esd_modification_date", date)	
							.setParameter("es_id", es_id)
				.setParameter("sc_subject_id",  subject_id);
				query1.executeUpdate();
		    
				}
				}
				
				
				
				if(exam_id.equals("2") ) {
					
					
					String hql = "update EXAM_SCHEDULE set es_begin_date=:es_begin_date, es_to_year=:es_to_year,es_part_b=:es_part_b,"
							+ "es_part_d=:es_part_d,es_compensatory=:es_compensatory,es_consider_date=:es_consider_date,es_status_id=:es_status_id,es_modified_by=:es_modified_by,es_modification_date=:es_modification_date  where es_id=:es_id  ";
					Query query = sessionHQL.createQuery(hql)
								.setParameter("es_begin_date", comm.convertStringToDate(es_begin_date))
//								.setParameter("es_begin_todate", comm.convertStringToDate(es_begin_todate))
								//.setParameter("es_index_mode", es_index_mode)		
								.setParameter("es_to_year", comm.convertStringToDate(dimandingYear))
								.setParameter("es_part_b", request.getParameter("es_part_b"))		
								.setParameter("es_part_d", es_part_d)		
								.setParameter("es_compensatory", es_compensatory)		
								.setParameter("es_consider_date", es_consider_date)		
								.setParameter("es_status_id", 1)	
								.setParameter("es_modified_by", username)	
								.setParameter("es_modification_date", date)	
								.setParameter("es_id", es_id);
				
						query.executeUpdate();
						
						System.err.println(sublist+"============");
						
						  for(int i=0;i<sublist.size();i++) {
							int i1=i+1;
							   int subject_id= sublist.get(i).getSc_subject_id();
						
							  
							  System.err.println("============"+request.getParameter("esd_date"+i1));
						
						    
						String hq1l = "update EXAM_SCHEDULE_DETAIL_M set esd_date=:esd_date, esd_cutoff=:esd_cutoff,"
								+ "sc_is_applicable=:sc_is_applicable,"
								+ "esd_status_id=:esd_status_id,esd_modified_by=:esd_modified_by,esd_modification_date=:esd_modification_date where es_id=:es_id and sc_subject_id=:sc_subject_id";
						Query query1 = sessionHQL.createQuery(hq1l)
									.setParameter("esd_date", comm.convertStringToDate(request.getParameter("esd_date"+i1)))	
									.setParameter("esd_cutoff",Integer.parseInt(request.getParameter("esd_cutoff"+i1)))
									.setParameter("sc_is_applicable", request.getParameter("sc_is_applicable"+i1))
									.setParameter("esd_status_id", 1)	
									.setParameter("esd_modified_by", username)	
									.setParameter("esd_modification_date", date)	
									.setParameter("es_id",  es_id)
						.setParameter("sc_subject_id",  subject_id);
						query1.executeUpdate();
				    
						}
				}
				
				if(exam_id.equals("3")) {
					
					String hql = "update EXAM_SCHEDULE set es_begin_date=:es_begin_date, es_to_year=:es_to_year,es_part_b=:es_part_b,"
							+ "es_part_d=:es_part_d,es_compensatory=:es_compensatory,es_consider_date=:es_consider_date,es_status_id=:es_status_id,es_modified_by=:es_modified_by,es_modification_date=:es_modification_date,es_dssc_check_year=:es_dssc_check_year,es_dssc_month=:es_dssc_month,es_dssc_chance=:es_dssc_chance  where es_id=:es_id ";
					Query query = sessionHQL.createQuery(hql)
								.setParameter("es_begin_date", comm.convertStringToDate(es_begin_date))
								//.setParameter("es_index_mode", es_index_mode)		
								.setParameter("es_to_year", comm.convertStringToDate(dimandingYear))
								.setParameter("es_part_b", request.getParameter("es_part_b"))		
								.setParameter("es_part_d", es_part_d)		
								.setParameter("es_compensatory", es_compensatory)		
								.setParameter("es_consider_date", es_consider_date)		
								.setParameter("es_status_id", 1)	
								.setParameter("es_modified_by", username)	
								.setParameter("es_modification_date", date)	
								.setParameter("es_dssc_check_year", comm.convertStringToDate(es_dssc_check_year))	
								.setParameter("es_dssc_month",Integer.parseInt(request.getParameter("es_dssc_month")))	
								.setParameter("es_dssc_chance", Integer.parseInt(request.getParameter("es_dssc_chance")))
								
								.setParameter("es_id", es_id);
						query.executeUpdate();
						  for(int i=0;i<sublist.size();i++) {
							  int subject_id= sublist.get(i).getSc_subject_id();
							int i2=i+1;
							System.err.println("============"+request.getParameter("esd_final_cutoff_dssc"+i2));
						
						String hq1l = "update EXAM_SCHEDULE_DETAIL_M set esd_cutoff=:esd_cutoff, sc_dssc_applicable=:sc_dssc_applicable,esd_date=:esd_date,"
								+ "sc_tsoc_applicable=:sc_tsoc_applicable,esd_status_id=:esd_status_id,esd_modified_by=:esd_modified_by,esd_modification_date=:esd_modification_date where es_id=:es_id and sc_subject_id=:sc_subject_id ";
						Query query1 = sessionHQL.createQuery(hq1l)
									.setParameter("esd_cutoff",Integer.parseInt(request.getParameter("esd_cutoff"+i2)))
									.setParameter("sc_dssc_applicable", request.getParameter("sc_dssc_applicable"+i2))
									.setParameter("esd_date", comm.convertStringToDate(request.getParameter("esd_date"+i2)))	
									.setParameter("sc_tsoc_applicable",request.getParameter("sc_tsoc_applicable"+i2))
									.setParameter("esd_status_id", 1)	
									.setParameter("esd_modified_by", username)	
									.setParameter("esd_modification_date", date)	
									.setParameter("es_id",  es_id)
						          .setParameter("sc_subject_id",  subject_id);
						query1.executeUpdate();
						}
						
						int i3 = 0;
						List<Map<String, Object>> reserveandvacancy = objDAO.getvacancyReserveDetailsbyExmsch(es_id);
						for (int i = 0; i < reserveandvacancy.size(); i++) {
							i3 = i + 1;
							String course_date = request.getParameter("dssc_course_date" + i3);
							int id = Integer.parseInt(request.getParameter("insp_addQuanyId" + i3));
							System.err.println("course_date=============" + course_date);
							String hq13 = "update DSSC_COURSE_VACANCY_RESERVE set dssc_course_no=:dssc_course_no, dssc_course_date=:dssc_course_date, vacancy=:vacancy,reserve=:reserve ,modified_by=:modified_by,modified_date=:modified_date where es_id=:es_id and id=:id ";
							Query query3 = sessionHQL.createQuery(hq13)
									.setParameter("dssc_course_no", request.getParameter("dssc_course_no" + i3))
									.setParameter("dssc_course_date", comm.convertStringToDate(course_date))
									.setParameter("vacancy", Integer.parseInt(request.getParameter("vacancy" + i3)))
									.setParameter("reserve", Integer.parseInt(request.getParameter("reserve" + i3)))
									.setParameter("modified_by", username).setParameter("modified_date", date)
									.setParameter("es_id", es_id)
									.setParameter("id", id);
							query3.executeUpdate();

						}
				
				
				}
		    
		    tx.commit(); 
		    sessionHQL.close(); 

		 
		    model.put("msg","Data Updated Successfully"); 
			}catch(RuntimeException e){
				e.printStackTrace();
				tx.rollback();
				
				model.put("msg","Server side Error");
				
			}
			        
		        return new ModelAndView("redirect:Search_exam_schedule_Url");
		}
		  
		  @RequestMapping(value = "/getActiveExamScheduleforExamSchedule", method = RequestMethod.POST)
			@ResponseBody public ArrayList<ArrayList<String>> getActiveExamScheduleforExamSchedule(String exm) { 
				
				
			  ArrayList<ArrayList<String>>list2= objDAO.getactivebegindate(exm);
			
				
			return list2; 
			}
		  
		  
		  
		  @RequestMapping(value = "/getActiveExamSchByExamWise", method = RequestMethod.POST)
			@ResponseBody public List<Map<String, Object>>getActiveExamSchByExamWise(String exam_id) { 
				
				
				List<Map<String, Object>>list2= objDAO.getdatafromsubmst(exam_id);
			
				
			return list2; 
			}
		  
		  
		  @RequestMapping(value = "/getReserveAndVacancyData", method = RequestMethod.POST)
			@ResponseBody public List<Map<String, Object>>getReserveAndVacancyData(String es_id) { 
				
				
				List<Map<String, Object>>list2= objDAO.getvacancyReserveDetailsbyExmsch(Integer.parseInt(es_id));
			
				System.err.println("ReserveAndVacancyData============"+list2);
			return list2; 
			}
			
			
			
}




