package com.BisagN.controller.office.masters;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.IAST_CasesDAO;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.TBL_ARM_HISTORY_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Grant_PC_to_SS_OffrsController {

	
	
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	

	CommonController comm = new CommonController();
	
	
	
	@Autowired
	private Officer_personal_detailsDAO ofc_Dao;
	
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	

	@Autowired
	private IAST_CasesDAO iastDao;
	
	@Autowired
	private Officer_personal_detailsDAO opdDAO;
	
	@Autowired
	private RoleBaseMenuDAO roledao; 


	  @RequestMapping(value = "PCtoSS_Officers_detailsUrl", method = RequestMethod.GET)
      public ModelAndView PCtoSS_Officers_detailsUrl(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg,String opd_pers_no1,String opd_name1){
		  
		  if(request.getHeader("Referer") == null ) { 
 			 session.invalidate();
 			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
 			 return new ModelAndView("redirect:/login");
 		 }

     	 String roleid1 = session.getAttribute("roleid").toString();
 		 Boolean val = roledao.ScreenRedirect("PCtoSS_Officers_detailsUrl", roleid1);		
 			if(val == false) {
 				return new ModelAndView("AccessTiles");
 		}			  
		  
		  
     	 try {
           
     		 Mmap.put("msg", msg);
     		 Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL( sessionFactory));
            
            
     	 } catch (Exception e) {
  			e.printStackTrace();
  		}
      return new ModelAndView("PCtoSSOffrs_tile");
}
	  
	  
	  
	  @RequestMapping(value = "EditGrantPCtoSS_detailsUrl", method = RequestMethod.POST)
      public ModelAndView EditGrantPCtoSS_detailsUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String updateid) {

System.out.println("updateid--------------------------"+updateid);
             Session s1 = this.sessionFactory.openSession();
             Transaction tx = s1.beginTransaction();
             String enckey = "commonPwdEncKeys";  
             String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
             Query q = null;
             q = s1.createQuery("from OFFICER_PERSONAL_DETAILS_M where cast(id as string)=:PK");
             q.setString("PK", DcryptedPk);
             @SuppressWarnings("unchecked")
             List<String> list = (List<String>) q.list();
             tx.commit();
             s1.close();
           
             Mmap.put("Edit_pers_details",opdDAO.getarmcodeforIASTcase(DcryptedPk));
             Mmap.put("Editofficer_personal_detailsCMD1", list.get(0));
             Mmap.put("Edit_pers_details", opdDAO.getpersdetails(DcryptedPk));
          Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL(sessionFactory));
          Mmap.put("getctranktypeListDDL", comm.getctranktypeListDDL(sessionFactory));
          Mmap.put("getPersonalType", comm.getPersonalType(sessionFactory));
             Mmap.put("msg", msg);
             Mmap.put("opd_id", DcryptedPk);
      return new ModelAndView("EDIT_PCtoSSOffrs_tile","editIASTBCMD",new OFFICER_PERSONAL_DETAILS_M());
}
	  

	  @RequestMapping(value = "/EditGrantPCtoSSAction" ,method = RequestMethod.POST) 
	  public ModelAndView EditGrantPCtoSSAction(@Valid @ModelAttribute("editGrantPCtoSSCMD") OFFICER_PERSONAL_CODE_M pers_code, BindingResult result, 
	  HttpServletRequest request, ModelMap model, HttpSession session) { 

		
			
		  Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
		
			String persnl_no1=request.getParameter("persnl_no1");
			if(persnl_no1 == "" || persnl_no1.equals("-1")) {
				model.put("msg", "Please Select Personal No");		
				return new ModelAndView("redirect:PCtoSS_Officers_detailsUrl");
			}
			
			
			String opd_personal_no=request.getParameter("opd_personal_no");
			if(opd_personal_no == "" || opd_personal_no.equals("")) {
				model.put("msg", "Please Enter Personal No");		
				return new ModelAndView("redirect:PCtoSS_Officers_detailsUrl");
			}
			
			String opd_suffix_code=request.getParameter("opd_suffix_code");
			if(opd_suffix_code == "" || opd_suffix_code.equals("")) {
				model.put("msg", "Please Enter Personal No");		
				return new ModelAndView("redirect:PCtoSS_Officers_detailsUrl");
			}
			String auth_letter_no=request.getParameter("auth_letter_no");
			if(auth_letter_no == "" || auth_letter_no.equals("")) {
				model.put("msg", "Please Enter Auth (Letter No)");		
			return new ModelAndView("redirect:PCtoSS_Officers_detailsUrl");
			}
			
			try {
			


    int id = pers_code.getId() > 0 ? pers_code.getId() : 0;
    System.err.println("id-------------"+id);
	Date date = new Date();
	String username = session.getAttribute("username").toString();
	String opd_id= request.getParameter("opd_id");
	try {

		if (id == 0) {
			
			
			String hq1l = "update OFFICER_PERSONAL_CODE_M set opc_status_id=:opc_status_id  where opd_personal_id=:opd_personal_id ";
			Query query1 = sessionHQL.createQuery(hq1l)
						.setParameter("opc_status_id", 0)
			.setParameter("opd_personal_id", Integer.parseInt(opd_id));
			query1.executeUpdate();
			
			
			String personal_code= request.getParameter("persnl_no1")+request.getParameter("opd_personal_no");
		
			pers_code.setOpc_modified_by(username);
			pers_code.setOpc_modification_date(date);
			pers_code.setOpc_personal_code(personal_code);
			pers_code.setOpc_suffix_code(request.getParameter("opd_suffix_code"));
			pers_code.setOpc_status_id(1);
			pers_code.setAuth_letter_no(request.getParameter("auth_letter_no"));
			pers_code.setOpd_personal_id(Integer.parseInt(opd_id));
			pers_code.setOpc_modification_date(date);
			pers_code.setOpc_modified_by(username);
					sessionHQL.save(pers_code);
					tx.commit();
				
					
					
					model.put("msg", "Data Updated Successfully.");

			
		}


		
	} catch (RuntimeException e) {
		try {
			tx.rollback();
			model.put("msg", "roll back transaction");
		} catch (RuntimeException rbe) {
			model.put("msg", "Couldn�t roll back transaction " + rbe);
		}
		throw e;
	} finally {
		if (sessionHQL != null) {
			sessionHQL.close();
		}
	}
	  }
	catch (Exception e) {
		e.printStackTrace();
	}

	return new ModelAndView("redirect:PCtoSS_Officers_detailsUrl"); 

 } 
	  
	  
	  @RequestMapping(value = "UploadPCtoSSOFFRSURL", method = RequestMethod.GET)
	  public ModelAndView UploadPCtoSSOFFRSURL(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg,String Subjectid) {
	  
	  
		  Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
	        if(flashMap != null){
	        	ArrayList<ArrayList<String>> errorList =  (ArrayList<ArrayList<String>>) flashMap.get("errorlist");
	            System.out.println("==================="+errorList);
	            //return "home";
	            Mmap.put("errorList",errorList);
	        }
          Mmap.put("msg", msg);
      return new ModelAndView("Upload_PCtoSSOffrs_tile");
}
	//UPLOAD CANDIDATE DATA
			@RequestMapping(value = "/UploadPCtoSSAction", method = RequestMethod.POST)
			public ModelAndView UploadPCtoSSAction(HttpServletRequest request, ModelMap model, HttpSession session,RedirectAttributes ra,
					@RequestParam(value = "fileUpload", required = false) MultipartFile fileUpload)
			{
				ArrayList<ArrayList<String>> listerror=new ArrayList<ArrayList<String>>();
				Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction();
				
//				if(fileUpload==null) {
//					 model.put("msg","Please Upload Copy Of File Upload");
//					  return new ModelAndView("redirect:PCtoSS_Officers_detailsUrl");
//				  }
				
//				if(fileUpload.isEmpty()) {
//					model.put("msg","Please Upload Copy Of File Upload");
//					  return new ModelAndView("redirect:PCtoSS_Officers_detailsUrl");
//				}
				
				if(fileUpload.isEmpty()) {
					ra.addAttribute("msg","Please Upload Copy Of File Upload");
					  return new ModelAndView("redirect:UploadPCtoSSOFFRSURL");
				}
				
				try {

					
					Date date = new Date();
					String username = session.getAttribute("username").toString();

					int count = Integer.parseInt(request.getParameter("count"));
					DateFormat format = new SimpleDateFormat("dd/MM/yyyy");

					
					int count_duplicate=0;
					int errorcount=0;
					int succeesscount=0;
					String errormsg= "";
					File file = new File(comm.fileupload2(fileUpload.getBytes(), fileUpload.getOriginalFilename(), "doc_contract",""));
					FileInputStream fis = new FileInputStream(file);
					@SuppressWarnings("resource")
					XSSFWorkbook wb = new XSSFWorkbook(fis);
					XSSFSheet sheet = wb.getSheetAt(0);
					Row row_head = sheet.getRow(0);
					
					
					
				
					for (int i = 1; i <= sheet.getLastRowNum(); i++) {
						ArrayList<String> listData = new ArrayList<String>();
						Row row = sheet.getRow(i);
						String N_personal_no="";
						String N_suffixcode="";
						String old_ss_number="";
						String o_suffix = "";
						String officer_name="";
						String doc = "";
						String dos="";
						String arm_service="";
					
					
						
						
						
						if (row.getCell(0) == null) {
							break;
						}
						
						for (int j = 1; j < 8; j++) {

							Cell cell = row.getCell(j);
							
							

							String value = "";
							switch (cell.getCellType()) {
							case Cell.CELL_TYPE_STRING:
								value = cell.getStringCellValue();
								break;
							case Cell.CELL_TYPE_NUMERIC:
								if (HSSFDateUtil.isCellDateFormatted(cell)) {
									value = String.valueOf(cell.getDateCellValue());
								} else {
									value = String.valueOf((long) cell.getNumericCellValue());
								}
								break;
							case Cell.CELL_TYPE_BOOLEAN:
								value = String.valueOf(cell.getBooleanCellValue());
								break;
							default:
							}
						
				
							
							if (row_head.getCell(j).getStringCellValue().equals("NEW_IC_NO")) {
								N_personal_no=value;
							}
							if (row_head.getCell(j).getStringCellValue ().equals("N_SUFFIX")) {
								N_suffixcode=value;
								
							}
							if (row_head.getCell(j).getStringCellValue().equals("OLD_SS_NUMBER")) {
								old_ss_number=value;
						     }
							
							if (row_head.getCell(j).getStringCellValue().equals("O_SUFFIX")) {
								o_suffix=value;
							}
							
							if (row_head.getCell(j).getStringCellValue().equals("OFFICER_NAME")) {
								officer_name=value;
							}
							if (row_head.getCell(j).getStringCellValue().equals("DOC")) {
								doc=value;
								
								
							}
							
							if (row_head.getCell(j).getStringCellValue().equals("DOS")) {
								dos=value;
							
							}
							if (row_head.getCell(j).getStringCellValue().equals("ARM_SERVICE")) {
								arm_service=value;
							
							}
							
							
							
							
						}
//					for (int i = 0; i < count; i++) {
						
						List<OFFICER_PERSONAL_CODE_M> opdpers_id= comm.getopdIdbycode( sessionFactory, old_ss_number);
						
						if(opdpers_id.isEmpty()) {
							
							 listData.add(N_personal_no);
							 listData.add(N_suffixcode);
							 listData.add(old_ss_number);
							 listData.add(o_suffix);
							 listData.add(officer_name);
							 listData.add(doc);
							 listData.add(dos);
							 listData.add(arm_service);
							
							 
							
								
								
								listData.add("The Personal Number is Wrong");
							 errormsg= N_personal_no +"The Personal Number is Wrong";
								model.put("msg",errormsg);
								errorcount++;
						}
						else {
						int opd_pers_id= opdpers_id.get(0).getOpd_personal_id();
						
						String hq1l = "update OFFICER_PERSONAL_CODE_M set opc_status_id=:opc_status_id  where opd_personal_id=:opd_personal_id ";
						Query query1 = sessionHQL.createQuery(hq1l)
									.setParameter("opc_status_id", 0)
						.setParameter("opd_personal_id",opd_pers_id);
						query1.executeUpdate();
					
	                         OFFICER_PERSONAL_CODE_M op_pers_code= new OFFICER_PERSONAL_CODE_M();
						
					
							op_pers_code.setOpc_personal_code(N_personal_no);
						op_pers_code.setOpc_suffix_code(N_suffixcode);
						op_pers_code.setAuth_letter_no(request.getParameter("auth_letter_no"));
							op_pers_code.setOpd_personal_id(opd_pers_id);
							op_pers_code.setOpc_status_id(1);
							op_pers_code.setOpc_modification_date(date);
							op_pers_code.setOpc_modified_by(username);
							sessionHQL.save(op_pers_code);
						}	
						
							
						tx.commit();
						sessionHQL.close();

						ra.addAttribute("msg","Data Saved Successfully");
									
						
						if(!listData.isEmpty()) {
							System.err.println("listData======="+listData);
							listerror.add(listData);
						}
							
						
							
						model.put("errorlist", listerror);
							
							
							
						} 

					
						
					
						
					
				
						
					}
					
				
			
				 catch (Exception e) {
					//tx.rollback();
					e.printStackTrace();
				} finally {
					if (sessionHQL != null) {
						sessionHQL.close();
					}
				}
				
				ra.addFlashAttribute("errorlist",listerror);
				return new ModelAndView("redirect:UploadPCtoSSOFFRSURL");
			}		
			
			
			
			//Download DEMO EXCEL
			@RequestMapping(value = "/DemoCandidateExcelFORPCtoSS", method = RequestMethod.POST)
			public ModelAndView DemoCandidateExcelFORPCtoSS(HttpServletRequest request,ModelMap model,HttpSession session,String typeReport1) {
				
			
			ArrayList<ArrayList<String>> listexport=new ArrayList<ArrayList<String>>();
			List<String> TH = new ArrayList<String>();
		    	TH.add("SER_NO");
		    	 TH.add("NEW_IC_NO");
		    	   TH.add("N_SUFFIX");
			    TH.add("OLD_SS_NUMBER");
			    TH.add("O_SUFFIX");
				TH.add("OFFICER_NAME");
				TH.add("DOC");
				TH.add("DOS");
				TH.add("ARM_SERVICE");
			
				
				

				String Heading = "\n";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList", listexport);
			}
			
}
