package com.BisagN.dao.officer.trans;


import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class Partbd_compens_chanceDAOImpl implements Partbd_compens_chanceDAO {

	@Autowired
         private DataSource dataSource;
//         public void setDataSource(DataSource dataSource) {
//	       this.dataSource = dataSource;
//         }
 HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
 CommonController comm= new CommonController();


 @Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
 
 
 
  public boolean checkIsIntegerValue(String Search) {
	return Search.matches("[0-9]+");
}


public List<Map<String, Object>> getReportListPartbd_compens_chance(int startPage,String pageLength,String Search,String orderColunm,String orderType,String pers_no,String opd_officer_name,int ec_exam_id,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		if(pageLength.equals("-1")){
 			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search);

 		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		String q = "";
		String q1 = "";
		String q2 = "";
		String q3 = "";
		
		if (!pers_no.equals("")) {		
			
			
			pers_no=comm.getSearchIcNumberwithoutZero(pers_no);
			 System.err.println("opc_code==========="+pers_no);
				 
		}
		
		try {
			
			
			if(!pers_no.equals("")) {
				
				q1="and lower(ofc.opc_personal_code) like ?";
			}
			if(!opd_officer_name.equals("")) {
				
				q2="and  lower(opd.opd_officer_name)like ?";
				}
			
			if(ec_exam_id == 1) {
				
				q3+="where partb_chance.ec_exam_id=1";
						
			}
			if(ec_exam_id == 2) {
				
				q3+="where partb_chance.ec_exam_id=2";
						
			}
			conn = dataSource.getConnection();
			q = "select distinct partb_chance.pcc_id,partb_chance.opd_personal_id,opd.opd_officer_name,ofc.opc_suffix_code,partb_chance.pcc_area, ofc.opc_personal_code,\n"
					+ " TO_CHAR(partb_chance.pcc_area_entry_date,'DD/MM/YYYY') as pcc_area_entry_date,\n"
					+ " TO_CHAR( partb_chance.pcc_area_leave_date,'DD/MM/YYYY') as pcc_area_leave_date\n"
					+ ",partb_chance.pcc_remarks,ar.area_name,partb_chance.pcc_granted_year  \n"
					+ "from partbd_compens_chance  partb_chance\n"
					+ "inner join officer_personal_code ofc on partb_chance.opd_personal_id = ofc.opd_personal_id \n"
					+" inner join area_master ar on ar.area_id::text=partb_chance.pcc_area \n"
					+ "inner join  officer_personal_details opd on partb_chance.opd_personal_id = opd.opd_personal_id "+q3+" "+q1+" "+q2+"  "+SearchValue+" ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
			PreparedStatement stmt = conn.prepareStatement(q);
			
			System.err.print("====="+q);
			
			stmt = setQueryWhereClause_SQL(stmt,Search);
			if(!pers_no.equals("")) {
				stmt.setString(1, "%"+ pers_no.toLowerCase() + "%");
			}
			
			if(!opd_officer_name.equals("")) {
				stmt.setString(1,"%"+ opd_officer_name.toLowerCase() + "%");
			}

			
			ResultSet rs = stmt.executeQuery();
			
			System.err.println("stmt=========="+stmt);
			
			ResultSetMetaData metaData = rs.getMetaData();
 			int columnCount = metaData.getColumnCount();
 			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
				    columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
                      String enckey ="commonPwdEncKeys";
	                    Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
	                    String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("pcc_id").toString().getBytes())));
//                      String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"+EncryptedPk+"')}else{ return false;}\""; 
//                      String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
                      String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('"+EncryptedPk+"')}else{ return false;}\""; 
                      String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>"; 
                      
                      
                  	String download = "onclick=\"  if (confirm('Are You Sure You Want to Download?')){getCompchpartbPDF('" +EncryptedPk+ "')}else {return false;}\"";
                    String downloadButton = "<i class='action_icons action_download ' " + download + " title='Download Data'></i>";
                      String f = "";
                      String f1 = "";
                     
                      f += updateButton;
//                    f += deleteButton;

                    String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
//                    System.out.println("157=====opc_personal_code"+opc_personal_code);
           			String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));
          			f1 += opc_code;
                      columns.put("action",f);
                      columns.put("opc_code",f1);
                     columns.put(metaData.getColumnLabel(1), f);
			list.add(columns);
                    
	}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {
	e.printStackTrace();
} finally {
if (conn != null) {
try {
	conn.close();
} catch (SQLException e) {
}
}
}
return list;
}

public long getReportListPartbd_compens_chanceTotalCount(String Search,String pers_no, String opd_officer_name,int ec_exam_id) {
 		String SearchValue = GenerateQueryWhereClause_SQL(Search);
 		int total = 0;
 		String q = null;
 		Connection conn = null;
 		
 		
 		String q1 = "";
		String q2 = "";
		String q3 = "";
		
 		try {
 			
           if(!pers_no.equals("")) {
				
				q1="and ofc.opc_personal_code=?";
			}
			if(!opd_officer_name.equals("")) {
				
				q2="and  lower(opd.opd_officer_name)like ?";
				}
			if(ec_exam_id == 1) {
				
				q3+="where partb_chance.ec_exam_id=1";
						
			}
			if(ec_exam_id == 2) {
				
				q3+="where partb_chance.ec_exam_id=2";
						
			}
 			conn = dataSource.getConnection();
 			q ="select count(*) from (select distinct partb_chance.pcc_id,partb_chance.opd_personal_id,partb_chance.pcc_area, ofc.opc_personal_code,\n"
 					+ " TO_CHAR(partb_chance.pcc_area_entry_date,'DD/MM/YYYY') as pcc_area_entry_date,\n"
 					+ " TO_CHAR( partb_chance.pcc_area_leave_date,'DD/MM/YYYY') as pcc_area_leave_date\n"
 					+ ",partb_chance.pcc_remarks,ar.area_name,partb_chance.pcc_granted_year \n"
 					+ "from partbd_compens_chance  partb_chance\n"
 					+ "inner join officer_personal_code ofc on partb_chance.opd_personal_id = ofc.opd_personal_id \n"
 					+" inner join area_master ar on ar.area_id::text=partb_chance.pcc_area \n"
 					+ "inner join  officer_personal_details opd on partb_chance.opd_personal_id = opd.opd_personal_id  "+q3+"  "+q1+" "+q2+" "+SearchValue +") ab " ;
 			PreparedStatement stmt = conn.prepareStatement(q);
 			stmt = setQueryWhereClause_SQL(stmt,Search);
 			if(!pers_no.equals("")) {
				stmt.setString(1, pers_no);
			}
			
			if(!opd_officer_name.equals("")) {
				stmt.setString(1,"%"+ opd_officer_name.toLowerCase() + "%");
			}

 			ResultSet rs = stmt.executeQuery();
 			while (rs.next()) {
 				total = rs.getInt(1);
 			}
  			rs.close();
  			stmt.close();
  			conn.close();
  		} catch (SQLException e) {
  			e.printStackTrace();
  		} finally {
  			if (conn != null) {
  				try {
  					conn.close();
  				} catch (SQLException e) {
  				}
 			}
  		}
  		return (long) total;
  	}


  	public String GenerateQueryWhereClause_SQL(String Search) {
 		String SearchValue ="";
  		if(!Search.equals("")) {
			Search = Search.toLowerCase();
  			SearchValue =" and ( ";
//  			if(checkIsIntegerValue(Search)) {
//  				SearchValue +=" id=? or ";
//  			}
String opd_personal_id = "";  			if(checkIsIntegerValue(Search)) {
  				opd_personal_id +=" opd_personal_id= ? or ";
  			}
// 			SearchValue +=" "+opd_personal_id+"lower(pcc_area) like ? or   to_char(pcc_area_entry_date,'dd-MM-yyyy') like ? or to_char(pcc_area_leave_date,'dd-MM-yyyy') like ? or lower(pcc_remarks) like ?  )";
SearchValue +=" lower(ofc.opc_personal_code) like ? or lower(opd.opd_officer_name) like ? or lower(ar.area_name) like ? or lower( partb_chance.pcc_granted_year) like ? or lower( partb_chance.pcc_remarks) like ? or (TO_CHAR(partb_chance.pcc_area_entry_date,'DD/MM/YYYY')) like ? or (TO_CHAR( partb_chance.pcc_area_leave_date,'DD/MM/YYYY')) like ? )";


  		}
   return SearchValue;
 }


  public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search) {
 		int flag = 0;
 		try {
//    		if(!Search.equals("")) {
//// 				if(checkIsIntegerValue(Search)) {
//// 					flag += 1;
//// 					stmt.setInt(flag, Integer.parseInt(Search));
//// 				}
//// 				if(checkIsIntegerValue(Search)) {
//// 					flag += 1;
//// 					stmt.setInt(flag, Integer.parseInt(Search));
//// 				}
// 				flag += 1;
// 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 	
 			if(!Search.equals("")) {
 				if(checkIsIntegerValue(Search)) {
 					flag += 1;
 					stmt.setInt(flag, Integer.parseInt(Search));
 				}
// 				if(checkIsIntegerValue(Search)) {
// 					flag += 1;
// 					stmt.setInt(flag, Integer.parseInt(Search));
// 				}
 				flag += 1;
// 				String pers_no = "";
// 				if (!Search.equals("")) {
// 					
// 					String Data=Search.toString();
// 					String DataPre="";
// 					String DataM="";
// 					if(Data.contains("NTR") || Data.contains("NTS")) {
// 						DataPre= Data.substring(0,3);
// 						DataM = Data.substring(4);
// 					}else {
// 						DataPre= Data.substring(0,2);
// 						DataM = Data.substring(2);
// 					}
//
// 					  pers_no=DataPre+"%"+DataM;
// 					
// 				}
 				Search=comm.getSearchIcNumberwithoutZero(Search);

 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 				flag += 1;
// 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 			}
 		}catch (Exception e) {}
 		return stmt;
 	}
   public String Deletepartbd_compens_chance(String deleteid,HttpSession session1) {

      	Session session = this.sessionFactory.openSession();
      	Transaction tx = session.beginTransaction();
      	String enckey = "commonPwdEncKeys";
		    String DcryptedPk = hex_asciiDao.decrypt((String) deleteid,enckey,session1);
	      	String hql = "Delete from PARTBD_COMPENS_CHANCE_M  where cast(id as string) = :deleteid";
          Query q = session.createQuery(hql).setString("deleteid",DcryptedPk);
      	int rowCount = q.executeUpdate();
      	tx.commit();
          session.close();
	    if(rowCount > 0) {
 			return "Deleted Successfully";
  		}else {
  		return "Deleted not Successfully";
   	}
  	}
   
   
   
   public ArrayList<ArrayList<String>> getyearlistfromicnodao(String icno) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String qry = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "select string_agg(pcc_granted_year,',') as pcc_granted_year FROM public.partbd_compens_chance bdchance\n"
					+ "inner join officer_personal_code  code on bdchance.opd_personal_id = code.opd_personal_id\n"
					+ "where code.opc_personal_code= ? \n"
					+ "";

				stmt = conn.prepareStatement(q);
			 
			  stmt.setString(1, (icno));
			ResultSet rs = stmt.executeQuery();
			 System.out.println("stmt========"+stmt);
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("pcc_granted_year"));//0
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}


   

   public ArrayList<ArrayList<String>> getexistfromicnodao(String icno) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String qry = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "select pcc_remarks,pcc_id,case when pcc_auth_doc is null then '-' else  pcc_auth_doc end  as pcc_auth_doc  FROM public.partbd_compens_chance bdchance\n"
					+ "inner join officer_personal_code  code on bdchance.opd_personal_id = code.opd_personal_id\n"
					+ "where code.opc_personal_code= ? \n"
					+ "";

				stmt = conn.prepareStatement(q);
			 
			  stmt.setString(1, (icno));
			ResultSet rs = stmt.executeQuery();
			 System.out.println("stmt========"+stmt);
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("pcc_remarks"));//0
				list.add(rs.getString("pcc_auth_doc"));//1
				list.add(rs.getString("pcc_id"));//2
				
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
   
   
   
   public String getFilePathQueryForDoc(String id) {

		String whr = "";
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String query = null;
			query = "select pcc_auth_doc from partbd_compens_chance where pcc_id=?  limit 1 ";
			stmt = conn.prepareStatement(query);
			stmt.setInt(1,Integer.parseInt(id));
			ResultSet rs = stmt.executeQuery();
			
			System.err.println("stmt==="+stmt);

			while (rs.next()) {
				whr = rs.getString("pcc_auth_doc");
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return whr;
	}

}
