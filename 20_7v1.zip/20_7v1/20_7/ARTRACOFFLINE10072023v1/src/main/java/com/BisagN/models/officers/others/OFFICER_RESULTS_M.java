package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "officer_results", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class OFFICER_RESULTS_M {

      private int id;
      private int opd_personal_id;
      private int es_id;
      private int sc_subject_id;
      private int or_subject_pass;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getOpd_personal_id() {
           return opd_personal_id;
      }
      public void setOpd_personal_id(int opd_personal_id) {
	  this.opd_personal_id = opd_personal_id;
      }
      public int getEs_id() {
           return es_id;
      }
      public void setEs_id(int es_id) {
	  this.es_id = es_id;
      }
      public int getSc_subject_id() {
           return sc_subject_id;
      }
      public void setSc_subject_id(int sc_subject_id) {
	  this.sc_subject_id = sc_subject_id;
      }
      public int getOr_subject_pass() {
           return or_subject_pass;
      }
      public void setOr_subject_pass(int or_subject_pass) {
	  this.or_subject_pass = or_subject_pass;
      }
}
