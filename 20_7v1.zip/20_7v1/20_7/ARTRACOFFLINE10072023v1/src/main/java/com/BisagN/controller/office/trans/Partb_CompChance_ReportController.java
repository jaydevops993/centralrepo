package com.BisagN.controller.office.trans;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class Partb_CompChance_ReportController extends AbstractPdfView {
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public Partb_CompChance_ReportController(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		
		document.setPageSize(PageSize.A4.rotate());
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		
		response.setContentType("application/pdf");
//	response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");

		Font fontTableHeadingSubMainHead = FontFactory.getFont(FontFactory.TIMES_BOLD, 14);;
		Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
		String es_year =  (String) model.get("es_year");
//		String letter_no =  (String) model.get("letter_no1");
//		String letter_date1 =  (String) model.get("letter_date1");
		
		
		
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		Chunk underline = new Chunk("FIRST COMPENSATORY CHNACE LIST 2022:PROMOTION EXAM PART B" , fontTableHeadingSubMainHead);
		underline.setUnderline(0.1f, -2f);
		
		Phrase phh2 = new Phrase(underline);
		phh2.add("\n");
		phh2.add("\n");
		
		phh2.setFont(fontTableHeadingSubMainHead);
		
		Paragraph cell1 = new Paragraph(phh2);
		cell1.setAlignment(Element.ALIGN_CENTER);
		
		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell1);
			
		PdfPTable tabledata1 = new PdfPTable(1);
		tabledata1.setWidths(new int[] {7});
		tabledata1.setWidthPercentage(100/3.5f);
		tabledata1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata1.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	
		
		 Paragraph head1 = new Paragraph("Exam Sec,");
		 Paragraph head2 = new Paragraph("ARTRAC");
		 Paragraph head4 = new Paragraph("C/o 56 APO"  );
		 Paragraph head5 = new Paragraph("PIN:908548");
		 
		 tabledata1.addCell(head1);
		 tabledata1.addCell(head2);
		 tabledata1.addCell(head4);
		tabledata1.addCell(head5);
		
		PdfPTable tabledata2 = new PdfPTable(1);
		tabledata2.setWidths(new int[] {7});
		tabledata2.setWidthPercentage(100/3.5f);
		tabledata2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata2.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		
		Paragraph head_c6 = new Paragraph("Headquarters");
		Paragraph head_c7 = new Paragraph("Southern Comd GS (Trg)",fontTableHeadingSubMainHead);
		Paragraph head_c8 = new Paragraph("South Western Comd GS (Trg)",fontTableHeadingSubMainHead);
		Paragraph head_c9 = new Paragraph("Eastern Comd GS (Trg)",fontTableHeadingSubMainHead);
		Paragraph head_c1 = new Paragraph("Western Comd GS (Trg)",fontTableHeadingSubMainHead);
		Paragraph head_c2 = new Paragraph("Central Comd GS (Trg)",fontTableHeadingSubMainHead);
		Paragraph head_c3 = new Paragraph("Northern Comd GS (Trg)",fontTableHeadingSubMainHead);
		Paragraph head_c4 = new Paragraph("Strategic Forces Comd",fontTableHeadingSubMainHead);
	
		
		tabledata2.addCell(head_c6);
		tabledata2.addCell(head_c7);
		tabledata2.addCell(head_c8);
		tabledata2.addCell(head_c9);
		tabledata2.addCell(head_c1);
		tabledata2.addCell(head_c2);
		tabledata2.addCell(head_c3);
		tabledata2.addCell(head_c4);
		
		PdfPTable tableC253 = new PdfPTable(2);
		tableC253.setWidths(new int[]{5,100});
		tableC253.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC253.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		tableC253.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC253.setWidthPercentage(100);
		tableC253.setSpacingBefore(5);

		tableC253.addCell("");
		tableC253.addCell("");

		tableC253.addCell("1");
		tableC253.addCell("PI ref Para 11 of SAI 1/S/2006 and SOP on Grant of Compensatory Chance promulgated vide DGMT (MT-2)\n"
				+ " (now Exam Sec, HQ ARTRAC) letter No 16005/GS/M dt 18 May 2018.\n");

		

		tableC253.addCell("");
		tableC253.addCell("");


		tableC253.addCell("2");
		tableC253.addCell(" Compensatory Chance(s) are given to the offrs who are eligible to appear but Op commitments or org/ med exigency could not appear in Promotion Exam."); 



		tableC253.addCell("");
		tableC253.addCell("");

		tableC253.addCell("3");
		tableC253.addCell("The ‘First Compensatory Chance List - 2022’ is att as Appx. The atiemet to utilized in the 14\" year of service with protection of seniority"); 

		tableC253.addCell("");
		tableC253.addCell("");
		
		tableC253.addCell("4");
		tableC253.addCell("The list to be promulgated to the effected offrs.");

		
	
			 
		PdfPTable tabledata_C4 = new PdfPTable(1);
		tabledata_C4.setWidths(new int[] {4});
		tabledata_C4.setWidthPercentage(100/3f);
		tabledata_C4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C4.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		 Paragraph head_c44 = new Paragraph("(Abhilov Sharma)");
		 Paragraph head_c45 = new Paragraph("Lt Col");
		 Paragraph head_c46 = new Paragraph("GSO-1 Exams");
		 Paragraph head_c47 = new Paragraph("for GoC-in-C" );
		 
		 
		 tabledata_C4.addCell(head_c44);
		 tabledata_C4.addCell(head_c45);
		 tabledata_C4.addCell(head_c46);
		 tabledata_C4.addCell(head_c47);
		 
		 
		 
		 Chunk underlinec2 = new Chunk("Encls :As above");
			

		 underlinec2.setUnderline(0.1f, -2f);
			
			Phrase phhc212 = new Phrase(underlinec2);
			phhc212.setFont(fontTableHeadingSubMainHead);
			
			
			Paragraph cell_c1222 = new Paragraph(phhc212);
			cell_c1222.setAlignment(Element.ALIGN_LEFT);
		 
				
			
	
		PdfPCell cell123;
		cell123 = new PdfPCell();
		cell123.addElement(tabledata1);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tabledata2);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tableheader);
		
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tableC253);
		
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tabledata_C4);
		
		
		cell123.addElement(cell_c1222);
		
		cell123.setBorder(0);
		table.addCell(cell123);
		


	
	document.add(table);
	super.buildPdfMetadata(model, document, request);
	}



}
