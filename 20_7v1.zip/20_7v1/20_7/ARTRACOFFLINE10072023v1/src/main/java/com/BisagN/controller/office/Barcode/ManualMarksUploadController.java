package com.BisagN.controller.office.Barcode;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.xssf.usermodel.XSSFDataValidation;
import org.apache.poi.xssf.usermodel.XSSFDataValidationConstraint;
import org.apache.poi.xssf.usermodel.XSSFDataValidationHelper;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.Indexing.SubjectWiseSecDetailsDao;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.others.PartB_marksDAO;
import com.BisagN.dao.officer.others.ProcessResultDao;
import com.BisagN.dao.officer.others.SearchResultswithheldDAO;
import com.BisagN.dao.officer.report.PartB_ReportDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MANUAL;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MASTER;
import com.BisagN.models.officers.indexing.TB_BARCODE_COUNT;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_ARM_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.OFFICER_RESULTS_M;
import com.BisagN.models.officers.trans.ANSWER_BOOK_M;
import com.BisagN.models.officers.trans.Questionwise_marks_details;
import com.BisagN.models.officers.trans.TB_PARTPASS_FULLPASS_DTL;



@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class ManualMarksUploadController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	
	CommonController comm = new CommonController();
	
	@Autowired
	private SubjectWiseSecDetailsDao subwisesecDAO;
	

	@Autowired
	private PartB_marksDAO partBmarksDao;
	
	
	
	@Autowired
	PartB_ReportDAO partbreportDao;
	
	
	@Autowired
	ProcessResultDao prsDao;
	
	@Autowired
	private SearchResultswithheldDAO resDao;
	
	@Autowired
	private RoleBaseMenuDAO roledao;
	

	@Autowired
	private PartB_ExaminationDAO PartBDAo;
	
	@RequestMapping(value = "UploadManualMarksURL", method = RequestMethod.GET)
		public ModelAndView UploadManualMarksURL(ModelMap Mmap, HttpSession session, HttpServletRequest request,
				@RequestParam(value = "msg", required = false) String msg, String Subjectid) {

			int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
			if(esi_es_id != 0) {
			List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esi_es_id);
			Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			
			  int day = date.getDayOfMonth();
			  String[] months = {"Jan", "Feb", "Mar", "Apr" ,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
			  
			  String[] shortMonths = new DateFormatSymbols().getShortMonths();
		        for (String shortMonth : shortMonths) {
		            
		      	 
		        }
			  
			  Month month = date.getMonth();
			  int year = date.getYear();
			String begindateShow= day +" "+ month + " "+ year;
			 
			 Mmap.put("begindateShow",begindateShow);
			 Mmap.put("esid_es_id",esi_es_id);
			
					int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			
			if (ec_exam_id != 0) {
			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			
		}
			 
			}
			
			int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
			  
			if(es_id != 0) {
				 List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
				 Mmap.put("es_id", es_id);
				 String index_mode= UnlcokExmsch.get(0).getEs_index_mode();
				 Mmap.put("index_mode", index_mode);
			}
			

			int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
			
			if (esid_sub_subject_id != 0) {
				List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
				String sub_subject_name=SubSubject.get(0).getSub_subject();
				
				 System.out.println("sub_subject_name==================="+sub_subject_name);
				
				Mmap.put("sub_subject_name", sub_subject_name);
			}
			  
		     Mmap.put("msg", msg);
		     
		     Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		        if(flashMap != null){
		        	@SuppressWarnings("unchecked")
					ArrayList<List<Map<String, Object>>> errorList =  (ArrayList<List<Map<String, Object>>>) flashMap.get("errorlist");
		            System.out.println(errorList);
		            Mmap.put("errorList",errorList);
		             
		            int countsectionlist = (int) flashMap.get("countsectionlist");
		            
		            System.out.println("countsectionlist==========="+countsectionlist);
		            
		            Mmap.put("countsectionlist",countsectionlist);
		            
		            
		            
                    int savedatecount = (int) flashMap.get("savedatecount");
		            
		            System.out.println("countsectionlist==========="+savedatecount);
		            
		            Mmap.put("savedatecount",savedatecount);
		            
		            
		        	ArrayList<List<Map<String, Object>>> listsection =  (ArrayList<List<Map<String, Object>>>) flashMap.get("listsection");
		            System.out.println(listsection);
		            Mmap.put("listsection",listsection);
		            
		            
		            
		            int subject_id = (int) flashMap.get("subject_id");
		            
		            Mmap.put("subject_id",subject_id);
		            
		            
		            
		        }
		        
		      //  String subjectid1 = "";
		        
		    	//Mmap.put("list",Getlist(es_id , subjectid1 )); 
		    	
		        
		        
			return new ModelAndView("ManualMarksUploadTiles");

	}
	
	
	
	 @RequestMapping(value = "/UploadMamualMarksAction", method = RequestMethod.POST)
		public ModelAndView UploadMamualMarksAction(HttpServletRequest request, ModelMap model, HttpSession session,RedirectAttributes ra,
				@RequestParam(value = "fileUpload", required = false) MultipartFile fileUpload){
			
//			ArrayList<List<Map<String, Object>>> listerror=new ArrayList<List<Map<String, Object>>>();

			ArrayList<ArrayList<ArrayList<ArrayList<String>>>> listerror = new ArrayList<ArrayList<ArrayList<ArrayList<String>>>>();
			
		
			ArrayList<ArrayList<String>> listsection = new ArrayList<ArrayList<String>>();
			
			int countsectionlist =0;
			
			int savedatecount =0;
			
			
			Session sessionHQL = this.sessionFactory.openSession();
			//Session sessionHQL6 = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			if(fileUpload.equals("")) {
				 ra.addAttribute("msg","Please Upload Copy Of File Upload");
				  return new ModelAndView("redirect:UploadManualMarksURL");
			  }
			int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
			String subject_id= request.getParameter("subject_id");
			System.out.println("subject_id=============="+subject_id);
			try {
				Date date = new Date();
				String username = session.getAttribute("username").toString();
				String userId = session.getAttribute("userId").toString();

				XSSFWorkbook wb = new XSSFWorkbook(fileUpload.getInputStream());
				XSSFSheet sheet = wb.getSheetAt(0);
				String es_begindate = session.getAttribute("es_begin_date") == "" ? "": session.getAttribute("es_begin_date").toString();
				String es_year1 = es_begindate.split("-")[0];
				int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
	 			if (esi_es_id != 0) {
	 				
	 				 ArrayList<ArrayList<String>> list =subwisesecDAO.GetSubwiseQueDetails( esi_es_id,  Integer.parseInt(subject_id), "Excel");

	 				 System.err.println("subjectwiseSecDetails============"+list);
	 				ArrayList<ArrayList<String>> indexlist=subwisesecDAO.GetIndexNoForExcel( esi_es_id,   Integer.parseInt(subject_id), "Excel");
	 				
	 				String section_count= list.get(0).get(2);
	 				
	 				
	 				
	 				int rowNum4 = 4;
	 				Cell cell = null;
	 				
	 				
	 				
	 				int rowNum4count = 0;
	 				
	 				
	 				int lastrownum = sheet.getLastRowNum() - 3;
	 				
	 				ArrayList<ArrayList<ArrayList<String>>> listDataman = new ArrayList<ArrayList<ArrayList<String>>>();
	 				
	 				ArrayList <ArrayList<String>> listDataereinoman = new ArrayList<ArrayList<String>>();
	 				
	 				ArrayList<String> listDataereino = new ArrayList<String>();
 					
	 				int lpcount =0;
 					
 					for (int ino = 0; ino < indexlist.size(); ino++) {
	 					
 						
 						rowNum4 = 4;
 						
 						int inno=0;
 						
 						int innonotmch=0;
 						 
 						
 						List<String> l = indexlist.get(ino);
	 					 
	 					System.err.println("l  : "+ l );
	 					
	 					System.err.println("l.get(1)   :"+l.get(1));
	 				 
	 					String indexnodatab=l.get(1);

	 				for (int i3 = 0; i3 < sheet.getLastRowNum(); i3++) {
	 					
	 					
	 					Row row3 = sheet.getRow(rowNum4);
	 					
	 					if (sheet.getRow(rowNum4) == null) {
							break;
						}
	 					
	 					if (row3.getCell(0) == null) {
							break;
						}

	 					String indexno= row3.getCell(1).getStringCellValue();
	 					
	 					if ( indexno == null) {
	 						break;
						}
	 					 
	 					System.err.println("indexno :"+indexno);
		 				
		 					if (indexno.equals(indexnodatab)) {

		 						inno++;
		 						
								}
		 					
		 					if (!indexnodatab.equals(indexno)) {

		 						innonotmch++;
		 						
								}
		 					
		 					
		 					
		 					rowNum4++;
		 					
		 					if ( lpcount==0 ) {
		 						rowNum4count++;
							}
	 					} 
	 				
	 				if ( indexlist.size()!=rowNum4count) {
 						listDataereino.add("");
	 				 
	 					listDataereino.add("DIFFERENT FILE AS NO OF INDEX NOS NOT MATCHING");
					}
	 				
//	 				if (inno>1) {
//	 					listDataereino.add(indexnodatab);
//	 					listDataereino.add("DIFFERENT ");
//					}
	 				
	 				 System.err.println("inno============"+inno);
	 				
	 				if (inno>1) {
	 					listDataereino.add(indexnodatab);
	 					listDataereino.add("DUPLICATE INDEX NO FOOND / INDEX NO MISSING");
					}
	 				
	 				
	 				
	 				   
	 				lpcount++;
	 					
	 				}
	 				
 					
 					
	 				
 					
 					
 					
	 				 System.err.println("rowNum4count============"+rowNum4count);
	 				 
	 				 System.err.println("indexlist.size()============"+indexlist.size());
	 
	 				 
	 				 if (listDataereino.isEmpty()) {
						
					
	 				
	 				
	 				rowNum4 = 4;
	 				

	 				for (int i3 = 0; i3 < indexlist.size(); i3++) {
	 					
//	 					ArrayList<String> listData = new ArrayList<String>();
//	 					ArrayList <ArrayList<String>> sectionandquestionlistforlisterror = new ArrayList<ArrayList<String>>();
//	 					
	 					
	 					ArrayList<ArrayList<ArrayList<String>>> listData = new ArrayList<ArrayList<ArrayList<String>>>();
	 					ArrayList <ArrayList<String>> sectionandquestionlistforlisterror = new ArrayList<ArrayList<String>>();
	 					ArrayList <ArrayList<String>> listDataere12 = new ArrayList<ArrayList<String>>();
	 					
	 					
	 					
	 					
	 					
	 					ArrayList<String> listDataere = new ArrayList<String>();
	 					
	 					Row row3 = sheet.getRow(rowNum4);
	 					String indexno= row3.getCell(1).getStringCellValue();
	 					
//	 					===========================================
	 					
	 					List<String> l = indexlist.get(i3);
	 					 
	 					System.err.println("l  : "+ l );
	 					
	 					System.err.println("l.get(1)   :"+l.get(1));
	 					 System.err.println("indexno :"+indexno);
	 					String indexnodatab=l.get(1);
	 					
	 				
	 					
	 				
	 					if (!indexnodatab.equals(indexno)) {
	 						
	 				 
	 						listDataere.add(indexno);
	 						listDataere.add("INDEX NO NOT FOUND");
//	 						listDataere.add("index no out of bound");
								
//		 						if(!listData.isEmpty()) {
// 								listerror.add(listData);
// 							}
		 						
							}
		 					 else {	
		 						 
		 					 
//	 					=============================================
	 					List<OFFICER_APPLICATION_M>application_no=comm.getOfficerApplicationByIndexNo(sessionFactory,Integer.parseInt(indexno), esi_es_id);
	 					int applicatio_id= application_no.get(0).getOa_application_id();
	 					int opd_pers_id=application_no.get(0).getOpd_personal_id();
	 					
	 					
	 					
	 				
	 					
	 			 
	 					Query q0 = sessionHQL.createQuery(
	 							"select count(*) from ANSWER_BOOK_M where oa_application_id=:oa_application_id and sc_subject_id=:sc_subject_id ");
	 					
	 					q0.setParameter("oa_application_id", applicatio_id).setParameter("sc_subject_id",Integer.parseInt(subject_id) );
	 			 

//	 					q0.setParameter("opd_personal_id", id);
	 					Long c = (Long) q0.uniqueResult();
	 					
	 					System.err.println("c=========="+c);
	 				 
	 					Boolean error = false;
	 					
	 			 
 							
 							if (c == 0) {
					
	 					
	 					
	 					
	 					
	 					
	 					
	 					List<OFFICER_PERSONAL_DETAILS_M> pbda_sumBy_opdId= comm.getpbdasumbyopdid( sessionFactory, opd_pers_id);
	 					int pbda_subject_code= pbda_sumBy_opdId.get(0).getPbda_sub_code();
	 					List<INDEX_SLIP_MASTER>IndxSlipMstId=comm.getIndexSlipId(sessionFactory, Integer.parseInt(indexno),  esi_es_id);
	 					int indxslipMstId=IndxSlipMstId.get(0).getIsm_id();
	 					 List<INDEX_SLIP_MANUAL>getIs_id=comm. getSlipManualIDforOfc( sessionFactory, indxslipMstId,  Integer.parseInt(subject_id));
	 					int is_id=getIs_id.get(0).getIs_id();
	 					
	 					List<SUBJECT_CODE_M> sublist=comm.getsubjectIdbysubname(sessionFactory, Integer.parseInt(subject_id),ec_exam_id);
	 					int excel_sub_code= sublist.get(0).getSc_subject_code();
	 					
	 					System.err.println("index no : "+ indexno);
	 					
	 					int m2=2;
	 					
	 					
	 					
	 						 				 
	 					
	 					
	 					List<Map<String, Object>> section = new ArrayList<Map<String, Object>>();
	 					
	 						int total=0;
	 						
	 						countsectionlist=Integer.parseInt(section_count);	 						
	 						
	 						for (int i=0; i < Integer.parseInt(section_count);i++) {
	 							
	 							ArrayList<String> sectionandquestionlist = new ArrayList<String>();
	 						
	 							 int j =m2;
	 							
	 							int attemp=0;
	 							
	 							String sectionname= "";
	 							
	 							sectionname = ""+(i+1);
	 							
	 							ArrayList<String>  sectiondate = new ArrayList<String>();

	 							sectiondate.add(sectionname);//section name
	 							
	 							sectiondate.add(list.get(i).get(6)); //MARKS
	 							
	 							sectiondate.add(list.get(i).get(7)); //QUESTIONS
	 							
	 							
	 							if (countsectionlist>listsection.size()) {
	 								listsection.add(sectiondate);
								} 
	 							
	 							
	 							
	 							Map<String, Object> question = new LinkedHashMap<String, Object>();
	 							for(int m=0;m<Integer.parseInt(list.get(i).get(4));m++) {
	 								
	 								cell = row3.getCell(j);
	 								String value = "";
	 								if(cell != null) {
	 								switch (cell.getCellType()) {
	 								case Cell.CELL_TYPE_STRING:
	 									value = cell.getStringCellValue();
	 									break;
	 								case Cell.CELL_TYPE_NUMERIC:
	 									if (HSSFDateUtil.isCellDateFormatted(cell)) {
	 										value = String.valueOf(cell.getDateCellValue());
	 									} else {
	 										value = String.valueOf((long) cell.getNumericCellValue());
	 									}
	 									break;
	 								case Cell.CELL_TYPE_BOOLEAN:
	 									value = String.valueOf(cell.getBooleanCellValue());
	 									break;
	 								default:
	 								}
	 								if(value.equals("")) value="0";
	 								}
	 								else {
	 									value="0";
	 								}
	 								if(!value.equals("0")) {
	 									attemp++;
	 								}
	 								
	 								
	 								
	 								
	 								if(Integer.parseInt(value)>Integer.parseInt(list.get(i).get(6))) {
	 									listDataere.add(indexno);
//	 									listDataere.add("Marks gretar then Max Marks");
	 									listDataere.add("MARKS FED GREATER THAN APPLICABLE MARKS");
	 									error=true;
	 								}
	 								
	 								
	 								sectionandquestionlist.add(value);
	 								
	 								question.put("q"+m, value);
	 								total = total + Integer.parseInt(value);
	 								
	 								System.err.println("row "+rowNum4+" cell "+j+": "+value);
	 								j++;
	 								
	 								
	 							}
	 							
	 				
	 							
	 							if(attemp>Integer.parseInt(list.get(i).get(7))) {
	 								
	 								listDataere.add(indexno);
//	 								listDataere.add("question out of bound");
//	 								listDataere.add("MORE QUESTIONS ATTEMPTED THAN APPLICABLE");
	 								
	 								listDataere.add("EXTRA QS ATTEMPTED");
	 								
	 								error=true;
	 							}
	 							section.add(question);
	 							
	 							m2=m2+Integer.parseInt(list.get(i).get(4));
	 							
	 							
	 							sectionandquestionlistforlisterror.add(sectionandquestionlist);
	 						}
	 						
	 						
	 						System.err.println("total :"+ total);
	 						
	 						if(!error) {
	 							
	 							
	 							Session sessionHQL3 = this.sessionFactory.openSession();
	 							Transaction tx3 = sessionHQL3.beginTransaction();
	 							System.err.println(section);
	 							int q=1;
	 							for (int i=0; i < section.size();i++) {
	 								for(int j=0;j< section.get(i).size();j++) {
	 									System.out.println("Q :"+j+" marks :"+section.get(i).get("q"+j));
	 									Questionwise_marks_details que_marks= new Questionwise_marks_details();
	 									que_marks.setOa_application_id(applicatio_id);
	 									que_marks.setSubject_id(Integer.parseInt(subject_id));
	 									
	 		 							que_marks.setQmd_qno(q);
	 		 							que_marks.setQmd_is_id(is_id);
	 		 							que_marks.setQmd_marks_obtained(String.valueOf((section.get(i).get("q"+j))));
	 		 							que_marks.setTm_ncreatedby(Integer.parseInt(userId));
	 		 							que_marks.setTm_dtcreatedate(date);
	 		 							sessionHQL3.save(que_marks);
	 		 							q++;
	 								}
	 							}
	 							ANSWER_BOOK_M ans_book=new ANSWER_BOOK_M();
	 							ans_book.setOa_application_id(applicatio_id);
	 							ans_book.setSc_subject_id(Integer.parseInt(subject_id));
	 							ans_book.setAb_created_by(username);
	 							ans_book.setAb_creation_date(date);
	 							ans_book.setAb_marks_obtained(total);
	 							ans_book.setAb_first_entry(total);
	 							ans_book.setAb_status_id(0);
	 							ans_book.setSc_subject_id(Integer.parseInt(subject_id));
	 							sessionHQL3.save(ans_book);
	 							
	 							
								ArrayList<ArrayList<String>> pass_marks = partBmarksDao.PartBOfficerresult(esi_es_id,
										Integer.parseInt(subject_id));
								  String passingmarks= pass_marks.get(0).get(0);
								  
								  OFFICER_RESULTS_M off_result= new OFFICER_RESULTS_M();
								  int latest_pbdacode=0;
									if (Integer.parseInt(passingmarks) <= total) {
										
										off_result.setOr_subject_pass(1);

										latest_pbdacode= pbda_subject_code - excel_sub_code;
										String hq14 = "update OFFICER_PERSONAL_DETAILS_M set pbda_sub_code=:pbda_sub_code  where opd_personal_id=:opd_personal_id ";
										Query query4 = sessionHQL3.createQuery(hq14)
												.setParameter("pbda_sub_code", pbda_subject_code - excel_sub_code)
												.setParameter("opd_personal_id", opd_pers_id);
										query4.executeUpdate();

									}

									else {
										latest_pbdacode=pbda_subject_code;
										off_result.setOr_subject_pass(0);
									}

									off_result.setEs_id(esi_es_id);
									off_result.setSc_subject_id(Integer.parseInt(subject_id));
									off_result.setOpd_personal_id(opd_pers_id);
									sessionHQL3.save(off_result);

									sessionHQL3.flush();
									sessionHQL3.clear();

									tx3.commit();
									sessionHQL3.close();
									
									
									
									Session sessionHQL1 = this.sessionFactory.openSession();
									Transaction tx1 = sessionHQL1.beginTransaction();
									
									if(ec_exam_id == 1) {
		 								
		 								List<OFFICER_ARM_M> pers_armID = comm.getarmcode(sessionFactory, opd_pers_id);
		 								int pers_armId = pers_armID.get(0).getAc_arm_id();

		 								ArrayList<ArrayList<String>> ForPartbubjectList = PartBDAo.getSubjectList("Part D",
		 										String.valueOf(pers_armId));
		 								int PartD_SubCode = 0;
		 								for (int i1 = 0; i1 < ForPartbubjectList.size(); i1++) {

		 									String sub = ForPartbubjectList.get(i1).get(2);

		 									PartD_SubCode += Integer.parseInt(sub);

		 								}
									if (latest_pbdacode == 0) {
										String hq16 = "update OFFICER_PERSONAL_DETAILS_M set opd_partb=:opd_partb,pbda_sub_code=:pbda_sub_code   where opd_personal_id=:opd_personal_id ";
										Query query6 = sessionHQL1.createQuery(hq16)
												.setParameter("opd_partb", Integer.parseInt(es_year1))
												.setParameter("pbda_sub_code", PartD_SubCode)
												.setParameter("opd_personal_id", opd_pers_id);
										query6.executeUpdate();
										tx1.commit();
									}
									}
									if(ec_exam_id == 2) {
									if (latest_pbdacode == 0) {
										String hq16 = "update OFFICER_PERSONAL_DETAILS_M set opd_partd=:opd_partd,pbda_sub_code=:pbda_sub_code   where opd_personal_id=:opd_personal_id ";
										Query query6 = sessionHQL1.createQuery(hq16)
												.setParameter("opd_partd", Integer.parseInt(es_year1))
												.setParameter("pbda_sub_code", 0)
												.setParameter("opd_personal_id", opd_pers_id);
										query6.executeUpdate();
										tx1.commit();
									}
									}
									ra.addAttribute("msg", "DATA SAVED SUCCESSFULLY");
									
									savedatecount++;
									
 							}
 							
 							
	 						else {
	 							
//	 							listerror.add(section);
	 						}
									
	 							}
	 							else {
	 								listDataere.add(indexno);
	 								listDataere.add("DATA ALREADY EXISTS");
	 								
	 							}
									
	 						} 
	 					
	 					if(!listDataere.isEmpty()) {
	 						
	 						listDataere12.add(listDataere);
	 						
	 						int datelistcount=0;
	 						for(int m=0;m< listDataere.size() ;m++) {
	 						
	 							if ( listDataere.get(m).equals(indexno) ) {
	 								datelistcount++;
								}
	 							
	 							if ( listDataere.get(m).equals("DATA ALREADY EXISTS") ) {
	 								datelistcount=0;
								}
	 							
	 							 
	 						}
	 						
	 						listData.add(listDataere12);
	 						if (datelistcount>0) {
	 							listData.add(sectionandquestionlistforlisterror);
							}
	 						
 
	 						listerror.add(listData);
	 					}
	 				
	 					rowNum4++;
	 				}
	 				
	 				 }//for ino chak
	 				 
	 				 else {
	 					 
                       
	 					    listDataereinoman.add(listDataereino);
	 						 
	 						listDataman.add(listDataereinoman);
	 						 
	 						listerror.add(listDataman);
	 					 
	 					 
	 				 }
	 				 
	 				 
	 				 
	 				 
	 				 
	 				 
	 				 
	 				 
	 				 
	 				 
	 				tx.commit();
	 			}
	 		}
			 catch (Exception e) {
				tx.rollback();
				e.printStackTrace();
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}
			
			System.err.println("listerror=======_--------"+listerror.size());
			
			
			
			System.err.println("listsection=======_--------"+listsection);
			
			ra.addFlashAttribute("errorlist",listerror);
			ra.addFlashAttribute("errorlistSize",listerror.size());
		 
			ra.addFlashAttribute("countsectionlist",countsectionlist);
			
			ra.addFlashAttribute("savedatecount",savedatecount);
			
			
			ra.addFlashAttribute("listsection",listsection);
			
			ra.addFlashAttribute("subject_id", Integer.parseInt(subject_id));
			
			return new ModelAndView("redirect:UploadManualMarksURL");
		
		 }
	 
	 @RequestMapping(value = "/savedateforerrorrepotUrl11", method = RequestMethod.POST)
	 public @ResponseBody String savedateforerrorrepotUrl11(ModelMap model, HttpSession session,
				@RequestParam(value = "msg", required = false) String msg , HttpServletRequest request,String typeReport) {
			 
			String save = "";
			 
			String indexno = request.getParameter("indexnohid"); 
			
			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();

			Date date = new Date();
			String username = session.getAttribute("username").toString();

			
			String es_begindate = session.getAttribute("es_begin_date") == "" ? "": session.getAttribute("es_begin_date").toString();
			String es_year1 = es_begindate.split("-")[0];
			
			String userId = session.getAttribute("userId").toString();
			
			String subject_id = request.getParameter("subject_id");
			  
			int esi_es_id = Integer
					.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
 
			int ec_exam_id = Integer.parseInt(
					session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
			
			 
			List<OFFICER_APPLICATION_M>application_no=comm.getOfficerApplicationByIndexNo(sessionFactory,Integer.parseInt(indexno), esi_es_id);
 	
			String opd_pers_id = String.valueOf(application_no.get(0).getOpd_personal_id()) ;
	
 
			String applicatio_id =  String.valueOf(application_no.get(0).getOa_application_id());
			
			
			System.err.println("applicatio_id====applicatio_id="+applicatio_id);
//			================================================================================
			
			 ArrayList<ArrayList<String>> list =subwisesecDAO.GetSubwiseQueDetails( esi_es_id,  Integer.parseInt(subject_id), "Excel");

				 System.err.println("subjectwiseSecDetails============"+list);
 
				 List<INDEX_SLIP_MASTER> indexlist= comm.getIndexSlipId( sessionFactory,   Integer.parseInt(indexno), esi_es_id);
				String section_count= list.get(0).get(2);
				
				
				String indexnodatab=String.valueOf(indexlist.get(0).getIsm_indexno());
				 

 
					
					ArrayList<ArrayList<ArrayList<String>>> listData = new ArrayList<ArrayList<ArrayList<String>>>();
					ArrayList <ArrayList<String>> sectionandquestionlistforlisterror = new ArrayList<ArrayList<String>>();
					ArrayList <ArrayList<String>> listDataere12 = new ArrayList<ArrayList<String>>();
					
					
					
					ArrayList<String> listDataere = new ArrayList<String>();
					
 
					
				
					if (!indexnodatab.equals(indexno)) {
 
						save = "INDEX NO NOT FOUND";
						return save;
						
 
 						
					}
 					 else {	
 						 
 
					Session sessionHQL6 = this.sessionFactory.openSession();
					Transaction tx6 = sessionHQL6.beginTransaction();
					
			 
					Query q0 = sessionHQL.createQuery(
							"select count(*) from ANSWER_BOOK_M where oa_application_id=:oa_application_id and sc_subject_id=:sc_subject_id ");
					
					q0.setParameter("oa_application_id", Integer.parseInt(applicatio_id)).setParameter("sc_subject_id",Integer.parseInt(subject_id) );
			 

//					q0.setParameter("opd_personal_id", id);
					Long c = (Long) q0.uniqueResult();
					
					System.err.println("c=========="+c);
				 
					sessionHQL6.flush();
					sessionHQL6.clear();

				tx6.commit();
					
					
				
				if (c == 0) {
					
					
					
					
					
					
					List<OFFICER_PERSONAL_DETAILS_M> pbda_sumBy_opdId= comm.getpbdasumbyopdid( sessionFactory,Integer.parseInt(opd_pers_id));
					int pbda_subject_code= pbda_sumBy_opdId.get(0).getPbda_sub_code();
					List<INDEX_SLIP_MASTER>IndxSlipMstId=comm.getIndexSlipId(sessionFactory, Integer.parseInt(indexno),  esi_es_id);
					int indxslipMstId=IndxSlipMstId.get(0).getIsm_id();
					 List<INDEX_SLIP_MANUAL>getIs_id=comm. getSlipManualIDforOfc( sessionFactory, indxslipMstId,  Integer.parseInt(subject_id));
					int is_id=getIs_id.get(0).getIs_id();
					
					List<SUBJECT_CODE_M> sublist=comm.getsubjectIdbysubname(sessionFactory, Integer.parseInt(subject_id),ec_exam_id);
					int excel_sub_code= sublist.get(0).getSc_subject_code();
					
					System.err.println("index no : "+ indexno);
					
					int m2=2;
					
					
					
		 
					
					
					List<Map<String, Object>> section = new ArrayList<Map<String, Object>>();
						Boolean error = false;
						int total=0;
						
						
						
						
						
						int qmd_qno=0;
			 
						int qmd_qno_old=0;
						
						int i1_old=0;
						
 
						
						
						for (int i=0; i < Integer.parseInt(section_count);i++) {
							
							ArrayList<String> sectionandquestionlist = new ArrayList<String>();
						
 
							
							int attemp=0;
							
 
							
							Map<String, Object> question = new LinkedHashMap<String, Object>();
							for(int m=0;m<Integer.parseInt(list.get(i).get(4));m++) {
								
								qmd_qno++;
								int i1 = m + 1;
								
//								if ( i1 > qmd_qno+i1_old) {
//									qmd_qno_old=qmd_qno;
//									i1_old=i1-1;
//									break;
//								}
//								
//								if (i1 <qmd_qno_old) {
//									i1=i1_old+1;
//									m = i1_old;
//								}
								
								
								System.err.println("que====="+qmd_qno);
								
								
								
								
								String value = request.getParameter(indexno+"que"+qmd_qno); ;
								if(value.equals("null") ||  value.equals("") || value.equals(null)) {
									value="0";
								}
								
								if(!value.equals("0")) {
									attemp++;
								}
								if(Integer.parseInt(value)>Integer.parseInt(list.get(i).get(6))) {
//									listDataere.add(indexno);
//									listDataere.add("Marks gretar then Max Marks");
//									System.err.println("Marks gretar then Max Marks");
//									 
									error=true;
//									save = "Marks gretar then Max Marks";
									save ="MARKS FED GREATER THAN APPLICABLE MARKS";
									return save;
									
									
								}
								
								
								sectionandquestionlist.add(value);
								
								question.put("q"+m, value);
								total = total + Integer.parseInt(value);
								
//								System.err.println("row "+rowNum4+" cell "+j+": "+value);
//								j++;
							}
							if(attemp>Integer.parseInt(list.get(i).get(7))) {
								
//								listDataere.add(indexno);
//								listDataere.add("question out of bound");
//								
								error=true;
//								save = "Question Out of Bound";
								save = "MORE QUESTIONS ATTEMPTED THAN APPLICABLE";
								return save;
								
								
							}
							section.add(question);
							
							m2=m2+Integer.parseInt(list.get(i).get(4));
							
							
							sectionandquestionlistforlisterror.add(sectionandquestionlist);
							
						}
						
						System.err.println("error :"+ error);
						
						
					
						
						if(!error) {
							
						
							
							Session sessionHQL3 = this.sessionFactory.openSession();
							Transaction tx3 = sessionHQL3.beginTransaction();
							System.err.println(section);
							int q=1;
							for (int i=0; i < section.size();i++) {
								for(int j=0;j< section.get(i).size();j++) {
									System.out.println("Q :"+j+" marks :"+section.get(i).get("q"+j));
									Questionwise_marks_details que_marks= new Questionwise_marks_details();
									que_marks.setOa_application_id(Integer.parseInt(applicatio_id));
									que_marks.setSubject_id(Integer.parseInt(subject_id));
									
		 							que_marks.setQmd_qno(q);
		 							que_marks.setQmd_is_id(is_id);
		 							que_marks.setQmd_marks_obtained(String.valueOf((section.get(i).get("q"+j))));
		 							que_marks.setTm_ncreatedby(Integer.parseInt(userId));
		 							que_marks.setTm_dtcreatedate(date);
		 							sessionHQL3.save(que_marks);
		 							q++;
								}
							}
							ANSWER_BOOK_M ans_book=new ANSWER_BOOK_M();
							ans_book.setOa_application_id(Integer.parseInt(applicatio_id));
							ans_book.setSc_subject_id(Integer.parseInt(subject_id));
							ans_book.setAb_created_by(username);
							ans_book.setAb_creation_date(date);
							ans_book.setAb_marks_obtained(total);
							ans_book.setAb_first_entry(total);
							ans_book.setAb_status_id(0);
							ans_book.setSc_subject_id(Integer.parseInt(subject_id));
							sessionHQL3.save(ans_book);
							
							
						ArrayList<ArrayList<String>> pass_marks = partBmarksDao.PartBOfficerresult(esi_es_id,
								Integer.parseInt(subject_id));
						  String passingmarks= pass_marks.get(0).get(0);
						  
						  OFFICER_RESULTS_M off_result= new OFFICER_RESULTS_M();
						  int latest_pbdacode=0;
							if (Integer.parseInt(passingmarks) <= total) {
								
								off_result.setOr_subject_pass(1);

								latest_pbdacode= pbda_subject_code - excel_sub_code;
								String hq14 = "update OFFICER_PERSONAL_DETAILS_M set pbda_sub_code=:pbda_sub_code  where opd_personal_id=:opd_personal_id ";
								Query query4 = sessionHQL3.createQuery(hq14)
										.setParameter("pbda_sub_code", pbda_subject_code - excel_sub_code)
										.setParameter("opd_personal_id", Integer.parseInt(opd_pers_id));
								query4.executeUpdate();

							}

							else {
								latest_pbdacode=pbda_subject_code;
								off_result.setOr_subject_pass(0);
							}

							off_result.setEs_id(esi_es_id);
							off_result.setSc_subject_id(Integer.parseInt(subject_id));
							off_result.setOpd_personal_id(Integer.parseInt(opd_pers_id));
							sessionHQL3.save(off_result);

							sessionHQL3.flush();
							sessionHQL3.clear();

							tx3.commit();
							sessionHQL3.close();
							
							
							
							Session sessionHQL1 = this.sessionFactory.openSession();
							Transaction tx1 = sessionHQL1.beginTransaction();
							
							if(ec_exam_id == 1) {
 								
 								List<OFFICER_ARM_M> pers_armID = comm.getarmcode(sessionFactory, Integer.parseInt(opd_pers_id));
 								int pers_armId = pers_armID.get(0).getAc_arm_id();

 								ArrayList<ArrayList<String>> ForPartbubjectList = PartBDAo.getSubjectList("Part D",
 										String.valueOf(pers_armId));
 								int PartD_SubCode = 0;
 								for (int i1 = 0; i1 < ForPartbubjectList.size(); i1++) {

 									String sub = ForPartbubjectList.get(i1).get(2);

 									PartD_SubCode += Integer.parseInt(sub);

 								}
							if (latest_pbdacode == 0) {
								String hq16 = "update OFFICER_PERSONAL_DETAILS_M set opd_partb=:opd_partb,pbda_sub_code=:pbda_sub_code   where opd_personal_id=:opd_personal_id ";
								Query query6 = sessionHQL1.createQuery(hq16)
										.setParameter("opd_partb", Integer.parseInt(es_year1))
										.setParameter("pbda_sub_code", PartD_SubCode)
										.setParameter("opd_personal_id", Integer.parseInt(opd_pers_id));
								query6.executeUpdate();
								tx1.commit();
							}
							}
							if(ec_exam_id == 2) {
							if (latest_pbdacode == 0) {
								String hq16 = "update OFFICER_PERSONAL_DETAILS_M set opd_partd=:opd_partd,pbda_sub_code=:pbda_sub_code   where opd_personal_id=:opd_personal_id ";
								Query query6 = sessionHQL1.createQuery(hq16)
										.setParameter("opd_partd", Integer.parseInt(es_year1))
										.setParameter("pbda_sub_code", 0)
										.setParameter("opd_personal_id", Integer.parseInt(opd_pers_id));
								query6.executeUpdate();
								tx1.commit();
							}
							}
							}
							
							
						
							
							
						else { }
						}
						else {
						 
							save = "DATA ALREADY EXISTS";
							return save;
						}
						
						save = "DATA SAVED SUCCESSFULLY";
 						} 
				
					 
 
				tx.commit();
 
			
			System.err.println("applicatio_id====applicatio_id="+applicatio_id);
			
			System.err.println("save====="+save);
			
 
			if (save == "DATA SAVED SUCCESSFULLY") {
				ArrayList<String> savecountlist =  partBmarksDao.getcountformulmks(  subject_id, String .valueOf(esi_es_id));	
				
				save += "_"+savecountlist.get(0)+"_"+savecountlist.get(1);
			}
			
			
			return save;
		}
		
	 
	 
	  
}
