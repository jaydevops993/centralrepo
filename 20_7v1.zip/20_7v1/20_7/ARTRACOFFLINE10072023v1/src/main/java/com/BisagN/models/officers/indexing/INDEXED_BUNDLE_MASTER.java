package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "indexed_bundle_master", uniqueConstraints = {
@UniqueConstraint(columnNames = "ibm_id"),})
public class INDEXED_BUNDLE_MASTER {

	private int ibm_id;
	private String ibm_bundle_prefix;
	private String ibm_bundle_no;
	private int ibm_es_id;
	private int ibm_nsubjectid;
	private int ibm_iu_user_id;
	private int ibm_ac_arm_id;
	private int ibm_abcount;
	private int ibm_updatedby;
	private int ibm_masterab_status_id;
	private int ibm_exmsheet_status_id;
	private int ibm_sub_subject_id;
	private int ibm_status_id;
	
	
	@Id
     @GeneratedValue(strategy = IDENTITY)
     @Column(name = "ibm_id", unique = true, nullable = false)
	
	public int getIbm_id() {
		return ibm_id;
	}
	public void setIbm_id(int ibm_id) {
		this.ibm_id = ibm_id;
	}
	public String getIbm_bundle_prefix() {
		return ibm_bundle_prefix;
	}
	public void setIbm_bundle_prefix(String ibm_bundle_prefix) {
		this.ibm_bundle_prefix = ibm_bundle_prefix;
	}
	public String getIbm_bundle_no() {
		return ibm_bundle_no;
	}
	public void setIbm_bundle_no(String ibm_bundle_no) {
		this.ibm_bundle_no = ibm_bundle_no;
	}
	public int getIbm_es_id() {
		return ibm_es_id;
	}
	public void setIbm_es_id(int ibm_es_id) {
		this.ibm_es_id = ibm_es_id;
	}
	public int getIbm_nsubjectid() {
		return ibm_nsubjectid;
	}
	public void setIbm_nsubjectid(int ibm_nsubjectid) {
		this.ibm_nsubjectid = ibm_nsubjectid;
	}
	public int getIbm_iu_user_id() {
		return ibm_iu_user_id;
	}
	public void setIbm_iu_user_id(int ibm_iu_user_id) {
		this.ibm_iu_user_id = ibm_iu_user_id;
	}
	public int getIbm_ac_arm_id() {
		return ibm_ac_arm_id;
	}
	public void setIbm_ac_arm_id(int ibm_ac_arm_id) {
		this.ibm_ac_arm_id = ibm_ac_arm_id;
	}
	public int getIbm_abcount() {
		return ibm_abcount;
	}
	public void setIbm_abcount(int ibm_abcount) {
		this.ibm_abcount = ibm_abcount;
	}
	public int getIbm_updatedby() {
		return ibm_updatedby;
	}
	public void setIbm_updatedby(int ibm_updatedby) {
		this.ibm_updatedby = ibm_updatedby;
	}
	public int getIbm_masterab_status_id() {
		return ibm_masterab_status_id;
	}
	public void setIbm_masterab_status_id(int ibm_masterab_status_id) {
		this.ibm_masterab_status_id = ibm_masterab_status_id;
	}
	public int getIbm_exmsheet_status_id() {
		return ibm_exmsheet_status_id;
	}
	public void setIbm_exmsheet_status_id(int ibm_exmsheet_status_id) {
		this.ibm_exmsheet_status_id = ibm_exmsheet_status_id;
	}
	public int getIbm_sub_subject_id() {
		return ibm_sub_subject_id;
	}
	public void setIbm_sub_subject_id(int ibm_sub_subject_id) {
		this.ibm_sub_subject_id = ibm_sub_subject_id;
	}
	public int getIbm_status_id() {
		return ibm_status_id;
	}
	public void setIbm_status_id(int ibm_status_id) {
		this.ibm_status_id = ibm_status_id;
	}
	
	
	
}
