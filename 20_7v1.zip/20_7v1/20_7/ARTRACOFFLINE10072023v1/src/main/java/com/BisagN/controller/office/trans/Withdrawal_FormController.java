package com.BisagN.controller.office.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.PartiallyPassPDFController;
import com.BisagN.controller.office.others.ResultReleasePDFController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.course.MeritandResultGenerationDao;
import com.BisagN.models.officers.masters.CHOICE_M;
import com.BisagN.models.officers.others.RESULTS_WITHHELD_M;
import com.BisagN.models.officers.trans.QUALIFIED_OFFICERS;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Withdrawal_FormController {
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

//	@Autowired
//	private Reason_MasterDAO objDAO;

	@Autowired
	private RoleBaseMenuDAO roledao;

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	CommonController comm = new CommonController(); 
	
	@Autowired
	private MeritandResultGenerationDao MeritDao;
	
	// ===========================OPEN PAGE============================//
		@RequestMapping(value = "WithdrawalFormMasterUrl", method = RequestMethod.GET)
		public ModelAndView WithdrawalFormMasterUrl(ModelMap Mmap, HttpSession session, HttpServletRequest request,
				@RequestParam(value = "msg", required = false) String msg)
				throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
				NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

			if (request.getHeader("Referer") == null) {
				session.invalidate();
				Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
				return new ModelAndView("redirect:/login");
			}
	
			String roleid1 = session.getAttribute("roleid").toString();
			Boolean val = roledao.ScreenRedirect("WithdrawalFormMasterUrl", roleid1);
			if (val == false) {
				return new ModelAndView("AccessTiles");
			}
			
			
			String es_begindate = session.getAttribute("es_begin_dateshow") == null ? ""
					: session.getAttribute("es_begin_dateshow").toString();
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
					: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			if (ec_exam_id == 3) {
				
				
			if (!es_begindate.equals("")) {
				Mmap.put("es_begindate", es_begindate);
			}
			
		}
			
			int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
			ArrayList<ArrayList<String>> choiceList=MeritDao.getcourseandmeritlistfordssc(es_id);
			if(!choiceList.isEmpty())
			{
				Mmap.put("choiceList", choiceList);
				Mmap.put("choiceListSize", choiceList.size());
			}
			
			Mmap.put("msg", msg);
			Mmap.put("getreasonlist", comm.getreasonlist(sessionFactory));
			return new ModelAndView("WithdrawalFormTiles");
		}

		@RequestMapping(value = "/getwithdrawreportReportDataList", method = RequestMethod.POST)
		 public @ResponseBody ArrayList<ArrayList<String>> getwithdrawreportReportDataList(int startPage,
				 int pageLength,String Search,String orderColunm,String orderType,String personal_no,HttpSession sessionUserId) 
			     throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, 
			     InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
			int es_id = Integer.parseInt(sessionUserId.getAttribute("es_id") == null ? "0": sessionUserId.getAttribute("es_id").toString());
		  return MeritDao.getwithdrawList(startPage,pageLength,Search,orderColunm,orderType,es_id,personal_no);
		}

		 
		 @RequestMapping(value = "/getwithdrawTotalCount", method = RequestMethod.POST)
		public @ResponseBody long getwithdrawTotalCount(HttpSession sessionUserId,String Search,String personal_no){
			 int es_id = Integer.parseInt(sessionUserId.getAttribute("es_id") == null ? "0": sessionUserId.getAttribute("es_id").toString());
			return MeritDao.getReportListwithdrawTotalCount(Search,es_id,personal_no);
		}
		 
		 
		//====================SAVE MODEL
			
			@RequestMapping(value = "/updatewithdrawal_Action" , method = RequestMethod.POST)
			public @ResponseBody  String updatewithdrawal_Action( HttpSession session,
					HttpServletRequest request, ModelMap model, String msg) {
				
				Session sessionHQL = sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction();
				
				String  reason=(request.getParameter("reason"));
					String  oid_hid=(request.getParameter("oid_hid"));
					String  oa_applicant_id_hid=(request.getParameter("oa_applicant_id_hid"));
					Date date = new Date();
					String username = session.getAttribute("username").toString();

					try {
						
						String hql = "update  QUALIFIED_OFFICERS set reason=:reason,status_id=:status_id,modified_by=:modified_by,modified_date=:modified_date where oid=:oid and oa_applicant_id=:oa_applicant_id ";
						Query query = sessionHQL.createQuery(hql);
						query.setParameter("reason", reason);
						query.setParameter("status_id", 6);
						query.setParameter("modified_by", username);
						query.setParameter("modified_date", date);
						
						query.setParameter("oid",Integer.parseInt(oid_hid));
						query.setParameter("oa_applicant_id",Integer.parseInt(oa_applicant_id_hid));
						 query.executeUpdate();
						 tx.commit();
						
						 sessionHQL.close();
						 msg="Update Successfully";
////						
					} catch (RuntimeException e) {
						try {
							tx.rollback();
							model.put("msg", "roll back transaction");
						} catch (RuntimeException rbe) {
							model.put("msg", "Couldn?t roll back transaction " + rbe);
						}
						throw e;
					} finally {
						if (sessionHQL != null) {
							sessionHQL.close();
						}
					}

				return msg;

				}
			
			
			
			//====================== Upgradation of merit
			
			// ===========================OPEN PAGE============================//
			@RequestMapping(value = "/upgradationmeritUrl", method = RequestMethod.GET)
			public ModelAndView upgradationmeritUrl( ModelMap Mmap, HttpSession session,
					@RequestParam(value = "msg", required = false) String msg) {
				
				int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
				
				String es_begindate = session.getAttribute("es_begin_dateshow") == null ? ""
						: session.getAttribute("es_begin_dateshow").toString();
				int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
						: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
				if (ec_exam_id == 3) {
					
					
				if (!es_begindate.equals("")) {
					Mmap.put("es_begindate", es_begindate);
					ArrayList<ArrayList<String>> choiceList=MeritDao.getcourseandmeritlistfordssc(es_id);
					if(!choiceList.isEmpty())
					{
						Mmap.put("choiceList", choiceList);
						Mmap.put("choiceListSize", choiceList.size());
					}
					Mmap.put("msg", msg);
					Mmap.put("getreasonlist", comm.getreasonlist(sessionFactory));
				}
				
			}
				
				return new ModelAndView("UpgradationmeritTiles");
			}
			
			
			@RequestMapping(value = "/getupgradationmeritreportReportDataList", method = RequestMethod.POST)
			 public @ResponseBody ArrayList<ArrayList<String>> getupgradationmeritreportReportDataList(int startPage,
					 int pageLength,String Search,String orderColunm,String orderType,String choice_type_id,HttpSession sessionUserId) 
				     throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, 
				     InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
				int es_id = Integer.parseInt(sessionUserId.getAttribute("es_id") == null ? "0": sessionUserId.getAttribute("es_id").toString());
			  return MeritDao.getupgradationmeritList(startPage,pageLength,Search,orderColunm,orderType,es_id,choice_type_id);
			}

			 
			 @RequestMapping(value = "/getupgradationmeritTotalCount", method = RequestMethod.POST)
			public @ResponseBody long getupgradationmeritTotalCount(HttpSession sessionUserId,String Search,String choice_type_id){
				 int es_id = Integer.parseInt(sessionUserId.getAttribute("es_id") == null ? "0": sessionUserId.getAttribute("es_id").toString());
				return MeritDao.getReportListupgradationmeritTotalCount(Search,es_id,choice_type_id);
			}
			 
			 @RequestMapping(value = "UpgradeMeritURL", method = RequestMethod.POST)
				public ModelAndView UpgradeMeritURL(ModelMap Mmap, HttpSession session,
						@RequestParam(value = "msg", required = false) String msg, String oid_hid1,String oa_applicant_id_hid1,String course_name1, HttpServletRequest request,
						String typeReport) {

					try {
						
						System.err.println("oid_hid1============"+oid_hid1);
						System.err.println("oa_applicant_id_hid1============"+oa_applicant_id_hid1);
						System.err.println("course_name1============"+course_name1);
						
						Session sessionHQL = this.sessionFactory.openSession();
						Transaction tx = sessionHQL.beginTransaction();
						int es_id = Integer
								.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

						Date date = new Date();
						String username = session.getAttribute("username").toString();

						
						
						String hql = "update  QUALIFIED_OFFICERS set status_id=:status_id,modified_by=:modified_by,modified_date=:modified_date where oid=:oid and oa_applicant_id=:oa_applicant_id ";
						Query query = sessionHQL.createQuery(hql);
						query.setParameter("status_id", 2);
						query.setParameter("modified_by", username);
						query.setParameter("modified_date", date);
						
						query.setParameter("oid",Integer.parseInt(oid_hid1));
						query.setParameter("oa_applicant_id",Integer.parseInt(oa_applicant_id_hid1));
						 query.executeUpdate();
						 tx.commit();
						 
						 
						 
						List<CHOICE_M>getChoiceId=comm.getChoicemstIdByChoiceName(sessionFactory, course_name1);
						if(!getChoiceId.isEmpty()) {
					
						int course_id= getChoiceId.get(0).getId();
						Session sessionHQL2 = this.sessionFactory.openSession();
						Transaction tx2 = sessionHQL2.beginTransaction();
						
						List<QUALIFIED_OFFICERS>getMeritNo=comm.getMeritIdbyEsID(sessionFactory,es_id,Integer.parseInt(oa_applicant_id_hid1));
						int MeriId= getMeritNo.get(0).getMeritid();
						QUALIFIED_OFFICERS qua= new QUALIFIED_OFFICERS();
						qua.setNominatedfor(course_name1);
						qua.setCourse_id(course_id);
						qua.setModified_by(username);
						qua.setModified_date(date);
						qua.setOa_applicant_id(Integer.parseInt(oa_applicant_id_hid1));
						qua.setStatus_id(1);
						qua.setEs_id(es_id);
						qua.setMeritid(MeriId);
						
						sessionHQL.save(qua);
						Mmap.put("msg", "Data Upgrated Succeessfully.");
						
						sessionHQL2.flush();
						sessionHQL2.clear();
						tx2.commit();
						sessionHQL2.close();
						
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
					

					return new ModelAndView("redirect:upgradationmeritUrl");
				}
}

