package com.BisagN.models.officers.masters;


import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "exam_code", uniqueConstraints = {
@UniqueConstraint(columnNames = "ec_exam_id"),})

public class EXAM_CODE_M {

      private int id;
      //private int ec_exam_id;
      private String ec_exam_name;
      private int ec_status_id;
      private String ec_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date ec_creation_date;
      private String ec_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date ec_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "ec_exam_id", unique = true, nullable = false)
      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      
      public String getEc_exam_name() {
           return ec_exam_name;
      }
      public void setEc_exam_name(String ec_exam_name) {
	  this.ec_exam_name = ec_exam_name;
      }
      public int getEc_status_id() {
           return ec_status_id;
      }
      public void setEc_status_id(int ec_status_id) {
	  this.ec_status_id = ec_status_id;
      }
      public String getEc_created_by() {
           return ec_created_by;
      }
      public void setEc_created_by(String ec_created_by) {
	  this.ec_created_by = ec_created_by;
      }
      public Date getEc_creation_date() {
           return ec_creation_date;
      }
      public void setEc_creation_date(Date ec_creation_date) {
	  this.ec_creation_date = ec_creation_date;
      }
      public String getEc_modified_by() {
           return ec_modified_by;
      }
      public void setEc_modified_by(String ec_modified_by) {
	  this.ec_modified_by = ec_modified_by;
      }
      public Date getEc_modification_date() {
           return ec_modification_date;
      }
      public void setEc_modification_date(Date ec_modification_date) {
	  this.ec_modification_date = ec_modification_date;
      }
}
