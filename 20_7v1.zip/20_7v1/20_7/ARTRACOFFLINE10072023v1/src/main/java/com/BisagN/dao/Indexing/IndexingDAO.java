package com.BisagN.dao.Indexing;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface IndexingDAO {

	public List<Map<String, Object>> GetCandidateDetailsforIndexing(String ic_number,int esid_es_id,int esid_sc_subject_id);
	public ArrayList<ArrayList<String>> GetIndexDetailsforBarcoding(String ic_number,int es_id);
	public ArrayList<ArrayList<String>> GetCountforIndexing(int es_id, int subject_id);
	public ArrayList<ArrayList<String>> getSubjectWiseIndxDetails(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,int es_id,String sc_subject_id,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	
	public long getTotalCountSubjectWiseIndxDetails(String Search,int es_id,String sc_subject_id);
	public ArrayList<ArrayList<String>> GetSubjectWiseIndexingDetails(int es_id, String sc_subject_id);
	public ArrayList<ArrayList<String>> GetLockUnlockIndexingDetails(int es_id) ;
	public ArrayList<ArrayList<String>> getSubSubjectDetails(String sc_subject_id) ;
	public ArrayList<ArrayList<String>> getRegisteredPartDData(int es_id, int sc_subject_id,String command,String personal_code,String center);


	public ArrayList<ArrayList<String>> GetBarcodcount(int oa_app_id,int es_id,int subject_id);
	public ArrayList<ArrayList<String>> getIndxSlipBundleCountByIbm(int subject_id,int es_id) ;
	public ArrayList<ArrayList<String>> GetcurrentBarcode(int es_id,int subject_id,String User);
	public ArrayList<ArrayList<String>> GetcountCL(int es_id,int subject_id);


}
