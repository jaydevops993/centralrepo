package com.BisagN.models.officers.trans;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "unfair_means", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class UNFAIR_MEANS_M {

      private int id;
      private int opd_personal_id;
      private int es_id;
      private int sc_subject_id;
      private String um_remarks;
      private int um_status_id;
      private String um_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date um_creation_date;
      private String um_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date um_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getOpd_personal_id() {
           return opd_personal_id;
      }
      public void setOpd_personal_id(int opd_personal_id) {
	  this.opd_personal_id = opd_personal_id;
      }
      public int getEs_id() {
           return es_id;
      }
      public void setEs_id(int es_id) {
	  this.es_id = es_id;
      }
      public int getSc_subject_id() {
           return sc_subject_id;
      }
      public void setSc_subject_id(int sc_subject_id) {
	  this.sc_subject_id = sc_subject_id;
      }
      public String getUm_remarks() {
           return um_remarks;
      }
      public void setUm_remarks(String um_remarks) {
	  this.um_remarks = um_remarks;
      }
      public int getUm_status_id() {
           return um_status_id;
      }
      public void setUm_status_id(int um_status_id) {
	  this.um_status_id = um_status_id;
      }
      public String getUm_created_by() {
           return um_created_by;
      }
      public void setUm_created_by(String um_created_by) {
	  this.um_created_by = um_created_by;
      }
      public Date getUm_creation_date() {
           return um_creation_date;
      }
      public void setUm_creation_date(Date um_creation_date) {
	  this.um_creation_date = um_creation_date;
      }
      public String getUm_modified_by() {
           return um_modified_by;
      }
      public void setUm_modified_by(String um_modified_by) {
	  this.um_modified_by = um_modified_by;
      }
      public Date getUm_modification_date() {
           return um_modification_date;
      }
      public void setUm_modification_date(Date um_modification_date) {
	  this.um_modification_date = um_modification_date;
      }
}
