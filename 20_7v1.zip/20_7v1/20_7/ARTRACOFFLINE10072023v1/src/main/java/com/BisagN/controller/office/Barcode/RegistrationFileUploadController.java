package com.BisagN.controller.office.Barcode;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormatSymbols;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.controller.office.others.Part_b_examinationController;
import com.BisagN.dao.Indexing.IndexingDAO;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_DETAILS;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_MASTER;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_DETAILS;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_MASTER;
import com.BisagN.models.officers.indexing.INDEXING_SETTING;
import com.BisagN.models.officers.indexing.INDEX_NO;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MANUAL;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MASTER;
import com.BisagN.models.officers.indexing.INDEX_SLIP_SCANNED;
import com.BisagN.models.officers.indexing.KITBAGMASTER;
import com.BisagN.models.officers.masters.ARM_CODES_M;
import com.BisagN.models.officers.masters.COMMAND_CODE_M;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class RegistrationFileUploadController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	CommonController comm;

	
	@Autowired
	IndexingDAO indexDao;	
	
	@Autowired
	Part_b_examinationController partb_con;

	@RequestMapping(value = "/RegisterationDataUploadUrl", method = RequestMethod.GET)
	public ModelAndView RegisterationDataUploadUrl(ModelMap Mmap, HttpServletRequest request, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg) {
	

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		if (es_id != 0) {

			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, es_id);
			String index_mode = UnlcokExmsch.get(0).getEs_index_mode();
			Mmap.put("index_mode", index_mode);
			Mmap.put("es_id", es_id);

	
		
			if(!UnlcokExmsch.isEmpty()) {
			int indx_esid = UnlcokExmsch.get(0).getEs_id();
			List<EXAM_SCHEDULE> getbegindate = comm.getUnlockExamSchedule(sessionFactory, es_id);
			
			Date begin_date= getbegindate.get(0).getEs_begin_date();
			System.err.println("begin_date=-============"+begin_date);
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			List<INDEXING_SETTING> bundledetails = comm.getbundledetailsforindexing(sessionFactory, es_id);
			
			int booklet_no=bundledetails.get(0).getIst_maxab_bundle();
			Mmap.put("booklet_no", booklet_no);
			
			
			int day = date.getDayOfMonth();
			String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

			String[] shortMonths = new DateFormatSymbols().getShortMonths();
			

			Month month = date.getMonth();
			int year = date.getYear();
			String begindateShow = day + " " + month + " " + year;

			Mmap.put("begindateShow", begindateShow);

			Mmap.put("esid_es_id", es_id);

			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
					: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
			int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
			if (esid_sc_subject_id != 0) {
				

				List<SUBJECT_CODE_M> ActiveSubName = comm.getsubjectIdbysubname(sessionFactory, esid_sc_subject_id,
						ec_exam_id);

				Mmap.put("ActiveSub", ActiveSubName.get(0).getSc_subject_name());

			
			Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL(sessionFactory));
			Mmap.put("msg", msg);
		}
			
			int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
			
			if (esid_sub_subject_id != 0) {
				List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
				String sub_subject_name=SubSubject.get(0).getSub_subject();
				Mmap.put("sub_subject_name", sub_subject_name);
			}
			System.err.println("esid_sub_subject_id========="+esid_sub_subject_id);
			}	
		}
		Mmap.put("msg", msg);
		return new ModelAndView("Registrationfileupload_tiles");
	}
	
//	
//	//Download DEMO EXCEL
//	@RequestMapping(value = "/DemoIndexingCandidateExcel", method = RequestMethod.POST)
//	public ModelAndView DemoIndexingCandidateExcel(HttpServletRequest request,ModelMap model,HttpSession session,String typeReport1) {
//		
//	ArrayList<ArrayList<String>> listexport=new ArrayList<ArrayList<String>>();
//	List<String> TH = new ArrayList<String>();
//	    TH.add("Sr_no");
//	    TH.add("UNIQUE_NO");
//	    TH.add("ARMY_NO");
//		TH.add("MONTH_YEAR");
//		TH.add("CENTER_CODE");
//		TH.add("COMMAND");
//		TH.add("SUBJECT");
//		
//	
//		
//
//		String Heading = "\n";
//		String username = session.getAttribute("username").toString();
//		return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList", listexport);
//	}
	// UPLOAD CANDIDATE DATA
		@RequestMapping(value = "/UploadIndexingDataAction", method = RequestMethod.POST)
		public ModelAndView UploadIndexingDataAction(HttpServletRequest request, ModelMap model, HttpSession session,RedirectAttributes ra,
				@RequestParam(value = "fileUpload", required = false) MultipartFile fileUpload) {

			
			ArrayList<ArrayList<String>> listerror=new ArrayList<ArrayList<String>>();
			
			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			
		
				if(fileUpload.isEmpty()) {
					 ra.addAttribute("msg","Please Upload Copy Of File Upload");
						  return new ModelAndView("redirect:RegisterationDataUploadUrl");
					  }


			try {
				
				Date date = new Date();
				int es_id = Integer
						.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
				
				
				File file = new File(comm.fileupload2(fileUpload.getBytes(), fileUpload.getOriginalFilename(), "doc_contract",""));
				FileInputStream fis = new FileInputStream(file);
				@SuppressWarnings("resource")
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sheet = wb.getSheetAt(0);
				Row row_head = sheet.getRow(0);
				
				
				
				
				
			
				
				
			
				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
					
					

				
				ArrayList<String> listData = new ArrayList<String>();
			
				
				Row row = sheet.getRow(i);
				
				String errormsg= "";
				String application_no = "";
				String month_year = "";
				String gender="";
				String mobile_no="";
				String  centreid="";
				String command="";
				String unit="";
				
				if (row.getCell(0) == null) {
					break;
				}
				
				
				for (int j=1; j < 8; j++) {

					Cell cell = row.getCell(j);
					
					

					String value = "";
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						value = cell.getStringCellValue();
						break;
					case Cell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							value = String.valueOf(cell.getDateCellValue());
						} else {
							value = String.valueOf((long) cell.getNumericCellValue());
						}
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						value = String.valueOf(cell.getBooleanCellValue());
						break;
					default:
					}
				
			
					
					if (row_head.getCell(j).getStringCellValue().equals("APPLICATION_NO")) {
					
						application_no=value;
					}
					if (row_head.getCell(j).getStringCellValue ().equals("MONTH_YEAR")) {
						month_year=value;
						
					}
					if (row_head.getCell(j).getStringCellValue().equals("CENTER_CODE")) {
						centreid=value;
				     }
					
					if (row_head.getCell(j).getStringCellValue().equals("COMMAND")) {
						command=value;
					}
					
					if (row_head.getCell(j).getStringCellValue().equals("GENDER")) {
						gender=value;
					}
					if (row_head.getCell(j).getStringCellValue().equals("MOBILE_NO")) {
						mobile_no=value;
						
						
					}
					
					
					if (row_head.getCell(j).getStringCellValue().equals("UNIT")) {
						unit=value;
						
						
					}
					
					
					
					
				}
				
				List<OFFICER_APPLICATION_M> opdpers_id = comm.getOpdIdbyOappId(sessionFactory,
						Integer.parseInt(application_no), es_id);
				
				int opd_pers_id = opdpers_id.get(0).getOpd_personal_id(); 
				
				System.err.println("opd_pers_id========"+opd_pers_id);
				
				 String es_year= month_year.split("-")[1];
				  	
				    String es_begindate = session.getAttribute("es_begin_date") == "" ? "": session.getAttribute("es_begin_date").toString();
			      String es_begindate_year= es_begindate.split("-")[0];
			  	
			  
			    System.err.println("unit============="+unit);
			    
			    Session sessionHQL1 = this.sessionFactory.openSession();
				Transaction tx1 = sessionHQL1.beginTransaction();
				
			  	if(es_begindate_year.equals(es_year)) {
			  		
		  		
						
						
			  		Query qry = sessionHQL1.createQuery("update OFFICER_APPLICATION_M  set oa_center_granted=:oa_center_granted where oa_application_id=:oa_application_id and es_id=:es_id");
					qry.setParameter("oa_center_granted",Integer.parseInt(centreid));
					qry.setParameter("oa_application_id",Integer.parseInt(application_no));
					qry.setParameter("es_id",es_id);
					qry.executeUpdate();
					
					
					Query qry1 = sessionHQL1.createQuery("update OFFICER_PERSONAL_DETAILS_M set cc_command_id=:cc_command_id,opd_gender=:opd_gender, mobile_no=:mobile_no,opd_unit=:opd_unit  where opd_personal_id=:opd_personal_id");
					qry1.setParameter("cc_command_id",Integer.parseInt(command));
					qry1.setParameter("opd_gender", Integer.parseInt(gender));
					qry1.setParameter("mobile_no", mobile_no);
					qry1.setParameter("opd_unit", unit);
					qry1.setParameter("opd_personal_id",opd_pers_id);
					qry1.executeUpdate();
			  		
				
			
					tx1.commit();
					//sessionHQL.close();

					ra.addAttribute("msg","Data Saved Successfully");
					
					
					
//					}else {
//
//						 listData.add(pers_code);
//						 listData.add(month_year);
//						 listData.add(centreid);
//						 listData.add(command);
//						 listData.add(gender);
//						 listData.add(mobile_no);
//						
//						
//						
//						 listData.add("Register Data Already Exist");
//					
//						
//					}
			  			
			}else {
				
				 listData.add(application_no);
				 listData.add(month_year);
				 listData.add(centreid);
				 listData.add(command);
				 listData.add(gender);
				 listData.add(mobile_no);
				
				 listData.add("Exam Schedule Not Matched with Current Exam Schedule");
			
			}
				 	
				
		
			  	if(!listData.isEmpty()) {
					listerror.add(listData);
				}
			}
			
				tx.commit();
			model.put("errorlist", listerror);
			model.put("errorlistsize", listerror.size());

				
			
				
			} catch (Exception e) {
				tx.rollback();
				e.printStackTrace();
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}
			ra.addFlashAttribute("errorlist",listerror);
			ra.addFlashAttribute("errorlistsize",listerror.size());
			return new ModelAndView("redirect:RegisterationDataUploadUrl");
		}
}
