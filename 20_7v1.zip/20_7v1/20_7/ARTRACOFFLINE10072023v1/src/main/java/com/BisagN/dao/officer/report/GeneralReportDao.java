package com.BisagN.dao.officer.report;

import java.util.ArrayList;

public interface GeneralReportDao {

	
	public ArrayList<ArrayList<String>> getComChanceGenReport(String Year,int exam_id);
	public ArrayList<ArrayList<String>> getAttemptInExamReport(int es_year);
	public ArrayList<ArrayList<String>> getUnfairmeansData(String exam_id, int Year);
}
