package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "status_description", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class STATUS_DESCRIPTION_M {

      private int id;
      private int sd_id;
      private int sd_description;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getSd_id() {
           return sd_id;
      }
      public void setSd_id(int sd_id) {
	  this.sd_id = sd_id;
      }
      public int getSd_description() {
           return sd_description;
      }
      public void setSd_description(int sd_description) {
	  this.sd_description = sd_description;
      }
}
