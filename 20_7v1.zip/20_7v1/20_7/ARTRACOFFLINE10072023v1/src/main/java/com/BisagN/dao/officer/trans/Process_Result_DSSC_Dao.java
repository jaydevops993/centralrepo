package com.BisagN.dao.officer.trans;

import java.util.List;

public interface Process_Result_DSSC_Dao {

	List getSubjectListWithCutOff(int es_id);

	void generateMerit(String[] cols);

}
