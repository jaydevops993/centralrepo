package com.BisagN.dao.officer.report;

import java.util.ArrayList;

public interface DSSC_DSTSC_REPORTDAO {
	
	
	public ArrayList<ArrayList<String>> getWithDrawalsDSSC(int es_id);
	public ArrayList<ArrayList<String>> getJcCourseCandidateWiseDetails();
	public ArrayList<ArrayList<String>> getCompensatoryChnaceReport(String es_year);
	public ArrayList<ArrayList<String>> PartAbsenteesForDSSC_DSTSC(int es_id) ;
	public ArrayList<ArrayList<String>> getArmwiseAnalysisReport(int es_id);
	public ArrayList<ArrayList<String>> getcompatativemeritlistReport(int es_id);
	public ArrayList<ArrayList<String>> getnominateddssclistReport(int es_id);
	public ArrayList<ArrayList<String>> getnominateddstsclistReport(int es_id);
	public ArrayList<ArrayList<String>> getreserveofficeristReport(int es_id);
	public ArrayList<ArrayList<String>> getfailofficeristReport(int es_id) ;
	public ArrayList<ArrayList<String>> getALMC_ISCmeritlistReport(int es_id);
	public ArrayList<ArrayList<String>> getACRndFdMarksReport(int es_id);

}
