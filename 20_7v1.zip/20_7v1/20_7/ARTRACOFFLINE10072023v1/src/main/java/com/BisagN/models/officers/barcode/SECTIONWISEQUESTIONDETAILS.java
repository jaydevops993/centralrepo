package com.BisagN.models.officers.barcode;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;




@Entity
@Table(name = "sectionwisequestiondetails", uniqueConstraints = {
@UniqueConstraint(columnNames = "sqd_id"),})
public class SECTIONWISEQUESTIONDETAILS {

	
	private int sqd_id;
	
	private int sqd_ssd_id;
	private String sqd_sectionno;
	private int sqd_totalquestions;
	private int sqd_markablequestions;
	private int sqd_userid;
	private int sqd_marksperquestion;
	private Date sqd_createddate;
	private Date sqd_updatedate;
	
	@Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "sqd_id", unique = true, nullable = false)
	public int getSqd_id() {
		return sqd_id;
	}
	public void setSqd_id(int sqd_id) {
		this.sqd_id = sqd_id;
	}
	public int getSqd_ssd_id() {
		return sqd_ssd_id;
	}
	public void setSqd_ssd_id(int sqd_ssd_id) {
		this.sqd_ssd_id = sqd_ssd_id;
	}
	public String getSqd_sectionno() {
		return sqd_sectionno;
	}
	public void setSqd_sectionno(String sqd_sectionno) {
		this.sqd_sectionno = sqd_sectionno;
	}
	public int getSqd_totalquestions() {
		return sqd_totalquestions;
	}
	public void setSqd_totalquestions(int sqd_totalquestions) {
		this.sqd_totalquestions = sqd_totalquestions;
	}
	public int getSqd_markablequestions() {
		return sqd_markablequestions;
	}
	public void setSqd_markablequestions(int sqd_markablequestions) {
		this.sqd_markablequestions = sqd_markablequestions;
	}
	public int getSqd_userid() {
		return sqd_userid;
	}
	public void setSqd_userid(int sqd_userid) {
		this.sqd_userid = sqd_userid;
	}
	public int getSqd_marksperquestion() {
		return sqd_marksperquestion;
	}
	public void setSqd_marksperquestion(int sqd_marksperquestion) {
		this.sqd_marksperquestion = sqd_marksperquestion;
	}
	public Date getSqd_createddate() {
		return sqd_createddate;
	}
	public void setSqd_createddate(Date sqd_createddate) {
		this.sqd_createddate = sqd_createddate;
	}
	public Date getSqd_updatedate() {
		return sqd_updatedate;
	}
	public void setSqd_updatedate(Date sqd_updatedate) {
		this.sqd_updatedate = sqd_updatedate;
	}
	
	
	  
}
