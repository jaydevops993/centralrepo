package com.BisagN.controller.office_DSSC_MeritRerport;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.BisagN.controller.office_DSSC_MeritRerport.MeritDSSCReportForIndexPdf_controller.PageNumeration;
//import com.BisagN.controller.office_DSSC_Report.ACRndFDMarksReportController.PageNumeration;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

public class ALMCISC_Report_controllerPdf extends AbstractPdfView {

	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	String exam="";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	int totalRecords=0;

	private static final DecimalFormat decfor = new DecimalFormat("0.00");  

	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public ALMCISC_Report_controllerPdf(String Type, List<String> TH, String Heading, String username,String exam) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
		this.exam = exam;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		document.setPageSize(PageSize.A4.rotate()); 
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
		Font fontTableHeadingSubMainHead1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 1);
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.BOX);
		table.setWidthPercentage(100);
		
		
		PdfPTable table1 = new PdfPTable(1);
		table1.getDefaultCell().setBorder(Rectangle.BOX);
		table1.setWidthPercentage(100);

		
		PdfPTable table4_4 = new PdfPTable(1);
		table4_4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table4_4.setWidthPercentage(100);

		PdfPTable tabledata4_4 = new PdfPTable(1);
		tabledata4_4.setWidths(new int[] { 7 });
		tabledata4_4.setWidthPercentage(100 / 3.5f);
		tabledata4_4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata4_4.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata4_4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

//		Paragraph head45_21 = new Paragraph("Appendix 'E' Contd.", fontTableHeadingMainHead_l);
//		Paragraph head6122 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
//		Paragraph head632 = new Paragraph("Letter No:" + letter_no, fontTableHeadingMainHead_l);
//		Paragraph head642 = new Paragraph("Dated:" + letter_date1 + ")", fontTableHeadingMainHead_l);
//		tabledata4_4.addCell(head45_21);
//		tabledata4_4.addCell(head6122);
//		tabledata4_4.addCell(head632);
//		tabledata4_4.addCell(head642);

		Chunk ALMC_heading = new Chunk("LIST OF NOMINATED OFFICERS FOR ALMC/ISC \n \n \n", fontTableHeading1);
		ALMC_heading.setUnderline(0.1f, -2f);
		Paragraph ALMC_paragraph = new Paragraph(ALMC_heading);
		ALMC_paragraph.setFont(fontTableHeading1);
		ALMC_paragraph.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader4_ALMC = new PdfPTable(1);
		tableheader4_ALMC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader4_ALMC.setWidthPercentage(100);
		tableheader4_ALMC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader4_ALMC.addCell(ALMC_paragraph);
//		tableheader4_ALMC.addCell(new Paragraph(
//				"THE UNDER MENTIONED OFFICER LISTED IN THEIR ORDER OF SENIORITY BY ARMS AND \n  "
//						+ "         SERVICES HAVE BEEN NOMINATED TO ATTEND THE DEFENCE SERVICES TECHNICAL STAFF COLLEGE COURSE COMMENCING-5 \n\n\n",
//				fontTableHeadingSubMainHeadNew_2));

		PdfPTable tabledata41_ALMC = new PdfPTable(5);
//		tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tabledata41_ALMC.setWidths(new int[] { 2, 3, 3, 10, 5 });
		tabledata41_ALMC.setWidthPercentage(100);
		tabledata41_ALMC.setHeaderRows(1);

		
		tabledata41_ALMC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata41_ALMC.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);

		Paragraph a_C22 = new Paragraph("SER NO", fontTableHeadingdata);
		Paragraph f_C22 = new Paragraph("PERS NO", fontTableHeadingdata);
		Paragraph b_C22 = new Paragraph("RANK", fontTableHeadingdata);
		Paragraph c_C22 = new Paragraph("NAME", fontTableHeadingdata);
		Paragraph d_C22 = new Paragraph("UNIT", fontTableHeadingdata);

		PdfPCell blank_cella1_C122 = new PdfPCell(a_C22);
		blank_cella1_C122.setPadding(5);
		blank_cella1_C122.setBorder(Rectangle.BOTTOM);

		blank_cella1_C122.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella2_C12 = new PdfPCell(f_C22);
		blank_cella2_C12.setPadding(5);
		blank_cella2_C12.setBorder(Rectangle.BOTTOM);

		blank_cella2_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella3_C12 = new PdfPCell(b_C22);
		blank_cella3_C12.setPadding(5);
		blank_cella3_C12.setBorder(Rectangle.BOTTOM);

		blank_cella3_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella4_C12 = new PdfPCell(c_C22);
		blank_cella4_C12.setPadding(5);
		blank_cella4_C12.setBorder(Rectangle.BOTTOM);

		blank_cella4_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella5_C12 = new PdfPCell(d_C22);
		blank_cella5_C12.setPadding(5);
		blank_cella5_C12.setBorder(Rectangle.BOTTOM);

		blank_cella5_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		tabledata41_ALMC.addCell(blank_cella1_C122);
		tabledata41_ALMC.addCell(blank_cella2_C12);
		tabledata41_ALMC.addCell(blank_cella3_C12);
		tabledata41_ALMC.addCell(blank_cella4_C12);
		tabledata41_ALMC.addCell(blank_cella5_C12);

		String arm = "";
		ArrayList<List<String>> getALMCISCList = (ArrayList<List<String>>) model.get("userList");
		
		System.out.println("getALMCISCList+++++++"+ getALMCISCList);

		for (int i = 0; i < getALMCISCList.size(); i++) {

			List<String> l = getALMCISCList.get(i);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingSubMainHead);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingSubMainHead);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingSubMainHead);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingSubMainHead);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingSubMainHead);
			Paragraph blank6 = new Paragraph(l.get(7), fontTableHeadingdata);

			PdfPCell cellar = new PdfPCell();

			cellar.setFixedHeight(20f);
			if (i % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}

			if (!l.get(7).equals(arm)) {
				arm = l.get(7);
				PdfPCell cellarow = new PdfPCell();
				cellarow.setColspan(5);
				cellarow.setPhrase(blank6);
				cellarow.setBorder(Rectangle.NO_BORDER);
				cellarow.setPadding(2);
				cellarow.setPaddingBottom(8f);
				cellarow.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata41_ALMC.addCell(cellarow);
			}
			cellar.setPhrase(blank1);
			cellar.setPadding(2);
			cellar.setBorder(Rectangle.NO_BORDER);

			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_ALMC.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_ALMC.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_ALMC.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata41_ALMC.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_ALMC.addCell(cellar);

//			tabledata41_ALMC.addCell(blank1);
//			tabledata41_ALMC.addCell(blank2);
//			tabledata41_ALMC.addCell(blank3);
//			tabledata41_ALMC.addCell(blank4);
//			tabledata41_ALMC.addCell(blank5);

		}
		
		 PageNumeration event = new PageNumeration(arg2);
			arg2.setPageEvent(event);
			document.setPageCount(1);	

//		PdfPCell cell1236_C122;
//		cell1236_C122 = new PdfPCell();
//		cell1236_C122.addElement(tabledata4_4);
//		cell1236_C122.addElement(new Paragraph("\n"));
//		cell1236_C122.addElement(tableheader4_ALMC);
//		cell1236_C122.addElement(tabledata41_ALMC);
//		cell1236_C122.setBorder(0);
			
			table1.setSplitLate(false);
			PdfPCell cell12356;
			cell12356 = new PdfPCell();
			cell12356.addElement(tableheader4_ALMC);
//			cell12356.addElement(tabledata13);
			cell12356.setBorder(Rectangle.NO_BORDER);

			table1.addCell(cell12356);

			PdfPCell cell1235612;
			cell1235612 = new PdfPCell();
//			cell1235612.addElement(tableheader1);
			cell1235612.setBorder(Rectangle.BOX);
			cell1235612.addElement(tabledata41_ALMC);
		

				table1.addCell(cell1235612);
		
		
		document.add(table1);
		super.buildPdfMetadata(model, document, request);
	}
	
	class PageNumeration extends PdfPageEventHelper {
		PdfTemplate total;
		PdfTemplate total1;

		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				total1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {
			// total = writer.getDirectContent().createTemplate(30, 12);
		}

		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			String ip = "";
			try {
				table.setWidths(new int[] { 15,6,1});  
				table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				Date now = new Date();
				String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
				table.addCell(dateString);  //table.addCell("TOTAL SHEET :");
				
				
				PdfPCell cell1 = new PdfPCell(Image.getInstance(total1));
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			//	table.addCell(cell1);
								
			
				//String watermark = " Generated by "+username+" on "+dateString +" with IP " +ip ;
				
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Pages %d of", writer.getPageNumber()));
				//table.addCell("Month :");
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.NO_BORDER);				
				table.addCell(cell);
				
				table.writeSelectedRows(0, -1, document.leftMargin(), document.topMargin() + 0, writer.getDirectContent());
			} catch (DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT, new Phrase(String.valueOf(writer.getPageNumber() - 1)), 2, 2, 0);
			ColumnText.showTextAligned(total1, Element.ALIGN_LEFT, new Phrase(String.valueOf(totalRecords)), 2, 2, 0);
		}
	}
	

}
