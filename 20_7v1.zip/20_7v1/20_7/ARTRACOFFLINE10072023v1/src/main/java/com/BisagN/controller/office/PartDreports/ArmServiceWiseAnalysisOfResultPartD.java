package com.BisagN.controller.office.PartDreports;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.StyleConstants.ColorConstants;

import org.apache.poi.hssf.record.RightMarginRecord;
import org.apache.poi.ss.usermodel.Color;
import org.apache.poi.xwpf.usermodel.TextAlignment;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.ListItem;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;

public class ArmServiceWiseAnalysisOfResultPartD extends AbstractPdfView {


	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	

	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";
	
	public ArmServiceWiseAnalysisOfResultPartD(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		document.setPageSize(PageSize.A4.rotate());
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		
		response.setContentType("application/pdf");
    	response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");

		
		
		
		
		//Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
	    Font fontTableHeadingMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
	    Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 1);
	    Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
	   //Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
		//Font fontTableHeadingSubMainHead = FontFactory.getFont(FontFactory.TIMES_BOLD, 12);
		
		String es_year =  (String) model.get("es_year");
//		String letter_no =  (String) model.get("letter_no1");
//		String letter_date1 =  (String) model.get("letter_date1");
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		
		

		
		 
		 
		 
		Chunk chunk = new Chunk();

		Chunk underline1 = new Chunk("ARMY TRAINING COMMAND (EXAM SEC)" +"\n"+ "PROMOTION EXAMINATION PART D-"+es_year+"" +"\n"+ "ARM/SERVICES WISE ANALYSIS OF RESULTS" , fontTableHeadingMainHead);
		underline1.setUnderline(0.1f, -2f);
		
		
		Chunk glue = new Chunk(new VerticalPositionMark());
		
		Phrase phh2 = new Phrase(underline1);
		phh2.add("\n");
		phh2.add("\n");
		
		
		Paragraph cell12 = new Paragraph(phh2);
		cell12.setAlignment(Element.ALIGN_LEFT);
		
		
		
		
		
		
		
		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell12);
			
		PdfPTable tabledata = new PdfPTable(13);
		tabledata.setWidths(new int[] {6,5,6,5,5,5,5,5,5,5,5,5,5});
		tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
		tabledata.setWidthPercentage(100);
		
		
	
		Paragraph A1 = new Paragraph("Arm/Service",fontTableHeadingSubMainHead);
		Paragraph B1 = new Paragraph("Total Candidates Appd",fontTableHeadingSubMainHead);
		Paragraph C1 = new Paragraph("Passed Whole Exam",fontTableHeadingSubMainHead);
		Paragraph D1 = new Paragraph("Partially Passed in One/More Subjects",fontTableHeadingSubMainHead);
		Paragraph E1 = new Paragraph("Failed in All Appd Subjects",fontTableHeadingSubMainHead);

		
		
		
		
		 PdfPCell blank_cella;
		 blank_cella = new PdfPCell();
		 blank_cella.setRowspan(3);
		 blank_cella.addElement(A1);
		 blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
		 tabledata.addCell(blank_cella);
		 

		 //PdfPCell blank_cellb;
		// blank_cellb = new PdfPCell();
		 PdfPCell blank_cellb=new PdfPCell(B1);
		 blank_cellb.setRowspan(2);
		 blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
		 //blank_cellb.addElement(B1);
		 tabledata.addCell(blank_cellb);
		 
		 
		 
		 
		 //PdfPCell blank_cellc;
		 //blank_cellc = new PdfPCell();
		 PdfPCell blank_cellc=new PdfPCell(C1);
		 blank_cellc.setRowspan(2);
		 //blank_cellc.addElement(C1);
		 blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
		 tabledata.addCell(blank_cellc);
		 
		 
		// PdfPCell blank_celld;
		 //blank_celld = new PdfPCell();
		 PdfPCell blank_celld=new PdfPCell(D1);
		 blank_celld.setRowspan(2);
		 //blank_celld.addElement(D1);
		 blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
		 tabledata.addCell(blank_celld);
		 

		 //PdfPCell blank_celle;
		// blank_celle = new PdfPCell();
		 PdfPCell blank_celle=new PdfPCell(E1);
		 blank_celle.setRowspan(2);
		// blank_celle.addElement(E1);
		 blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
		 tabledata.addCell(blank_celle);
		 
		 Paragraph F1 = new Paragraph("Appd in Whole Exam(All 5 Subjects)",fontTableHeadingSubMainHead);
		 PdfPCell blank_cellf=new PdfPCell(F1);
		 blank_cellf.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cellf.setColspan(8);
		 
		 

		 
		
		tabledata.addCell(blank_cellf);

		
		 ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");

		Paragraph F2 = new Paragraph("Total Candidates Appd ",fontTableHeadingSubMainHead);
		Paragraph G2 = new Paragraph("All",fontTableHeadingSubMainHead);
		Paragraph R2 = new Paragraph("Five",fontTableHeadingSubMainHead);
		Paragraph H2 = new Paragraph("Four",fontTableHeadingSubMainHead);
		Paragraph I2 = new Paragraph("Three",fontTableHeadingSubMainHead);
		Paragraph J2 = new Paragraph("Two",fontTableHeadingSubMainHead);
		Paragraph K2 = new Paragraph("One",fontTableHeadingSubMainHead);
		Paragraph L2 = new Paragraph("None",fontTableHeadingSubMainHead);
		
		
		
		
		 
		 
		 
		 
		tabledata.addCell(F2);
		tabledata.addCell(G2);
		tabledata.addCell(R2);
		tabledata.addCell(H2);
		tabledata.addCell(I2);
		tabledata.addCell(J2);
		tabledata.addCell(K2);
		tabledata.addCell(L2);
		
		
		
		
		
		Paragraph B3 = new Paragraph("No",fontTableHeadingSubMainHead);
		PdfPCell cellB3=new PdfPCell(B3);
		cellB3.setHorizontalAlignment(Element.ALIGN_CENTER);
		
		
		Paragraph C3 = new Paragraph("No      %",fontTableHeadingSubMainHead);
		Paragraph D3 = new Paragraph("No      %",fontTableHeadingSubMainHead);
		Paragraph E3 = new Paragraph("No      %",fontTableHeadingSubMainHead);
		Paragraph F3 = new Paragraph("No",fontTableHeadingSubMainHead);
		Paragraph G3 = new Paragraph("No      %",fontTableHeadingSubMainHead);
		Paragraph H3 = new Paragraph("No      %",fontTableHeadingSubMainHead);
		Paragraph I3 = new Paragraph("No      %",fontTableHeadingSubMainHead);
		Paragraph J3 = new Paragraph("No      %",fontTableHeadingSubMainHead);
		Paragraph K3 = new Paragraph("No      %",fontTableHeadingSubMainHead);
		Paragraph L3 = new Paragraph("No      %",fontTableHeadingSubMainHead);
		Paragraph P3 = new Paragraph("No      %",fontTableHeadingSubMainHead);
		Paragraph o3 = new Paragraph("No      %",fontTableHeadingSubMainHead);
		
		
		
		tabledata.addCell(cellB3);
		tabledata.addCell(C3);
		tabledata.addCell(D3);
		tabledata.addCell(E3);
		tabledata.addCell(F3);
		tabledata.addCell(G3);
		tabledata.addCell(H3);
		tabledata.addCell(I3);
		tabledata.addCell(J3);
		tabledata.addCell(K3);
		tabledata.addCell(L3);
		tabledata.addCell(P3);
			 
		
		//data bind
		//System.err.println("arm=================="+list);
		
		 for(int i=0;i<list.size();i++)
		 {

			 List<String> l = list.get(i);
		 Paragraph blank1 = new Paragraph(l.get(0),fontTableHeadingdata);
		 
		
		 Paragraph blank2 = new Paragraph(l.get(1),fontTableHeadingdata);
		  
		
		 Paragraph blank3 = new Paragraph(l.get(2)+getSpace((14-(l.get(2)+l.get(3)).length()))+l.get(3),fontTableHeadingdata);
		 

	
		 Paragraph blank4 = new Paragraph(l.get(4)+getSpace((14-(l.get(4)+l.get(5)).length()))+l.get(5),fontTableHeadingdata);
		 Paragraph blank5 = new Paragraph(l.get(6)+getSpace((14-(l.get(6)+l.get(7)).length()))+l.get(7),fontTableHeadingdata);
		 
		 
		 Paragraph blank6 = new Paragraph(l.get(8),fontTableHeadingdata);
		 
		 Paragraph blank7 = new Paragraph(l.get(9)+getSpace((14-(l.get(9)+l.get(10)).length()))+l.get(10),fontTableHeadingdata);
		 Paragraph blank8 = new Paragraph(l.get(11)+getSpace((14-(l.get(11)+l.get(12)).length()))+l.get(12),fontTableHeadingdata);
		 Paragraph blank9 = new Paragraph(l.get(13)+getSpace((14-(l.get(13)+l.get(14)).length()))+l.get(14),fontTableHeadingdata);
		 Paragraph blank10 = new Paragraph(l.get(15)+getSpace((14-(l.get(15)+l.get(16)).length()))+l.get(16),fontTableHeadingdata);
		 Paragraph blank11 = new Paragraph(l.get(17)+getSpace((14-(l.get(17)+l.get(18)).length()))+l.get(18),fontTableHeadingdata);
		 Paragraph blank12 = new Paragraph(l.get(19)+getSpace((14-(l.get(19)+l.get(20)).length()))+l.get(20),fontTableHeadingdata);
		 Paragraph blank13 = new Paragraph(l.get(21)+getSpace((14-(l.get(21)+l.get(22)).length()))+l.get(22),fontTableHeadingdata);
		 
		 
		
			 
	   
			PdfPCell cell1 = new PdfPCell();
			if(i % 2 == 0){
				 cell1.setBackgroundColor(java.awt.Color.lightGray);
			}
			cell1.setPhrase(blank1);
			 if(i==list.size()-1) {
				 cell1.setHorizontalAlignment(Element.ALIGN_CENTER); 
			 }
			
			
			tabledata.addCell(cell1);
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell1.setPhrase(blank2);
			tabledata.addCell(cell1);
			 //----original code
			
			
			cell1.setPhrase(blank3);
			cell1.setHorizontalAlignment(Element.ALIGN_RIGHT);
			tabledata.addCell(cell1);
			 
			 
			cell1.setPhrase(blank4);
			 tabledata.addCell(cell1);
			cell1.setPhrase(blank5);
			 tabledata.addCell(cell1);
			cell1.setPhrase(blank6);
			cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
			 tabledata.addCell(cell1);
			cell1.setPhrase(blank7);
			cell1.setHorizontalAlignment(Element.ALIGN_RIGHT);
			 tabledata.addCell(cell1);
			cell1.setPhrase(blank8);
			 tabledata.addCell(cell1);
			cell1.setPhrase(blank9);
			 tabledata.addCell(cell1);
			cell1.setPhrase(blank10);
			 tabledata.addCell(cell1);
			 cell1.setPhrase(blank11);
			 tabledata.addCell(cell1);
			 cell1.setPhrase(blank12);
			 tabledata.addCell(cell1);
			 cell1.setPhrase(blank13);
			 tabledata.addCell(cell1);
		 }

	
		 PdfPTable tabledataend = new PdfPTable(1);
		 tabledataend.setWidths(new int[] {5});
		 tabledataend.setWidthPercentage(100);
		 tabledataend.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		 tabledataend.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			 
		PdfPCell cell123;
		cell123 = new PdfPCell();
		cell123.addElement(tableheader);
		cell123.addElement(tabledata);
		cell123.setBorder(0);
		table.addCell(cell123);
	
	document.add(table);
	
	super.buildPdfMetadata(model, document, request);
	}

	String pagNum = "";
	public void onEndPage(PdfWriter writer, Document document) {
		PdfPTable table = new PdfPTable(1);
		try {

			table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
			table.setLockedWidth(true);
			table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			
			if ((writer.getPageNumber() - 2) > 0) {
				pagNum = String.valueOf((writer.getPageNumber() - 1));
			}
							
			

			
			PdfPCell cell1 = new PdfPCell(new Paragraph(pagNum));
			cell1.setBorder(Rectangle.NO_BORDER);
			cell1.setHorizontalAlignment(Element.ALIGN_TOP);
			table.addCell(cell1);

			table.writeSelectedRows(0, -1, document.leftMargin() + 360, document.topMargin() + 565,
			writer.getDirectContent());
			Font fontTableHeadingdataforFooter = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 0);
			 PdfContentByte cb = writer.getDirectContent();
			 
			 
			 
			 table.writeSelectedRows(0, -1, document.leftMargin() + 360, document.topMargin() + 565,
						writer.getDirectContent());
				 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("Appd : Appeared", writer.getPageNumber()),fontTableHeadingdataforFooter),document.left(),document.bottom(), 0);
//			
			 
//           if(page >= table_from6 & page <=table_to6 ) {
//				 
//				 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("hiiiiii", writer.getPageNumber()),fontTableHeadingdataforFooter),document.left(),document.bottom(), 0);
//			 }
			 /*
//			 * if (Integer.parseInt(String.valueOf(writer.getPageNumber())) > 2) { page++; }
//			 */
		} catch (Exception de) {
			throw new ExceptionConverter(de);
		}
	}
	
	
	
	
	
	public String getSpace(int no){
		//System.out.println("NO : "+ no);
		String space = "";
		if(no == 1) {space = " ";}
		if(no == 2) {space = "  ";}
		if(no == 3) {space = "   ";}
		if(no == 4) {space = "    ";}
		if(no == 5) {space = "     ";}
		if(no == 6) {space = "      ";}
		if(no == 7) {space = "       ";}
		if(no == 8) {space = "        ";}
		if(no == 9) {space = "          ";}
		if(no == 10) {space = "           ";}
		if(no == 11) {space = "           ";}
		if(no == 12) {space = "            ";}
		if(no == 13) {space = "             ";}
		if(no == 14) {space = "              ";}
		if(no == 15) {space = "               ";}
		if(no == 16) {space = "                ";}
		if(no == 17) {space = "                 ";}
		if(no == 18) {space = "                  ";}
		if(no == 19) {space = "                   ";}
		if(no == 20) {space = "                    ";}
		return space;
	}

}
