package com.BisagN.dao.officer.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;


@Service
public class SupplymentryDaoImpl implements SupplymentryDAO {

	@Autowired
	private DataSource dataSource;
	
	CommonController comm = new CommonController();
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	public boolean checkIsIntegerValue(String Search) {
		return Search.matches("[0-9]+");
	}
	
	
	public ArrayList<ArrayList<String>> getSupplymntryDetails(int startPage,String pageLength,String Search,String orderColunm,
			String orderType,int es_id,String opd_personal_id, HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, 
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{

		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search);

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
String q1= "";

if(!opd_personal_id.equals("")) {
	
	q1+= "and lower(vw.opc_personal_code) = ?";
			
}

		try {
			conn = dataSource.getConnection();

			q = "select ROW_NUMBER() OVER(order by ab.id) as sr_no,ab.id, vw.opc_personal_code,vw.opd_officer_name, vw.ac_arm_description,sc.sc_subject_name,ofa.oa_application_id as oa_app_id  from answer_book ab\n"
					+ "inner join officer_application ofa ON ofa.oa_application_id = ab.oa_application_id\n"
					+ "inner join vw_personal_details vw on vw.opd_personal_id = ofa.opd_personal_id\n"
					+ "inner join subject_code sc ON sc.sc_subject_id = ab.sc_subject_id\n"
					+ "where ofa.es_id=? and ab.ab_second_entry !=0 "+q1+""  + SearchValue ;
			
			

			PreparedStatement stmt = conn.prepareStatement(q);

			stmt = setQueryWhereClause_SQL(stmt, Search);
			stmt.setInt(1, es_id);

			if(!opd_personal_id.equals("")) {
				
				stmt.setString(2, opd_personal_id.toLowerCase());
						
			}
			
			System.err.println("stmt========bbbb======"+stmt);

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("sr_no"));//2
				list.add(rs.getString("opc_personal_code"));//3
				list.add(rs.getString("opd_officer_name"));//4	
				list.add(rs.getString("ac_arm_description"));//6
				list.add(rs.getString("sc_subject_name"));//7		
			
				
				
				
				String enckey = "commonPwdEncKeys";
				Cipher c = hex_asciiDao.EncryptionSHA256Algo(session, enckey);
				String EncryptedPk = new String(
						Base64.encodeBase64(c.doFinal(rs.getString("oa_app_id").toString().getBytes())));
				
				
				
				
				
				String Print = "onclick=\"  if (confirm('Are you sure you want to Print?') ){printData('" + EncryptedPk
						+ "')}else{ return false;}\"";
				String printButton = "<i class='action_icons action_view' " + Print + " title='Release Data'></i>";
				
				
				
				

				
			
          
				list.add(printButton);
				list.add(rs.getString("oa_app_id"));//7		
				alist.add(list);
//				System.err.println("list---------"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	public long getSupplymntryDetailsCount(String Search,int es_id,String opd_personal_id) {
		
		
		String SearchValue = GenerateQueryWhereClause_SQL(Search);
		int total = 0;
		Connection conn = null;
		try {
			
			String q = "";
			String q1= "";
			if(!opd_personal_id.equals("")) {
				
				q1+= "and lower(vw.opc_personal_code) = ?";
						
			}
			conn = dataSource.getConnection();
			
			
		q="select count(*) from(select ROW_NUMBER() OVER(order by ab.id) as sr_no,ab.id, vw.opc_personal_code,vw.opd_officer_name, vw.ac_arm_description,sc.sc_subject_name,ofa.oa_application_id from answer_book ab\n"
				+ "inner join officer_application ofa ON ofa.oa_application_id = ab.oa_application_id\n"
				+ "inner join vw_personal_details vw on vw.opd_personal_id = ofa.opd_personal_id\n"
				+ "inner join subject_code sc ON sc.sc_subject_id = ab.sc_subject_id\n"
				+ "where ofa.es_id=? and ab.ab_second_entry !=0 "+q1+""+SearchValue+") as a ";
			
			PreparedStatement stmt = conn.prepareStatement(q);
			
			stmt = setQueryWhereClause_SQL(stmt, Search);
			stmt.setInt(1, es_id);
			if(!opd_personal_id.equals("")) {
				
				stmt.setString(2, opd_personal_id.toLowerCase());
						
			}
			
			
				
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				total = rs.getInt(1);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search) {
		String SearchValue = "";
		if (!Search.equals("")) {
			Search = Search.toLowerCase();
			SearchValue = " and ( ";
			if (checkIsIntegerValue(Search)) {
				SearchValue += " area_id=? or ";
			}
//			SearchValue += " lower(area_name) like ? )";
			SearchValue += " lower(vw.opc_personal_code) like ? or lower(vw.opd_officer_name) like ? or lower(vw.ac_arm_description) like ? or lower(sc.sc_subject_name) like ? )";
		}
		return SearchValue;
	}


	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt, String Search) {
		int flag = 1;
		try {
			if (!Search.equals("")) {
				
				if (checkIsIntegerValue(Search)) {
					flag += 1;
					stmt.setInt(flag, Integer.parseInt(Search));
				}
				
				flag += 1;
				stmt.setString(flag, "%" + Search.toLowerCase() + "%");
				
				flag += 1;
				stmt.setString(flag, "%" + Search.toLowerCase() + "%");
				
				flag += 1;
				stmt.setString(flag, "%" + Search.toLowerCase() + "%");
				
				flag += 1;
				stmt.setString(flag, "%" + Search.toLowerCase() + "%");
				
				flag += 1;
				stmt.setString(flag, "%" + Search.toLowerCase() + "%");
				
				
			}
		} catch (Exception e) {
		}
		return stmt;
	}
	
	public ArrayList<ArrayList<String>> getPartPassedandFailuresForSulymntryRpt(String es_year,String oa_application_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		try {
			List<SUBJECT_CODE_M> sublist= comm.getsubjectlist(sessionFactory, 1);
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String qbuilder="";
			
			String whr="";
			
			
			if(!oa_application_id.equals("")) {
				
			whr+="and cy.oa_application_id=?";
			}


			
	q="select pfd.ser_no, cy.opc_personal_code||''||cy.opc_suffix_code as opc_personal_code,cy.opd_officer_name,cy.opc_suffix_code,cy.opd_officer_name,\n"
			+ "rc.rc_rank_name, ar.ac_arm_description,ar.ac_arm_code,cy.opd_personal_id,\n"
			+ "	case when cy.ta_a is null and py.ta_a is null then 'ABS' when cy.ta_a is null and py.ta_a is not null then py.ta_a else cy.ta_a end as ta_a,\n"
			+ "		case when cy.ta_l is null and py.ta_l is null then 'ABS' when cy.ta_l is null and py.ta_l is not null then py.ta_l else cy.ta_l end as ta_l,\n"
			+ "			case when cy.ta_h is null and py.ta_h is null then 'ABS' when cy.ta_h is null and py.ta_h is not null then py.ta_h else cy.ta_h end as ta_h,\n"
			+ "	case when cy.ta_c is null and py.ta_c is null then 'ABS' when cy.ta_c is null and py.ta_c is not null then py.ta_c else cy.ta_c end as ta_c,\n"
			+ "	case when cy.ta_t is null and py.ta_t is null then 'ABS' when cy.ta_t is null and py.ta_t is not null then py.ta_t else cy.ta_t end as ta_t,\n"
			+ "	string_agg(getsubjectnamefromcode(pfd.pbda_code,1),',') as yettopass\n"
			+ "from\n"
			+ "(select opc.opc_personal_code,opc.opc_suffix_code,opd.opd_officer_name,opd.opd_partb,opd.pbda_sub_code,opd.opd_personal_id,oa.oa_application_id,\n"
			+ "string_agg(case when ab.ab_first_entry>= 200 then 'NP' else coalesce(ab.ab_first_entry::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 51::text) as ta_a,\n"
			+ "string_agg(case when ab.ab_first_entry>= 200 then 'NP' else coalesce(ab.ab_first_entry::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 52::text) as ta_l,\n"
			+ "string_agg(case when ab.ab_first_entry>= 200 then 'NP' else coalesce(ab.ab_first_entry::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 53::text) as ta_h,\n"
			+ "string_agg(case when ab.ab_first_entry>= 200 then 'NP' else coalesce(ab.ab_first_entry::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 54::text) as ta_c,\n"
			+ "string_agg(case when ab.ab_first_entry>= 200 then 'NP' else coalesce(ab.ab_first_entry::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 55::text) as ta_t \n"
			+ "from officer_application oa\n"
			+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
			+ "left join exam_schedule es on es.es_id = oa.es_id\n"
			+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id  and opd.opd_status_id != 0\n"
			+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
			+ "where  oa.oa_status_id=1 and extract (year from es.es_begin_date) = "+es_year+" and es.ec_exam_id=1 \n"
			+ "group by  opc.opc_personal_code,opc.opc_suffix_code,opd.opd_officer_name,opd.opd_partb,opd.pbda_sub_code,opd.opd_personal_id,oa.oa_application_id) as cy\n"
			+ "left join \n"
			+ "(select opc.opc_personal_code,oa.oa_application_id,\n"
			+ "string_agg(case when ab.ab_first_entry>= 200 then 'PP' else coalesce(ab.ab_first_entry::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 51::text) as ta_a,\n"
			+ "string_agg(case when ab.ab_first_entry>= 200 then 'PP' else coalesce(ab.ab_first_entry::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 52::text) as ta_l,\n"
			+ "string_agg(case when ab.ab_first_entry>= 200 then 'PP' else coalesce(ab.ab_first_entry::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 53::text) as ta_h,\n"
			+ "string_agg(case when ab.ab_first_entry>= 200 then 'PP' else coalesce(ab.ab_first_entry::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 54::text) as ta_c,\n"
			+ "string_agg(case when ab.ab_first_entry>= 200 then 'PP' else coalesce(ab.ab_first_entry::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 55::text) as ta_t \n"
			+ "from officer_application oa\n"
			+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
			+ "left join exam_schedule es on es.es_id = oa.es_id\n"
			+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id\n"
			+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
			+ "where   extract (year from es.es_begin_date) != 2022 and es.ec_exam_id=1 and (opd.opd_partb =0 or opd.opd_partb ="+es_year+") \n"
			+ "group by opc.opc_personal_code,oa.oa_application_id\n"
			+ "order by 1,2) py on cy.opc_personal_code=py.opc_personal_code\n"
			+ "left join officer_rank ofr on ofr.opd_personal_id = cy.opd_personal_id\n"
			+ "left join officer_arm ofar on ofar.opd_personal_id = cy.opd_personal_id\n"
			+ "full join tb_partpass_fullpass_dtl pfd on pfd.opd_personal_id = cy.opd_personal_id\n"
			+ "inner join rank_code rc on rc.rc_rank_id = ofr.rc_rank_id\n"
			+ "inner join arm_codes ar on ar.ac_arm_id = ofar.ac_arm_id\n"
			+ " where  cy.oa_application_id=? and pfd.result=0 \n"
			
			+ "group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14\n"
			+ "order by 1\n";
			
			stmt = conn.prepareStatement(q);
			if(!oa_application_id.equals("")) {
				stmt.setInt(1,Integer.parseInt(oa_application_id));
			}
			System.out.println("stmt ----------fff--------"+stmt);
			ResultSet rs = stmt.executeQuery();
	int i=1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				list.add(String.valueOf(i));
				list.add(Data);
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("ac_arm_description")+"("+(rs.getString("ac_arm_code")+")"));
				for (SUBJECT_CODE_M subject_CODE_M : sublist) {
					list.add(rs.getString("ta_"+subject_CODE_M.getSc_form_caption().toLowerCase()));			
				}
				list.add(rs.getString("yettopass"));
				
				
				list.add(rs.getString("opd_personal_id"));
				list.add(rs.getString("ser_no"));
				
				
				
				list.add(Data);
				alist.add(list);
				i++;

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
public ArrayList<ArrayList<String>> getoldSerno(int es_id,int repo_no,int oapp_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";

		

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

//			q = "select mrw.* from mv_result_withheld mrw where mrw.es_id=?";
			
			q="select ser_no from tb_partpass_fullpass_dtl where es_id=? and result="+repo_no+" and oa_app_id=?  ";

		
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			stmt.setInt(2, oapp_id);
			ResultSet rs = stmt.executeQuery();
System.err.println("ols-----------"+stmt);
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ser_no"));
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
}
