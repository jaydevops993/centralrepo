package com.BisagN.dao.officer.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;



@Service
public class Dssc_tsoc_applicationDAOImpl implements Dssc_tsoc_applicationDAO {

	@Autowired
	private DataSource dataSource;
//         public void setDataSource(DataSource dataSource) {
//	       this.dataSource = dataSource;
//         }
 HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
 
 CommonController comm= new CommonController();


 @Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

  public boolean checkIsIntegerValue(String Search) {
	return Search.matches("[0-9]+");
}


  public ArrayList<ArrayList<String>> getexportDSSCTSOCexmCandidateReport(int startPage, String pageLength, String Search,
			String orderColunm, String orderType, String exam_schedule_dt2, String min_year2,String es_consider_date1,int es_id,String table,String btn_value, String partb_status,String partd_status,String dssc_month,String dssc_chance,
			String es_year,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	  
	  
	  
		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search);
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String q1 = "";
		String q2 = "";
		String q3 = "";
		String q4 = "";
		
		if(es_consider_date1.equals("opd_date_of_seniority")) {
			
			q1= "opd_date_of_seniority";
		}
		if(es_consider_date1.equals("opd_date_of_comm")) {
			q1="opd_date_of_comm";
		}
		
		
		System.err.println("min_year2-------------"+partb_status);
		System.err.println("min_year2-------------"+partd_status);
		if(btn_value.equals("ADMIT CARDS YET TO BE GENERATED")) {
			
			q2="and adm.admit_card_no = '0'";
		}
	
		if(partb_status != null ) {

	
	q3+="and vw.opd_partb !=0";
     }
if(partd_status != null ) {
	
	q4+="and vw.opd_partd !=0";
}
		try {
			conn = dataSource.getConnection();
			
			
			
			q="SELECT ROW_NUMBER() OVER(order by vw.opd_personal_id) as sr_no, ofa.oa_application_id,  \n"
					+ "vw.opc_personal_code,vw.opc_suffix_code, vw.opd_officer_name,vw.ac_arm_description,TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm ,\n"
					+ "vw.rc_rank_name, TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority , vw.opd_personal_id,\n"
					+ "date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) as total_service,\n"
					+ "vw.ac_arm_code,vw.opd_type_of_entry,vw.opd_partd,count(vw.opd_personal_id) filter (where ofa.in_index_id != 0 and a.ec_exam_id=3 ) as dssc_count,adm.admit_card_no,TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob\n"
					+ "from vw_personal_details vw	left join officer_application ofa on ofa.opd_personal_id = vw.opd_personal_id  and ofa.es_id="+es_id+"	\n"
					+ "inner join (select distinct string_agg(sc.sc_subject_code::text,',')  as subcode,sum(sc.sc_subject_code) as sub_sum,\n"
					+ "sct.arm_id,sc.ec_exam_id from subject_code sc\n"
					+ "inner join subject_code_child_tbl sct on sc.sc_subject_id=sct.sub_id group by 3,4) as a on a.arm_id=vw.ac_arm_id and a.ec_exam_id=3 \n"
					+ "left join dssc_admit_card_tbl adm on adm.opd_personal_id = vw.opd_personal_id \n"
					+ "left join dssc_compens_chance_new dsch on dsch.opd_personal_id = ofa.opd_personal_id and dsch.dcc_compens_year="+es_year+"\n"
					+ "where vw.opd_status_id='1' and vw.opd_isactive='yes'   "+q3+"  "+q4+"   \n"
					+ "and  case when vw.ct_comm_type='SHORT SERVICE' then date_part('year',age('"+exam_schedule_dt2+"',"+q1+" + interval '"+dssc_month+" months')) >= "+min_year2+" \n"
					+ "else date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) >= "+min_year2+"  end group by 2,3,4,5,6,7,8,9,10,11,12,13,14,16,17 \n"
					+ "                      having (count(*) filter (where ofa.in_index_id != 0))<="+dssc_chance+" "+q2+"     "+SearchValue+"   \n"
							+ "ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage;
			

			PreparedStatement stmt = conn.prepareStatement(q);

			stmt = setQueryWhereClause_SQL(stmt, Search);

				System.err.println("dsccc============"+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				if(table.equals("excelL")) {
				list.add(rs.getString("admit_card_no"));//0
				
				}
				if(!table.equals("excelL")) {
				list.add(rs.getString("sr_no"));//0
				}

                String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
       			String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));
				list.add(opc_code);	

				list.add(rs.getString("rc_rank_name"));//7	
				list.add(rs.getString("opd_officer_name"));//2
				list.add(rs.getString("ac_arm_description"));//3

				if(table.equals("excelL")) {
					list.add(rs.getString("opd_dob"));//10
				}
				list.add(rs.getString("opd_date_of_comm"));//5	
					
				
				list.add(rs.getString("opd_date_of_seniority"));//8
				
				
				
				
				
				list.add(rs.getString("opd_partd"));//10
				list.add(rs.getString("dssc_count"));//10
				if(!table.equals("excelL")) {
				list.add(rs.getString("opd_type_of_entry"));//10
				list.add(rs.getString("opc_personal_code"));
				}
			
				alist.add(list);
				System.err.println("list==========="+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	public long getexportDSSCTSOCCandidatereportTotalCount(String Search, String exam_schedule_dt2,String min_year2,String es_consider_date1,int es_id,String btn_value,String partb_status,String partd_status,String dssc_month,String dssc_chance,String es_year) {
	String SearchValue = GenerateQueryWhereClause_SQL(Search);
	int total = 0;
	String q = null;
	Connection conn = null;
	try {
		String q1 = "";
		String q2 = "";
		String q3 = "";
		String q4 = "";
		
	if(es_consider_date1.equals("opd_date_of_seniority")) {
			
			q1= "opd_date_of_seniority";
		}
		if(es_consider_date1.equals("opd_date_of_comm")) {
			q1="opd_date_of_comm";
		}
		
		if(btn_value.equals("ADMIT CARDS YET TO BE GENERATED")) {
			
			q2="and adm.admit_card_no = '0'";
		}
		
if(partb_status != null ) {
			
			q4+="and vw.opd_partb !=0";
		}
		
		if(partd_status != null ) {
			
			q4+="and vw.opd_partd !=0";
		}
		System.err.println("btn_value=============="+btn_value);
		
		conn = dataSource.getConnection();
		q ="select count(*) from (SELECT ROW_NUMBER() OVER(order by vw.opd_personal_id) as sr_no, ofa.oa_application_id,  \n"
				+ "vw.opc_personal_code,vw.opc_suffix_code, vw.opd_officer_name,vw.ac_arm_description,TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm ,\n"
				+ "vw.rc_rank_name, TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority , vw.opd_personal_id,\n"
				+ "date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) as total_service,\n"
				+ "vw.ac_arm_code,vw.opd_type_of_entry,vw.opd_partd,count(vw.opd_personal_id) filter (where ofa.in_index_id != 0 and a.ec_exam_id=3 ) as dssc_count,adm.admit_card_no,TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob\n"
				+ "from vw_personal_details vw	left join officer_application ofa on ofa.opd_personal_id = vw.opd_personal_id  and ofa.es_id="+es_id+"	\n"
				+ "inner join (select distinct string_agg(sc.sc_subject_code::text,',')  as subcode,sum(sc.sc_subject_code) as sub_sum,\n"
				+ "sct.arm_id,sc.ec_exam_id from subject_code sc\n"
				+ "inner join subject_code_child_tbl sct on sc.sc_subject_id=sct.sub_id group by 3,4) as a on a.arm_id=vw.ac_arm_id and a.ec_exam_id=3 \n"
				+ "left join dssc_admit_card_tbl adm on adm.opd_personal_id = vw.opd_personal_id \n"
				+ "left join dssc_compens_chance_new dsch on dsch.opd_personal_id = ofa.opd_personal_id and dsch.dcc_compens_year="+es_year+"\n"
				+ "where vw.opd_status_id='1' and vw.opd_isactive='yes' "+q3+"  "+q4+"  \n"
				+ "and  case when vw.ct_comm_type='SHORT SERVICE' then date_part('year',age('"+exam_schedule_dt2+"',"+q1+" + interval '"+dssc_month+" months')) >= "+min_year2+" \n"
				+ "else date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) >= "+min_year2+"  end group by 2,3,4,5,6,7,8,9,10,11,12,13,14,16,17 having (count(*) filter (where ofa.in_index_id != 0))<="+dssc_chance+" "+q2+"    ) ab WHERE 1=1  "+SearchValue ;
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereClause_SQL(stmt,Search);
		System.out.println("stmt===gggg===="+stmt);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search) {
	String SearchValue ="";
	if(!Search.equals("")) {
	Search = Search.toLowerCase();
//		SearchValue =" and ( ";
//
//
//		SearchValue +=" lower(opd_unit) like ? or"
//			+" lower(opc_personal_code) like ? or "
//				+ "lower(opd_officer_name) like ? or to_char(opd_date_of_seniority,'dd-MM-yyyy') like ? or  "
//				+ " lower(ac_arm_description) like ? )";
	
	
	SearchValue ="and (  lower(opc_personal_code) like ? or lower(opd_officer_name) like ? \n"
			+ "or   lower(ac_arm_description) like ? or   lower(opd_type_of_entry) like ? or lower(rc_rank_name) like ?)"
			+ "or  lower(TO_CHAR(opd_date_of_seniority,'DD/MM/YYYY'))  like ? or lower( TO_CHAR(opd_date_of_comm,'DD/MM/YYYY')) like ?  ";
	
	
	
	}
	return SearchValue;

	}


	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search) {
	int flag = 0;
	try {
	if(!Search.equals("")) {
			
			flag += 1;
			Search=comm.getSearchIcNumberwithoutZero(Search);

			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			
//			flag += 1;
		
			
		}
	}catch (Exception e) {}
	return stmt;
	}
   public String Deletedssc_tsoc_application(String deleteid,HttpSession session1) {

      	Session session = this.sessionFactory.openSession();
      	Transaction tx = session.beginTransaction();
      	String enckey = "commonPwdEncKeys";
		    String DcryptedPk = hex_asciiDao.decrypt((String) deleteid,enckey,session1);
	      	String hql = "Delete from DSSC_TSOC_APPLICATION_M  where cast(id as string) = :deleteid";
          Query q = session.createQuery(hql).setString("deleteid",DcryptedPk);
      	int rowCount = q.executeUpdate();
      	tx.commit();
          session.close();
	    if(rowCount > 0) {
 			return "Deleted Successfully";
  		}else {
  		return "Deleted not Successfully";
   	}
  	}
   
   public List<Map<String, Object>> getCourseDetails(String course_name) {

		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		String q = "";
		String q1 = "";
		
		System.err.println("course_name==========="+course_name);

		try {
			
			conn = dataSource.getConnection();
			
			if(!course_name.equals("")) {
		         q1+=" where choice_id=?";
			}
			q="select choice_type_id,name,choice_id from course_master "+q1+"";
			
			

			PreparedStatement stmt = conn.prepareStatement(q);
			
			if(!course_name.equals("")) {
				stmt.setInt(1,Integer.parseInt(course_name));
			}
			
		
			ResultSet rs = stmt.executeQuery();
			System.err.println("us============"+stmt);
			ResultSetMetaData metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();
			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
					columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
				list.add(columns);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}

		return list;
	}
   public ArrayList<ArrayList<String>> getManualDSSCRulesappdetails(int opd_personal_id, String exmsch_dt,String exam_schedule_dt, String min_year, String dscc_schedule_dt) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		String whr = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			
		
			
			q="select * from vw_personal_details vw where opd_personal_id=? and vw.opd_partd != 0 \n"
					+ "and case when vw.ct_comm_type='SHORT SERVICE' then\n"
					+ "date_part('year',age('"+dscc_schedule_dt+"',"+exam_schedule_dt+" + interval '3 months')) >= 2 \n"
					+ "else date_part('year',age('"+dscc_schedule_dt+"',"+exam_schedule_dt+" )) >= 2 end";
			
			stmt = conn.prepareStatement(q);
			int i=0;
		
			stmt.setInt(1, opd_personal_id);
			System.err.println("center=============="+stmt);
			
			ResultSet rs = stmt.executeQuery();
			
		
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("opc_personal_code"));//1
				list.add(rs.getString("opd_officer_name"));//1
				
				
				
				alist.add(list);
				
				
			}

			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
   
   public ArrayList<ArrayList<String>> getDSSCDSTSCexmApplicationReport(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,String pers_no, String pers_name, String center, String opd_arm_service,int es_id,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	   

		if (!pers_no.equals("")) {
			
			
			//using commaon controller searchwithout zero
			pers_no=comm.getSearchIcNumberwithoutZero(pers_no);
			 System.err.println("opc_code==========="+pers_no);
				 
		}
		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		
		
		String SearchValue = GenerateQueryWhereClause_SQL(Search,pers_no,pers_name,center,opd_arm_service,es_id);
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		  
		

		try {
			conn = dataSource.getConnection();

			q = "select ROW_NUMBER() OVER(order by dsscapp.id) as sr_no, dsscapp.id, vpd.opc_personal_code,vpd.opc_suffix_code, vpd.ac_arm_description, vpd.opd_officer_name \n"
					+ "from dssc_tsoc_application dsscapp\n"
					+ "inner join officer_application ofa on ofa.oa_application_id = dsscapp.oa_application_id\n"
					+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
					+ "where ofa.es_id=? and ofa.oa_status_id=1  " + SearchValue + " "
							+ "ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
			

			PreparedStatement stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			
			stmt = setQueryWhereClause_SQL(stmt, Search,pers_no,pers_name,center,opd_arm_service,es_id);
			
			
			System.err.println("k  0108============"+stmt);
			ResultSet rs = stmt.executeQuery();
		
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("sr_no"));//0
				
				String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
	     		String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));			
				list.add(opc_code);//1
				
//				list.add(rs.getString("opc_personal_code"));//1
				list.add(rs.getString("opd_officer_name"));//2
				list.add(rs.getString("ac_arm_description"));//3
				
				
				String enckey = "commonPwdEncKeys";
				Cipher c = hex_asciiDao.EncryptionSHA256Algo(session, enckey);
				String EncryptedPk = new String(
						Base64.encodeBase64(c.doFinal(rs.getString("id").toString().getBytes())));
				
				String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('" + EncryptedPk
						+ "')}else{ return false;}\"";
				String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>";

//				String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deletePartBData('"
//						+ EncryptedPk + "')}else{ return false;}\"";
//				String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>";
//				
				
				list.add(updateButton);
				alist.add(list);
				

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	public long getDSSCDSTSCexmApplicationReportTotalCount(String Search,String pers_no, String pers_name,String center, String opd_arm_service,int es_id) {

		String SearchValue = GenerateQueryWhereClause_SQL(Search,pers_no,pers_name,center,opd_arm_service,es_id);
	int total = 0;
	String q = null;
	Connection conn = null;
	try {
		
		

		conn = dataSource.getConnection();
		q ="select count(*) from (select ROW_NUMBER() OVER(order by dsscapp.id) as sr_no, dsscapp.id,vpd.opc_personal_code, vpd.ac_arm_description, vpd.opd_officer_name \n"
				+ "from dssc_tsoc_application dsscapp\n"
				+ "inner join officer_application ofa on ofa.oa_application_id = dsscapp.oa_application_id\n"
				+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
				+ "where ofa.es_id=? and ofa.oa_status_id=1   " +SearchValue +"   ) ab " ;
		
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereClause_SQL(stmt,Search,pers_no,pers_name,center,opd_arm_service,es_id);

		stmt.setInt(1,es_id);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search, String pers_no, String pers_name, String center,
			String opd_arm_service,int es_id) {
		String SearchValue = "";

		try {
		
			
		if (!pers_no.equals("") && pers_no != "" && pers_no != null) {
			SearchValue = "and lower(vpd.opc_personal_code::text) like ?";
		}

		if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
			SearchValue = "and lower(vpd.opd_officer_name) like ? ";
		}

			if (!opd_arm_service.equals("0") && opd_arm_service != "0") {
				SearchValue = "and vpd.ac_arm_id=?";
			}
		
			if (!center.equals("0") && center != "0") {
				SearchValue = "and ofa.oa_center_opted=?";
			}
			
			if (!Search.equals("")) {
				Search = Search.toLowerCase();
				SearchValue = " and ( ";
				SearchValue += " lower(opc_personal_code) like ?  or lower(opd_officer_name) like ? or lower(ac_arm_description) like ?)";
						
			}
		} catch (Exception e) {
			
		}

		return SearchValue;

	}

	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,String pers_no, String pers_name,String center, 
			String opd_arm_service,int es_id) {
		int flag = 1;
		
	try {
		
		if (!pers_no.equals("") && pers_no != "" && pers_no != null) {
			flag += 1;
//			stmt.setInt(flag, Integer.parseInt(pers_no));
			stmt.setString(flag,"%"+ pers_no.toLowerCase() + "%");

			
		}
		
		if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
			flag += 1;
			stmt.setString(flag,"%"+ pers_name.toLowerCase() + "%");
		}
			
			if (!opd_arm_service.equals("0") && opd_arm_service != "0") {
				flag += 1;
				stmt.setInt(flag,Integer.parseInt(opd_arm_service) );
			}
			
			if (!center.equals("0") && center != "0") {
				flag += 1;
				stmt.setInt(flag, Integer.parseInt(center));
			}

		if(!Search.equals("")) {
			
			flag += 1;
			Search=comm.getSearchIcNumberwithoutZero(Search);
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				
			
		}
	}catch (Exception e) {
		
	}
	return stmt;
	}
   
}
