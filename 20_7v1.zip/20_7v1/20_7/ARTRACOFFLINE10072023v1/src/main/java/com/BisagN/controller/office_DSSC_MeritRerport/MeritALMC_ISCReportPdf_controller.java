package com.BisagN.controller.office_DSSC_MeritRerport;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.BisagN.controller.office_DSSC_MeritRerport.MeritDSSCReportPdf_controller.PageNumeration;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

public class MeritALMC_ISCReportPdf_controller extends AbstractPdfView {

	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	String exam="";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	int totalRecords=0;
	private static final DecimalFormat decfor = new DecimalFormat("0.00");  

	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public MeritALMC_ISCReportPdf_controller(String Type, List<String> TH, String Heading, String username,String exam) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
		this.exam = exam;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		
		document.setPageSize(PageSize.LEGAL.rotate()); 
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 7, 1);
		Font fontTableHeadingSubMainHead1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		
	PdfPTable table6 = new PdfPTable(1);
	table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	table6.setWidthPercentage(100);


	PdfPTable tabledata6 = new PdfPTable(1);
	tabledata6.setWidths(new int[] {5});
	tabledata6.setWidthPercentage(100/ 3.5f);
	tabledata6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata6.setHorizontalAlignment(Element.ALIGN_RIGHT);
	tabledata6.getDefaultCell().setBorder(Rectangle.NO_BORDER);


	 
	


		Chunk underline6 = new Chunk("PERSONAL DETAILS MARKS AND MERIT LIST "+exam +"", fontTableHeadingSubMainHead1);

		underline6.setUnderline(0.1f, -2f);

	Phrase phh6 = new Phrase(underline6);

	phh6.add("\n");
	phh6.add("\n");
	phh6.setFont(fontTableHeadingSubMainHead);






	Paragraph cell61 = new Paragraph(phh6);
	cell61.setAlignment(Element.ALIGN_LEFT);


	PdfPTable tableheader6 = new PdfPTable(1);
	tableheader6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	tableheader6.setWidthPercentage(100);
	tableheader6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	tableheader6.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	tableheader6.addCell(cell61);






	 
	 PdfPTable tabledata61 = new PdfPTable(21);
		

	 tabledata61.setWidths(new int[] {4,5,4,21,6,3,3,3,3,3,3,5,5,5,5,4,4,4,4,4,4});
	 tabledata61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	 tabledata61.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	 tabledata61.setWidthPercentage(100);
	 tabledata61.setHeaderRows(2);
	 tabledata61.getDefaultCell().setBorder( Rectangle.NO_BORDER );
		

		Paragraph a6 = new Paragraph("SER NO",fontTableHeadingSubMainHead);
		Paragraph b6 = new Paragraph("PERS NO",fontTableHeadingSubMainHead);
		Paragraph c6 = new Paragraph("RANK",fontTableHeadingSubMainHead);
		Paragraph d6 = new Paragraph("NAME",fontTableHeadingSubMainHead);
		Paragraph e6 = new Paragraph("ARM/SERVICE",fontTableHeadingSubMainHead);
//		Paragraph e6 = new Paragraph("ARM",fontTableHeadingSubMainHead);
		Paragraph f6 = new Paragraph("TAC A",fontTableHeadingSubMainHead);
		Paragraph f7 = new Paragraph("TAC B",fontTableHeadingSubMainHead);
		Paragraph f8 = new Paragraph("A & L",fontTableHeadingSubMainHead);	
		Paragraph f9 = new Paragraph("CA",fontTableHeadingSubMainHead);
		Paragraph f10 = new Paragraph("SMT",fontTableHeadingSubMainHead);
		Paragraph f11 = new Paragraph("MH",fontTableHeadingSubMainHead);
		Paragraph f12 = new Paragraph("SCORE",fontTableHeadingSubMainHead);
		Paragraph f13 = new Paragraph("CAREER",fontTableHeadingSubMainHead);
		Paragraph f14 = new Paragraph("OVERALL",fontTableHeadingSubMainHead);
		Paragraph f15 = new Paragraph("CH 1",fontTableHeadingSubMainHead);
		Paragraph f16 = new Paragraph("CH 2",fontTableHeadingSubMainHead);
		Paragraph f17 = new Paragraph("CH 3",fontTableHeadingSubMainHead);
		Paragraph f18 = new Paragraph("CH 4",fontTableHeadingSubMainHead);
		Paragraph f19 = new Paragraph("MERIT",fontTableHeadingSubMainHead);
		Paragraph k66 = new Paragraph("OVERALL",fontTableHeadingSubMainHead);
		Paragraph l66 = new Paragraph("STATUS",fontTableHeadingSubMainHead);
		
		
		
		PdfPCell blank_cella1_C11 = new PdfPCell(a6);
//		blank_cella1_C11.setRowspan(2);
		blank_cella1_C11.setBorder( Rectangle.NO_BORDER );
		blank_cella1_C11.setPaddingLeft(5f);
		
		PdfPCell blank_cella1_C12 = new PdfPCell(b6);
//		blank_cella1_C12.setRowspan(2);
		blank_cella1_C12.setBorder( Rectangle.NO_BORDER );
		blank_cella1_C12.setPaddingLeft(8f);
		
		PdfPCell blank_cella1_C13 = new PdfPCell(c6);
//		blank_cella1_C13.setRowspan(2);
		blank_cella1_C13.setBorder( Rectangle.NO_BORDER );
		blank_cella1_C13.setPaddingLeft(8f);
		
		
		PdfPCell blank_cella1_C14 = new PdfPCell(d6);
//		blank_cella1_C14.setRowspan(2);
		blank_cella1_C14.setBorder( Rectangle.NO_BORDER );
		blank_cella1_C14.setPaddingLeft(80f);
		
		
		PdfPCell blank_cella1_C15 = new PdfPCell(e6);
//		blank_cella1_C15.setRowspan(2);
		blank_cella1_C15.setBorder( Rectangle.NO_BORDER );
		blank_cella1_C15.setPaddingLeft(4f);
//		PdfPCell blank_cella1_C16 = new PdfPCell(f6);
//		blank_cella1_C16.setColspan(6);
		
		
		PdfPCell blank_cella1_f12 = new PdfPCell(f12);
		blank_cella1_f12.setColspan(2);	
		blank_cella1_f12.setBorder( Rectangle.NO_BORDER );
		blank_cella1_f12.setPaddingLeft(35f);

		
		PdfPCell blank_cella1_f15 = new PdfPCell(f15);
//		blank_cella1_f15.setRowspan(2);
		blank_cella1_f15.setBorder( Rectangle.NO_BORDER );
		blank_cella1_f15.setPaddingLeft(15f);


		
		PdfPCell blank_cella1_f16 = new PdfPCell(f16);
//		blank_cella1_f16.setRowspan(2);
		blank_cella1_f16.setBorder( Rectangle.NO_BORDER );
		blank_cella1_f16.setPaddingLeft(15f);

		PdfPCell blank_cella1_f17 = new PdfPCell(f17);
//		blank_cella1_f17.setRowspan(2);
		blank_cella1_f17.setBorder( Rectangle.NO_BORDER );
		blank_cella1_f17.setPaddingLeft(15f);

		PdfPCell blank_cella1_f18 = new PdfPCell(f18);
//		blank_cella1_f18.setRowspan(2);
		blank_cella1_f18.setBorder( Rectangle.NO_BORDER );
		blank_cella1_f18.setPaddingLeft(15f);

		PdfPCell blank_cella1_f19 = new PdfPCell(f19);
//		blank_cella1_f19.setRowspan(2);	
		blank_cella1_f19.setBorder( Rectangle.NO_BORDER );
		blank_cella1_f19.setPaddingLeft(8f);


		PdfPCell blank_cella1_k66 = new PdfPCell(k66);
		blank_cella1_k66.setBorder( Rectangle.NO_BORDER );
//		blank_cella1_k66.setRowspan(2);
		PdfPCell blank_cella1_l66 = new PdfPCell(l66);
		blank_cella1_l66.setBorder( Rectangle.NO_BORDER );
//		blank_cella1_l66.setRowspan(2);
		
		tabledata61.addCell(blank_cella1_C11);
		tabledata61.addCell(blank_cella1_C12);
		tabledata61.addCell(blank_cella1_C13);
		tabledata61.addCell(blank_cella1_C14);
		tabledata61.addCell(blank_cella1_C15);
		tabledata61.addCell(f6);
		tabledata61.addCell(f7);
		tabledata61.addCell(f8);
		tabledata61.addCell(f9);
		tabledata61.addCell(f10);
		tabledata61.addCell(f11);
		tabledata61.addCell(blank_cella1_f12);
		tabledata61.addCell(f13);
		tabledata61.addCell(f14);

		tabledata61.addCell(blank_cella1_f15);
		tabledata61.addCell(blank_cella1_f16);
		tabledata61.addCell(blank_cella1_f17);
		tabledata61.addCell(blank_cella1_f18);
		tabledata61.addCell(blank_cella1_f19);
		//tabledata61.addCell(blank_cella1_k66);
		tabledata61.addCell(blank_cella1_l66);
//		Paragraph q66 = new Paragraph("    / \n   SERVICE",fontTableHeadingSubMainHead);
		Paragraph a66 = new Paragraph("500",fontTableHeadingSubMainHead);
		Paragraph b66 = new Paragraph("500",fontTableHeadingSubMainHead);
		Paragraph c66 = new Paragraph("500",fontTableHeadingSubMainHead);
		Paragraph d66 = new Paragraph("500",fontTableHeadingSubMainHead);
		Paragraph e66 = new Paragraph("500",fontTableHeadingSubMainHead);
		Paragraph f66 = new Paragraph("500",fontTableHeadingSubMainHead);
		Paragraph g66 = new Paragraph("TOTAL",fontTableHeadingSubMainHead);
		Paragraph h66 = new Paragraph("700",fontTableHeadingSubMainHead);
		Paragraph i66 = new Paragraph("300",fontTableHeadingSubMainHead);
		Paragraph j66 = new Paragraph("1000",fontTableHeadingSubMainHead);
		
		
		String rdp="";
		PdfPCell blank_cella2_C12 = new PdfPCell(new Paragraph(rdp)); 
	blank_cella2_C12.setBorder( Rectangle.BOTTOM );
	blank_cella2_C12.setPaddingLeft(20f);
	tabledata61.addCell(blank_cella2_C12);
	
	blank_cella2_C12 = new PdfPCell(new Paragraph(rdp)); 
	blank_cella2_C12.setBorder( Rectangle.BOTTOM );
	blank_cella2_C12.setPaddingLeft(20f);
	tabledata61.addCell(blank_cella2_C12);
	
	blank_cella2_C12 = new PdfPCell(new Paragraph(rdp)); 
	blank_cella2_C12.setBorder( Rectangle.BOTTOM );
	blank_cella2_C12.setPaddingLeft(20f);
	tabledata61.addCell(blank_cella2_C12);
	
	 
	
	blank_cella2_C12 = new PdfPCell(new Paragraph(rdp)); 
	blank_cella2_C12.setBorder( Rectangle.BOTTOM );
//	blank_cella2_C12.setPaddingLeft(20f);
	tabledata61.addCell(blank_cella2_C12);
	
	blank_cella2_C12 = new PdfPCell(new Paragraph(rdp)); 
	blank_cella2_C12.setBorder( Rectangle.BOTTOM );
//	blank_cella2_C12.setHorizontalAlignment(Element.ALIGN_CENTER);
	blank_cella2_C12.setVerticalAlignment(Element.ALIGN_MIDDLE);
//	blank_cella2_C12.setPaddingLeft(20f);
	tabledata61.addCell(blank_cella2_C12);
		
//		tabledata61.addCell("");
//		tabledata61.addCell("");

//	tabledata61.addCell(a66);
	
	blank_cella2_C12 = new PdfPCell(a66); 
	blank_cella2_C12.setBorder( Rectangle.BOTTOM );
//	blank_cella2_C12.setPaddingLeft(20f);
	blank_cella2_C12.setPaddingLeft(7f);
	tabledata61.addCell(blank_cella2_C12);
	

		
	 
		
//		tabledata61.addCell(b66);
		
		blank_cella2_C12 = new PdfPCell(b66); 
		blank_cella2_C12.setBorder( Rectangle.BOTTOM );
		blank_cella2_C12.setPaddingLeft(7f);
		tabledata61.addCell(blank_cella2_C12);
		
//		tabledata61.addCell(c66);
		
		blank_cella2_C12 = new PdfPCell(c66); 
		blank_cella2_C12.setBorder( Rectangle.BOTTOM );
		blank_cella2_C12.setPaddingLeft(7f);
		tabledata61.addCell(blank_cella2_C12);
		
//		tabledata61.addCell(d66);
		
		blank_cella2_C12 = new PdfPCell(d66); 
		blank_cella2_C12.setBorder( Rectangle.BOTTOM );
		blank_cella2_C12.setPaddingLeft(7f);
		tabledata61.addCell(blank_cella2_C12);
		
//		tabledata61.addCell(e66);
		
		blank_cella2_C12 = new PdfPCell(e66); 
		blank_cella2_C12.setBorder( Rectangle.BOTTOM );
		blank_cella2_C12.setPaddingLeft(7f);
		tabledata61.addCell(blank_cella2_C12);
		
//		tabledata61.addCell(f66);
		
		blank_cella2_C12 = new PdfPCell(f66); 
		blank_cella2_C12.setBorder( Rectangle.BOTTOM );
		blank_cella2_C12.setPaddingLeft(7f);
		tabledata61.addCell(blank_cella2_C12);
		
//		tabledata61.addCell(g66);
		
		blank_cella2_C12 = new PdfPCell(g66); 
		blank_cella2_C12.setBorder( Rectangle.BOTTOM );
		blank_cella2_C12.setPaddingLeft(10f);
		tabledata61.addCell(blank_cella2_C12);
		
//		tabledata61.addCell(h66);
		
		blank_cella2_C12 = new PdfPCell(h66); 
		blank_cella2_C12.setBorder( Rectangle.BOTTOM );
		blank_cella2_C12.setPaddingLeft(13f);
		tabledata61.addCell(blank_cella2_C12);
		
//		tabledata61.addCell(i66);
		
		blank_cella2_C12 = new PdfPCell(i66); 
		blank_cella2_C12.setBorder( Rectangle.BOTTOM );
		blank_cella2_C12.setPaddingLeft(13f);
		tabledata61.addCell(blank_cella2_C12);
		
//		tabledata61.addCell(j66);
		
		blank_cella2_C12 = new PdfPCell(j66); 
		blank_cella2_C12.setBorder( Rectangle.BOTTOM );
		blank_cella2_C12.setPaddingLeft(13f);
		tabledata61.addCell(blank_cella2_C12);
		
		
		 blank_cella2_C12 = new PdfPCell(new Paragraph(rdp)); 
			blank_cella2_C12.setBorder( Rectangle.BOTTOM );
			blank_cella2_C12.setPaddingLeft(20f);
			tabledata61.addCell(blank_cella2_C12);
			
			blank_cella2_C12 = new PdfPCell(new Paragraph(rdp)); 
			blank_cella2_C12.setBorder( Rectangle.BOTTOM );
			blank_cella2_C12.setPaddingLeft(20f);
			tabledata61.addCell(blank_cella2_C12);
			
			blank_cella2_C12 = new PdfPCell(new Paragraph(rdp)); 
			blank_cella2_C12.setBorder( Rectangle.BOTTOM );
			blank_cella2_C12.setPaddingLeft(20f);
			tabledata61.addCell(blank_cella2_C12);
		
			blank_cella2_C12 = new PdfPCell(new Paragraph(rdp)); 
			blank_cella2_C12.setBorder( Rectangle.BOTTOM );
			blank_cella2_C12.setPaddingLeft(20f);
			tabledata61.addCell(blank_cella2_C12);
			
			blank_cella2_C12 = new PdfPCell(new Paragraph(rdp)); 
			blank_cella2_C12.setBorder( Rectangle.BOTTOM );
			blank_cella2_C12.setPaddingLeft(20f);
			tabledata61.addCell(blank_cella2_C12);
			
			blank_cella2_C12 = new PdfPCell(new Paragraph(rdp)); 
			blank_cella2_C12.setBorder( Rectangle.BOTTOM );
			blank_cella2_C12.setPaddingLeft(20f);
			tabledata61.addCell(blank_cella2_C12);
			
//		tabledata61.addCell(a66);
//		tabledata61.addCell(b66);
//		tabledata61.addCell(c66);
//		tabledata61.addCell(d66);
//		tabledata61.addCell(e66);
//		tabledata61.addCell(f66);
//		tabledata61.addCell(g66);
//		tabledata61.addCell(h66);
//		tabledata61.addCell(i66);
//		tabledata61.addCell(j66);

			
		ArrayList<List<String>> getfailofficeristReport = (ArrayList<List<String>>) model.get("list");
			 int  index5=1;
			 for(int i5=0;i5<getfailofficeristReport.size();i5++)
			 {
			
				 List<String> l = getfailofficeristReport.get(i5);
				 Paragraph blank1 = new Paragraph(l.get(0),fontTableHeadingdata);
					Paragraph blank2 = new Paragraph(l.get(1),fontTableHeadingdata);
					Paragraph blank3 = new Paragraph(l.get(2),fontTableHeadingdata);
					Paragraph blank4 = new Paragraph(l.get(3),fontTableHeadingdata);
					Paragraph blank5 = new Paragraph(l.get(4),fontTableHeadingdata);
					Paragraph blank6 = new Paragraph(l.get(5),fontTableHeadingdata);
					Paragraph blank7 = new Paragraph(l.get(6),fontTableHeadingdata);
					Paragraph blank8 = new Paragraph(l.get(7),fontTableHeadingdata);
					Paragraph blank9 = new Paragraph(l.get(8),fontTableHeadingdata);
					Paragraph blank10 = new Paragraph(l.get(9),fontTableHeadingdata);
					Paragraph blank11 = new Paragraph(l.get(10),fontTableHeadingdata);
					Paragraph blank12 = new Paragraph(l.get(11),fontTableHeadingdata);
				//	Paragraph blank13 = new Paragraph(l.get(12),fontTableHeadingdata);
					
					 Paragraph blank13 = new Paragraph(decfor.format(Double.parseDouble(l.get(12))),fontTableHeadingdata);

					Paragraph blank14 = new Paragraph(l.get(13),fontTableHeadingdata);
					Paragraph blank15 = new Paragraph(l.get(14),fontTableHeadingdata);
					 
					Paragraph blank16 = new Paragraph(choice(l.get(15)),fontTableHeadingdata);
//				 
					Paragraph blank17 = new Paragraph(choice(l.get(16)),fontTableHeadingdata);
//				 
					Paragraph blank18 = new Paragraph(choice(l.get(17)),fontTableHeadingdata);
//					 
					Paragraph blank19 = new Paragraph(choice(l.get(18)),fontTableHeadingdata);
					Paragraph blank20 = new Paragraph(l.get(19),fontTableHeadingdata);

					Paragraph blank21 = new Paragraph(l.get(20),fontTableHeadingdata);

					PdfPCell cellar = new PdfPCell();
					
					cellar.setFixedHeight(20f);
					if (i5 % 2 == 0) {
						cellar.setBackgroundColor(java.awt.Color.lightGray);
					}

					cellar.setPhrase(blank1);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					cellar.setBorder(Rectangle.NO_BORDER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank2);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank3);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank4);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank5);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank6);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank7);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank8);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank9);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank10);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank11);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank12);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank13);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank14);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank15);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank16);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank17);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank18);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank19);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank20);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					
					cellar.setPhrase(blank21);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
//					tabledata61.addCell(blank1);
//					tabledata61.addCell(blank2);
//					tabledata61.addCell(blank3);
//					tabledata61.addCell(blank4);
//					tabledata61.addCell(blank5);
//					tabledata61.addCell(blank6);
//					tabledata61.addCell(blank7);
//					tabledata61.addCell(blank8);
//					tabledata61.addCell(blank9);
//					tabledata61.addCell(blank10);
//					tabledata61.addCell(blank11);
//					tabledata61.addCell(blank12);
//					tabledata61.addCell(blank13);
//					tabledata61.addCell(blank14);
//					tabledata61.addCell(blank15);
//					tabledata61.addCell(blank16);
//					tabledata61.addCell(blank17);
//					tabledata61.addCell(blank18);
//					tabledata61.addCell(blank19);
//					tabledata61.addCell(blank20);
//			
			 }
//			 
//				 
				
			 
			 PageNumeration event = new PageNumeration(arg2);
				arg2.setPageEvent(event);
				document.setPageCount(1);				 
				
				
				table6.setSplitLate(false);
				PdfPCell cell12356;
				cell12356 = new PdfPCell(); 
				cell12356.addElement(tableheader6); 
				cell12356.setBorder(Rectangle.NO_BORDER);
				 
				table6.addCell(cell12356);
				
				PdfPCell cell1235612 ;
				cell1235612 = new PdfPCell();
				cell1235612.setBorder(Rectangle.BOX);
				 
				cell1235612.addElement(tabledata61);
			 
				table6.addCell(cell1235612);
		 
		 
			 
//		PdfPCell cell12356;
//		cell12356 = new PdfPCell();
//		cell12356.addElement(tabledata6);
//		cell12356.addElement(tableheader6);
//		cell12356.addElement(tabledata61);
//		
//		
//		cell12356.setBorder(Rectangle.NO_BORDER);
//		table6.addCell(cell12356);
		document.add(table6);
		super.buildPdfMetadata(model, document, request);
	}
	
	class PageNumeration extends PdfPageEventHelper {
		PdfTemplate total;
		PdfTemplate total1;
		PdfTemplate footer1;
		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				total1 = writer.getDirectContent().createTemplate(30, 16);
				footer1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {
			// total = writer.getDirectContent().createTemplate(30, 12);
		}

		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(5);
			String ip = "";
			try {
				table.setWidths(new int[] { 3,7,0,2,1});  
				table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				Date now = new Date();
				String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
				table.addCell(dateString);  //table.addCell("TOTAL SHEET :");
				
				PdfPCell cell2 = new PdfPCell(Image.getInstance(footer1));
//				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_MIDDLE);
				table.addCell(String.format("D : DSSC    T : DSTSC    S : SHORTLISTED  F : FAILED  NA : NOT APPLIED"));
				cell2.setBorder(Rectangle.NO_BORDER);				
				table.addCell(cell2);
				
				PdfPCell cell1 = new PdfPCell(Image.getInstance(total1));
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			//	table.addCell(cell1);
								
			
				//String watermark = " Generated by "+username+" on "+dateString +" with IP " +ip ;
				
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Pages %d of", writer.getPageNumber()));
				//table.addCell("Month :");
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.NO_BORDER);				
				table.addCell(cell);
				
				table.writeSelectedRows(0, -1, document.leftMargin(), document.topMargin() + 0, writer.getDirectContent());
			} catch (DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT, new Phrase(String.valueOf(writer.getPageNumber() - 1)), 2, 2, 0);
			ColumnText.showTextAligned(total1, Element.ALIGN_LEFT, new Phrase(String.valueOf(totalRecords)), 2, 2, 0);
		}
	}
	public String choice(String ch) {
		if ( ch==null) {
			ch="NA";
		}
		else if (ch.equals( "DSSC")) {
			ch="D";
		}
		else if ( ch.equals("DSTSC")) {
			ch="T";
		}
		else if ( ch.equals("COMPETITIVE")) {
			ch="C" ;
		}
		else if ( ch.equals("ALMC")) {
			ch="A";
		}
		else if ( ch.equals("ISC")) {
			ch="I";
		}
		else if ( ch.equals("DSSC Res")) {
			ch="R";
		}
		else if ( ch.equals("ALMC Res")) {
			ch="R";
		}
		else if ( ch.equals("ISC Res")) {
			ch="R";
		}
		else if ( ch.equals("DSTSC Res")) {
			ch="R";
		}
		return ch;
	}
	

}
