package com.BisagN.dao.Indexing;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Service
public class IndexSlipManualDaoImpl implements IndexSlipManualDAO  {
	
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	 CommonController comm= new CommonController();

	
	public boolean checkIsIntegerValue(String Search) {
		return Search.matches("[0-9]+");
		}
	
	
	public ArrayList<ArrayList<String>> getIndexSlipManualDetails(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,int ec_exam_id, int es_id,int sc_subject_id,String bundle_name,String bundle_no,
			String personal_no,String command,String center,int esid_sub_subject_id,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		
		if (!personal_no.equals("")) {
			
			
			//using commaon controller searchwithout zero
			personal_no=comm.getSearchIcNumberwithoutZero(personal_no);
			 System.err.println("opc_code==========="+personal_no);
				 
		}
		
		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search,sc_subject_id,bundle_name,bundle_no,personal_no,command,center,esid_sub_subject_id);
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String q2 = "";
		
		
		System.err.println("bundle_name=========="+bundle_name);
		System.err.println("bundle_no=========="+bundle_no);
		
		if (esid_sub_subject_id != 0) {
			q2 += "and ismn.is_sub_subject_id=?"; 
		}
		
		
		

		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			 q = "select DISTINCT vpd.opc_personal_code,vpd.opc_suffix_code,ecc.ecc_name,vpd.ac_arm_description,sc.sc_subject_name,cc.cc_command_name,ism.ism_indexno, ismn.is_abs,ibm_bundle_prefix,ibm.ibm_bundle_no,"
			 		+ " ism.ism_id \n"
			 		+ ", ismn.is_id ,is_iu_user_id,ofa.oa_application_id,tbc.print_status\n"
			 		+ "from index_slip_manual ismn\n"
			 		+ "inner join index_slip_master ism on ism.ism_id=ismn.is_ism_id\n"
			 		+ "inner join vw_personal_details vpd on vpd.opc_personal_code=ism.ism_armyno\n"
			 		+ "inner join officer_application ofa on vpd.opd_personal_id = ofa.opd_personal_id and ofa.es_id=? \n"
			 		+ "inner join exam_center_code ecc on ism.center_code=ecc.ecc_center_code\n"
			 		+ "inner join arm_codes ar on ismn.is_ac_arm_id=ar.ac_arm_id\n"
			 		+ "inner join subject_code sc on ismn.is_sc_subject_id=sc.sc_subject_id and sc.ec_exam_id=?\n"
			 		+ "inner join command_code cc on ism.command_id=cc.cc_command_id\n"
			 		+ "inner join indexed_bundle_master ibm on ibm.ibm_id=ismn.is_ibm_id\n"
			 		+ "inner join indexed_packing_notes_details ipnd on ibm.ibm_id=ipnd.ipnd_ibm_id\n"
			 		+ "inner join indexed_packing_notes_master ipnm on ipnm.ipnm_id=ipnd.ipnd_ipnm_id\n"
			 		+ "inner join tb_barcode_count tbc on tbc.is_id = ismn.is_id\n"
			 		+ "where ism.ism_es_id=? and ismn.is_sc_subject_id=?  and ismn.is_status = 1  "+q2+" \n"
			 		+ " "+SearchValue+" \n"
					+ "ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage;
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			stmt.setInt(2, ec_exam_id);
			stmt.setInt(3, es_id);
			stmt.setInt(4,sc_subject_id);
			if (esid_sub_subject_id != 0) {
				stmt.setInt(5,esid_sub_subject_id);
			}
			
			
			stmt = setQueryWhereClause_SQL(stmt,Search,sc_subject_id,bundle_name,bundle_no,personal_no,command,center,esid_sub_subject_id);
			
			System.err.println("indexslip=========="+stmt);
			ResultSet rs = stmt.executeQuery();
			int i=1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(String.valueOf(i));
				
				String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
	     		String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));			
				list.add(opc_code);//1
				
				list.add(rs.getString("ecc_name"));//0
				list.add(rs.getString("ac_arm_description"));//0
				list.add(rs.getString("sc_subject_name"));//0
				list.add(rs.getString("cc_command_name"));//0
				list.add(rs.getString("ism_indexno"));//0
				list.add(rs.getString("is_abs"));//0
				
				if (rs.getInt("print_status")==1) {
					list.add("Verified,Printed");//0	
				}
				else {
					list.add("Verified");//0
				}
			
				list.add(rs.getString("ibm_bundle_prefix")+(rs.getString("ibm_bundle_no")));//0
				String enckey ="commonPwdEncKeys";
                Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
                String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("ism_id").toString().getBytes())));
                String EPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("is_id").toString().getBytes())));
                String Euser_id = new String(Base64.encodeBase64( c.doFinal(rs.getString("is_iu_user_id").toString().getBytes())));
                String EOff_id = new String(Base64.encodeBase64( c.doFinal(rs.getString("oa_application_id").toString().getBytes())));
                
                String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') )"
                		+ "{editData('" + EncryptedPk+ "','" + EPk+ "','" + Euser_id+ "','" + EOff_id+ "')}else{ return false;}\"";
    			String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>";
    			
    			 String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete Permanent?') ){deleteData('" + EncryptedPk+ "','" + EPk+ "','" + Euser_id+ "','" + EOff_id+ "')}else{ return false;}\""; 
                 String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
             
                 list.add(updateButton+deleteButton);
    			 alist.add(list);
				i++;

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	public long getTotalCountgetIndexSlipManualDetails(String Search,int ec_exam_id,int es_id,int sc_subject_id,String bundle_name,String bundle_no,
			String personal_no,String command,String center,int esid_sub_subject_id) {

		String SearchValue = GenerateQueryWhereClause_SQL(Search,sc_subject_id,bundle_name,bundle_no,personal_no,command,center,esid_sub_subject_id);
	int total = 0;
	String q = null;
	String q2 = "";
	Connection conn = null;
	
	if (esid_sub_subject_id != 0) {
		q2 += "and ismn.is_sub_subject_id=?"; 
	}
	
	
	
	try {
		conn = dataSource.getConnection();
		q ="select count(*) from (select DISTINCT ism.ism_armyno,ecc.ecc_name,vpd.ac_arm_description,sc.sc_subject_name,cc.cc_command_name,ism.ism_indexno, ismn.is_abs\n"
				+ "from index_slip_manual ismn\n"
				+ "inner join index_slip_master ism on ism.ism_id=ismn.is_ism_id\n"
				+ "inner join vw_personal_details vpd on vpd.opc_personal_code=ism.ism_armyno\n"
				+ "inner join officer_application ofa on vpd.opd_personal_id = ofa.opd_personal_id and ofa.es_id=? \n"
				+ "inner join exam_center_code ecc on ism.center_code=ecc.ecc_center_code\n"
				+ "inner join arm_codes ar on ismn.is_ac_arm_id=ar.ac_arm_id\n"
				+ "inner join subject_code sc on ismn.is_sc_subject_id=sc.sc_subject_id and sc.ec_exam_id=?\n"
				+ "inner join command_code cc on ism.command_id=cc.cc_command_id\n"
				+ "inner join indexed_bundle_master ibm on ibm.ibm_id=ismn.is_ibm_id\n"
				+ "inner join indexed_packing_notes_details ipnd on ibm.ibm_id=ipnd.ipnd_ibm_id\n"
				+ "inner join indexed_packing_notes_master ipnm on ipnm.ipnm_id=ipnd.ipnd_ipnm_id\n"
				+ "where ism.ism_es_id=? and ismn.is_sc_subject_id=? "+q2+" \n"
				+ ""  +SearchValue +"   ) ab " ;
		
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereClause_SQL(stmt,Search,sc_subject_id,bundle_name,bundle_no,personal_no,command,center,esid_sub_subject_id);
		stmt.setInt(1, es_id);
		stmt.setInt(2, ec_exam_id);
		stmt.setInt(3, es_id);
		stmt.setInt(4,sc_subject_id);
		if (esid_sub_subject_id != 0) {
			stmt.setInt(5,esid_sub_subject_id);
		}
		
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search, int sc_subject_id,String bundle_name,String bundle_no,
			String personal_no,String command,String center,int esid_sub_subject_id) {
		String SearchValue = "";

		try {
			if (!bundle_name.equals("0") && bundle_name != "0") {
				SearchValue += " and ipnm.ipnm_id=?"; 
			}
			
			if (!bundle_no.equals("0") && bundle_no != "0") {
				SearchValue += " and ibm.ibm_id=?"; 
			}
			
			
			if (!personal_no.equals("") && personal_no != "" && personal_no != null) {
				SearchValue += " and lower(vpd.opc_personal_code) like  ? "; 
			}
			
			if (!command.equals("0") && command != "0") {
				SearchValue += " and vpd.cc_command_id=?"; 
			}
			
			if (!center.equals("0") && center != "0") {
			
				
				SearchValue += " and ism.center_code=?"; 
			}
			
			
			
		
			
			
			if (!Search.equals("")) {
				Search = Search.toLowerCase();
				SearchValue = " and ( ";
				SearchValue += " lower(opc_personal_code) like ?  or lower(opd_officer_name) like ? or lower(vpd.ac_arm_description) like ?)";
						
			}
		} catch (Exception e) {
			
		}
		return SearchValue;

	}

	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,int sc_subject_id,String bundle_name,String bundle_no,
			String personal_no,String command,String center,int esid_sub_subject_id) {
//		int flag=0;
//		if (esid_sub_subject_id != 0) {
			 int flag = 4;
//		}
		
		
	try {
		

			
		if (!bundle_name.equals("0") && bundle_name != "0") {
			flag += 1;
			stmt.setInt(flag, Integer.parseInt(bundle_name));
		}
		
		if (!bundle_no.equals("0") && bundle_no != "0") {
			flag += 1;
			stmt.setInt(flag, Integer.parseInt(bundle_no));
		}
		
		if (!personal_no.equals("") && personal_no != "" && personal_no != null)  {
			flag += 1;
			stmt.setString(flag, personal_no.toLowerCase());
				
		}
		
	
		if (!command.equals("0") && command != "0") {
			flag += 1;
			stmt.setInt(flag, Integer.parseInt(command));
		}
		if (!center.equals("0") && center != "0") {
			flag += 1;
			stmt.setInt(flag, Integer.parseInt(center));
		}
		
		
		if(!Search.equals("")) {
			
						
			flag += 1;
			Search=comm.getSearchIcNumberwithoutZero(Search);

			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				
			
		}
	}catch (Exception e) {
		
	}
	return stmt;
	}

	
	public ArrayList<ArrayList<String>> GetActivebundlleName(int indx_esId, String sc_subject_id,String bundle_name,String bundle_no) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select count(*) as bundle from indexed_bundle_master ibm \n"
					+ "inner join index_slip_manual ism on ibm.ibm_id=ism.is_ibm_id \n"
					+ "where ibm.ibm_es_id=? and ibm.ibm_nsubjectid=? and ism.is_status != 2 and ibm.ibm_bundle_prefix=? and ibm.ibm_bundle_no=? ";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, indx_esId);
			stmt.setInt(2, Integer.parseInt(sc_subject_id));
			stmt.setString(3, bundle_name);
			stmt.setString(4, bundle_no);


			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("bundle"));//0
			
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	public ArrayList<ArrayList<String>> GetMasterABList(int indx_esId, String subject_id1,String bundle_name1,String bundle_no1) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select DISTINCT ism.ism_armyno, ism.ism_indexno, ismn.is_abs,ibm.ibm_id,l.username from indexed_bundle_master ibm\n"
					+ "inner join index_slip_manual ismn on ibm.ibm_id=ismn.is_ibm_id\n"
					+ "inner join index_slip_master ism on ism.ism_id=ismn.is_ism_id\n"
					+ "inner join indexed_packing_notes_details ipnd on ipnd.ipnd_ibm_id=ibm.ibm_id\n"
					+ "inner join indexed_packing_notes_master ipnm on ipnm.ipnm_id=ipnd.ipnd_ipnm_id \n"
					+ "inner join logininformation l on ibm.ibm_iu_user_id=l.userid\n"
					+ "where ibm.ibm_es_id=? and ismn.is_sc_subject_id=? and ipnm.ipnm_id=? and ibm.ibm_id=? and  ismn.is_status != 2 order by ism.ism_indexno ";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, indx_esId);
			stmt.setInt(2, Integer.parseInt(subject_id1));
			stmt.setInt(3, Integer.parseInt(bundle_name1));
			stmt.setInt(4, Integer.parseInt(bundle_no1));
			
			ResultSet rs = stmt.executeQuery();
			
			System.err.println("getIndexSlip_Report============"+stmt);
			int i=0;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(String.valueOf(i));
//				list.add(rs.getString("ism_armyno"));//0
				String  ism_armyno=comm.getIcNumberwithoutZero(rs.getString("ism_armyno")).toString();
//	     		String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));			
				list.add(ism_armyno);//1
//				list.add(rs.getString("ism_armyno"));//0
				list.add(rs.getString("ism_indexno"));//0
				list.add(rs.getString("is_abs"));//0
				list.add(rs.getString("ibm_id"));//0
				list.add(rs.getString("username"));//0
				
			
				alist.add(list);
				i++;
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	public ArrayList<ArrayList<String>> getBunldeNoByPackingBundle(int es_id, int user_id,String bundle_packing_id, String role) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q1="";
			String q2="";
			
			
			
			if(role.equals("Index Group")) {
				q2+="and ibm.ibm_iu_user_id=?";
				
			}
			
			System.err.println("bundle_packing_id======"+bundle_packing_id);
			
			String q = "select DISTINCT ibm.ibm_id ,ibm.ibm_bundle_prefix,ibm.ibm_bundle_no from indexed_packing_notes_master ipnm\n"
					+ "inner join indexed_packing_notes_details ipnd on ipnm.ipnm_id=ipnd.ipnd_ipnm_id\n"
					+ "inner join indexed_bundle_master ibm on ipnd.ipnd_ibm_id=ibm.ibm_id\n"
					+ "where ipnm.ipnm_es_id=? and ipnm.ipnm_id=?  "+q2+"     ";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			
			stmt.setInt(2, Integer.parseInt(bundle_packing_id));
			
			if(role.equals("Index Group")) {
				stmt.setInt(3, user_id);
			}
			
			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ibm_id"));
				list.add(rs.getString("ibm_bundle_prefix")+(rs.getString("ibm_bundle_no")));//0
			
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	public ArrayList<ArrayList<String>> getNotGenerateBunldeNoByPackingBundle(int es_id, int user_id,String bundle_packing_id, String role) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q1="";
			String q2="";
			
			
			
			if(role.equals("Index Group")) {
				q2+="and ibm.ibm_iu_user_id=?";
				
			}
			
			System.err.println("bundle_packing_id======"+bundle_packing_id);
			
			String q = "select ibm.ibm_id ,ibm.ibm_bundle_prefix,ibm.ibm_bundle_no from indexed_packing_notes_master ipnm\n"
					+ "inner join indexed_packing_notes_details ipnd on ipnm.ipnm_id=ipnd.ipnd_ipnm_id\n"
					+ "inner join indexed_bundle_master ibm on ipnd.ipnd_ibm_id=ibm.ibm_id\n"
					+ "where ipnm.ipnm_es_id=? and ipnm.ipnm_id=?  "+q2+"     ";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			
			stmt.setInt(2, Integer.parseInt(bundle_packing_id));
			
			if(role.equals("Index Group")) {
				stmt.setInt(3, user_id);
			}
			
			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ibm_id"));
				list.add(rs.getString("ibm_bundle_prefix")+(rs.getString("ibm_bundle_no")));//0
			
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	

	
//	 public String DeleteIndexSlip(String deleteid,String Epk,HttpSession session1) {
//
//	      	Session session = this.sessionFactory.openSession();
//	      	Transaction tx = session.beginTransaction();
//	      	String enckey = "commonPwdEncKeys";
//	      	
//			    String DcryptedPk = hex_asciiDao.decrypt((String) deleteid,enckey,session1);
//			    
//			    System.out.println("DcryptedPk=============="+DcryptedPk);
//			    
//			 
//	      	 String hql = "update COMMAND_CODE_M set cc_status_id=:cc_status_id where cast(cc_command_id as string) = :deleteid";
//			    
//		        Query q = session.createQuery(hql)
//		        		.setString("deleteid",DcryptedPk)
//		        		.setInteger("cc_status_id", 0);
//		    	int rowCount = q.executeUpdate();
//		    	tx.commit();
//		        session.close();
//			    if(rowCount > 0) {
//					return "Deleted Successfully";
//				}else {
//				return "Deleted not Successfully";
//		 	}
//		}
	 

	public ArrayList<ArrayList<String>> getGroupusername( int user_id ) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			 
			
			 
			String q = " SELECT  li.userid,li.username FROM public.userroleinformation url\n"
					+ "INNER join logininformation li ON li.userid = url.user_id\n"
					+ "inner join roleinformation ri ON ri.role_id = url.role_id\n"
					+ "where url.role_id = ?";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, user_id);
			 
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("userid"));
				list.add(rs.getString("username"));
			
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	
	public ArrayList<ArrayList<String>> dateIndexDetailsForBarocde(int startPage, String pageLength, String Search,
			String orderColunm, String orderType, int es_id ,String usrename ,int subject_id,String role) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			 
			String q2 = "";
			String q3 = "";
			System.err.println("role=========="+role);
			if(role.equals("Closing Group")) {
				q2+="a.close_by=?";
				q3+="and tbc.close_status=0 ";
			}
			if(role.equals("Opening Group")) {
				q2+="a.opng_by=?";
				q3+="and tbc.opng_status=0 ";
			}
			 
			String q = "  select tbc.barcode_no,tbc.oa_app_id,ibm.ibm_bundle_prefix,ibm.ibm_bundle_no from tb_barcode_count tbc \n"
					+ "	inner join index_slip_manual ism on ism.is_id=tbc.is_id\n"
					+ "	inner join indexed_bundle_master ibm on ibm.ibm_id=ism.is_ibm_id\n"
					+ "	where tbc.is_id in (select is_id from tb_barcode_count a where "+q2+" ) "+q3+"\n"
					+ "	and tbc.es_id =? \n"
					+ "and tbc.subject_id = ?"
					+ "ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
			stmt = conn.prepareStatement(q);
			stmt.setString(1, usrename);
			stmt.setInt(2, es_id);
			stmt.setInt(3, subject_id);
			
			System.err.println("====stmt======"+stmt);
			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ibm_bundle_prefix"));
				list.add(rs.getString("ibm_bundle_prefix")+""+rs.getString("ibm_bundle_no"));
				list.add(rs.getString("barcode_no"));
				list.add(rs.getString("oa_app_id"));
			
				System.err.println("====list======"+list);
				
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	

	
	
	public ArrayList<ArrayList<String>> getcountdateIndexDetailsForBarocde( int es_id ,String usrename ,int subject_id,String role) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			 
			String q2 = "";
			String q3 = "";
			System.err.println("role=========="+role);
			if(role.equals("Closing Group")) {
				q2+="a.close_by=?";
				q3+="and tbc.close_status=0 ";
			}
			if(role.equals("Opening Group")) {
				q2+="a.opng_by=?";
				q3+="and tbc.opng_status=0 ";
			}
			 
			String q = "  select count(tbc.barcode_no ) as coun from tb_barcode_count tbc \n"
					+ "	inner join index_slip_manual ism on ism.is_id=tbc.is_id\n"
					+ "	inner join indexed_bundle_master ibm on ibm.ibm_id=ism.is_ibm_id\n"
					+ "	where tbc.is_id in (select is_id from tb_barcode_count a where "+q2+" ) "+q3+"\n"
					+ "	and tbc.es_id =? \n"
					+ "and tbc.subject_id = ?";
					 
			stmt = conn.prepareStatement(q);
			stmt.setString(1, usrename);
			stmt.setInt(2, es_id);
			stmt.setInt(3, subject_id);
			
			System.err.println("====stmt======"+stmt);
			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("coun"));
			 
			
				System.err.println("====list======"+list);
				
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
}
