package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.Indexing.IndexSlipManualDAO;
import com.BisagN.dao.Indexing.StickerGenerationDAO;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_MASTER;
import com.BisagN.models.officers.indexing.INDEXING_SETTING;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class StickerGenerationController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	CommonController comm;

	@Autowired
	private PartB_ExaminationDAO partBDao;

	@Autowired
	IndexSlipManualDAO ismDao;
	
	@Autowired
	StickerGenerationDAO sgDao;
	
	int subjectID;

	@RequestMapping(value = "StickerGenerationDetails_Url", method = RequestMethod.GET)
	public ModelAndView StickerGenerationDetails_Url(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

		if (es_id != 0) {
			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, es_id);
			Mmap.put("es_id", es_id);
			String index_mode = UnlcokExmsch.get(0).getEs_index_mode();
			Mmap.put("index_mode", index_mode);
		}

		int esi_es_id = Integer.parseInt(
				session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		if (esi_es_id != 0) {
			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, esi_es_id);
			Date begin_date = UnlcokExmsch.get(0).getEs_begin_date();
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

			int day = date.getDayOfMonth();
			String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

			String[] shortMonths = new DateFormatSymbols().getShortMonths();
			for (String shortMonth : shortMonths) {

			}

			Month month = date.getMonth();
			int year = date.getYear();
			String begindateShow = day + " " + month + " " + year;

			Mmap.put("begindateShow", begindateShow);
			Mmap.put("esid_es_id", esi_es_id);

			List<EXAMSCHEDULE_INDEXING_DETAIL> ActiveSubject = comm.getActiveIndxSubject(sessionFactory, esi_es_id);
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
					: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
			if (esid_sc_subject_id != 0) {
				List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
				Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			
				
				Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
				List<SUBJECT_CODE_M> ActiveSubName = comm.getsubjectIdbysubname(sessionFactory, esid_sc_subject_id,
						ec_exam_id);

				ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
				Mmap.put("getexamcentrelist", examcentrelist);
				Mmap.put("ActiveSub", ActiveSubName.get(0).getSc_subject_name());
				
				
				subjectID = ActiveSubName.get(0).getSc_subject_id();
//				System.out.println("SUBID===================="+ SubId);
				List<INDEXED_PACKING_NOTES_MASTER> bundleprefix = comm.getBundlePrefixList(sessionFactory, esi_es_id,
						esid_sc_subject_id);
				Mmap.put("bundle_prefix", bundleprefix);

			}

		}

		int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());

		if (esid_sub_subject_id != 0) {
			List<SUB_SUBJECT_MST> SubSubject = comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
			String sub_subject_name = SubSubject.get(0).getSub_subject();
			Mmap.put("sub_subject_name", sub_subject_name);
		}
		Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));

		Mmap.put("msg", msg);
		return new ModelAndView("StickerGenerationTiles");

	}

	@RequestMapping(value = "/getBundleNoByBagNoInStickerGeneration", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getBundleNoByBagNo(String bundle_packing_id, HttpSession session) {

		int esid_es_id = Integer.parseInt(
				session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		if (esid_es_id != 0) {
			String userId = session.getAttribute("userId").toString();
			String role = session.getAttribute("role").toString();
			ArrayList<ArrayList<String>> list = ismDao.getBunldeNoByPackingBundle(esid_es_id, Integer.parseInt(userId),
					bundle_packing_id, role);
			return list;

		}
		return null;

	}
	
	
	@RequestMapping(value = "/getIndexNoInStickerGeneration", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getIndexNoInStickerGeneration(String bundle_no_id, HttpSession session) {

		int esid_es_id = Integer.parseInt(
				session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		if (esid_es_id != 0) {
			String userId = session.getAttribute("userId").toString();
			String role = session.getAttribute("role").toString();
			ArrayList<ArrayList<String>> list = sgDao.getIndexNoByPackingBundle(esid_es_id, Integer.parseInt(userId),
					bundle_no_id, role);
			return list;

		}
		return null;
	}
	
	
	
	
	@RequestMapping(value = "/getApplicationNoInStickerGeneration", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getApplicationNoInStickerGeneration(String application_no, HttpSession session) {

		int esid_es_id = Integer.parseInt(
				session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		if (esid_es_id != 0) {
			String userId = session.getAttribute("userId").toString();
			String role = session.getAttribute("role").toString();
			ArrayList<ArrayList<String>> list = sgDao.getApplicationNoByPackingBundle(esid_es_id, Integer.parseInt(userId),
					application_no,subjectID, role);
			return list;

		}
		return null;
	}
	
	
	
}
