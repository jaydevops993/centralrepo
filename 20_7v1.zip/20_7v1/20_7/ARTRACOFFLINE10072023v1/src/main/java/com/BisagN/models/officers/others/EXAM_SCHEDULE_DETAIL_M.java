package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "exam_schedule_detail", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class EXAM_SCHEDULE_DETAIL_M {

      private int id;
      private int es_id;
      private int sc_subject_id;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date esd_date;
      private int esd_cutoff;
      private int esd_final_cutoff_dssc;
      private int esd_final_cutoff_tsoc;
      private String sc_is_applicable;
      private String sc_dssc_applicable;
      private String sc_tsoc_applicable;
      private int esd_status_id;
      private String esd_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date esd_creation_date;
      private String esd_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date esd_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getEs_id() {
           return es_id;
      }
      public void setEs_id(int es_id) {
	  this.es_id = es_id;
      }
      public int getSc_subject_id() {
           return sc_subject_id;
      }
      public void setSc_subject_id(int sc_subject_id) {
	  this.sc_subject_id = sc_subject_id;
      }
      public Date getEsd_date() {
           return esd_date;
      }
      public void setEsd_date(Date esd_date) {
	  this.esd_date = esd_date;
      }
      public int getEsd_cutoff() {
           return esd_cutoff;
      }
      public void setEsd_cutoff(int esd_cutoff) {
	  this.esd_cutoff = esd_cutoff;
      }
      public int getEsd_final_cutoff_dssc() {
           return esd_final_cutoff_dssc;
      }
      public void setEsd_final_cutoff_dssc(int esd_final_cutoff_dssc) {
	  this.esd_final_cutoff_dssc = esd_final_cutoff_dssc;
      }
      public int getEsd_final_cutoff_tsoc() {
           return esd_final_cutoff_tsoc;
      }
      public void setEsd_final_cutoff_tsoc(int esd_final_cutoff_tsoc) {
	  this.esd_final_cutoff_tsoc = esd_final_cutoff_tsoc;
      }
      public String getSc_is_applicable() {
           return sc_is_applicable;
      }
      public void setSc_is_applicable(String sc_is_applicable) {
	  this.sc_is_applicable = sc_is_applicable;
      }
      public String getSc_dssc_applicable() {
           return sc_dssc_applicable;
      }
      public void setSc_dssc_applicable(String sc_dssc_applicable) {
	  this.sc_dssc_applicable = sc_dssc_applicable;
      }
      public String getSc_tsoc_applicable() {
           return sc_tsoc_applicable;
      }
      public void setSc_tsoc_applicable(String sc_tsoc_applicable) {
	  this.sc_tsoc_applicable = sc_tsoc_applicable;
      }
      public int getEsd_status_id() {
           return esd_status_id;
      }
      public void setEsd_status_id(int esd_status_id) {
	  this.esd_status_id = esd_status_id;
      }
      public String getEsd_created_by() {
           return esd_created_by;
      }
      public void setEsd_created_by(String esd_created_by) {
	  this.esd_created_by = esd_created_by;
      }
      public Date getEsd_creation_date() {
           return esd_creation_date;
      }
      public void setEsd_creation_date(Date esd_creation_date) {
	  this.esd_creation_date = esd_creation_date;
      }
      public String getEsd_modified_by() {
           return esd_modified_by;
      }
      public void setEsd_modified_by(String esd_modified_by) {
	  this.esd_modified_by = esd_modified_by;
      }
      public Date getEsd_modification_date() {
           return esd_modification_date;
      }
      public void setEsd_modification_date(Date esd_modification_date) {
	  this.esd_modification_date = esd_modification_date;
      }
}
