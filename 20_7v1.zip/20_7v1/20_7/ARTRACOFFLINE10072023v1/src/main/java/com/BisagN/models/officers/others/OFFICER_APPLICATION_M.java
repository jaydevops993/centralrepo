package com.BisagN.models.officers.others;


import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "officer_application", uniqueConstraints = {
@UniqueConstraint(columnNames = "oa_application_id"),})

public class OFFICER_APPLICATION_M {

    
      private int oa_application_id;
      private int in_index_id;
      private int es_id;
      private int oa_app_id;
      private int opd_personal_id;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date oa_application_date;
      private int oa_center_opted;
      private int oa_center_granted;
      private int oa_eligible;
      private int oa_dssc_eligible;
      private int oa_tsoc_eligible;
      private int oa_might_be_eligible;
      private String oa_remarks;
      private int oa_status_id;
      private String oa_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date oa_creation_date;
      private String oa_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date oa_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "oa_application_id", unique = true, nullable = false)


     
      public int getOa_application_id() {
           return oa_application_id;
      }
      public void setOa_application_id(int oa_application_id) {
	  this.oa_application_id = oa_application_id;
      }
      public int getIn_index_id() {
           return in_index_id;
      }
      public void setIn_index_id(int in_index_id) {
	  this.in_index_id = in_index_id;
      }
      public int getEs_id() {
           return es_id;
      }
      public void setEs_id(int es_id) {
	  this.es_id = es_id;
      }
      public int getOa_app_id() {
           return oa_app_id;
      }
      public void setOa_app_id(int oa_app_id) {
	  this.oa_app_id = oa_app_id;
      }
      public int getOpd_personal_id() {
           return opd_personal_id;
      }
      public void setOpd_personal_id(int opd_personal_id) {
	  this.opd_personal_id = opd_personal_id;
      }
      public Date getOa_application_date() {
           return oa_application_date;
      }
      public void setOa_application_date(Date oa_application_date) {
	  this.oa_application_date = oa_application_date;
      }
      public int getOa_center_opted() {
           return oa_center_opted;
      }
      public void setOa_center_opted(int oa_center_opted) {
	  this.oa_center_opted = oa_center_opted;
      }
      public int getOa_center_granted() {
           return oa_center_granted;
      }
      public void setOa_center_granted(int oa_center_granted) {
	  this.oa_center_granted = oa_center_granted;
      }
      public int getOa_eligible() {
           return oa_eligible;
      }
      public void setOa_eligible(int oa_eligible) {
	  this.oa_eligible = oa_eligible;
      }
      public int getOa_dssc_eligible() {
           return oa_dssc_eligible;
      }
      public void setOa_dssc_eligible(int oa_dssc_eligible) {
	  this.oa_dssc_eligible = oa_dssc_eligible;
      }
      public int getOa_tsoc_eligible() {
           return oa_tsoc_eligible;
      }
      public void setOa_tsoc_eligible(int oa_tsoc_eligible) {
	  this.oa_tsoc_eligible = oa_tsoc_eligible;
      }
      public int getOa_might_be_eligible() {
           return oa_might_be_eligible;
      }
      public void setOa_might_be_eligible(int oa_might_be_eligible) {
	  this.oa_might_be_eligible = oa_might_be_eligible;
      }
      public String getOa_remarks() {
           return oa_remarks;
      }
      public void setOa_remarks(String oa_remarks) {
	  this.oa_remarks = oa_remarks;
      }
      public int getOa_status_id() {
           return oa_status_id;
      }
      public void setOa_status_id(int oa_status_id) {
	  this.oa_status_id = oa_status_id;
      }
      public String getOa_created_by() {
           return oa_created_by;
      }
      public void setOa_created_by(String oa_created_by) {
	  this.oa_created_by = oa_created_by;
      }
      public Date getOa_creation_date() {
           return oa_creation_date;
      }
      public void setOa_creation_date(Date oa_creation_date) {
	  this.oa_creation_date = oa_creation_date;
      }
      public String getOa_modified_by() {
           return oa_modified_by;
      }
      public void setOa_modified_by(String oa_modified_by) {
	  this.oa_modified_by = oa_modified_by;
      }
      public Date getOa_modification_date() {
           return oa_modification_date;
      }
      public void setOa_modification_date(Date oa_modification_date) {
	  this.oa_modification_date = oa_modification_date;
      }
}
