package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.others.ExaminationlockunlockDAO;
import com.BisagN.dao.officer.others.ExaminationschedulepartdDao;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;

@Controller
@RequestMapping(value = { "admin", "/", "user" })

public class ExmschedulelockunlockController {
	@Autowired
	private ExaminationlockunlockDAO objDAO;

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private RoleBaseMenuDAO roledao; 

	@Autowired
	CommonController comm = new CommonController();

	@RequestMapping(value = "/ExmschedulelockunlockUrl", method = RequestMethod.GET)
	public ModelAndView ExmschedulelockunlockUrl(ModelMap Mmap,HttpServletRequest request, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		
		 if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

    	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("ExmschedulelockunlockUrl", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}
		
		
		Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
		Mmap.put("msg", msg);
		return new ModelAndView("Exmschedukelockunlocktiles");
	}

	@RequestMapping(value = "/getbegindate", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getbegindatefrmexmschedule(String exm, HttpSession session) {
		int ec_exam_id = Integer.parseInt(
				session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());

		ArrayList<ArrayList<String>> list2 = objDAO.getbegindatefrmexmschedule(Integer.parseInt(exm));

		return list2;
	}

	@RequestMapping(value = "/ExmschedulelockunlockAction", method = RequestMethod.POST)
	public ModelAndView ExmschedulelockunlockAction(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, HttpServletRequest request)
			throws ParseException {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();

		String exm_id = request.getParameter("ec_exam_id1");

		String exm_schid = request.getParameter("exam_schedule_dt");
		String exmsch_id = request.getParameter("exmsch_id");

		if (exm_id.equals("0")) {
			Mmap.put("msg", "Please Select Exam Name");
			return new ModelAndView("redirect:ExmschedulelockunlockUrl");
		}

		if (exm_schid.equals("0")) {
			Mmap.put("msg", "Please Select Exam Schedule");
			return new ModelAndView("redirect:ExmschedulelockunlockUrl");
		}

		Query qry = sessionHQL.createQuery("update EXAM_SCHEDULE  set es_status_id=:es_status_id where  id=:id");
		qry.setParameter("es_status_id", 1);

		qry.setParameter("id", Integer.parseInt(exmsch_id));

		qry.executeUpdate();

		Query qry1 = sessionHQL.createQuery("update EXAM_SCHEDULE  set es_status_id=:es_status_id where  id !=:id");
		qry1.setParameter("es_status_id", 0);

		qry1.setParameter("id", Integer.parseInt(exmsch_id));
		qry1.executeUpdate();

		Mmap.put("msg", msg);

		Mmap.put("msg", "Examination Schedule Unlock Successfully");
		tx.commit();

		EXAM_SCHEDULE ewid = (EXAM_SCHEDULE) sessionHQL.get(EXAM_SCHEDULE.class, Integer.parseInt(exm_schid));
		request.getSession().setAttribute("es_id", ewid.getEs_id());
		request.getSession().setAttribute("ec_exam_id", ewid.getEc_exam_id());
		request.getSession().setAttribute("es_begin_date", ewid.getEs_begin_date());
		

		return new ModelAndView("redirect:ExmschedulelockunlockUrl");

	}

	@RequestMapping(value = "/getstatusforlkun", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getstatusfrmexmschedule(String exm) {

		ArrayList<ArrayList<String>> list2 = objDAO.getstatusfrmexmschedule(exm);

		return list2;
	}

	@RequestMapping(value = "/getbegindateforlockunlock", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getbegindatefrmexmschedule() {

		ArrayList<ArrayList<String>> list2 = objDAO.getbegindatefrmexmschedule(0);

		return list2;
	}

}
