
package com.BisagN.controller.office.reports;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.itextpdf.text.pdf.PdfGState;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPTableEvent;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;
public class WrongApperiance_Controller_Pdf extends AbstractPdfView{

		String Type = "";
		List<String> TH;
		String Heading = "";
		String username = "";
		final static String USER_PASSWORD = "user";
		final static String OWNER_PASSWORD = "owner";
		public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

		public WrongApperiance_Controller_Pdf(String Type, List<String> TH, String Heading, String username) {
			this.Type = Type;
			this.TH = TH; 	
			this.Heading = Heading;
			this.username = username;
		}

		protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
			
			document.open();
			if (Type.equals("L")) {
				document.setPageSize(PageSize.A3); // set document landscape
			}
			document.setPageSize(PageSize.A4.rotate());
			super.buildPdfMetadata(model, document, request);
		}

		@Override
		protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
				HttpServletRequest request, HttpServletResponse response) throws Exception {

			DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
			String file_name = datetimestamp.currentDateWithTimeStampString();

			
			response.setContentType("application/pdf");
	//	response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");

			
			
			
			
			Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
			Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
			Font fontTableHeadingSubMainHead = FontFactory.getFont(FontFactory.TIMES_BOLD, 12);;
			
			
			PdfPTable table = new PdfPTable(1);
			table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			table.setWidthPercentage(100);
			
			

			PdfPTable tabledata = new PdfPTable(1);
			tabledata.setWidths(new int[] {5});
			tabledata.setWidthPercentage(100/ 3.5f);
			tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata.setHorizontalAlignment(Element.ALIGN_RIGHT);
			tabledata.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			
			//Chunk underline = new Chunk("Appendix 'A' " +"\n"+ "Refers to Para 1(a) of IHQ MoD(Army)" +"\n"+ "DGMT(MT-2)" +"\n"+ "Leter No A/16014/B/2019/GS/MT-2" +"\n"+ "Dated 19 Sep 2019)", fontTableHeading1);
			
		

			
			 Paragraph head1 = new Paragraph("Appendix 'D'");
			 Paragraph head2 = new Paragraph("Refers to Para 1(d) of IHQ MoD(Army)");
			 Paragraph head3 = new Paragraph("DGMT(MT-2)");
			 Paragraph head4 = new Paragraph("Leter No A/16014/B/2019/GS/MT-2");
			 Paragraph head5 = new Paragraph("Dated 12 sep 2019");
			 
			tabledata.addCell(head1);
			tabledata.addCell(head2);
			tabledata.addCell(head3);
			tabledata.addCell(head4);
			tabledata.addCell(head5);
			
			
			
			Chunk chunk = new Chunk();
			
			Chunk glue = new Chunk(new VerticalPositionMark());
					
			Chunk underline1 = new Chunk("DIRECTORATE GENERAL OF MILITARY TRAINING MT-2" +"\n"+ "PROMOTION EXAMINATION PART B-2019" +"\n"+ "WRONG APPEARANCES" , fontTableHeadingSubMainHead);	 
					
			Phrase ph = new Phrase(underline1);
			ph.setFont(fontTableHeading1);
			Paragraph cell = new Paragraph(ph);
			cell.setAlignment(Element.ALIGN_LEFT);
			
			PdfPTable tableheader = new PdfPTable(1);
			tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			tableheader.setWidthPercentage(100);
			tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tableheader.addCell(cell);
		
			
			
			
			PdfPTable tabledata1 = new PdfPTable(8);
			tabledata1.setWidths(new int[] {4,4,4,4,4,4,4,4});
			tabledata1.setWidthPercentage(100);
			tabledata1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata1.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		
			
		
			Paragraph a = new Paragraph("S.No",fontTableHeadingSubMainHead);
			Paragraph b = new Paragraph("Personal No ",fontTableHeadingSubMainHead);
			Paragraph c = new Paragraph("Rank",fontTableHeadingSubMainHead);
			Paragraph d = new Paragraph("Name",fontTableHeadingSubMainHead);
			Paragraph e = new Paragraph("Arm ",fontTableHeadingSubMainHead);
			Paragraph f = new Paragraph("Centre",fontTableHeadingSubMainHead);
			Paragraph g = new Paragraph("Command",fontTableHeadingSubMainHead);
			Paragraph h = new Paragraph("Subject",fontTableHeadingSubMainHead);
			
			
			tabledata1.addCell(a);
			 tabledata1.addCell(b);
			 tabledata1.addCell(c);
			 tabledata1.addCell(d);
			 tabledata1.addCell(e);
			 tabledata1.addCell(f);
			 tabledata1.addCell(g);
			 tabledata1.addCell(h);
			
			
			 
			 //data bind
			 
			 
			 Paragraph a1 = new Paragraph("1");
				Paragraph b1 = new Paragraph("  ");
				Paragraph c1 = new Paragraph(" ");
				Paragraph d1= new Paragraph(" ");
				Paragraph e1 = new Paragraph("   ");
				Paragraph f1 = new Paragraph(" ");
				Paragraph g1 = new Paragraph(" ");
				Paragraph h1 = new Paragraph(" ");
				
				
				tabledata1.addCell(a1);
				 tabledata1.addCell(b1);
				 tabledata1.addCell(c1);
				 tabledata1.addCell(d1);
				 tabledata1.addCell(e1);
				 tabledata1.addCell(f1);
				 tabledata1.addCell(g1);
				 tabledata1.addCell(h1);
				 
				
				
				 
				 
			PdfPCell cell123;
			cell123 = new PdfPCell();
			cell123.addElement(tabledata);
			cell123.addElement(new Paragraph("\n"));
			cell123.addElement(tableheader);
			cell123.addElement(new Paragraph("\n"));
			cell123.addElement(tabledata1);
			cell123.addElement(new Paragraph("\n"));
			cell123.setBorder(0);
			table.addCell(cell123);
			


		
		document.add(table);
		super.buildPdfMetadata(model, document, request);
		}



}

