package com.BisagN.dao.officer.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface ExportPartBDao {
	public ArrayList<ArrayList<String>> getbegindateforexport(String exm_id) ;
	public  ArrayList<ArrayList<String>>  getexportPartBexmCandidateReport(int startPage,String pageLength,String Search,String orderColunm,String orderType, 
			String exam_schedule_dt,String min_year2, String es_consider_date1,int es_id,String table,String btn_value,String max_year2,
			HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, 
	InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	public long getexportPartbexmCandidatereportTotalCount(String Search,  String exam_schedule_dt,String min_year2, String es_consider_date1,int es_id,
			String btn_value,String max_year2);
	public ArrayList<ArrayList<String>> getRulesDetailsFromExmSchedule(String exmsch_dt,String exm_id,String dssc_date);
	public ArrayList<ArrayList<String>> getExportPartBForExcel(int es_id);
}
