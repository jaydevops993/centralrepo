package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "qualified_officers_dssc", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class QUALIFIED_OFFICERS_DSSC_M {

      private int id;
      private int qod_id;
      private int es_id;
      private int qod_dssc;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getQod_id() {
           return qod_id;
      }
      public void setQod_id(int qod_id) {
	  this.qod_id = qod_id;
      }
      public int getEs_id() {
           return es_id;
      }
      public void setEs_id(int es_id) {
	  this.es_id = es_id;
      }
      public int getQod_dssc() {
           return qod_dssc;
      }
      public void setQod_dssc(int qod_dssc) {
	  this.qod_dssc = qod_dssc;
      }
}
