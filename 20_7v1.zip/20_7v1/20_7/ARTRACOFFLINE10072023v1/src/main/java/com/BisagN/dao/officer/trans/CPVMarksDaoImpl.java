package com.BisagN.dao.officer.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.persistence.Query;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Service
public class CPVMarksDaoImpl implements CPVMarksDao {
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

CommonController comm= new CommonController();


@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;



public boolean checkIsIntegerValue(String Search) {
return Search.matches("[0-9]+");
}


public List<Map<String, Object>> getCPVmarksDetails(int startPage,String pageLength,String Search,String orderColunm,String orderType,String pers_no,String opd_officer_name,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	if(pageLength.equals("-1")){
		pageLength = "ALL";
	}
	String SearchValue = GenerateQueryWhereClause_SQL(Search);

	List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
	Connection conn = null;
	String q = "";
	String q1 = "";
	String q2 = "";
	String q3 = "";
	
	try {
		
			if (!pers_no.equals("")) {			
			
			//using commaon controller searchwithout zero
				pers_no=comm.getSearchIcNumberwithoutZero(pers_no);
			 System.err.println("opc_code==========="+pers_no);
				 
		}		
		if(!pers_no.equals("")) {
			
			q1="and lower(ofc.opc_personal_code)like ?";
		}
		if(!opd_officer_name.equals("")) {
			
			q2="and  lower(ofc.opd_officer_name)like ?";
			}
		
		
		conn = dataSource.getConnection();
		q = "select cpv.id, ofc.opc_personal_code,ofc.opc_suffix_code,ofc.opd_officer_name, cpv.cpv_mks from cpv\n"
				+ "inner join vw_personal_details ofc on ofc.opd_personal_id = cpv.opd_personal_id "+q1+" "+q2+"  "+SearchValue+" ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereClause_SQL(stmt,Search);
		
		if(!pers_no.equals("")) {
			stmt.setString(1, pers_no.toLowerCase());
		}
		
		if(!opd_officer_name.equals("")) {
			stmt.setString(1,"%"+ opd_officer_name.toLowerCase() + "%");
		}

		
		ResultSet rs = stmt.executeQuery();
		
		System.err.println("stmt=========="+stmt);
		
		ResultSetMetaData metaData = rs.getMetaData();
		int columnCount = metaData.getColumnCount();
		while (rs.next()) {
			Map<String, Object> columns = new LinkedHashMap<String, Object>();
			for (int i = 1; i <= columnCount; i++) {
			    columns.put(metaData.getColumnLabel(i), rs.getObject(i));
			}
                 String enckey ="commonPwdEncKeys";
                   Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
                   String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("id").toString().getBytes())));
//                 String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"+EncryptedPk+"')}else{ return false;}\""; 
//                 String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
                 String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('"+EncryptedPk+"')}else{ return false;}\""; 
                 String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>"; 
                 String f = "";
                 //===================chnage j=======//
                 String f1 = "";
                 f += updateButton;
//               f += deleteButton;

               String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
      			String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));
     			f1 += opc_code;
                 columns.put("action",f);
                 columns.put("opc_code",f1);
                columns.put(metaData.getColumnLabel(1), f);
		list.add(columns);
		
}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {
e.printStackTrace();
} finally {
if (conn != null) {
try {
conn.close();
} catch (SQLException e) {
}
}
}
return list;
}


public long getgetCPVmarksDetailsTotalCount(String Search,String pers_no, String opd_officer_name) {
	String SearchValue = GenerateQueryWhereClause_SQL(Search);
	int total = 0;
	String q = null;
	Connection conn = null;
	
	
	String q1 = "";
	String q2 = "";
	String q3 = "";
	
	try {
		
		if (!pers_no.equals("")) {
			
			String Data=pers_no.toString();
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(2);
			}

			pers_no=DataPre+"%"+DataM;
			 
		}
		
		
      if(!pers_no.equals("")) {
			
			q1="and lower(ofc.opc_personal_code)like ?";
		}
		if(!opd_officer_name.equals("")) {
			
			q2="and  lower(ofc.opd_officer_name)like ?";
			}
		
		conn = dataSource.getConnection();
		q ="select count(*) from (select ofc.opc_personal_code,ofc.opd_officer_name, cpv.cpv_mks from cpv\n"
				+ "inner join vw_personal_details ofc on ofc.opd_personal_id = cpv.opd_personal_id   "+q1+" "+q2+" "+SearchValue +") ab " ;
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereClause_SQL(stmt,Search);
		
System.err.println("stmt====================="+stmt);
		
		if(!pers_no.equals("")) {
			stmt.setString(1, pers_no.toLowerCase());
//			stmt.setString(1, "%"+pers_no.toLowerCase()+"%");
		}
		
		if(!opd_officer_name.equals("")) {
			stmt.setString(1,"%"+ opd_officer_name.toLowerCase() + "%");
		}

		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			total = rs.getInt(1);
		}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
		}
		}
		return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search) {
	String SearchValue ="";
		if(!Search.equals("")) {
		Search = Search.toLowerCase();
			SearchValue =" where ( ";
			if(checkIsIntegerValue(Search)) {
				SearchValue +=" id=? or ";
			}
			
			
			
			
			
			
//String opd_personal_id = "";  			
//           if(checkIsIntegerValue(Search)) {
//				opd_personal_id +="lower(ofc.opc_personal_code)like ? or ";
//			}
//		SearchValue +=" "+opd_personal_id+"lower(pcc_area) like ? or   to_char(pcc_area_entry_date,'dd-MM-yyyy') like ? or to_char(pcc_area_leave_date,'dd-MM-yyyy') like ? or lower(pcc_remarks) like ?  )";
           SearchValue +=" lower(ofc.opc_personal_code)like ? or lower(ofc.opd_officer_name) like ?  or (cpv.cpv_mks::text) like ?  )";
	}
return SearchValue;
}


	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search) {
		int flag = 0;
		try {
			if(!Search.equals("")) {
				if(checkIsIntegerValue(Search)) {
					flag += 1;
					stmt.setInt(flag, Integer.parseInt(Search));
				}
//				if(checkIsIntegerValue(Search)) {
//					flag += 1;
//					stmt.setInt(flag, Integer.parseInt(Search));
//				}
				flag += 1;
//				String pers_no = "";
//				if (!Search.equals("")) {
//					
//					String Data=Search.toString();
//					String DataPre="";
//					String DataM="";
//					if(Data.contains("NTR") || Data.contains("NTS")) {
//						DataPre= Data.substring(0,3);
//						DataM = Data.substring(4);
//					}else {
//						DataPre= Data.substring(0,2);
//						DataM = Data.substring(2);
//					}
	//
//					  pers_no=DataPre+"%"+DataM;
//					
//				}
				Search=comm.getSearchIcNumberwithoutZero(Search);

				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				
				flag += 1;
				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				flag += 1;
				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				flag += 1;
				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				flag += 1;
				stmt.setString(flag, "%"+Search.toLowerCase()+"%");

			}
		}catch (Exception e) {}
		return stmt;
	}

public ArrayList<ArrayList<String>> getPartDAttmptCountForCPV(int opd_persid) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();

	Connection conn = null;
	String q = "";
	String qry = "";

	try {
		
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		
	q="select (count(ofa.opd_personal_id)-count(pbdch.opd_personal_id)filter(where pbdch.ec_exam_id=2)) as FinalCount,  \n"
			+ "count(ofa.opd_personal_id) as partD,\n"
			+ "count(pbdch.opd_personal_id)filter(where pbdch.ec_exam_id=2) as CompCount from officer_application ofa \n"
			+ "inner join exam_schedule es on es.es_id = ofa.es_id\n"
			+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
			+ "left join partbd_compens_chance pbdch on pbdch.opd_personal_id = ofa.opd_personal_id\n"
			+ "where es.ec_exam_id=2 and ofa.opd_personal_id=? and vpd.opd_partd != 0 ";

		stmt = conn.prepareStatement(q);
		stmt.setInt(1, opd_persid);
		System.err.println("course==========="+stmt);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();

			list.add(rs.getString("FinalCount"));// 0
			list.add(rs.getString("partD"));// 0
			list.add(rs.getString("CompCount"));// 0
		
			
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;

}
@Override
public void generateMerit(String[] cols) {
	
	
	Transaction tx = null;
	Query que = null;
	System.out.println("Coulmn 1= " + cols[0] + " , Column2=" + cols[1] + ", column 3 " + cols[2]
			+ " ,column 4 " + cols[3] + "");
	Session session = this.sessionFactory.openSession();

//	int opd_persId = (int) session
//			.createSQLQuery("select id from officer_application where oa_application_id =  " + cols[0])
//			.uniqueResult();

		


			tx = session.beginTransaction();

			que = session.createSQLQuery("INSERT INTO public.answer_book(\n"
					+ "	 oa_application_id, sc_subject_id, ab_first_entry, ab_marks_obtained, ab_status_id)\n" + "	VALUES (" + cols[0]
					+ ","+cols[1]+"," + cols[2] +"," + cols[2] +","+cols[3]+") ");
	

			que.executeUpdate();
			tx.commit();


		
	

	}
}
