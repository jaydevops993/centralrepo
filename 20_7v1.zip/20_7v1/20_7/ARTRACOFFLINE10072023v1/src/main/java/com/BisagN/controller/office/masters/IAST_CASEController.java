package com.BisagN.controller.office.masters;

import java.io.File;
import java.io.FileInputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.IAST_CasesDAO;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.models.officers.masters.ARM_CODES_M;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.masters.RANK_CODE_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.TBL_ARM_HISTORY_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class IAST_CASEController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	CommonController comm = new CommonController();

	@Autowired
	private Officer_personal_detailsDAO ofc_Dao;

	@Autowired
	private RoleBaseMenuDAO roledao;

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

	@Autowired
	private IAST_CasesDAO iastDao;

	@Autowired
	private Officer_personal_detailsDAO opdDAO;

	@RequestMapping(value = "IAST_CASEofficer_personal_detailsUrl", method = RequestMethod.GET)
	public ModelAndView IAST_CASEofficer_personal_detailsUrl(ModelMap Mmap, HttpSession session,
			HttpServletRequest request, @RequestParam(value = "msg", required = false) String msg, String opd_pers_no1,
			String opd_name1) {
		try {

			if (request.getHeader("Referer") == null) {
				session.invalidate();
				Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
				return new ModelAndView("redirect:/login");
			}

			String roleid1 = session.getAttribute("roleid").toString();
			Boolean val = roledao.ScreenRedirect("IAST_CASEofficer_personal_detailsUrl", roleid1);
			if (val == false) {
				return new ModelAndView("AccessTiles");
			}

			Mmap.put("msg", msg);
			Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL(sessionFactory));

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("IAST_Case_tile");
	}

	@RequestMapping(value = "/getOfficer_personal_detailsForIASTCaseList", method = RequestMethod.POST)
	public @ResponseBody List<Map<String, Object>> getOfficer_personal_detailsReportDataList(int startPage,
			String pageLength, String Search, String orderColunm, String orderType, String pers_no, String pers_name,
			HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		return iastDao.getReportListOfficer_personal_detailsForIAST(startPage, pageLength, Search, orderColunm,
				orderType, pers_no, pers_name, sessionUserId);
	}

	@RequestMapping(value = "/getOfficer_personal_detailsForIASTCaseTotalCount", method = RequestMethod.POST)
	public @ResponseBody long getOfficer_personal_detailsTotalCount(HttpSession sessionUserId, String Search,
			String pers_no, String pers_name) {
		return iastDao.getIASTCaseOfficer_personal_detailsTotalCount(Search, pers_no, pers_name);
	}

	// Download DEMO EXCEL
	@RequestMapping(value = "/DemoCandidateExcelFORIAST", method = RequestMethod.POST)
	public ModelAndView DemoCandidateExcelFORIAST(HttpServletRequest request, ModelMap model, HttpSession session,
			String typeReport1) {

//			int abc = comm.getsubjectlist().size();
//			
		ArrayList<ArrayList<String>> listexport = new ArrayList<ArrayList<String>>();
		List<String> TH = new ArrayList<String>();
		TH.add("SER_NO");

		TH.add("PERSONAL_NO");
		TH.add("SUFFIX_CODE");
		TH.add("RANK");
		TH.add("OFFICER_NAME");
		TH.add("PREVIOUS_ARM_SERVICE");
		TH.add("NEW_ARM_SERVICE");
		TH.add("DATE_OF_CHNAGE_OF_ARM");

		String Heading = "\n";
		String username = session.getAttribute("username").toString();
		return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList",
				listexport);
	}

	@RequestMapping(value = "EditIAST_CASEOfficer_personal_detailsUrl", method = RequestMethod.POST)
	public ModelAndView EditIAST_CASEOfficer_personal_detailsUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String updateid) {

		System.out.println("updateid--------------------------" + updateid);
		Session s1 = this.sessionFactory.openSession();
		Transaction tx = s1.beginTransaction();
		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);
		Query q = null;
		q = s1.createQuery("from OFFICER_PERSONAL_DETAILS_M where cast(id as string)=:PK");
		q.setString("PK", DcryptedPk);
		@SuppressWarnings("unchecked")
		List<String> list = (List<String>) q.list();
		tx.commit();
		s1.close();

		Mmap.put("Edit_pers_details", opdDAO.getarmcodeforIASTcase(DcryptedPk));
		Mmap.put("Editofficer_personal_detailsCMD1", list.get(0));
		Mmap.put("Edit_pers_details", opdDAO.getpersdetails(DcryptedPk));
		Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL(sessionFactory));
		Mmap.put("getctranktypeListDDL", comm.getctranktypeListDDL(sessionFactory));
		Mmap.put("getPersonalType", comm.getPersonalType(sessionFactory));
		Mmap.put("msg", msg);
		Mmap.put("opd_id", DcryptedPk);
		return new ModelAndView("EDIT_IAST_Case_tile", "editIASTBCMD", new OFFICER_PERSONAL_DETAILS_M());
	}

	@RequestMapping(value = "/EditIASTCasesAction", method = RequestMethod.POST)
	public ModelAndView EditIASTCasesAction(@Valid @ModelAttribute("editIASTBCMD") TBL_ARM_HISTORY_M arm_his,
			BindingResult result, HttpServletRequest request, ModelMap model, HttpSession session) {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();

		String curarmscode1 = request.getParameter("curarmscode");
		if (curarmscode1 == "" || curarmscode1.equals("0")) {
			model.put("msg", "Please Select New Arm/Service");
			return new ModelAndView("redirect:IAST_CASEofficer_personal_detailsUrl");
		}

		String arm_chnage_date1 = request.getParameter("arm_chnage_date");
		if (arm_chnage_date1.equals("DD/MM/YYYY") || arm_chnage_date1.equals("") || arm_chnage_date1 == ""
				|| arm_chnage_date1 == "DD/MM/YYYY") {
			model.put("msg", "Please Select BID Start Date");
			return new ModelAndView("redirect:IAST_CASEofficer_personal_detailsUrl");
		}
		String auth_letter_no = request.getParameter("auth_letter_no");
		if (auth_letter_no == "" || auth_letter_no.equals("")) {
			model.put("msg", "Please Enter Auth (Letter No)");
			return new ModelAndView("redirect:IAST_CASEofficer_personal_detailsUrl");
		}

		try {
			String prvarmscode = request.getParameter("prvarmscode");

			String curarmscode = request.getParameter("curarmscode");
			String opd_id = request.getParameter("opd_id");

			int id = arm_his.getHrid() > 0 ? arm_his.getHrid() : 0;
			Date date = new Date();
			String username = session.getAttribute("username").toString();

			try {

				if (id == 0) {

					System.err.println("opd_personal_id---------------" + opd_id);

					String hq1l = "update OFFICER_ARM_M set ac_arm_id=:ac_arm_id  where opd_personal_id=:opd_personal_id ";
					Query query1 = sessionHQL.createQuery(hq1l).setParameter("ac_arm_id", Integer.parseInt(curarmscode))
							.setParameter("opd_personal_id", Integer.parseInt(opd_id));
					query1.executeUpdate();

					String arm_chnage_date = request.getParameter("arm_chnage_date");

					TBL_ARM_HISTORY_M arm_hist = new TBL_ARM_HISTORY_M();

					String oldarm = request.getParameter("prvarmscode");
					arm_hist.setPrvarmscode(Integer.parseInt(oldarm));
					arm_hist.setOpd_personal_id(Integer.parseInt(opd_id));
					arm_hist.setCurarmscode(Integer.parseInt(curarmscode));
					arm_hist.setUpdatedby(username);
					arm_hist.setUpdateddate(date);
					arm_hist.setArm_chnage_date(comm.convertStringToDate(arm_chnage_date));
					arm_hist.setAuth_letter_no(request.getParameter("auth_letter_no"));
					sessionHQL.save(arm_hist);
					tx.commit();

					model.put("msg", "Data Updated Successfully.");

				}

			} catch (RuntimeException e) {
				try {
					tx.rollback();
					model.put("msg", "roll back transaction");
				} catch (RuntimeException rbe) {
					model.put("msg", "Couldn�t roll back transaction " + rbe);
				}
				throw e;
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("redirect:IAST_CASEofficer_personal_detailsUrl");

	}

	@RequestMapping(value = "UploadIASTCaseFileURL", method = RequestMethod.GET)
	public ModelAndView UploadIASTCaseFileURL(ModelMap Mmap, HttpServletRequest request, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String Subjectid) {

		Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		if (flashMap != null) {
			ArrayList<ArrayList<String>> errorList = (ArrayList<ArrayList<String>>) flashMap.get("errorlist");
			System.out.println("===================" + errorList);
			// return "home";
			Mmap.put("errorList", errorList);
		}

		Mmap.put("msg", msg);
		return new ModelAndView("Upload_IAST_Casesfile_tile");
	}

	// UPLOAD CANDIDATE DATA
	@RequestMapping(value = "/UploadIASTCAsesAction", method = RequestMethod.POST)
	public ModelAndView UploadIASTCAsesAction(HttpServletRequest request, ModelMap model, HttpSession session,
			RedirectAttributes ra, @RequestParam(value = "fileUpload", required = false) MultipartFile fileUpload) {

		Session sessionHQL = this.sessionFactory.openSession();

		ArrayList<ArrayList<String>> listerror = new ArrayList<ArrayList<String>>();

//				if(fileUpload==null) {
//					 model.put("msg","Please Upload Copy Of File Upload");
//					  return new ModelAndView("redirect:IAST_CASEofficer_personal_detailsUrl");
//				  }

//				if(fileUpload.isEmpty()) {
//					model.put("msg","Please Upload Copy Of File Upload");
//					  return new ModelAndView("redirect:IAST_CASEofficer_personal_detailsUrl");
//				}
		
		
		if(fileUpload.isEmpty()) {
			ra.addAttribute("msg","Please Upload Copy Of File Upload");
			  return new ModelAndView("redirect:UploadIASTCaseFileURL");
		}
		

		try {

			Date date = new Date();
			String username = session.getAttribute("username").toString();

			DateFormat format = new SimpleDateFormat("dd/MM/yyyy");

			int errorcount = 0;
			int succeesscount = 0;
			String errormsg = "";
			int count_duplicate = 0;

			File file = new File(
					comm.fileupload2(fileUpload.getBytes(), fileUpload.getOriginalFilename(), "doc_contract", ""));
			FileInputStream fis = new FileInputStream(file);
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheetAt(0);
			Row row_head = sheet.getRow(0);

			String personal_no = "";
			String suffixcode = "";
			String rank = "";
			String officer_name = "";
			String pre_arm_service = "";
			String new_arm_service = "";
			String date_change_arm_service = "";

			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				Transaction tx = sessionHQL.beginTransaction();
				ArrayList<String> listData = new ArrayList<String>();
				Row row = sheet.getRow(i);

				if (row.getCell(0) == null) {
					break;
				}

				for (int j = 1; j < 8; j++) {

					Cell cell = row.getCell(j);

					String value = "";
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						value = cell.getStringCellValue();
						break;
					case Cell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							value = String.valueOf(cell.getDateCellValue());
						} else {
							value = String.valueOf((long) cell.getNumericCellValue());
						}
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						value = String.valueOf(cell.getBooleanCellValue());
						break;
					default:
					}

					if (row_head.getCell(j).getStringCellValue().equals("PERSONAL_NO")) {
						personal_no = value;
					}
					if (row_head.getCell(j).getStringCellValue().equals("SUFFIX_CODE")) {
						suffixcode = value;

					}
					if (row_head.getCell(j).getStringCellValue().equals("RANK")) {
						rank = value;
					}

					if (row_head.getCell(j).getStringCellValue().equals("OFFICER_NAME")) {
						officer_name = value;
					}

					if (row_head.getCell(j).getStringCellValue().equals("PREVIOUS_ARM_SERVICE")) {
						pre_arm_service = value;
					}
					if (row_head.getCell(j).getStringCellValue().equals("NEW_ARM_SERVICE")) {
						new_arm_service = value;

					}

					if (row_head.getCell(j).getStringCellValue().equals("DATE_OF_CHNAGE_OF_ARM")) {
						date_change_arm_service = value;

					}

				}
				List<OFFICER_PERSONAL_CODE_M> opdpers_id = comm.getopdIdbycode(sessionFactory, personal_no);
				System.err.println("new_arm_service============" + new_arm_service);
				System.err.println("date_change_arm_service============" + date_change_arm_service);

				if (opdpers_id.isEmpty()) {
					listData.add(personal_no);
					listData.add(suffixcode);
					listData.add(rank);
					listData.add(officer_name);
					listData.add(pre_arm_service);
					listData.add(new_arm_service);
					listData.add(date_change_arm_service);

					listData.add("The Personal Number is Wrong");
					errormsg = personal_no + "The Personal Number is Wrong";
					model.put("msg", errormsg);
					errorcount++;
				}

				else {
					System.err.println("pers_code===========" + opdpers_id.get(0).getOpd_personal_id());
					int opd_pers_id = opdpers_id.get(0).getOpd_personal_id();

					List<ARM_CODES_M> check_ac_arm_description = comm.getarmdetailsbyarmId(sessionFactory,
							new_arm_service);
					int new_arm_code_id = check_ac_arm_description.get(0).getAc_arm_id();

					List<ARM_CODES_M> pre_check_ac_arm_description = comm.getarmdetailsbyarmId(sessionFactory,
							pre_arm_service);
					int pre_arm_code_id = check_ac_arm_description.get(0).getAc_arm_id();

					long check_RankList = comm.getRankCountByRankName(sessionFactory, rank);
					String rank2 = String.valueOf(check_RankList);

					String hq1l = "update OFFICER_ARM_M set ac_arm_id=:ac_arm_id  where opd_personal_id=:opd_personal_id ";
					Query query1 = sessionHQL.createQuery(hq1l).setParameter("ac_arm_id", new_arm_code_id)
							.setParameter("opd_personal_id", opd_pers_id);
					query1.executeUpdate();

					TBL_ARM_HISTORY_M trm = new TBL_ARM_HISTORY_M();

					trm.setAuth_letter_no(request.getParameter("auth_letter_no"));
					trm.setPrvarmscode(pre_arm_code_id);
					trm.setCurarmscode(new_arm_code_id);
					trm.setArm_chnage_date(comm.convertStringToDate(date_change_arm_service));
					trm.setOpd_personal_id(opd_pers_id);
					sessionHQL.save(trm);
					ra.addAttribute("msg", "Data Save Successfully");

				}

				if (!listData.isEmpty()) {
					listerror.add(listData);
				}

				tx.commit();

			}

			System.err.println("o==========" + listerror);
			model.put("errorlist", listerror);

			model.put("errorlistSize", listerror.size());

		}

		catch (Exception e) {
			// tx.rollback();
			e.printStackTrace();
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		ra.addFlashAttribute("errorlist", listerror);
		return new ModelAndView("redirect:UploadIASTCaseFileURL");
	}
}
