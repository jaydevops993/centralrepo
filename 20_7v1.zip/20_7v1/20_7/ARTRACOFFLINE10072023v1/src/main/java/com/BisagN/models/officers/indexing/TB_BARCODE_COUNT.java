package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "tb_barcode_count", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})
public class TB_BARCODE_COUNT {
	private int id;
	private String barcode_no;
	private int opd_pers_id;
	private int es_id;
	private int oa_app_id;
	private String created_by;
	private Date created_date;
	private int brcd_status;
	private int opng_status;
	private String opng_by;
	private Date opng_date;

	private int close_status;
	private String close_by;
	private Date close_date;
	private int is_id;
	private int subject_id;
	private int sub_subject_id;
	private int print_status;

	@Id
     @GeneratedValue(strategy = IDENTITY)
     @Column(name = "id", unique = true, nullable = false)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBarcode_no() {
		return barcode_no;
	}
	public void setBarcode_no(String barcode_no) {
		this.barcode_no = barcode_no;
	}
	public int getOpd_pers_id() {
		return opd_pers_id;
	}
	public void setOpd_pers_id(int opd_pers_id) {
		this.opd_pers_id = opd_pers_id;
	}
	public int getEs_id() {
		return es_id;
	}
	public void setEs_id(int es_id) {
		this.es_id = es_id;
	}
	public int getOa_app_id() {
		return oa_app_id;
	}
	public void setOa_app_id(int oa_app_id) {
		this.oa_app_id = oa_app_id;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public int getBrcd_status() {
		return brcd_status;
	}
	public void setBrcd_status(int brcd_status) {
		this.brcd_status = brcd_status;
	}
	public int getOpng_status() {
		return opng_status;
	}
	public void setOpng_status(int opng_status) {
		this.opng_status = opng_status;
	}
	public String getOpng_by() {
		return opng_by;
	}
	public void setOpng_by(String opng_by) {
		this.opng_by = opng_by;
	}
	public Date getOpng_date() {
		return opng_date;
	}
	public void setOpng_date(Date opng_date) {
		this.opng_date = opng_date;
	}
	public int getClose_status() {
		return close_status;
	}
	public void setClose_status(int close_status) {
		this.close_status = close_status;
	}
	public String getClose_by() {
		return close_by;
	}
	public void setClose_by(String close_by) {
		this.close_by = close_by;
	}
	public Date getClose_date() {
		return close_date;
	}
	public void setClose_date(Date close_date) {
		this.close_date = close_date;
	}
	public int getIs_id() {
		return is_id;
	}
	public void setIs_id(int is_id) {
		this.is_id = is_id;
	}
	public int getSubject_id() {
		return subject_id;
	}
	public void setSubject_id(int subject_id) {
		this.subject_id = subject_id;
	}
	public int getSub_subject_id() {
		return sub_subject_id;
	}
	public void setSub_subject_id(int sub_subject_id) {
		this.sub_subject_id = sub_subject_id;
	}

	
	public int getPrint_status() {
		return print_status;
	}
	public void setPrint_status(int print_status) {
		this.print_status = print_status;
	}
	
	
	
}
