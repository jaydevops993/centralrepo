package com.BisagN.controller.office.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.officer.trans.Marks_entryDAO;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.trans.ANSWER_BOOK_M;




@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Marks_entryController {


@Autowired
private Marks_entryDAO objDAO;
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();


@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

         @RequestMapping(value = "Marks_entry_Url", method = RequestMethod.GET)
         public ModelAndView Marks_entry_Url(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
  NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

             Mmap.put("getscsubjectnameListDDL", getscsubjectnameListDDL(session));
             Mmap.put("msg", msg);
         return new ModelAndView("Marks_entry_tile","marks_entryCMD",new ANSWER_BOOK_M());
}
 public List<SUBJECT_CODE_M> getscsubjectnameListDDL(HttpSession sessionU) {
   	Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query q = session.createQuery("from SUBJECT_CODE_M order by sc_subject_id");
		@SuppressWarnings("unchecked")
		List<SUBJECT_CODE_M>  list = (List<SUBJECT_CODE_M>) q.list();
		tx.commit();
		session.close();
		return list;
	}
         @RequestMapping(value = "Searchmarks_entryUrl", method = RequestMethod.GET)
         public ModelAndView Searchmarks_entryUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
  NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

               Mmap.put("msg", msg);
         return new ModelAndView("SearchMarks_entry_tile","Searchmarks_entryCMD",new ANSWER_BOOK_M());
}
 @RequestMapping(value = "/getMarks_entryReportDataList", method = RequestMethod.POST)
 public @ResponseBody List<Map<String, Object>> getMarks_entryReportDataList(int startPage,String pageLength,String Search,String orderColunm,String orderType,HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
	return objDAO.getReportListMarks_entry(startPage,pageLength,Search,orderColunm,orderType,sessionUserId);
}

 @RequestMapping(value = "/getMarks_entryTotalCount", method = RequestMethod.POST)
public @ResponseBody long getMarks_entryTotalCount(HttpSession sessionUserId,String Search,String name){
	return objDAO.getReportListMarks_entryTotalCount(Search);
}
  @RequestMapping(value = "/marks_entryAction" ,method = RequestMethod.POST) 
  public ModelAndView marks_entryAction( @ModelAttribute("marks_entryCMD") ANSWER_BOOK_M ln, BindingResult result, 
  HttpServletRequest request, ModelMap model, HttpSession session){ 

 

 int errCount=0;

    if(request.getParameter("oa_application_id").equals("") || request.getParameter("oa_application_id") == null) 
    { 
 errCount ++;
 model.put("oa_application_id_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Index No.");
    } 
    if(request.getParameter("sc_subject_id").equals("0") || request.getParameter("sc_subject_id").equals("")) 
    { 
 errCount ++;
 model.put("sc_subject_id_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Subject");
    } 
    if(request.getParameter("ab_first_entry") == "undefined") 
    { 
 errCount ++;
 model.put("ab_first_entry_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter First Entry");
    } 
    if(request.getParameter("ab_second_entry") == "undefined") 
    { 
 errCount ++;
 model.put("ab_second_entry_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Second Entry");
    } 
 if(errCount > 0) {

     return new ModelAndView("Marks_entry_tile");
  }

 
    Session sessionHQL = this.sessionFactory.openSession(); 
    Transaction tx = sessionHQL.beginTransaction(); 
    sessionHQL.save(ln); 
    tx.commit(); 
    sessionHQL.close(); 

 
    model.put("msg","Data Saved Successfully"); 
    return new ModelAndView("redirect:Marks_entry_Url"); 
  } 
         @RequestMapping(value = "EditMarks_entryUrl", method = RequestMethod.POST)
         public ModelAndView EditMarks_entryUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String updateid) {


                Session s1 = this.sessionFactory.openSession();
                Transaction tx = s1.beginTransaction();
                String enckey = "commonPwdEncKeys";  
                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
                Query q = null;
                q = s1.createQuery("from ANSWER_BOOK_M where cast(id as string)=:PK");
                q.setString("PK", DcryptedPk);
                @SuppressWarnings("unchecked")
                List<String> list = (List<String>) q.list();
                tx.commit();
                s1.close();
                Mmap.put("Editmarks_entryCMD1", list.get(0));
             Mmap.put("getscsubjectnameListDDL", getscsubjectnameListDDL(session));
                Mmap.put("msg", msg);
         return new ModelAndView("EditMarks_entry_tile","Editmarks_entryCMD",new ANSWER_BOOK_M());
}
  @RequestMapping(value = "/Editmarks_entryAction" ,method = RequestMethod.POST) 
  public ModelAndView Editmarks_entryAction( @ModelAttribute("Editmarks_entryCMD") ANSWER_BOOK_M ln, BindingResult result, 
  HttpServletRequest request, ModelMap model, HttpSession session){ 

 
 int errCount=0;

    if(request.getParameter("oa_application_id").equals("") || request.getParameter("oa_application_id") == null) 
    { 
 errCount ++;
 model.put("oa_application_id_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Index No.");
    } 
    if(request.getParameter("sc_subject_id").equals("0") || request.getParameter("sc_subject_id").equals("")) 
    { 
 errCount ++;
 model.put("sc_subject_id_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Subject");
    } 
    if(request.getParameter("ab_first_entry") == "undefined") 
    { 
 errCount ++;
 model.put("ab_first_entry_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter First Entry");
    } 
    if(request.getParameter("ab_second_entry") == "undefined") 
    { 
 errCount ++;
 model.put("ab_second_entry_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Second Entry");
    } 
 if(errCount > 0) {

     return new ModelAndView("EditMarks_entry_tile");
  }

 
    Session sessionHQL = this.sessionFactory.openSession(); 
    Transaction tx = sessionHQL.beginTransaction(); 
    ln.setId(Integer.parseInt(request.getParameter("id")));
    sessionHQL.saveOrUpdate(ln); 
    tx.commit(); 
    sessionHQL.close(); 

 
    model.put("msg","Data Updated Successfully"); 
    return new ModelAndView("redirect:Searchmarks_entryUrl"); 
  } 
  @RequestMapping(value = "/deletemarks_entryUrl", method = RequestMethod.POST) 
  public ModelAndView deletemarks_entryUrl(String deleteid,HttpSession session,ModelMap model) { 
  	List<String> list = new ArrayList<String>(); 
  	list.add(objDAO.Deletemarks_entry(deleteid,session)); 
  	model.put("msg",list);  
    return new ModelAndView("redirect:Searchmarks_entryUrl"); 
  	}
} 
