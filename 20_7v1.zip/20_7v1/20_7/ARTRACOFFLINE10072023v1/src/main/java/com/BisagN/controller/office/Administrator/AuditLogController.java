package com.BisagN.controller.office.Administrator;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.office.reports.ArmServiceWiseAnalysisOfResult;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class AuditLogController {

	
	@RequestMapping(value = "AuditLogUrl", method = RequestMethod.GET)
	public ModelAndView AuditLogUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) 
			 throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
	NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{
		
		
		
	    Mmap.put("msg", msg);
	    
	return new ModelAndView("AuditLogtiles");

	}
	
	
	@RequestMapping(value = "/getAuditLogPDF", method = RequestMethod.POST)
	public ModelAndView getAuditLogPDF(ModelMap Mmap, HttpSession session, String typeReport) {
		try {

			
			

//			ArrayList<ArrayList<String>> list = Atdnc.Attedence_View(roll2, board_id1, f_date2, t_date2,
//					progress_status, list2.get(0).get(0));
	//
//			if (list.size() == 0) {
//				Mmap.put("msg", "Data Not Available");
	//
//			} else {
//				Mmap.put("list", list);
//				Mmap.put("list.size()", list.size());
//			}

			if (typeReport != null && typeReport.equals("pdfL")) {
				//if (list.size() > 0) {

					List<String> TH = new ArrayList<String>();
					TH.add("Sr No");// 0
					TH.add("Roll No");// 1
					TH.add("Candidate Name");// 2
					TH.add("Gender");// 3

					TH.add("DOB");// 5
					TH.add("Photo & Signature");// 6
					TH.add("Sign of Candidate at Centre");// 7
					TH.add("Left Hand Thumb(L.T.)");// 8

					String Heading = "";
					String username = session.getAttribute("username").toString();

					return new ModelAndView(new AuditLogdownloadpdf("L", TH, Heading, username));

				//}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("AuditLogtiles");
	}
}
