package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.masters.Officer_personal_detailsController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.dao.officer.others.ExportPartBDao;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.trans.Dssc_compens_chanceDAO;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.PARTB_D_APPLICATION_M;
import com.BisagN.models.officers.trans.UNFAIR_MEANS_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Part_b_examinationController {

	@Autowired
	private PartB_ExaminationDAO partBDao;

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;


	Officer_personal_detailsController ofd = new Officer_personal_detailsController();

	CommonController comm = new CommonController();

	  @Autowired
		private RoleBaseMenuDAO roledao;  
	
	
	@Autowired
	private ExportPartBDao export;

	@RequestMapping(value = "Searchpart_b_examinationUrl", method = RequestMethod.GET)
	public ModelAndView Searchpart_b_examinationUrl(ModelMap Mmap, HttpSession session,HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg)
			{
		
		 if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

    	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("Searchpart_b_examinationUrl", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}	
		
		
		Mmap.put("msg", msg);
		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();	
		System.err.println("es_begindate==========="+es_begindate);
	
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		if (ec_exam_id == 1) {
			if (!es_begindate.equals("")) {
				Mmap.put("partb_begindate", es_begindate);
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
			if (ec_exam_id != 0) {
				ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
				Mmap.put("getexamcentrelist", examcentrelist);
				Mmap.put("ec_exam_id", ec_exam_id);
			}
		}
		

		Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL(sessionFactory));

		return new ModelAndView("SearchPartBexm_tile");
	}

	@RequestMapping(value = "/PartB_applicationAction", method = RequestMethod.POST)
	public @ResponseBody String PartB_applicationAction(
			@Valid @ModelAttribute("PartBCMD") PARTB_D_APPLICATION_M partbexm, BindingResult result,
			HttpServletRequest request, ModelMap model, HttpSession session) {
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		String save = "";
		try {

			
			
			String personal_number = request.getParameter("personal_number");
			String center = request.getParameter("center_id");
			String sub_id = request.getParameter("submodulehid");
			
			if (personal_number == "" || personal_number.equals("")) {
				 return   "Please Enter Personal No" ;
				 
			}
			
			
			if (center.equals("0")) {		
				  return "Please Select Centre";
				  }
			

			if(sub_id.equals("0")) {
				
				return "Please Select Atleast One Subject Appearing For in Written Exam" ;
			}

//			if(sub_id.equals("")) {
//				
//				return "Please Select Atleast One Subject Appearing For in Written Exam" ;
//			}
			String username = session.getAttribute("username").toString();
			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			OFFICER_APPLICATION_M o_app1 = new OFFICER_APPLICATION_M();
			int id = o_app1.getOa_application_id() > 0 ? o_app1.getOa_application_id() : 0;
			String pers_code = request.getParameter("personal_number");
			
			List<OFFICER_PERSONAL_CODE_M>getopdid=comm.getopdIdbycode( sessionFactory, pers_code);
			if(!getopdid.isEmpty()) {
		int opd_pers_id= getopdid.get(0).getOpd_personal_id();
			ArrayList<ArrayList<String>> begindatelist = export.getbegindateforexport("Part B");
			int es_id = Integer
					.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			
			String es_begindate = session.getAttribute("es_begin_date") == null ? ""
					: session.getAttribute("es_begin_date").toString();
			 if(!es_begindate.equals("")) {
				 int ec_exam_id = session.getAttribute("ec_exam_id") ==null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());	
				String exmsch_dt= es_begindate.substring(0, 10);
		
			
			ArrayList<ArrayList<String>> list2 = export.getRulesDetailsFromExmSchedule(exmsch_dt, String.valueOf(ec_exam_id),"");
			
			String exam_schedule_dt =list2.get(0).get(0);
			String min_year=list2.get(0).get(1);
			String max_year=list2.get(0).get(2);
			
			ArrayList<ArrayList<String>>getvalidappdata= partBDao.getManualPartbRulesappdetails( opd_pers_id,  exmsch_dt,exam_schedule_dt, min_year,  max_year);
			model.put("getvalidappdata", getvalidappdata);
  if(!getvalidappdata.isEmpty()) {
            	 
			Query q0 = sessionHQL.createQuery(
					"select count(*) from OFFICER_APPLICATION_M where (es_id=:es_id and opd_personal_id=:opd_personal_id) and oa_application_id!=:oa_application_id and oa_status_id=:oa_status_id");

			q0.setParameter("es_id", es_id);
			q0.setParameter("opd_personal_id", opd_pers_id);
			q0.setParameter("oa_application_id", id);
			q0.setParameter("oa_status_id", 1);
			Long c = (Long) q0.uniqueResult();

			if (id == 0) {

				if (c == 0) {

					OFFICER_APPLICATION_M o_app = new OFFICER_APPLICATION_M();

					o_app.setEs_id(es_id);
					o_app.setOpd_personal_id(opd_pers_id);
					o_app.setOa_created_by(username);
					o_app.setOa_creation_date(date);
					o_app.setOa_center_granted(Integer.parseInt(center));
					o_app.setOa_status_id(1);
					int mid = (int) sessionHQL.save(o_app);
					sessionHQL.flush();
					sessionHQL.clear();
					tx.commit();

//					PARTB_D_APPLICATION_M partbexm = new PARTB_D_APPLICATION_M();

					Session sessionHQL1 = this.sessionFactory.openSession();
					Transaction tx1 = sessionHQL1.beginTransaction();


					partbexm.setPbda_created_by(username);
					partbexm.setPbda_creation_date(date);
					partbexm.setPbda_add_corres1(request.getParameter("pbda_add_corres1"));
					partbexm.setPbda_add_corres2(request.getParameter("pbda_add_corres2"));
					partbexm.setPbda_add_corres3(request.getParameter("pbda_add_corres3"));
					partbexm.setOa_application_id(mid);
					partbexm.setPbda_immediate_super(request.getParameter("pbda_immediate_super"));
					partbexm.setPbda_subjects(Integer.parseInt(sub_id));
					sessionHQL1.save(partbexm);

					sessionHQL1.flush();
					sessionHQL1.clear();
					tx1.commit();

					return "Application Generated Successfully";
				}
				
 
			else {

				return "Application already Exist";
				}
			}

			}else {
				return "Rules not Matched With Your Application Data";
				
			}
			 }
			 }
		}

		catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return save;
	}

	@RequestMapping(value = "/getPart_b_examinationReportDataList", method = RequestMethod.POST)
	public @ResponseBody ArrayList<ArrayList<String>> getPartBexmCandidateReport(int startPage, String pageLength,
			String Search, String orderColunm, String orderType, String pers_no, String pers_name, String center,
			String opd_arm_service, String exam_schedule_dt_id, HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		return partBDao.getPartBexmCandidateReport(startPage, pageLength, Search, orderColunm, orderType, pers_no,
				pers_name, center, opd_arm_service, exam_schedule_dt_id, sessionUserId);
	}

	@RequestMapping(value = "/getPart_b_examinationTotalCount", method = RequestMethod.POST)
	public @ResponseBody long getPart_d_examinationTotalCount(HttpSession sessionUserId, String Search, String pers_no,
			String pers_name, String center, String opd_arm_service, String exam_schedule_dt_id) {
		return partBDao.getPartbexmCandidatereportTotalCount(Search, pers_no, pers_name, center, opd_arm_service,
				exam_schedule_dt_id);
	}

	@RequestMapping(value = "EditPartB_Application_detailsUrl", method = RequestMethod.POST)
	public ModelAndView EditPartB_Application_detailsUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String updateid, HttpServletRequest request) {

		Session s1 = this.sessionFactory.openSession();
		Transaction tx = s1.beginTransaction();
		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);
		System.err.println("DcryptedPk===============" + DcryptedPk);
		Query q = null;
		q = s1.createQuery("from PARTB_D_APPLICATION_M where cast(id as string)=:PK");
		q.setString("PK", DcryptedPk);
		@SuppressWarnings("unchecked")
		List<String> sub_total = (List<String>) q.list();

		tx.commit();
		s1.close();
		
		int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
		if (ec_exam_id != 0) {
			ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
			Mmap.put("getexamcentrelist", examcentrelist);
			Mmap.put("ec_exam_id", ec_exam_id);
		}
		Mmap.put("Edit_pers_details", partBDao.getOPDdetailsforpartb(DcryptedPk));
		ArrayList<ArrayList<String>> partblist = partBDao.getpartbapplicationdtl(DcryptedPk);

		String subjecttotal = partblist.get(0).get(5);

		String arm_id = partBDao.getOPDdetailsforpartb(DcryptedPk).get(0).get(10);
		ArrayList<ArrayList<String>> list = partBDao.getSubjectList("Part B", arm_id);

		String exam_id = list.get(0).get(3);

		List<SUBJECT_CODE_M> sublist = comm.getsubjectlist(sessionFactory, Integer.parseInt(exam_id));
		ArrayList<Integer> subtotallist = getsubjectListFromTotal(Integer.parseInt(subjecttotal), sublist);

		Mmap.put("subtotallist", subtotallist);
		Mmap.put("subtotallistSize", subtotallist.size());
		Mmap.put("Edit_partb_Details", partBDao.getpartbapplicationdtl(DcryptedPk));

		String oapp_id = partBDao.getOPDdetailsforpartb(DcryptedPk).get(0).get(11);

		System.err.println("oapp_id========" + oapp_id);
		Mmap.put("msg", msg);

		Mmap.put("oapp_id", oapp_id);
		Mmap.put("subjecttotal", subjecttotal);

		return new ModelAndView("EditPartB_Application_tile", "editPartBCMD", new PARTB_D_APPLICATION_M());
	}

	// ==========================CODE CALCULATION

	public static ArrayList<Integer> getsubjectListFromTotal(int temp, List<SUBJECT_CODE_M> subjectcodeList) {
		ArrayList<Integer> rip = new ArrayList<Integer>();
		System.err.println("subjectcodeList.size()   :  " + subjectcodeList.size());
		for (int i = subjectcodeList.size() - 1; i >= 0; i--) {
			System.err.println("sublist   :  " + subjectcodeList.get(i).getSc_subject_code());
			if ((temp - (subjectcodeList.get(i).getSc_subject_code())) >= 0) {
				rip.add(subjectcodeList.get(i).getSc_subject_code());
				temp = temp - (subjectcodeList.get(i).getSc_subject_code());
				System.err.println(subjectcodeList.get(i).getSc_subject_code());
			}
		}
		return rip;
	}

	@RequestMapping(value = "/EditPart_b_examinationAction", method = RequestMethod.POST)
	public ModelAndView EditPart_b_examinationAction(@Valid @ModelAttribute("EditPartBCMD") PARTB_D_APPLICATION_M ln,
			BindingResult result, HttpServletRequest request, ModelMap model, HttpSession session) {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		String updateid = request.getParameter("oapp_id");
		Date date = new Date();
		String username = session.getAttribute("username").toString();
		// ln.setId(Integer.parseInt(request.getParameter("id")));

		String pbda_immediate_super = request.getParameter("pbda_immediate_super");
		String pbda_survey_details = request.getParameter("pbda_survey_details");
		String pbda_comp_details = request.getParameter("pbda_comp_details");

		
		
		String centre= request.getParameter("oa_center_opted");
		String pbda_add_corres1= request.getParameter("pbda_add_corres1");
		String pbda_add_corres2= request.getParameter("pbda_add_corres2");
		String pbda_add_corres3= request.getParameter("pbda_add_corres3");
		
		String sub_total = request.getParameter("submodulehid");
		System.err.println("sub_total=========="+sub_total);
		
		if (centre.equals("0")) {
			model.put("msg", " Please Enter Centre" );
			  return new ModelAndView("redirect:Searchpart_b_examinationUrl");
			  }
//		if (pbda_add_corres1 == "" || pbda_add_corres1.equals("")) {
//			model.put("msg", " Please Enter Address to receive Exam Correspondence Address1" );
//			  return new ModelAndView("redirect:Searchpart_b_examinationUrl");
//		}
//		
//		if (pbda_add_corres2 == "" || pbda_add_corres2.equals("")) {
//			model.put("msg", " Please Enter Address to receive Exam Correspondence Address2 " );
//			  return new ModelAndView("redirect:Searchpart_b_examinationUrl");
//		}
//		
//		if (pbda_add_corres3 == "" || pbda_add_corres3.equals("")) {
//			model.put("msg", " Please Enter Address to receive Exam Correspondence Address3" );
//			  return new ModelAndView("redirect:Searchpart_b_examinationUrl");
//		}

		if(sub_total.equals("0")) {
			
			model.put("msg", "Please Select Atleast One Subject Appearing For in Written Exam" );
			  return new ModelAndView("redirect:Searchpart_b_examinationUrl");
		}

		System.err.println("updateid========" + updateid);

		System.err.println("sub_total========" + sub_total);

		System.err.println("pbda_add_corres1========" + pbda_add_corres1);

			String hql = "update PARTB_D_APPLICATION_M set pbda_add_corres1=:pbda_add_corres1,pbda_add_corres2=:pbda_add_corres2,"
					+ "pbda_add_corres3=:pbda_add_corres3,pbda_comp_details=:pbda_comp_details,pbda_subjects=:pbda_subjects where  oa_application_id=:oa_application_id";

			Query query = sessionHQL.createQuery(hql)
					.setParameter("pbda_add_corres1", pbda_add_corres1)
					.setParameter("pbda_add_corres2", pbda_add_corres2)
					.setParameter("pbda_add_corres3", pbda_add_corres3)
					.setParameter("pbda_comp_details", pbda_comp_details)
					.setParameter("pbda_subjects", Integer.parseInt(sub_total))
					.setInteger("oa_application_id", Integer.parseInt(updateid));
			
			query.executeUpdate();

			
			//if(oa_center_opted != null) {
			String hql1 = "update OFFICER_APPLICATION_M set oa_center_granted=:oa_center_granted	  where oa_application_id=:oa_application_id ";
			Query query1 = sessionHQL.createQuery(hql1)
					.setParameter("oa_center_granted", Integer.parseInt(centre))
					.setParameter("oa_application_id", Integer.parseInt(updateid));
			query1.executeUpdate();
			
			//}
		// sessionHQL.saveOrUpdate(ln);
		tx.commit();
		model.put("msg", "Data Updated Successfully");
		sessionHQL.close();

		return new ModelAndView("redirect:Searchpart_b_examinationUrl");
	}

	@RequestMapping(value = "PartB_ApplicationURL", method = RequestMethod.POST)
	public ModelAndView PartB_ApplicationURL(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String deleteid) {

		int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
		if (ec_exam_id != 0) {
			ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
			Mmap.put("getexamcentrelist", examcentrelist);
			Mmap.put("ec_exam_id", ec_exam_id);
		}

		

		
		
		Mmap.put("msg", msg);
		return new ModelAndView("Part_b_examination_tile", "PartBCMD", new PARTB_D_APPLICATION_M());
	}

	@RequestMapping(value = "/getPartBSubjectlist", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getSubjectlist(String exm_name, String arm_id) {

		ArrayList<ArrayList<String>> list = partBDao.getSubjectList("Part B", arm_id);
		//System.err.println("list-------------" + list);
		return list;

	}

	@RequestMapping(value = "/deletePartB_Application_detailsUrl", method = RequestMethod.POST)
	public ModelAndView deletePartB_Application_detailsUrl(String deleteid2, HttpSession session, ModelMap model) {

		System.err.println("deleteid===========" + deleteid2);
		String msg = "";
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();

		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) deleteid2, enckey, session);
		System.out.println(DcryptedPk + "==========DcryptedPk");
		try {
			String hql = "update OFFICER_APPLICATION_M set oa_status_id=:oa_status_id where oa_application_id=:oa_application_id";
			Query query = sessionHQL.createQuery(hql).setParameter("oa_status_id", 0).setParameter("oa_application_id",
					Integer.parseInt(DcryptedPk));
			query.executeUpdate();

//				
//				String hq1l = "update PARTB_D_APPLICATION_M set oa_status_id=:oa_status_id  where oa_application_id=:oa_application_id ";
//				Query query1 = sessionHQL.createQuery(hq1l)
//							.setParameter("oa_status_id", 0)			
//							.setParameter("oa_application_id",  Integer.parseInt(DcryptedPk));
//				query1.executeUpdate();

			model.put("msg", msg);
			model.put("msg", "Delete Successfully");

			tx.commit();
		} catch (RuntimeException e) {
			e.printStackTrace();
			tx.rollback();

			model.put("msg", "Server side Error");

		}

		return new ModelAndView("redirect:Searchpart_b_examinationUrl");
	}

	
	@RequestMapping(value = "ManualApplicationGenerate", method = RequestMethod.POST)
	public ModelAndView ManualApplicationGenerate(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String application_status, String personal_number_hid1,String centre1,String submodulehid1,HttpServletRequest request) {
		int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0": session.getAttribute("ec_exam_id").toString());
		try {
			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			String username = session.getAttribute("username").toString();
			Date date = new Date();
			OFFICER_APPLICATION_M o_app1 = new OFFICER_APPLICATION_M();
			int id = o_app1.getOa_application_id() > 0 ? o_app1.getOa_application_id() : 0;
			int es_id = Integer
					.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			
			  
			
			System.err.println("centre1=========="+centre1);
			System.err.println("submodulehid1=========="+submodulehid1);
			if(application_status.equals("Yes")) {
			Query q0 = sessionHQL.createQuery(
					"select count(*) from OFFICER_APPLICATION_M where (es_id=:es_id and opd_personal_id=:opd_personal_id) and oa_application_id!=:oa_application_id and oa_status_id=:oa_status_id");

			q0.setParameter("es_id", es_id);
			q0.setParameter("opd_personal_id",Integer.parseInt(personal_number_hid1));
			q0.setParameter("oa_application_id", id);
			q0.setParameter("oa_status_id", 1);
			Long c = (Long) q0.uniqueResult();

			if (id == 0) {

				if (c == 0) {

					OFFICER_APPLICATION_M o_app = new OFFICER_APPLICATION_M();

					o_app.setEs_id(es_id);
					o_app.setOpd_personal_id(Integer.parseInt(personal_number_hid1));
					o_app.setOa_created_by(username);
					o_app.setOa_creation_date(date);
					o_app.setOa_center_opted(Integer.parseInt(centre1));
					o_app.setOa_status_id(1);
					int mid = (int) sessionHQL.save(o_app);
					sessionHQL.flush();
					sessionHQL.clear();
					tx.commit();

					PARTB_D_APPLICATION_M partbexm = new PARTB_D_APPLICATION_M();

					Session sessionHQL1 = this.sessionFactory.openSession();
					Transaction tx1 = sessionHQL1.beginTransaction();


					partbexm.setPbda_created_by(username);
					partbexm.setPbda_creation_date(date);
					partbexm.setPbda_add_corres1(request.getParameter("pbda_add_corres1"));
					partbexm.setPbda_add_corres2(request.getParameter("pbda_add_corres2"));
					partbexm.setPbda_add_corres3(request.getParameter("pbda_add_corres3"));
					partbexm.setOa_application_id(mid);
					partbexm.setPbda_immediate_super(request.getParameter("pbda_immediate_super"));
					partbexm.setPbda_subjects(Integer.parseInt(submodulehid1));
					sessionHQL1.save(partbexm);

					sessionHQL1.flush();
					sessionHQL1.clear();
					tx1.commit();

					Mmap.put("msg", "Data Saved Successfully");
				}else {
					Mmap.put("msg", "Data already exist");	
					
				}
				
			}else {
				if(ec_exam_id == 1) {
					return new ModelAndView("redirect:Searchpart_b_examinationUrl");
				}
				
				if(ec_exam_id == 2) {
					return new ModelAndView("redirect:SearchPart_d_examinationUrl");
				}
				
			}
}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		if(ec_exam_id == 1) {
			return new ModelAndView("redirect:Searchpart_b_examinationUrl");
		}
		
		if(ec_exam_id == 2) {
			return new ModelAndView("redirect:SearchPart_d_examinationUrl");
		}
		return null;
		
}
}
