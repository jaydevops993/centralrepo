package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "dssc_tsoc_date", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class DSSC_TSOC_DATE_M {

      private int id;
      private int es_id;
      private int dtd_dssc_courseno;
      private int dtd_tsoc_courseno;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dtd_dssc_startdate;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dtd_tsoct_startdate;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dtd_tsocnt_startdate;
      private int dtd_dssc_vacancy;
      private int dtd_dssc_reserves;
      private int dtd_tsoc_vacancy;
      private int dtd_tsoc_reserves;

      private int dtd_almc_vacancy;
      private int dtd_isc_vacancy;
      private int dtd_almc_reserves;
      private int dtd_isc_reserves;

      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getEs_id() {
           return es_id;
      }
      public void setEs_id(int es_id) {
	  this.es_id = es_id;
      }
      public int getDtd_dssc_courseno() {
           return dtd_dssc_courseno;
      }
      public void setDtd_dssc_courseno(int dtd_dssc_courseno) {
	  this.dtd_dssc_courseno = dtd_dssc_courseno;
      }
      public int getDtd_tsoc_courseno() {
           return dtd_tsoc_courseno;
      }
      public void setDtd_tsoc_courseno(int dtd_tsoc_courseno) {
	  this.dtd_tsoc_courseno = dtd_tsoc_courseno;
      }
      public Date getDtd_dssc_startdate() {
           return dtd_dssc_startdate;
      }
      public void setDtd_dssc_startdate(Date dtd_dssc_startdate) {
	  this.dtd_dssc_startdate = dtd_dssc_startdate;
      }
      public Date getDtd_tsoct_startdate() {
           return dtd_tsoct_startdate;
      }
      public void setDtd_tsoct_startdate(Date dtd_tsoct_startdate) {
	  this.dtd_tsoct_startdate = dtd_tsoct_startdate;
      }
      public Date getDtd_tsocnt_startdate() {
           return dtd_tsocnt_startdate;
      }
      public void setDtd_tsocnt_startdate(Date dtd_tsocnt_startdate) {
	  this.dtd_tsocnt_startdate = dtd_tsocnt_startdate;
      }
      public int getDtd_dssc_vacancy() {
           return dtd_dssc_vacancy;
      }
      public void setDtd_dssc_vacancy(int dtd_dssc_vacancy) {
	  this.dtd_dssc_vacancy = dtd_dssc_vacancy;
      }
      public int getDtd_dssc_reserves() {
           return dtd_dssc_reserves;
      }
      public void setDtd_dssc_reserves(int dtd_dssc_reserves) {
	  this.dtd_dssc_reserves = dtd_dssc_reserves;
      }
      public int getDtd_tsoc_vacancy() {
           return dtd_tsoc_vacancy;
      }
      public void setDtd_tsoc_vacancy(int dtd_tsoc_vacancy) {
	  this.dtd_tsoc_vacancy = dtd_tsoc_vacancy;
      }
      public int getDtd_tsoc_reserves() {
           return dtd_tsoc_reserves;
      }
      public void setDtd_tsoc_reserves(int dtd_tsoc_reserves) {
	  this.dtd_tsoc_reserves = dtd_tsoc_reserves;
      }
	public int getDtd_almc_vacancy() {
		return dtd_almc_vacancy;
	}
	public void setDtd_almc_vacancy(int dtd_almc_vacancy) {
		this.dtd_almc_vacancy = dtd_almc_vacancy;
	}
	public int getDtd_isc_vacancy() {
		return dtd_isc_vacancy;
	}
	public void setDtd_isc_vacancy(int dtd_isc_vacancy) {
		this.dtd_isc_vacancy = dtd_isc_vacancy;
	}
	public int getDtd_almc_reserves() {
		return dtd_almc_reserves;
	}
	public void setDtd_almc_reserves(int dtd_almc_reserves) {
		this.dtd_almc_reserves = dtd_almc_reserves;
	}
	public int getDtd_isc_reserves() {
		return dtd_isc_reserves;
	}
	public void setDtd_isc_reserves(int dtd_isc_reserves) {
		this.dtd_isc_reserves = dtd_isc_reserves;
	}
      
      
}
