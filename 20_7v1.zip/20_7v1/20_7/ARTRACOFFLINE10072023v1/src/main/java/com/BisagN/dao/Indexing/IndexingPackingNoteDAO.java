package com.BisagN.dao.Indexing;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface IndexingPackingNoteDAO {

	
	public ArrayList<ArrayList<String>> GetPackingnoteDetailsSubwise(int indx_esId,int subject_id,int esid_sub_subject_id) ;
	public ArrayList<ArrayList<String>> GetBundleListByPackingNote(int indx_esId, String packing_note_id) ;
	public ArrayList<ArrayList<String>> getPackingNoteReportDetails(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,int es_id,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException ;
	public long getTotalCountgetPackingNoteReportDetails(String Search,int es_id) ;
	public ArrayList<ArrayList<String>> GetFinalPackageNameListByEsid(int indx_esId);
	public ArrayList<ArrayList<String>> GetpackedPackingnoteDetailsSubwise(int indx_esId, int subject_id,int esid_sub_subject_id,String packed_status);
	public ArrayList<ArrayList<String>> GetUnpackedPackingnoteDetailsSubwise(int indx_esId, int subject_id,int esid_sub_subject_id,String packed_status);
}
