/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.BisagN.models.officers.trans;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author rdp
 */
@Entity
@Table(name = "dsscaualified")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Dsscaualified.findAll", query = "SELECT d FROM Dsscaualified d"),
    @NamedQuery(name = "Dsscaualified.findByDid", query = "SELECT d FROM Dsscaualified d WHERE d.did = :did"),
    @NamedQuery(name = "Dsscaualified.findByOaApplicantId", query = "SELECT d FROM Dsscaualified d WHERE d.oaApplicantId = :oaApplicantId"),
    @NamedQuery(name = "Dsscaualified.findByNominatefor", query = "SELECT d FROM Dsscaualified d WHERE d.nominatefor = :nominatefor"),
    @NamedQuery(name = "Dsscaualified.findByAssigned", query = "SELECT d FROM Dsscaualified d WHERE d.assigned = :assigned"),
    @NamedQuery(name = "Dsscaualified.findByGrandtotal", query = "SELECT d FROM Dsscaualified d WHERE d.grandtotal = :grandtotal"),
    @NamedQuery(name = "Dsscaualified.findByOutof700", query = "SELECT d FROM Dsscaualified d WHERE d.outof700 = :outof700")})
public class Dsscaualified implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "did")
    private Integer did;
    @Column(name = "oa_applicant_id")
    private Integer oaApplicantId;
    @Column(name = "nominatefor")
    private String nominatefor;
    @Column(name = "assigned")
    private String assigned;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "grandtotal")
    private Double grandtotal;
    @Column(name = "outof700")
    private Double outof700;
    
//    private int status_id;
//    private String reason;
    
    @Column(name = "es_id")
    private int esId;

    public int getEsId() {
		return esId;
	}

	public void setEsId(int esId) {
		this.esId = esId;
	}

	public Dsscaualified() {
    }

    public Dsscaualified(Integer did) {
        this.did = did;
    }

    public Integer getDid() {
        return did;
    }

    public void setDid(Integer did) {
        this.did = did;
    }

    public Integer getOaApplicantId() {
        return oaApplicantId;
    }

    public void setOaApplicantId(Integer oaApplicantId) {
        this.oaApplicantId = oaApplicantId;
    }

    public String getNominatefor() {
        return nominatefor;
    }

    public void setNominatefor(String nominatefor) {
        this.nominatefor = nominatefor;
    }

    public String getAssigned() {
        return assigned;
    }

    public void setAssigned(String assigned) {
        this.assigned = assigned;
    }

    public Double getGrandtotal() {
        return grandtotal;
    }

    public void setGrandtotal(Double grandtotal) {
        this.grandtotal = grandtotal;
    }

    public Double getOutof700() {
        return outof700;
    }

    public void setOutof700(Double outof700) {
        this.outof700 = outof700;
    }
    
    

//    public int getStatus_id() {
//		return status_id;
//	}
//
//	public void setStatus_id(int status_id) {
//		this.status_id = status_id;
//	}

//	public String getReason() {
//		return reason;
//	}
//
//	public void setReason(String reason) {
//		this.reason = reason;
//	}

	@Override
    public int hashCode() {
        int hash = 0;
        hash += (did != null ? did.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Dsscaualified)) {
            return false;
        }
        Dsscaualified other = (Dsscaualified) object;
        if ((this.did == null && other.did != null) || (this.did != null && !this.did.equals(other.did))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.demodb.Dsscaualified[ did=" + did + " ]";
    }
    
}
