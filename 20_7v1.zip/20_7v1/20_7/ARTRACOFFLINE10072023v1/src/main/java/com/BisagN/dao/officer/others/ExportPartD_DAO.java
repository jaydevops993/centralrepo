package com.BisagN.dao.officer.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface ExportPartD_DAO {
	
	
	public ArrayList<ArrayList<String>> getexportPartDexmCandidateReport(int startPage, String pageLength, String Search,
			String orderColunm, String orderType, String exam_schedule_dt2, String min_year2,String es_consider_date1,int es_id,String table, String btn_value,
			String max_year2,String partb_status,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException ;
	public long getexportPartDexmCandidatereportTotalCount(String Search, String exam_schedule_dt2,String min_year2,String es_consider_date1,int es_id,
			String btn_value,String max_year2,String partb_status);
	public ArrayList<ArrayList<String>> getExportPartDForExcel(int es_id, String partb_status2);
	}
