package com.BisagN.controller.office.Course;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.course.MeritandResultGenerationDao;
import com.BisagN.models.officers.merit.DSSC_MERIT_RESULT_GEN_TBL;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.trans.DSSC_COMPENS_CHANCE_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class MeritAndResultGenerationController {

	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	CommonController comm = new CommonController();
	
	@Autowired
	private MeritandResultGenerationDao MeritDao;
	
	@Autowired
	private RoleBaseMenuDAO roledao;
	
	
	@RequestMapping(value = "Merit_search_Url", method = RequestMethod.GET)
    public ModelAndView Merit_search_Url(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{
		  
		  if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

   	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("Merit_search_Url", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}	
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			if (ec_exam_id == 3) {
		  String es_begindate = session.getAttribute("es_begin_dateshow") == null ? ""
					: session.getAttribute("es_begin_dateshow").toString();
		  Mmap.put("DSSC_begindate", es_begindate);
		  
		   Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
		   Mmap.put("getctarmcodetypeListDDL",comm.getctarmcodetypeListDDL(sessionFactory));
			}  
        Mmap.put("msg", msg);
    return new ModelAndView("Merit_search_tiles");
}
	
	
	
	  @RequestMapping(value = "/getMeritReportDataListjsp", method = RequestMethod.POST)
		 public @ResponseBody List<Map<String, Object>> getMeritReportDataListjsp(int startPage,
				 String pageLength,String Search,String orderColunm,String orderType,HttpSession sessionUserId) 
			     throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, 
			     InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
		  int es_id = Integer.parseInt(sessionUserId.getAttribute("es_id") == null ? "0": sessionUserId.getAttribute("es_id").toString());
		  return MeritDao.getMeritReportDataList(startPage,pageLength,Search,orderColunm,orderType,sessionUserId,es_id);
		}

		 
		 @RequestMapping(value = "/getMeritTotalCountjsp", method = RequestMethod.POST)
		public @ResponseBody long getMeritTotalCountjsp(HttpSession sessionUserId,String Search,String name){
			 int es_id = Integer.parseInt(sessionUserId.getAttribute("es_id") == null ? "0": sessionUserId.getAttribute("es_id").toString());
			return MeritDao.getMeritTotalCount(Search,es_id);
		}
	//===========================OPEN PAGE============================//
			@RequestMapping(value = "MeritAndResultGenerationUrl", method = RequestMethod.POST)
			public ModelAndView MeritAndResultGenerationUrl(ModelMap Mmap, HttpSession session,
					@RequestParam(value = "msg", required = false) String msg)
					throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
					NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

				Mmap.put("msg", msg);
				int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
				  
				if(es_id != 0) {
					String es_begindate = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();	
					
					int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

					if (ec_exam_id ==3) {
						if (!es_begindate.equals("")) {
							Mmap.put("DSSC_begindate", es_begindate);
						}
						
				ArrayList<ArrayList<String>> choiceList=MeritDao.getcourseandmeritlist(es_id);
				if(!choiceList.isEmpty())
				{
					Mmap.put("choiceList", choiceList);
					Mmap.put("choiceListSize", choiceList.size());
				}
					}
				}
				return new ModelAndView("Merit_ResultGnrtn_tiles");
			}
			
			
			@RequestMapping(value = "/MeritResultGenAction", method = RequestMethod.POST)
			public ModelAndView MeritResultGenAction(
					@Valid @ModelAttribute("MeritResultGenCMD") DSSC_MERIT_RESULT_GEN_TBL mrtbl, BindingResult result,
					HttpServletRequest request, ModelMap model, HttpSession session) {

				try {
					Session sessionHQL = this.sessionFactory.openSession();
					Transaction tx = sessionHQL.beginTransaction();
					Date date = new Date();
					String username = session.getAttribute("username").toString();
					int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
					
					int id = mrtbl.getId() > 0 ? mrtbl.getId() : 0;
//					Query q0 = sessionHQL.createQuery(
//							"select count(*) from DSSC_MERIT_RESULT_GEN_TBL where es_id=:es_id");
//
//					q0.setParameter("es_id",es_id);
//					Long c = (Long) q0.uniqueResult();

					if (id == 0) {

						//if (c == 0) {
							ArrayList<ArrayList<String>> choiceList=MeritDao.getcourseandmeritlist(es_id);
							for(int i=0;i<choiceList.size();i++) {
								
								Session sessionHQL1 = this.sessionFactory.openSession();
								Transaction tx1 = sessionHQL1.beginTransaction();
								int i1=i+1;
								String course_id= choiceList.get(i).get(4); 
								String course_name=choiceList.get(i).get(0); 
								String total_vacancy=choiceList.get(i).get(2); 
								String reserve=choiceList.get(i).get(1);
								String division = request.getParameter("division_"+course_name+"_"+i1+"");
								System.err.println("division============="+division);
							
								
								mrtbl.setCourse_id(Integer.parseInt(course_id));
								mrtbl.setCreated_by(username);
								mrtbl.setCreated_date(date);
								mrtbl.setEs_id(es_id);
								mrtbl.setDivision(division);
								mrtbl.setTotal_vacancy(Integer.parseInt(total_vacancy));
								String priority_merrit=request.getParameter("priority_merit_gen_"+course_name+"_"+i1+"");
								String priority_result=request.getParameter("priority_result_gen_"+course_name+"_"+i1+"");
								if(division != "null" || division != "") {
									mrtbl.setPriority_merit(0);
									mrtbl.setPriority_result(0);	
								}
								else {
									
									mrtbl.setPriority_merit(Integer.parseInt(priority_merrit));
									mrtbl.setPriority_result(Integer.parseInt(priority_result));
								}

								mrtbl.setType("P");
								mrtbl.setSub_course("");
								sessionHQL1.save(mrtbl);
								tx1.commit();
								
								
								
								Session sessionHQL3 = this.sessionFactory.openSession();
								Transaction tx3 = sessionHQL3.beginTransaction();
								mrtbl.setCourse_id(Integer.parseInt(course_id));
								mrtbl.setCreated_by(username);
								mrtbl.setCreated_date(date);
								mrtbl.setEs_id(es_id);
								mrtbl.setSub_course("Res");
								mrtbl.setDivision("N");
								mrtbl.setTotal_vacancy(Integer.parseInt(reserve));
								String res_priority_merrit=request.getParameter("priority_merit_gen_res_"+course_name+"_"+i1+"");
								String res_priority_result=request.getParameter("priority_result_gen_res_"+course_name+"_"+i1+"");
								mrtbl.setPriority_merit(Integer.parseInt(res_priority_merrit));
								mrtbl.setPriority_result(Integer.parseInt(res_priority_result));
								mrtbl.setType("P");
								sessionHQL3.save(mrtbl);
								tx3.commit();
								
								
							
									String count= request.getParameter("count_"+course_name+"");
									
									if(!count.equals("")) {
									for(int i3=1;i3<=Integer.parseInt(count);i3++) {
										int i4=i3+1;
										Session sessionHQL2 = this.sessionFactory.openSession();
										Transaction tx2 = sessionHQL2.beginTransaction();
										mrtbl.setCourse_id(Integer.parseInt(course_id));
										mrtbl.setCreated_by(username);
										mrtbl.setCreated_date(date);
										mrtbl.setEs_id(es_id);
										mrtbl.setDivision("N");
										System.err.println("i3========="+i3);
										System.err.println("course_name========="+course_name);
										mrtbl.setSub_course(request.getParameter(""+course_name+"_"+i3+""));
										String vacancy=request.getParameter("vacancy_"+course_name+"_"+i3+"");
										
										System.err.println("vacancy========="+vacancy);
										mrtbl.setTotal_vacancy(Integer.parseInt(vacancy));
										
										String priority_merrit2=request.getParameter("priority_merit_gen_"+course_name+"_"+i4+"");
										
										String priority_result2=request.getParameter("priority_result_gen_"+course_name+"_"+i4+"");
										mrtbl.setPriority_merit(Integer.parseInt(priority_merrit2));
										mrtbl.setPriority_result(Integer.parseInt(priority_result2));
										mrtbl.setType("C");
										sessionHQL2.save(mrtbl);
										tx2.commit();
										
									}
									
									}
									
								//}
								
									}
							
							
							
								
							
							
							
							//tx.commit();
							//sessionHQL.close();

							model.put("msg", "Data Saved Successfully");
						
						//}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				return new ModelAndView("redirect:Merit_search_Url");
			
				
			}

			
}
