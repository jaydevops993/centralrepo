package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "dssc_course_vacancy_reserve", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})
public class DSSC_COURSE_VACANCY_RESERVE {
	
	private int id;
	private int es_id;
	private int course_id;
	private int vacancy;
	private int reserve;
	private String dssc_course_no;
	private Date  dssc_course_date;
	private String created_by;
	private Date created_date;
	private String modified_by;
	private Date modified_date;
	
	 @Id
     @GeneratedValue(strategy = IDENTITY)
     @Column(name = "id", unique = true, nullable = false)
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getEs_id() {
		return es_id;
	}
	public void setEs_id(int es_id) {
		this.es_id = es_id;
	}
	
	public String getDssc_course_no() {
		return dssc_course_no;
	}
	public void setDssc_course_no(String dssc_course_no) {
		this.dssc_course_no = dssc_course_no;
	}
	public Date getDssc_course_date() {
		return dssc_course_date;
	}
	public void setDssc_course_date(Date dssc_course_date) {
		this.dssc_course_date = dssc_course_date;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	public int getCourse_id() {
		return course_id;
	}
	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}
	public int getVacancy() {
		return vacancy;
	}
	public void setVacancy(int vacancy) {
		this.vacancy = vacancy;
	}
	public int getReserve() {
		return reserve;
	}
	public void setReserve(int reserve) {
		this.reserve = reserve;
	}
	
	 
	
}
