package com.BisagN.models.officers.masters;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "rank_code", uniqueConstraints = {
@UniqueConstraint(columnNames = "rc_rank_id"),})

public class RANK_CODE_M {

      private int id;
      //private int rc_rank_id;
      private String rc_rank_name;
      private int rc_status_id;
      private String rc_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date rc_creation_date;
      private String rc_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date rc_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "rc_rank_id", unique = true, nullable = false)
      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      
      public String getRc_rank_name() {
           return rc_rank_name;
      }
      public void setRc_rank_name(String rc_rank_name) {
	  this.rc_rank_name = rc_rank_name;
      }
      public int getRc_status_id() {
           return rc_status_id;
      }
      public void setRc_status_id(int rc_status_id) {
	  this.rc_status_id = rc_status_id;
      }
      public String getRc_created_by() {
           return rc_created_by;
      }
      public void setRc_created_by(String rc_created_by) {
	  this.rc_created_by = rc_created_by;
      }
      public Date getRc_creation_date() {
           return rc_creation_date;
      }
      public void setRc_creation_date(Date rc_creation_date) {
	  this.rc_creation_date = rc_creation_date;
      }
      public String getRc_modified_by() {
           return rc_modified_by;
      }
      public void setRc_modified_by(String rc_modified_by) {
	  this.rc_modified_by = rc_modified_by;
      }
      public Date getRc_modification_date() {
           return rc_modification_date;
      }
      public void setRc_modification_date(Date rc_modification_date) {
	  this.rc_modification_date = rc_modification_date;
      }
}
