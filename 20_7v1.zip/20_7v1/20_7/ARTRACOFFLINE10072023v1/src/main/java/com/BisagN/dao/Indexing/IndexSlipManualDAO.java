package com.BisagN.dao.Indexing;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface IndexSlipManualDAO {
	




	public ArrayList<ArrayList<String>> getIndexSlipManualDetails(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,int ec_exam_id, int es_id,int sc_subject_id,String bundle_name,String bundle_no,
			String personal_no,String command,String center,int esid_sub_subject_id,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;

	public long getTotalCountgetIndexSlipManualDetails(String Search,int ec_exam_id,int es_id,int sc_subject_id,String bundle_name,String bundle_no,
			String personal_no,String command,String center,int esid_sub_subject_id);
public ArrayList<ArrayList<String>> GetActivebundlleName(int indx_esId, String sc_subject_id,String bundle_name,String bundle_no);
public ArrayList<ArrayList<String>> GetMasterABList(int indx_esId, String subject_id1,String bundle_name1,String bundle_no1);
public ArrayList<ArrayList<String>> getBunldeNoByPackingBundle(int es_id, int user_id,String bundle_packing_id, String role);


public ArrayList<ArrayList<String>> getGroupusername( int user_id );

public ArrayList<ArrayList<String>> dateIndexDetailsForBarocde( int startPage, String pageLength, String Search,
		String orderColunm, String orderType,int es_id ,String usrename ,int subject_id ,String role) ;


public ArrayList<ArrayList<String>> getcountdateIndexDetailsForBarocde( int es_id ,String usrename ,int subject_id,String role); 
 
}
