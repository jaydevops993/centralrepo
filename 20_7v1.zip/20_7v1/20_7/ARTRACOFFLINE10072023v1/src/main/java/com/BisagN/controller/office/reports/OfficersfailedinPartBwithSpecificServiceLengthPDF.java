package com.BisagN.controller.office.reports;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;

public class OfficersfailedinPartBwithSpecificServiceLengthPDF extends AbstractPdfView{

	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public OfficersfailedinPartBwithSpecificServiceLengthPDF(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();
		
		response.setContentType("application/pdf");
		//response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);

		Chunk underline1 = new Chunk("OFFICERS FAILED IN 'PARTB' EXAM WITH SPECIFIC SERVICE LENGTH " , fontTableHeadingSubMainHead);	 
		Chunk underline2 = new Chunk("EXAM SCHEDULE DATE        " + "SERVICE LENGTH IN YEARS", fontTableHeadingSubMainHead);	 
		
		Phrase ph = new Phrase(underline1);
		Phrase phh2 = new Phrase(underline2);
		ph.add("\n");
		ph.add("\n");
		phh2.add("\n");
		phh2.add("\n");
		ph.setFont(fontTableHeading1);

		Paragraph cell = new Paragraph(ph);
		cell.setAlignment(Element.ALIGN_LEFT);
		cell.setAlignment(Element.ALIGN_LEFT);
		
		Paragraph cell1 = new Paragraph(phh2);
		cell1.setAlignment(Element.ALIGN_LEFT);
		cell1.setAlignment(Element.ALIGN_LEFT);
		
		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell);
		tableheader.addCell(cell1);
		
		PdfPTable tabledata = new PdfPTable(6);
		tabledata.setWidths(new int[] {5,5,5,5,5,5});
		tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata.setWidthPercentage(100);
	
		Paragraph a = new Paragraph("SER NO.",fontTableHeadingSubMainHead);
		Paragraph b = new Paragraph("ARMY NO",fontTableHeadingSubMainHead);
		Paragraph c = new Paragraph("RANK",fontTableHeadingSubMainHead);
		Paragraph d = new Paragraph("NAME",fontTableHeadingSubMainHead);
		Paragraph e = new Paragraph("DATE OF COMM",fontTableHeadingSubMainHead);
		Paragraph f = new Paragraph("DATE OF SENIORITY",fontTableHeadingSubMainHead);
		
		 PdfPCell blank_cella;
		 blank_cella = new PdfPCell();
		 blank_cella.addElement(a);
		 blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			 PdfPCell blank_cellb;
			 blank_cellb = new PdfPCell();
			 blank_cellb.addElement(b);
			 blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			 PdfPCell blank_cellc;
			 blank_cellc = new PdfPCell();
			 blank_cellc.addElement(c);
			 blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
			 
			 PdfPCell blank_celld;
			 blank_celld = new PdfPCell();
			 blank_celld.addElement(d);
			 blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
			 
			 PdfPCell blank_celle;
			 blank_celle = new PdfPCell();
			 blank_celle.addElement(e);
			 blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
			 
			 PdfPCell blank_cellf;
			 blank_cellf = new PdfPCell();
			 blank_cellf.addElement(f);
			 blank_cellf.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			 tabledata.addCell(blank_cella);
			 tabledata.addCell(blank_cellb);
			 tabledata.addCell(blank_cellc);
			 tabledata.addCell(blank_celld);
			 tabledata.addCell(blank_celle);
			 tabledata.addCell(blank_cellf);
			 
			 //data bind
			 Paragraph blank1 = new Paragraph("0");
			 Paragraph blank2 = new Paragraph("0");
			 Paragraph blank3 = new Paragraph("0");
			 Paragraph blank4 = new Paragraph("0");
			 Paragraph blank5 = new Paragraph("0");
			 Paragraph blank6 = new Paragraph("0");
				 
				 tabledata.addCell(blank1);
				 tabledata.addCell(blank2);
				 tabledata.addCell(blank3);
				 tabledata.addCell(blank4);
				 tabledata.addCell(blank5);
				 tabledata.addCell(blank6);
	
		PdfPCell cell123;
		cell123 = new PdfPCell();
		cell123.addElement(tableheader);
		cell123.addElement(tabledata);
		cell123.addElement(new Paragraph("\n"));
		cell123.setBorder(0);
		table.addCell(cell123);

		document.add(table);
		super.buildPdfMetadata(model, document, request);
	}

}
