package com.BisagN.models.officers.others;


import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "officer_rank", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class OFFICER_RANK_M {

      private int id;
      private int rc_rank_id;
      private int opd_personal_id;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date or_effective_date;
      private int or_status_id;
      private String or_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date or_creation_date;
      private String or_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date or_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getRc_rank_id() {
           return rc_rank_id;
      }
      public void setRc_rank_id(int rc_rank_id) {
	  this.rc_rank_id = rc_rank_id;
      }
      public int getOpd_personal_id() {
           return opd_personal_id;
      }
      public void setOpd_personal_id(int opd_personal_id) {
	  this.opd_personal_id = opd_personal_id;
      }
      public Date getOr_effective_date() {
           return or_effective_date;
      }
      public void setOr_effective_date(Date or_effective_date) {
	  this.or_effective_date = or_effective_date;
      }
      public int getOr_status_id() {
           return or_status_id;
      }
      public void setOr_status_id(int or_status_id) {
	  this.or_status_id = or_status_id;
      }
      public String getOr_created_by() {
           return or_created_by;
      }
      public void setOr_created_by(String or_created_by) {
	  this.or_created_by = or_created_by;
      }
      public Date getOr_creation_date() {
           return or_creation_date;
      }
      public void setOr_creation_date(Date or_creation_date) {
	  this.or_creation_date = or_creation_date;
      }
      public String getOr_modified_by() {
           return or_modified_by;
      }
      public void setOr_modified_by(String or_modified_by) {
	  this.or_modified_by = or_modified_by;
      }
      public Date getOr_modification_date() {
           return or_modification_date;
      }
      public void setOr_modification_date(Date or_modification_date) {
	  this.or_modification_date = or_modification_date;
      }
}
