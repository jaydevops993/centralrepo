package com.BisagN.dao.Indexing;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_MASTER;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

@Service
public class ManageBundleDaoImpl implements ManageBundleDAO {

	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	
	@Autowired
	ManageBundleDAO MbindxDao;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	public boolean checkIsIntegerValue(String Search) {
		return Search.matches("[0-9]+");
		}
	
	
	public ArrayList<ArrayList<String>> getManageBundleDetails(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,int es_id,int sc_subject_id,int sub_subject_id,String userId,String role,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		
		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search,sc_subject_id);
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String q1 = "";
		String q2="";
		
		if(role.equals("Index Group")) {
			q1+=" and ibm.ibm_iu_user_id=?";
		}
		
		if(sub_subject_id != 0 ) {
			q2+= "and ibm.ibm_sub_subject_id=?";	
		}

		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			 q = "select ibm.ibm_bundle_prefix, ibm.ibm_bundle_no, ibm.ibm_abcount,ibm.ibm_id,l.username from indexed_bundle_master ibm \n"
			 		+ "inner join logininformation l on ibm.ibm_iu_user_id=l.userid \n"
			 		+ "where ibm.ibm_es_id=? and ibm.ibm_nsubjectid=? and ibm.ibm_status_id=1"+q1+" "+q2+"  "+SearchValue+" \n"
					+ "ORDER BY ibm_id    "+orderType +" limit "  +pageLength+" OFFSET "+startPage;
			
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			stmt.setInt(2, sc_subject_id);
			if(role.equals("Index Group")) {
				stmt.setInt(3, Integer.parseInt(userId));
				if(sub_subject_id != 0 ) {
					stmt.setInt(4, sub_subject_id);
					}
			}
			if(role.equals("Mt2_admin_Users")) {
				if(sub_subject_id != 0 ) {
					stmt.setInt(3, sub_subject_id);
					}
				}

			ResultSet rs = stmt.executeQuery();
			
			System.err.println("ManageBundle============"+stmt);
			int i=1;
			
			
			
			
			
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(String.valueOf(i));
				list.add(rs.getString("ibm_bundle_prefix")+(rs.getString("ibm_bundle_no")));
			
				list.add(rs.getString("ibm_abcount"));//0
				
				String enckey = "commonPwdEncKeys";
				Cipher c = hex_asciiDao.EncryptionSHA256Algo(session, enckey);
			
				
				 
                   String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('" + rs.getString("ibm_id") + "','" + rs.getString("ibm_abcount") + "')}else{ return false;}\""; 
                   String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
               
//                   list.add(deleteButton);
                   
				String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('" + rs.getString("ibm_id") + "','" + rs.getString("ibm_abcount") + "')}else{ return false;}\"";
				String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>";

				list.add(rs.getString("username"));//0
				if(role.equals("Index Group")) {
				list.add(deleteButton);
				}
				if(role.equals("Mt2_admin_Users")) {
				list.add(updateButton+deleteButton);
			
				}
				
				int ibm_id = rs.getInt("ibm_id");
				
				ArrayList<ArrayList<String>>countslipscan= MbindxDao.getIndxSlipCountByIbm(es_id, ibm_id,  Integer.parseInt(userId),role);
				if (!countslipscan.isEmpty()) {
					String slip_count=countslipscan.get(0).get(0);
					
					list.add(slip_count);
				}
				else {
					list.add("0");
				}
				
				
				alist.add(list);
				
			i++;
				

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	public long getTotalCountgetManageBundleDetails(String Search,int es_id,int sc_subject_id,int sub_subject_id,String userId,String role) {

		String SearchValue = GenerateQueryWhereClause_SQL(Search,sc_subject_id);
	int total = 0;
	String q = null;
	String q1 = "";
	String q2 = "";
	Connection conn = null;
	try {
		
if(role.equals("Index Group")) {
			
			q1+=" and ibm.ibm_iu_user_id=?";
		}
if(sub_subject_id != 0 ) {
	q2+= "and ibm.ibm_sub_subject_id=?";	
	}
		conn = dataSource.getConnection();
		q ="select count(*) from (select ibm.ibm_bundle_prefix, ibm.ibm_bundle_no, ibm.ibm_abcount,ibm.ibm_id from indexed_bundle_master ibm\n"
				+ "where ibm.ibm_es_id=? and ibm.ibm_nsubjectid=? and ibm.ibm_status_id=1 "+q1+" "+q2+"  ORDER BY ibm_id asc "  +SearchValue +"   ) ab " ;
		
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereClause_SQL(stmt,Search,sc_subject_id);
		stmt.setInt(1, es_id);
		stmt.setInt(2,sc_subject_id);
		if(role.equals("Index Group")) {
			
			stmt.setInt(3, Integer.parseInt(userId));
			if(sub_subject_id != 0 ) {
			stmt.setInt(4, sub_subject_id);
			}
		}
		if(role.equals("Mt2_admin_Users")) {
		if(sub_subject_id != 0 ) {
			stmt.setInt(3, sub_subject_id);
			}
		}
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search, int sc_subject_id) {
		String SearchValue = "";

		try {
		
			
		

			
		
			
			
			if (!Search.equals("")) {
				Search = Search.toLowerCase();
				SearchValue = " and ( ";
				SearchValue += " lower(opc_personal_code) like ?  or lower(opd_officer_name) like ? or lower(ac_arm_description) like ?)";
						
			}
		} catch (Exception e) {
			
		}

		return SearchValue;

	}

	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,int sc_subject_id) {
		int flag = 1;
		
	try {
		
		
			
			
		

		if(!Search.equals("")) {
			
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				
			
		}
	}catch (Exception e) {
		
	}
	return stmt;
	}
	
	
	
	public ArrayList<ArrayList<String>> GetFirstBundleByEsId(String es_id)  {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select count(*) from indexed_bundle_master where ibm_es_id=?";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, Integer.parseInt(es_id));

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("count")) ;
					
			
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	
	public ArrayList<ArrayList<String>> getIndxSlipCountByIbm(int es_id,int ibm_id, int user_id,String role)  {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			String q1=""; 
			
			
			if(role.equals("Index Group")) {
				
				q1+=" and ibm.ibm_iu_user_id=?";
			}

			
			
			String q = "select count(ism.is_id) as slip_count,ibm.ibm_abcount,ibm.ibm_masterab_status_id,ibm.ibm_exmsheet_status_id  from indexed_bundle_master ibm\n"
					+ "inner join index_slip_manual ism on ibm.ibm_id=ism.is_ibm_id\n"
					+ "where ibm.ibm_es_id=?  and ism.is_ibm_id=? "+q1+" group by 2,3,4";
			
		
			stmt = conn.prepareStatement(q);
			stmt.setInt(1,es_id);
			stmt.setInt(2,ibm_id);
			
			if(role.equals("Index Group")) {
				
				stmt.setInt(3, user_id);
			}
			
			System.err.println("total_count_slip======"+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("slip_count")) ;
				list.add(rs.getString("ibm_abcount")) ;
				String ablist = rs.getString("ibm_masterab_status_id");
//				if(ablist.equals(1)) {
//					list.add("m_ablist") ;
//				}else {
//					list.add(rs.getString("ibm_masterab_status_id")) ;
//				}
				list.add((rs.getString("ibm_masterab_status_id").equals("1")) ? "m_ablist" : "0");
				list.add((rs.getString("ibm_exmsheet_status_id").equals("1")) ? "exm_sheet" : "0");
					
			
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	
	   public String DeleteBundlmaster(int deleteid) {
		   
		   int rowcoun=0;
		   
		   Connection conn = null;
			try {
				conn = dataSource.getConnection();
				PreparedStatement stmt = null;
				
				  
				  
				String q = "with new_a as (  DELETE FROM  indexed_bundle_master\n"
						+ "	WHERE  ibm_id=?)\n"
						+ "	 DELETE FROM  indexed_packing_notes_details\n"
						+ "	WHERE  ipnd_ibm_id=? ";
				
			
				stmt = conn.prepareStatement(q);
				stmt.setInt(1, deleteid);
				stmt.setInt(2,deleteid);
				 
				System.err.println("stmt======"+stmt);
				
				rowcoun= stmt.executeUpdate();
				 
				System.err.println("rowcoun======"+rowcoun);
				 
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
					}
				}
			}
			
			if ( rowcoun> 0) {
				return "Deleted Successfully";
			} else {
				return "Deleted not Successfully";
			}
		  
		}
	   
	   public ArrayList<ArrayList<String>> getBundleCount(String esi_es_id,String objid,String sc_id)  {
			ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
			Connection conn = null;
			try {
				conn = dataSource.getConnection();
				PreparedStatement stmt = null;
				String q = "select count(distinct ism.is_id) as total,count(distinct ism.is_id) filter(where tbc.close_status =0) as pending,\n"
						+ "count(distinct ism.is_id)-count(distinct ism.is_id) filter(where tbc.close_status =0) as scanned\n"
						+ "from tb_barcode_count tbc \n"
						+ "inner join index_slip_manual ism on ism.is_id=tbc.is_id\n"
						+ "where ism.is_ibm_id::text=? and ism.is_sc_subject_id::text =? ";
				stmt = conn.prepareStatement(q);
				stmt.setString(1, objid);
				stmt.setString(2, sc_id);
				System.err.println("total_count_slip======"+stmt);
				ResultSet rs = stmt.executeQuery();
				while (rs.next()) {
					ArrayList<String> list = new ArrayList<String>();
					list.add(rs.getString("total")) ;
					list.add(rs.getString("scanned")) ;
					list.add(rs.getString("pending")) ;
					alist.add(list);
				}
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
					}
				}
			}
			return alist;
		}
	   
  ////for opening
	   
	   public ArrayList<ArrayList<String>> getBundleCountforOP(String esi_es_id,String objid,String sc_id)  {
			ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
			Connection conn = null;
			try {
				conn = dataSource.getConnection();
				PreparedStatement stmt = null;
				String q = "select count(distinct ism.is_id) as total,count(distinct ism.is_id) filter(where tbc.opng_status =0) as pending,\n"
						+ "count(distinct ism.is_id)-count(distinct ism.is_id) filter(where tbc.opng_status =0) as scanned\n"
						+ "from tb_barcode_count tbc \n"
						+ "inner join index_slip_manual ism on ism.is_id=tbc.is_id\n"
						+ "where ism.is_ibm_id::text=? and ism.is_sc_subject_id::text =? ";
				stmt = conn.prepareStatement(q);
				stmt.setString(1, objid);
				stmt.setString(2, sc_id);
				System.err.println("total_count_slip======"+stmt);
				ResultSet rs = stmt.executeQuery();
				while (rs.next()) {
					ArrayList<String> list = new ArrayList<String>();
					list.add(rs.getString("total")) ;
					list.add(rs.getString("scanned")) ;
					list.add(rs.getString("pending")) ;
					alist.add(list);
				}
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
					}
				}
			}
			return alist;
		}
	   
	   
	   
			
	
}
