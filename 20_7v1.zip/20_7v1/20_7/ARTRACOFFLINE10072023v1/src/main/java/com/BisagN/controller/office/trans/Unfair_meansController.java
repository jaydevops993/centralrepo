package com.BisagN.controller.office.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.masters.Officer_personal_detailsController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.trans.Unfair_meansDAO;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.trans.ANSWER_BOOK_M;
import com.BisagN.models.officers.trans.EXAM_CENTER_CODE_M;
import com.BisagN.models.officers.trans.UNFAIR_MEANS_M;


@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Unfair_meansController {


@Autowired
private Unfair_meansDAO objDAO;


HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();


@Autowired
Officer_personal_detailsController ofc = new Officer_personal_detailsController();

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

@Autowired
private RoleBaseMenuDAO roledao; 


CommonController comm = new CommonController();


 
         @RequestMapping(value = "Searchunfair_meansUrl", method = RequestMethod.GET)
         public ModelAndView Searchunfair_meansUrl(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
  NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{
        	 
        	 if(request.getHeader("Referer") == null ) { 
    			 session.invalidate();
    			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
    			 return new ModelAndView("redirect:/login");
    		 }

        	 String roleid1 = session.getAttribute("roleid").toString();
    		 Boolean val = roledao.ScreenRedirect("Searchunfair_meansUrl", roleid1);		
    			if(val == false) {
    				return new ModelAndView("AccessTiles");
    		}	
        	 
        	 int es_id = Integer
     				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

     		if (es_id != 0) {
     			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, es_id);
//     			Date begin_date = UnlcokExmsch.get(0).getEs_begin_date();
     			 Mmap.put("es_id",es_id);
     		}
        	 Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));     	    
               Mmap.put("msg", msg);
         return new ModelAndView("SearchUnfair_means_tile","Searchunfair_meansCMD",new UNFAIR_MEANS_M());
}
 @RequestMapping(value = "/getUnfair_meansReportDataList", method = RequestMethod.POST)
 public @ResponseBody List<Map<String, Object>> getUnfair_meansReportDataList(int startPage,String pageLength,String Search,String orderColunm,String orderType,String exam_schedule_dt_id,HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
	return objDAO.getReportListUnfair_means(startPage,pageLength,Search,orderColunm,orderType,exam_schedule_dt_id,sessionUserId);
}

 @RequestMapping(value = "/getUnfair_meansTotalCount", method = RequestMethod.POST)
public @ResponseBody long getUnfair_meansTotalCount(HttpSession sessionUserId,String Search,String  exam_schedule_dt_id){
	return objDAO.getReportListUnfair_meansTotalCount(Search,exam_schedule_dt_id);
}
 
 
//     =========================================save======================================================
  @RequestMapping(value = "/unfair_meansAction" ,method = RequestMethod.POST) 
  public ModelAndView unfair_meansAction(@Valid @ModelAttribute("unfair_meansCMD") UNFAIR_MEANS_M ln, BindingResult result, 
  HttpServletRequest request, ModelMap model, HttpSession session){ 
	  
	  
	  Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		
		
          int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
	  try {
			
			String sc_subject_id= request.getParameter("sc_subject_id");
			String opd_personal_hid= request.getParameter("opd_personal_hid");
//			String opd_name= request.getParameter("opd_name");
			String arm_service= request.getParameter("arm_service");
			String um_remarks= request.getParameter("um_remarks");
			
		
		     String username = session.getAttribute("username").toString();
			Date date = new Date();
			
			if(sc_subject_id == "" || sc_subject_id.equals("0")) {
				model.put("msg", "Please Select Subject");		
				return new ModelAndView("redirect:Searchunfair_meansUrl");
			}
			if(opd_personal_hid.equals("")) {
				model.put("msg","Please Enter Personal Code");
				  return new ModelAndView("redirect:Searchunfair_meansUrl");
			  }
			
//			if(opd_name.equals("")) {
//				model.put("msg","Please Enter Name");
//				  return new ModelAndView("redirect:Searchunfair_meansUrl");
//			  }
//			
			if(arm_service.equals("")) {
				model.put("msg","Please Enter Arm/service");
				  return new ModelAndView("redirect:Searchunfair_meansUrl");
			  }
			if(um_remarks.equals("")) {
				model.put("msg","Please Enter Remarks");
				  return new ModelAndView("redirect:Searchunfair_meansUrl");
			  }
			List<OFFICER_APPLICATION_M>oappid=comm.getOappIdbyopdId(sessionFactory,Integer.parseInt(opd_personal_hid),es_id);
			if(!oappid.isEmpty()) {
				int oa_application_id=oappid.get(0).getOa_application_id(); 
		
		 Query q0 = sessionHQL.createQuery(
			  "select count(id) from UNFAIR_MEANS_M where opd_personal_id=:opd_personal_id and sc_subject_id=:sc_subject_id and es_id=:es_id ");

			q0.setParameter("opd_personal_id",Integer.parseInt(opd_personal_hid));
			q0.setParameter("sc_subject_id", Integer.parseInt(sc_subject_id));
			q0.setParameter("es_id",es_id);
			
			Long c = (Long) q0.uniqueResult();	
			
			if (c == 0  ) {
						
					

				ln.setUm_created_by(username);
				ln.setUm_creation_date(date);
			    ln.setEs_id(es_id);
				ln.setOpd_personal_id(Integer.parseInt(opd_personal_hid));
		        ln.setSc_subject_id(Integer.parseInt(sc_subject_id));
		        ln.setUm_remarks(um_remarks);
		        ln.setUm_status_id(1);
		        sessionHQL.save(ln);
		        
		        
		        
		        ANSWER_BOOK_M ansbook = new ANSWER_BOOK_M();
		        ansbook.setAb_marks_obtained(0);
				ansbook.setAb_created_by(username);
				ansbook.setAb_creation_date(date);
				ansbook.setAb_status_id(3);
				ansbook.setAb_unfair_status(1);
				ansbook.setOa_application_id(oa_application_id);
				ansbook.setSc_subject_id(Integer.parseInt(sc_subject_id));
				ansbook.setAb_first_entry(0);
				sessionHQL.save(ansbook);
		        
		        String hq1uf = "update OFFICER_PERSONAL_DETAILS_M set  opd_status_id=:opd_status_id  where opd_personal_id=:opd_personal_id ";
				Query queryuf = sessionHQL.createQuery(hq1uf)
						.setParameter("opd_status_id", 3).setParameter("opd_personal_id", Integer.parseInt(opd_personal_hid));
				queryuf.executeUpdate();
				
				
				
			
				     sessionHQL.save(ln);
					 tx.commit();

					
					model.put("msg","Data Saved Successfully"); 
		    
					
					}else {
						
						model.put("msg","Data already Exist"); 
					}
			}else {
				model.put("msg","Application not Generated"); 	
			}
				}catch (RuntimeException e) {
					try {
						tx.rollback();
						model.put("msg", "roll back transaction");
					} catch (RuntimeException rbe) {
						model.put("msg", "Couldn�t roll back transaction " + rbe);
					}
					throw e;
				} finally {
					if (sessionHQL != null) {
						sessionHQL.close();
					}
				}

				return new ModelAndView("redirect:Searchunfair_meansUrl"); 
				}	
		
         @RequestMapping(value = "EditUnfair_meansUrl", method = RequestMethod.POST)
         public ModelAndView EditUnfair_meansUrl(ModelMap Mmap, HttpServletRequest request,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String updateid  ) {

        	 	
        	 	System.out.println("updateid---------------"+updateid);
        	 	
                Session s1 = this.sessionFactory.openSession();
                Transaction tx = s1.beginTransaction();

                
                String status= request.getParameter("statusforupdate");
        		 
                String enckey = "commonPwdEncKeys";  
                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
                System.out.println("DcryptedPk---------------"+DcryptedPk);
               
                Query q = null;
                q = s1.createQuery("from UNFAIR_MEANS_M where cast(id as string)=:PK");
                q.setString("PK", DcryptedPk);
                
                @SuppressWarnings("unchecked")
                List<UNFAIR_MEANS_M> list = (List<UNFAIR_MEANS_M>) q.list();
                
          
                tx.commit();
                s1.close();
                int opd_personal_id= list.get(0).getOpd_personal_id();
                System.out.println("opd_personal_id---------------"+opd_personal_id);
                Session sessionHQL = this.sessionFactory.openSession();
    			Transaction tx1 = sessionHQL.beginTransaction();
               
        			Query qry = sessionHQL.createQuery("update UNFAIR_MEANS_M set um_status_id=:um_status_id where id=:id");
        			
        			
//        			==================================================
        			
        			 if(status.equals("Clear UFM"))
                     {
        				 qry.setParameter("um_status_id",1);
                     }
                     else
                     {
                    	 qry.setParameter("um_status_id",0);
                     }
//        			===================================================
        					
        					
        					
        					
        					
        			qry.setParameter("id",Integer.parseInt(DcryptedPk));
        			
        			qry.executeUpdate();
        			
        			  String hq1uf = "update OFFICER_PERSONAL_DETAILS_M set  opd_status_id=:opd_status_id  where opd_personal_id=:opd_personal_id ";
      				Query queryuf = sessionHQL.createQuery(hq1uf)
      						.setParameter("opd_status_id", 1).setParameter("opd_personal_id", opd_personal_id);
      				queryuf.executeUpdate();
      				
      				
      				 tx1.commit();
                     sessionHQL.close();
        			Mmap.put("msg", "Data Updated Successfully");	
        		//    Mmap.put("msg", msg);
               
            
          
       

                return new ModelAndView("redirect:Searchunfair_meansUrl");
         }


  @RequestMapping(value = "/deleteunfair_meansUrl", method = RequestMethod.POST) 
  public ModelAndView deleteunfair_meansUrl(String deleteid,HttpSession session,ModelMap model) { 
  	List<String> list = new ArrayList<String>(); 
  	list.add(objDAO.Deleteunfair_means(deleteid,session)); 
  	model.put("msg",list);  
    return new ModelAndView("redirect:Searchunfair_meansUrl"); 
  	}

  
  
  @RequestMapping(value = "Unfair_means_Url", method = RequestMethod.POST)
  public ModelAndView Unfair_means_Url(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String deleteid) {

	   
	  int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		
	  System.err.println("es_id==========="+es_id);
		if(es_id != 0) {
		List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
		Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
		LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		
		  int day = date.getDayOfMonth();
		  String[] months = {"Jan", "Feb", "Mar", "Apr" ,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		  
		  String[] shortMonths = new DateFormatSymbols().getShortMonths();
	        for (String shortMonth : shortMonths) {
	            
	      	 
	        }
		  
		  Month month = date.getMonth();
		  int year = date.getYear();
		  System.err.println(day+""+month+""+year);
		  System.err.println("o====="+month + ' ' + day + ' ' + year);
	String begindateShow= day +" "+ month + " "+ year;
		 
	 Mmap.put("begindateShow",begindateShow);
	int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

	if (ec_exam_id != 0) {
		List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
		Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
		Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
	}
		}  
        Mmap.put("msg", msg);
    return new ModelAndView("Unfair_means_tile");

  
  }
}
  
  

