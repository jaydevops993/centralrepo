package com.BisagN.dao.officer.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface PartB_marksDAO {
	
	public ArrayList<ArrayList<String>> PartBOfficerresult(int es_id, int subjectId);
	public List<Map<String, Object>> getPartBMarksDetails(int startPage,String pageLength,String Search,String orderColunm,String orderType,String sub_id,
			String es_id,String opd_personal_id,String officername,
			String indexno,
			HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, 
	InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	public long getPartBMarksdetailsTotalCount(String Search,String sub_id,String es_id,String opd_personal_id,String officername,
			String indexno) ;
	public ArrayList<ArrayList<String>> getpartbMarksdtl(String oapp_id,String subjectid);
 
	
	public ArrayList<ArrayList<String>> getpartbMarksquestiondtl( String subjectid,String applicationid);
	
	
	public ArrayList<String>  getcountformulmks( String subjectid,String es_id);
}
