package com.BisagN.dao.Indexing;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class IndexingDaoImpl implements IndexingDAO  {
	
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	CommonController comm= new CommonController();


	public List<Map<String, Object>> GetCandidateDetailsforIndexing(String application_no,int esid_es_id,int esid_sc_subject_id) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select vw.opd_officer_name, vw.rc_rank_name, vw.ac_arm_description,vw.opc_personal_code,cc.cc_command_id,ecc.ecc_center_code,ism.ism_indexno, \n"
					+ "ismn.is_sc_subject_id\n"
					+ "from officer_application ofa \n"
					+ "left join vw_personal_details vw on vw.opd_personal_id = ofa.opd_personal_id\n"
					+ "left join command_code cc on vw.cc_command_id = cc.cc_command_id\n"
					+ "left join exam_center_code ecc on ofa.oa_center_granted=ecc.ecc_center_code\n"
					+ "left join index_slip_master ism on ism.ism_armyno=vw.opc_personal_code and ism.ism_es_id=? \n"
					+ "left join index_slip_manual ismn on ismn.is_ism_id=ism.ism_id and ismn.is_sc_subject_id=? "
					+ "where ofa.oa_application_id=? ";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, esid_es_id);
			stmt.setInt(2, esid_sc_subject_id);
			stmt.setInt(3, Integer.parseInt(application_no));
		
			
			System.err.println("getDetailsPers====="+stmt);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();
			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
					columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
				list.add(columns);
				
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return list;
	}
   
	
	public ArrayList<ArrayList<String>> GetIndexDetailsforBarcoding(String ic_number,int es_id) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select ism_indexno from index_slip_master of_app  where ism_armyno=? and ism_es_id=? ";
			stmt = conn.prepareStatement(q);
			stmt.setString(1, ic_number);
			stmt.setInt(2, es_id);


	System.out.println("stmt=====fff===="+stmt);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ism_indexno"));//0
			
				alist.add(list);
				System.err.println("list---------------------"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	public ArrayList<ArrayList<String>> GetCountforIndexing(int es_id, int subject_id)  {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select count(*) as index_count from index_slip_master ism \n"
					+ "inner join index_slip_manual isp on isp.is_ism_id=ism.ism_id\n"
					+ "where ism.ism_es_id=? and isp.is_sc_subject_id=? ";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			stmt.setInt(2, subject_id);

	System.out.println("stmt=====fff===="+stmt);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("index_count"));//0
			
				alist.add(list);
				System.err.println("list---------------------"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	
	
	
	
	public boolean checkIsIntegerValue(String Search) {
		return Search.matches("[0-9]+");
		}
	
	
	public ArrayList<ArrayList<String>> getSubjectWiseIndxDetails(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,int es_id,String sc_subject_id,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		
		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search,sc_subject_id);
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String q1="";
		System.err.println("sc_subject_id : "+sc_subject_id);
		if(!sc_subject_id.equals("0")) {
			q1 += "and esid_sc_subject_id=?";
		}

		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			 q = "select sc.sc_subject_name,eid.esid_dtindexdate,eid.esid_startdatetime,eid.esid_enddatetime,eid.no_of_copies,\n"
			 		+ "count(ismn.is_abs) as abs_count from examschedule_indexing_detail  eid\n"
			 		+ "inner join index_slip_master ism on ism.ism_es_id=eid.esid_es_id\n"
			 		+ "left join index_slip_scanned iss on iss.is_updatedate=eid.esid_dtindexdate \n"
			 		+ "inner join index_slip_manual ismn on ismn.is_ism_id=ism.ism_id\n"
			 		+ "inner join subject_code sc on sc.sc_subject_id=eid.esid_sc_subject_id \n"
			 		+ "where eid.esid_es_id= ? "+q1+"   group by 1,2,3,4,5  "+SearchValue+" \n"
					+ "ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage;
			
			
			
			
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			if(!sc_subject_id.equals("0")) {
			stmt.setInt(2, Integer.parseInt(sc_subject_id));
			}
	System.out.println("stmt=====fff===="+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("esid_dtindexdate"));//0
				list.add(rs.getString("esid_startdatetime"));//0
				list.add(rs.getString("esid_enddatetime"));//0
				list.add(rs.getString("abs_count"));//0
				list.add(rs.getString("sc_subject_name"));//0
				
				System.err.println("list--------"+list);
				alist.add(list);
				

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	public long getTotalCountSubjectWiseIndxDetails(String Search,int es_id,String sc_subject_id) {

		String SearchValue = GenerateQueryWhereClause_SQL(Search,sc_subject_id);
	int total = 0;
	String q = null;
	Connection conn = null;
	String q1="";
	
	
	if(!sc_subject_id.equals("0")) {
		q1 += "and esid_sc_subject_id=?";
	}
	try {
		
		

		conn = dataSource.getConnection();
		q ="select count(*) from (select sc.sc_subject_name, eid.esid_dtindexdate,eid.esid_startdatetime,eid.esid_enddatetime,eid.no_of_copies,count(iss.is_abs) as abs_count,count(iss.is_scan_id) as scan_count from examschedule_indexing_detail  eid\n"
				+ "left join index_slip_scanned iss on iss.is_updatedate=eid.esid_dtindexdate \n"
				+ "inner join subject_code sc on sc.sc_subject_id=eid.esid_sc_subject_id\n"
				+ "where eid.esid_es_id= ? "+q1+"  group by 1,2,3,4,5"  +SearchValue +"   ) ab " ;
		
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereClause_SQL(stmt,Search,sc_subject_id);
		stmt.setInt(1, es_id);
		if(!sc_subject_id.equals("0")) {
		stmt.setInt(2,Integer.parseInt(sc_subject_id));
		
		}
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search, String sc_subject_id) {
		String SearchValue = "";

		try {
		
			if (!Search.equals("")) {
				Search = Search.toLowerCase();
				SearchValue = " and ( ";
				SearchValue += " lower(opc_personal_code) like ?  or lower(opd_officer_name) like ? or lower(ac_arm_description) like ?)";
						
			}
		} catch (Exception e) {
			
		}

		return SearchValue;

	}

	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,String sc_subject_id) {
		int flag = 1;
		
	try {
		if(!Search.equals("")) {
			
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				
			
		}
	}catch (Exception e) {
		
	}
	return stmt;
	}
	
	public ArrayList<ArrayList<String>> GetSubjectWiseIndexingDetails(int es_id, String sc_subject_id)  {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			String q = "select DISTINCT esid_dtindexdate,esid_startdatetime,esid_enddatetime,esid_sc_subject_id,no_of_copies,esid_sub_subject_id from examschedule_indexing_detail eid\n"
					+ "where esid_es_id= ? order by esid_enddatetime desc  ";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			
			System.err.println("in---------"+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("esid_startdatetime"));//0
				list.add(rs.getString("esid_enddatetime"));//1
				list.add(rs.getString("esid_sc_subject_id"));//2
				list.add(rs.getString("no_of_copies"));//3
				list.add(rs.getString("esid_sub_subject_id"));//3
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	
	
//	public ArrayList<ArrayList<String>> GetSubjectWiseIndexingDetails(int es_id, String sc_subject_id,String sub_sc_subject_id)  {
//		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
//		Connection conn = null;
//		try {
//			conn = dataSource.getConnection();
//			PreparedStatement stmt = null;
//			
//			String q1="";
//			String q2="";
//			
//			System.err.println("sc_subject_id============"+sc_subject_id);
//			
//			System.err.println("sub_sc_subject_id============"+sub_sc_subject_id);
//			
//			if(sc_subject_id != "null") {
//				q1+="count(ism.is_id) filter(where ism.is_sc_subject_id=?)as scan_count";
//				q2+="inner join index_slip_manual ism on ism.is_sc_subject_id=eid.esid_sc_subject_id";
//			}
//			
//			if(sub_sc_subject_id != "null") {
//				q1+="count(ism.is_id) filter(where ism.is_sub_subject_id=?)as scan_count";
//				q2+="inner join index_slip_manual ism on ism.is_sub_subject_id=eid.esid_sub_subject_id";
//			}
//			
////			String q = "select DISTINCT esid_dtindexdate,esid_startdatetime,esid_enddatetime,esid_sc_subject_id,no_of_copies,esid_sub_subject_id from examschedule_indexing_detail eid\n"
////					+ "where esid_es_id= ? order by esid_enddatetime desc  ";
//			
//			String q="select DISTINCT esid_dtindexdate,esid_startdatetime,esid_enddatetime,esid_sc_subject_id,no_of_copies,esid_sub_subject_id,\n"
//					+ ""+q1+"\n"
//					+ "from examschedule_indexing_detail eid\n"
//					+ ""+q2+"\n"
//					+ "where esid_es_id= ?\n"
//					+ "group by 1,2,3,4,5,6\n"
//					+ "order by esid_enddatetime desc  ";
//			stmt = conn.prepareStatement(q);
//			if(sc_subject_id != "null") {
//			stmt.setInt(1, Integer.parseInt(sc_subject_id));
//			}
//
//			if(sub_sc_subject_id != "null") {
//				stmt.setInt(1, Integer.parseInt(sub_sc_subject_id));
//				}
//			stmt.setInt(2, es_id);
//			System.err.println("in---------"+stmt);
//			ResultSet rs = stmt.executeQuery();
//			while (rs.next()) {
//				ArrayList<String> list = new ArrayList<String>();
//				list.add(rs.getString("esid_startdatetime"));//0
//				list.add(rs.getString("esid_enddatetime"));//1
//				list.add(rs.getString("esid_sc_subject_id"));//2
//				list.add(rs.getString("no_of_copies"));//3
//				list.add(rs.getString("esid_sub_subject_id"));//3
//				list.add(rs.getString("scan_count"));//3
//				alist.add(list);
//
//			}
//			rs.close();
//			stmt.close();
//			conn.close();
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			if (conn != null) {
//				try {
//					conn.close();
//				} catch (SQLException e) {
//				}
//			}
//		}
//		return alist;
//	}
	
	
	
	public ArrayList<ArrayList<String>> GetLockUnlockIndexingDetails(int es_id)  {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select esi_islocked from examschedule_indexing where esi_es_id=? ";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				if(rs.getString("esi_islocked").equals("0")) {
					list.add("Lock");
				}else
				{
					list.add("Unlock");
					
				}
			
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	public ArrayList<ArrayList<String>> getSubSubjectDetails(String sc_subject_id)  {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			String q = "select id, sub_subject from sub_subject_mst_tbl ss where sc_subject_id=? and subsubject_status=1";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, Integer.parseInt(sc_subject_id));
			
			System.err.println("in---------"+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("id"));//0
				list.add(rs.getString("sub_subject"));//1
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	public ArrayList<ArrayList<String>> getRegisteredPartDData(int es_id, int sc_subject_id,String command,String personal_code,String center)  {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
//			 vpd.cc_command_id=2
//					 and vpd.opc_personal_code='' and ofa.oa_center_granted=
//	String q1="vpd.cc_command_id=?";
//			
//			String q2="vpd.opc_personal_code=?";
//			
//			String q3="ofa.oa_center_granted=?";

			String q1="";
			
			int flag=2;
			
			
			if(!command.equals("0")) {
				q1+="and vpd.cc_command_id=?";
				 
			}
			
			if(!personal_code.equals("")) {
				q1 += "and vpd.opc_personal_code=?";
				 
			}
			
			if(!center.equals("0")) {
				q1 += "and ofa.oa_center_granted=?";
				
			}
			
		
			
			
			String q = "select vpd.opc_personal_code, vpd.opc_suffix_code,vpd.rc_rank_name, ofa.oa_application_id, ecc.ecc_name, vpd.ac_arm_description, vpd.cc_command_name, \n" + 
					"vpd.opd_unit, TO_CHAR(esd.esd_date,'DD/MM/YYYY') as esd_date,vpd.opd_officer_name, sc.sc_subject_name,(extract(year FROM es.es_begin_date )::int ) as es_year from officer_application ofa\n" + 
					"inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n" + 
					"inner join exam_center_code ecc on ecc.ecc_center_code=ofa.oa_center_granted\n" + 
					"inner join exam_schedule es on ofa.es_id = es.es_id\n" + 
					"left join exam_schedule_detail esd on esd.es_id = es.es_id\n"
					+ "inner join subject_code sc on esd.sc_subject_id=sc.sc_subject_id \n" + 
					"where ofa.es_id=? and esd.sc_subject_id=? " +q1+ "";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			stmt.setInt(2, sc_subject_id);
			
			if(!command.equals("0")) {
				flag+=1;
				stmt.setInt(flag,Integer.parseInt(command));
			}
			if(!personal_code.equals("")) {
				flag+=1;
				stmt.setString(flag, personal_code);
			}
			
			if(!center.equals("0")) {
				flag+=1;
				stmt.setInt(flag,Integer.parseInt(center) );
			}
			
			
			System.err.println("in-s--------"+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
				list.add(opc_personal_code);//0
				
//				list.add(rs.getString("opc_personal_code")+""+rs.getString("opc_suffix_code"));//0
				list.add(rs.getString("oa_application_id"));//1
				list.add(rs.getString("ecc_name"));//2
				list.add(rs.getString("ac_arm_description"));//3
				list.add(rs.getString("cc_command_name"));//4
				list.add(rs.getString("opd_unit"));//5
				list.add(rs.getString("esd_date"));//6
				list.add(rs.getString("opd_officer_name"));//7
				list.add(rs.getString("sc_subject_name"));//8
				list.add(rs.getString("es_year"));//9
				list.add(rs.getString("rc_rank_name"));//10
				
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	
	
	
	
	
	
	public ArrayList<ArrayList<String>> GetBarcodcount(int oa_app_id,int es_id,int subject_id) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			
			
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = " select COUNT(*)filter (where close_status=0) as scancount,COUNT(*) as allcount from tb_barcode_count where oa_app_id=? and es_id=? and subject_id=? ";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, oa_app_id);
			stmt.setInt(2, es_id);
			stmt.setInt(3, subject_id);

	System.out.println("stmt=====fff===="+stmt);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("scancount"));//0
				list.add(rs.getString("allcount"));
				alist.add(list);
				System.err.println("list---------------------"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	public ArrayList<ArrayList<String>> getIndxSlipBundleCountByIbm(int subject_id,int es_id)  {
		ArrayList<ArrayList<String>> alist1 = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			String q1=""; 
			
			
//			if(role.equals("Index Group")) {
//				
//				q1+=" and ibm.ibm_iu_user_id=?";
//			}

			
			
			String q = "SELECT count (*) as totalscannedcount FROM (select  tbc.oa_app_id from (\n"
					+ "SELECT oa_app_id, count (*) as indsane from tb_barcode_count where close_status = 1 and tb_barcode_count.subject_id =? and tb_barcode_count.es_id =? \n"
					+ "	GROUP by oa_app_id\n"
					+ ") as indss\n"
					+ "inner join tb_barcode_count tbc on tbc.oa_app_id = indss.oa_app_id\n"
					+ "where tbc.subject_id =? and tbc.es_id =?  \n"
					+ "GROUP by tbc.oa_app_id ,indss.indsane\n"
					+ "HAVING indss.indsane = count ( tbc.oa_app_id)) as btobescan";
			
		
			stmt = conn.prepareStatement(q);
			stmt.setInt(1,subject_id);
			stmt.setInt(2,es_id);
			stmt.setInt(3,subject_id);
			stmt.setInt(4,es_id);
//			
//			if(role.equals("Index Group")) {
//				
//				stmt.setInt(3, user_id);
//			}
			
			System.err.println("total_bundlecount_slip======"+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("totalscannedcount")) ;
			
			
				alist1.add(list);
				System.err.println("=====listcount======"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist1;
	}
	
/////////////////////////////////////////////
	public ArrayList<ArrayList<String>> GetcurrentBarcode(int es_id,int subject_id,String User){
		ArrayList<ArrayList<String>> alist1 = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			

			String q = "select count(*) as cnt,tbc.barcode_no from tb_barcode_count tbc \n"
					+ "inner join index_slip_manual ism on ism.is_id=tbc.is_id\n"
					+ "inner join indexed_bundle_master ibm on ibm.ibm_id=ism.is_ibm_id\n"
					+ "where tbc.is_id in (select is_id from tb_barcode_count a where a.close_by=?) and tbc.close_status=0 \n"
					+ "and ism.is_sc_subject_id=?\n"
					+ "group by 2";
			
		
			stmt = conn.prepareStatement(q);
			stmt.setString(1,User);
			stmt.setInt(2,es_id);
			stmt.setInt(3,subject_id);
//			stmt.setInt(4,es_id);
//			
//			if(role.equals("Index Group")) {
//				
//				stmt.setInt(3, user_id);
//			}
			
			System.err.println("total_bundlecount_slip======"+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("cnt")) ;
				list.add(rs.getString("barcode_no")) ;
				alist1.add(list);
				System.err.println("=====listcount======"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist1;
	}
	
	///////////////////
	public ArrayList<ArrayList<String>> GetcountCL(int es_id,int subject_id){
		ArrayList<ArrayList<String>> alist1 = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			

			String q = "SELECT count(*) as total from tb_barcode_count \n"
					+ "where es_id=? and subject_id =? and close_status=0";
			
		
			stmt = conn.prepareStatement(q);
			stmt.setInt(1,es_id);
			stmt.setInt(2,subject_id);
			//stmt.setInt(3,subject_id);
//			stmt.setInt(4,es_id);
//			
//			if(role.equals("Index Group")) {
//				
//				stmt.setInt(3, user_id);
//			}
			
			System.err.println("total_bundlecount_slip======"+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("total")) ;
			//	list.add(rs.getString("barcode_no")) ;
				alist1.add(list);
				System.err.println("=====listcount======"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist1;
	}
	

	

	
	
	
	
	
	
	
}
