package com.BisagN.dao.officer.report;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;



@Service
public class PartD_ReportDaoImpl implements PartD_ReportDAO{
	@Autowired
    private DataSource dataSource;
	
	CommonController comm = new CommonController();
	
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	public ArrayList<ArrayList<String>> getArmsubsummaryresult(int es_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		List<SUBJECT_CODE_M> sublist= comm.getsubjectlist(sessionFactory, 2);
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String qbuilder="";

			for (SUBJECT_CODE_M subject_CODE_M : sublist) {
				qbuilder+="COUNT(distinct ismn.is_ism_id) filter (where ismn.is_sc_subject_id="+subject_CODE_M.getSc_subject_id()+" and  ism.ism_es_id=? ) as appd_"+subject_CODE_M.getSc_form_caption().toLowerCase()+",\n"
						+ "COUNT(distinct ofr.opd_personal_id) filter (where ofr.sc_subject_id="+subject_CODE_M.getSc_subject_id()+" and ofr.or_subject_pass='1' and ofr.es_id=?) as pass_"+subject_CODE_M.getSc_form_caption().toLowerCase()+" , ";
			}
			qbuilder = qbuilder.substring(0,qbuilder.length()-3);
			q = "select vw.ac_arm_description ,vw.ac_arm_order, \n"
					+qbuilder
					+ "\n"
					+ "from officer_results ofr\n"
					+ "		inner join officer_application ofres on ofres.opd_personal_id=ofr.opd_personal_id  \n"
					+ "			inner join vw_personal_details vw on vw.opd_personal_id = ofr.opd_personal_id \n"
					+ "				inner join index_slip_master ism on ism.ism_armyno=vw.opc_personal_code \n"
					+ "				inner join index_slip_manual ismn on ism.ism_id=ismn.is_ism_id\n"
					+ "				where ism.ism_es_id=? group by 1,vw.ac_arm_order \n"
					+ "UNION all \n"
					+ "select 'Total','9999', \n"
					+qbuilder
					+"\n"
					+ "from officer_results ofr\n"
					+ "		inner join officer_application ofres on ofres.opd_personal_id=ofr.opd_personal_id  \n"
					+ "			inner join vw_personal_details vw on vw.opd_personal_id = ofr.opd_personal_id \n"
					+ "				inner join index_slip_master ism on ism.ism_armyno=vw.opc_personal_code \n"
					+ "				inner join index_slip_manual ismn on ism.ism_id=ismn.is_ism_id\n"
					+ "				where ism.ism_es_id=? group by 1 order by 2";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			stmt.setInt(2, es_id);
			stmt.setInt(3, es_id);
			stmt.setInt(4, es_id);
			stmt.setInt(5, es_id);
			stmt.setInt(6, es_id);
			stmt.setInt(7, es_id);
			stmt.setInt(8, es_id);
			stmt.setInt(9, es_id);
			stmt.setInt(10, es_id);
			stmt.setInt(11, es_id);
			stmt.setInt(12, es_id);
			stmt.setInt(13, es_id);
			stmt.setInt(14, es_id);
			stmt.setInt(15, es_id);
			stmt.setInt(16, es_id);
			stmt.setInt(17, es_id);
			stmt.setInt(18, es_id);
			stmt.setInt(19, es_id);
			stmt.setInt(20, es_id);
			stmt.setInt(21, es_id);
			stmt.setInt(22, es_id);
			stmt.setInt(23, es_id);
			stmt.setInt(24, es_id);
			stmt.setInt(25, es_id);
			stmt.setInt(26, es_id);
			
			
			
			System.err.println("sub--------"+stmt);
			ResultSet rs = stmt.executeQuery();
			DecimalFormat df_double = new DecimalFormat("0.00");

			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ac_arm_description"));
				for (SUBJECT_CODE_M subject_CODE_M : sublist) {
					double passed_whole_exam = Integer.parseInt(rs.getString("appd_"+subject_CODE_M.getSc_form_caption().toLowerCase()));
					double total_candidate_appeared = Integer.parseInt(rs.getString("pass_"+subject_CODE_M.getSc_form_caption().toLowerCase()));				
					list.add(rs.getString("appd_"+subject_CODE_M.getSc_form_caption().toLowerCase()));
					list.add(rs.getString("pass_"+subject_CODE_M.getSc_form_caption().toLowerCase()));
					if(passed_whole_exam==0) {
						passed_whole_exam=1;
					}	
					double pers_passed_whole_exam = (total_candidate_appeared * 100)/passed_whole_exam;
					list.add(df_double.format(pers_passed_whole_exam));
				}
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	public ArrayList<ArrayList<String>> getFullyPassedForPartD(int es_id, String oa_application_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";
	if(!oa_application_id.equals("")) {
		
		whr+= "and oapp.oa_application_id=?";
	}
		

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			
			q="select distinct pfd.ser_no, pfd.es_id,\n"
					+ "    vw.opd_personal_id,\n"
					+ "    vw.opc_personal_code,  vw.opc_suffix_code,\n"
					+ "    vw.rc_rank_name,\n"
					+ "    vw.opd_officer_name,\n"
					+ "    vw.ac_arm_description,pfd.oa_app_id,\n"
					+ "    vw.ac_arm_code from tb_partpass_fullpass_dtl pfd\n"
					+ "inner join vw_personal_details vw on pfd.opd_personal_id = vw.opd_personal_id \n"
					+ "inner join officer_application oapp on vw.opd_personal_id = oapp.opd_personal_id \n"
					+ "where pfd.es_id=? and pfd.result=1 "+whr+" order by pfd.ser_no asc , vw.opc_personal_code ";


		
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			if(!oa_application_id.equals("")) {
				stmt.setInt(2,Integer.parseInt(oa_application_id));
			}
			
			System.err.println("smt====fu===="+stmt);
			ResultSet rs = stmt.executeQuery();
	int i=1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				String ArmCode=rs.getString("ac_arm_code");
				int armcodestringsize=ArmCode.length();
				
				list.add(String.valueOf(i));
				list.add(Data+" "+(rs.getString("opc_suffix_code")));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				if(armcodestringsize == 1)
					list.add(rs.getString("ac_arm_description")+" (0"+(rs.getString("ac_arm_code")+")"));
				else
					list.add(rs.getString("ac_arm_description")+" ("+(rs.getString("ac_arm_code")+")"));
				list.add(rs.getString("opd_personal_id"));
				list.add(rs.getString("oa_app_id"));
				alist.add(list);
				i++;
				//System.err.println("list============"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	
	public ArrayList<ArrayList<String>> getPartPassedandFailuresForPartD(String es_year,String oa_application_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		try {
			List<SUBJECT_CODE_M> sublist= comm.getsubjectlist(sessionFactory, 2);
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String qbuilder="";
			
			String whr="";
			
			
			if(!oa_application_id.equals("")) {
				
			whr+="where cy.oa_application_id=?";
			}

//			for (SUBJECT_CODE_M subject_CODE_M : sublist) {
//				qbuilder+= "string_agg(case when ab.ab_marks_obtained>200 then 'NP' else ab.ab_marks_obtained::text end, ','::text) filter (where ab.sc_subject_id::text = "+subject_CODE_M.getSc_subject_id()+"::text) as ta_"+subject_CODE_M.getSc_form_caption().toLowerCase()+" "+" ,\n";
//			}
//			qbuilder = qbuilder.substring(0,qbuilder.length()-3);
//			
//			q =  "select oa.oa_application_id,opc.opc_personal_code, opc.opc_suffix_code,opd.opd_officer_name,rc.rc_rank_name, ar.ac_arm_description,ar.ac_arm_code,\n"
//					+qbuilder
//					+ "from officer_application oa\n"
//					+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
//					+ "left join exam_schedule es on es.es_id = oa.es_id\n"
//					+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id\n"
//					+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
//					+ "left join officer_rank ofr on ofr.opd_personal_id = opd.opd_personal_id\n"
//					+ "left join officer_arm ofar on ofar.opd_personal_id = opd.opd_personal_id\n"
//					+ "inner join rank_code rc on rc.rc_rank_id = ofr.rc_rank_id\n"
//					+ "inner join arm_codes ar on ar.ac_arm_id = ofar.ac_arm_id\n"
//					+ "where extract (year from es.es_begin_date) = 2023 and \n"
//					+ "es.ec_exam_id=1\n"
//					+ "group by oa.oa_application_id,opc.opc_personal_code, opc.opc_suffix_code,opd.opd_officer_name,rc.rc_rank_name,ar.ac_arm_description,ar.ac_arm_code";
	//	
			
	q="select cy.pbda_sub_code, cy.oa_application_id,cy.opc_personal_code||' '||cy.opc_suffix_code as opc_personal_code,cy.opd_officer_name,cy.opc_suffix_code,cy.opd_officer_name,\n"
			+ "rc.rc_rank_name, ar.ac_arm_description,ar.ac_arm_code,cy.opd_personal_id,\n"
			+ " case when cy.ta_t is null and py.ta_t is null and position('T' in getsubjectnamefromcode(cy.pbda_sub_code,2))=0 then 'NA'\n"
			+ "	when cy.ta_t is null and py.ta_t is null and position('T' in getsubjectnamefromcode(cy.pbda_sub_code,2))>0 then 'ABS'\n"
			+ "	when cy.ta_t is null and py.ta_t is not null then py.ta_t else cy.ta_t end as ta_t,\n"
			+ "	\n"
			+ "	case when cy.ta_a is null and py.ta_a is null and position('A' in getsubjectnamefromcode(cy.pbda_sub_code,2))=0 then 'NA' \n"
			+ "	when cy.ta_a is null and py.ta_a is null and position('A' in getsubjectnamefromcode(cy.pbda_sub_code,2))>0 then 'ABS' \n"
			+ "	when cy.ta_a is null and py.ta_a is not null then py.ta_a else cy.ta_a end as ta_a,\n"
			+ "	\n"
			+ "	case when cy.ta_l is null and py.ta_l is null and position('L' in getsubjectnamefromcode(cy.pbda_sub_code,2))=0 then 'NA'\n"
			+ "	when cy.ta_l is null and py.ta_l is null and position('L' in getsubjectnamefromcode(cy.pbda_sub_code,2))>0 then 'ABS'\n"
			+ "	when cy.ta_l is null and py.ta_l is not null then py.ta_l else cy.ta_l end as ta_l,\n"
			+ "	\n"
			+ "	case when cy.ta_h is null and py.ta_h is null and position('H' in getsubjectnamefromcode(cy.pbda_sub_code,2))=0 then 'NA'\n"
			+ "	when cy.ta_h is null and py.ta_h is null and position('H' in getsubjectnamefromcode(cy.pbda_sub_code,2))>0 then 'ABS'\n"
			+ "	when cy.ta_h is null and py.ta_h is not null then py.ta_h else cy.ta_h end as ta_h,\n"
			+ "	\n"
			+ "	case when cy.ta_c is null and py.ta_c is null and position('C' in getsubjectnamefromcode(cy.pbda_sub_code,2))=0 then 'NA'\n"
			+ "	when cy.ta_c is null and py.ta_c is null and position('C' in getsubjectnamefromcode(cy.pbda_sub_code,2))>0 then 'ABS'\n"
			+ "	when cy.ta_c is null and py.ta_c is not null then py.ta_c else cy.ta_c end as ta_c,\n"
			+ "	case when cy.ta_s is null and py.ta_s is null and position('S' in getsubjectnamefromcode(cy.pbda_sub_code,2))=0 then 'NA' \n"
			+ "	when cy.ta_s is null and py.ta_s is null and position('S' in getsubjectnamefromcode(cy.pbda_sub_code,2))>0 then 'ABS' \n"
			+ "	when cy.ta_s is null and py.ta_s is not null then py.ta_s else cy.ta_s end as ta_s, "
			//+ "	case when cy.ta_t is null and py.ta_t is null then 'ABS' when cy.ta_t is null and py.ta_t is not null then py.ta_t else cy.ta_t end as ta_t,\n"
			//+ "	case when cy.ta_a is null and py.ta_a is null then 'ABS' when cy.ta_a is null and py.ta_a is not null then py.ta_a else cy.ta_a end as ta_a,\n"
			//+ "		case when cy.ta_l is null and py.ta_l is null then 'ABS' when cy.ta_l is null and py.ta_l is not null then py.ta_l else cy.ta_l end as ta_l,\n"
			//+ "			case when cy.ta_h is null and py.ta_h is null then 'ABS' when cy.ta_h is null and py.ta_h is not null then py.ta_h else cy.ta_h end as ta_h,\n"
			//+ "	case when cy.ta_c is null and py.ta_c is null then 'ABS' when cy.ta_c is null and py.ta_c is not null then py.ta_c else cy.ta_c end as ta_c,\n"
			//+ "	case when cy.ta_s is null and py.ta_s is null then 'ABS' when cy.ta_s is null and py.ta_s is not null then py.ta_s else cy.ta_s end as ta_s,\n"
			+ "	string_agg(distinct getsubjectnamefromcode(cy.pbda_sub_code,2),',') filter (where cy.opd_partd =0)  as yettopass\n"
			+ "from\n"
			+ "(select opc.opc_personal_code,opc.opc_suffix_code,opd.opd_officer_name,opd.opd_partd,opd.pbda_sub_code,opd.opd_personal_id,oa.oa_application_id,ab.ab_status_id,\n"
			+ "string_agg(case when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 200 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 56::text) as ta_t,\n"
			+ " string_agg(case when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 200 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 57::text) as ta_a,\n"
			+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 200 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 58::text) as ta_l,\n"
			+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 200 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 59::text) as ta_h,\n"
			+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 200 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 60::text) as ta_c,\n"
			+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 200 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 61::text) as ta_s \n"
			+ "from officer_application oa\n"
			+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
			+ "left join exam_schedule es on es.es_id = oa.es_id\n"
			+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id and opd.opd_status_id != 0\n"
			+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
			+ "where oa.oa_status_id=1 and extract (year from es.es_begin_date) = "+es_year+" and es.ec_exam_id=2 and opd.opd_partd =0\n"
			+ "group by opc.opc_personal_code,opc.opc_suffix_code,opd.opd_officer_name,opd.opd_partd,opd.pbda_sub_code,opd.opd_personal_id,oa.oa_application_id,ab.ab_status_id) as cy\n"
			+ "left join \n"
			+ "(select opc.opc_personal_code, \n"
			+ " string_agg(case when ab.ab_marks_obtained>= 200 then 'PP' end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 56::text) as ta_t,\n"
			+ "string_agg(case when ab.ab_marks_obtained>= 200 then 'PP' end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 57::text) as ta_a,\n"
			+ "string_agg(case when ab.ab_marks_obtained>= 200 then 'PP' end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 58::text) as ta_l,\n"
			+ "string_agg(case when ab.ab_marks_obtained>= 200 then 'PP' end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 59::text) as ta_h,\n"
			+ "string_agg(case when ab.ab_marks_obtained>= 200 then 'PP' end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 60::text) as ta_c,\n"
			+ "string_agg(case when ab.ab_marks_obtained>= 200 then 'PP' end, ','::text\n"
			+ "		  ) filter (where ab.sc_subject_id::text = 61::text) as ta_s \n"
			+ "from officer_application oa\n"
			+ "inner join answer_book ab ON oa.oa_application_id = ab.oa_application_id\n"
			+ "left join exam_schedule es on es.es_id = oa.es_id\n"
			+ "left join officer_personal_details opd on opd.opd_personal_id=oa.opd_personal_id and opd.opd_status_id != 0 \n"
			+ "left join officer_personal_code opc on opc.opd_personal_id = opd.opd_personal_id\n"
			+ "where oa.oa_status_id=1 and extract (year from es.es_begin_date) !=  "+es_year+" and es.ec_exam_id=2 and (opd.opd_partd =0 or opd.opd_partd = "+es_year+") \n"
			+ "group by opc.opc_personal_code\n"
			+ "order by 1) py on cy.opc_personal_code=py.opc_personal_code\n"
			+ "left join officer_rank ofr on ofr.opd_personal_id = cy.opd_personal_id\n"
			+ "left join officer_arm ofar on ofar.opd_personal_id = cy.opd_personal_id\n"
			+ "inner join rank_code rc on rc.rc_rank_id = ofr.rc_rank_id\n"
			+ "inner join arm_codes ar on ar.ac_arm_id = ofar.ac_arm_id\n"
			+ " \n"
			+ "group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16\n"
			+ "order by 3";
			
			stmt = conn.prepareStatement(q);
			if(!oa_application_id.equals("")) {
				stmt.setInt(1,Integer.parseInt(oa_application_id));
			}
			System.out.println("stmt -------gggg-----------"+stmt);
			ResultSet rs = stmt.executeQuery();
	int i=1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				
				
				Data=DataPre+DataM;
				String ArmCode=rs.getString("ac_arm_code");
				int armcodestringsize=ArmCode.length();

				
				list.add(String.valueOf(i));
				list.add(Data);
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				//list.add(rs.getString("ac_arm_description")+"("+(rs.getString("ac_arm_code")+")"));
				if(armcodestringsize == 1)
					list.add(rs.getString("ac_arm_description")+" (0"+(rs.getString("ac_arm_code")+")"));
				else
					list.add(rs.getString("ac_arm_description")+" ("+(rs.getString("ac_arm_code")+")"));
				for (SUBJECT_CODE_M subject_CODE_M : sublist) {
					list.add(rs.getString("ta_"+subject_CODE_M.getSc_form_caption().toLowerCase()));			
				}
				
				
				list.add(rs.getString("yettopass"));
				list.add(rs.getString("opd_personal_id"));
				list.add(rs.getString("pbda_sub_code"));
			
				list.add(rs.getString("oa_application_id"));
				list.add(Data);
				alist.add(list);
				//System.out.println("list ------------------"+list);
				i++;

			

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	//===========================PART ABSENTEES=======================//

	public ArrayList<ArrayList<String>> PartAbsenteesForPartD(int es_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q="select a.opd_personal_id,vpd.rc_rank_name , vpd.opc_personal_code , vpd.opd_officer_name ,string_agg(sub,',')as \n"
					+ "subject,vpd.opc_suffix_code from (select oa.opd_personal_id,'T' as sub												\n"
					+ "	from officer_application oa, partb_d_application pbd											\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and (pbd.pbda_subjects & 2)= 2											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and (oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =56)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 56 and ab_marks_obtained is null))										\n"
					+ "union all												\n"
					+ "	select oa.opd_personal_id,'A' as sub											\n"
					+ "	from officer_application oa, partb_d_application pbd											\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and (pbd.pbda_subjects & 4)= 4											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and 											\n"
					+ "	(oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =57)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 57 and ab_marks_obtained is null))										\n"
					+ "union all												\n"
					+ "	select oa.opd_personal_id,'L' as sub											\n"
					+ "	from officer_application oa, partb_d_application pbd											\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and (pbd.pbda_subjects & 8)= 8											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and 											\n"
					+ "	(oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =58)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 58 and ab_marks_obtained is null))										\n"
					+ "												   union all\n"
					+ "	select oa.opd_personal_id,'H' as sub											\n"
					+ "	from officer_application oa, partb_d_application pbd											\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and (pbd.pbda_subjects & 32)= 32											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and 											\n"
					+ "	(oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =59)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 59 and ab_marks_obtained is null))										\n"
					+ "												   union all\n"
					+ "	select oa.opd_personal_id,'C' as sub											\n"
					+ "	from officer_application oa, partb_d_application pbd											\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and (pbd.pbda_subjects & 16)= 16											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and 											\n"
					+ "	(oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =60)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 60 and ab_marks_obtained is null))\n"
					+ "	union all\n"
					+ "	\n"
					+ "	select oa.opd_personal_id,'S' as sub											\n"
					+ "	from officer_application oa, partb_d_application pbd											\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and (pbd.pbda_subjects & 4)= 4											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and 											\n"
					+ "	(oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =61)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 61 and ab_marks_obtained is null))) a		\n"
					+ "	inner join vw_personal_details vpd on vpd.opd_personal_id=a.opd_personal_id  \n"
					+ "	group by 1,2,3,4,vpd.opc_suffix_code";

		
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			stmt.setInt(2, es_id);
			stmt.setInt(3, es_id);
			stmt.setInt(4, es_id);
			stmt.setInt(5, es_id);
			stmt.setInt(6, es_id);
			ResultSet rs = stmt.executeQuery();
	System.err.println("absentees========"+stmt);
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				//System.err.println("DataPre "+ DataPre);
				//System.err.println("DataM "+ DataM);
				
				Data=DataPre+DataM;
				
				//System.err.println("pers_cde==rrrrr====="+Data);
				
				list.add(Data +rs.getString("opc_suffix_code"));
				list.add(rs.getString("rc_rank_name")+" "+(rs.getString("opd_officer_name")+" "));
				list.add(rs.getString("subject"));
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	public ArrayList<ArrayList<String>> IndexagainstmarksObtainedForPartD(int es_id, int subject_id1,int arm_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";

		

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "select   of_app.in_index_id,ab.ab_marks_obtained,arc.ac_arm_description from vw_personal_details vw\n"
					+ "inner join officer_application of_app on of_app.opd_personal_id = vw.opd_personal_id\n"
					+ "inner join answer_book ab on ab.oa_application_id = of_app.oa_application_id\n"
					+ "inner join officer_arm ofarm on of_app.opd_personal_id = ofarm.opd_personal_id\n"
					+ "inner join arm_codes arc on ofarm.ac_arm_id = arc.ac_arm_id\n"
					+ "where of_app.es_id=?  and ab.sc_subject_id=? and ofarm.ac_arm_id=? order by of_app.in_index_id " ;

		
			stmt = conn.prepareStatement(q);
		
			stmt.setInt(1, es_id);
			stmt.setInt(2, subject_id1);
			ResultSet rs = stmt.executeQuery();
			System.out.println("stmt ---------jjjj---------"+stmt);
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("in_index_id"));
				list.add(rs.getString("ab_marks_obtained"));
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	public ArrayList<ArrayList<String>> getArmServiceAnalysisResultsPartD(int es_id, String es_year){
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
//	q="select vw.ac_arm_description , \n"
//			+ "COUNT(distinct ofr.oa_application_id)filter (where ofr.in_index_id != 0 and ofr.es_id=? )as total_candidate_appeared,\n"
//			+ "count(distinct vw.opd_personal_id)filter (where  vw.opd_partd = "+es_year+" ) as passed_whole_exam,\n"
//			+ "\n"
//			+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and vw.opd_partd = 0 and pbd.pbda_subjects != vw.pbda_sub_code and ofr.es_id=?) \n"
//			+ "as partially_passed_exam,\n"
//			+ " count(DISTINCT vw.opd_personal_id )filter(where ofr.in_index_id != 0  and pbd.pbda_subjects = vw.pbda_sub_code and ofr.es_id=?  ) as failed_subject,\n"
//			+ " \n"
//			+ "\n"
//			+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
//			+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)=\n"
//			+ "	(select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2))  as app_total_candidate_appeared,\n"
//			+ "\n"
//			+ "\n"
//			+ "\n"
//			+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
//			+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'  and ors.es_id=?)=\n"
//			+ " (select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2)) as all,\n"
//			+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
//			+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'  and ors.es_id=? and vw.opd_partd != 0)='5' and \n"
//			+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)=\n"
//			+ "(select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2)))  as five,\n"
//			+ "  count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
//			+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id=? and vw.opd_partd != 0)='4'\n"
//			+ "and(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)=\n"
//			+ "(select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2)) ) as four,\n"
//			+ "   count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
//			+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id=? and vw.opd_partd != 0)='3' and\n"
//			+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)=\n"
//			+ "(select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2))) as three,\n"
//			+ " \n"
//			+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
//			+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id=? and vw.opd_partd != 0)='2' and\n"
//			+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)=\n"
//			+ "(select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2))) as two,\n"
//			+ "\n"
//			+ "\n"
//			+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
//			+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1' and ors.es_id=? and vw.opd_partd != 0 )='1' and\n"
//			+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)=\n"
//			+ "(select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2))) as one,\n"
//			+ "\n"
//			+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
//			+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='0' and ors.es_id=? and vw.opd_partd != 0 )='6' and\n"
//			+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?)=\n"
//			+ "(select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2))) as none\n"
//			+ "from officer_application ofr\n"
//			+ "inner join vw_personal_details vw on vw.opd_personal_id = ofr.opd_personal_id and vw.opd_status_id=1 \n"
//			+ "inner join partb_d_application pbd on pbd.oa_application_id = ofr.oa_application_id where ofr.oa_status_id=1 \n"
//			+ "  group by 1,vw.ac_arm_order order by vw.ac_arm_order";
			q="select vw.ac_arm_description , \n"
					+ "COUNT(distinct ofr.oa_application_id)filter (where ofr.in_index_id != 0 and ofr.es_id= ? )as total_candidate_appeared,\n"
					+ "count(distinct vw.opd_personal_id)filter (where  vw.opd_partd = "+es_year+" )as passed_whole_exam,\n"
					+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and vw.opd_partd = 0 and pbd.pbda_subjects != vw.pbda_sub_code and ofr.es_id= ?)\n"
					+ "as partially_passed_exam,\n"
					+ " count(DISTINCT vw.opd_personal_id )filter(where ofr.in_index_id != 0  and pbd.pbda_subjects = vw.pbda_sub_code and ofr.es_id= ?  ) as failed_subject,\n"
					+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
					+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id= ? and ofr.in_index_id != 0  )=\n"
					+ "	(select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2  and ofr.es_id= ? ))  as app_total_candidate_appeared,\n"
					+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
					+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'  and ors.es_id= ? and vw.opd_partd != 0  and pbd.pbda_subjects != vw.pbda_sub_code  )=\n"
					+ " (select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2   and ofr.es_id= ?   )) as all,\n"
					+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
					+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1' and ors.es_id= ? and  pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd !=0 )='5'))  as five,\n"
					+ "  count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
					+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id= ? and pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd !=0  )='4') ) as four,\n"
					+ "   count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
					+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id= ? and pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd !=0)='3' )) as three,\n"
					+ " \n"
					+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
					+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'  and ors.es_id= ? and pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd !=0 )='2')) as two,\n"
					+ "\n"
					+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
					+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1' and ors.es_id= ? and pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd !=0   )='1')) as one,\n"
					+ "\n"
					+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and\n"
					+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='0'  and ors.es_id= ? and pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd =0  )=\n"
					+ " '6') as none\n"
					+ "from officer_application ofr\n"
					+ "inner join vw_personal_details vw on vw.opd_personal_id = ofr.opd_personal_id \n"
					+ "inner join partb_d_application pbd on pbd.oa_application_id = ofr.oa_application_id where ofr.oa_status_id=1 and ofr.es_id= ?\n"
					+ "  group by 1,vw.ac_arm_order order by vw.ac_arm_order \n"
					+ "";
//			q="select vw.ac_arm_description , \n"
//					+ "COUNT(distinct ofr.oa_application_id)filter (where ofr.in_index_id != 0 and ofr.es_id=? )as total_candidate_appeared,\n"
//					+ "count(distinct vw.opd_personal_id)filter (where  vw.opd_partd = "+es_year+" )as passed_whole_exam,\n"
//					+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and vw.opd_partd = 0 and pbd.pbda_subjects != vw.pbda_sub_code and ofr.es_id=?)\n"
//					+ "as partially_passed_exam,\n"
//					+ " count(DISTINCT vw.opd_personal_id )filter(where ofr.in_index_id != 0  and pbd.pbda_subjects = vw.pbda_sub_code and ofr.es_id=?  ) as failed_subject,\n"
//					+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
//					+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id  and ors.es_id=?   )=\n"
//					+ "	(select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2  and ofr.es_id=? ))  as app_total_candidate_appeared,\n"
//					+ "count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
//					+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'  and ors.es_id=? and vw.opd_partd != 0  and pbd.pbda_subjects != vw.pbda_sub_code  )=\n"
//					+ " (select count(*) from subject_code_child_tbl scb where vw.ac_arm_id = scb.arm_id and scb.exm_id=2   and ofr.es_id=?   )) as all,\n"
//					+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
//					+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1' and ors.es_id=? and  pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd !=0 )='5'))  as five,\n"
//					+ "  count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0  and \n"
//					+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id=? and pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd !=0  )='4') ) as four,\n"
//					+ "   count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
//					+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'   and ors.es_id=? and pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd !=0)='3' )) as three,\n"
//					+ " \n"
//					+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
//					+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1'  and ors.es_id=? and pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd !=0 )='2')) as two,\n"
//					+ "\n"
//					+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and \n"
//					+ "((select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='1' and ors.es_id=? and pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd !=0   )='1')) as one,\n"
//					+ "\n"
//					+ " count(distinct vw.opd_personal_id)filter (where  ofr.in_index_id != 0 and\n"
//					+ "(select count(*) from officer_results ors where ors.opd_personal_id=ofr.opd_personal_id and ors.or_subject_pass='0'  and ors.es_id=? and pbd.pbda_subjects != vw.pbda_sub_code and vw.opd_partd =0  )=\n"
//					+ " '6') as none\n"
//					+ "from officer_application ofr\n"
//					+ "inner join vw_personal_details vw on vw.opd_personal_id = ofr.opd_personal_id \n"
//					+ "inner join partb_d_application pbd on pbd.oa_application_id = ofr.oa_application_id where ofr.oa_status_id=1 \n"
//					+ "  group by 1,vw.ac_arm_order order by vw.ac_arm_order\n"
//					+ "";
		//opd status change by ripal for 4382  and vw.opd_status_id=1
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			stmt.setInt(2, es_id);
			
			stmt.setInt(3, es_id);
			stmt.setInt(4, es_id);
			
			stmt.setInt(5, es_id);
			stmt.setInt(6, es_id);
			
			stmt.setInt(7, es_id);
			stmt.setInt(8, es_id);
			
			stmt.setInt(9, es_id);
			stmt.setInt(10, es_id);
			
			stmt.setInt(11, es_id);
			
			stmt.setInt(12, es_id);
			stmt.setInt(13, es_id);
			stmt.setInt(14, es_id);
//			stmt.setInt(15, es_id);
//			stmt.setInt(16, es_id);
//			stmt.setInt(17, es_id);
			
			
			
			
			
			ResultSet rs = stmt.executeQuery();
			System.out.println("armRs ------------------"+stmt);
			///////////////
			double total_candidate_appeared_t = 0;
			double passed_whole_exam_t = 0;
			double pers_passed_whole_exam_t = 0;
			double partially_passed_exam_t = 0;
			double pers_partially_passed_exam_t =0;
			double failed_subject_t = 0;
			double pers_failed_subject_t =0;
			
			double app_total_candidate_appeared_t =0;
			double all_t =0;
			double pers_all_t =0;
			double five_t =0;
			double pers_five_t =0;
			double four_t =0;
			double pers_four_t =0;
			double three_t =0;
			double pers_three_t =0;
			double two_t=0;
			double pers_two_t =0;
			double one_t =0;
			double pers_one_t =0;
			double none_t =0;
			double pers_none_t =0;
			
			DecimalFormat df_double = new DecimalFormat("0.00");
			DecimalFormat df_int = new DecimalFormat("0");
			
			////////////
			while (rs.next()) {
				
				
				double total_candidate_appeared = Integer.parseInt(rs.getString("total_candidate_appeared"));
				total_candidate_appeared_t +=total_candidate_appeared;
				double passed_whole_exam = Integer.parseInt(rs.getString("passed_whole_exam"));
				passed_whole_exam_t +=passed_whole_exam;
				if(total_candidate_appeared==0) {
					total_candidate_appeared=1;
				}

				double pers_passed_whole_exam = (passed_whole_exam * 100)/total_candidate_appeared;
				
				double partially_passed_exam = Integer.parseInt(rs.getString("partially_passed_exam"));
				partially_passed_exam_t +=partially_passed_exam;
				double pers_partially_passed_exam = (partially_passed_exam * 100)/total_candidate_appeared;
				
				double failed_subject = Integer.parseInt(rs.getString("failed_subject"));
				failed_subject_t +=failed_subject;
				double pers_failed_subject = (failed_subject * 100)/total_candidate_appeared;
				
				double app_total_candidate_appeared = Integer.parseInt(rs.getString("app_total_candidate_appeared"));
				app_total_candidate_appeared_t +=app_total_candidate_appeared;
				double all = Integer.parseInt(rs.getString("all"));
				all_t +=all; 
				if(app_total_candidate_appeared==0) {
					app_total_candidate_appeared=1;
				}
				
				double pers_all = (all * 100)/app_total_candidate_appeared;
				double five = Integer.parseInt(rs.getString("five"));
				five_t += five;
				double pers_five = (five * 100)/app_total_candidate_appeared;
				
				double four = Integer.parseInt(rs.getString("four"));
				four_t += four;
				double pers_four = (four * 100)/app_total_candidate_appeared;
				
				
				
				double three = Integer.parseInt(rs.getString("three"));
				three_t +=three;
				double pers_three = (three * 100)/app_total_candidate_appeared;
				double two = Integer.parseInt(rs.getString("two"));
				two_t +=two;
				double pers_two = (two * 100)/app_total_candidate_appeared;
				double one = Integer.parseInt(rs.getString("one"));
				one_t += one;
				double pers_one = (one * 100)/app_total_candidate_appeared;
				double none = Integer.parseInt(rs.getString("none"));
				none_t += none;
				double pers_none = (none * 100)/app_total_candidate_appeared;
				
				
				
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ac_arm_description"));
				list.add(rs.getString("total_candidate_appeared"));
				list.add(rs.getString("passed_whole_exam"));
				list.add(df_double.format(pers_passed_whole_exam));
				list.add(rs.getString("partially_passed_exam"));
				list.add(df_double.format(pers_partially_passed_exam));
				list.add(rs.getString("failed_subject"));
				list.add(df_double.format(pers_failed_subject));
				list.add(rs.getString("app_total_candidate_appeared"));
				list.add(rs.getString("all"));
				list.add(df_double.format(pers_all));
				list.add(rs.getString("five"));
				list.add(df_double.format(pers_five));
				list.add(rs.getString("four"));
				list.add(df_double.format(pers_four));
				list.add(rs.getString("three"));
				list.add(df_double.format(pers_three));
				list.add(rs.getString("two"));
				list.add(df_double.format(pers_two));
				list.add(rs.getString("one"));
				list.add(df_double.format(pers_one));
				list.add(rs.getString("none"));
				list.add(df_double.format(pers_none));
				alist.add(list);
			}
			
			/////////////
			pers_passed_whole_exam_t = (passed_whole_exam_t * 100)/total_candidate_appeared_t;
			pers_partially_passed_exam_t = (partially_passed_exam_t * 100)/total_candidate_appeared_t;
			pers_failed_subject_t = (failed_subject_t * 100)/total_candidate_appeared_t;
			pers_all_t = (all_t * 100)/app_total_candidate_appeared_t;
			pers_five_t = (five_t * 100)/app_total_candidate_appeared_t;
			pers_four_t = (four_t * 100)/app_total_candidate_appeared_t;
			pers_three_t = (three_t * 100)/app_total_candidate_appeared_t;
			pers_two_t = (two_t * 100)/app_total_candidate_appeared_t;
			pers_one_t = (one_t * 100)/app_total_candidate_appeared_t;
			pers_none_t = (none_t * 100)/app_total_candidate_appeared_t;
			/////////
			
			
			
			ArrayList<String> list = new ArrayList<String>();
			list.add("Total");
			list.add(df_int.format(total_candidate_appeared_t));
			list.add(df_int.format(passed_whole_exam_t));
			list.add(df_double.format(pers_passed_whole_exam_t));
			list.add(df_int.format(partially_passed_exam_t));
			list.add(df_double.format(pers_partially_passed_exam_t));
			list.add(df_int.format(failed_subject_t));
			list.add(df_double.format(pers_failed_subject_t));
			list.add(df_int.format(app_total_candidate_appeared_t));
			list.add(df_int.format(all_t));
			list.add(df_double.format(pers_all_t));
			list.add(df_int.format(five_t));
			list.add(df_double.format(pers_five_t));
			list.add(df_int.format(four_t));
			list.add(df_double.format(pers_four_t));
			list.add(df_int.format(three_t));
			list.add(df_double.format(pers_three_t));
			list.add(df_int.format(two_t));
			list.add(df_double.format(pers_two_t));
			list.add(df_int.format(one_t));
			list.add(df_double.format(pers_one_t));
			list.add(df_int.format(none_t));
			list.add(df_double.format(pers_none_t));
			alist.add(list);
			
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	
     }
}
