package com.BisagN.dao.officer.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Service
public class WithdrawAppDaoImpl implements  WithdrawAppDao {

	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

CommonController comm= new CommonController();

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

public boolean checkIsIntegerValue(String Search) {
return Search.matches("[0-9]+");
}


public List<Map<String, Object>> getReportListWithdrawApp(int startPage,String pageLength,String Search,String orderColunm,String orderType,String pers_no, String pers_name,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	
	
	if (!pers_no.equals("")) {
		
		
		//using commaon controller searchwithout zero
		pers_no=comm.getSearchIcNumberwithoutZero(pers_no);
		 System.err.println("opc_code==========="+pers_no);
			 
	}
	if(pageLength.equals("-1")){
		pageLength = "ALL";
	}
	String SearchValue = GenerateQueryWhereClause_SQL(Search, pers_no, pers_name);
System.err.println("pers_no========="+pers_no);
	List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
	Connection conn = null;
	String q = "";
	try {
		conn = dataSource.getConnection();
		q = "select wd.id,vpd.opc_personal_code,vpd.opc_suffix_code, vpd.opd_officer_name, vpd.ac_arm_description from vw_personal_details vpd\n"
				+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
				+ "inner join withdrawal_application wd on wd.oa_application_id = ofa.oa_application_id\n"
				+ " "+SearchValue+" ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
		PreparedStatement stmt = conn.prepareStatement(q);
		
		System.out.println("stmt-------------"+stmt);
		stmt = setQueryWhereClause_SQL(stmt,Search, pers_no, pers_name);
		ResultSet rs = stmt.executeQuery();
		ResultSetMetaData metaData = rs.getMetaData();
		int columnCount = metaData.getColumnCount();
		while (rs.next()) {
			Map<String, Object> columns = new LinkedHashMap<String, Object>();
			for (int i = 1; i <= columnCount; i++) {
			    columns.put(metaData.getColumnLabel(i), rs.getObject(i));
			}
                 String enckey ="commonPwdEncKeys";
                   Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
                   String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("id").toString().getBytes())));
                 String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"+EncryptedPk+"')}else{ return false;}\""; 
                 String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
                 String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('"+EncryptedPk+"')}else{ return false;}\""; 
                 String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>"; 
                 String f = "";
                 //===================chnage j=======//
                 String f1 = "";
                 f += updateButton;
//               f += deleteButton;

               String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
      			String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));
     			f1 += opc_code;
                 columns.put("action",f);
                 columns.put("opc_code",f1);
                columns.put(metaData.getColumnLabel(1), f);
                list.add(columns);
}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {
e.printStackTrace();
} finally {
if (conn != null) {
try {
conn.close();
} catch (SQLException e) {
}
}
}
return list;
}

public long getReportListgetReportListWithdrawAppTotalCount(String Search,String pers_no, String pers_name) {
	String SearchValue = GenerateQueryWhereClause_SQL(Search, pers_no, pers_name);
	int total = 0;
	String q = null;
	Connection conn = null;
	try {
		conn = dataSource.getConnection();
		q ="select count(*) from(select wd.id, vpd.opc_personal_code, vpd.opd_officer_name, vpd.ac_arm_description from vw_personal_details vpd\n"
				+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
				+ "inner join withdrawal_application wd on wd.oa_application_id = ofa.oa_application_id\n"
				+ " "+SearchValue +") ab"   ;
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereClause_SQL(stmt,Search, pers_no, pers_name);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			total = rs.getInt(1);
		}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
		}
		}
		return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search,String pers_no,String pers_name) {
	String SearchValue ="";
	
	if (!pers_no.equals("") && pers_no != "" && pers_no != null) {
		SearchValue += " and lower(vpd.opc_personal_code) like ?"; 
	}
	
	
	
	if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
		System.out.println("name===="+pers_name);
		SearchValue += " and lower(vpd.opd_officer_name) like ?"; 
	}
		if(!Search.equals("")) {
		Search = Search.toLowerCase();
			SearchValue =" and ( ";
//			if(checkIsIntegerValue(Search)) {
//				SearchValue +=" id=? or ";
//			}

		SearchValue +="  lower(vpd.opc_personal_code) like ? or lower(vpd.opd_officer_name) like ? or lower( vpd.ac_arm_description) like ? )";
	}
return SearchValue;
}


	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,String pers_no,String pers_name) {
		int flag =0;
		try {
			
			System.err.println("pers_no=========="+pers_no);
			if (!pers_no.equals("") && pers_no != "" && pers_no != null)  {
				flag += 1;
				stmt.setString(flag, "%" + pers_no.toLowerCase() + "%");
			}
			
			if (!pers_name.equals("") && pers_name != "" && pers_name != null)  {
				flag += 1;
				stmt.setString(flag, "%" + pers_name.toLowerCase() + "%");
			}
			
			if(!Search.equals("")) {
				if(checkIsIntegerValue(Search)) {
					flag += 1;
					stmt.setInt(flag, Integer.parseInt(Search));
				}
//				if(checkIsIntegerValue(Search)) {
//					flag += 1;
//					stmt.setInt(flag, Integer.parseInt(Search));
//				}
				flag += 1;
				Search=comm.getSearchIcNumberwithoutZero(Search);

				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				flag += 1;
				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				flag += 1;
				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				
			}
		}catch (Exception e) {}
		return stmt;
	}


public ArrayList<ArrayList<String>> getstatusfrmexmschedule(String exm_name) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	String whr = "";

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q="select es.es_id as id, TO_CHAR( es.es_begin_date,'DD/MM/YYYY') as  es_begin_date,es.es_status_id from exam_schedule es \n"
				+ "inner join exam_code ex on ex.ec_exam_id=es.ec_exam_id where es.es_id::text=? ";
		
		stmt = conn.prepareStatement(q);
		int i=0;
	
		stmt.setString(1, exm_name);
		
		ResultSet rs = stmt.executeQuery();
		
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("id"));//1
			list.add(rs.getString("es_status_id"));//1
			
			if(rs.getString("es_status_id").equals("0")) {
				list.add("Close");
			}else
			{
				list.add("Open");
				
			}
			
			
			alist.add(list);
			
			
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}
}
