package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.Area_MasterDAO;
import com.BisagN.models.officers.masters.AREA_M;
import com.BisagN.models.officers.masters.CHOICE_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Area_MasterController {
	
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private Area_MasterDAO objDAO;
	
	  @Autowired
		private RoleBaseMenuDAO roledao; 
	
	
	@Autowired
	CommonController comm= new CommonController();
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	//===========================OPEN PAGE============================//
		@RequestMapping(value = "AreaMasterUrl", method = RequestMethod.GET)
		public ModelAndView SearchSubject_master_Url(ModelMap Mmap, HttpSession session,HttpServletRequest request,
				@RequestParam(value = "msg", required = false) String msg)
				throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
				NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
			
			
			 if(request.getHeader("Referer") == null ) { 
    			 session.invalidate();
    			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
    			 return new ModelAndView("redirect:/login");
    		 }

        	 String roleid1 = session.getAttribute("roleid").toString();
    		 Boolean val = roledao.ScreenRedirect("AreaMasterUrl", roleid1);		
    			if(val == false) {
    				return new ModelAndView("AccessTiles");
    		}	

			
			 Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
			Mmap.put("msg", msg);
			return new ModelAndView("AreaMasterTiles","AreaMstCMD", new AREA_M());
		}
		
		//============================SAVE==========================//
		  
		  @RequestMapping(value = "/AreaMasterAction" ,method = RequestMethod.POST) 
		  public ModelAndView AreaMasterAction( @ModelAttribute("AreaMstCMD") AREA_M ln, BindingResult result, 
		  HttpServletRequest request, ModelMap model, HttpSession session){ 
			  
//				int errCount = 0;
//
//				if (request.getParameter("area_name").equals("") || request.getParameter("area_name") == null) {
//					errCount++;
//					model.put("area_name_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Choice Name");
//				}
//				if (errCount > 0) {
//
//					return new ModelAndView("AreaMasterTiles");
//				}
			  
			  
				String area_command_name=request.getParameter("area_command_name");
				if(area_command_name == "" || area_command_name.equals("0")) {
					model.put("msg", "Please Select Command");		
					return new ModelAndView("redirect:AreaMasterUrl");
				}
				
				
				
				String area_name=request.getParameter("area_name");
				if(area_name == "" || area_name.equals("")) {
					model.put("msg", "Please Enter Area Name");		
					return new ModelAndView("redirect:AreaMasterUrl");
				}
				
				String area_authority_letter_reference=request.getParameter("area_authority_letter_reference");
				if(area_authority_letter_reference == "" || area_authority_letter_reference.equals("")) {
					model.put("msg", "Please Enter Authority Letter Reference");		
					return new ModelAndView("redirect:AreaMasterUrl");
				}

				int id = ln.getArea_id() > 0 ? ln.getArea_id() : 0;
				Date date = new Date();
				String username = session.getAttribute("username").toString();
				Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction(); 

			try {

				Query q0 = sessionHQL.createQuery(
						"select count(id) from AREA_M where LOWER(area_name)=:area_name and area_id!=:id");

				q0.setParameter("area_name", ln.getArea_name().toLowerCase());
				q0.setParameter("id", id);
				Long c = (Long) q0.uniqueResult();

				
				if (id == 0) {
					ln.setCreated_by(username);
					ln.setCreated_date(date);
					ln.setArea_status_id(1);
					
					if (c == 0) {

						sessionHQL.save(ln);
						sessionHQL.flush();
						sessionHQL.clear();
						model.put("msg", "Data Saved Successfully.");

					} else {
						model.put("msg", "Data already Exist.");
					}
				}

			
				tx.commit();
			} catch (RuntimeException e) {
				try {
					tx.rollback();
					model.put("msg", "roll back transaction");
				} catch (RuntimeException rbe) {
					model.put("msg", "Couldn�t roll back transaction " + rbe);
				}
				throw e;
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}

			return new ModelAndView("redirect:AreaMasterUrl");
		}
		
		  
		//=======================SEARCH============================//
		  
		  @RequestMapping(value = "/getArea_MasterReportDataList", method = RequestMethod.POST)
			 public @ResponseBody List<Map<String, Object>> getArea_MasterReportDataList(int startPage,
					 String pageLength,String Search,String orderColunm,String orderType,String command_name,HttpSession sessionUserId) 
				     throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, 
				     InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
				
			  return objDAO.getReportListArea_Master(startPage,pageLength,Search,orderColunm,orderType,command_name,sessionUserId);
			}

			 
			 @RequestMapping(value = "/getArea_MasterTotalCount", method = RequestMethod.POST)
			public @ResponseBody long getArea_MasterTotalCount(HttpSession sessionUserId,String Search,String command_name){
				 
				return objDAO.getReportListArea_MasterTotalCount(Search,command_name);
			}
			 
			 //=============================EDIT OPEN PAGE=============================//
			 
	         @RequestMapping(value = "EditArea_MasterUrl", method = RequestMethod.POST)
	         public ModelAndView EditArea_MasterUrl(ModelMap Mmap,HttpSession session,
	        		 @RequestParam(value = "msg", required = false) String msg,String updateid) {

	                Session s1 = this.sessionFactory.openSession();
	                Transaction tx = s1.beginTransaction();
	                
	                String enckey = "commonPwdEncKeys";  
	                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
	                
	                Query q = null;
	                q = s1.createQuery("from AREA_M where cast(area_id as string)=:PK");
	                q.setString("PK", DcryptedPk);
	                
	                @SuppressWarnings("unchecked")
	                List<String> list = (List<String>) q.list();
	                tx.commit();
	                s1.close();
	           	 Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
	                Mmap.put("EditAreaMstCMD1", list.get(0));
	                Mmap.put("msg", msg);
	                
	         return new ModelAndView("EditAreaMasterTiles","EditAreaMstCMD",new AREA_M());
	}
			 
	         
	       //============================UPDATE========================//
	         @RequestMapping(value = "/EditAreaMasterAction" ,method = RequestMethod.POST) 
	   	  public ModelAndView EditAreaMasterAction( @ModelAttribute("EditAreaMstCMD") AREA_M ln, BindingResult result, 
	   	  HttpServletRequest request, ModelMap model, HttpSession session){ 

	        	 
//	        	 int errCount = 0;
//
//					if (request.getParameter("area_name").equals("") || request.getParameter("area_name") == null) {
//						errCount++;
//						model.put("area_name_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Choice Name");
//					}
//					if (errCount > 0) {
//
//						return new ModelAndView("EditAreaMasterTiles");
//					}
	        	 
	        	 
	        	 String area_command_name=request.getParameter("area_command_name");
					if(area_command_name == "" || area_command_name.equals("0")) {
						model.put("msg", "Please Select Command");		
						return new ModelAndView("redirect:AreaMasterUrl");
					}
					
					
					
					String area_name=request.getParameter("area_name");
					if(area_name == "" || area_name.equals("")) {
						model.put("msg", "Please Enter Area Name");		
						return new ModelAndView("redirect:AreaMasterUrl");
					}
					
					String area_authority_letter_reference=request.getParameter("area_authority_letter_reference");
					if(area_authority_letter_reference == "" || area_authority_letter_reference.equals("")) {
						model.put("msg", "Please Enter Authority Letter Reference");		
						return new ModelAndView("redirect:AreaMasterUrl");
					}

	        	 
	        Date date = new Date();
	     	String username = session.getAttribute("username").toString();
	   	    Session sessionHQL = this.sessionFactory.openSession();
	   	    Transaction tx = sessionHQL.beginTransaction(); 
	   	    
	   	    ln.setArea_id(Integer.parseInt(request.getParameter("id")));
	   	    sessionHQL.saveOrUpdate(ln); 
	   	    ln.setModified_by(username);
			ln.setModified_date(date);
			ln.setArea_status_id(1);
			
	   	    tx.commit(); 
	   	    sessionHQL.close(); 
	   	 
	   	    model.put("msg","Data Updated Successfully"); 
	   	    return new ModelAndView("redirect:AreaMasterUrl"); 
	   	  } 
			 
			 //=======================DELETE===========================//
			 @RequestMapping(value = "/DeleteArea_MasterUrl", method = RequestMethod.POST) 
			  public ModelAndView DeleteArea_MasterUrl(String deleteid,HttpSession session,ModelMap model) { 
				 
			  	List<String> list = new ArrayList<String>(); 
			  	list.add(objDAO.DeleteArea_Master(deleteid,session)); 
			  	
			  	model.put("msg",list);  
			  	
			    return new ModelAndView("redirect:AreaMasterUrl"); 
			    
			  	}
		
		
}
