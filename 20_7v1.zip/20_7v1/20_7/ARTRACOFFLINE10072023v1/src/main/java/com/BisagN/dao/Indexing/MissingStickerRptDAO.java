package com.BisagN.dao.Indexing;

import java.util.ArrayList;

public interface MissingStickerRptDAO {
	
	public ArrayList<ArrayList<String>> getMissingStickerRptDetails(String es_id, int opd_pers_id);

}
