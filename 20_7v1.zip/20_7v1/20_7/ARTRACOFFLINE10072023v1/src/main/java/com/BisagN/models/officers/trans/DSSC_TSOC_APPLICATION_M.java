package com.BisagN.models.officers.trans;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "dssc_tsoc_application", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class DSSC_TSOC_APPLICATION_M {

      private int id;
      private int oa_application_id;
      private int dta_dssc;
      private int dta_tsoc;
      private int dta_course_pref;
      private int dta_comp;
      private String dta_sign_comp_auth;
      private String dta_type_of_entry;
      private String dta_medical_cat;
      private String dta_regiment;
      private String dta_address_corres1;
      private String dta_address_coress2;
      private String dta_jccourse_no;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dta_jccourse_beg_date;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dta_jccourse_end_date;
      private String dta_182daycourse_no;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dta_182daycourse_init_date;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dta_182daycourse_term_date;
      private int dta_waiver;
      private String dta_26week_detail;
      private int dta_firstchance_year;
      private int dta_firstchance_center;
      private int dta_secondchance_year;
      private int dta_secondchance_center;
      private int dta_thirdchance_year;
      private int dta_thirdchance_center;
      private int dta_bsc;
      private int dta_ttc;
      private int dta_lgsc;
      private int dta_btech;
      private int dta_sign_candidate;
      private int dta_sign_co;
      private String dta_acr_marks;
      private int dta_fd_days;
      private String dta_agepolicy;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dta_dateoftos;
      private int dta_cpscatttended;
      private int dta_year;
      private int dta_firstchoice;
      private int dta_secondchoice;
      private int dta_thirdchoice;
      private String dta_others;
      private int dta_bsc_hons;
      private int dta_bsc_first_second_year;
      private int dta_bsc_p_c_e_m;
      private int dta_msc;
      private int dta_cs;
      private int dta_bcs_cs_first_third;
      private String dta_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dta_creation_date;
      private String dta_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dta_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getOa_application_id() {
           return oa_application_id;
      }
      public void setOa_application_id(int oa_application_id) {
	  this.oa_application_id = oa_application_id;
      }
      public int getDta_dssc() {
           return dta_dssc;
      }
      public void setDta_dssc(int dta_dssc) {
	  this.dta_dssc = dta_dssc;
      }
      public int getDta_tsoc() {
           return dta_tsoc;
      }
      public void setDta_tsoc(int dta_tsoc) {
	  this.dta_tsoc = dta_tsoc;
      }
      public int getDta_course_pref() {
           return dta_course_pref;
      }
      public void setDta_course_pref(int dta_course_pref) {
	  this.dta_course_pref = dta_course_pref;
      }
      public int getDta_comp() {
           return dta_comp;
      }
      public void setDta_comp(int dta_comp) {
	  this.dta_comp = dta_comp;
      }
      public String getDta_sign_comp_auth() {
           return dta_sign_comp_auth;
      }
      public void setDta_sign_comp_auth(String dta_sign_comp_auth) {
	  this.dta_sign_comp_auth = dta_sign_comp_auth;
      }
      public String getDta_type_of_entry() {
           return dta_type_of_entry;
      }
      public void setDta_type_of_entry(String dta_type_of_entry) {
	  this.dta_type_of_entry = dta_type_of_entry;
      }
      public String getDta_medical_cat() {
           return dta_medical_cat;
      }
      public void setDta_medical_cat(String dta_medical_cat) {
	  this.dta_medical_cat = dta_medical_cat;
      }
      public String getDta_regiment() {
           return dta_regiment;
      }
      public void setDta_regiment(String dta_regiment) {
	  this.dta_regiment = dta_regiment;
      }
      public String getDta_address_corres1() {
           return dta_address_corres1;
      }
      public void setDta_address_corres1(String dta_address_corres1) {
	  this.dta_address_corres1 = dta_address_corres1;
      }
      public String getDta_address_coress2() {
           return dta_address_coress2;
      }
      public void setDta_address_coress2(String dta_address_coress2) {
	  this.dta_address_coress2 = dta_address_coress2;
      }
      public String getDta_jccourse_no() {
           return dta_jccourse_no;
      }
      public void setDta_jccourse_no(String dta_jccourse_no) {
	  this.dta_jccourse_no = dta_jccourse_no;
      }
      public Date getDta_jccourse_beg_date() {
           return dta_jccourse_beg_date;
      }
      public void setDta_jccourse_beg_date(Date dta_jccourse_beg_date) {
	  this.dta_jccourse_beg_date = dta_jccourse_beg_date;
      }
      public Date getDta_jccourse_end_date() {
           return dta_jccourse_end_date;
      }
      public void setDta_jccourse_end_date(Date dta_jccourse_end_date) {
	  this.dta_jccourse_end_date = dta_jccourse_end_date;
      }
      public String getDta_182daycourse_no() {
           return dta_182daycourse_no;
      }
      public void setDta_182daycourse_no(String dta_182daycourse_no) {
	  this.dta_182daycourse_no = dta_182daycourse_no;
      }
      public Date getDta_182daycourse_init_date() {
           return dta_182daycourse_init_date;
      }
      public void setDta_182daycourse_init_date(Date dta_182daycourse_init_date) {
	  this.dta_182daycourse_init_date = dta_182daycourse_init_date;
      }
      public Date getDta_182daycourse_term_date() {
           return dta_182daycourse_term_date;
      }
      public void setDta_182daycourse_term_date(Date dta_182daycourse_term_date) {
	  this.dta_182daycourse_term_date = dta_182daycourse_term_date;
      }
      public int getDta_waiver() {
           return dta_waiver;
      }
      public void setDta_waiver(int dta_waiver) {
	  this.dta_waiver = dta_waiver;
      }
      public String getDta_26week_detail() {
           return dta_26week_detail;
      }
      public void setDta_26week_detail(String dta_26week_detail) {
	  this.dta_26week_detail = dta_26week_detail;
      }
      public int getDta_firstchance_year() {
           return dta_firstchance_year;
      }
      public void setDta_firstchance_year(int dta_firstchance_year) {
	  this.dta_firstchance_year = dta_firstchance_year;
      }
      public int getDta_firstchance_center() {
           return dta_firstchance_center;
      }
      public void setDta_firstchance_center(int dta_firstchance_center) {
	  this.dta_firstchance_center = dta_firstchance_center;
      }
      public int getDta_secondchance_year() {
           return dta_secondchance_year;
      }
      public void setDta_secondchance_year(int dta_secondchance_year) {
	  this.dta_secondchance_year = dta_secondchance_year;
      }
      public int getDta_secondchance_center() {
           return dta_secondchance_center;
      }
      public void setDta_secondchance_center(int dta_secondchance_center) {
	  this.dta_secondchance_center = dta_secondchance_center;
      }
      public int getDta_thirdchance_year() {
           return dta_thirdchance_year;
      }
      public void setDta_thirdchance_year(int dta_thirdchance_year) {
	  this.dta_thirdchance_year = dta_thirdchance_year;
      }
      public int getDta_thirdchance_center() {
           return dta_thirdchance_center;
      }
      public void setDta_thirdchance_center(int dta_thirdchance_center) {
	  this.dta_thirdchance_center = dta_thirdchance_center;
      }
      public int getDta_bsc() {
           return dta_bsc;
      }
      public void setDta_bsc(int dta_bsc) {
	  this.dta_bsc = dta_bsc;
      }
      public int getDta_ttc() {
           return dta_ttc;
      }
      public void setDta_ttc(int dta_ttc) {
	  this.dta_ttc = dta_ttc;
      }
      public int getDta_lgsc() {
           return dta_lgsc;
      }
      public void setDta_lgsc(int dta_lgsc) {
	  this.dta_lgsc = dta_lgsc;
      }
      public int getDta_btech() {
           return dta_btech;
      }
      public void setDta_btech(int dta_btech) {
	  this.dta_btech = dta_btech;
      }
      public int getDta_sign_candidate() {
           return dta_sign_candidate;
      }
      public void setDta_sign_candidate(int dta_sign_candidate) {
	  this.dta_sign_candidate = dta_sign_candidate;
      }
      public int getDta_sign_co() {
           return dta_sign_co;
      }
      public void setDta_sign_co(int dta_sign_co) {
	  this.dta_sign_co = dta_sign_co;
      }
      public String getDta_acr_marks() {
           return dta_acr_marks;
      }
      public void setDta_acr_marks(String dta_acr_marks) {
	  this.dta_acr_marks = dta_acr_marks;
      }
      
      public int getDta_fd_days() {
		return dta_fd_days;
	}
	public void setDta_fd_days(int dta_fd_days) {
		this.dta_fd_days = dta_fd_days;
	}
	public String getDta_agepolicy() {
           return dta_agepolicy;
      }
      public void setDta_agepolicy(String dta_agepolicy) {
	  this.dta_agepolicy = dta_agepolicy;
      }
      public Date getDta_dateoftos() {
           return dta_dateoftos;
      }
      public void setDta_dateoftos(Date dta_dateoftos) {
	  this.dta_dateoftos = dta_dateoftos;
      }
      public int getDta_cpscatttended() {
           return dta_cpscatttended;
      }
      public void setDta_cpscatttended(int dta_cpscatttended) {
	  this.dta_cpscatttended = dta_cpscatttended;
      }
      public int getDta_year() {
           return dta_year;
      }
      public void setDta_year(int dta_year) {
	  this.dta_year = dta_year;
      }
      public int getDta_firstchoice() {
           return dta_firstchoice;
      }
      public void setDta_firstchoice(int dta_firstchoice) {
	  this.dta_firstchoice = dta_firstchoice;
      }
      public int getDta_secondchoice() {
           return dta_secondchoice;
      }
      public void setDta_secondchoice(int dta_secondchoice) {
	  this.dta_secondchoice = dta_secondchoice;
      }
      public int getDta_thirdchoice() {
           return dta_thirdchoice;
      }
      public void setDta_thirdchoice(int dta_thirdchoice) {
	  this.dta_thirdchoice = dta_thirdchoice;
      }
      public String getDta_others() {
           return dta_others;
      }
      public void setDta_others(String dta_others) {
	  this.dta_others = dta_others;
      }
      public int getDta_bsc_hons() {
           return dta_bsc_hons;
      }
      public void setDta_bsc_hons(int dta_bsc_hons) {
	  this.dta_bsc_hons = dta_bsc_hons;
      }
      public int getDta_bsc_first_second_year() {
           return dta_bsc_first_second_year;
      }
      public void setDta_bsc_first_second_year(int dta_bsc_first_second_year) {
	  this.dta_bsc_first_second_year = dta_bsc_first_second_year;
      }
      public int getDta_bsc_p_c_e_m() {
           return dta_bsc_p_c_e_m;
      }
      public void setDta_bsc_p_c_e_m(int dta_bsc_p_c_e_m) {
	  this.dta_bsc_p_c_e_m = dta_bsc_p_c_e_m;
      }
      public int getDta_msc() {
           return dta_msc;
      }
      public void setDta_msc(int dta_msc) {
	  this.dta_msc = dta_msc;
      }
      public int getDta_cs() {
           return dta_cs;
      }
      public void setDta_cs(int dta_cs) {
	  this.dta_cs = dta_cs;
      }
      public int getDta_bcs_cs_first_third() {
           return dta_bcs_cs_first_third;
      }
      public void setDta_bcs_cs_first_third(int dta_bcs_cs_first_third) {
	  this.dta_bcs_cs_first_third = dta_bcs_cs_first_third;
      }
      public String getDta_created_by() {
           return dta_created_by;
      }
      public void setDta_created_by(String dta_created_by) {
	  this.dta_created_by = dta_created_by;
      }
      public Date getDta_creation_date() {
           return dta_creation_date;
      }
      public void setDta_creation_date(Date dta_creation_date) {
	  this.dta_creation_date = dta_creation_date;
      }
      public String getDta_modified_by() {
           return dta_modified_by;
      }
      public void setDta_modified_by(String dta_modified_by) {
	  this.dta_modified_by = dta_modified_by;
      }
      public Date getDta_modification_date() {
           return dta_modification_date;
      }
      public void setDta_modification_date(Date dta_modification_date) {
	  this.dta_modification_date = dta_modification_date;
      }
	
      
}
