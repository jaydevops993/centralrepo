package com.BisagN.controller.office.trans;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.trans.Dssc_compens_chanceDAO;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.trans.DSSC_COMPENS_CHANCE_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Dssc_compens_chanceController {

	@Autowired
	private Dssc_compens_chanceDAO objDAO;
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	private PartB_ExaminationDAO partBDao;

	@Autowired
	private RoleBaseMenuDAO roledao;

	CommonController comm = new CommonController();

	@RequestMapping(value = "Searchdssc_compens_chanceUrl", method = RequestMethod.GET)
	public ModelAndView Searchdssc_compens_chanceUrl(ModelMap Mmap,HttpServletRequest request, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? ""
				: session.getAttribute("es_begin_dateshow").toString();

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		if (ec_exam_id == 3) {
			if (!es_begindate.equals("")) {
				Mmap.put("DSSC_begindate", es_begindate);
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
			if (ec_exam_id != 0) {
				ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
				Mmap.put("getexamcentrelist", examcentrelist);
				Mmap.put("ec_exam_id", ec_exam_id);
			}
		}

		if (request.getHeader("Referer") == null) {
			session.invalidate();
			Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			return new ModelAndView("redirect:/login");
		}

		String roleid1 = session.getAttribute("roleid").toString();
		Boolean val = roledao.ScreenRedirect("Searchdssc_compens_chanceUrl", roleid1);
		if (val == false) {
			return new ModelAndView("AccessTiles");
		}
		Mmap.put("msg", msg);
		return new ModelAndView("SearchDssc_compens_chance_tile");
	}

	@RequestMapping(value = "/getDssc_compens_chanceReportDataList", method = RequestMethod.POST)
	public @ResponseBody List<Map<String, Object>> getDssc_compens_chanceReportDataList(int startPage,
			String pageLength, String Search, String orderColunm, String orderType, String pers_no, String pers_name,
			HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		return objDAO.getReportListDssc_compens_chance(startPage, pageLength, Search, orderColunm, orderType, pers_no,
				pers_name, sessionUserId);
	}

	@RequestMapping(value = "/getDssc_compens_chanceTotalCount", method = RequestMethod.POST)
	public @ResponseBody long getDssc_compens_chanceTotalCount(HttpSession sessionUserId, String Search, String pers_no,
			String pers_name) {
		return objDAO.getReportListDssc_compens_chanceTotalCount(Search, pers_no, pers_name);
	}

	@RequestMapping(value = "/dssc_compens_chanceAction", method = RequestMethod.POST)
	public ModelAndView dssc_compens_chanceAction(
			@Valid @ModelAttribute("dssc_compens_chanceCMD") DSSC_COMPENS_CHANCE_M ln, BindingResult result,
			@RequestParam(value = "dcc_auth_doc", required = false) MultipartFile dcc_auth_doc,
			HttpServletRequest request, ModelMap model, HttpSession session) {

		String PersonalNo = request.getParameter("opd_personal_id");
		String Authority = request.getParameter("dcc_remarks");
		String dcc_compens_year = request.getParameter("dcc_compens_year");

		if (PersonalNo == "" || PersonalNo.equals("")) {
			model.put("msg", "Please Enter Personal No");
			return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
		}

		if (Authority == "" || Authority.equals("")) {
			model.put("msg", "Please Enter Authority");
			return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
		}

		if (dcc_auth_doc.isEmpty()) {
			model.put("msg", "Please Insert Authority File Upload");
			return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
		}

		if (dcc_compens_year == "" || dcc_compens_year.equals("")) {
			model.put("msg", "Please Enter Compensatory chance");
			return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
		}

		try {
			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			Date date = new Date();
			String username = session.getAttribute("username").toString();

			String opd_personal_id = request.getParameter("opd_personal_id");
			List<OFFICER_PERSONAL_CODE_M> getopdId = comm.getopdIdbycode(sessionFactory, opd_personal_id);
			int opd_persId = getopdId.get(0).getOpd_personal_id();

			int id = ln.getDcc_id() > 0 ? ln.getDcc_id() : 0;
			Query q0 = sessionHQL.createQuery(
					"select count(*) from DSSC_COMPENS_CHANCE_M where opd_personal_id=:opd_personal_id and dcc_id!=:dcc_id");

			q0.setParameter("opd_personal_id", opd_persId);
			q0.setParameter("dcc_id", id);
			Long c = (Long) q0.uniqueResult();

			if (id == 0) {

				// if (c == 0) {

				ln.setDcc_remarks(request.getParameter("dcc_remarks"));
				ln.setDcc_compens_year(Integer.parseInt(request.getParameter("dcc_compens_year")));
				ln.setDcc_dispes_year(Integer.parseInt(request.getParameter("dcc_compens_year")));
				ln.setOpd_personal_id(opd_persId);

				if (!dcc_auth_doc.isEmpty()) {
					String name = comm.fileupload2(dcc_auth_doc.getBytes(), dcc_auth_doc.getOriginalFilename(),
							String.valueOf(opd_persId), "dcc_auth_doc" + ln.getDcc_id());
					if (name != "") {
						ln.setDcc_auth_doc(name);
					}
				}

				ln.setDcc_created_by(username);
				ln.setDcc_creation_date(date);
				ln.setDcc_status_id(1);
				ln.setDcc_compens_status(1);
				sessionHQL.save(ln);
				tx.commit();
				sessionHQL.close();

				model.put("msg", "Data Saved Successfully");
//				}else {
//					model.put("msg", "You have already taken two chances");
//					
//				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");

	}

	@RequestMapping(value = "EditDssc_compens_chanceUrl", method = RequestMethod.POST)
	public ModelAndView EditDssc_compens_chanceUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String updateid) {

		Session s1 = this.sessionFactory.openSession();
		Transaction tx = s1.beginTransaction();
		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);
		Query q = null;
		q = s1.createQuery("from DSSC_COMPENS_CHANCE_M where cast(id as string)=:PK");
		q.setString("PK", DcryptedPk);
		@SuppressWarnings("unchecked")
		List<DSSC_COMPENS_CHANCE_M> list = (List<DSSC_COMPENS_CHANCE_M>) q.list();
		tx.commit();
		s1.close();
		Mmap.put("Editdssc_compens_chanceCMD1", list.get(0));
		int opd_pers_id = list.get(0).getOpd_personal_id();
		List<OFFICER_PERSONAL_CODE_M> getPerscode = comm.getPersCodebyOpdID(sessionFactory, opd_pers_id);
		String pers_code = getPerscode.get(0).getOpc_personal_code();
		Mmap.put("msg", msg);
		Mmap.put("id", list.get(0).getDcc_id());
		Mmap.put("pers_code", pers_code);
		Mmap.put("opd_pers_id", opd_pers_id);
		return new ModelAndView("EditDssc_compens_chance_tile", "Editdssc_compens_chanceCMD",
				new DSSC_COMPENS_CHANCE_M());
	}

	@RequestMapping(value = "/Editdssc_compens_chanceAction", method = RequestMethod.POST)
	public ModelAndView Editdssc_compens_chanceAction(
			@Valid @ModelAttribute("Editdssc_compens_chanceCMD") DSSC_COMPENS_CHANCE_M ln, BindingResult result,
			@RequestParam(value = "dcc_auth_doc", required = false) MultipartFile dcc_auth_doc,
			HttpServletRequest request, ModelMap model, HttpSession session) throws IOException {

		String PersonalNo = request.getParameter("perscode");
		String Authority = request.getParameter("dcc_remarks");
		String dcc_compens_year = request.getParameter("dcc_compens_year");

		if (PersonalNo == "" || PersonalNo.equals("")) {
			model.put("msg", "Please Enter Personal No");
			return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
		}

		if (Authority == "" || Authority.equals("")) {
			model.put("msg", "Please Enter Authority");
			return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
		}

//		if (dcc_auth_doc.isEmpty()) {
//			model.put("msg", "Please Insert Authority File Upload");		
//			return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
//		}

		if (dcc_compens_year == "" || dcc_compens_year.equals("")) {
			model.put("msg", "Please Enter Compensatory chance");
			return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
		}

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		Date date = new Date();
		String username = session.getAttribute("username").toString();

		String id = request.getParameter("id");
		String opd_pers_id = request.getParameter("opd_pers_id");
		String name = "";
		if (!dcc_auth_doc.isEmpty()) {
			name = comm.fileupload2(dcc_auth_doc.getBytes(), dcc_auth_doc.getOriginalFilename(),
					String.valueOf(opd_pers_id), "dcc_auth_doc" + ln.getDcc_id());
			if (name != "") {
				ln.setDcc_auth_doc(name);
			}
		}

		String hql = "update DSSC_COMPENS_CHANCE_M set dcc_compens_year=:dcc_compens_year, dcc_remarks=:dcc_remarks, dcc_auth_doc=:dcc_auth_doc,"
				+ "dcc_status_id=:dcc_status_id,dcc_modified_by=:dcc_modified_by,dcc_modification_date=:dcc_modification_date  where dcc_id=:dcc_id  ";
		Query query = sessionHQL.createQuery(hql)
				.setParameter("dcc_compens_year", Integer.parseInt(request.getParameter("dcc_compens_year")))
				.setParameter("dcc_remarks", request.getParameter("dcc_remarks")).setParameter("dcc_auth_doc", name)
				.setParameter("dcc_status_id", 1).setParameter("dcc_modified_by", username)
				.setParameter("dcc_modification_date", date).setParameter("dcc_id", Integer.parseInt(id));

		query.executeUpdate();
		tx.commit();
		sessionHQL.close();

		model.put("msg", "Data Updated Successfully");
		return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
	}

	@RequestMapping(value = "/deletedssc_compens_chanceUrl", method = RequestMethod.POST)
	public ModelAndView deletedssc_compens_chanceUrl(String deleteid, HttpSession session, ModelMap model) {
		List<String> list = new ArrayList<String>();
		list.add(objDAO.Deletedssc_compens_chance(deleteid, session));
		model.put("msg", list);
		return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getOfficerPersonalDataurl", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getAllDataurl(HttpSession session, String adv_detail) {

		ArrayList<ArrayList<String>> list = objDAO.getAllData(adv_detail);

		return list;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getOfficerPersonalDataurlforDSSC", method = RequestMethod.POST)
	@ResponseBody
	public List<Map<String, Object>> getOfficerPersonalDataurlforDSSC(HttpSession session, String perscode) {

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		List<Map<String, Object>> list = objDAO.getPersDataForDssc(perscode, es_id);

		return list;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getOfficerPersonalDataurlForDsscCompChance", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getOfficerPersonalDataurlForDsscCompChance(HttpSession session,
			String pers_id) {

		ArrayList<ArrayList<String>> list = objDAO.getAllDataforDsscCompChance(pers_id);

		return list;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getOfficerPersonalDataurlForDsscApplicationCount", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getOfficerPersonalDataurlForDsscApplicationCount(HttpSession session,
			String opd_personal_id) {

		ArrayList<ArrayList<String>> list = objDAO.getDsscCountDetailsForOfficer(opd_personal_id);

		return list;
	}

	@RequestMapping(value = "Dssc_compchanceURL", method = RequestMethod.GET)
	public ModelAndView Dssc_compchanceURL(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String Dssc_compchanceid) {

		Mmap.put("getAreaTypeListDDL", comm.getAreaTypeListDDL(sessionFactory));
		Mmap.put("getEntryTypeListDDL", comm.getEntryTypeListDDL(sessionFactory));
		Mmap.put("msg", msg);
		return new ModelAndView("Dssc_compens_chance_tile", "dssc_compens_chanceCMD", new DSSC_COMPENS_CHANCE_M());
	}

	@RequestMapping(value = "UploadDssc_compchanceURL", method = RequestMethod.GET)
	public ModelAndView UploadDssc_compchanceURL(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String Uploadssc_tsoc_Applicationid,
			HttpServletRequest request) {

		Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		if (flashMap != null) {
			ArrayList<ArrayList<String>> errorList = (ArrayList<ArrayList<String>>) flashMap.get("errorlist");
			System.out.println("===================" + errorList);
			// return "home";
			Mmap.put("errorList", errorList);
		}
		Mmap.put("msg", msg);
		return new ModelAndView("ImportDsscCompChanceOffcrDetails_tiles");
	}

	// UPLOAD CANDIDATE DATA
	@RequestMapping(value = "/UploadDsscCompChancedataAction", method = RequestMethod.POST)
	public ModelAndView UploadDsscCompChancedataAction(HttpServletRequest request, ModelMap model, HttpSession session,
			@RequestParam(value = "fileUpload", required = false) MultipartFile fileUpload,
			@RequestParam(value = "dcc_auth_doc", required = false) MultipartFile dcc_auth_doc, RedirectAttributes ra) {
		
		
		
		
		ArrayList<ArrayList<String>> listerror = new ArrayList<ArrayList<String>>();
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		
		if (fileUpload.isEmpty()) {
			ra.addAttribute("msg", "Please Upload Copy Of File Upload");		
			return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
		}

		if (dcc_auth_doc.isEmpty()) {
			ra.addAttribute("msg", "Please Upload Copy Of Authority Letter File Upload");		
			return new ModelAndView("redirect:Searchdssc_compens_chanceUrl");
		}
		
		
		
		try {

			Date date = new Date();
			String username = session.getAttribute("username").toString();

			int errorcount = 0;
			String errormsg = "";
			File file = new File(
					comm.fileupload2(fileUpload.getBytes(), fileUpload.getOriginalFilename(), "doc_contract", ""));
			FileInputStream fis = new FileInputStream(file);
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheetAt(0);
			Row row_head = sheet.getRow(0);

			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				System.err.println("sheet.getLastRowNum()===========" + sheet.getLastRowNum());
				ArrayList<String> listData = new ArrayList<String>();
				Row row = sheet.getRow(i);
				String N_personal_no = "";
				String c_year = "";
				String d_year = "";

				if (row.getCell(0) == null) {
					break;
				}

				for (int j = 0; j < 3; j++) {

					Cell cell = row.getCell(j);

					String value = "";
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						value = cell.getStringCellValue();
						break;
					case Cell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							value = String.valueOf(cell.getDateCellValue());
						} else {
							value = String.valueOf((long) cell.getNumericCellValue());
						}
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						value = String.valueOf(cell.getBooleanCellValue());
						break;
					default:
					}

					if (row_head.getCell(j).getStringCellValue().equals("ICNo")) {
						N_personal_no = value;
					}
					if (row_head.getCell(j).getStringCellValue().equals("Compens_year")) {
						c_year = value;

					}

					if (row_head.getCell(j).getStringCellValue().equals("Dispense_year")) {
						d_year = value;

					}

				}
				String pers_code2 = N_personal_no.substring(0, N_personal_no.length() - 1);
				List<OFFICER_PERSONAL_CODE_M> opdpers_id = comm.getopdIdbycode(sessionFactory, pers_code2);

				if (opdpers_id.isEmpty()) {

					listData.add(N_personal_no);
					listData.add(c_year);
					listData.add(d_year);
					listData.add("The Personal Number is Wrong");
					errormsg = N_personal_no + "The Personal Number is Wrong";
					model.put("msg", errormsg);
					errorcount++;
				} else {

					DSSC_COMPENS_CHANCE_M ln = new DSSC_COMPENS_CHANCE_M();
					int opd_pers_id = opdpers_id.get(0).getOpd_personal_id();

					// if (c == 0) {

					ln.setDcc_compens_year(Integer.parseInt(c_year));
					ln.setDcc_dispes_year(Integer.parseInt(d_year));
					ln.setOpd_personal_id(opd_pers_id);

					if (!dcc_auth_doc.isEmpty()) {
						String name = comm.fileupload2(dcc_auth_doc.getBytes(), dcc_auth_doc.getOriginalFilename(),
								String.valueOf(opd_pers_id), "dcc_auth_doc" + ln.getDcc_id());
						if (name != "") {
							ln.setDcc_auth_doc(name);
						}
					}

					ln.setDcc_created_by(username);
					ln.setDcc_creation_date(date);
					ln.setDcc_status_id(1);
					ln.setDcc_compens_status(1);

					sessionHQL.save(ln);

					ra.addAttribute("msg", "Data Save Successfully");

					if (!listData.isEmpty()) {
						System.err.println("listData=======" + listData);
						listerror.add(listData);
					}

					model.put("errorlist", listerror);

				}

			}
			tx.commit();
		}

		catch (Exception e) {
			// tx.rollback();
			e.printStackTrace();
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		ra.addFlashAttribute("errorlist", listerror);
		ra.addFlashAttribute("errorlistSize", listerror.size());
		return new ModelAndView("redirect:UploadDssc_compchanceURL");
	}
}
