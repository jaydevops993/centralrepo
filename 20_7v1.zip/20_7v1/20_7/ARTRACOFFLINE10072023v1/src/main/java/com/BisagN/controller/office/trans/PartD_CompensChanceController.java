package com.BisagN.controller.office.trans;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.others.ExportPartBDao;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.trans.Partbd_compens_chanceDAO;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.trans.PARTBD_COMPENS_CHANCE_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class PartD_CompensChanceController {
	@Autowired
	private Partbd_compens_chanceDAO objDAO;
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

	@Autowired
	private ExportPartBDao export;

	@Autowired
	private PartB_ExaminationDAO partBDao;
	CommonController comm = new CommonController();

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	private RoleBaseMenuDAO roledao;

	@RequestMapping(value = "SearchpartD_compens_chanceUrl", method = RequestMethod.GET)
	public ModelAndView SearchpartD_compens_chanceUrl(ModelMap Mmap, HttpSession session, HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
		
		
		if (request.getHeader("Referer") == null) {
		session.invalidate();
		Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
		return new ModelAndView("redirect:/login");
	}

	String roleid1 = session.getAttribute("roleid").toString();
	Boolean val = roledao.ScreenRedirect("SearchpartD_compens_chanceUrl", roleid1);
	if (val == false) {
		return new ModelAndView("AccessTiles");
	}
		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? ""
				: session.getAttribute("es_begin_dateshow").toString();

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		if (ec_exam_id == 2) {
			if (!es_begindate.equals("")) {
				Mmap.put("partb_begindate", es_begindate);
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
			if (ec_exam_id != 0) {
				ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
				Mmap.put("getexamcentrelist", examcentrelist);
				Mmap.put("ec_exam_id", ec_exam_id);
			}
		}
		Mmap.put("msg", msg);
		return new ModelAndView("SearchPartD_CompenChance_tile");
	}

	@RequestMapping(value = "Comp_chancePartD_ApplicationURL", method = RequestMethod.GET)
	public ModelAndView Comp_chancePartD_ApplicationURL(ModelMap Mmap, HttpServletRequest request, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String Comp_chancePartBdid) {



		Mmap.put("getAreaListDDL", comm.getAreaListDDL(sessionFactory));

		Mmap.put("msg", msg);
		return new ModelAndView("PartD_CompenChance_tile", "partD_compens_chanceCMD", new PARTBD_COMPENS_CHANCE_M());
	}

	@RequestMapping(value = "/partD_compens_chanceAction", method = RequestMethod.POST)
	public ModelAndView partD_compens_chanceAction(
			@Valid @ModelAttribute("partD_compens_chanceCMD") PARTBD_COMPENS_CHANCE_M PartBd_cs, BindingResult result,
			@RequestParam(value = "partbd_auth_doc", required = false) MultipartFile partbd_auth_doc,
			HttpServletRequest request, ModelMap model, HttpSession session) {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		int errCount = 0;
		String opd_personal_hid = request.getParameter("opd_personal_hid");

		try {
			String opd_personal_id = request.getParameter("opd_personal_id");
			String pcc_area = request.getParameter("pcc_area");
			String pcc_area_entry_date = request.getParameter("pcc_area_entry_date");
			String pcc_area_leave_date = request.getParameter("pcc_area_leave_date");
			String pcc_remarks = request.getParameter("pcc_remarks");
			String pcc_avail_year = request.getParameter("pcc_granted_year");
			String partbd_auth_doc_val = request.getParameter("partbd_auth_doc");
			
			if (opd_personal_id == "" || opd_personal_id.equals("")) {
				model.put("msg", " Please Enter Personal");
				return new ModelAndView("redirect:SearchpartD_compens_chanceUrl");
			}

			if (pcc_area.equals("")) {
				model.put("msg", " Please Select Qualifying Area/Operation");
				return new ModelAndView("redirect:SearchpartD_compens_chanceUrl");

			}
			if (pcc_area_entry_date.equals("DD/MM/YYYY") || pcc_area_entry_date.equals("") || pcc_area_entry_date == ""
					|| pcc_area_entry_date == "DD/MM/YYYY") {
				model.put("msg", "Please Select Date of posting into the area");
				return new ModelAndView("redirect:SearchpartD_compens_chanceUrl");
			}
			if (pcc_area_leave_date.equals("DD/MM/YYYY") || pcc_area_leave_date.equals("") || pcc_area_leave_date == ""
					|| pcc_area_leave_date == "DD/MM/YYYY") {
				model.put("msg", " Please Select Date of posting out");
				return new ModelAndView("redirect:SearchpartD_compens_chanceUrl");
			}
			
			if (pcc_avail_year == "" || pcc_avail_year.equals("")) {
				model.put("msg", "Please Enter Waiver Granted For Year");
				return new ModelAndView("redirect:SearchpartD_compens_chanceUrl");
			}
			
			if (pcc_remarks == "" || pcc_remarks.equals("")) {
				model.put("msg", " Please Enter Authority");
				return new ModelAndView("redirect:SearchpartD_compens_chanceUrl");
			}
			
			if (partbd_auth_doc.isEmpty()) {
				model.put("msg", " Please Upload Copy Of File Upload");
				return new ModelAndView("redirect:SearchpartD_compens_chanceUrl");
			}
			
			

			String username = session.getAttribute("username").toString();
			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			int id = PartBd_cs.getPcc_id() > 0 ? PartBd_cs.getPcc_id() : 0;
			DateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");

			if (id == 0) {

				List<OFFICER_PERSONAL_CODE_M> getopdId = comm.getopdIdbycode(sessionFactory, opd_personal_id);
				int opdid = getopdId.get(0).getOpd_personal_id();

				PartBd_cs.setOpd_personal_id(opdid);
				PartBd_cs.setPcc_created_by(username);
				PartBd_cs.setPcc_creation_date(date);
				PartBd_cs.setEc_exam_id(2);

				if (!partbd_auth_doc.isEmpty()) {
					String name = comm.fileupload2(partbd_auth_doc.getBytes(), partbd_auth_doc.getOriginalFilename(),
							String.valueOf(opdid), "partbd_auth_doc" + PartBd_cs.getPcc_id());
					if (name != "") {
						PartBd_cs.setPcc_auth_doc(name);
					}
				}
				sessionHQL.save(PartBd_cs);

				model.put("msg", "Data Saved Successfully");

				tx.commit();
				sessionHQL.close();
			}

		}

		catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return new ModelAndView("redirect:SearchpartD_compens_chanceUrl");
	}

}
