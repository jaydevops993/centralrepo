package com.BisagN.dao.officer.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class DSSCMarksDaoImpl implements DSSCMarksDAO {
	
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	 CommonController comm= new CommonController();

	public boolean checkIsIntegerValue(String Search) {
		return Search.matches("[0-9]+");
	}
	
	
	
	public List<Map<String, Object>> getDSSCCMarksDetails(int startPage,String pageLength,String Search,String orderColunm,String orderType,String sub_id,String es_id,
			String opd_personal_id,String officername,	String indexno,	HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		
		if (!opd_personal_id.equals("")) {			
			
			//using commaon controller searchwithout zero
			opd_personal_id=comm.getSearchIcNumberwithoutZero(opd_personal_id);
			 System.err.println("opc_code==========="+opd_personal_id);
				 
		}
		
		if(pageLength.equals("-1")){
 			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search,sub_id,es_id,opd_personal_id,officername,indexno);
 		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		String q = "";
		String q1 = "";
		String q2 = "";
		
		

	System.err.println("sub_id--------------"+sub_id);
	System.err.println("opd_personal_id--------------"+opd_personal_id);
	System.err.println("officername--------------"+officername);
	System.err.println("indexno--------------"+indexno);
		try {
			conn = dataSource.getConnection();
			q = "select DISTINCT oapp.oa_application_id,oapp.in_index_id, vw.opc_personal_code,vw.opc_suffix_code,sc.sc_subject_name,ab.ab_marks_obtained,vw.opd_officer_name,ab.sc_subject_id from answer_book ab\n"
					+ "inner join officer_application oapp on oapp.oa_application_id = ab.oa_application_id\n"
//					+ "inner join officer_results ofc on ofc.opd_personal_id = oapp.opd_personal_id\n"
					+ "inner join vw_personal_details vw on oapp.opd_personal_id = vw.opd_personal_id\n"
					+ "inner join subject_code sc on sc.sc_subject_id=ab.sc_subject_id\n"
					+ "where oapp.es_id= ? "+SearchValue+" "
							+  " ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
			PreparedStatement stmt = conn.prepareStatement(q);
			stmt.setInt(1, Integer.parseInt(es_id));
			
			stmt = setQueryWhereClause_SQL(stmt,Search,sub_id,es_id,opd_personal_id,officername,indexno);
			System.out.println("stmt=======ssssss==fff========="+stmt);
			
		
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
 			int columnCount = metaData.getColumnCount();
 			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
				    columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
                      String enckey ="commonPwdEncKeys";
	                    Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
	                    String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("oa_application_id").toString().getBytes())));
	                    
	                    
                      String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"+EncryptedPk+"')}else{ return false;}\""; 
                      String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
                      String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('"+EncryptedPk+"','"+rs.getString("sc_subject_id")+"')}else{ return false;}\""; 
                      String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>"; 
                      String f = "";
                      //===================chnage j=======//
                      String f1 = "";
                      f += updateButton;
//                    f += deleteButton;

                    String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
           			String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));
          			f1 += opc_code;
                      columns.put("action",f);
                      columns.put("opc_code",f1);
                     columns.put(metaData.getColumnLabel(1), f);
			list.add(columns);
	}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {
	e.printStackTrace();
} finally {
if (conn != null) {
try {
	conn.close();
} catch (SQLException e) {
}
}
}
return list;
}


public long getDSSCCMarksdetailsTotalCount(String Search,String sub_id,String es_id,String opd_personal_id,String officername,
		String indexno) {
	String SearchValue = GenerateQueryWhereClause_SQL(Search,sub_id,es_id,opd_personal_id,officername,indexno);
	int total = 0;
	String q = null;
	Connection conn = null;
	String q1 = "";
	String q2 = "";
	
	System.err.println("es-,,,,"+es_id);

	
	
	
	try {
		conn = dataSource.getConnection();
		q ="select count(*) from (select DISTINCT ab.ab_marks_obtained,oapp.in_index_id ,vw.opc_personal_code ,sc.sc_subject_name ,vw.opd_officer_name from answer_book ab\n"
				+ "inner join officer_application oapp on oapp.oa_application_id = ab.oa_application_id\n"
//				+ "inner join officer_results ofc on ofc.opd_personal_id = oapp.opd_personal_id\n"
				+ "inner join vw_personal_details vw on oapp.opd_personal_id = vw.opd_personal_id\n"
				+ "inner join subject_code sc on sc.sc_subject_id=ab.sc_subject_id where oapp.es_id= ?\n"
				+ "  "+SearchValue +"  ) ab " ;
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt.setInt(1, Integer.parseInt(es_id));
		stmt = setQueryWhereClause_SQL(stmt,Search,sub_id,es_id,opd_personal_id,officername,indexno);

		ResultSet rs = stmt.executeQuery();
		
		while (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return (long) total;
}


public String GenerateQueryWhereClause_SQL(String Search,String sub_id,String es_id,String opd_personal_id,String officername,
		String indexno) {
	String SearchValue ="";
	
	if (!sub_id.equals("0") && sub_id != "0") {
		SearchValue += " and ab.sc_subject_id=?"; 
	}
//	if (!es_id.equals("") && es_id != "" && es_id != null) {
//		SearchValue += " and oapp.es_id= ?"; 
//	}
	System.err.println("==========="+opd_personal_id);
	if (!opd_personal_id.equals("") && opd_personal_id != "" && opd_personal_id != null) {
		SearchValue += " and lower(vw.opc_personal_code) like ?"; 
	}	
	System.err.println("==========="+officername);
	
	if (!officername.equals("") && officername != "" && officername != null) {
		SearchValue += " and lower(vw.opd_officer_name) like ?"; 
	}
	
	System.err.println("==========="+indexno);
	if (!indexno.equals("") && indexno != "" && indexno != null) {
		SearchValue += " and oapp.in_index_id=?"; 
	}
	
	
	if(!Search.equals("")) {
	Search = Search.toLowerCase();
		SearchValue +=" and ( ";
//		SearchValue +=" lower(opd_unit) like ? or lower(opd_unit_address2) like ? or"
//			+" to_char(opd_dob,'dd-MM-yyyy') like ? or "
//				+ "to_char(opd_date_of_comm,'dd-MM-yyyy') like ? or to_char(opd_date_of_seniority,'dd-MM-yyyy') like ? or  "
//				+ " lower(opd_remarks) like ? )";
		SearchValue +=" lower(vw.opc_personal_code) like ? or (oapp.in_index_id::text) like ? or lower(vw.opd_officer_name)like ? or lower(sc.sc_subject_name)like ? or (ab.ab_marks_obtained::text)like ?)";
	}
	
	System.err.println("==========="+SearchValue);
	return SearchValue;
}


public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,String sub_id,String es_id,String opd_personal_id,String officername,
		String indexno) {
	int flag = 1;
	try {
		
		if (!sub_id.equals("0") && sub_id != "0") {
			flag += 1;
			stmt.setInt(flag, Integer.parseInt(sub_id));
		}
//		if (!es_id.equals("") && es_id != "" && es_id != null)  {
//			flag += 1;
//			stmt.setInt(flag, Integer.parseInt(es_id));
//				
//		}
		
		System.err.println("opd_personal_id==="+opd_personal_id);
		if (!opd_personal_id.equals("") && opd_personal_id != "" && opd_personal_id != null)  {
			flag += 1;
			stmt.setString(flag, (opd_personal_id.toLowerCase()));
				
		}
		
		System.err.println("officername==="+officername);
		if (!officername.equals("") && officername != "" && officername != null)  {
			flag += 1;
			stmt.setString(flag, "%" + officername.toLowerCase() + "%");
		}
		
		System.err.println("indexno==="+indexno);
		if (!indexno.equals("") && indexno != "" && indexno != null)  {
			flag += 1;
			stmt.setInt(flag, Integer.parseInt(indexno));
				
		}
		
		
		
	if(!Search.equals("")) {
		
//		if(checkIsIntegerValue(Search)) {
//				flag += 1;
//				stmt.setInt(flag, Integer.parseInt(Search));
//			}
//			if(checkIsIntegerValue(Search)) {
//				flag += 1;
//				stmt.setInt(flag, Integer.parseInt(Search));
//			}
			
			flag += 1;
			Search=comm.getSearchIcNumberwithoutZero(Search);

			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			
		}
	}catch (Exception e) {}
	return stmt;
}

public ArrayList<ArrayList<String>> getDSSCMarksDetails(String oapp_id,String subjectid) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();

	Connection conn = null;
	String q = "";
	String qry = "";

	try {

		System.err.println("subjectid========="+subjectid);

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q = "select DISTINCT sc.sc_subject_name,sc.sc_subject_id,ab.ab_marks_obtained ,oapp.oa_application_id,oapp.in_index_id, opc.opc_personal_code,ab.ab_status_id from answer_book ab\n"
				+ "inner join officer_application oapp on oapp.oa_application_id = ab.oa_application_id\n"
//				+ "inner join officer_results ofc on ab.oa_application_id = oapp.oa_application_id\n"
				+ "inner join officer_personal_code opc on oapp.opd_personal_id = opc.opd_personal_id\n"
				+ "inner join subject_code sc on sc.sc_subject_id=ab.sc_subject_id\n"
				+ "where oapp.oa_application_id=? and  ab.sc_subject_id=? ";

		stmt = conn.prepareStatement(q);
		stmt.setInt(1, Integer.parseInt(oapp_id));
		stmt.setInt(2, Integer.parseInt(subjectid));
System.err.println("partb============"+stmt);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();

			list.add(rs.getString("sc_subject_name"));//1
			list.add(rs.getString("sc_subject_id"));//2
			list.add(rs.getString("ab_marks_obtained"));//3
			list.add(rs.getString("in_index_id"));//4	
			list.add(rs.getString("opc_personal_code"));//5	
			list.add(rs.getString("ab_status_id"));//5	
			
		
			

			alist.add(list);
			//System.err.println("list============"+list);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;

}


}
