package com.BisagN.controller.office.reports;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;

public class SummaryPdfController  extends AbstractPdfView{
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public SummaryPdfController(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		document.setPageSize(PageSize.A4.rotate());
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		
		response.setContentType("application/pdf");
	response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");

		
		String es_year =  (String) model.get("es_year");
		String ExamName =  (String) model.get("ExamName");

//		String letter_no =  (String) model.get("letter_no1");
//		String letter_date1 =  (String) model.get("letter_date1");
		
		
//		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
//		Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
//		Font fontTableHeadingSubMainHead = FontFactory.getFont(FontFactory.TIMES_BOLD, 12);;
		
		
		 Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
	     Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 1);
	     Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
		
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		
		Chunk chunk = new Chunk();
		
		Chunk glue = new Chunk(new VerticalPositionMark());
				
		Chunk underline1 = new Chunk( "SUMMARY" +"\n"+ ""+ExamName+":"+es_year+"" , fontTableHeading1);	 
		underline1.setUnderline(0.1f, -2f);
			
		
		
		
		Phrase ph = new Phrase(underline1);
		ph.add("\n");
		ph.add("\n");
		ph.add("\n");
		ph.setFont(fontTableHeading1);
		Paragraph cell = new Paragraph(ph);
		cell.setAlignment(Element.ALIGN_LEFT);
		
		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell);
		 
		 PdfPTable tabledata = new PdfPTable(4);
			
	
			tabledata.setWidths(new int[] {1,1,1,1});
			tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tabledata.setWidthPercentage(50);
			
			
			ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");

			Paragraph a = new Paragraph("SUBJECT",fontTableHeadingSubMainHead);
			Paragraph b = new Paragraph("HAD TO APPEAR",fontTableHeadingSubMainHead);
			Paragraph c = new Paragraph("APPEARED",fontTableHeadingSubMainHead);
			Paragraph e = new Paragraph("ABSENTEES",fontTableHeadingSubMainHead);
			
				
				 tabledata.addCell(a);
				 tabledata.addCell(b);
				 tabledata.addCell(c);
				 tabledata.addCell(e);
				 
				 for(int i=0;i<list.size();i++)
				 {
				
					 List<String> l = list.get(i); 
				 //data bind
				 Paragraph blank1 = new Paragraph(l.get(0),fontTableHeadingdata);
				 Paragraph blank2 = new Paragraph(l.get(1),fontTableHeadingdata);
				 Paragraph blank3 = new Paragraph(l.get(2),fontTableHeadingdata);
				 Paragraph blank4 = new Paragraph(l.get(3),fontTableHeadingdata);
				
				
//					 
//					 tabledata.addCell(blank1);
//					 tabledata.addCell(blank2);
//					 tabledata.addCell(blank3);
//					 tabledata.addCell(blank4);
					 
					 
					 PdfPCell cell2 = new PdfPCell();
						if(i % 2 == 0){
							cell2.setBackgroundColor(java.awt.Color.lightGray);
						}
						cell2.setPhrase(blank1);
						cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
						 tabledata.addCell(cell2);
						 cell2.setPhrase(blank2);
						 tabledata.addCell(cell2);
						 cell2.setPhrase(blank3);
						 tabledata.addCell(cell2);
						 cell2.setPhrase(blank4);
						 tabledata.addCell(cell2);
						 
					
				 }
			 
				 
			PdfPCell cell123;
			cell123 = new PdfPCell();
			cell123.addElement(tableheader);
			cell123.addElement(tabledata);
			cell123.setBorder(0);
			table.addCell(cell123);
			document.add(table);
			super.buildPdfMetadata(model, document, request);
		}



}
