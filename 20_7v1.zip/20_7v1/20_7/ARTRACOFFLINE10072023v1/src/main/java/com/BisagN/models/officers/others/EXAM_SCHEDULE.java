package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "exam_schedule", uniqueConstraints = {
@UniqueConstraint(columnNames = "es_id"),})

public class EXAM_SCHEDULE {
	
      private int es_id;
      private int ec_exam_id;
      private Date es_begin_date;
      private String es_authority;
      private String es_index_mode;
      private String es_letter_no;
      private Date es_letter_dated;
      private int es_status_id;
      private String es_created_by;
      private Date es_creation_date;
      private String es_modified_by;
      private Date es_modification_date;
      
      private Date es_dssc_check_year;
      private Date es_to_year;
      private String es_part_b;
      private String es_part_d;
      private String es_compensatory;
      private String es_consider_date;
      private Date es_begin_todate;
      private int es_max_year;
      private int es_dssc_month;
      private int es_dssc_chance;
      
      
      
      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "es_id", unique = true, nullable = false)
	
	public int getEs_id() {
		return es_id;
	}
	public void setEs_id(int es_id) {
		this.es_id = es_id;
	}
	public int getEc_exam_id() {
		return ec_exam_id;
	}
	public void setEc_exam_id(int ec_exam_id) {
		this.ec_exam_id = ec_exam_id;
	}
	public Date getEs_begin_date() {
		return es_begin_date;
	}
	public void setEs_begin_date(Date es_begin_date) {
		this.es_begin_date = es_begin_date;
	}
	public String getEs_authority() {
		return es_authority;
	}
	public void setEs_authority(String es_authority) {
		this.es_authority = es_authority;
	}
	public String getEs_index_mode() {
		return es_index_mode;
	}
	public void setEs_index_mode(String es_index_mode) {
		this.es_index_mode = es_index_mode;
	}
	public String getEs_letter_no() {
		return es_letter_no;
	}
	public void setEs_letter_no(String es_letter_no) {
		this.es_letter_no = es_letter_no;
	}
	public Date getEs_letter_dated() {
		return es_letter_dated;
	}
	public void setEs_letter_dated(Date es_letter_dated) {
		this.es_letter_dated = es_letter_dated;
	}
	public int getEs_status_id() {
		return es_status_id;
	}
	public void setEs_status_id(int es_status_id) {
		this.es_status_id = es_status_id;
	}
	public String getEs_created_by() {
		return es_created_by;
	}
	public void setEs_created_by(String es_created_by) {
		this.es_created_by = es_created_by;
	}
	public Date getEs_creation_date() {
		return es_creation_date;
	}
	public void setEs_creation_date(Date es_creation_date) {
		this.es_creation_date = es_creation_date;
	}
	public String getEs_modified_by() {
		return es_modified_by;
	}
	public void setEs_modified_by(String es_modified_by) {
		this.es_modified_by = es_modified_by;
	}
	public Date getEs_modification_date() {
		return es_modification_date;
	}
	public void setEs_modification_date(Date es_modification_date) {
		this.es_modification_date = es_modification_date;
	}
	
	public Date getEs_to_year() {
		return es_to_year;
	}
	public void setEs_to_year(Date es_to_year) {
		this.es_to_year = es_to_year;
	}
	public String getEs_part_b() {
		return es_part_b;
	}
	public void setEs_part_b(String es_part_b) {
		this.es_part_b = es_part_b;
	}
	public String getEs_part_d() {
		return es_part_d;
	}
	public void setEs_part_d(String es_part_d) {
		this.es_part_d = es_part_d;
	}
	public String getEs_compensatory() {
		return es_compensatory;
	}
	public void setEs_compensatory(String es_compensatory) {
		this.es_compensatory = es_compensatory;
	}
	public String getEs_consider_date() {
		return es_consider_date;
	}
	public void setEs_consider_date(String es_consider_date) {
		this.es_consider_date = es_consider_date;
	}
	public Date getEs_begin_todate() {
		return es_begin_todate;
	}
	public void setEs_begin_todate(Date es_begin_todate) {
		this.es_begin_todate = es_begin_todate;
	}
	public int getEs_max_year() {
		return es_max_year;
	}
	public void setEs_max_year(int es_max_year) {
		this.es_max_year = es_max_year;
	}
	public Date getEs_dssc_check_year() {
		return es_dssc_check_year;
	}
	public void setEs_dssc_check_year(Date es_dssc_check_year) {
		this.es_dssc_check_year = es_dssc_check_year;
	}
	public int getEs_dssc_month() {
		return es_dssc_month;
	}
	public void setEs_dssc_month(int es_dssc_month) {
		this.es_dssc_month = es_dssc_month;
	}
	public int getEs_dssc_chance() {
		return es_dssc_chance;
	}
	public void setEs_dssc_chance(int es_dssc_chance) {
		this.es_dssc_chance = es_dssc_chance;
	}

      
      
      
      
}


 