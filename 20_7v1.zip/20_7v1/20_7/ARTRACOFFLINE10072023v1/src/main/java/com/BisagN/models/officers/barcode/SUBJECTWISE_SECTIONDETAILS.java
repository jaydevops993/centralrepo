package com.BisagN.models.officers.barcode;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;



@Entity
@Table(name = "subjectwisesectiondetails", uniqueConstraints = {
@UniqueConstraint(columnNames = "ssd_id"),})
public class SUBJECTWISE_SECTIONDETAILS {

	
	private int ssd_id;
	private int ssd_es_id;
	private int ssd_subject_id;
	private int sub_ssd_subject_id;
	private int ssd_total_sections;
	private int ssd_totalquestions;
	
	private int ssd_totalmarks;
	private int ssd_userid;
	private Date ssd_createdate;
	private Date ssd_updatedate;
	private int  ssd_arms_id;
	
	
	@Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "ssd_id", unique = true, nullable = false)
	public int getSsd_id() {
		return ssd_id;
	}
	public void setSsd_id(int ssd_id) {
		this.ssd_id = ssd_id;
	}
	public int getSsd_es_id() {
		return ssd_es_id;
	}
	public void setSsd_es_id(int ssd_es_id) {
		this.ssd_es_id = ssd_es_id;
	}
	public int getSsd_subject_id() {
		return ssd_subject_id;
	}
	public void setSsd_subject_id(int ssd_subject_id) {
		this.ssd_subject_id = ssd_subject_id;
	}
	public int getSsd_total_sections() {
		return ssd_total_sections;
	}
	public void setSsd_total_sections(int ssd_total_sections) {
		this.ssd_total_sections = ssd_total_sections;
	}
	public int getSsd_totalquestions() {
		return ssd_totalquestions;
	}
	public void setSsd_totalquestions(int ssd_totalquestions) {
		this.ssd_totalquestions = ssd_totalquestions;
	}
	public int getSsd_totalmarks() {
		return ssd_totalmarks;
	}
	public void setSsd_totalmarks(int ssd_totalmarks) {
		this.ssd_totalmarks = ssd_totalmarks;
	}
	public int getSsd_userid() {
		return ssd_userid;
	}
	public void setSsd_userid(int ssd_userid) {
		this.ssd_userid = ssd_userid;
	}
	public Date getSsd_createdate() {
		return ssd_createdate;
	}
	public void setSsd_createdate(Date ssd_createdate) {
		this.ssd_createdate = ssd_createdate;
	}
	public Date getSsd_updatedate() {
		return ssd_updatedate;
	}
	public void setSsd_updatedate(Date ssd_updatedate) {
		this.ssd_updatedate = ssd_updatedate;
	}
	public int getSsd_arms_id() {
		return ssd_arms_id;
	}
	public void setSsd_arms_id(int ssd_arms_id) {
		this.ssd_arms_id = ssd_arms_id;
	}
	public int getSub_ssd_subject_id() {
		return sub_ssd_subject_id;
	}
	public void setSub_ssd_subject_id(int sub_ssd_subject_id) {
		this.sub_ssd_subject_id = sub_ssd_subject_id;
	}
	
	
	
	
	
}
