package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "qualified_officers_tsoc", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class QUALIFIED_OFFICERS_TSOC_M {

      private int id;
      private int qot_id;
      private int es_id;
      private int qot_tsoc;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getQot_id() {
           return qot_id;
      }
      public void setQot_id(int qot_id) {
	  this.qot_id = qot_id;
      }
      public int getEs_id() {
           return es_id;
      }
      public void setEs_id(int es_id) {
	  this.es_id = es_id;
      }
      public int getQot_tsoc() {
           return qot_tsoc;
      }
      public void setQot_tsoc(int qot_tsoc) {
	  this.qot_tsoc = qot_tsoc;
      }
}
