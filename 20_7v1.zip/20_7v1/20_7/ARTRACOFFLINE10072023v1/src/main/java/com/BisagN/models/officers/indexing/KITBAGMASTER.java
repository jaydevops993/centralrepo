package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "kitbagmaster", uniqueConstraints = {
@UniqueConstraint(columnNames = "kbm_id"),})
public class KITBAGMASTER {

	
	private int kbm_id;
	private int kbm_sc_subject_id;
	private int kbm_ac_arm_id;
	private int kbm_ngroupid;
	private int kbm_iu_user_id;
	private int kbm_es_id;
	
	private int kbm_ipnm_id;
	private String kbm_bagname;
	private int kbm_status;
	private Date kbm_createdate;
	private Date kbm_updatedate;
	private int  kbm_sub_subject_id;
	
	
	   @Id
	      @GeneratedValue(strategy = IDENTITY)
	      @Column(name = "kbm_id", unique = true, nullable = false)
	
	public int getKbm_id() {
		return kbm_id;
	}
	public void setKbm_id(int kbm_id) {
		this.kbm_id = kbm_id;
	}
	public int getKbm_sc_subject_id() {
		return kbm_sc_subject_id;
	}
	public void setKbm_sc_subject_id(int kbm_sc_subject_id) {
		this.kbm_sc_subject_id = kbm_sc_subject_id;
	}
	public int getKbm_ac_arm_id() {
		return kbm_ac_arm_id;
	}
	public void setKbm_ac_arm_id(int kbm_ac_arm_id) {
		this.kbm_ac_arm_id = kbm_ac_arm_id;
	}
	public int getKbm_ngroupid() {
		return kbm_ngroupid;
	}
	public void setKbm_ngroupid(int kbm_ngroupid) {
		this.kbm_ngroupid = kbm_ngroupid;
	}
	public int getKbm_iu_user_id() {
		return kbm_iu_user_id;
	}
	public void setKbm_iu_user_id(int kbm_iu_user_id) {
		this.kbm_iu_user_id = kbm_iu_user_id;
	}
	public int getKbm_es_id() {
		return kbm_es_id;
	}
	public void setKbm_es_id(int kbm_es_id) {
		this.kbm_es_id = kbm_es_id;
	}
	public int getKbm_ipnm_id() {
		return kbm_ipnm_id;
	}
	public void setKbm_ipnm_id(int kbm_ipnm_id) {
		this.kbm_ipnm_id = kbm_ipnm_id;
	}
	public String getKbm_bagname() {
		return kbm_bagname;
	}
	public void setKbm_bagname(String kbm_bagname) {
		this.kbm_bagname = kbm_bagname;
	}
	public int getKbm_status() {
		return kbm_status;
	}
	public void setKbm_status(int kbm_status) {
		this.kbm_status = kbm_status;
	}
	public Date getKbm_createdate() {
		return kbm_createdate;
	}
	public void setKbm_createdate(Date kbm_createdate) {
		this.kbm_createdate = kbm_createdate;
	}
	public Date getKbm_updatedate() {
		return kbm_updatedate;
	}
	public void setKbm_updatedate(Date kbm_updatedate) {
		this.kbm_updatedate = kbm_updatedate;
	}
	public int getKbm_sub_subject_id() {
		return kbm_sub_subject_id;
	}
	public void setKbm_sub_subject_id(int kbm_sub_subject_id) {
		this.kbm_sub_subject_id = kbm_sub_subject_id;
	}
	
	
}


