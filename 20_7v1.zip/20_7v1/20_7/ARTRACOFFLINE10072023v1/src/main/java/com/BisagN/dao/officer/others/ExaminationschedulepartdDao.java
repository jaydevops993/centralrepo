package com.BisagN.dao.officer.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface ExaminationschedulepartdDao {

	
	public List<Map<String, Object>> getdatafromsubmst(String exam_id);
	public List<Map<String, Object>> getExaminationScheduleList(int startPage,String pageLength,String Search,String orderColunm,String orderType,String exam,
		String es_id,	HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	public long getExaminationScheduleTotalCount(String Search,String exam,String es_id);
	public List<Map<String, Object>> getexamscheduleDetails(int ew_id,int sub_id) ;
	public List<Map<String, Object>> getexamscheduledetails2(int ew_id,int subject_id);
	public List<Map<String, Object>> getvacancyReserveDetailsbyExmsch(int es_id);
	
	public List<Map<String, Object>> editgetdatafromsubmst(String es_id);
	
	public ArrayList<ArrayList<String>> getactivebegindate(String exm_name);
}
