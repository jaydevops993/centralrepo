package com.BisagN.dao.officer.others;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


@Service
public class Officer_pers_DaoImp implements Officer_pers_DAO{
	
	@Autowired
	private DataSource dataSource;
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	public  ArrayList<ArrayList<String>> Officer_pers_data(String personal_code) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		String whr = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			q=" select vpd.opc_personal_code,vpd.opd_officer_name,vpd.ac_arm_description,vpd.opd_date_of_comm,vpd.opd_date_of_seniority\n"
					+ "from vw_personal_details vpd\n"
					+ "where vpd.opc_personal_code=?";
			
			stmt = conn.prepareStatement(q);
			
		
			stmt.setString(1, personal_code.toUpperCase());
 
			
			ResultSet rs = stmt.executeQuery();
			
//			System.err.println("rs==do==="+rs);
//			
//			
//		    System.err.println("stmt=========="+stmt);
		
		    int i=0;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("opc_personal_code"));//1
				list.add(rs.getString("opd_officer_name"));//2
				list.add(rs.getString("ac_arm_description"));//3
				list.add(rs.getString("opd_date_of_comm").substring(0,10));//4
				list.add(rs.getString("opd_date_of_seniority").substring(0,10));//5
				  
				alist.add(list);
				i++;				
				
			}

			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
//		System.err.println("list==do==="+alist);
		return alist;
	}
	
	
	
	public  ArrayList<ArrayList<String>> Officer_pers_data_part_b(String personal_code) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		String whr = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
 
//			q="select   vpd.opc_personal_code ,\n"
//					+ "es.es_begin_date,ofa.es_id, \n"
//					+ "CASE WHEN (\n"
//					+ "	    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'\n"
//					+ "					 when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=51) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 51::text) )	\n"
//					+ "	     IS NOT NULL THEN \n"
//					+ "   		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'\n"
//					+ "					 when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=51) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 51::text)\n"
//					+ "		   ELSE ''\n"
//					+ "		 end\n"
//					+ "		  as ADM,\n"
//					+ "		  CASE WHEN (\n"
//					+ "	     string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=52) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 52::text) )	\n"
//					+ "	     IS NOT NULL THEN \n"
//					+ "		    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=52) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 52::text)\n"
//					+ "		    ELSE ''\n"
//					+ "		 end\n"
//					+ "		  as LAW\n"
//					+ "          ,\n"
//					+ " 		  CASE WHEN (string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=53) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 53::text) )	\n"
//					+ "	     IS NOT NULL THEN \n"
//					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=53) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 53::text) \n"
//					+ "	    ELSE ''\n"
//					+ "		 end\n"
//					+ "	   	 as MH,\n"
//					+ "\n"
//					+ "		 CASE WHEN (string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=53) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 54::text)  )	\n"
//					+ "	     IS NOT NULL THEN \n"
//					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=54) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 54::text)\n"
//					+ "		  ELSE ''\n"
//					+ "		 end\n"
//					+ "	 	 as CA,\n"
//					+ " 		 CASE WHEN (\n"
//					+ "	    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=55) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 55::text) )	\n"
//					+ "	     IS NOT NULL THEN \n"
//					+ "         string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=55) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 55::text) \n"
//					+ "	     ELSE ''\n"
//					+ "		 end\n"
//					+ "	     as TCA\n"
//					+ "   ,vpd.opd_partb\n"
//					+ "   ,(extract( year FROM es.es_begin_date )::int ) as Yearofexam\n"
//					+ "\n"
//					+ "from vw_personal_details vpd\n"
//					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
//					+ "inner join exam_schedule es on es.es_id = ofa.es_id\n"
//					+ "inner join exam_code exm ON exm.ec_exam_id = es.ec_exam_id\n"
//					+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
//					+ "where vpd.opc_personal_code= ?\n"
//					+ "and ((extract( year FROM es.es_begin_date )::int) <= vpd.opd_partb)\n"
//					+ "and exm.ec_exam_id =1\n"
//					+ "GROUP By 1,2,3,9\n"
//					+ " ";
		
			q="select   vpd.opc_personal_code ,\n"
					+ "es.es_begin_date,ofa.es_id, \n"
					+ "CASE WHEN (\n"
					+ "	    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'\n"
					+ "					 when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=51) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 51::text) )	\n"
					+ "	     IS NOT NULL THEN \n"
					+ "   		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'\n"
					+ "					 when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=51) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 51::text)\n"
					+ "		   ELSE ''\n"
					+ "		 end\n"
					+ "		  as ADM,\n"
					+ "		  CASE WHEN (\n"
					+ "	     string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=52) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 52::text) )	\n"
					+ "	     IS NOT NULL THEN \n"
					+ "		    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=52) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 52::text)\n"
					+ "		    ELSE ''\n"
					+ "		 end\n"
					+ "		  as LAW\n"
					+ "          ,\n"
					+ " 		  CASE WHEN (string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=53) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 53::text) )	\n"
					+ "	     IS NOT NULL THEN \n"
					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=53) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 53::text) \n"
					+ "	    ELSE ''\n"
					+ "		 end\n"
					+ "	   	 as MH,\n"
					+ "\n"
					+ "		 CASE WHEN (string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=53) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 54::text)  )	\n"
					+ "	     IS NOT NULL THEN \n"
					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=54) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 54::text)\n"
					+ "		  ELSE ''\n"
					+ "		 end\n"
					+ "	 	 as CA,\n"
					+ " 		 CASE WHEN (\n"
					+ "	    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=55) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 55::text) )	\n"
					+ "	     IS NOT NULL THEN \n"
					+ "         string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=55) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 55::text) \n"
					+ "	     ELSE ''\n"
					+ "		 end\n"
					+ "	     as TCA\n"
					+ "   ,vpd.opd_partb\n"
					+ "   ,(extract( year FROM es.es_begin_date )::int ) as Yearofexam\n"
					+ "\n"
					+ "from vw_personal_details vpd\n"
					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
					+ "inner join exam_schedule es on es.es_id = ofa.es_id\n"
					+ "inner join exam_code exm ON exm.ec_exam_id = es.ec_exam_id\n"
					+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
					+ "where vpd.opc_personal_code= ?\n"
					+ "and ((extract( year FROM es.es_begin_date )::int) <= vpd.opd_partb)\n"
					+ "and exm.ec_exam_id =1\n"
					+ "GROUP By 1,2,3,9\n"
					+ " ";
			
			stmt = conn.prepareStatement(q);
			
		
			stmt.setString(1, personal_code.toUpperCase());
 
			
			ResultSet rs = stmt.executeQuery();
			
			System.err.println("rs==do==="+rs);
//			
//			
		    System.err.println("stmt=========="+stmt);
		
		    int i=0;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
//				list.add(rs.getString("opc_personal_code"));//1
//				list.add(rs.getString("opd_officer_name"));//2
//				list.add(rs.getString("ac_arm_description"));//3
//				list.add(rs.getString("opd_date_of_comm"));//4
//				list.add(rs.getString("opd_date_of_seniority"));//5
//				
//				
				
				list.add(rs.getString("ADM"));//0
				list.add(rs.getString("LAW"));//1
				list.add(rs.getString("MH"));//2
				list.add(rs.getString("CA"));//3
				list.add(rs.getString("TCA"));//4
				  
				list.add(rs.getString("Yearofexam"));//5
				list.add(rs.getString("opd_partb"));//6
				 
				
				alist.add(list);
				i++;				
				
			}

			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		System.err.println("list==do==="+alist);
		return alist;
	}
	
	
	
	public  ArrayList<ArrayList<String>> Officer_pers_data_part_d(String personal_code) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		String whr = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
 
			
//			q="select   vpd.opc_personal_code ,es.es_begin_date,ofa.es_id,\n"
//					+ " CASE WHEN (\n"
//					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 56::text))\n"
//					+ "		  IS NOT NULL THEN  \n"
//					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=56) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 56::text) \n"
//					+ "		  ELSE ''\n"
//					+ "		  end\n"
//					+ "		  as tac,\n"
//					+ "		  CASE WHEN (\n"
//					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 57::text))\n"
//					+ "		  IS NOT NULL THEN \n"
//					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=57) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 57::text) \n"
//					+ "		  ELSE ''\n"
//					+ "		  end\n"
//					+ "		  as adw\n"
//					+ "		  ,\n"
//					+ "		    CASE WHEN (string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=58) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 58::text))\n"
//					+ "		  IS NOT NULL THEN 	\n"
//					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=58) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 58::text)\n"
//					+ "		  \n"
//					+ "		  ELSE ''\n"
//					+ "		  end\n"
//					+ "		  as law, \n"
//					+ "				\n"
//					+ "				  CASE WHEN ( string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=59) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text ) filter (where ab.sc_subject_id::text = 59::text))\n"
//					+ "		  IS NOT NULL THEN 			  \n"
//					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=59) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text ) filter (where ab.sc_subject_id::text = 59::text)\n"
//					+ "					 ELSE ''\n"
//					+ "		  end\n"
//					+ "					 as mh, \n"
//					+ "					    CASE WHEN (string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=60) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 60::text) )\n"
//					+ "		  IS NOT NULL THEN   string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=60) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 60::text)  \n"
//					+ "		  ELSE ''\n"
//					+ "		  end\n"
//					+ "		  as ca, \n"
//					+ "							  CASE WHEN (  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=61) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 61::text) )\n"
//					+ "		  IS NOT NULL THEN  				 \n"
//					+ "        string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=61) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 61::text) \n"
//					+ "		  ELSE ''\n"
//					+ "		  end\n"
//					+ "		  as SPEC\n"
//					+ "		  ,vpd.opd_partd\n"
//					+ "		  ,(extract( year FROM es.es_begin_date )::int ) as Yearofexam from vw_personal_details vpd\n"
//					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
//					+ "inner join exam_schedule es on es.es_id = ofa.es_id\n"
//					+ "inner join exam_code exm ON exm.ec_exam_id = es.ec_exam_id\n"
//					+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
//					+ "where vpd.opc_personal_code=?\n"
//					+ "and ((extract( year FROM es.es_begin_date )::int) <= vpd.opd_partd)\n"
//					+ "and exm.ec_exam_id =2\n"
//					+ "GROUP By 1,2,3,10\n"
//					+ " ";
			
			
			q="select   vpd.opc_personal_code ,es.es_begin_date,ofa.es_id,\n"
					+ " CASE WHEN (\n"
					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 56::text))\n"
					+ "		  IS NOT NULL THEN  \n"
					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=56) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 56::text) \n"
					+ "		  ELSE ''\n"
					+ "		  end\n"
					+ "		  as tac,\n"
					+ "		  CASE WHEN (\n"
					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 57::text))\n"
					+ "		  IS NOT NULL THEN \n"
					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=57) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 57::text) \n"
					+ "		  ELSE ''\n"
					+ "		  end\n"
					+ "		  as adw\n"
					+ "		  ,\n"
					+ "		    CASE WHEN (string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=58) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 58::text))\n"
					+ "		  IS NOT NULL THEN 	\n"
					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=58) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 58::text)\n"
					+ "		  \n"
					+ "		  ELSE ''\n"
					+ "		  end\n"
					+ "		  as law, \n"
					+ "				\n"
					+ "				  CASE WHEN ( string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=59) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text ) filter (where ab.sc_subject_id::text = 59::text))\n"
					+ "		  IS NOT NULL THEN 			  \n"
					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=59) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text ) filter (where ab.sc_subject_id::text = 59::text)\n"
					+ "					 ELSE ''\n"
					+ "		  end\n"
					+ "					 as mh, \n"
					+ "					    CASE WHEN (string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=60) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 60::text) )\n"
					+ "		  IS NOT NULL THEN   string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=60) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 60::text)  \n"
					+ "		  ELSE ''\n"
					+ "		  end\n"
					+ "		  as ca, \n"
					+ "							  CASE WHEN (  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=61) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 61::text) )\n"
					+ "		  IS NOT NULL THEN  				 \n"
					+ "        string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'   when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=61) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 61::text) \n"
					+ "		  ELSE ''\n"
					+ "		  end\n"
					+ "		  as SPEC\n"
					+ "		  ,vpd.opd_partd\n"
					+ "		  ,(extract( year FROM es.es_begin_date )::int ) as Yearofexam from vw_personal_details vpd\n"
					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
					+ "inner join exam_schedule es on es.es_id = ofa.es_id\n"
					+ "inner join exam_code exm ON exm.ec_exam_id = es.ec_exam_id\n"
					+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
					+ "where vpd.opc_personal_code=?\n"
					+ "and ((extract( year FROM es.es_begin_date )::int) <= vpd.opd_partd)\n"
					+ "and exm.ec_exam_id =2\n"
					+ "GROUP By 1,2,3,10\n"
					+ " ";
			
			stmt = conn.prepareStatement(q);
			
		
			stmt.setString(1, personal_code.toUpperCase());
 
			
			ResultSet rs = stmt.executeQuery();
			
			System.err.println("rs==do==="+rs);
//			
//			
		    System.err.println("stmt=========="+stmt);
		
		    int i=0;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
 
//				
//				
				list.add(rs.getString("TAC"));//0
				list.add(rs.getString("ADW"));//1
				list.add(rs.getString("LAW"));//2
				list.add(rs.getString("MH"));//3
				list.add(rs.getString("CA"));//4
				list.add(rs.getString("SPEC"));//5				  
				list.add(rs.getString("Yearofexam"));//6
//				list.add(rs.getString("opd_partb"));//6
				 
				
				alist.add(list);
				i++;				
				
			}

			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		System.err.println("list==do==="+alist);
		return alist;
	}
	
	
	public  ArrayList<ArrayList<String>> Officer_pers_data_DSSC(String personal_code) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		String whr = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
 
			
//			q="select   vpd.opc_personal_code ,es.es_begin_date,ofa.es_id,\n"
//					+ "CASE WHEN (\n"
//					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=70) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 70::text))\n"
//					+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=70) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 70::text)\n"
//					+ "		  ELSE ''\n"
//					+ "		  end\n"
//					+ "		  as tac_a,\n"
//					+ "		  CASE WHEN (\n"
//					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=71) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 71::text))\n"
//					+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=71) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 71::text)\n"
//					+ "		  ELSE ''\n"
//					+ "		  end\n"
//					+ "		  as tac_b\n"
//					+ "          ,\n"
//					+ " 		 CASE WHEN (\n"
//					+ "	 	 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=72) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 72::text) )	  \n"
//					+ "	     IS NOT NULL THEN 	  \n"
//					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=72) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 72::text) \n"
//					+ "	   	 ELSE ''\n"
//					+ "		 end\n"
//					+ "	   	 as adm_law,\n"
//					+ "\n"
//					+ "		 CASE WHEN (\n"
//					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=73) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 73::text))	\n"
//					+ "	  	 IS NOT NULL THEN \n"
//					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=73) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 73::text)\n"
//					+ "		 ELSE ''\n"
//					+ "		 end\n"
//					+ "	 	 as ca,\n"
//					+ " 		 CASE WHEN (\n"
//					+ "	     string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=74) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 74::text) )	\n"
//					+ "	     IS NOT NULL THEN \n"
//					+ "         string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=74) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 74::text) \n"
//					+ "	     ELSE ''\n"
//					+ "		  end\n"
//					+ "	     as smt,\n"
//					+ "        CASE WHEN (\n"
//					+ "	    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=75) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 75::text))\n"
//					+ "	    IS NOT NULL THEN \n"
//					+ "        string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained<= (select esd.esd_cutoff from exam_schedule_detail esd  \n"
//					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=75) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
//					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
//					+ "		  ) filter (where ab.sc_subject_id::text = 75::text)\n"
//					+ "	    ELSE ''\n"
//					+ "		  end\n"
//					+ "		  as mh\n"
//					+ "		   \n"
//					+ "		  ,(extract( year FROM es.es_begin_date )::int ) as Yearofexam\n"
//					+ " \n"
//					+ "from vw_personal_details vpd\n"
//					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
//					+ "inner join exam_schedule es on es.es_id = ofa.es_id\n"
//					+ "inner join exam_code exm ON exm.ec_exam_id = es.ec_exam_id\n"
//					+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
//					+ "where vpd.opc_personal_code= ?\n"
//					+ "and exm.ec_exam_id =3\n"
//					+ "GROUP By 1,2,3,10 ";
			
			q="select   vpd.opc_personal_code ,es.es_begin_date,ofa.es_id,\n"
					+ "CASE WHEN (\n"
					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=70) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 70::text))\n"
					+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=70) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 70::text)\n"
					+ "		  ELSE ''\n"
					+ "		  end\n"
					+ "		  as tac_a,\n"
					+ "		  CASE WHEN (\n"
					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=71) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 71::text))\n"
					+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=71) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 71::text)\n"
					+ "		  ELSE ''\n"
					+ "		  end\n"
					+ "		  as tac_b\n"
					+ "          ,\n"
					+ " 		 CASE WHEN (\n"
					+ "	 	 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=72) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 72::text) )	  \n"
					+ "	     IS NOT NULL THEN 	  \n"
					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=72) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 72::text) \n"
					+ "	   	 ELSE ''\n"
					+ "		 end\n"
					+ "	   	 as adm_law,\n"
					+ "\n"
					+ "		 CASE WHEN (\n"
					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=73) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 73::text))	\n"
					+ "	  	 IS NOT NULL THEN \n"
					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=73) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 73::text)\n"
					+ "		 ELSE ''\n"
					+ "		 end\n"
					+ "	 	 as ca,\n"
					+ " 		 CASE WHEN (\n"
					+ "	     string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=74) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 74::text) )	\n"
					+ "	     IS NOT NULL THEN \n"
					+ "         string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=74) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 74::text) \n"
					+ "	     ELSE ''\n"
					+ "		  end\n"
					+ "	     as smt,\n"
					+ "        CASE WHEN (\n"
					+ "	    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=75) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 75::text))\n"
					+ "	    IS NOT NULL THEN \n"
					+ "        string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM'  when ab.ab_marks_obtained< (select esd.esd_cutoff from exam_schedule_detail esd  \n"
					+ "					 where esd.es_id=es.es_id and esd.sc_subject_id=75) then coalesce(ab.ab_marks_obtained::text,'0') ||'(F)'					 \n"
					+ "					 else coalesce(ab.ab_marks_obtained::text,'0') ||'(P)' end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 75::text)\n"
					+ "	    ELSE ''\n"
					+ "		  end\n"
					+ "		  as mh\n"
					+ "		   \n"
					+ "		  ,(extract( year FROM es.es_begin_date )::int ) as Yearofexam\n"
					+ " \n"
					+ "from vw_personal_details vpd\n"
					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
					+ "inner join exam_schedule es on es.es_id = ofa.es_id\n"
					+ "inner join exam_code exm ON exm.ec_exam_id = es.ec_exam_id\n"
					+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
					+ "where vpd.opc_personal_code= ?\n"
					+ "and exm.ec_exam_id =3\n"
					+ "GROUP By 1,2,3,10 ";
			
			stmt = conn.prepareStatement(q);
			
		
			stmt.setString(1, personal_code.toUpperCase());
 
			
			ResultSet rs = stmt.executeQuery();
			
			System.err.println("rs==do==="+rs);
//			
//			
		    System.err.println("stmt===Dscs======="+stmt);
		    
		    q=" select   ofa.es_id,qo.nominatedfor \n"
		    		+ " \n"
		    		+ "from vw_personal_details vpd\n"
		    		+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
		    		+ "inner join exam_schedule es on es.es_id = ofa.es_id\n"
		    		+ "left join qualified_officers qo on qo.oa_applicant_id=ofa.oa_application_id\n"
		    		+ "inner join exam_code exm ON exm.ec_exam_id = es.ec_exam_id\n"
		    		+ " \n"
		    		+ "where vpd.opc_personal_code= ?\n"
		    		+ "and exm.ec_exam_id =3\n"
		    		+ "GROUP By 1,2  ";
			
			stmt = conn.prepareStatement(q);
			
		
			stmt.setString(1, personal_code.toUpperCase());
 
			
			ResultSet rs2 = stmt.executeQuery();
		    
		    

			System.err.println("rs==do==="+rs2);
//			
//			
		    System.err.println("stmt=========="+stmt);
		    
		    
		    
		    
		    
		    
		    
		
		    int i=0;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
 
//				
//				
				list.add(rs.getString("tac_a"));//0
				list.add(rs.getString("tac_b"));//1
				list.add(rs.getString("adm_law"));//2
				list.add(rs.getString("ca"));//3
				list.add(rs.getString("smt"));//4
				list.add(rs.getString("mh"));//5				  
				list.add(rs.getString("Yearofexam"));//6
				
               String esidrs =rs.getString("es_id");
				 
				
				rs2 = stmt.executeQuery();
				
				while (rs2.next()) {
				String esid=rs2.getString("es_id");
			  
				 if ( esidrs.equals(esid)) {
					 list.add(rs2.getString("nominatedfor"));//7
					} 
				 else {
					 
					 list.add("");//7
				 }
				} 
				alist.add(list);
				i++;				
				
			}

			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		System.err.println("list==do==="+alist);
		return alist;
	}
	
	
	public  ArrayList<ArrayList<String>> Officer_pers_data_withheld(String personal_code ,int exam_id) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = " ";
		
	 

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			q=" select   vpd.opc_personal_code  ,ofa.es_id,\n"
					+ " (extract( year FROM es.es_begin_date )::int ) as Yearofexam\n"
					+ " from vw_personal_details vpd\n"
					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
					+ "inner join exam_schedule es on es.es_id = ofa.es_id\n"
					+ "inner join exam_code exm ON exm.ec_exam_id = es.ec_exam_id\n"
					+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
					+ "where  vpd.opc_personal_code=? and exm.ec_exam_id =? and  ofa.oa_status_id=4\n"
					+ "GROUP By 1,2,3 ";
			
			stmt = conn.prepareStatement(q);
			 System.err.println("exam_id=="+exam_id); 
			System.err.println("personal_code==do==="+personal_code);
			stmt.setString(1, personal_code.toUpperCase());
			System.err.println("exam_id==do==="+exam_id);
			stmt.setInt(2, exam_id);
			
			
			ResultSet rs = stmt.executeQuery();
			
			System.err.println("rs==do==="+rs);
//			
//			
		    System.err.println("stmt=========="+stmt);
		
		    int i=0;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
 
 			
				 			  
				list.add(rs.getString("Yearofexam")); 
				 
				
				alist.add(list);
				i++;				
				
			}

			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		System.err.println("list==do==="+alist);
		return alist;
	}
	
	
	
	
}
