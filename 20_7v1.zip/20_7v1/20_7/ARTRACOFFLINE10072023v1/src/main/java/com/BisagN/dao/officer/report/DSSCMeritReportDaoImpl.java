package com.BisagN.dao.officer.report;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;


@Service
public class DSSCMeritReportDaoImpl implements DSSCMeritReportDao {

	
	@Autowired
    private DataSource dataSource;
	
	
	CommonController comm = new CommonController();
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	
//	public ArrayList<ArrayList<String>> getMeritListforDSSC(int es_id,String course_id){
//		
//		
//		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
//		Connection conn = null;
//		String q = "";
//		String whr = "";
//		String whr1 = "";
//		String whr2 = "";
//
//		try {
//
//			conn = dataSource.getConnection();
//			PreparedStatement stmt = null;
//			
//			if(course_id.equals("8"))
//			{
//				q="select DISTINCT qo.meritid,qo.oid,qo.nominatedfor, vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description, dsscqua.outof700,\n"
//						+ "cp.fd_service_mks,cp.cpv_mks,\n"
//						+ "string_agg(case when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 70::text) as tac_a,\n"
//						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 71::text) as tac_b,\n"
//						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 72::text) as adm_law,\n"
//						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 73::text) as ca,\n"
//						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 74::text) as smts,\n"
//						+ "		  string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 75::text) as mh \n" 
//						+ "from vw_personal_details vpd \n"
//						+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
//						+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
//						+ "inner join qualified_officers qo on qo.oa_applicant_id=ofa.oa_application_id\n"
//						+ "inner join dsscaualified dsscqua on dsscqua.oa_applicant_id = qo.oa_applicant_id\n"
//						+ "inner join cpv cp on cp.oa_application_id=dsscqua.oa_applicant_id\n"
//						+ "where ofa.es_id= ? and qo.status_id=1 and (qo.course_id= ? or qo.course_id=13 or qo.course_id=0) \n"
//						+ "group by 1,2,3,4,5,6,7,8,9,10,11 order by qo.meritid ";
//			}else {
//				q="select DISTINCT qo.meritid,qo.oid,qo.nominatedfor, vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description, dsscqua.outof700,\n"
//						+ "cp.fd_service_mks,cp.cpv_mks,\n"
//						+ "string_agg(case when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 70::text) as tac_a,\n"
//						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 71::text) as tac_b,\n"
//						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 72::text) as adm_law,\n"
//						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 73::text) as ca,\n"
//						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 74::text) as smts,\n"
//						+ "		  string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 75::text) as mh \n" 
//						+ "from vw_personal_details vpd \n"
//						+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
//						+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
//						+ "inner join qualified_officers qo on qo.oa_applicant_id=ofa.oa_application_id\n"
//						+ "inner join dsscaualified dsscqua on dsscqua.oa_applicant_id = qo.oa_applicant_id\n"
//						+ "inner join cpv cp on cp.oa_application_id=dsscqua.oa_applicant_id\n"
//						+ "where ofa.es_id= ? and qo.status_id=1 and qo.course_id= ? \n"
//						+ "group by 1,2,3,4,5,6,7,8,9,10,11 order by qo.meritid ";
//			}
//
//
//		
//			stmt = conn.prepareStatement(q);
//			stmt.setInt(1, es_id);
//			stmt.setInt(2, Integer.parseInt(course_id));
//			
//			System.err.println("getMeritListforDSSC===="+stmt);
//			ResultSet rs = stmt.executeQuery();
//				int i=1;
////				double  total= 0;
//				int  total= 0;
//				double  carear= 0;
//				double  carear_300= 0;
//				DecimalFormat df_double = new DecimalFormat("0.00");
//			while (rs.next()) {
//				ArrayList<String> list = new ArrayList<String>();
//				list.add(String.valueOf(i));//0
//				list.add(rs.getString("opc_personal_code"));//1
//				list.add(rs.getString("rc_rank_name"));//2
//				list.add(rs.getString("opd_officer_name"));//3
//				list.add(rs.getString("ac_arm_description"));//4
//				list.add(rs.getString("tac_a"));//5
//				list.add(rs.getString("tac_b"));//6
//				list.add(rs.getString("adm_law"));//7
//				list.add(rs.getString("ca"));//8
//				list.add(rs.getString("smts"));//9
//				list.add(rs.getString("mh"));//10
//				
//				
//				String a=rs.getString("tac_a");
//				String b=rs.getString("tac_b");
//				String c=rs.getString("adm_law");
//				String d=rs.getString("ca");
//				String e=rs.getString("smts");
//				String f=rs.getString("mh");
//				
////				total = Double.parseDouble(a)+Double.parseDouble(b)+Double.parseDouble(c)+Double.parseDouble(d)+Double.parseDouble(e)+Double.parseDouble(f);
//				total = Integer.parseInt(a)+Integer.parseInt(b)+Integer.parseInt(c)+Integer.parseInt(d)+Integer.parseInt(e)+Integer.parseInt(f);
//				
//				list.add(String.valueOf(total));//11
//				list.add(rs.getString("outof700"));//12
//				
//				
//				String fd_service_mks=rs.getString("fd_service_mks");
//				String cpv_mks=rs.getString("cpv_mks");
//				carear=Double.parseDouble(fd_service_mks)+Double.parseDouble(cpv_mks);
//				
//				list.add(String.valueOf(df_double.format(carear)));//13
//				
//				String outof700=rs.getString("outof700");
//				carear_300=Double.parseDouble(outof700)+(carear);
//				
//				
//				list.add(String.valueOf(df_double.format(carear_300)));//14
//				list.add(rs.getString("meritid"));//15
//				list.add(rs.getString("nominatedfor"));//16
//				alist.add(list);
//				i++;
//				
//			}
//			rs.close();
//			stmt.close();
//			conn.close();
//		} catch (SQLException e) {
//
//			e.printStackTrace();
//		} finally {
//			if (conn != null) {
//				try {
//					conn.close();
//				} catch (SQLException e) {
//				}
//			}
//		}
//		return alist;
//	}
//	
//public ArrayList<ArrayList<String>> getMeritListforALMC_ISC(int es_id,String course_id){
//		
//		
//		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
//		Connection conn = null;
//		String q = "";
//		try {
//			conn = dataSource.getConnection();
//			PreparedStatement stmt = null;
//				q="select DISTINCT qo.meritid,qo.oid,qo.nominatedfor, vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description, dsscqua.outof700,\n"
//						+ "cp.fd_service_mks,cp.cpv_mks,\n"
//						+ "string_agg(distinct case when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 70::text) as tac_a,\n"
//						+ "string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 71::text) as tac_b,\n"
//						+ "string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 72::text) as adm_law,\n"
//						+ "string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 73::text) as ca,\n"
//						+ "string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 74::text) as smts,\n"
//						+ "string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//						+ "		  ) filter (where ab.sc_subject_id::text = 75::text) as mh,\n"
//						+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=1) as ch1,\n"
//						+ "string_agg(DISTINCT cm.name,',') filter(where dsch.course_preference=2) as ch2,\n"
//						+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=3) as ch3,\n"
//						+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=4) as ch4\n"
//						+ "from vw_personal_details vpd \n"
//						+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
//						+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
//						+ "inner join qualified_officers qo on qo.oa_applicant_id=ofa.oa_application_id\n"
//						+ "inner join dsscaualified dsscqua on dsscqua.oa_applicant_id = qo.oa_applicant_id\n"
//						+ "inner join cpv cp on cp.oa_application_id=dsscqua.oa_applicant_id\n"
//						+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
//						+ "left join dssc_choice_tbl dsch on dsch.dscc_app_id = dssc.id\n"
//						+ "inner join course_master cm on cm.choice_id=dsch.course_applied\n"
//						+ "where ofa.es_id= ? and qo.status_id=1 and (qo.course_id= 8 or qo.course_id=13 or qo.course_id=0) \n"
//						+ "group by 1,2,3,4,5,6,7,8,9,10,11 order by qo.meritid ";
//
//				stmt = conn.prepareStatement(q);
//			stmt.setInt(1, es_id);
////			stmt.setInt(2, Integer.parseInt(course_id));
//			
//			System.err.println("getMeritListforALMC_ISC===="+stmt);
//			ResultSet rs = stmt.executeQuery();
//				int i=1;
////				double  total= 0;
//				int  total= 0;
//				double  carear= 0;
//				double  carear_300= 0;
//				DecimalFormat df_double = new DecimalFormat("0.00");
//			while (rs.next()) {
//				ArrayList<String> list = new ArrayList<String>();
//				list.add(String.valueOf(i));//0
//				list.add(rs.getString("opc_personal_code"));//1
//				list.add(rs.getString("rc_rank_name"));//2
//				list.add(rs.getString("opd_officer_name"));//3
//				list.add(rs.getString("ac_arm_description"));//4
//				list.add(rs.getString("tac_a"));//5
//				list.add(rs.getString("tac_b"));//6
//				list.add(rs.getString("adm_law"));//7
//				list.add(rs.getString("ca"));//8
//				list.add(rs.getString("smts"));//9
//				list.add(rs.getString("mh"));//10
//				String a=rs.getString("tac_a");
//				String b=rs.getString("tac_b");
//				String c=rs.getString("adm_law");
//				String d=rs.getString("ca");
//				String e=rs.getString("smts");
//				String f=rs.getString("mh");
////				total = Double.parseDouble(a)+Double.parseDouble(b)+Double.parseDouble(c)+Double.parseDouble(d)+Double.parseDouble(e)+Double.parseDouble(f);
//				total = Integer.parseInt(a)+Integer.parseInt(b)+Integer.parseInt(c)+Integer.parseInt(d)+Integer.parseInt(e)+Integer.parseInt(f);
//				list.add(String.valueOf(total));//11
//				list.add(rs.getString("outof700"));//12
//				String fd_service_mks=rs.getString("fd_service_mks");
//				String cpv_mks=rs.getString("cpv_mks");
//				carear=Double.parseDouble(fd_service_mks)+Double.parseDouble(cpv_mks);
//				list.add(String.valueOf(df_double.format(carear)));//13
//				String outof700=rs.getString("outof700");
//				carear_300=Double.parseDouble(outof700)+(carear);
//				list.add(String.valueOf(df_double.format(carear_300)));//14
//				list.add(rs.getString("ch1"));
//				list.add(rs.getString("ch2"));
//				list.add(rs.getString("ch3"));
//				list.add(rs.getString("ch4"));
//				list.add(rs.getString("meritid"));//15
//				list.add(rs.getString("nominatedfor"));//16
//				alist.add(list);
//				i++;
//				
//			}
//			System.err.println("getMeritListforALMC_ISC===="+stmt);
//			rs.close();
//			stmt.close();
//			conn.close();
//		} catch (SQLException e) {
//
//			e.printStackTrace();
//		} finally {
//			if (conn != null) {
//				try {
//					conn.close();
//				} catch (SQLException e) {
//				}
//			}
//		}
//		return alist;
//	}
	
	public ArrayList<ArrayList<String>> getMeritListforDSSC(int es_id,String course_id){
		
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			if(course_id.equals("8"))
			{
				q="select DISTINCT qo.meritid,qo.oid,qo.nominatedfor, vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description, dsscqua.outof700,\n"
						+ "cp.fd_service_mks,cp.cpv_mks,ofa.In_Index_Id,\n"
						+ "string_agg(case when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 70::text) as tac_a,\n"
						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 71::text) as tac_b,\n"
						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 72::text) as adm_law,\n"
						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 73::text) as ca,\n"
						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 74::text) as smts,\n"
						+ "		  string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 75::text) as mh \n" 
						+ "from vw_personal_details vpd \n"
						+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
						+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
						+ "inner join qualified_officers qo on qo.oa_applicant_id=ofa.oa_application_id\n"
						+ "inner join dsscaualified dsscqua on dsscqua.oa_applicant_id = qo.oa_applicant_id\n"
						+ "inner join cpv cp on cp.oa_application_id=dsscqua.oa_applicant_id\n"
						+ "where ofa.es_id= ? and qo.status_id=1 and (qo.course_id= ? or qo.course_id=13 or qo.course_id=0) \n"
						+ "group by 1,2,3,4,5,6,7,8,9,10,11,12 order by qo.meritid ";
			}else {
				q="select DISTINCT qo.meritid,qo.oid,qo.nominatedfor, vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description, dsscqua.outof700,\n"
						+ "cp.fd_service_mks,cp.cpv_mks,ofa.In_Index_Id, \n"
						+ "string_agg(case when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 70::text) as tac_a,\n"
						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 71::text) as tac_b,\n"
						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 72::text) as adm_law,\n"
						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 73::text) as ca,\n"
						+ "string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 74::text) as smts,\n"
						+ "		  string_agg(case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 75::text) as mh \n" 
						+ "from vw_personal_details vpd \n"
						+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
						+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
						+ "inner join qualified_officers qo on qo.oa_applicant_id=ofa.oa_application_id\n"
						+ "inner join dsscaualified dsscqua on dsscqua.oa_applicant_id = qo.oa_applicant_id\n"
						+ "inner join cpv cp on cp.oa_application_id=dsscqua.oa_applicant_id\n"
						+ "where ofa.es_id= ? and qo.status_id=1 and qo.course_id= ? \n"
						+ "group by 1,2,3,4,5,6,7,8,9,10,11,12 order by qo.meritid ";
			}


		
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			stmt.setInt(2, Integer.parseInt(course_id));
			
			System.err.println("getMeritListforDSSC===="+stmt);
			ResultSet rs = stmt.executeQuery();
				int i=1;
//				double  total= 0;
				int  total= 0;
				double  carear= 0;
				double  carear_300= 0;
				DecimalFormat df_double = new DecimalFormat("0.00");
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				
				
				
				list.add(String.valueOf(i));//0
				list.add(Data);//1
				list.add(rs.getString("rc_rank_name"));//2
				list.add(rs.getString("opd_officer_name"));//3
				list.add(rs.getString("ac_arm_description"));//4
				list.add(rs.getString("tac_a"));//5
				list.add(rs.getString("tac_b"));//6
				list.add(rs.getString("adm_law"));//7
				list.add(rs.getString("ca"));//8
				list.add(rs.getString("smts"));//9
				list.add(rs.getString("mh"));//10
				
				
				
				String a=rs.getString("tac_a");
				String b=rs.getString("tac_b");
				String c=rs.getString("adm_law");
				String d=rs.getString("ca");
				String e=rs.getString("smts");
				String f=rs.getString("mh");
				
//				total = Double.parseDouble(a)+Double.parseDouble(b)+Double.parseDouble(c)+Double.parseDouble(d)+Double.parseDouble(e)+Double.parseDouble(f);
				total = Integer.parseInt(a)+Integer.parseInt(b)+Integer.parseInt(c)+Integer.parseInt(d)+Integer.parseInt(e)+Integer.parseInt(f);
				
				list.add(String.valueOf(total));//11
				list.add(rs.getString("outof700"));//12
				
				
				String fd_service_mks=rs.getString("fd_service_mks");
				String cpv_mks=rs.getString("cpv_mks");
				carear=Double.parseDouble(fd_service_mks)+Double.parseDouble(cpv_mks);
				
				list.add(String.valueOf(df_double.format(carear)));//13
				
				String outof700=rs.getString("outof700");
				carear_300=Double.parseDouble(outof700)+(carear);
				
				
				list.add(String.valueOf(df_double.format(carear_300)));//14
				list.add(rs.getString("meritid"));//15
				list.add(rs.getString("nominatedfor"));//16
//				list.add(nominatedfor(rs.getString("nominatedfor")));//16
				list.add(rs.getString("In_Index_Id"));//17
				alist.add(list);
				i++;
				
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
public ArrayList<ArrayList<String>> getMeritListforALMC_ISC(int es_id,String course_id){
		
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
				q="select DISTINCT qo.meritid,qo.oid,qo.nominatedfor, vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description, dsscqua.outof700,\n"
						+ "cp.fd_service_mks,cp.cpv_mks,ofa.In_Index_Id,\n"
						+ "string_agg(distinct case when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 70::text) as tac_a,\n"
						+ "string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 71::text) as tac_b,\n"
						+ "string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 72::text) as adm_law,\n"
						+ "string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 73::text) as ca,\n"
						+ "string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 74::text) as smts,\n"
						+ "string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
						+ "		  ) filter (where ab.sc_subject_id::text = 75::text) as mh,\n"
						+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=1) as ch1,\n"
						+ "string_agg(DISTINCT cm.name,',') filter(where dsch.course_preference=2) as ch2,\n"
						+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=3) as ch3,\n"
						+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=4) as ch4\n"
						+ "from vw_personal_details vpd \n"
						+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
						+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
						+ "inner join qualified_officers qo on qo.oa_applicant_id=ofa.oa_application_id\n"
						+ "inner join dsscaualified dsscqua on dsscqua.oa_applicant_id = qo.oa_applicant_id\n"
						+ "inner join cpv cp on cp.oa_application_id=dsscqua.oa_applicant_id\n"
						+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
						+ "left join dssc_choice_tbl dsch on dsch.dscc_app_id = dssc.id\n"
						+ "inner join course_master cm on cm.choice_id=dsch.course_applied\n"
						+ "where ofa.es_id= ? and qo.status_id=1 and (qo.course_id= 8 or qo.course_id=13 or qo.course_id=0) \n"
						+ "group by 1,2,3,4,5,6,7,8,9,10,11,12 order by qo.meritid ";

				stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
//			stmt.setInt(2, Integer.parseInt(course_id));
			
			System.err.println("getMeritListforALMC_ISC===="+stmt);
			ResultSet rs = stmt.executeQuery();
				int i=1;
//				double  total= 0;
				int  total= 0;
				double  carear= 0;
				double  carear_300= 0;
				DecimalFormat df_double = new DecimalFormat("0.00");
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				list.add(String.valueOf(i));//0
				list.add(Data);//1
				list.add(rs.getString("rc_rank_name"));//2
				list.add(rs.getString("opd_officer_name"));//3
				list.add(rs.getString("ac_arm_description"));//4
				list.add(rs.getString("tac_a"));//5
				list.add(rs.getString("tac_b"));//6
				list.add(rs.getString("adm_law"));//7
				list.add(rs.getString("ca"));//8
				list.add(rs.getString("smts"));//9
				list.add(rs.getString("mh"));//10
				String a=rs.getString("tac_a");
				String b=rs.getString("tac_b");
				String c=rs.getString("adm_law");
				String d=rs.getString("ca");
				String e=rs.getString("smts");
				String f=rs.getString("mh");
//				total = Double.parseDouble(a)+Double.parseDouble(b)+Double.parseDouble(c)+Double.parseDouble(d)+Double.parseDouble(e)+Double.parseDouble(f);
				total = Integer.parseInt(a)+Integer.parseInt(b)+Integer.parseInt(c)+Integer.parseInt(d)+Integer.parseInt(e)+Integer.parseInt(f);
				list.add(String.valueOf(total));//11
				list.add(rs.getString("outof700"));//12
				String fd_service_mks=rs.getString("fd_service_mks");
				String cpv_mks=rs.getString("cpv_mks");
				carear=Double.parseDouble(fd_service_mks)+Double.parseDouble(cpv_mks);
				list.add(String.valueOf(df_double.format(carear)));//13
				String outof700=rs.getString("outof700");
				carear_300=Double.parseDouble(outof700)+(carear);
				list.add(String.valueOf(df_double.format(carear_300)));//14
				list.add(rs.getString("ch1"));
				list.add(rs.getString("ch2"));
				list.add(rs.getString("ch3"));
				list.add(rs.getString("ch4"));
				list.add(rs.getString("meritid"));//15
//				list.add(rs.getString("nominatedfor"));//16
				list.add(nominatedfor(rs.getString("nominatedfor")));//16
				list.add(rs.getString("In_Index_Id"));//17
				
				alist.add(list);
				i++;
				
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}



public ArrayList<ArrayList<String>> getOverallReport(int es_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String whr = "";
	String whr1 = "";
	String whr2 = "";

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
		
		
//		q=" Select * , ROW_NUMBER() OVER(ORDER BY 1,2,3) as a1 from(\n"
//				+ "\n"
//				+ "Select * from(\n"
//				+ "	\n"
//				+ "SELECT   vpd.opc_personal_code,  qoa.meritid,qoa.nominatedfor,vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name,\n"
//				+ "vpd.ac_arm_description, (sum(ab.ab_marks_obtained)) as TOTAL, ROUND(dsscqua.outof700,2)as outof700, ROUND((dsscqua.outof700+cp.cpv_mks),2) as outof1000,\n"
//				+ "cp.fd_service_mks,ROUND(cp.cpv_mks,2) as cpv_mks, 			\n"
//				+ " \n"
//				+ "		  CASE WHEN (\n"
//				+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 70::text))\n"
//				+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 70::text)\n"
//				+ "		  ELSE 'ABS'\n"
//				+ "		  end\n"
//				+ "		  as tac_a,\n"
//				+ "		  CASE WHEN (\n"
//				+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 71::text))\n"
//				+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 71::text)\n"
//				+ "		  ELSE 'ABS'\n"
//				+ "		  end\n"
//				+ "		  as tac_b\n"
//				+ "          ,\n"
//				+ " 		 CASE WHEN (\n"
//				+ "	 	 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 72::text) )	  \n"
//				+ "	     IS NOT NULL THEN 	  \n"
//				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 72::text) \n"
//				+ "	   	 ELSE 'ABS'\n"
//				+ "		 end\n"
//				+ "	   	 as adm_law,\n"
//				+ "\n"
//				+ "		 CASE WHEN (\n"
//				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 73::text))	\n"
//				+ "	  	 IS NOT NULL THEN \n"
//				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 73::text)\n"
//				+ "		 ELSE 'ABS'\n"
//				+ "		 end\n"
//				+ "	 	 as ca,\n"
//				+ " 		 CASE WHEN (\n"
//				+ "	     string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 74::text) )	\n"
//				+ "	     IS NOT NULL THEN \n"
//				+ "         string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 74::text) \n"
//				+ "	     ELSE 'ABS'\n"
//				+ "		  end\n"
//				+ "	     as smts,\n"
//				+ "        CASE WHEN (\n"
//				+ "	    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 75::text))\n"
//				+ "	    IS NOT NULL THEN \n"
//				+ "        string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 75::text)\n"
//				+ "	    ELSE 'ABS'\n"
//				+ "		  end\n"
//				+ "	    as mh ,ch.ch1,ch.ch2,ch.ch3,ch.ch4 from (\n"
//				+ "\n"
//				+ "select DISTINCT vpd.opd_personal_id,ofa.oa_application_id, string_agg(distinct cm.name,',') filter(where dsch.course_preference=1) as ch1,\n"
//				+ "string_agg(DISTINCT cm.name,',') filter(where dsch.course_preference=2) as ch2,\n"
//				+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=3) as ch3,\n"
//				+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=4) as ch4\n"
//				+ "											from vw_personal_details vpd \n"
//				+ "											inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id 											\n"
//				+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
//				+ "left join dssc_choice_tbl dsch on dsch.dscc_app_id = dssc.id\n"
//				+ "inner join course_master cm on cm.choice_id=dsch.course_applied\n"
//				+ "			inner join qualified_officers qo on qo.oa_applicant_id=ofa.oa_application_id\n"
//				+ "inner join dsscaualified dsscqua on dsscqua.oa_applicant_id = qo.oa_applicant_id\n"
//				+ "											 where ofa.es_id= ? and qo.status_id=1  \n"
//				+ "			group by vpd.opd_personal_id,ofa.oa_application_id	\n"
//				+ ") as ch\n"
//				+ "inner join vw_personal_details vpd on  vpd.opd_personal_id 	=  ch.opd_personal_id\n"
//				+ "inner join answer_book ab on ab.oa_application_id = ch.oa_application_id\n"
//				+ "											inner join cpv cp on cp.oa_application_id= ch.oa_application_id\n"
//				+ "											 	inner join qualified_officers qoa on qoa.oa_applicant_id=ch.oa_application_id\n"
//				+ "inner join dsscaualified dsscqua on dsscqua.oa_applicant_id = qoa.oa_applicant_id\n"
//				+ "											group by vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description, \n"
//				+ "											dsscqua.outof700,qoa.meritid,qoa.nominatedfor,cp.fd_service_mks,cp.cpv_mks,ch.ch1,ch.ch2,ch.ch3,ch.ch4 \n"
//				+ "	                               ORDER by  meritid\n"
//				+ ") as q\n"
//				+ "			\n"
//				+ " UNION all\n"
//				+ " \n"
//				+ " Select *   from(\n"
//				+ "	\n"
//				+ "SELECT    vpd.opc_personal_code, 0 as merit_id,'Fail' as nominatedfor, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description ,\n"
//				+ "							(sum(ab.ab_marks_obtained)) as TOTAL,ROUND((((sum(ab.ab_marks_obtained))*700)/3000),2)	as  outof700 , ROUND(( (((sum(ab.ab_marks_obtained))*700)/3000)+cp.cpv_mks),2) as outof1000,\n"
//				+ "cp.fd_service_mks,ROUND(cp.cpv_mks,2)as cpv_mks , 			\n"
//				+ " \n"
//				+ "		  CASE WHEN (\n"
//				+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 70::text))\n"
//				+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 70::text)\n"
//				+ "		  ELSE 'ABS'\n"
//				+ "		  end\n"
//				+ "		  as tac_a,\n"
//				+ "		  CASE WHEN (\n"
//				+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 71::text))\n"
//				+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 71::text)\n"
//				+ "		  ELSE 'ABS'\n"
//				+ "		  end\n"
//				+ "		  as tac_b\n"
//				+ "          ,\n"
//				+ " 		 CASE WHEN (\n"
//				+ "	 	 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 72::text) )	  \n"
//				+ "	     IS NOT NULL THEN 	  \n"
//				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 72::text) \n"
//				+ "	   	 ELSE 'ABS'\n"
//				+ "		 end\n"
//				+ "	   	 as adm_law,\n"
//				+ "\n"
//				+ "		 CASE WHEN (\n"
//				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 73::text))	\n"
//				+ "	  	 IS NOT NULL THEN \n"
//				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 73::text)\n"
//				+ "		 ELSE 'ABS'\n"
//				+ "		 end\n"
//				+ "	 	 as ca,\n"
//				+ " 		 CASE WHEN (\n"
//				+ "	     string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 74::text) )	\n"
//				+ "	     IS NOT NULL THEN \n"
//				+ "         string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 74::text) \n"
//				+ "	     ELSE 'ABS'\n"
//				+ "		  end\n"
//				+ "	     as smts,\n"
//				+ "        CASE WHEN (\n"
//				+ "	    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 75::text))\n"
//				+ "	    IS NOT NULL THEN \n"
//				+ "        string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
//				+ "		  ) filter (where ab.sc_subject_id::text = 75::text)\n"
//				+ "	    ELSE 'ABS'\n"
//				+ "		  end\n"
//				+ "	    as mh ,ch.ch1,ch.ch2,ch.ch3,ch.ch4 from (\n"
//				+ "\n"
//				+ "select DISTINCT vpd.opd_personal_id,ofa.oa_application_id, string_agg(distinct cm.name,',') filter(where dsch.course_preference=1) as ch1,\n"
//				+ "string_agg(DISTINCT cm.name,',') filter(where dsch.course_preference=2) as ch2,\n"
//				+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=3) as ch3,\n"
//				+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=4) as ch4\n"
//				+ "											from vw_personal_details vpd \n"
//				+ "											inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id 											\n"
//				+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
//				+ "left join dssc_choice_tbl dsch on dsch.dscc_app_id = dssc.id\n"
//				+ "inner join course_master cm on cm.choice_id=dsch.course_applied\n"
//				+ "											where  ofa.es_id=? and  not exists (select * from qualified_officers qua where qua.oa_applicant_id=ofa.oa_application_id ) \n"
//				+ "											group by vpd.opd_personal_id,ofa.oa_application_id	\n"
//				+ ") as ch\n"
//				+ "inner join vw_personal_details vpd on  vpd.opd_personal_id 	=  ch.opd_personal_id\n"
//				+ "inner join answer_book ab on ab.oa_application_id = ch.oa_application_id\n"
//				+ "											inner join cpv cp on cp.oa_application_id= ch.oa_application_id\n"
//				+ "											 \n"
//				+ "											group by vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description \n"
//				+ "											,cp.fd_service_mks,cp.cpv_mks,ch.ch1,ch.ch2,ch.ch3,ch.ch4 	\n"
//				+ "											\n"
//				+ "											\n"
//				+ "											ORDER by TOTAL DESC \n"
//				+ ") as w\n"
//				+ ")as e";
//		
		q="		Select * from(\n"
				+ "	\n"
				+ "SELECT  DISTINCT  vpd.opc_personal_code,  qoa.meritid,qoa.nominatedfor,vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name,\n"
				+ "vpd.ac_arm_description, (sum(ab.ab_marks_obtained)) as TOTAL, ROUND(dsscqua.outof700,2)as outof700, ROUND((dsscqua.outof700+cp.cpv_mks),2) as outof1000,\n"
				+ "cp.fd_service_mks,ROUND(cp.cpv_mks,2) as cpv_mks, 			\n"
				+ " \n"
				+ "		  CASE WHEN (\n"
				+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 70::text))\n"
				+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 70::text)\n"
				+ "		  ELSE 'ABS'\n"
				+ "		  end\n"
				+ "		  as tac_a,\n"
				+ "		  CASE WHEN (\n"
				+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 71::text))\n"
				+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 71::text)\n"
				+ "		  ELSE 'ABS'\n"
				+ "		  end\n"
				+ "		  as tac_b\n"
				+ "          ,\n"
				+ " 		 CASE WHEN (\n"
				+ "	 	 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 72::text) )	  \n"
				+ "	     IS NOT NULL THEN 	  \n"
				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 72::text) \n"
				+ "	   	 ELSE 'ABS'\n"
				+ "		 end\n"
				+ "	   	 as adm_law,\n"
				+ "\n"
				+ "		 CASE WHEN (\n"
				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 73::text))	\n"
				+ "	  	 IS NOT NULL THEN \n"
				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 73::text)\n"
				+ "		 ELSE 'ABS'\n"
				+ "		 end\n"
				+ "	 	 as ca,\n"
				+ " 		 CASE WHEN (\n"
				+ "	     string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 74::text) )	\n"
				+ "	     IS NOT NULL THEN \n"
				+ "         string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 74::text) \n"
				+ "	     ELSE 'ABS'\n"
				+ "		  end\n"
				+ "	     as smts,\n"
				+ "        CASE WHEN (\n"
				+ "	    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 75::text))\n"
				+ "	    IS NOT NULL THEN \n"
				+ "        string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 75::text)\n"
				+ "	    ELSE 'ABS'\n"
				+ "		  end\n"
				+ "	    as mh ,ch.ch1,ch.ch2,ch.ch3,ch.ch4 from (\n"
				+ "\n"
				+ "select DISTINCT vpd.opd_personal_id,ofa.oa_application_id, string_agg(distinct cm.name,',') filter(where dsch.course_preference=1) as ch1,\n"
				+ "string_agg(DISTINCT cm.name,',') filter(where dsch.course_preference=2) as ch2,\n"
				+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=3) as ch3,\n"
				+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=4) as ch4\n"
				+ "											from vw_personal_details vpd \n"
				+ "											inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id 											\n"
				+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
				+ "left join dssc_choice_tbl dsch on dsch.dscc_app_id = dssc.id\n"
				+ "inner join course_master cm on cm.choice_id=dsch.course_applied\n"
				+ "			inner join qualified_officers qo on qo.oa_applicant_id=ofa.oa_application_id\n"
				+ "inner join dsscaualified dsscqua on dsscqua.oa_applicant_id = qo.oa_applicant_id\n"
				+ "											 where ofa.es_id= ? and qo.status_id=1 \n"
				+ "			group by vpd.opd_personal_id,ofa.oa_application_id	\n"
				+ ") as ch\n"
				+ "inner join vw_personal_details vpd on  vpd.opd_personal_id 	=  ch.opd_personal_id\n"
				+ "inner join answer_book ab on ab.oa_application_id = ch.oa_application_id\n"
				+ "											inner join cpv cp on cp.oa_application_id= ch.oa_application_id\n"
				+ "											 	inner join qualified_officers qoa on qoa.oa_applicant_id=ch.oa_application_id  and qoa.status_id=1\n"
				+ "inner join dsscaualified dsscqua on dsscqua.oa_applicant_id = qoa.oa_applicant_id\n"
				+ "											group by vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description, \n"
				+ "											dsscqua.outof700,qoa.meritid,qoa.nominatedfor,cp.fd_service_mks,cp.cpv_mks,ch.ch1,ch.ch2,ch.ch3,ch.ch4 \n"
				+ "	                               ORDER by  meritid \n"
				+ ") as q\n"
				+ "			\n"
				+ " UNION all\n"
				+ " \n"
				+ " Select * from(\n"
				+ "	\n"
				+ "SELECT  DISTINCT vpd.opc_personal_code, 0 as meritid,'Fail' as nominatedfor, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description ,\n"
				+ "							(sum(ab.ab_marks_obtained)) as TOTAL,ROUND((((sum(ab.ab_marks_obtained))*700)/3000),2)	as  outof700 , ROUND(( (((sum(ab.ab_marks_obtained))*700)/3000)+cp.cpv_mks),2) as outof1000,\n"
				+ "cp.fd_service_mks,ROUND(cp.cpv_mks,2)as cpv_mks , 			\n"
				+ " \n"
				+ "		  CASE WHEN (\n"
				+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 70::text))\n"
				+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 70::text)\n"
				+ "		  ELSE 'ABS'\n"
				+ "		  end\n"
				+ "		  as tac_a,\n"
				+ "		  CASE WHEN (\n"
				+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 71::text))\n"
				+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 71::text)\n"
				+ "		  ELSE 'ABS'\n"
				+ "		  end\n"
				+ "		  as tac_b\n"
				+ "          ,\n"
				+ " 		 CASE WHEN (\n"
				+ "	 	 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 72::text) )	  \n"
				+ "	     IS NOT NULL THEN 	  \n"
				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 72::text) \n"
				+ "	   	 ELSE 'ABS'\n"
				+ "		 end\n"
				+ "	   	 as adm_law,\n"
				+ "\n"
				+ "		 CASE WHEN (\n"
				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 73::text))	\n"
				+ "	  	 IS NOT NULL THEN \n"
				+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 73::text)\n"
				+ "		 ELSE 'ABS'\n"
				+ "		 end\n"
				+ "	 	 as ca,\n"
				+ " 		 CASE WHEN (\n"
				+ "	     string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 74::text) )	\n"
				+ "	     IS NOT NULL THEN \n"
				+ "         string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 74::text) \n"
				+ "	     ELSE 'ABS'\n"
				+ "		  end\n"
				+ "	     as smts,\n"
				+ "        CASE WHEN (\n"
				+ "	    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 75::text))\n"
				+ "	    IS NOT NULL THEN \n"
				+ "        string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
				+ "		  ) filter (where ab.sc_subject_id::text = 75::text)\n"
				+ "	    ELSE 'ABS'\n"
				+ "		  end\n"
				+ "	    as mh ,ch.ch1,ch.ch2,ch.ch3,ch.ch4 from (\n"
				+ "\n"
				+ "select DISTINCT vpd.opd_personal_id,ofa.oa_application_id, string_agg(distinct cm.name,',') filter(where dsch.course_preference=1) as ch1,\n"
				+ "string_agg(DISTINCT cm.name,',') filter(where dsch.course_preference=2) as ch2,\n"
				+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=3) as ch3,\n"
				+ "string_agg(distinct cm.name,',') filter(where dsch.course_preference=4) as ch4\n"
				+ "											from vw_personal_details vpd \n"
				+ "											inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id 											\n"
				+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
				+ "left join dssc_choice_tbl dsch on dsch.dscc_app_id = dssc.id\n"
				+ "inner join course_master cm on cm.choice_id=dsch.course_applied\n"
				+ "											where  ofa.es_id=? and  not exists (select * from qualified_officers qua where qua.oa_applicant_id=ofa.oa_application_id ) \n"
				+ "											group by  vpd.opd_personal_id,ofa.oa_application_id	\n"
				+ ") as ch\n"
				+ "inner join vw_personal_details vpd on  vpd.opd_personal_id 	=  ch.opd_personal_id\n"
				+ "inner join answer_book ab on ab.oa_application_id = ch.oa_application_id\n"
				+ "											inner join cpv cp on cp.oa_application_id= ch.oa_application_id\n"
				+ "											 \n"
				+ "											group by vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description \n"
				+ "											,cp.fd_service_mks,cp.cpv_mks,ch.ch1,ch.ch2,ch.ch3,ch.ch4 	\n"
				+ "											\n"
				+ "											\n"
				+ "											ORDER by outof1000 DESC \n"
				+ ") as w";
		


	
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
		stmt.setInt(2, es_id);
		
		System.err.println("ALMC===="+stmt);
		ResultSet rs = stmt.executeQuery();
int i=1;
int sum=0;
String ch="";
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			
			Data=DataPre+DataM;
			list.add(String.valueOf(i));//0
			list.add(Data+ "  "+rs.getString("opc_suffix_code"));//1
			list.add(rs.getString("rc_rank_name"));//2
			list.add(rs.getString("opd_officer_name"));//3
			list.add(rs.getString("ac_arm_description"));//4
			list.add(rs.getString("tac_a"));//5
			list.add(rs.getString("tac_b"));//6
			list.add(rs.getString("adm_law"));//7
			list.add(rs.getString("ca"));//8
			list.add(rs.getString("smts"));//9
			list.add(rs.getString("mh"));//10
			
			  
			list.add(rs.getString("total"));//15
			list.add(rs.getString("fd_service_mks"));//16
			list.add(rs.getString("cpv_mks"));//17
			list.add(rs.getString("outof700"));//18
			list.add(rs.getString("outof1000"));//19

  
			
			list.add(Choice( rs.getString("ch1")));//11
			list.add(Choice( rs.getString("ch2")));//12										
			list.add(Choice( rs.getString("ch3")));//13										
			    list.add(Choice( rs.getString("ch4")));//14
			
 
			list.add(rs.getString("meritid"));//meritid
			list.add(nominatedfor(rs.getString("nominatedfor")));
			
			alist.add(list);
			i++;

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}
public ArrayList<ArrayList<String>> getCutoffRepoerforDSSC(int es_id,String course_id){
	
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	try {
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q="select qo.nominatedfor,min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=70) as tac_a, \n"
				+ "				min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=71)  as tac_b, \n"
				+ "				min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=72) as al,\n"
				+ "				min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=73) as ca, \n"
				+ "				min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=74) as smt, \n"
				+ "			 min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=75) as mh\n"
				+ "				from qualified_officers qo \n"
				+ "				inner join answer_book ab on ab.oa_application_id=qo.oa_applicant_id \n"
				+ "				where qo.es_id=? and qo.nominatedfor not in ('Fail')\n"
				+ "			    group by 1  \n"
				+ "				order by CASE WHEN qo.nominatedfor LIKE 'COMPETITIVE' THEN 1 \n"
				+ "				 WHEN qo.nominatedfor LIKE 'DSSC' THEN 2\n"
				+ "				  WHEN qo.nominatedfor LIKE 'DSSC Res' THEN 3\n"
				+ "				 WHEN qo.nominatedfor LIKE 'DSTSC' THEN 4\n"
				+ "				  WHEN qo.nominatedfor LIKE 'DSTSC Res' THEN 5\n"
				+ "				 WHEN qo.nominatedfor LIKE 'ALMC' THEN 6\n"
				+ "				 WHEN qo.nominatedfor LIKE 'ALMC Res' THEN 7\n"
				+ "				  WHEN qo.nominatedfor LIKE 'ISC' THEN 8 \n"
				+ "				 WHEN qo.nominatedfor LIKE 'ISC Res' THEN 9\n"
				+ "				ELSE 10\n"
				+ "				END";
		
//		q = "select qo.nominatedfor,min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=70) as tac_a, \n"
//				+"min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=71)  as tac_b, \n"
//				+"min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=72) as al, \n"
//				+"min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=73) as ca, \n"
//				+"min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=74) as smt, \n"
//				+" min(ab.ab_marks_obtained) filter (where ab.sc_subject_id=75) as mh\n"
//				+"from qualified_officers qo \n"
//				+"inner join answer_book ab on ab.oa_application_id=qo.oa_applicant_id \n"
//				+"where qo.es_id=189 and qo.nominatedfor not in ('Fail') \n"
//				+"group by 1 order by 1 asc";
			
				
			stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
//		stmt.setInt(2, Integer.parseInt(course_id));
		
		System.err.println("CUTOFF REport===="+stmt);
		ResultSet rs = stmt.executeQuery();
			int i=1;
//			double  total= 0;
			int  total= 0;
			double  carear= 0;
			double  carear_300= 0;
			DecimalFormat df_double = new DecimalFormat("0.00");
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(String.valueOf(i));//0
			list.add(rs.getString("nominatedfor"));//1
			
			list.add(rs.getString("tac_a"));//2
			list.add(rs.getString("tac_b"));//3
			list.add(rs.getString("al"));//4
			list.add(rs.getString("ca"));//5
			list.add(rs.getString("smt"));//6
			list.add(rs.getString("mh"));//7
		
			alist.add(list);
			i++;
			
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}


/////////////////UPGRADATION DSTSCTODSSC  REPORT JAY
public ArrayList<ArrayList<String>> getUpgradationRepoerforDSTSCTODSSC(int es_id){
	
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	try {
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q="\n"
				+ "\n"
				+ "SELECT  vpd.opc_personal_code,vpd.opc_suffix_code,vpd.rc_rank_name,vpd.opd_officer_name,upgradefrom, upgradeto from (\n"
				+ "SELECT DISTINCT qof.oa_applicant_id, \n"
				+ "	\n"
				+ "	 string_agg(CASE WHEN qof.status_id = 2  \n"
				+ "		    THEN qof.nominatedfor  \n"
				+ "		  ELSE  ''\n"
				+ "		  end ,'') filter (where  1=1) as upgradefrom \n"
				+ "	 ,\n"
				+ "		  	 string_agg(CASE WHEN qof.status_id = 1  \n"
				+ "		    THEN qof.nominatedfor  \n"
				+ "		  ELSE  ''\n"
				+ "		  end ,'') filter (where  1=1) as upgradeto\n"
				+ "		  \n"
				+ "		  from (\n"
				+ "\n"
				+ "SELECT  a.oa_applicant_id from qualified_officers a\n"
				+ "  INNER JOIN qualified_officers b on a.oa_applicant_id = b.oa_applicant_id\n"
				+ "where  \n"
				+ " a.status_id = 1 \n"
				+ "  AND b.status_id = 2\n"
				+ "	and	\n"
				+ "			   a.course_id = 5\n"
				+ "			  and\n"
				+ "			   b.course_id = 6\n"
				+ "	 ) as oai\n"
				+ "	\n"
				+ "inner join qualified_officers qof on oai.oa_applicant_id = qof.oa_applicant_id\n"
				+ "	\n"
				+ "GROUP by  qof.oa_applicant_id\n"
				+ ") as d\n"
				+ "\n"
				+ "inner join officer_application ofa on ofa.oa_application_id= d.oa_applicant_id\n"
				+ "inner join  vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
				
				+ " where  ofa.es_id=? ";
		
//		
				
			stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
//		stmt.setInt(2, Integer.parseInt(course_id));
		
		System.err.println("UPGRADATION REport===="+stmt);
		ResultSet rs = stmt.executeQuery();
			int i=1;
//			double  total= 0;
			int  total= 0;
			double  carear= 0;
			double  carear_300= 0;
			DecimalFormat df_double = new DecimalFormat("0.00");
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(String.valueOf(i));//0
			
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			
			Data=DataPre+DataM;
			list.add(Data+ "  "+rs.getString("opc_suffix_code"));//1			
			list.add(rs.getString("rc_rank_name"));//2 RANK
			list.add(rs.getString("opd_officer_name"));//3 NAME
			list.add(rs.getString("upgradefrom"));//4 UPGRADATION FROM
			list.add(rs.getString("upgradeto"));//5UPGRADATION TO

			alist.add(list);
			i++;
			
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}



/////////////////UPGRADATION RESERVETODSSC /DSTSC  REPORT JAY
public ArrayList<ArrayList<String>> getUpgradationRepoerforRESERVETODSSCDSTSC(int es_id){
	

ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
Connection conn = null;
String q = "";
try {
conn = dataSource.getConnection();
PreparedStatement stmt = null;

q="\n"
		+ "\n"
		+ "SELECT  vpd.opc_personal_code,vpd.opc_suffix_code,vpd.rc_rank_name,vpd.opd_officer_name,upgradefrom, upgradeto from (\n"
		+ "SELECT DISTINCT qof.oa_applicant_id, \n"
		+ "	\n"
		+ "	 string_agg(CASE WHEN qof.status_id = 2  \n"
		+ "		    THEN qof.nominatedfor  \n"
		+ "		  ELSE  ''\n"
		+ "		  end ,'') filter (where  1=1) as upgradefrom \n"
		+ "	 ,\n"
		+ "		  	 string_agg(CASE WHEN qof.status_id = 1  \n"
		+ "		    THEN qof.nominatedfor  \n"
		+ "		  ELSE  ''\n"
		+ "		  end ,'') filter (where  1=1) as upgradeto\n"
		+ "		  \n"
		+ "		  from (\n"
		+ "\n"
		+ "SELECT  a.oa_applicant_id from qualified_officers a\n"
		+ "  INNER JOIN qualified_officers b on a.oa_applicant_id = b.oa_applicant_id\n"
		+ "where  \n"
		+ " a.status_id = 1 \n"
		+ "  AND b.status_id = 2\n"
		+ "			  and(a.course_id = 5 or a.course_id = 6)\n"
		+ " and	 (  b.nominatedfor='DSTSC Res'  or b.nominatedfor='DSSC Res')\n"
		+ "	 ) as oai\n"
		+ "	\n"
		+ "inner join qualified_officers qof on oai.oa_applicant_id = qof.oa_applicant_id\n"
		+ "	\n"
		+ "GROUP by  qof.oa_applicant_id\n"
		+ ") as d\n"
		+ "\n"
		+ "inner join officer_application ofa on ofa.oa_application_id= d.oa_applicant_id\n"
		+ "inner join  vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
		+ " where  ofa.es_id=?";

//

stmt = conn.prepareStatement(q);
stmt.setInt(1, es_id);
//stmt.setInt(2, Integer.parseInt(course_id));

System.err.println("UPGRADATION REport===="+stmt);
ResultSet rs = stmt.executeQuery();
int i=1;
//double  total= 0;
int  total= 0;
double  carear= 0;
double  carear_300= 0;
DecimalFormat df_double = new DecimalFormat("0.00");
while (rs.next()) {
ArrayList<String> list = new ArrayList<String>();
list.add(String.valueOf(i));//0
String Data=rs.getString("opc_personal_code");
String DataPre="";
String DataM="";
if(Data.contains("NTR") || Data.contains("NTS")) {
	DataPre= Data.substring(0,3);
	DataM = Data.substring(4);
}else {
	DataPre= Data.substring(0,2);
	DataM = Data.substring(3);
}

Data=DataPre+DataM;
list.add(Data+ "  "+rs.getString("opc_suffix_code"));//1			
list.add(rs.getString("rc_rank_name"));//2 RANK
list.add(rs.getString("opd_officer_name"));//3 NAME
list.add(rs.getString("upgradefrom"));//4 UPGRADATION FROM
list.add(rs.getString("upgradeto"));//5UPGRADATION TO

alist.add(list);
i++;

}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {

e.printStackTrace();
} finally {
if (conn != null) {
try {
conn.close();
} catch (SQLException e) {
}
}
}
return alist;
}




/////////////////UPGRADATION RESERVETOALMCISC  REPORT JAY
public ArrayList<ArrayList<String>> getUpgradationRepoerforRESERVETOALMCISC(int es_id ){


ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
Connection conn = null;
String q = "";
try {
conn = dataSource.getConnection();
PreparedStatement stmt = null;

q=" SELECT  ofa.es_id,vpd.opc_personal_code,vpd.opc_suffix_code,vpd.rc_rank_name,vpd.opd_officer_name,upgradefrom, upgradeto from (\n"
		+ "SELECT DISTINCT qof.oa_applicant_id, \n"
		+ "	\n"
		+ "	 string_agg(CASE WHEN qof.status_id = 2  \n"
		+ "		    THEN qof.nominatedfor  \n"
		+ "		  ELSE  ''\n"
		+ "		  end ,'') filter (where  1=1) as upgradefrom \n"
		+ "	 ,\n"
		+ "		  	 string_agg(CASE WHEN qof.status_id = 1  \n"
		+ "		    THEN qof.nominatedfor  \n"
		+ "		  ELSE  ''\n"
		+ "		  end ,'') filter (where  1=1) as upgradeto\n"
		+ "		  \n"
		+ "		  from (\n"
		+ "\n"
		+ "SELECT  a.oa_applicant_id from qualified_officers a\n"
		+ "  INNER JOIN qualified_officers b on a.oa_applicant_id = b.oa_applicant_id\n"
		+ "where  \n"
		+ " a.status_id = 1 \n"
		+ "  and b.status_id = 2\n"
		+ "	and	 \n"
		+ "			( b.course_id = 13 or  b.course_id = 8 or b.nominatedfor='ALMC Res'  or b.nominatedfor='ISC Res')\n"
		+ "	 \n"
		+ "		  \n"
		+ "		  ) as oai\n"
		+ "	\n"
		+ "inner join qualified_officers qof on oai.oa_applicant_id = qof.oa_applicant_id\n"
		+ "	\n"
		+ "GROUP by  qof.oa_applicant_id\n"
		+ ") as d\n"
		+ "\n"
		+ "inner join officer_application ofa on ofa.oa_application_id= d.oa_applicant_id\n"
		+ "inner join  vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
		+ "\n"
		+ "where  ofa.es_id=?\n"
		+ "";

//

stmt = conn.prepareStatement(q);
stmt.setInt(1, es_id);
//stmt.setInt(2, Integer.parseInt(course_id));

System.err.println("UPGRADATION REport===="+stmt);
ResultSet rs = stmt.executeQuery();
int i=1;
//double  total= 0;
int  total= 0;
double  carear= 0;
double  carear_300= 0;
DecimalFormat df_double = new DecimalFormat("0.00");
while (rs.next()) {
ArrayList<String> list = new ArrayList<String>();
list.add(String.valueOf(i));//0
String Data=rs.getString("opc_personal_code");
String DataPre="";
String DataM="";
if(Data.contains("NTR") || Data.contains("NTS")) {
	DataPre= Data.substring(0,3);
	DataM = Data.substring(4);
}else {
	DataPre= Data.substring(0,2);
	DataM = Data.substring(3);
}

Data=DataPre+DataM;
list.add(Data+ "  "+rs.getString("opc_suffix_code"));//1			
list.add(rs.getString("rc_rank_name"));//2 RANK
list.add(rs.getString("opd_officer_name"));//3 NAME
list.add(rs.getString("upgradefrom"));//4 UPGRADATION FROM
list.add(rs.getString("upgradeto"));//5UPGRADATION TO

alist.add(list);
i++;

}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {

e.printStackTrace();
} finally {
if (conn != null) {
try {
conn.close();
} catch (SQLException e) {
}
}
}
return alist;
}






/////////////////WITHDRAWAL REPORTFRO NOMINATION REPORT JAY
public ArrayList<ArrayList<String>> getUpgradationRepoerforWITHDRAWALFORNOMINATION(int es_id){


ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
Connection conn = null;
String q = "";
try {
conn = dataSource.getConnection();
PreparedStatement stmt = null;

q="select vpd.opc_personal_code,vpd.opc_suffix_code,vpd.rc_rank_name,vpd.opd_officer_name,vpd.ac_arm_description,res.reason_name\n"
		+ "from qualified_officers qo\n"
		+ "inner join officer_application ofa on ofa.oa_application_id=qo.oa_applicant_id\n"
		+ "inner join vw_personal_details vpd on vpd.opd_personal_id=ofa.opd_personal_id\n"
		+ "inner join reason_mst res on res.id::text = qo.reason\n"
		+ "where status_id='6' and ofa.es_id=?";

//

stmt = conn.prepareStatement(q);
stmt.setInt(1, es_id);
//stmt.setInt(2, Integer.parseInt(course_id));

System.err.println("UPGRADATION REport===="+stmt);
ResultSet rs = stmt.executeQuery();
int i=1;
//double  total= 0;
int  total= 0;
double  carear= 0;
double  carear_300= 0;
DecimalFormat df_double = new DecimalFormat("0.00");
while (rs.next()) {
ArrayList<String> list = new ArrayList<String>();
//list.add(String.valueOf(i));//0
String Data=rs.getString("opc_personal_code");
String DataPre="";
String DataM="";
if(Data.contains("NTR") || Data.contains("NTS")) {
	DataPre= Data.substring(0,3);
	DataM = Data.substring(4);
}else {
	DataPre= Data.substring(0,2);
	DataM = Data.substring(3);
}

Data=DataPre+DataM;
list.add(Data+ "  "+rs.getString("opc_suffix_code"));//1		
list.add(rs.getString("rc_rank_name"));//2 
list.add(rs.getString("opd_officer_name"));//2 
list.add(rs.getString("ac_arm_description"));//3 
list.add(rs.getString("reason_name"));//4 

alist.add(list);
i++;

}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {

e.printStackTrace();
} finally {
if (conn != null) {
try {
conn.close();
} catch (SQLException e) {
}
}
}
return alist;
}





public ArrayList<ArrayList<String>> getALMC_ISCmeritlistReport(int es_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	try {
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
		q="select vpd.opc_personal_code,vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name,vpd.ac_arm_description,\n"
				+ "vpd.opd_unit  from qualified_officers qua \n"
				+ "inner join officer_application ofa on qua.oa_applicant_id=ofa.oa_application_id\n"
				+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
				+ "inner join vw_personal_details vpd on ofa.opd_personal_id = vpd.opd_personal_id\n"
				+ "where ofa.es_id=? and ( qua.nominatedfor='ALMC' or qua.nominatedfor='ISC' or qua.nominatedfor='ALMC Res' or qua.nominatedfor='ISC Res' )";
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);
		System.err.println("ALMC===="+stmt);
		ResultSet rs = stmt.executeQuery();
int i=1;
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			
			Data=DataPre+DataM;
			list.add(String.valueOf(i));
			list.add(Data+ "  " +rs.getString("opc_suffix_code"));
			list.add(rs.getString("rc_rank_name"));
			list.add(rs.getString("opd_officer_name"));
			list.add(rs.getString("opd_unit"));
			alist.add(list);
			i++;
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}
public String Choice(String ch)
{
if ( ch==null) {
ch="NA";
}
else if ( ch.equals("DSSC")) {
ch="D";
}
else if ( ch.equals("DSTSC")) {
ch="T";
}
else if ( ch.equals("ALMC")) {
ch="A";
}
else if ( ch.equals("ISC")) {
ch= "I";
}

return ch;
}	

public String nominatedfor(String nominatedfor)
{

	if (nominatedfor == null) {
		nominatedfor = "";
	}
	if (nominatedfor.equals("ALMC") || nominatedfor.equals("ISC") || nominatedfor.equals("ALMC Res")
			|| nominatedfor.equals("ISC Res")) {
		nominatedfor = "S";
	} else if (nominatedfor.equals("Fail")) {
		nominatedfor = "F";
	} else if (nominatedfor.equals("DSSC")) {
		nominatedfor = "D";
	} else if (nominatedfor.equals("DSTSC")) {
		nominatedfor = "T";
	} else if (nominatedfor.equals("COMPETITIVE")) {
		nominatedfor = "C";
	} else if (nominatedfor.equals("DSSC Res") || nominatedfor.equals("DSTSC Res")) {
		nominatedfor = "R";
	}  
	return nominatedfor;
}

}
