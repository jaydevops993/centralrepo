package com.BisagN.dao.officer.course;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Service
public class CourseDaoImpl implements CourseDao {
	
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;
	public ArrayList<ArrayList<String>> getPersDetailForCPSCCourse(int opd_persid) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();

		Connection conn = null;
		String q = "";
		String qry = "";

		try {
			
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			
		q="select count(*) as dssc_count,ofa.oa_application_id from officer_application ofa\n"
				+ "left join exam_schedule es on es.es_id = ofa.es_id\n"
				+ "where opd_personal_id=? and es.ec_exam_id=3 group by 2 ";

			stmt = conn.prepareStatement(q);
			stmt.setInt(1, opd_persid);
			System.err.println("course==========="+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();

				list.add(rs.getString("dssc_count"));// 0
				list.add(rs.getString("oa_application_id"));// 0
			
				
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;

	}
}
