package com.BisagN.models.officers.merit;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "dssc_merit_result_gen_tbl", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})
public class DSSC_MERIT_RESULT_GEN_TBL {
	
	private int id;
	private int course_id;
private String sub_course;
	private int total_vacancy;
	private String division;
	private int priority_merit;
	private int priority_result;
	private String type;
	private String created_by;
	private Date created_date;
	private int es_id;
	
	@Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCourse_id() {
		return course_id;
	}
	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}
	public String getSub_course() {
		return sub_course;
	}
	public void setSub_course(String sub_course) {
		this.sub_course = sub_course;
	}
	public int getTotal_vacancy() {
		return total_vacancy;
	}
	public void setTotal_vacancy(int total_vacancy) {
		this.total_vacancy = total_vacancy;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public int getPriority_merit() {
		return priority_merit;
	}
	public void setPriority_merit(int priority_merit) {
		this.priority_merit = priority_merit;
	}
	public int getPriority_result() {
		return priority_result;
	}
	public void setPriority_result(int priority_result) {
		this.priority_result = priority_result;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public int getEs_id() {
		return es_id;
	}
	public void setEs_id(int es_id) {
		this.es_id = es_id;
	}
	
	
	
	
	     
}
