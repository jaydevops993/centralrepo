package com.BisagN.dao.officer.trans;

import java.util.List;
import java.util.Map;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import org.apache.commons.codec.binary.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import org.hibernate.Session;
import java.util.ArrayList;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;


public interface Dssc_compens_chanceDAO {

public List<Map<String, Object>> getReportListDssc_compens_chance(int startPage,String pageLength,String Search,String orderColunm,String orderType,String pers_no, String pers_name,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
public long getReportListDssc_compens_chanceTotalCount(String Search,String pers_no, String pers_name);
public String Deletedssc_compens_chance(String deleteid,HttpSession session);
public ArrayList<ArrayList<String>> getAllData(String adv_detail);
public ArrayList<ArrayList<String>> getjc_courseAllData(String adv_detail);
public List<Map<String, Object>> getPersDataForDssc(String perscode,int es_id);
public ArrayList<ArrayList<String>> getAllDataforDsscCompChance(String pers_id);
public ArrayList<ArrayList<String>> getDsscCountDetailsForOfficer(String pers_id);
}
