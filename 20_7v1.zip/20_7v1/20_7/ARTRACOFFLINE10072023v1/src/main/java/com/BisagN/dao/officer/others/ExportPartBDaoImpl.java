package com.BisagN.dao.officer.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Service
public class ExportPartBDaoImpl implements ExportPartBDao {

	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

CommonController comm= new CommonController();


@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

public boolean checkIsIntegerValue(String Search) {
	
return Search.matches("[0-9]+");
}



public ArrayList<ArrayList<String>> getbegindateforexport(String exm_id) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	String whr = "";

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

//		q="select es.es_id as id, TO_CHAR( es.es_begin_date,'DD/MM/YYYY') as  es_begin_date,es.es_status_id from exam_schedule es \n"
//				+ "where es.ec_exam_id=? and es.es_status_id='1' ";
	
		
		q="select es.es_id as id, TO_CHAR( es.es_begin_date,'DD/MM/YYYY') as  es_begin_date,es.es_status_id from exam_schedule es \n"
				+ "inner join exam_code ex on ex.ec_exam_id=es.ec_exam_id where ex.ec_exam_name=? and es.es_status_id='1' ";
		
		stmt = conn.prepareStatement(q);
		int i=0;
	
		stmt.setString(1, exm_id);
		System.err.println("stmt==========="+stmt);
		ResultSet rs = stmt.executeQuery();
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("es_begin_date"));//1
			list.add(rs.getString("id"));//1
			list.add(rs.getString("es_status_id"));//1
			
			if(rs.getString("es_status_id").equals("0")) {
				list.add("Lock");
			}else
			{
				list.add("UnLock");
				
			}
			
			
			alist.add(list);
			
			
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

public ArrayList<ArrayList<String>> getexportPartBexmCandidateReport(int startPage, String pageLength, String Search,
		String orderColunm, String orderType, String exam_schedule_dt2, String min_year2,String es_consider_date1,int es_id,String table,String btn_value, String max_year2,HttpSession session)
		throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
		InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	if (pageLength.equals("-1")) {
		pageLength = "ALL";
	}
	String SearchValue = GenerateQueryWhereClause_SQL(Search);
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String q1 = "";
	String q2 = "";
	
	if(!es_consider_date1.equals(null))	{
	if(es_consider_date1.equals("opd_date_of_seniority")) {
		
		q1= "opd_date_of_seniority";
	}
	if(es_consider_date1.equals("opd_date_of_comm")) {
		q1="opd_date_of_comm";
	}
	}
	if(btn_value.equals("APPLNS YET TO BE GENERATED")) {
		
		q2="and ofa.oa_application_id is  null";
	}
	
	
	System.err.println("max_year2-------------"+max_year2);
	
	try {
		conn = dataSource.getConnection();
		
		
		
		q="SELECT ROW_NUMBER() OVER(order by vw.opd_personal_id) as sr_no, ofa.oa_application_id,  \n" + 
				"vw.opc_personal_code,vw.opc_suffix_code, vw.opd_officer_name,vw.ac_arm_description,TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob,"
				+ "TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm ,vw.ct_comm_type,"
				+ " vw.rc_rank_name, TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority ,"
				+ " getSubjectNameFromCode(vw.pbda_sub_code,1) as sunma,vw.pbda_sub_code,"
				+ " vw.cc_command_name,vw.opd_personal_id,\n" + 
				"\n" + 
				"date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) as total_service,\n" + 
				"\n" + 
				"vw.opc_suffix_code,vw.opd_unit,\n" + 
				"vw.ac_arm_code,\n" + 
				"a.subcode\n" + 
				"from vw_personal_details vw	"
				+ "left join officer_application ofa on ofa.opd_personal_id = vw.opd_personal_id  and ofa.es_id="+es_id+"	\n" + 
				"		inner join (select distinct string_agg(sc.sc_subject_code::text,',')  as subcode,sum(sc.sc_subject_code) as sub_sum,sct.arm_id,sc.ec_exam_id from subject_code sc\n" + 
				"				inner join subject_code_child_tbl sct on sc.sc_subject_id=sct.sub_id\n" + 
				"					group by 3,4) as a on a.arm_id=vw.ac_arm_id and a.ec_exam_id=1\n"
				+ "where  vw.opd_partb='0' and vw.opd_status_id='1' and vw.opd_isactive='yes' \n" + 
				"		and  date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) >= "+min_year2+" and   date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) <= "+max_year2+" "+q2+" "+SearchValue+"   \n"
						+ "ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage;
		


		
		
		
		
		PreparedStatement stmt = conn.prepareStatement(q);

		stmt = setQueryWhereClause_SQL(stmt, Search);

		System.err.println("stmt========bbbb======"+stmt);

		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("sr_no"));//0
			
			String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
    		String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));
			list.add( opc_code);

//			list.add(rs.getString("opc_personal_code"));
			list.add(rs.getString("opd_officer_name"));//2
			list.add(rs.getString("ac_arm_description"));//3
			list.add(rs.getString("opd_dob"));//4	
			list.add(rs.getString("opd_date_of_comm"));//5	
			list.add(rs.getString("ct_comm_type"));//6
			list.add(rs.getString("rc_rank_name"));//7		
			
			list.add(rs.getString("opd_date_of_seniority"));//8
			
			
			StringBuilder input1 = new StringBuilder();
			input1.append(rs.getString("sunma"));
			input1.reverse();
			list.add(input1.toString());
			
			System.err.println("table-----------"+table);
			if(!table.equals("excelL")) {
			list.add(rs.getString("pbda_sub_code"));//10
			list.add(rs.getString("opc_personal_code"));
			}
		
			list.add(rs.getString("oa_application_id"));//10	
			
			alist.add(list);
//			System.err.println("list---------"+list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

public long getexportPartbexmCandidatereportTotalCount(String Search, String exam_schedule_dt2,String min_year2,String es_consider_date1,int es_id,String btn_value,String max_year2) {
String SearchValue = GenerateQueryWhereClause_SQL(Search);
int total = 0;
String q = null;
Connection conn = null;
try {
	String q1 = "";
	String q2 = "";
	
	
	System.err.println("es_consider_date1============="+es_consider_date1);
	
if(!es_consider_date1.equals(null))	{
if(es_consider_date1.equals("opd_date_of_seniority")) {
		
		q1= "opd_date_of_seniority";
	}
	if(es_consider_date1.equals("opd_date_of_comm")) {
		q1="opd_date_of_comm";
	}
}
	if(btn_value.equals("APPLNS YET TO BE GENERATED")) {
		
		q2="and ofa.oa_application_id is  null";
	}
	System.err.println("btn_value=============="+btn_value);
	
	conn = dataSource.getConnection();
	q ="select count(*) from (SELECT ROW_NUMBER() OVER(order by vw.opd_personal_id) as sr_no, ofa.oa_application_id, \n"
			+ "vw.opd_officer_name,vw.opc_suffix_code,vw.cc_command_name,vw.opd_personal_id,\n"
			+ "TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority ,\n"
			+ "date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) as total_service,\n"
			+ "TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm ,\n"
			+ "vw.opc_suffix_code,vw.opd_unit,vw.opc_personal_code,\n"
			+ "vw.ac_arm_code,vw.ac_arm_description,\n"
			+ "TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob,vw.ct_comm_type,vw.rc_rank_name,getSubjectNameFromCode(vw.pbda_sub_code,1) as sunma,vw.pbda_sub_code,a.subcode\n"
			+ "from vw_personal_details vw	"
			+ "left join officer_application ofa on ofa.opd_personal_id = vw.opd_personal_id and ofa.es_id="+es_id+"	\n"
			+ "		inner join (select distinct string_agg(sc.sc_subject_code::text,',')  as subcode,sum(sc.sc_subject_code) as sub_sum,sct.arm_id,sc.ec_exam_id from subject_code sc\n"
			+ "				inner join subject_code_child_tbl sct on sc.sc_subject_id=sct.sub_id\n"
			+ "					group by 3,4) as a on a.arm_id=vw.ac_arm_id and a.ec_exam_id=1\n"
//			+ "		left join officer_application ofa on ofa.opd_personal_id = vw.opd_personal_id and ofa.oa_status_id='1'"
			
			+ "		where  vw.opd_partb='0' and vw.opd_status_id='1' and vw.opd_isactive='yes'\n"
			+ "		and  date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) >= "+min_year2+" and  date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) <= "+max_year2+" "+q2+") ab "+SearchValue ;
	PreparedStatement stmt = conn.prepareStatement(q);
	stmt = setQueryWhereClause_SQL(stmt,Search);
	System.out.println("stmt===gggg===="+stmt);
	ResultSet rs = stmt.executeQuery();
	while (rs.next()) {
		total = rs.getInt(1);
	}
	rs.close();
	stmt.close();
	conn.close();
} catch (SQLException e) {
	e.printStackTrace();
} finally {
	if (conn != null) {
		try {
			conn.close();
		} catch (SQLException e) {
		}
	}
}
return (long) total;
}


public String GenerateQueryWhereClause_SQL(String Search) {
String SearchValue ="";
if(!Search.equals("")) {
Search = Search.toLowerCase();
	SearchValue =" and ( ";


	SearchValue +=" lower(opd_unit) like ? or"
		+" lower(opc_personal_code) like ? or "
			+ "lower(opd_officer_name) like ? or to_char(opd_date_of_seniority,'dd-MM-yyyy') like ? or  "
			+ " lower(ac_arm_description) like ? )";
}
return SearchValue;

}


public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search) {
int flag = 0;
try {
if(!Search.equals("")) {
		
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
		Search=comm.getSearchIcNumberwithoutZero(Search);
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
	
		
	}
}catch (Exception e) {}
return stmt;
}

public ArrayList<ArrayList<String>> getRulesDetailsFromExmSchedule(String exmsch_dt, String exm_id, String dssc_date) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String q1 = "";
	System.err.println("dssc_date========="+dssc_date);
	
	try {
		
		System.err.println(exmsch_dt);
		System.err.println(exm_id);
		

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		if(exm_id.equals("1")) {
			
			q1+=" date_part('year',age('"+exmsch_dt+"',es_to_year)) as rule_year";
		}
		
		if(exm_id.equals("2")) {
			q1+=" date_part('year',age('"+exmsch_dt+"',es_to_year)) as rule_year";
		}
		
       if(exm_id.equals("3")) {
			
			q1+=" date_part('year',age('"+dssc_date+"',es_to_year)) as rule_year";
		}
		
		q="select es_consider_date, "+q1+",es_max_year,es_part_b,es_dssc_month,es_dssc_check_year,es_part_b,es_part_d,es_dssc_chance from exam_schedule where ec_exam_id= ? and es_begin_date='"+exmsch_dt+"'";
		
		stmt = conn.prepareStatement(q);
	
		
		stmt.setInt(1, Integer.parseInt (exm_id));
		
		System.err.println("schhhhh==============="+stmt);
		ResultSet rs = stmt.executeQuery();
		
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("es_consider_date"));//1
			list.add(rs.getString("rule_year"));//1
			list.add(rs.getString("es_max_year"));//1
			list.add(rs.getString("es_part_b"));//1
			list.add(rs.getString("es_dssc_month"));//1
			
			String es_dssc_check_year= rs.getString("es_dssc_check_year");
			System.err.println("es_dssc_check_year==========="+es_dssc_check_year);
			
			list.add(rs.getString("es_dssc_check_year"));//1
		
			list.add(rs.getString("es_part_b"));//1
			list.add(rs.getString("es_part_d"));//1
			list.add(rs.getString("es_dssc_chance"));//1
			
			alist.add(list);
			
			
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}


public ArrayList<ArrayList<String>> getExportPartBForExcel(int es_id) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	String whr = "";

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
	
		
		q="select DISTINCT ROW_NUMBER() OVER(order by vpd.opd_personal_id) as sr_no, vpd.opc_personal_code, vpd.opc_suffix_code, vpd.opd_officer_name, vpd.ac_arm_description,TO_CHAR(vpd.opd_dob,'DD/MM/YYYY') as opd_dob,\n"
				+ "TO_CHAR(vpd.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm,\n"
				+ "TO_CHAR(vpd.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority,\n"
				+ "vpd.rc_rank_name, vpd.ct_comm_type,\n"
				+ " getSubjectNameFromCode(vpd.pbda_sub_code,1) as sunma,vpd.pbda_sub_code,\n"
				+ " ofa.oa_application_id\n"
				+ "\n"
				+ "from officer_application ofa \n"
				+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
				+ "inner join partb_d_application pbd on pbd.oa_application_id = ofa.oa_application_id\n"
				+ "where es_id=? and ofa.oa_status_id=1 and vpd.opd_status_id=1 and vpd.opd_isactive='yes' and vpd.opd_partb = 0";
		
		stmt = conn.prepareStatement(q);
		int i=0;
	
		stmt.setInt(1, es_id);
		System.err.println("stmt==========="+stmt);
		ResultSet rs = stmt.executeQuery();
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("sr_no"));//0
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			
			Data=DataPre+DataM;
			
			list.add(Data+(rs.getString("opc_suffix_code")));
			list.add(rs.getString("opd_officer_name"));//2
			list.add(rs.getString("ac_arm_description"));//3
			list.add(rs.getString("opd_dob"));//4	
			list.add(rs.getString("opd_date_of_comm"));//5	
			list.add(rs.getString("ct_comm_type"));//6
			list.add(rs.getString("rc_rank_name"));//7		
			
			list.add(rs.getString("opd_date_of_seniority"));//8
			
			
			StringBuilder input1 = new StringBuilder();
			input1.append(rs.getString("sunma"));
			input1.reverse();
			list.add(input1.toString());
			

			list.add(rs.getString("oa_application_id"));//10	
			
			alist.add(list);
			
			
			
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}
}
