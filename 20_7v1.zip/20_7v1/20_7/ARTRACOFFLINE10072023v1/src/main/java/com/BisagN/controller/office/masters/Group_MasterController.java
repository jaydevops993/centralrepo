package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.Group_MasterDAO;
import com.BisagN.models.officers.masters.GROUP_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Group_MasterController {
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private Group_MasterDAO objDAO;
	
	  @Autowired
		private RoleBaseMenuDAO roledao;  
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	//===========================OPEN PAGE============================//
		@RequestMapping(value = "GroupMasterUrl", method = RequestMethod.GET)
		public ModelAndView GroupMasterUrl(ModelMap Mmap, HttpSession session,HttpServletRequest request,
				@RequestParam(value = "msg", required = false) String msg)
				throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
				NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
			
			if(request.getHeader("Referer") == null ) { 
   			 session.invalidate();
   			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
   			 return new ModelAndView("redirect:/login");
   		 }

       	 String roleid1 = session.getAttribute("roleid").toString();
   		 Boolean val = roledao.ScreenRedirect("GroupMasterUrl", roleid1);		
   			if(val == false) {
   				return new ModelAndView("AccessTiles");
   		}	

			Mmap.put("msg", msg);
			return new ModelAndView("GroupMasterTiles","GroupMstCMD", new GROUP_M());
		}
		
		//============================SAVE==========================//
		  
		  @RequestMapping(value = "/GroupMasterAction" ,method = RequestMethod.POST) 
		  public ModelAndView GroupMasterAction( @ModelAttribute("GroupMstCMD") GROUP_M ln, BindingResult result, 
		  HttpServletRequest request, ModelMap model, HttpSession session){ 
			  
//				int errCount = 0;
//
//				if (request.getParameter("gm_groupname").equals("") || request.getParameter("gm_groupname") == null) {
//					errCount++;
//					model.put("gm_groupname_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Choice Name");
//				}
//				if (errCount > 0) {
//
//					return new ModelAndView("GroupMasterTiles");
//				}

			  
			  String gm_groupname=request.getParameter("gm_groupname");
				if(gm_groupname == "" || gm_groupname.equals("")) {
					model.put("msg", "Please Enter Group Name");		
					return new ModelAndView("redirect:GroupMasterUrl");
				}
			  
				int id = ln.getGm_ngroupid() > 0 ? ln.getGm_ngroupid() : 0;
				
				//System.err.println("id================"+id);
				Date date = new Date();
				String username = session.getAttribute("username").toString();
				Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction(); 

			try {

				Query q0 = sessionHQL.createQuery("select count(gm_ngroupid) from GROUP_M where LOWER(gm_groupname)=:gm_groupname and gm_ngroupid!=:gm_ngroupid");
//																								and area_type_id!=:id

				q0.setParameter("gm_groupname", ln.getGm_groupname().toLowerCase());
				q0.setParameter("gm_ngroupid", id);
				Long c = (Long) q0.uniqueResult();

				
				if (id == 0) {
					
				
					ln.setCreated_by(username);
					ln.setCreated_date(date);
					ln.setGm_role_flag("1");
					
					if (c == 0) {

						sessionHQL.save(ln);
						sessionHQL.flush();
						sessionHQL.clear();
						model.put("msg", "Data Saved Successfully.");

					} else {
						model.put("msg", "Data already Exist.");
					}
				}

			
				tx.commit();
			} catch (RuntimeException e) {
				try {
					tx.rollback();
					model.put("msg", "roll back transaction");
				} catch (RuntimeException rbe) {
					model.put("msg", "Couldn�t roll back transaction " + rbe);
				}
				throw e;
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}

			return new ModelAndView("redirect:GroupMasterUrl");
		}
		
		  
		//=======================SEARCH============================//
		  
		  @RequestMapping(value = "/getGroup_MasterReportDataList", method = RequestMethod.POST)
			 public @ResponseBody List<Map<String, Object>> getGroup_MasterReportDataList(int startPage,
					 String pageLength,String Search,String orderColunm,String orderType,HttpSession sessionUserId) 
				     throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, 
				     InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
				
			  return objDAO.getReportListGroup_Master(startPage,pageLength,Search,orderColunm,orderType,sessionUserId);
			}

			 
			 @RequestMapping(value = "/getGroup_MasterTotalCount", method = RequestMethod.POST)
			public @ResponseBody long getGroup_MasterTotalCount(HttpSession sessionUserId,String Search,String name){
				 
				return objDAO.getReportListGroup_MasterTotalCount(Search);
			}
			 
			 //=============================EDIT OPEN PAGE=============================//
			 
	         @RequestMapping(value = "EditGroupMasterUrl", method = RequestMethod.POST)
	         public ModelAndView EditGroupMasterUrl(ModelMap Mmap,HttpSession session,
	        		 @RequestParam(value = "msg", required = false) String msg,String updateid) {

	                Session s1 = this.sessionFactory.openSession();
	                Transaction tx = s1.beginTransaction();
	                
	                String enckey = "commonPwdEncKeys";  
	                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
	                
	                
	                Query q = null;
	                q = s1.createQuery("from GROUP_M where cast(gm_ngroupid as string)=:PK");
	                q.setString("PK", DcryptedPk);
	                
	                @SuppressWarnings("unchecked")
	                List<String> list = (List<String>) q.list();
	                tx.commit();
	                s1.close();
	              
	                Mmap.put("EditGroupMstCMD1", list.get(0));
	                Mmap.put("msg", msg);
	                
	         return new ModelAndView("EditGroupMasterTiles","EditGroupMstCMD",new GROUP_M());
	}
			 
	         
//	       //============================UPDATE========================//
	         @RequestMapping(value = "/EditGroupMasterAction" ,method = RequestMethod.POST) 
	   	  public ModelAndView EditGroupMasterAction( @ModelAttribute("EditGroupMstCMD") GROUP_M ln, BindingResult result, 
	   	  HttpServletRequest request, ModelMap model, HttpSession session){ 

	        	 
//	        	 int errCount = 0;
//
//					if (request.getParameter("gm_groupname").equals("") || request.getParameter("gm_groupname") == null) {
//						errCount++;
//						model.put("gm_groupname_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Choice Name");
//					}
//					if (errCount > 0) {
//
//						return new ModelAndView("EditGroupMasterTiles");
//					}
	        	 
	        	 
	        	  String gm_groupname=request.getParameter("gm_groupname");
					if(gm_groupname == "" || gm_groupname.equals("")) {
						model.put("msg", "Please Enter Group Name");		
						return new ModelAndView("redirect:GroupMasterUrl");
					}

	        	 
	        Date date = new Date();
	     	String username = session.getAttribute("username").toString();
	   	    Session sessionHQL = this.sessionFactory.openSession();
	   	    Transaction tx = sessionHQL.beginTransaction(); 
	   	    
	   	    ln.setGm_ngroupid(Integer.parseInt(request.getParameter("id")));
	   	 ln.setGm_role_flag("1");
	   	    sessionHQL.saveOrUpdate(ln); 
	   	    ln.setModified_by(username);
			ln.setModified_date(date);
			
	   	    tx.commit(); 
	   	    sessionHQL.close(); 
	   	 
	   	    model.put("msg","Data Updated Successfully"); 
	   	    return new ModelAndView("redirect:GroupMasterUrl"); 
	   	  } 
			 
			 //=======================DELETE===========================//
			 @RequestMapping(value = "/DeleteGroupMasterUrl", method = RequestMethod.POST) 
			  public ModelAndView DeleteGroupMasterUrl(String deleteid,HttpSession session,ModelMap model) { 
				 
			  	List<String> list = new ArrayList<String>(); 
			  	list.add(objDAO.DeleteGroupMaster(deleteid,session)); 
			  	
			  	model.put("msg",list);  
			  	
			    return new ModelAndView("redirect:GroupMasterUrl"); 
			    
			  	}
}
