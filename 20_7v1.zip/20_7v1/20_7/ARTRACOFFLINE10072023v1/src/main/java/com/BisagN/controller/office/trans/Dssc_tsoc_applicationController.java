package com.BisagN.controller.office.trans;

import java.io.File;
import java.io.FileInputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.masters.Officer_personal_detailsController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.dao.officer.others.ExportPartBDao;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.trans.Dssc_tsoc_applicationDAO;
import com.BisagN.models.officers.masters.CHOICE_M;
import com.BisagN.models.officers.masters.COMMAND_CODE_M;
import com.BisagN.models.officers.masters.REGIMENT_M;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.trans.CPV;
import com.BisagN.models.officers.trans.DSCC_CHOICE_TBL;
import com.BisagN.models.officers.trans.DSSC_ADMIT_CARD_TBL;
import com.BisagN.models.officers.trans.DSSC_TSOC_APPLICATION_M;
import com.BisagN.models.officers.trans.EXAM_CENTER_CODE_M;



@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Dssc_tsoc_applicationController {

	@Autowired
	private Dssc_tsoc_applicationDAO objDAO;
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private PartB_ExaminationDAO partbDAO;

	
	CommonController comm = new CommonController();
	
	@Autowired
	Officer_personal_detailsController ofd= new Officer_personal_detailsController();
	
	
	@Autowired
	private ExportPartBDao export;

	@Autowired
	Officer_personal_detailsDAO ofcDao;
	
	@Autowired
	Dssc_tsoc_applicationDAO dsscDao;
	
	@RequestMapping(value = "Searchdssc_tsoc_applicationUrl", method = RequestMethod.GET)
	public ModelAndView Searchdssc_tsoc_applicationUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		 
		 	 
			String es_begindate = session.getAttribute("es_begin_date") == null ? "": session.getAttribute("es_begin_date").toString();		
			int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

			if (ec_exam_id == 3) {
				if (!es_begindate.equals("")) {
					Mmap.put("DSSC_begindate", es_begindate.substring(0, 10));
				}
				if (es_id != 0) {
					Mmap.put("es_id", es_id);
				}
				if (ec_exam_id != 0) {
					Mmap.put("ec_exam_id", ec_exam_id);
					 ArrayList<ArrayList<String>>list2= partbDAO.getdatafromExaminationCentre(3);
					   Mmap.put("getexamcentrelist",list2);
				}
			}
			 Mmap.put("msg",msg);
			 
		     Mmap.put("getctarmcodetypeListDDL",comm.getctarmcodetypeListDDL( sessionFactory));
		     
		return new ModelAndView("SearchDssc_tsoc_application_tile");
	}

	@RequestMapping(value = "/getDssc_tsoc_applicationReportDataList", method = RequestMethod.POST)
	public @ResponseBody ArrayList<ArrayList<String>> getDssc_tsoc_applicationReportDataList(int startPage, String pageLength,
			String Search, String orderColunm, String orderType, String pers_no, String pers_name, String center,
			String opd_arm_service,HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		
		int es_id = Integer
				.parseInt(sessionUserId.getAttribute("es_id") == null ? "0" : sessionUserId.getAttribute("es_id").toString());
		return dsscDao.getDSSCDSTSCexmApplicationReport(startPage, pageLength, Search, orderColunm, orderType, pers_no,
				pers_name, center, opd_arm_service, es_id, sessionUserId);
	}

	@RequestMapping(value = "/getDssc_tsoc_applicationTotalCount", method = RequestMethod.POST)
	public @ResponseBody long getDssc_tsoc_applicationTotalCount(HttpSession sessionUserId, String Search, String pers_no,
			String pers_name, String center, String opd_arm_service) {
		int es_id = Integer
				.parseInt(sessionUserId.getAttribute("es_id") == null ? "0" : sessionUserId.getAttribute("es_id").toString());
		return dsscDao.getDSSCDSTSCexmApplicationReportTotalCount(Search, pers_no, pers_name, center, opd_arm_service,
				es_id);
	}
	
	
	
	@RequestMapping(value = "/Dssc_applicationAction", method = RequestMethod.POST)
	public @ResponseBody String Dssc_applicationAction(
			@Valid @ModelAttribute("DsscCMD") DSSC_TSOC_APPLICATION_M dssc, BindingResult result,
			HttpServletRequest request, ModelMap model, HttpSession session) throws ParseException {
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		String save = "";
		try {
		String username = session.getAttribute("username").toString();
		
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		OFFICER_APPLICATION_M o_app1 = new OFFICER_APPLICATION_M();
		
		String course_applied_hid = request.getParameter("course_applied_hid");
		String opd_pers_code = request.getParameter("opd_personal_id");
		String id = request.getParameter("id");
		
		
		
		List<OFFICER_PERSONAL_CODE_M>getOpdId=comm.getopdIdbycode( sessionFactory, opd_pers_code);
		int opd_pers_id=getOpdId.get(0).getOpd_personal_id();
		
		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		
		String es_begindate = session.getAttribute("es_begin_date") == null ? ""
				: session.getAttribute("es_begin_date").toString();
		 if(!es_begindate.equals("")) {
			 int ec_exam_id = session.getAttribute("ec_exam_id") ==null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());	
			String exmsch_dt= es_begindate.substring(0, 10);
			String es_year1 = es_begindate.split("-")[0];
			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, es_id);
			Date dscc_schedule_dt =UnlcokExmsch.get(0).getEs_dssc_check_year();
		ArrayList<ArrayList<String>> list2 = export.getRulesDetailsFromExmSchedule(exmsch_dt, String.valueOf(ec_exam_id),dscc_schedule_dt.toString());
		
		String exam_schedule_dt =list2.get(0).get(0);
		String min_year=list2.get(0).get(1);
		ArrayList<ArrayList<String>>GetvalidManualData= dsscDao.getManualDSSCRulesappdetails( opd_pers_id,  exmsch_dt, exam_schedule_dt,  min_year,  dscc_schedule_dt.toString());
		
	if(!GetvalidManualData.isEmpty()) {
	
		
		Query q0 = sessionHQL.createQuery(
				"select count(*) from OFFICER_APPLICATION_M where (es_id=:es_id and opd_personal_id=:opd_personal_id) and oa_application_id!=:oa_application_id and oa_status_id=:oa_status_id");

		q0.setParameter("es_id", es_id);
		q0.setParameter("opd_personal_id", opd_pers_id);
		q0.setParameter("oa_application_id", Integer.parseInt(id));
		q0.setParameter("oa_status_id", 1);
		Long c = (Long) q0.uniqueResult();	
		
		if(Integer.parseInt(id) == 0) {
			
		if (c == 0) {
			
			List<Map<String, Object>>persDetails= ofcDao.getpersdetails(String.valueOf(opd_pers_id));
			String arm_code= (String) persDetails.get(0).get("ac_arm_description");
			String rank= (String) persDetails.get(0).get("rank");
			String doc= (String) persDetails.get(0).get("opd_date_of_comm");
			String dos= (String) persDetails.get(0).get("opd_date_of_seniority");
			String officer_name= (String) persDetails.get(0).get("opd_officer_name");
			String startDateString = "01/03/"+es_year1+"";
			 Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(startDateString);  
			 Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(doc); 
			String FdService= request.getParameter("dta_fd_days");
			
			long total_Service_days=comm.getDifferenceDays(date1, date2);
		
			long Fsp_mks= Integer.parseInt(FdService)*25/total_Service_days;
			if(Fsp_mks <= 25) {
				return "Your Fsp Marks Above 25 Marks";
			}else {
			
			
			
			
			
			String hql = "update OFFICER_PERSONAL_DETAILS_M set opd_unit_address1=:opd_unit_address1,opd_unit_address2=:opd_unit_address2, opd_unit=:opd_unit,cc_command_id=:cc_command_id where opd_personal_id=:opd_personal_id";
			Query query = sessionHQL.createQuery(hql)
					.setParameter("opd_unit_address1", request.getParameter("dta_address_corres1"))
					.setParameter("opd_unit_address2", request.getParameter("dta_address_coress2"))
					.setParameter("opd_unit", request.getParameter("present_unit"))
					.setParameter("cc_command_id", Integer.parseInt(request.getParameter("cc_command_id")))
					.setParameter("opd_personal_id", opd_pers_id);
			query.executeUpdate();
			
			
			

			
			
			DSSC_ADMIT_CARD_TBL admitcard= new DSSC_ADMIT_CARD_TBL();
			String partd_pass_year = request.getParameter("year_part_d");
			 admitcard.setEs_id(es_id);
			 admitcard.setOpd_personal_id(opd_pers_id);
			 admitcard.setCreated_by(username);
			 admitcard.setCreated_date(date);
			 admitcard.setOpd_partdpass_year(Integer.parseInt(partd_pass_year));
			 //admitcard.setAtt_no(Integer.parseInt(dssc_attmp));
			 admitcard.setOpd_arms(arm_code);
			 admitcard.setOpd_doc(comm.convertStringToDate(doc));
			 admitcard.setOpd_rank(rank);
			 admitcard.setOpd_off_name(officer_name);
			 admitcard.setOpd_dos(comm.convertStringToDate(dos));
		
			 String Admitcard_no="";
			 

			 Query q = null;
             q = sessionHQL.createQuery("from DSSC_ADMIT_CARD_TBL where  es_id=:es_id order by id desc ");
             q.setParameter("es_id", admitcard.getEs_id());
             @SuppressWarnings("unchecked")
             List<DSSC_ADMIT_CARD_TBL> list = (List<DSSC_ADMIT_CARD_TBL>) q.list();
             String admit_cardno=list.get(0).getAdmit_card_no();
            
			int admit= Integer.parseInt(admit_cardno.substring(8));
			 int  n_admit=admit+1;
			 Admitcard_no =es_year1+""+"0000"+n_admit+"";
			 
			 
				admitcard.setAdmit_card_no(Admitcard_no);
				sessionHQL.save(admitcard);
				
			
			
			OFFICER_APPLICATION_M o_app = new OFFICER_APPLICATION_M();
			String center = request.getParameter("center");
			o_app.setEs_id(es_id);
			o_app.setOpd_personal_id(opd_pers_id);
			o_app.setOa_created_by(username);
			o_app.setOa_creation_date(date);
			o_app.setOa_center_granted(Integer.parseInt(center));
			o_app.setOa_status_id(1);
			int ofr_app = (int) sessionHQL.save(o_app);
			sessionHQL.flush();
			sessionHQL.clear();
			tx.commit();
			
			
			Session sessionHQL1 = this.sessionFactory.openSession();
			Transaction tx1 = sessionHQL1.beginTransaction();
			dssc.setDta_created_by(username);
			dssc.setOa_application_id(ofr_app);
			
			String medical_category= "S"+request.getParameter("Md_Category_S") + "H"+request.getParameter("Md_Category_H")+
					"A"+request.getParameter("Md_Category_A")+"P"+request.getParameter("Md_Category_P")+"E" +request.getParameter("Md_Category_E");
			dssc.setDta_medical_cat(medical_category);
			dssc.setDta_regiment(request.getParameter("dta_regiment"));
			dssc.setDta_fd_days(Integer.parseInt(request.getParameter("dta_fd_days")));
			
			int dss_app = (int) sessionHQL.save(dssc);
			sessionHQL1.flush();
			sessionHQL1.clear();
			tx1.commit();
			
			DSCC_CHOICE_TBL dssc_choice = new DSCC_CHOICE_TBL();
			String course_app= request.getParameter("course_applied_hid");
			String mhid_val= request.getParameter("mhid_val");
			String vhid_val= request.getParameter("vhid_val");
		
			String[] mnamesList = mhid_val.split(",");
			int k=4;
			for(int i=0;i<mnamesList.length;i++) {
				Session sessionHQL4 = this.sessionFactory.openSession();
				Transaction tx4 = sessionHQL4.beginTransaction();
				String couse_id=mnamesList[i];
				if(couse_id.equals(request.getParameter("dta_course_pref"))){
					dssc_choice.setCourse_preference(1);
				}else {
					dssc_choice.setCourse_preference(2);
				}
				dssc_choice.setCourse_applied(Integer.parseInt(couse_id));
				dssc_choice.setCreated_by(username);
				dssc_choice.setCreated_Date(date);
				dssc_choice.setDscc_app_id(dss_app);
				dssc_choice.setEs_id(es_id);
				sessionHQL4.save(dssc_choice);
				sessionHQL4.flush();
				sessionHQL4.clear();
				tx4.commit();
			}
			String[] vnamesList = vhid_val.split(",");
			for(int i=0;i<vnamesList.length;i++) {
				Session sessionHQL4 = this.sessionFactory.openSession();
				Transaction tx4 = sessionHQL4.beginTransaction();
				String couse_id=vnamesList[i];
				if(couse_id.equals(request.getParameter("vdta_course_pref"))){
					dssc_choice.setCourse_preference(3);
				}else {
					dssc_choice.setCourse_preference(k);
					k++;
				}
				dssc_choice.setCourse_applied(Integer.parseInt(couse_id));
				dssc_choice.setCreated_by(username);
				dssc_choice.setCreated_Date(date);
				dssc_choice.setDscc_app_id(dss_app);
				dssc_choice.setEs_id(es_id);
				sessionHQL4.save(dssc_choice);
				sessionHQL4.flush();
				sessionHQL4.clear();
				tx4.commit();
			}
		CPV cpv = new CPV();
		Session sessionHQL5 = this.sessionFactory.openSession();
		Transaction tx5 = sessionHQL5.beginTransaction();
		
			
			cpv.setCreated_by(username);
			cpv.setCpv_mks(0);
			cpv.setFd_service_mks(Fsp_mks);
			cpv.setOpd_personal_id(opd_pers_id);
			cpv.setOa_application_id(ofr_app);
			cpv.setCreated_date(date);
			sessionHQL5.save(cpv);
			sessionHQL5.flush();
			sessionHQL5.clear();
			tx5.commit();
			}
			return "Data Saved Successfully.";
		}else {
			return "Application already generated";
		}

		}else {
			
		}
		
		 }else {
			 return "Rules not Matched With Your Application Data";
		 }

} }

catch (RuntimeException e) {
try {
	tx.rollback();
	model.put("msg", "roll back transaction");
} catch (RuntimeException rbe) {
	model.put("msg", "Couldn�t roll back transaction " + rbe);
}
throw e;
} finally {
if (sessionHQL != null) {
	sessionHQL.close();
}
}

return save;
}

	@RequestMapping(value = "EditDssc_tsoc_applicationUrl", method = RequestMethod.POST)
	public ModelAndView EditDssc_tsoc_applicationUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String updateid) {

		Session s1 = this.sessionFactory.openSession();
		Transaction tx = s1.beginTransaction();
		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);
		Query q = null;
		q = s1.createQuery("from DSSC_TSOC_APPLICATION_M where cast(id as string)=:PK");
		q.setString("PK", DcryptedPk);
		@SuppressWarnings("unchecked")
		List<DSSC_TSOC_APPLICATION_M> list = (List<DSSC_TSOC_APPLICATION_M>) q.list();
		tx.commit();
		s1.close();
		Mmap.put("Editdssc_tsoc_applicationCMD1", list.get(0));
		int oa_app_id= list.get(0).getOa_application_id();
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		
		List<OFFICER_APPLICATION_M>getopdid=comm.getOpdIdbyOappId(sessionFactory, oa_app_id, es_id);
		int opd_pers_id= getopdid.get(0).getOpd_personal_id();
		List<OFFICER_PERSONAL_CODE_M>getIcNumber=comm.getPersCodebyOpdID(sessionFactory, opd_pers_id);
		String ic_number= getIcNumber.get(0).getOpc_personal_code();
		Mmap.put("msg", msg);
		Mmap.put("ic_number", ic_number);
		Mmap.put("id", DcryptedPk);
		Mmap.put("DSSCUrl", "Editurl");
		Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
		Mmap.put("getRegimentListDDL", comm.getRegimentMstListDDL( sessionFactory));
		 Mmap.put("getChoicemstListDDL", comm.getChoicemstListDDL( sessionFactory));

		
		return new ModelAndView("Dssc_tsoc_application_tile");
	}

	@RequestMapping(value = "/Editdssc_tsoc_applicationAction", method = RequestMethod.POST)
	public ModelAndView Editdssc_tsoc_applicationAction(
			 @ModelAttribute("Editdssc_tsoc_applicationCMD") DSSC_TSOC_APPLICATION_M ln, BindingResult result,
			HttpServletRequest request, ModelMap model, HttpSession session) {

		int errCount = 0;


		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		ln.setId(Integer.parseInt(request.getParameter("id")));
		sessionHQL.saveOrUpdate(ln);
		tx.commit();
		sessionHQL.close();

		model.put("msg", "Data Updated Successfully");
		return new ModelAndView("redirect:Searchdssc_tsoc_applicationUrl");
	}


	  @RequestMapping(value = "Dssc_tsoc_ApplicationURL", method = RequestMethod.POST)
	  public ModelAndView Dssc_tsoc_ApplicationURL(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String Dssc_tsoc_Applicationid) {
		  String es_begindate = session.getAttribute("es_begin_date") == null ? "": session.getAttribute("es_begin_date").toString();		
			int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

			if (ec_exam_id == 3) {
				if (!es_begindate.equals("")) {
					Mmap.put("dssc_begindate", es_begindate.substring(0, 10));
				}
				if (es_id != 0) {
					Mmap.put("es_id", es_id);
				}
					Mmap.put("ec_exam_id", ec_exam_id);
					 ArrayList<ArrayList<String>>list2= partbDAO.getdatafromExaminationCentre(3);
					   Mmap.put("getexamcentrelist",list2);
				}
			
		 	
			Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
					
		     Mmap.put("getctarmcodetypeListDDL",comm.getctarmcodetypeListDDL( sessionFactory));
			 Mmap.put("getChoicemstListDDL", comm.getChoicemstListDDL( sessionFactory));
			 Mmap.put("getRegimentListDDL", comm.getRegimentMstListDDL( sessionFactory));
				Mmap.put("DSSCUrl", "Open"); 
			 Mmap.put("getCPSCmstListDDL", comm.getCPSCmstListDDL( sessionFactory));
			return new ModelAndView("Dssc_tsoc_application_tile", "dssc_tsoc_applicationCMD",
					new DSSC_TSOC_APPLICATION_M());
		}
	  
	  
	  
	  @RequestMapping(value = "UploadDssc_tsoc_ApplicationURL", method = RequestMethod.GET)
	  public ModelAndView UploadDssc_tsoc_ApplicationURL(ModelMap Mmap,HttpSession session, HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg,String Uploadssc_tsoc_Applicationid) {

		  Mmap.put("msg",msg);
		  Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
			if (flashMap != null) {
				ArrayList<ArrayList<String>> errorList = (ArrayList<ArrayList<String>>) flashMap.get("errorlist");
				// return "home";
				Mmap.put("errorList", errorList);
			}
			return new ModelAndView("Import_DsscOfficerData_tile");
		}
	 
	  
	// Download DEMO EXCEL
//		@RequestMapping(value = "/ExportDsscExcel", method = RequestMethod.POST)
//		public ModelAndView ExportDsscExcel(HttpServletRequest request, ModelMap model, HttpSession session, String typeReport1,
//				String exam_schedule_dt2, String min_year2, String es_consider_date3, String exam_schedule_dthid2,String max_year2)
//				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
//				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
//
//			int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
//			
//			if (es_id != 0) {
////		
//				ArrayList<ArrayList<String>> listexport=new ArrayList<ArrayList<String>>();
//				List<String> TH = new ArrayList<String>();
//			
//				
//				TH.add("S_No");
//				TH.add("Arms");
//			
//				TH.add("IC_NO");
//				TH.add("RANK");
//				TH.add("IndName");
//				TH.add("Unit");
//				TH.add("Loc_of_unit");
//				TH.add("Regt");
//				TH.add("Comd");
//				TH.add("Type_of_Entry");
//				TH.add("Date_of_commission");
//				TH.add("Date_of_Seniority");
//				TH.add("MedCat");
//				TH.add("CPSC");
//				TH.add("Course_applied_for");
//				TH.add("FirstChoice");
//				TH.add("SecondChoice");
//				TH.add("TECH_NON_TECH");
//				TH.add("Ist");
//				TH.add("second_nd");
//				TH.add("CC_Mandatory");
//				TH.add("Attempt");
//				TH.add("Exam_Centre_Allotted");
//				TH.add("M_TECH_YR");
//				TH.add("JC_COURSE");
//				TH.add("PhoneNo");
//				TH.add("FdDuration");
//				TH.add("dob");
//				TH.add("Ante_dt_sene");
//				TH.add("tors");
//				TH.add("appt");
//				TH.add("email");
//				TH.add("FIRST_ATTEMP_YR");
//				TH.add("SECOND_ATTEMP_YR");
//				TH.add("THIRD_ATTEMP_YR");
//				TH.add("yr_auth");
//				TH.add("yos");
//				TH.add("partD");
//				TH.add("partd_auth");
//				TH.add("Long_course");
//				
//				
//				
//				String Heading = "\n";
//				String username = session.getAttribute("username").toString();
//				return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList",listexport);
//			} else {
//				model.put("msg", "Data Not Available.");
//				return new ModelAndView("redirect:Searchdssc_tsoc_applicationUrl");
//			}
//		
//		}
		
		
		@RequestMapping(value = "/UploadDsscAppdataAction", method = RequestMethod.POST)
		public ModelAndView UploadDsscAppdataAction(HttpServletRequest request, ModelMap model, HttpSession session,
				@RequestParam(value = "fileUpload1", required = false) MultipartFile fileUpload,RedirectAttributes ra)
		{
			
			
			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			ArrayList<ArrayList<String>> listerror=new ArrayList<ArrayList<String>>();

////			if(fileUpload==null) {
////				 model.put("msg","Please Upload Copy Of File Upload");
////				  return new ModelAndView("redirect:IAST_CASEofficer_personal_detailsUrl");
////			  }
//			
////			if(fileUpload.isEmpty()) {
////				model.put("msg","Please Upload Copy Of File Upload");
////				  return new ModelAndView("redirect:IAST_CASEofficer_personal_detailsUrl");
////			}
//			
			try {

				
				Date date = new Date();
				String username = session.getAttribute("username").toString();

				DateFormat format = new SimpleDateFormat("dd/MM/yyyy");
				int es_id = Integer
						.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
				
				String es_begindate = session.getAttribute("es_begin_date") == null ? ""
						: session.getAttribute("es_begin_date").toString();
				
				int errorcount=0;
				int succeesscount=0;
				String errormsg= "";
				int count_duplicate=0;
				
				File file = new File(comm.fileupload2(fileUpload.getBytes(), fileUpload.getOriginalFilename(), "DSSC_DATA",""));
				FileInputStream fis = new FileInputStream(file);
				@SuppressWarnings("resource")
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				XSSFSheet sheet = wb.getSheetAt(0);
				Row row_head = sheet.getRow(0);
				
				
				String ser_no = "";
				String arm_service="";
				String personal_no = "";
				String suffixcode = "";
				String rank="";
				String officer_name="";
				String unit="";
				String Loc_of_Unit="";
				String Arms_Ser_No="";
				String Regt="";
				String Comd="";
				String Type_of_Entry="";
				String Date_of_Commission="";
				String CPSC="";
				String Date_of_Seniority="";
				String Course_applied="";
				String Med_Cat="";
				String First_Choice="";
				String Second_Choice="";
				String tech_nontech="";
				String Dt_of_Receipt="";
				String first_ALMC_ISC="";
				String second_ALMC_ISC="";
				String app_atmpt="";
				String Attempt="";
				String Centre_1="";
				String Centre_2="";
				String exmcntr_alct="";
				String m_tech_yr="";
				String JC_Course="";
				String Phone_No="";
				String EMail="";
				String Status="";
				String Remarks="";
				String Duration_Days="";
				String Duration_Months="";
				
			
				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
					Session sessionHQL12 = this.sessionFactory.openSession();
					Transaction tx12 = sessionHQL12.beginTransaction();
					ArrayList<String> listData = new ArrayList<String>();
					Row row = sheet.getRow(i);

					if(row == null) {
						break;
					}
					
					if (row.getCell(0) == null) {
						break;
					}
					
					for (int j = 1; j < 34; j++) {

						Cell cell = row.getCell(j);
						
						

						String value = "";
						switch (cell.getCellType()) {
						case Cell.CELL_TYPE_STRING:
							value = cell.getStringCellValue();
							break;
						case Cell.CELL_TYPE_NUMERIC:
							if (HSSFDateUtil.isCellDateFormatted(cell)) {
								value = String.valueOf(cell.getDateCellValue());
							} else {
								value = String.valueOf((long) cell.getNumericCellValue());
							}
							break;
						case Cell.CELL_TYPE_BOOLEAN:
							value = String.valueOf(cell.getBooleanCellValue());
							break;
						default:
						}
					
			
						
						if (row_head.getCell(j).getStringCellValue().equals("S No")) {
							ser_no=value;
						}
						if (row_head.getCell(j).getStringCellValue ().equals("Arms")) {
							arm_service=value;
							
						}
						if (row_head.getCell(j).getStringCellValue().equals("IC No")) {
							personal_no=value;
					     }
						
						if (row_head.getCell(j).getStringCellValue().equals("Rank")) {
							rank=value;
						}
						
						if (row_head.getCell(j).getStringCellValue().equals("Name")) {
							officer_name=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Unit")) {
							unit=value;
							
							
						}
						
						if (row_head.getCell(j).getStringCellValue().equals("Loc of Unit")) {
							Loc_of_Unit=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Arms Ser No")) {
							Arms_Ser_No=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Regt")) {
							Regt=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Comd")) {
							Comd=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Type of Entry")) {
							Type_of_Entry=value;
						}if (row_head.getCell(j).getStringCellValue().equals("Date of Commission")) {
							Date_of_Commission=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Date of Seniority")) {
							Date_of_Seniority=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Med Cat")) {
							Med_Cat=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("CPSC")) {
							CPSC=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Course applied for DSSC/DSTSC")) {
							Course_applied=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("First Choice")) {
							First_Choice=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Second Choice")) {
							Second_Choice=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Tech/Non Tech")) {
							tech_nontech=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Dt of Receipt")) {
							Dt_of_Receipt=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("1st ALMC/ISC")) {
							first_ALMC_ISC=value;
						}if (row_head.getCell(j).getStringCellValue().equals("2nd ALMC/ISC")) {
							second_ALMC_ISC=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Applied for CC/Mandatory Attempt")) {
							app_atmpt=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Attempt")) {
							Attempt=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Centre-1")) {
							Centre_1=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Centre-2")) {
							Centre_2=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Exam Centre Allotted")) {
							exmcntr_alct=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("M Tech Yr")) {
							m_tech_yr=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("JC Course")) {
							JC_Course=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Phone No")) {
							Phone_No=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("EMail")) {
							EMail=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Status")) {
							Status=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Remarks")) {
							Remarks=value;
						}
						if (row_head.getCell(j).getStringCellValue().equals("Fd Duration in Days")) {
							Duration_Days=value;
						}
						
						if (row_head.getCell(j).getStringCellValue().equals("Fd Duration in Months")) {
							Duration_Months=value;
						}
						
						
						
						
						
					}
					
//					String pers_code2 = personal_no.substring(0, personal_no.length() - 1);
					List<OFFICER_PERSONAL_CODE_M> opdpers_id= comm.getopdIdbycode( sessionFactory, personal_no);
					List<COMMAND_CODE_M>getCommandId=comm.getCommandbycommandname( sessionFactory, Comd);
					int command_id=getCommandId.get(0).getCc_command_id();
					if(opdpers_id.isEmpty()) {
						
						
						 listData.add(arm_service);
						 listData.add(personal_no);
						 
						 listData.add(rank);
						 listData.add(officer_name);
						 
						 listData.add(unit);
						 listData.add(Loc_of_Unit);
						 listData.add(Arms_Ser_No);
						 listData.add(Regt);
						 listData.add(Comd);
						 listData.add(Type_of_Entry);
						 listData.add(Date_of_Commission);
						 listData.add(Date_of_Seniority);
						 listData.add(Med_Cat);
						 listData.add(CPSC);
						 listData.add(Course_applied);
						 listData.add(First_Choice);
						 listData.add(Second_Choice);
						 listData.add(tech_nontech);
      					 listData.add(Dt_of_Receipt);
						 listData.add(first_ALMC_ISC);
						 listData.add(second_ALMC_ISC);
						 listData.add(app_atmpt);
						 listData.add(Attempt);
						 listData.add(Centre_1);
						 listData.add(Centre_2);
						 listData.add(exmcntr_alct);
						 listData.add(m_tech_yr); 
						 listData.add(JC_Course);
						 listData.add(Phone_No);
						 listData.add(EMail);
						 listData.add(Status);
						 listData.add(Remarks);
						 listData.add(Duration_Days);
						 listData.add(Duration_Months);
						 
						

							
							
							listData.add("The Personal Number is Wrong");
						 errormsg= personal_no +"The Personal Number is Wrong";
							model.put("msg",errormsg);
							errorcount++;
					}
					
					else {
					int opd_pers_id= opdpers_id.get(0).getOpd_personal_id();
					List<DSSC_ADMIT_CARD_TBL>admitCard=comm.getAdmitcardlistforopdId( sessionFactory, opd_pers_id);
					if(!admitCard.isEmpty()) {
						
						OFFICER_APPLICATION_M o_app1= new OFFICER_APPLICATION_M();
						
						int id = o_app1.getOa_application_id() > 0 ? o_app1.getOa_application_id() : 0;
					
						Query q0 = sessionHQL12.createQuery(
								"select count(*) from OFFICER_APPLICATION_M where (es_id=:es_id and opd_personal_id=:opd_personal_id) and oa_application_id!=:oa_application_id and oa_status_id=:oa_status_id");

						q0.setParameter("es_id", es_id);
						q0.setParameter("opd_personal_id", opd_pers_id);
						q0.setParameter("oa_application_id", id);
						q0.setParameter("oa_status_id", 1);
						Long c = (Long) q0.uniqueResult();

						if (id == 0) {

							if (c == 0) {
								
								List<REGIMENT_M>RegtId=comm.getRegimentIdMstListDDL(sessionFactory, Regt) ;
								int Regt_id=RegtId.get(0).getR_id();
								String es_year1 = es_begindate.split("-")[0];
          						String startDateString = "01/03/"+es_year1+"";
          						 Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(startDateString);  
          						 Date date1=new SimpleDateFormat("EE MMM dd HH:mm:ss z yyyy",Locale.ENGLISH).parse(Date_of_Commission); 
          					
          						long total_Service_days=comm.getDifferenceDays(date1, date2);
          						Double Fsp_mks=Double.valueOf(Integer.parseInt(Duration_Days)*30*25/total_Service_days);
          						 List<EXAM_CENTER_CODE_M>center_idList=comm.getexamcentreListbyCenterNameDDL( sessionFactory, exmcntr_alct);
                                 int center_id=center_idList.get(0).getEcc_center_code();
          						if(Fsp_mks <= 25) {
								
								

                				String hql = "update OFFICER_PERSONAL_DETAILS_M set opd_unit=:opd_unit,cc_command_id=:cc_command_id  where opd_personal_id=:opd_personal_id and  opd_status_id=1 ";
                				Query query = sessionHQL12.createQuery(hql).setParameter("opd_unit", unit)
                						.setParameter("cc_command_id", command_id)
                						.setParameter("opd_personal_id", opd_pers_id);
                				query.executeUpdate();
                				
                				
                				
//                				Query qry = sessionHQL.createQuery("update OFFICER_APPLICATION_M  set oa_center_granted=:oa_center_granted where opd_personal_id=:opd_personal_id and es_id=:es_id");
//            					qry.setParameter("oa_center_granted",center_id);
//            					qry.setParameter("opd_personal_id",opd_pers_id);
//            					qry.setParameter("es_id",es_id);
//            					qry.executeUpdate();
                				
								o_app1.setEs_id(es_id);
								o_app1.setOa_created_by(username);
                                o_app1.setOa_creation_date(date);
                                o_app1.setOpd_personal_id(opd_pers_id);
                                o_app1.setOa_status_id(1);
                                

                                
                               
                                o_app1.setOa_center_granted(center_id);
                                int mid = (int) sessionHQL12.save(o_app1);
                                
                                


                				
                				
                				
                				
                                sessionHQL12.flush();
                                sessionHQL12.clear();
            					tx12.commit();
            					
            					
            					DSSC_TSOC_APPLICATION_M dsccbexm = new DSSC_TSOC_APPLICATION_M();

            					Session sessionHQL1 = this.sessionFactory.openSession();
            					Transaction tx1 = sessionHQL1.beginTransaction();
            					dsccbexm.setOa_application_id(mid);
            					dsccbexm.setDta_regiment(String.valueOf(Regt_id));
            					dsccbexm.setDta_created_by(username);
            					dsccbexm.setDta_creation_date(date);
            					dsccbexm.setDta_medical_cat(Med_Cat);
            					dsccbexm.setDta_fd_days(Integer.parseInt(Duration_Days));
            					 int dssc_id = (int) sessionHQL1.save(dsccbexm);
            					sessionHQL1.flush();
            					sessionHQL1.clear();
            					tx1.commit();
            					
            					
            					DSCC_CHOICE_TBL dssc_choice = new DSCC_CHOICE_TBL();

            				
            					
            					
            				
            					if(Course_applied.equals("BOTH")) {
            						Session sessionHQL2 = this.sessionFactory.openSession();
                					Transaction tx2 = sessionHQL2.beginTransaction();
            						 List<CHOICE_M>F_getchoiceId=comm.getChoicemstIdByChoiceName(sessionFactory,First_Choice);
            						 int f_choice_id=F_getchoiceId.get(0).getId();
            						dssc_choice.setCourse_preference(1);
            						dssc_choice.setCourse_applied(f_choice_id);
                 					dssc_choice.setEs_id(es_id);
                 					dssc_choice.setCreated_by(username);
                 					dssc_choice.setCreated_Date(date);
                 					dssc_choice.setDscc_app_id(dssc_id);
                 					sessionHQL2.save(dssc_choice);
                 				
               					     tx2.commit();
               					 
               					     
               					     
               					  List<CHOICE_M>S_getchoiceId=comm.getChoicemstIdByChoiceName(sessionFactory,Second_Choice);
               					Session sessionHQL3 = this.sessionFactory.openSession();
            					Transaction tx3 = sessionHQL3.beginTransaction();
         						 int s_choice_id=S_getchoiceId.get(0).getId();
         						dssc_choice.setCourse_preference(2);
         						dssc_choice.setCourse_applied(s_choice_id);
              					dssc_choice.setEs_id(es_id);
              					dssc_choice.setCreated_by(username);
              					dssc_choice.setCreated_Date(date);
              					dssc_choice.setDscc_app_id(dssc_id);
              					sessionHQL3.save(dssc_choice);
              					
            					     tx3.commit();
            					   
            					}
            					
            					
            					if(Course_applied.equals("DSSC")) {
            						Session sessionHQL2 = this.sessionFactory.openSession();
                					Transaction tx2 = sessionHQL2.beginTransaction();
            						 List<CHOICE_M>F_getchoiceId=comm.getChoicemstIdByChoiceName(sessionFactory,First_Choice);
            						 int f_choice_id=F_getchoiceId.get(0).getId();
            						dssc_choice.setCourse_preference(1);
            						dssc_choice.setCourse_applied(f_choice_id);
                 					dssc_choice.setEs_id(es_id);
                 					dssc_choice.setCreated_by(username);
                 					dssc_choice.setCreated_Date(date);
                 					dssc_choice.setDscc_app_id(dssc_id);
                 					sessionHQL2.save(dssc_choice);
                 				
               					     tx2.commit();
               					 
               					     
               					     
               					  
            					}
            					
            					
            					if(Course_applied.equals("DSTSC")) {
            						Session sessionHQL2 = this.sessionFactory.openSession();
                					Transaction tx2 = sessionHQL2.beginTransaction();
            						 List<CHOICE_M>F_getchoiceId=comm.getChoicemstIdByChoiceName(sessionFactory,First_Choice);
            						 int f_choice_id=F_getchoiceId.get(0).getId();
            						dssc_choice.setCourse_preference(1);
            						dssc_choice.setCourse_applied(f_choice_id);
                 					dssc_choice.setEs_id(es_id);
                 					dssc_choice.setCreated_by(username);
                 					dssc_choice.setCreated_Date(date);
                 					dssc_choice.setDscc_app_id(dssc_id);
                 					sessionHQL2.save(dssc_choice);
                 				
               					     tx2.commit();
               					 
               					     
               					     
               					  
            					}
            				
            					  List<CHOICE_M>first_ALMC_ISC_getchoiceId=comm.getChoicemstIdByChoiceName(sessionFactory,first_ALMC_ISC);
            					  if(!first_ALMC_ISC_getchoiceId.isEmpty()) {
                 					Session sessionHQL4 = this.sessionFactory.openSession();
              					Transaction tx4 = sessionHQL4.beginTransaction();
           						 int first_ALMC_ISC_id=first_ALMC_ISC_getchoiceId.get(0).getId();
           						dssc_choice.setCourse_preference(3);
           						dssc_choice.setCourse_applied(first_ALMC_ISC_id);
                					dssc_choice.setEs_id(es_id);
                					dssc_choice.setCreated_by(username);
                					dssc_choice.setCreated_Date(date);
                					dssc_choice.setDscc_app_id(dssc_id);
                					sessionHQL4.save(dssc_choice);
                					
              					     tx4.commit();
              					  
            					  }
              					 
              					List<CHOICE_M>second_ALMC_ISC_getchoiceId=comm.getChoicemstIdByChoiceName(sessionFactory,second_ALMC_ISC);
              				  if(!second_ALMC_ISC_getchoiceId.isEmpty()) {
             					Session sessionHQL5 = this.sessionFactory.openSession();
          					Transaction tx5 = sessionHQL5.beginTransaction();
       						 int second_ALMC_ISC_id=second_ALMC_ISC_getchoiceId.get(0).getId();
       						dssc_choice.setCourse_preference(4);
       						dssc_choice.setCourse_applied(second_ALMC_ISC_id);
            					dssc_choice.setEs_id(es_id);
            					dssc_choice.setCreated_by(username);
            					dssc_choice.setCreated_Date(date);
            					dssc_choice.setDscc_app_id(dssc_id);
            					sessionHQL5.save(dssc_choice);
            					
          					     tx5.commit();
          					     
              				  }
          					     
          					   CPV cpv = new CPV();
          						Session sessionHQL6 = this.sessionFactory.openSession();
          						Transaction tx6 = sessionHQL6.beginTransaction();
          						cpv.setCreated_by(username);
          						cpv.setCpv_mks(0);
          						cpv.setFd_service_mks(Fsp_mks);
          						cpv.setOpd_personal_id(opd_pers_id);
          						cpv.setOa_application_id(mid);
          						cpv.setCreated_date(date);
          						sessionHQL6.save(cpv);
          						sessionHQL6.flush();
          						sessionHQL6.clear();
          						tx6.commit();
          						
          					     
              					ra.addAttribute("msg","Data Save Successfully");
          						
          						}else {
          							
          							 listData.add(arm_service);
          							 listData.add(personal_no);
          							 listData.add(rank);
          							 listData.add(officer_name);
          							 listData.add(unit);
          							 listData.add(Loc_of_Unit);
          							 listData.add(Arms_Ser_No);
          							 listData.add(Regt);
          							 listData.add(Comd);
          							 listData.add(Type_of_Entry);
          							 listData.add(Date_of_Commission);
          							 listData.add(Date_of_Seniority);
          							 listData.add(Med_Cat);
          							 listData.add(CPSC);
          							 listData.add(Course_applied);
          							 listData.add(First_Choice);
          							 listData.add(Second_Choice);
          							 listData.add(tech_nontech);
          	      					 listData.add(Dt_of_Receipt);
          							 listData.add(first_ALMC_ISC);
          							 listData.add(second_ALMC_ISC);
          							 listData.add(app_atmpt);
          							 listData.add(Attempt);
          							 listData.add(Centre_1);
          							 listData.add(Centre_2);
          							 listData.add(exmcntr_alct);
          							 listData.add(m_tech_yr); 
          							 listData.add(JC_Course);
          							 listData.add(Phone_No);
          							 listData.add(EMail);
          							 listData.add(Status);
          							 listData.add(Remarks);
          							 listData.add(Duration_Days);
          							 listData.add(Duration_Months);
          							listData.add("Your Fsp Marks Above 25 Marks");
          							
          						}
          						
          					
          					     
          					     
          				
          							
							
								
							}else {
								 listData.add(arm_service);
								 listData.add(personal_no);
								 listData.add(rank);
								 listData.add(officer_name);
								 listData.add(unit);
								 listData.add(Loc_of_Unit);
								 listData.add(Arms_Ser_No);
								 listData.add(Regt);
								 listData.add(Comd);
								 listData.add(Type_of_Entry);
								 listData.add(Date_of_Commission);
								 listData.add(Date_of_Seniority);
								 listData.add(Med_Cat);
								 listData.add(CPSC);
								 listData.add(Course_applied);
								 listData.add(First_Choice);
								 listData.add(Second_Choice);
								 listData.add(tech_nontech);
		      					 listData.add(Dt_of_Receipt);
								 listData.add(first_ALMC_ISC);
								 listData.add(second_ALMC_ISC);
								 listData.add(app_atmpt);
								 listData.add(Attempt);
								 listData.add(Centre_1);
								 listData.add(Centre_2);
								 listData.add(exmcntr_alct);
								 listData.add(m_tech_yr); 
								 listData.add(JC_Course);
								 listData.add(Phone_No);
								 listData.add(EMail);
								 listData.add(Status);
								 listData.add(Remarks);
								 listData.add(Duration_Days);
								 listData.add(Duration_Months);
								 listData.add("The Application already Generated");
							}

						}
						
						
					}else {
						
						 listData.add(arm_service);
						 listData.add(personal_no);
						 listData.add(rank);
						 listData.add(officer_name);
						 listData.add(unit);
						 listData.add(Loc_of_Unit);
						 listData.add(Arms_Ser_No);
						 listData.add(Regt);
						 listData.add(Comd);
						 listData.add(Type_of_Entry);
						 listData.add(Date_of_Commission);
						 listData.add(Date_of_Seniority);
						 listData.add(Med_Cat);
						 listData.add(CPSC);
						 listData.add(Course_applied);
						 listData.add(First_Choice);
						 listData.add(Second_Choice);
						 listData.add(tech_nontech);
      					 listData.add(Dt_of_Receipt);
						 listData.add(first_ALMC_ISC);
						 listData.add(second_ALMC_ISC);
						 listData.add(app_atmpt);
						 listData.add(Attempt);
						 listData.add(Centre_1);
						 listData.add(Centre_2);
						 listData.add(exmcntr_alct);
						 listData.add(m_tech_yr); 
						 listData.add(JC_Course);
						 listData.add(Phone_No);
						 listData.add(EMail);
						 listData.add(Status);
						 listData.add(Remarks);
						 listData.add(Duration_Days);
						 listData.add(Duration_Months);
						 listData.add("Admit Card Not Generated");
					}
					
					
				
					
				
					}
					
					if(!listData.isEmpty()) {
						System.err.println("listData============"+listData);
						listerror.add(listData);
					}
					
			
					
					
					
				
					
						
					
						
						
						
					} 

				
				System.err.println("o=========="+listerror.size());
				model.put("errorlist", listerror);
				
				model.put("errorDSSClistSize", listerror.size());
				
		tx.commit();
					
				
						
						
						

				
				
					
				}
				
			
		
			 catch (Exception e) {
				//tx.rollback();
				e.printStackTrace();
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}
			
			ra.addFlashAttribute("errorlist", listerror);
			ra.addFlashAttribute("errorDSSClistSize", listerror.size());
			return new ModelAndView("redirect:UploadDssc_tsoc_ApplicationURL");
		}	
		 @SuppressWarnings("unchecked") 
		@RequestMapping(value = "/getCourseDetailsForDSSC", method = RequestMethod.POST)
		@ResponseBody public List<Map<String, Object>>getCourseDetails(String course_name) { 
			
			System.err.println("course_id========+"+course_name);
			List<Map<String, Object>>list2= objDAO.getCourseDetails(course_name);
		
			
		return list2; 
		}
}
