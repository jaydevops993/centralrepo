package com.BisagN.dao.officer.others;

import java.util.ArrayList;

public interface ProcessResultDao {
	
	public ArrayList<ArrayList<String>> getFullyPassedForProcessResult(int es_id, String oa_application_id,int exan_id) ;

}
