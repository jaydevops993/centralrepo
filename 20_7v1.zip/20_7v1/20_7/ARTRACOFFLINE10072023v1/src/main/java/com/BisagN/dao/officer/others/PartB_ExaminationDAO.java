package com.BisagN.dao.officer.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface PartB_ExaminationDAO  {

	public ArrayList<ArrayList<String>> getdatafromExaminationCentre(int exm_id);
	public ArrayList<ArrayList<String>> getSubjectList(String Exm_name, String arm_id);
	public ArrayList<ArrayList<String>> getPartBexmCandidateReport(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,String pers_no, String pers_name,String center, String opd_arm_service,String exam_schedule_dt_id, HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	public long getPartbexmCandidatereportTotalCount(String Search,String pers_no, String pers_name,String center, String opd_arm_service,String exam_schedule_dt_id);
	public ArrayList<ArrayList<String>> getOPDdetailsforpartb(String opd_id) ;
	public ArrayList<ArrayList<String>> getpartbapplicationdtl(String opd_id);
	
	
	public ArrayList<ArrayList<String>> getPartDexmCandidateReport(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,String pers_no, String pers_name, String center, String opd_arm_service,String exam_schedule_dt_id,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	

public long getPartDexmCandidatereportTotalCount(String Search,String pers_no, String pers_name,String center, String opd_arm_service, String exam_schedule_dt_id);

public ArrayList<ArrayList<String>> getManualPartbRulesappdetails(int opd_personal_id,String exmsch_dt, String exam_schedule_dt, String min_year, String max_year);
}
