package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "results_withheld", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class RESULTS_WITHHELD_M {

      private int id;
      private String personal_no;
      private String rc_rank_name;
      private String off_name;
      private String unit;
      private String ecc_name;
      private String cc_command_name;
      private int oa_appllication_id;
      private int res_status_id;
      private String res_remark;


      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public String getPersonal_no() {
           return personal_no;
      }
      public void setPersonal_no(String personal_no) {
	  this.personal_no = personal_no;
      }
      public String getRc_rank_name() {
           return rc_rank_name;
      }
      public void setRc_rank_name(String rc_rank_name) {
	  this.rc_rank_name = rc_rank_name;
      }
      public String getOff_name() {
           return off_name;
      }
      public void setOff_name(String off_name) {
	  this.off_name = off_name;
      }
      public String getUnit() {
           return unit;
      }
      public void setUnit(String unit) {
	  this.unit = unit;
      }
      public String getEcc_name() {
           return ecc_name;
      }
      public void setEcc_name(String ecc_name) {
	  this.ecc_name = ecc_name;
      }
      public String getCc_command_name() {
           return cc_command_name;
      }
      public void setCc_command_name(String cc_command_name) {
	  this.cc_command_name = cc_command_name;
      }
      public int getOa_appllication_id() {
           return oa_appllication_id;
      }
      public void setOa_appllication_id(int oa_appllication_id) {
	  this.oa_appllication_id = oa_appllication_id;
      }
	public int getRes_status_id() {
		return res_status_id;
	}
	public void setRes_status_id(int res_status_id) {
		this.res_status_id = res_status_id;
	}
	public String getRes_remark() {
		return res_remark;
	}
	public void setRes_remark(String res_remark) {
		this.res_remark = res_remark;
	}
      
      
}
