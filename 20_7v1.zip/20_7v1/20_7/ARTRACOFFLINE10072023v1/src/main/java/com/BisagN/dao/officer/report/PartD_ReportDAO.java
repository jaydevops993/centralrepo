package com.BisagN.dao.officer.report;

import java.util.ArrayList;

public interface PartD_ReportDAO {
	
	
	public ArrayList<ArrayList<String>> getArmsubsummaryresult(int es_id);
	public ArrayList<ArrayList<String>> getFullyPassedForPartD(int es_id, String oa_application_id);
	public ArrayList<ArrayList<String>> getPartPassedandFailuresForPartD(String es_year,String oa_application_id);
	public ArrayList<ArrayList<String>> PartAbsenteesForPartD(int es_id) ;
	public ArrayList<ArrayList<String>> IndexagainstmarksObtainedForPartD(int es_id, int subject_id1,int arm_id) ;
	public ArrayList<ArrayList<String>> getArmServiceAnalysisResultsPartD(int es_id, String es_year);
}
