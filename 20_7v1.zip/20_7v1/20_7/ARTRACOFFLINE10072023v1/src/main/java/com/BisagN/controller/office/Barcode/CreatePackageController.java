

package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.PartiallyPassPDFController;
import com.BisagN.controller.office.others.ResultReleasePDFController;
import com.BisagN.dao.Indexing.IndexingPackingNoteDAO;
import com.BisagN.dao.Indexing.ManageBundleDAO;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_DETAILS;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_MASTER;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_DETAILS;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_MASTER;
import com.BisagN.models.officers.indexing.INDEXING_SETTING;
import com.BisagN.models.officers.indexing.KITBAGMASTER;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.RESULTS_WITHHELD_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class CreatePackageController {

	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	
	@Autowired
	CommonController comm;
	@Autowired
	 PartB_ExaminationDAO partBDao;
	
	
	@Autowired
   IndexingPackingNoteDAO pckindxDao;
	
	
	
	@Autowired
	ManageBundleDAO MbindxDao;
	

	
	
	
	@RequestMapping(value = "CreatePackageUrl", method = RequestMethod.GET)
	public ModelAndView CreatePackageUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
  	
		
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
		  
		if(es_id != 0) {
			 List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
			 Mmap.put("es_id", es_id);
			 String index_mode= UnlcokExmsch.get(0).getEs_index_mode();
			 Mmap.put("index_mode", index_mode);
			 Mmap.put("es_id", es_id);
		}
		
		
		
		int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		if(esid_es_id != 0) {
		List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esid_es_id);
		Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
		LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		
		  int day = date.getDayOfMonth();
		  String[] months = {"Jan", "Feb", "Mar", "Apr" ,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		  
		  String[] shortMonths = new DateFormatSymbols().getShortMonths();
	        for (String shortMonth : shortMonths) {
	            
	      	 
	        }
		  
		  Month month = date.getMonth();
		  int year = date.getYear();
		String begindateShow= day +" "+ month + " "+ year;
		 
		 Mmap.put("begindateShow",begindateShow);
		 Mmap.put("esid_es_id",esid_es_id);
		
		
	
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
		
		int ActiveSubjectId=0;
		
		if (esid_sc_subject_id != 0) {
		List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
		Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
		Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
		List<SUBJECT_CODE_M>ActiveSubName= comm.getsubjectIdbysubname( sessionFactory, esid_sc_subject_id, ec_exam_id);
		
		ActiveSubjectId=esid_sc_subject_id;
		 Mmap.put("ActiveSub",ActiveSubName.get(0).getSc_subject_name());
		
		
	}
		
		int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
		if (esid_sub_subject_id != 0) {
			List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
			String sub_subject_name=SubSubject.get(0).getSub_subject();
			Mmap.put("sub_subject_name", sub_subject_name);
			ActiveSubjectId=esid_sub_subject_id;
		}
		
		Mmap.put("Active_subID", ActiveSubjectId);
		 
		}
	 Mmap.put("msg",msg);
	 return new ModelAndView("NewPackage_tile");
}
	

	  
	  
	  @RequestMapping(value = "/getPackingNoteDetails", method = RequestMethod.POST)
		@ResponseBody public ArrayList<ArrayList<String>> getPackingNoteDetails(String subject_id,String packed_status,HttpSession session) {
			int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
			if(esi_es_id != 0) {
				
				int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
						: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
				int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
			ArrayList<ArrayList<String>>list = pckindxDao.GetpackedPackingnoteDetailsSubwise(esi_es_id,esid_sc_subject_id, esid_sub_subject_id,packed_status);
			return list;
			}
			return null;
		}
	  
	  
	  @RequestMapping(value = "/getUnPackingNoteDetails", method = RequestMethod.POST)
			@ResponseBody public ArrayList<ArrayList<String>> getUnPackingNoteDetails(String subject_id,String packed_status,HttpSession session) {
				int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
				if(esi_es_id != 0) {
					
					int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
							: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
					int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
				ArrayList<ArrayList<String>>list = pckindxDao.GetUnpackedPackingnoteDetailsSubwise(esi_es_id,esid_sc_subject_id, esid_sub_subject_id,packed_status);
//				ArrayList<ArrayList<String>>list = pckindxDao.GetPackingnoteDetailsSubwise(esi_es_id,subject_id);
				return list;
				}
				return null;
			}
		 
	 
	  
	  @RequestMapping(value = "/getBundledetailsbyPackingNote", method = RequestMethod.POST)
			@ResponseBody public ArrayList<ArrayList<String>> getBundledetailsbyPackingNote(String packing_note_id,HttpSession session) {
				int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
				ArrayList<ArrayList<String>>list = pckindxDao.GetBundleListByPackingNote(esi_es_id,packing_note_id);
				return list;
				
			}
	  
	  
	  
	
	  
	  @RequestMapping(value = "/CheckFinalansbkCountByPkngNote", method = RequestMethod.POST)
		@ResponseBody public ArrayList<ArrayList<String>> CheckFinalansbkCountByPkngNote(String packing_note_id,HttpSession session) {
			int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
			  ArrayList<ArrayList<String>> packingNote_list = pckindxDao.GetFinalPackageNameListByEsid(esi_es_id);
			//System.err.println("list================::"+packingNote_list);
			return packingNote_list;
			
		}
	  
	  @RequestMapping(value = "/getPackedPackingNoteDetails", method = RequestMethod.POST)
			@ResponseBody public ArrayList<ArrayList<String>> getPackedPackingNoteDetails(String subject_id,String packed_status,HttpSession session) {
				int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
				if(esi_es_id != 0) {
					
					int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
							: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
					int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
					ArrayList<ArrayList<String>>list = pckindxDao.GetpackedPackingnoteDetailsSubwise(esi_es_id,esid_sc_subject_id,esid_sub_subject_id,packed_status);
					return list;
				}
				return null;
				
				
				
			}
	  
		
		
		@RequestMapping(value = "/getPackingNote_Report", method = RequestMethod.POST)
		public ModelAndView getPackingNote_Report(ModelMap Mmap, HttpSession session,HttpServletRequest request, String typeReport,String reportname1, String packing_note_id1, String packing_note_name_hid1) {
			try {
				Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction();

				
				int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
				int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
				
				
				int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
						: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
				int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
				
				 String ActiveSubjectName="";
				if (esid_sc_subject_id != 0) {
				List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
				Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
				Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
				List<SUBJECT_CODE_M>ActiveSubName= comm.getsubjectIdbysubname( sessionFactory, esid_sc_subject_id, ec_exam_id);
				
				ActiveSubjectName=ActiveSubName.get(0).getSc_subject_name();
				
				
			}
				
				if (esid_sub_subject_id != 0) {
					List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
					ActiveSubjectName=SubSubject.get(0).getSub_subject();
					
				}
				 
	
				 
				if(esid_es_id != 0) {
					
					List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
					Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
					
					
					String es_begindate = session.getAttribute("es_begin_date") == null ? ""
							: session.getAttribute("es_begin_date").toString();

					String es_year1 = es_begindate.split("-")[0];
					
				
						
			ArrayList<ArrayList<String>> packingNote = pckindxDao.GetBundleListByPackingNote(esid_es_id,packing_note_id1);
				
				if (packingNote.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {
					
					String hq15 = "update INDEXED_PACKING_NOTES_MASTER set ipnm_status_id=:ipnm_status_id  where ipnm_id=:ipnm_id";
					Query query5 = sessionHQL.createQuery(hq15)
								.setParameter("ipnm_status_id",1)	
								.setParameter("ipnm_id",Integer.parseInt(packing_note_id1));
								
					query5.executeUpdate();
					tx.commit();
					
					Mmap.put("list", packingNote);
					Mmap.put("ActiveSubName", ActiveSubjectName);
//					Mmap.put("Bundle", bundle_name_hid1);
					Mmap.put("packing_note_name_hid1", packing_note_name_hid1);
					Mmap.put("list.size()", packingNote.size());
					Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
					Mmap.put("es_year1", es_year1);
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (packingNote.size() > 0) {

						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(new PackingNotePdfReportController("L", TH, Heading, username),"userList",packingNote);

					}
				}
				
				
				}
				
				}
				
               
			
			
			
			
				
			} catch (Exception e) {
				e.printStackTrace();
			}

			return new ModelAndView("redirect:CreatePackageUrl");
		}
		
		
		@RequestMapping(value = "/getFinalPackingNote_Report", method = RequestMethod.POST)
		public ModelAndView getFinalPackingNote_Report(ModelMap Mmap, HttpSession session,HttpServletRequest request, String typeReport2, String packing_note_id2, String packing_note_name_hid2) {
			try {
				Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction();

				
				int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
				int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
				List<EXAMSCHEDULE_INDEXING_DETAIL>ActiveSubject = comm.getActiveIndxSubject(sessionFactory,esid_es_id);
				int Active_sub= ActiveSubject.get(0).getEsid_sc_subject_id();
				
				 List<SUBJECT_CODE_M>ActiveSubjectName=comm.getsubjectIdbysubname(sessionFactory, Active_sub, ec_exam_id);
				 
				 String ActiveSubName=ActiveSubjectName.get(0).getSc_subject_name();
				 
				if(esid_es_id != 0) {
					
					List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
					Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
					   ArrayList<ArrayList<String>> packingNote_list = pckindxDao.GetFinalPackageNameListByEsid(esid_es_id);
					   
					   System.err.println("packingNote_list=====:"+packingNote_list);
						
						if (packingNote_list.size() == 0) {

							Mmap.put("msg", "Data Not Available.");
						} else {

							
							String hq15 = "update INDEXED_PACKING_NOTES_MASTER set ipnm_final_status_id=:ipnm_final_status_id  where ipnm_es_id=:ipnm_es_id";
							Query query5 = sessionHQL.createQuery(hq15)
										.setParameter("ipnm_final_status_id",1)	
										.setParameter("ipnm_es_id",esid_es_id);
										
							query5.executeUpdate();
							tx.commit();
							
							
							Mmap.put("list", packingNote_list);
							Mmap.put("ActiveSubName", ActiveSubName);
//							Mmap.put("Bundle", bundle_name_hid1);
							Mmap.put("packing_note_name_hid1", packing_note_name_hid2);
							Mmap.put("list.size()", packingNote_list.size());
							Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
						if (typeReport2 != null && typeReport2.equals("pdfL")) {
							if (packingNote_list.size() > 0) {

								List<String> TH = new ArrayList<String>();
								String Heading = "";
								String username = session.getAttribute("username").toString();
								return new ModelAndView(new GenerateFinalPackingNoteListPdfController("L", TH, Heading, username),"userList",packingNote_list);

							}
						}
						}
					
					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			return new ModelAndView("redirect:CreatePackageUrl");
		}
		
		  @RequestMapping(value = "UnpackPackingNoteURL", method = RequestMethod.POST)
			public ModelAndView UnpackPackingNoteURL(ModelMap Mmap, HttpSession session,
					@RequestParam(value = "msg", required = false) String msg, String packing_note_id3, HttpServletRequest request) {

			  Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction();
				int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());

				String hq15 = "update INDEXED_PACKING_NOTES_MASTER set ipnm_status_id=:ipnm_status_id  where ipnm_id=:ipnm_id and ipnm_es_id=:ipnm_es_id";
				Query query5 = sessionHQL.createQuery(hq15)
							.setParameter("ipnm_status_id",0)	
							.setParameter("ipnm_id",Integer.parseInt(packing_note_id3)).setParameter("ipnm_es_id",esid_es_id);
							
				query5.executeUpdate();
				
				
			
								
				
				
				Mmap.put("msg",msg);
			     
				Mmap.put("msg", "The Packing Note is Unpack");	
				tx.commit();
				
				
			

				return new ModelAndView("redirect:CreatePackageUrl");
			}
		 
}
