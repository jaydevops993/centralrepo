package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.office.others.ExportExcel_genExcelController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.ARM_SECTION_MASTERDAO;
import com.BisagN.dao.officer.others.ExportPartD_DAO;
import com.BisagN.models.officers.masters.ARM_CODES_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class ARM_SECTION_MASTERController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	private ARM_SECTION_MASTERDAO objDAO;

	
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	@Autowired
	private RoleBaseMenuDAO roledao;

	@RequestMapping(value = "ARM_SECTION_MASTER_Url", method = RequestMethod.GET)
	public ModelAndView ARM_SECTION_MASTER_Url(ModelMap Mmap, HttpSession session,HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

   	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("ARM_SECTION_MASTER_Url", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}	
		
		Mmap.put("msg", msg);
		return new ModelAndView("ARM_SECTION_MASTER_tile", "ARM_SECTION_MASTERCMD", new ARM_CODES_M());
	}

	@RequestMapping(value = "/getARM_SECTION_MASTERReportDataList", method = RequestMethod.POST)
	public @ResponseBody List<Map<String, Object>> getARM_SECTION_MASTERReportDataList(int startPage, String pageLength,
			String Search, String orderColunm, String orderType, HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		return objDAO.getReportListARM_SECTION_MASTER(startPage, pageLength, Search, orderColunm, orderType,
				sessionUserId);
	}

	@RequestMapping(value = "/getARM_SECTION_MASTERTotalCount", method = RequestMethod.POST)
	public @ResponseBody long getARM_SECTION_MASTERTotalCount(HttpSession sessionUserId, String Search, String name) {
		return objDAO.getReportListARM_SECTION_MASTERTotalCount(Search);
	}

	@RequestMapping(value = "/ARM_SECTION_MASTERAction", method = RequestMethod.POST)
	public ModelAndView ARM_SECTION_MASTERAction(@Valid @ModelAttribute("ARM_SECTION_MASTERCMD") ARM_CODES_M ln,
			BindingResult result, HttpServletRequest request, ModelMap model, HttpSession session) {

		
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();

		try {
		int errCount = 0;
		
		if(request.getParameter("ac_arm_code").trim().equals("") || request.getParameter("ac_arm_code").trim()==null ||
				request.getParameter("ac_arm_code")=="null" || request.getParameter("ac_arm_code").equals(null))
		{
			model.put("msg", "Please Enter Valid Arm Code");
			return new ModelAndView("redirect:ARM_SECTION_MASTER_Url");
		}
		
		if(request.getParameter("ac_arm_description").trim().equals("") || request.getParameter("ac_arm_description").trim()==null ||
				request.getParameter("ac_arm_description")=="null" || request.getParameter("ac_arm_description").equals(null))
		{
			model.put("msg", "Please Enter Arm Description");
			return new ModelAndView("redirect:ARM_SECTION_MASTER_Url");
		}

//		if (request.getParameter("ac_arm_code").equals("") || request.getParameter("ac_arm_code") == null) {
//			errCount++;
//			model.put("ac_arm_code_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Arm Code");
//		}
//		if (request.getParameter("ac_arm_description").equals("")
//				|| request.getParameter("ac_arm_description") == null) {
//			errCount++;
//			model.put("ac_arm_description_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Arm Description");
//		}
//		if (errCount > 0) {
//
//			return new ModelAndView("ARM_SECTION_MASTER_tile");
//		}

		int id = ln.getAc_arm_id() > 0 ? ln.getAc_arm_id() : 0;
		Date date = new Date();
		String username = session.getAttribute("username").toString();
		
	

			Query q0 = sessionHQL.createQuery(
					"select count(ac_arm_id) from ARM_CODES_M where   (LOWER(ac_arm_description)=:ac_arm_description or  ac_arm_code=:ac_arm_code) and ac_arm_id!=:ac_arm_id");

			q0.setParameter("ac_arm_code", ln.getAc_arm_code());
			q0.setParameter("ac_arm_description", ln.getAc_arm_description().toLowerCase());
			q0.setParameter("ac_arm_id", id);
			Long c = (Long) q0.uniqueResult();

			if (id == 0) {
				ln.setAc_created_by(username);
				ln.setAc_creation_date(date);
				ln.setAc_status_id(1);
				if (c == 0) {

					sessionHQL.save(ln);
					sessionHQL.flush();
					sessionHQL.clear();
					model.put("msg", "Data Saved Successfully.");

				} else {
					model.put("msg", "Data already Exist.");
				}
			}

			tx.commit();
		} catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return new ModelAndView("redirect:ARM_SECTION_MASTER_Url");
	}

	@RequestMapping(value = "EditARM_SECTION_MASTERUrl", method = RequestMethod.POST)
	public ModelAndView EditARM_SECTION_MASTERUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String updateid) {

		Session s1 = this.sessionFactory.openSession();
		Transaction tx = s1.beginTransaction();
		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);
		Query q = null;
		System.err.println(DcryptedPk);
		q = s1.createQuery("from ARM_CODES_M where cast(id as string)=:PK");
		q.setString("PK", DcryptedPk);
		@SuppressWarnings("unchecked")
		List<String> list = (List<String>) q.list();
		tx.commit();
		s1.close();
		Mmap.put("EditARM_SECTION_MASTERCMD1", list.get(0));
		Mmap.put("msg", msg);
		return new ModelAndView("EditARM_SECTION_MASTER_tile", "EditARM_SECTION_MASTERCMD", new ARM_CODES_M());
	}

	@RequestMapping(value = "/EditARM_SECTION_MASTERAction", method = RequestMethod.POST)
	public ModelAndView EditARM_SECTION_MASTERAction(@Valid @ModelAttribute("EditARM_SECTION_MASTERCMD") ARM_CODES_M ln,
			BindingResult result, HttpServletRequest request, ModelMap model, HttpSession session) {
	
		if(request.getParameter("ac_arm_code").equals("") || request.getParameter("ac_arm_code")==null ||
				request.getParameter("ac_arm_code")=="null" || request.getParameter("ac_arm_code").equals(null))
		{
			model.put("msg", "Please Enter Valid Arm Code");
			return new ModelAndView("redirect:EditARM_SECTION_MASTERUrl");
		}
		
		if(request.getParameter("ac_arm_description").equals("") || request.getParameter("ac_arm_description")==null ||
				request.getParameter("ac_arm_description")=="null" || request.getParameter("ac_arm_description").equals(null))
		{
			model.put("msg", "Please Enter Description");
			return new ModelAndView("redirect:EditARM_SECTION_MASTERUrl");
		}
//		int errCount = 0;
//
//		if (request.getParameter("ac_arm_code").equals("") || request.getParameter("ac_arm_code") == null) {
//			errCount++;
//			model.put("ac_arm_code_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Arm Code");
//		}
//		if (request.getParameter("ac_arm_description").equals("")
//				|| request.getParameter("ac_arm_description") == null) {
//			errCount++;
//			model.put("ac_arm_description_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Arm Description");
//		}
//		if (errCount > 0) {
//
//			return new ModelAndView("EditARM_SECTION_MASTER_tile");
//		}

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		ln.setAc_arm_id(Integer.parseInt(request.getParameter("ac_arm_id")));
		ln.setAc_status_id(1);
		sessionHQL.saveOrUpdate(ln);
		tx.commit();
		sessionHQL.close();

		model.put("msg", "Data Updated Successfully");
		return new ModelAndView("redirect:ARM_SECTION_MASTER_Url");
	}

	@RequestMapping(value = "/deleteARM_SECTION_MASTERUrl", method = RequestMethod.POST)
	public ModelAndView deleteARM_SECTION_MASTERUrl(String deleteid, HttpSession session, ModelMap model) {
		List<String> list = new ArrayList<String>();
		list.add(objDAO.DeleteARM_SECTION_MASTER(deleteid, session));
		model.put("msg", list);
		return new ModelAndView("redirect:ARM_SECTION_MASTER_Url");
	}
	
	//-----Excel
	@RequestMapping(value = "/Export_ARM_SECTION_MASTER", method = RequestMethod.POST)
	public ModelAndView Export_ARM_SECTION_MASTER(HttpServletRequest request, ModelMap model, HttpSession session, String typeReport1,
			String exam_schedule_dt2, String min_year2, String es_consider_date3, String exam_schedule_dthid2)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		
		
		
		ArrayList<ArrayList<String>> exportARM_SEC = objDAO.getExcelARM_SECTION_MASTER(0, "-1", "", "1", "ASC",typeReport1,session);
	
	
		
		
		if (exportARM_SEC.size() > 0) {
			List<String> TH = new ArrayList<String>();
			
			TH.add("SER_NO");
			TH.add("ARM_CODE_ID");
			TH.add("ARM_CODE");
			TH.add("ARM_DESCRIPTION");
			
			
			String Heading = "\n";
			String username = session.getAttribute("username").toString();
			return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList",
					exportARM_SEC);
		} else {
			model.put("msg", "Data Not Available.");
			return new ModelAndView("redirect:ARM_SECTION_MASTER_Url");
		}
	
	}

	
	
	
}
