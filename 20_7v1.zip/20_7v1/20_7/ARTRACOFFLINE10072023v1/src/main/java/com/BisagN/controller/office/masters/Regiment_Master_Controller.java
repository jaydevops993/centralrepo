package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.ARM_SECTION_MASTERDAO;
import com.BisagN.dao.officer.masters.Regiment_MasterDAO;
import com.BisagN.models.officers.masters.ARM_CODES_M;
import com.BisagN.models.officers.masters.RANK_CODE_M;
import com.BisagN.models.officers.masters.REGIMENT_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})

public class Regiment_Master_Controller {
	
	@Autowired
	private Regiment_MasterDAO objDAO;

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	  
	  @Autowired
	private RoleBaseMenuDAO roledao; 
	
	 @RequestMapping(value = "Regiment_master_Url", method = RequestMethod.GET)
     public ModelAndView Regiment_master_Url(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{
		  
		 if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

    	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("Regiment_master_Url", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}	
//		   Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
//		   Mmap.put("getctarmcodetypeListDDL",comm.getctarmcodetypeListDDL(sessionFactory));
		   
         Mmap.put("msg", msg);
     return new ModelAndView("Regiment_tiles");
}
	 
	 
	 @RequestMapping(value = "/Regiment_masterAction" ,method = RequestMethod.POST) 
	  public ModelAndView regiment_masterAction(@Valid @ModelAttribute("Regiment_masterCMD") REGIMENT_M ln, BindingResult result, 
	  HttpServletRequest request, ModelMap model, HttpSession session){ 

	 
		 if(request.getParameter("R_code").equals("") || request.getParameter("R_code")==null ||
					request.getParameter("R_code")=="null" || request.getParameter("R_code").equals(null))
			{
				model.put("msg", "Please Enter Regiment Code");
				return new ModelAndView("redirect:Regiment_master_Url");
			}
		  
		  if(request.getParameter("R_name").equals("") || request.getParameter("R_name")==null ||
					request.getParameter("R_name")=="null" || request.getParameter("R_name").equals(null))
			{
				model.put("msg", "Please Enter Regiment Name");
				return new ModelAndView("redirect:Regiment_master_Url");
			}


	     int id = ln.getR_id() > 0 ? ln.getR_id() : 0;
		Date date = new Date();
		String username = session.getAttribute("username").toString();
		 Session sessionHQL = this.sessionFactory.openSession();
		    Transaction tx = sessionHQL.beginTransaction(); 

		try {System.err.println(id);
			Query q0 = sessionHQL.createQuery(
					"select count(*) from REGIMENT_M  where r_name=:r_name and r_id!=:r_id ");
			q0.setParameter("r_name", ln.getR_name());
			q0.setParameter("r_id", id);
			Long c = (Long) q0.uniqueResult();

			
			if (id == 0) {
				ln.setCreated_by(username);
				ln.setCreated_date(date);
				ln.setR_status("1");
				
				if (c == 0) {

					sessionHQL.save(ln);
					sessionHQL.flush();
					sessionHQL.clear();
					model.put("msg", "Data Saved Successfully.");

				} else {
					model.put("msg", "Data already Exist.");
				}
			}

		
			tx.commit();
		} catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return new ModelAndView("redirect:Regiment_master_Url");
	}
	 
	 @RequestMapping(value = "/getREGIMENT_MASTERReportDataList", method = RequestMethod.POST)
		public @ResponseBody List<Map<String, Object>> getREGIMENT_MASTERReportDataList(int startPage, String pageLength,
				String Search, String orderColunm, String orderType, HttpSession sessionUserId)
				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
			return objDAO.getReportListRegiment_Master(startPage, pageLength, Search, orderColunm, orderType,
					sessionUserId);
		}

		@RequestMapping(value = "/getREGIMENT_MASTERTotalCount", method = RequestMethod.POST)
		public @ResponseBody long getREGIMENT_MASTERTotalCount(HttpSession sessionUserId, String Search, String name) {
			return objDAO.getReportListRegiment_MasterTotalCount(Search);
		}
		
		
		@RequestMapping(value = "EditRegiment_MASTERUrl", method = RequestMethod.POST)
		public ModelAndView EditRegiment_MASTERUrl(ModelMap Mmap, HttpSession session,
				@RequestParam(value = "msg", required = false) String msg, String updateid) {

			Session s1 = this.sessionFactory.openSession();
			Transaction tx = s1.beginTransaction();
			String enckey = "commonPwdEncKeys";
			String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);
			Query q = null;
			System.err.println(DcryptedPk);
			q = s1.createQuery("from REGIMENT_M where cast(id as string)=:PK");
			q.setString("PK", DcryptedPk);
			@SuppressWarnings("unchecked")
			List<String> list = (List<String>) q.list();
			tx.commit();
			s1.close();
			Mmap.put("EditREGIMENT_MASTERCMD1", list.get(0));
			Mmap.put("msg", msg);
			return new ModelAndView("Edit_Regiment_tiles", "EditRegiment_masterCMD", new REGIMENT_M());
		}

		@RequestMapping(value = "/EditRegiment_masterAction", method = RequestMethod.POST)
		public ModelAndView EditRegiment_masterAction(@Valid @ModelAttribute("EditRegiment_masterCMD") REGIMENT_M ln,
				BindingResult result, HttpServletRequest request, ModelMap model, HttpSession session) {
		
//			if(request.getParameter("ac_arm_code").equals("") || request.getParameter("ac_arm_code")==null ||
//					request.getParameter("ac_arm_code")=="null" || request.getParameter("ac_arm_code").equals(null))
//			{
//				model.put("msg", "Please Enter Valid Arm Code");
//				return new ModelAndView("redirect:EditARM_SECTION_MASTERUrl");
//			}
//			
//			if(request.getParameter("ac_arm_description").equals("") || request.getParameter("ac_arm_description")==null ||
//					request.getParameter("ac_arm_description")=="null" || request.getParameter("ac_arm_description").equals(null))
//			{
//				model.put("msg", "Please Enter Description");
//				return new ModelAndView("redirect:EditARM_SECTION_MASTERUrl");
//			}
//			int errCount = 0;
	//
//			if (request.getParameter("ac_arm_code").equals("") || request.getParameter("ac_arm_code") == null) {
//				errCount++;
//				model.put("ac_arm_code_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Arm Code");
//			}
//			if (request.getParameter("ac_arm_description").equals("")
//					|| request.getParameter("ac_arm_description") == null) {
//				errCount++;
//				model.put("ac_arm_description_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Arm Description");
//			}
//			if (errCount > 0) {
	//
//				return new ModelAndView("EditARM_SECTION_MASTER_tile");
//			}

			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			
			 if(request.getParameter("R_code").equals("") || request.getParameter("R_code")==null ||
						request.getParameter("R_code")=="null" || request.getParameter("R_code").equals(null))
				{
					model.put("msg", "Please Enter Regiment Code");
					return new ModelAndView("redirect:Regiment_master_Url");
				}
			  
			  if(request.getParameter("R_name").equals("") || request.getParameter("R_name")==null ||
						request.getParameter("R_name")=="null" || request.getParameter("R_name").equals(null))
				{
					model.put("msg", "Please Enter Regiment Name");
					return new ModelAndView("redirect:Regiment_master_Url");
				}

			ln.setR_id(Integer.parseInt(request.getParameter("r_id")));
			ln.setR_status("1");
			sessionHQL.saveOrUpdate(ln);
			tx.commit();
			sessionHQL.close();

			model.put("msg", "Data Updated Successfully");
			return new ModelAndView("redirect:Regiment_master_Url");
		}

		
		
		@RequestMapping(value = "/delete_REGIMENT_MASTERUrl", method = RequestMethod.POST)
		public ModelAndView deleteARM_SECTION_MASTERUrl(String deleteid, HttpSession session, ModelMap model) {
			List<String> list = new ArrayList<String>();
			list.add(objDAO.DeleteRegiment_MASTER(deleteid, session));
			model.put("msg", list);
			return new ModelAndView("redirect:Regiment_master_Url");
		}
}
