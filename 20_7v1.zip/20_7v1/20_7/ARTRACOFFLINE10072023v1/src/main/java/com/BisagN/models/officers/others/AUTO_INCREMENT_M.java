package com.BisagN.models.officers.others;


import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "auto_increment", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class AUTO_INCREMENT_M {

      private int id;
      private String ai_field;
      private int ai_value;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public String getAi_field() {
           return ai_field;
      }
      public void setAi_field(String ai_field) {
	  this.ai_field = ai_field;
      }
      public int getAi_value() {
           return ai_value;
      }
      public void setAi_value(int ai_value) {
	  this.ai_value = ai_value;
      }
}
