package com.BisagN.models.officers.trans;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "qualified_officers", uniqueConstraints = {
@UniqueConstraint(columnNames = "oid"),})
public class QUALIFIED_OFFICERS {

	
	 private int oid;
     private String nominatedfor;
     private int oa_applicant_id;
     private int course_id;
     private int status_id;
     private String reason;
     private String modified_by;
     private Date modified_date;
     private int meritid;
     private int es_id;
    
   @Id
   @GeneratedValue(strategy = IDENTITY)
   @Column(name = "oid", unique = true, nullable = false)
   public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public String getNominatedfor() {
		return nominatedfor;
	}
	public void setNominatedfor(String nominatedfor) {
		this.nominatedfor = nominatedfor;
	}
	public int getOa_applicant_id() {
		return oa_applicant_id;
	}
	public void setOa_applicant_id(int oa_applicant_id) {
		this.oa_applicant_id = oa_applicant_id;
	}
	public int getCourse_id() {
		return course_id;
	}
	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}
	public int getStatus_id() {
		return status_id;
	}
	public void setStatus_id(int status_id) {
		this.status_id = status_id;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	public int getMeritid() {
		return meritid;
	}
	public void setMeritid(int meritid) {
		this.meritid = meritid;
	}
	public int getEs_id() {
		return es_id;
	}
	public void setEs_id(int es_id) {
		this.es_id = es_id;
	}



     
     
     
}
