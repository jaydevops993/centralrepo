package com.BisagN.controller.office.reports;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;

public class CandidateScoringZeroMarksPDF extends AbstractPdfView {
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public CandidateScoringZeroMarksPDF(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		
		document.setPageSize(PageSize.A4.rotate());

		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		
		response.setContentType("application/pdf");
//	response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");

		
		
		
		
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
		Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
		Font fontTableHeadingSubMainHead = FontFactory.getFont(FontFactory.TIMES_BOLD, 12);;
		
		
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		
		
		
		

		PdfPTable tabledata1 = new PdfPTable(1);
	tabledata1.setWidths(new int[] {5});
	tabledata1.setWidthPercentage(100/ 3.5f);
	tabledata1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata1.setHorizontalAlignment(Element.ALIGN_RIGHT);
	tabledata1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	
	
	
	 Paragraph head1 = new Paragraph("Appendix 'D'");
	 Paragraph head2 = new Paragraph("(Refers to Para 1(d) of IHQ MoD(Army)");
	 Paragraph head3 = new Paragraph("DGMT(MT-2)");
	 Paragraph head4 = new Paragraph("Letter No");
	 Paragraph head5 = new Paragraph("Dated");
	 
	 tabledata1.addCell(head1);
	 tabledata1.addCell(head2);
	 tabledata1.addCell(head3);
	 tabledata1.addCell(head4);
	tabledata1.addCell(head5);

	
	

		Chunk chunk = new Chunk();
		

		Chunk underline1 = new Chunk("DIRECTORATE GENERAL OF MILITRY TRAINING(MT-2)" +"\n"+ "PROMOTION EXAMINATION PART B-JAN 001 " +"\n"+ "CANDIDATES WHO SUBMITTED BLANK ANSWER BOOK/SECURED ZERO MARKS" , fontTableHeadingSubMainHead);
		
		
		
		Chunk glue = new Chunk(new VerticalPositionMark());
		
		Phrase phh2 = new Phrase(underline1);
		phh2.add("\n");
		phh2.add("\n");
		
		
		phh2.setFont(fontTableHeadingSubMainHead);

		
		
		Paragraph cell1 = new Paragraph(phh2);
		cell1.setAlignment(Element.ALIGN_CENTER);
		
		
		
		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell1);
			
		
		 PdfPTable tabledata = new PdfPTable(6);
			
			
			tabledata.setWidths(new int[] {5,5,5,5,5,5});
			tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tabledata.setWidthPercentage(100);
			
			ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");
			

			Paragraph a = new Paragraph("Ser No.",fontTableHeadingSubMainHead);
			Paragraph b = new Paragraph("Personal No",fontTableHeadingSubMainHead);
			
			Paragraph c = new Paragraph("Rank",fontTableHeadingSubMainHead);
			Paragraph d = new Paragraph("Name",fontTableHeadingSubMainHead);
			Paragraph e = new Paragraph("Arm",fontTableHeadingSubMainHead);
			Paragraph f = new Paragraph("Subject",fontTableHeadingSubMainHead);
			
			
			 PdfPCell blank_cella;
			 blank_cella = new PdfPCell();
			 blank_cella.addElement(a);
			 blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
				
				 PdfPCell blank_cellb;
				 blank_cellb = new PdfPCell();
				 blank_cellb.addElement(b);
				 blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
				
				 PdfPCell blank_cellc;
				 blank_cellc = new PdfPCell();
				 blank_cellc.addElement(c);
				 blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
				 
				 PdfPCell blank_celld;
				 blank_celld = new PdfPCell();
				 blank_celld.addElement(d);
				 blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
				 
				 PdfPCell blank_celle;
				 blank_celle = new PdfPCell();
				 blank_celle.addElement(e);
				 blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
				 
				 PdfPCell blank_cellf;
				 blank_cellf = new PdfPCell();
				 blank_cellf.addElement(f);
				 blank_cellf.setHorizontalAlignment(Element.ALIGN_CENTER);
				 
				 
				
				 tabledata.addCell(blank_cella);
				 tabledata.addCell(blank_cellb);
				 tabledata.addCell(blank_cellc);
				 tabledata.addCell(blank_celld);
				 tabledata.addCell(blank_celle);
				 tabledata.addCell(blank_cellf);
				 
				 
				 //data bind
				 
				 
				 int  index=1;
				 for(int i=0;i<list.size();i++)
				 {
				
					 List<String> l = list.get(i);
					 Paragraph a1index = new Paragraph(String.valueOf(index),fontTableHeadingdata);
					 Paragraph pers_code = new Paragraph(l.get(0),fontTableHeadingdata);
					 Paragraph rank = new Paragraph(l.get(1),fontTableHeadingdata);
					 Paragraph name = new Paragraph(l.get(2),fontTableHeadingdata);
					 Paragraph armservice = new Paragraph(l.get(3),fontTableHeadingdata);
					 Paragraph subject = new Paragraph(l.get(4),fontTableHeadingdata);
					 
					 
					 tabledata.addCell(a1index);
					 tabledata.addCell(pers_code);
					 tabledata.addCell(rank);
					 tabledata.addCell(name);
					 tabledata.addCell(armservice);
					 tabledata.addCell(subject);
					 
					 
					index+=1;
					 
				
				 }
				 
					 
				
			 
			 
			 
				 
			PdfPCell cell123;
			cell123 = new PdfPCell();
			cell123.addElement(tabledata1);
			cell123.addElement(new Paragraph("\n"));
			cell123.addElement(tableheader);
			cell123.addElement(tabledata);
			cell123.setBorder(0);
			table.addCell(cell123);

		


	
	document.add(table);
	super.buildPdfMetadata(model, document, request);
	}


}
