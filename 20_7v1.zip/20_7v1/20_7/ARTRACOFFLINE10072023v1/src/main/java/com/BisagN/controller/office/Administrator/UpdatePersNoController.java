package com.BisagN.controller.office.Administrator;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class UpdatePersNoController {

	
	
	@RequestMapping(value = "UpdatePersNoUrl", method = RequestMethod.GET)
	public ModelAndView UpdatePersNoUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) 
			 throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
	NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{
		
		
		
	    Mmap.put("msg", msg);
	    
	 //   Mmap.put("PartB_Begindate", list2);
	return new ModelAndView("UpdatepersNo_tiles");

	}
}
