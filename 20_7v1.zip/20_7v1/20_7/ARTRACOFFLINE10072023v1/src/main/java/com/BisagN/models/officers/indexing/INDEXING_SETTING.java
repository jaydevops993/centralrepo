package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Table(name = "indexing_settings", uniqueConstraints = {
@UniqueConstraint(columnNames = "ist_id"),})
public class INDEXING_SETTING {
	
	private int ist_maxab_bundle;
	private int ist_maxbundle_package;
	private int ist_es_id;
	private int ist_min_indexno;
	private int ist_max_indexno;
	private String created_by;
	private Date created_date;
	private String modified_by;
	private Date modified_date;	
	private int ist_id;
	private int ist_max_bundle;
	

	   
	@Id
	      @GeneratedValue(strategy = IDENTITY)
	      @Column(name = "ist_id", unique = true, nullable = false)
	   
	   
		public int getIst_id() {
			return ist_id;
		}
		public void setIst_id(int ist_id) {
			this.ist_id = ist_id;
		}
	public int getIst_maxab_bundle() {
		return ist_maxab_bundle;
	}
	public void setIst_maxab_bundle(int ist_maxab_bundle) {
		this.ist_maxab_bundle = ist_maxab_bundle;
	}
	public int getIst_maxbundle_package() {
		return ist_maxbundle_package;
	}
	public void setIst_maxbundle_package(int ist_maxbundle_package) {
		this.ist_maxbundle_package = ist_maxbundle_package;
	}
	public int getIst_es_id() {
		return ist_es_id;
	}
	public void setIst_es_id(int ist_es_id) {
		this.ist_es_id = ist_es_id;
	}
	public int getIst_min_indexno() {
		return ist_min_indexno;
	}
	public void setIst_min_indexno(int ist_min_indexno) {
		this.ist_min_indexno = ist_min_indexno;
	}
	public int getIst_max_indexno() {
		return ist_max_indexno;
	}
	public void setIst_max_indexno(int ist_max_indexno) {
		this.ist_max_indexno = ist_max_indexno;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	public int getIst_max_bundle() {
		return ist_max_bundle;
	}
	public void setIst_max_bundle(int ist_max_bundle) {
		this.ist_max_bundle = ist_max_bundle;
	}
	
	
	
	
	
}



