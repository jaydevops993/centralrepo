package com.BisagN.models.officers.masters;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "command_code", uniqueConstraints = {
@UniqueConstraint(columnNames = "cc_command_id"),})
public class COMMAND_CODE_M {

      private int cc_command_id;
      private String cc_command_name;
      private int cc_status_id;
      private int cc_command_order;
      private String cc_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date cc_creation_date;
      private String cc_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date cc_modification_date;


      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "cc_command_id", unique = true, nullable = false)
     
      
      public int getCc_command_id() {
  		return cc_command_id;
  	}
  	public void setCc_command_id(int cc_command_id) {
  		this.cc_command_id = cc_command_id;
  	}
  	
  	
      public String getCc_command_name() {
           return cc_command_name;
      }
      
	public void setCc_command_name(String cc_command_name) {
	  this.cc_command_name = cc_command_name;
      }
      public int getCc_status_id() {
           return cc_status_id;
      }
      public void setCc_status_id(int cc_status_id) {
	  this.cc_status_id = cc_status_id;
      }
      public int getCc_command_order() {
           return cc_command_order;
      }
      public void setCc_command_order(int cc_command_order) {
	  this.cc_command_order = cc_command_order;
      }
      public String getCc_created_by() {
           return cc_created_by;
      }
      public void setCc_created_by(String cc_created_by) {
	  this.cc_created_by = cc_created_by;
      }
      public Date getCc_creation_date() {
           return cc_creation_date;
      }
      public void setCc_creation_date(Date cc_creation_date) {
	  this.cc_creation_date = cc_creation_date;
      }
      public String getCc_modified_by() {
           return cc_modified_by;
      }
      public void setCc_modified_by(String cc_modified_by) {
	  this.cc_modified_by = cc_modified_by;
      }
      public Date getCc_modification_date() {
           return cc_modification_date;
      }
      public void setCc_modification_date(Date cc_modification_date) {
	  this.cc_modification_date = cc_modification_date;
      }
	
      
      
}
