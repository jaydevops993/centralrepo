package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.reports.AbsenteesPDF;
import com.BisagN.controller.office.reports.ArmServiceWiseAnalysisOfResult;
import com.BisagN.controller.office.reports.CandidateScoring25PermarksPDF;
import com.BisagN.controller.office.reports.CentreWiseOffAppearedagainstsubjectPDF;
import com.BisagN.controller.office.reports.ChancewiseAnalysisReportPDF;
import com.BisagN.controller.office.reports.CommandWiseAnalysic_Controller_Pdf;
import com.BisagN.controller.office.reports.FullyPassed_Controller_Pdf;
import com.BisagN.controller.office.reports.IndexNoAgainstMarksObtainedController_Pdf;
import com.BisagN.controller.office.reports.IndexNoAgainstPersonalNoController_Pdf;
import com.BisagN.controller.office.reports.IndexNoAgainstPersonalNoandNameController_Pdf;
import com.BisagN.controller.office.reports.IneligibleCandidateReportController;
import com.BisagN.controller.office.reports.PartiallyPassed_Controller_Pdf;
import com.BisagN.controller.office.reports.ResultApproval_Controller_Pdf;
import com.BisagN.controller.office.reports.Result_withheldPdf;
import com.BisagN.controller.office.reports.SubjectWiseAnalysic_Controller_Pdf;
import com.BisagN.controller.office.reports.SummaryPdfController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.booklet.GenerateBookletDao;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.dao.officer.others.ExaminationlockunlockDAO;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.others.ProcessResultDao;
import com.BisagN.dao.officer.others.SearchResultswithheldDAO;
import com.BisagN.dao.officer.report.PartB_ReportDAO;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MASTER;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.OFFICER_RANK_M;
import com.BisagN.models.officers.others.PARTB_D_APPLICATION_M;
import com.BisagN.models.officers.others.RESULTS_WITHHELD_M;
import com.BisagN.models.officers.trans.EXAM_CENTER_CODE_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class ResultswithheldController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	CommonController comm = new CommonController();

	@Autowired
	ExaminationlockunlockDAO exmlkunlkDAO;

	@Autowired
	private SearchResultswithheldDAO resDao;

	@Autowired
	private PartB_ExaminationDAO partBDao;

	@Autowired
	PartB_ReportDAO partbreportDao;

	@Autowired
	GenerateBookletDao genDao;

	@Autowired
	ProcessResultDao prsDao;

	@Autowired
	private RoleBaseMenuDAO roledao;

	@RequestMapping(value = "ResultswithheldUrl", method = RequestMethod.GET)
	public ModelAndView ResultswithheldUrl(ModelMap Mmap,HttpServletRequest request, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg) {

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

		if (es_id != 0) {
			ArrayList<ArrayList<String>> list2 = genDao.getResultStatusForExamSchedule(String.valueOf(es_id));
			Mmap.put("getprocess_status", list2.get(0).get(0));
			int ec_exam_id = Integer.parseInt(
					session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
			if (ec_exam_id != 0) {
				ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
				Mmap.put("getexamcentrelist", examcentrelist);
				Mmap.put("ec_exam_id", ec_exam_id);
			}
			Mmap.put("es_id", es_id);
		}

		

		Mmap.put("msg", msg);
		Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
		return new ModelAndView("Resultwithheldtiles");
	}

	@RequestMapping(value = "/ResultWithHeldAction", method = RequestMethod.POST)
	public ModelAndView ResultWithHeldAction(@ModelAttribute("ResultWithHeldCMD") RESULTS_WITHHELD_M ResultWithHeld,
			BindingResult result,ModelMap Mmap, HttpServletRequest request, ModelMap model, HttpSession session) {
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		try {

			String exm_id = request.getParameter("ec_exam_id1");
			String PersonalCode = request.getParameter("opd_personal_id");
			String Remarks = request.getParameter("res_remark");
			
			
			if (exm_id.equals("0")) {
				Mmap.put("msg", "Please Select Examination");
				return new ModelAndView("redirect:ResultswithheldUrl");
			}
			if (PersonalCode == "") {
				Mmap.put("msg", "Please Enter Personal Code");
				return new ModelAndView("redirect:ResultswithheldUrl");
			}
			if (Remarks == "") {
				Mmap.put("msg", "Please Enter Remarks");
				return new ModelAndView("redirect:ResultswithheldUrl");
			}
			
			
			int id = ResultWithHeld.getId() > 0 ? ResultWithHeld.getId() : 0;

			if (id == 0) {

				int es_id = Integer.parseInt(
						session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
				String pers_code = request.getParameter("opd_personal_id");
//				System.err.println("persoce==========" + pers_code);

				List<OFFICER_PERSONAL_CODE_M> opdpers_id = comm.getopdIdbycode(sessionFactory, pers_code);
//				System.err.println("opdpers_id====" + opdpers_id);
//				System.err.println("opdpers_id1====" + opdpers_id.get(0).getOpd_personal_id());
				int opd_pers_id = opdpers_id.get(0).getOpd_personal_id();

				List<INDEX_SLIP_MASTER> ismstr = comm.getIndexNoByICnumber(sessionFactory, pers_code,
						String.valueOf(es_id));
				int command = ismstr.get(0).getCommand_id();
				int ecc_code = ismstr.get(0).getCenter_code();

				List<EXAM_CENTER_CODE_M> examCenter = comm.getexamcentreListByEcc_Code(sessionFactory, ecc_code);
				String ecc_name = examCenter.get(0).getEcc_name();

				List<OFFICER_APPLICATION_M> Oapp_id = comm.getOappIdbyopdId(sessionFactory, opd_pers_id, es_id);
				int O_app_id = Oapp_id.get(0).getOa_application_id();

				Query q0 = sessionHQL.createQuery(
						"select count(*) from RESULTS_WITHHELD_M where personal_no=:personal_no and id!=:id");

				q0.setParameter("personal_no", pers_code);
				q0.setParameter("id", id);
				Long c = (Long) q0.uniqueResult();

				if (c == 0) {

					ResultWithHeld.setCc_command_name(String.valueOf(command));
					ResultWithHeld.setOff_name(request.getParameter("opd_officer_name"));
					ResultWithHeld.setPersonal_no(pers_code);
					ResultWithHeld.setRc_rank_name(String.valueOf(ecc_name));
					ResultWithHeld.setEcc_name(ecc_name);
					// ResultWithHeld.setUnit(opd_unit);
					ResultWithHeld.setOa_appllication_id(O_app_id);
					ResultWithHeld.setRes_remark(request.getParameter("res_remark"));
					ResultWithHeld.setRes_status_id(1);
					sessionHQL.save(ResultWithHeld);

					String hq15 = "update OFFICER_APPLICATION_M set oa_status_id=:oa_status_id where oa_application_id=:oa_application_id ";
					Query query5 = sessionHQL.createQuery(hq15).setParameter("oa_status_id", 4)
							.setParameter("oa_application_id", O_app_id);

					query5.executeUpdate();

					model.put("msg", "Data Saved Successfully");
					tx.commit();

				} else {

					model.put("msg", "Data already Exist");
				}

			}

		}

		catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return new ModelAndView("redirect:SearchResultswithheldURL");
	}

	@RequestMapping(value = "/getbegindateforresultwithheld", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getbegindateforresultwithheld(String exm) {

		ArrayList<ArrayList<String>> list2 = exmlkunlkDAO.getBeignDateForGnrtbooklet(exm);

		return list2;
	}

	@RequestMapping(value = "/SearchResultswithheldURL", method = RequestMethod.GET)
	public ModelAndView SearchResultswithheldURL(ModelMap Mmap,HttpServletRequest request, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
		Mmap.put("msg", msg);

		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? ""
				: session.getAttribute("es_begin_dateshow").toString();
		Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL(sessionFactory));
		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
		// if (ec_exam_id == 1) {
		if (!es_begindate.equals("")) {
			Mmap.put("partb_begindate", es_begindate);
		}
		if (es_id != 0) {
			Mmap.put("es_id", es_id);
		}
		if (ec_exam_id != 0) {
			ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
			Mmap.put("getexamcentrelist", examcentrelist);
			Mmap.put("ec_exam_id", ec_exam_id);
		}
		// }
		
		if (request.getHeader("Referer") == null) {
			session.invalidate();
			Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			return new ModelAndView("redirect:/login");
		}

		String roleid1 = session.getAttribute("roleid").toString();
		Boolean val = roledao.ScreenRedirect("SearchResultswithheldURL", roleid1);
		if (val == false) {
			return new ModelAndView("AccessTiles");
		}
		
		
		return new ModelAndView("SearchResultWithheld_Tiles");
	}

	@RequestMapping(value = "/getReportListResultwithheld", method = RequestMethod.POST)
	public @ResponseBody ArrayList<ArrayList<String>> getReportListResultwithheld(int startPage, String pageLength,
			String Search, String orderColunm, String orderType, String opd_personal_id, HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		int es_id = Integer.parseInt(
				sessionUserId.getAttribute("es_id") == null ? "0" : sessionUserId.getAttribute("es_id").toString());
		if (es_id != 0) {
			System.err.println("es_id-----------" + es_id);
			return resDao.getReportListResultwithheld(startPage, pageLength, Search, orderColunm, orderType, es_id,
					opd_personal_id, sessionUserId);
		}
		return null;

	}

	@RequestMapping(value = "/getReportListResultwithheldCount", method = RequestMethod.POST)
	public @ResponseBody long getExportPartDTotalCount(HttpSession sessionUserId, String Search,
			String opd_personal_id) {
		int es_id = Integer.parseInt(
				sessionUserId.getAttribute("es_id") == null ? "0" : sessionUserId.getAttribute("es_id").toString());
		if (es_id != 0) {
			return resDao.getReportListResultwithheldCount(Search, es_id, opd_personal_id);
		}
		return es_id;

	}

	@RequestMapping(value = "EditResultWithHeldURL", method = RequestMethod.POST)
	public ModelAndView EditResultWithHeldURL(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String updateid, HttpServletRequest request,
			String typeReport) {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);
		List<RESULTS_WITHHELD_M> list = comm.getStatusForResulWithHeld(sessionFactory, DcryptedPk);
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		int Status = list.get(0).getRes_status_id();
		int oappId = list.get(0).getOa_appllication_id();
		System.out.println("ec_exam_id========"+ec_exam_id);
		System.out.println("Status========"+Status);
		System.out.println("oappId========"+oappId);
		if (Status == 1) {
			Query qry = sessionHQL
					.createQuery("update RESULTS_WITHHELD_M  set res_status_id=:res_status_id where  id=:id");
			qry.setParameter("res_status_id", 0);

			qry.setParameter("id", Integer.parseInt(DcryptedPk));
			System.out.println("query=================="+qry);
			qry.executeUpdate();

			Query qry1 = sessionHQL.createQuery(
					"update OFFICER_APPLICATION_M set oa_status_id=:oa_status_id where oa_application_id=:oa_application_id");
			qry1.setParameter("oa_status_id", 1);
			qry1.setParameter("oa_application_id", oappId);
			qry1.executeUpdate();

			Mmap.put("msg", msg);

			Mmap.put("msg", "The Result Release Successfully");
			tx.commit();
			String es_begindate = session.getAttribute("es_begin_date") == null ? ""
					: session.getAttribute("es_begin_date").toString();
			String es_year = es_begindate.split("-")[0];

			ArrayList<ArrayList<String>>ResultwithHeldData=partbreportDao.getdetailsResultWithHeld(es_id,oappId);

			if (ResultwithHeldData.size() == 0) {

				Mmap.put("msg", "Data Not Available.");
			} else {

				
				Mmap.put("list", ResultwithHeldData);
				Mmap.put("list.size()", ResultwithHeldData.size());
				if (ResultwithHeldData.size() > 0) {

					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new ResultReleasePDFController("L", TH, Heading, username), "userList",
							ResultwithHeldData);

				}

			}


		}
		if (Status == 0) {
			Query qry = sessionHQL
					.createQuery("update RESULTS_WITHHELD_M  set res_status_id=:res_status_id where  id=:id");
			qry.setParameter("res_status_id", 1);

			qry.setParameter("id", Integer.parseInt(DcryptedPk));

			qry.executeUpdate();

			Query qry1 = sessionHQL.createQuery(
					"update OFFICER_APPLICATION_M set oa_status_id=:oa_status_id where oa_application_id=:oa_application_id");
			qry1.setParameter("oa_status_id", 4);
			qry1.setParameter("oa_application_id", oappId);
			qry1.executeUpdate();

			Mmap.put("msg", msg);

			Mmap.put("msg", "The Result With Held  Successfully");

			tx.commit();

		}

		return new ModelAndView("redirect:SearchResultswithheldURL");
	}

	@RequestMapping(value = "/getReleaseReport", method = RequestMethod.POST)
	public ModelAndView getReleaseReport(ModelMap Mmap, HttpSession session, HttpServletRequest request,
			String typeReport, String es_id1, String reportname1, String oapp_id) {
		try {

			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			String enckey = "commonPwdEncKeys";
			String oa_application_id = hex_asciiDao.decrypt((String) oapp_id, enckey, session);
			oa_application_id = oa_application_id.replace(" ", "+");
			int es_id = Integer
					.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

			String es_begindate = session.getAttribute("es_begin_date") == null ? ""
					: session.getAttribute("es_begin_date").toString();
			String es_year = es_begindate.split("-")[0];

			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
					: Integer.parseInt(session.getAttribute("ec_exam_id").toString());

			ArrayList<ArrayList<String>>ResultwithHeldData=partbreportDao.getdetailsResultWithHeld(es_id,Integer.parseInt(oa_application_id));

			if (ResultwithHeldData.size() == 0) {

				Mmap.put("msg", "Data Not Available.");
			} else {

				
				Mmap.put("list", ResultwithHeldData);
				Mmap.put("list.size()", ResultwithHeldData.size());
				if (ResultwithHeldData.size() > 0) {

					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new ResultReleasePDFController("L", TH, Heading, username), "userList",
							ResultwithHeldData);

				}

			}
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("redirect:SearchResultswithheldURL");
	}

}
