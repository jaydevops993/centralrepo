package com.BisagN.dao.officer.others;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Service
public class ExaminationlockunlockDaoImpl implements ExaminationlockunlockDAO {
	
	
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

public boolean checkIsIntegerValue(String Search) {
return Search.matches("[0-9]+");
}
public ArrayList<ArrayList<String>> getbegindatefrmexmschedule(int exm_name) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	String whr = "";

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		if(exm_name != 0) {
			q="where es.ec_exam_id=?";
		}
	
		
		q="select es.es_id as id, TO_CHAR( es.es_begin_date,'DD/MM/YYYY') as  es_begin_date,es.es_status_id,ex.ec_exam_name from exam_schedule es \n"
				+ "inner join exam_code ex on ex.ec_exam_id=es.ec_exam_id "+q+" order by es_id desc  ";
		
		stmt = conn.prepareStatement(q);
		
		if(exm_name != 0) {
		stmt.setInt(1, exm_name);
		
		}
		int i=0;
	
		System.out.println("lock==========="+stmt);
		
		ResultSet rs = stmt.executeQuery();
		
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("es_begin_date"));//1
			list.add(rs.getString("id"));//1
			list.add(rs.getString("es_status_id"));//1
			
			if(rs.getString("es_status_id").equals("0")) {
				list.add("Close");
			}else
			{
				list.add("Open");
				
			}
			list.add(rs.getString("ec_exam_name"));//1
			
			alist.add(list);
			
//			System.err.println("list---------"+list);
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}



public ArrayList<ArrayList<String>> getstatusfrmexmschedule(String exm_name) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	String whr = "";

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q="select es.es_id as id, TO_CHAR( es.es_begin_date,'DD/MM/YYYY') as  es_begin_date,es.es_status_id from exam_schedule es \n"
				+ "inner join exam_code ex on ex.ec_exam_id=es.ec_exam_id where es.es_id::text=? ";
		
		stmt = conn.prepareStatement(q);
		int i=0;
	
		stmt.setString(1, exm_name);
		
		ResultSet rs = stmt.executeQuery();
		
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("id"));//1
			list.add(rs.getString("es_status_id"));//1
			
			if(rs.getString("es_status_id").equals("0")) {
				list.add("Close");
			}else
			{
				list.add("Open");
				
			}
			
			
			alist.add(list);
			
			
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}


public ArrayList<ArrayList<String>> getBeignDateForGnrtbooklet(String exm_name) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	String whr = "";

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		if(!exm_name.equals("")) {
			q="and ex.ec_exam_name=?";
		}
	
		
		q="select es.es_id as id, TO_CHAR( es.es_begin_date,'DD/MM/YYYY') as  es_begin_date,es.es_status_id from exam_schedule es \n"
				+ "inner join exam_code ex on ex.ec_exam_id=es.ec_exam_id where es.es_status_id='1' " +q+"  ";
		
		stmt = conn.prepareStatement(q);
		
		if(!exm_name.equals("")) {
		stmt.setString(1, exm_name);
		
		}
		int i=0;
	
		System.out.println("stmt==========="+stmt);
		
		ResultSet rs = stmt.executeQuery();
		
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("es_begin_date"));//1
			list.add(rs.getString("id"));//1
			list.add(rs.getString("es_status_id"));//1
			
			if(rs.getString("es_status_id").equals("0")) {
				list.add("Close");
			}else
			{
				list.add("Open");
				
			}
			
			
			alist.add(list);
			
			
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

}
