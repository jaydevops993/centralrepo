package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.reports.AbsenteesPDF;
import com.BisagN.controller.office.reports.ArmServiceWiseAnalysisOfResult;
import com.BisagN.controller.office.reports.FullyPassed_Controller_Pdf;
import com.BisagN.controller.office.reports.IndexNoAgainstMarksObtainedController_Pdf;
import com.BisagN.controller.office.reports.IndexNoAgainstPersonalNoandNameController_Pdf;
import com.BisagN.controller.office.reports.IneligibleCandidateReportController;
import com.BisagN.controller.office.reports.PartiallyPassed_Controller_Pdf;
import com.BisagN.controller.office.reports.SubjectWiseAnalysic_Controller_Pdf;
import com.BisagN.controller.office.reports.SummaryPdfController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.Indexing.IndexSlipManualDAO;
import com.BisagN.dao.Indexing.ManageBundleDAO;
import com.BisagN.dao.officer.masters.Area_MasterDAO;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_MASTER;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_MASTER;
import com.BisagN.models.officers.masters.AREA_M;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})

public class IndexSlipController {
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	@Autowired
	CommonController comm;
	@Autowired
	private PartB_ExaminationDAO partBDao;
	
	@Autowired
	IndexSlipManualDAO ismDao;
	
	@Autowired
	ManageBundleDAO MbindxDao;
//===========================OPEN PAGE============================//
		@RequestMapping(value = "IndexSlipUrl", method = RequestMethod.GET)
		public ModelAndView IndexSlipUrl(ModelMap Mmap, HttpSession session,
				@RequestParam(value = "msg", required = false) String msg)
				throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
				NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

			int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
			  
			if(es_id != 0) {
				 List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
				 Mmap.put("es_id", es_id);
				 String index_mode= UnlcokExmsch.get(0).getEs_index_mode();
				 Mmap.put("index_mode", index_mode);
			}
			
			
			int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
			if(esi_es_id != 0) {
			List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esi_es_id);
			Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			
			  int day = date.getDayOfMonth();
			  String[] months = {"Jan", "Feb", "Mar", "Apr" ,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
			  
			  String[] shortMonths = new DateFormatSymbols().getShortMonths();
		        for (String shortMonth : shortMonths) {
		            
		      	 
		        }
			  
			  Month month = date.getMonth();
			  int year = date.getYear();
			String begindateShow= day +" "+ month + " "+ year;
			 
			 Mmap.put("begindateShow",begindateShow);
			 Mmap.put("esid_es_id",esi_es_id);
			
			
			List<EXAMSCHEDULE_INDEXING_DETAIL>ActiveSubject = comm.getActiveIndxSubject(sessionFactory,esi_es_id);
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
			if (esid_sc_subject_id != 0) {
			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
			List<SUBJECT_CODE_M>ActiveSubName= comm.getsubjectIdbysubname( sessionFactory, esid_sc_subject_id, ec_exam_id);
			
			  
			ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
			Mmap.put("getexamcentrelist", examcentrelist);
			 Mmap.put("ActiveSub",ActiveSubName.get(0).getSc_subject_name());
			 List<INDEXED_PACKING_NOTES_MASTER>bundleprefix=  comm.getBundlePrefixList(sessionFactory,esi_es_id,esid_sc_subject_id) ;
			 Mmap.put("bundle_prefix", bundleprefix);
			
		}
			 
			
			
			 
			}
			
			int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
			
			if (esid_sub_subject_id != 0) {
				List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
				String sub_subject_name=SubSubject.get(0).getSub_subject();
				Mmap.put("sub_subject_name", sub_subject_name);
			}
			 Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
			Mmap.put("msg", msg);
			return new ModelAndView("IndexSlip_tiles");
		}
		
	
	
		@RequestMapping(value = "/getIndexSlip_Report", method = RequestMethod.POST)
		public ModelAndView getIndexSlip_Report(ModelMap Mmap, HttpSession session,HttpServletRequest request, String typeReport,String reportname1, String bundle_name1, String bundle_no1,
				String sc_subject_id1,String bundle_name_hid1) {
			try {
				Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction();

				
				int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
				int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
				
				
				int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
				
				
				String ActiveSubjectName="";
				if (esid_sc_subject_id != 0) {
					List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
					Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
					Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());

					List<SUBJECT_CODE_M> ActiveSubName = comm.getsubjectIdbysubname(sessionFactory, esid_sc_subject_id,
							ec_exam_id);

					Mmap.put("ActiveSub", ActiveSubName.get(0).getSc_subject_name());
					
					ActiveSubjectName= ActiveSubName.get(0).getSc_subject_name();

				}
				int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
			
				if(esid_sub_subject_id !=0)
				{
					
						List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
					 ActiveSubjectName=SubSubject.get(0).getSub_subject();
						Mmap.put("sub_subject_name", ActiveSubjectName);
						
				}
				 
				
				 
				if(esid_es_id != 0) {
					
					List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
					Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
					
					
					String es_begindate = session.getAttribute("es_begin_date") == null ? ""
							: session.getAttribute("es_begin_date").toString();
					String es_year1 = es_begindate.split("-")[0];
					String es_begindate_month = es_begindate.split("-")[1];
					 String[] months = {"JAN", "FEB", "MAR", "APR" ,"MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};
						String begin_month = months[Integer.parseInt(es_begindate_month)-1];
					
						
						ArrayList<ArrayList<String>> list = ismDao.GetMasterABList(esid_es_id,String.valueOf(esid_sc_subject_id),bundle_name1, bundle_no1);
						
						
			if(reportname1.equals("m_ablist")) {
				
				if (list.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {
					
					String hq15 = "update INDEXED_BUNDLE_MASTER set ibm_masterab_status_id=:ibm_masterab_status_id  where ibm_id=:ibm_id";
					Query query5 = sessionHQL.createQuery(hq15)
								.setParameter("ibm_masterab_status_id",1)	
								.setParameter("ibm_id",Integer.parseInt(bundle_no1));
								
					query5.executeUpdate();
					tx.commit();
					System.err.println("bundle_name1============="+bundle_name1);
					Mmap.put("list", list);
					Mmap.put("es_year1", es_year1);
					Mmap.put("ActiveSubName", ActiveSubjectName);
					Mmap.put("Bundle", bundle_name_hid1);
					Mmap.put("begin_month", begin_month);
					Mmap.put("list.size()", list.size());
					Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (list.size() > 0) {

						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(new MasterABPdfController("L", TH, Heading, username),"userList",list);

					}
				}
				
				
				}
				
			}	else if(reportname1.equals("exm_sheet")) {
				
				
                 ArrayList<ArrayList<String>> list2 = ismDao.GetMasterABList(esid_es_id,String.valueOf(esid_sc_subject_id),bundle_name1, bundle_no1);
				
				if (list2.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {
					String hq15 = "update INDEXED_BUNDLE_MASTER set ibm_exmsheet_status_id=:ibm_exmsheet_status_id  where ibm_id=:ibm_id";
					Query query5 = sessionHQL.createQuery(hq15)
								.setParameter("ibm_exmsheet_status_id",1)	
								.setParameter("ibm_id",Integer.parseInt(bundle_no1));
								
					query5.executeUpdate();
					tx.commit();
					
					Mmap.put("list", list2);
					Mmap.put("es_year1", es_year1);
					Mmap.put("ActiveSubName", ActiveSubjectName);
					Mmap.put("Bundle", bundle_name_hid1);
					Mmap.put("begin_month", begin_month);
					Mmap.put("list.size()", list.size());
					Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (list2.size() > 0) {

						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(new ExaminersSheetPdfController("L", TH, Heading, username),"userList",list2);

					}
				}
				
				}
			}
			
			
			
			
				}	
				
			} catch (Exception e) {
				e.printStackTrace();
			}

			return new ModelAndView("redirect:IndexSlipUrl");
		}
	
		
		@RequestMapping(value = "/getActiveBundlelist", method = RequestMethod.POST)
		@ResponseBody public ArrayList<ArrayList<String>> getActiveBundlelist(HttpSession session,String bundle_name,String bundle_no,String sc_subject_id) {

			
			int esi_es_id = Integer.parseInt(session.getAttribute("esi_es_id") == null ? "0" : session.getAttribute("esi_es_id").toString());
			ArrayList<ArrayList<String>> list = ismDao.GetActivebundlleName(esi_es_id,sc_subject_id,bundle_name, bundle_no);
			return list;

		}
		
		 @RequestMapping(value = "/getIndexSlipManualDetails", method = RequestMethod.POST)
			public @ResponseBody ArrayList<ArrayList<String>> getIndexSlipManualDetails(int startPage, String pageLength,
					String Search, String orderColunm, String orderType, String sc_subject_id,String bundle_name,String bundle_no,
					String personal_no,String command_id,String center,HttpSession sessionUserId)
					throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
					InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
				int esid_es_id = Integer.parseInt(sessionUserId.getAttribute("esid_es_id") == null ? "0"
						: sessionUserId.getAttribute("esid_es_id").toString());
			 if (esid_es_id != 0) {
				 int ec_exam_id = sessionUserId.getAttribute("ec_exam_id") == null ? 0
							: Integer.parseInt(sessionUserId.getAttribute("ec_exam_id").toString());
				 int esid_sc_subject_id = sessionUserId.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(sessionUserId.getAttribute("esid_sc_subject_id").toString());
				 int esid_sub_subject_id = sessionUserId.getAttribute("esid_sub_subject_id") == null ? 0
							: Integer.parseInt(sessionUserId.getAttribute("esid_sub_subject_id").toString());
				 return ismDao.getIndexSlipManualDetails(startPage, pageLength, Search, orderColunm, orderType,ec_exam_id,esid_es_id, esid_sc_subject_id,
						bundle_name,bundle_no,personal_no,command_id,center,esid_sub_subject_id,sessionUserId);
			
					
					}
			return null;
			}

			@RequestMapping(value = "/getTotolCountIndexSlipManualDetails", method = RequestMethod.POST)
			public @ResponseBody long getTotolCountIndexSlipManualDetails(HttpSession sessionUserId, String Search, String sc_subject_id,String bundle_name,String bundle_no,
					String personal_no,String command_id,String center) {
				
				int esid_es_id = Integer.parseInt(sessionUserId.getAttribute("esid_es_id") == null ? "0"
						: sessionUserId.getAttribute("esid_es_id").toString());
			 if (esid_es_id != 0) {
				 
				 int ec_exam_id = sessionUserId.getAttribute("ec_exam_id") == null ? 0
							: Integer.parseInt(sessionUserId.getAttribute("ec_exam_id").toString());
				 int esid_sub_subject_id = sessionUserId.getAttribute("esid_sub_subject_id") == null ? 0
							: Integer.parseInt(sessionUserId.getAttribute("esid_sub_subject_id").toString());
				 int esid_sc_subject_id = sessionUserId.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(sessionUserId.getAttribute("esid_sc_subject_id").toString());
				return ismDao.getTotalCountgetIndexSlipManualDetails(Search,ec_exam_id, esid_es_id,esid_sc_subject_id,bundle_name,bundle_no,personal_no,command_id,center,esid_sub_subject_id);
			 }
			return esid_es_id;
			 }
			
			
			 @RequestMapping(value = "/getBundleNoByBagNo", method = RequestMethod.POST)
				@ResponseBody public ArrayList<ArrayList<String>> getBundleNoByBagNo(String bundle_packing_id,HttpSession session) {
				 
					int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
					if(esid_es_id != 0) {
						 String userId = session.getAttribute("userId").toString();
						 String role = session.getAttribute("role").toString();
					ArrayList<ArrayList<String>>list = ismDao.getBunldeNoByPackingBundle(esid_es_id,Integer.parseInt(userId),bundle_packing_id,role);
					return list;
					
					}
					return null;

				}
			 
			 
			 @RequestMapping(value = "/getBundleStausForPrint", method = RequestMethod.POST)
				@ResponseBody public ArrayList<ArrayList<String>> getBundleStausForPrint(String ibm_id,HttpSession session) {
				 
					int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
					if(esid_es_id != 0) {
						
						String userId = session.getAttribute("userId").toString();
						String role = session.getAttribute("role").toString();
						ArrayList<ArrayList<String>>BundleallDetails =MbindxDao.getIndxSlipCountByIbm( esid_es_id, Integer.parseInt(ibm_id),Integer.parseInt(userId),role);
					return BundleallDetails;
					
					}
					return null;

				}
			 
			 @RequestMapping(value = "/deleteIndexSlip", method = RequestMethod.POST) 
			  public ModelAndView deleteIndexSlip(String EncryptedPk1,String EPk1,HttpSession session,ModelMap model) { 
			  	String deleteid=EncryptedPk1;
			  	List<String> list = new ArrayList<String>(); 
				Session sessionHQL = this.sessionFactory.openSession();
				String enckey = "commonPwdEncKeys";
				String DcryptedPk = hex_asciiDao.decrypt((String) deleteid,enckey,session);
				Transaction tx = sessionHQL.beginTransaction();
				
				String DcryptedEPk1 = hex_asciiDao.decrypt((String) EPk1,enckey,session);
				 
				int rowcoun=0;
				
			  	try {
			  	
			  		String hq1l = "delete from INDEX_SLIP_MANUAL where is_ism_id=:is_ism_id ";
					Query query1 = sessionHQL.createQuery(hq1l).setParameter("is_ism_id",
							Integer.parseInt(DcryptedPk));
					rowcoun=query1.executeUpdate();
			  		
			  System.err.println("====is_ism_id===="+DcryptedPk);

				  if(rowcoun > 0) {
						 
						String hql = "delete from  TB_BARCODE_COUNT where is_id=:is_id ";
						Query query = sessionHQL.createQuery(hql).setParameter("is_id",
								Integer.parseInt(DcryptedEPk1));
						rowcoun=query.executeUpdate();
				  
						  System.err.println("====is_ism_id===="+DcryptedEPk1);
			
				  }
				  if(rowcoun > 0) {
						model.put("msg", "Deleted Successfully");
						 
					}else {
						model.put("msg", "Deleted not Successfully");
					 
			 	}
				
				tx.commit();
				
			  	}
				  catch (RuntimeException e) {
					e.printStackTrace();
					tx.rollback();

					model.put("msg", "Server side Error");

				}

			    return new ModelAndView("redirect:IndexSlipUrl"); 
			  	}
			 
			 
			 
//			  @RequestMapping(value = "/deleteIndexSlip", method = RequestMethod.POST) 
//			  public ModelAndView deleteIndexSlip(String EncryptedPk1,String EPk1,HttpSession session,ModelMap model) { 
//			  	String deleteid=EncryptedPk1;
//			  	List<String> list = new ArrayList<String>(); 
//				Session sessionHQL = this.sessionFactory.openSession();
//				String enckey = "commonPwdEncKeys";
//				String DcryptedPk = hex_asciiDao.decrypt((String) deleteid,enckey,session);
//				Transaction tx = sessionHQL.beginTransaction();
//				
//				String DcryptedEPk1 = hex_asciiDao.decrypt((String) EPk1,enckey,session);
//				
//				System.err.println("DcryptedPk============="+DcryptedPk);
//				
//				System.err.println("EPk1============="+DcryptedEPk1);
//				
//				int rowcoun=0;
//				
//			  	try {
//			  	
//			  		String hq1l = "update INDEX_SLIP_MANUAL set is_status=:is_status  where is_ism_id=:is_ism_id ";
//					Query query1 = sessionHQL.createQuery(hq1l).setParameter("is_status", 0).setParameter("is_ism_id",
//							Integer.parseInt(DcryptedPk));
//					rowcoun=query1.executeUpdate();
//			  		
//			  
//
//				  if(rowcoun > 0) {
//						 
//						String hql = "update TB_BARCODE_COUNT set brcd_status=:brcd_status  where is_id=:is_id ";
//						Query query = sessionHQL.createQuery(hql).setParameter("brcd_status", 0).setParameter("is_id",
//								Integer.parseInt(DcryptedEPk1));
//						rowcoun=query.executeUpdate();
//				  
//			
//				  }
//				  if(rowcoun > 0) {
//						model.put("msg", "Deleted Successfully");
//						 
//					}else {
//						model.put("msg", "Deleted not Successfully");
//					 
//			 	}
//				
//				tx.commit();
//				
//			  	}
//				  catch (RuntimeException e) {
//					e.printStackTrace();
//					tx.rollback();
//
//					model.put("msg", "Server side Error");
//
//				}
////			  	model.put("msg",list);  
//			    return new ModelAndView("redirect:IndexSlipUrl"); 
//			  	}
			 
			  
			 @RequestMapping(value = "/getGroup_usernames", method = RequestMethod.POST)
				@ResponseBody public ArrayList<ArrayList<String>> getGroup_usernames(int userid,HttpSession session) {
				 
				 System.err.println("+++++userid+++++++"+userid);
				  
					ArrayList<ArrayList<String>>list = ismDao.getGroupusername(userid);
					return list;
					 

				}
			 @RequestMapping(value = "/getdateIndexDetailsForBarocde", method = RequestMethod.POST)
				@ResponseBody public ArrayList<ArrayList<String>> getdateIndexDetailsForBarocde(int startPage, String pageLength,
						String Search, String orderColunm, String orderType,String usrename,String role,HttpSession session) {
				 
				 System.err.println("==usrename===="+usrename);
			 
				  
				 int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
					
				 int  es_id = Integer.parseInt(
							session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
				 
//				 String role = session.getAttribute("role").toString();
				 
					ArrayList<ArrayList<String>>list = ismDao.dateIndexDetailsForBarocde(startPage, pageLength, Search, orderColunm, orderType,es_id ,usrename ,esid_sc_subject_id , role );
					return list;
					 

				}
			 
			 @RequestMapping(value = "/getcountdateIndexDetailsForBarocde", method = RequestMethod.POST)
				@ResponseBody public ArrayList<ArrayList<String>> getdateIndexDetailsForBarocde( String usrename,String role,HttpSession session) {
				 
				 System.err.println("==usrename===="+usrename);
			 
				  
				 int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
					
				 int  es_id = Integer.parseInt(
							session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
				 
//				 String role = session.getAttribute("role").toString();
				 
					ArrayList<ArrayList<String>>list = ismDao.getcountdateIndexDetailsForBarocde( es_id ,usrename ,esid_sc_subject_id , role );
					return list;
					 

				}
			 
			 
}