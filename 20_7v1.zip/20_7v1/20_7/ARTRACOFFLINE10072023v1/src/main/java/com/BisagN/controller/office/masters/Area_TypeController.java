package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.Area_MasterDAO;
import com.BisagN.dao.officer.masters.Area_TypeDAO;
import com.BisagN.models.officers.masters.AREA_M;
import com.BisagN.models.officers.masters.AREA_TYPE;


@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Area_TypeController {

	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private Area_TypeDAO objDAO;
	
	 @Autowired
		private RoleBaseMenuDAO roledao;  
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	//===========================OPEN PAGE============================//
		@RequestMapping(value = "AreaTypeMasterUrl", method = RequestMethod.GET)
		public ModelAndView AreaTypeMasterUrl(ModelMap Mmap, HttpSession session,HttpServletRequest request,
				@RequestParam(value = "msg", required = false) String msg)
				throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
				NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
			
			
			if(request.getHeader("Referer") == null ) { 
   			 session.invalidate();
   			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
   			 return new ModelAndView("redirect:/login");
   		 }

       	 String roleid1 = session.getAttribute("roleid").toString();
   		 Boolean val = roledao.ScreenRedirect("AreaTypeMasterUrl", roleid1);		
   			if(val == false) {
   				return new ModelAndView("AccessTiles");
   		}	

			Mmap.put("msg", msg);
			return new ModelAndView("AreaTypeTiles","AreaTypeMstCMD", new AREA_TYPE());
		}
		
		//============================SAVE==========================//
		  
		  @RequestMapping(value = "/AreaTypeMasterAction" ,method = RequestMethod.POST) 
		  public ModelAndView AreaTypeMasterAction( @ModelAttribute("AreaTypeMstCMD") AREA_TYPE ln, BindingResult result, 
		  HttpServletRequest request, ModelMap model, HttpSession session){ 
			  
//				int errCount = 0;
//
//				if (request.getParameter("area_type").equals("") || request.getParameter("area_type") == null) {
//					errCount++;
//					model.put("area_type_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Choice Name");
//				}
//				if (errCount > 0) {
//
//					return new ModelAndView("AreaTypeTiles");
//				}
			  
			  
			  String area_type=request.getParameter("area_type");
				if(area_type == "" || area_type.equals("")) {
					model.put("msg", "Please Enter Area Type");		
					return new ModelAndView("redirect:AreaTypeMasterUrl");
				}

				int id = ln.getArea_type_id() > 0 ? ln.getArea_type_id() : 0;
				Date date = new Date();
				String username = session.getAttribute("username").toString();
				Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction(); 

			try {

				Query q0 = sessionHQL.createQuery(
						"select count(id) from AREA_TYPE where LOWER(area_type)=:area_type and area_type_id!=:id");

				q0.setParameter("area_type", ln.getArea_type().toLowerCase());
				q0.setParameter("id", id);
				Long c = (Long) q0.uniqueResult();

				
				if (id == 0) {
					ln.setCreated_by(username);
					ln.setCreated_date(date);
					ln.setArea_status_id(1);
					
					if (c == 0) {

						sessionHQL.save(ln);
						sessionHQL.flush();
						sessionHQL.clear();
						model.put("msg", "Data Saved Successfully.");

					} else {
						model.put("msg", "Data already Exist.");
					}
				}

			
				tx.commit();
			} catch (RuntimeException e) {
				try {
					tx.rollback();
					model.put("msg", "roll back transaction");
				} catch (RuntimeException rbe) {
					model.put("msg", "Couldn�t roll back transaction " + rbe);
				}
				throw e;
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}

			return new ModelAndView("redirect:AreaTypeMasterUrl");
		}
		
		  
		//=======================SEARCH============================//
		  
		  @RequestMapping(value = "/getArea_Type_MasterReportDataList", method = RequestMethod.POST)
			 public @ResponseBody List<Map<String, Object>> getArea_Type_MasterReportDataList(int startPage,
					 String pageLength,String Search,String orderColunm,String orderType,HttpSession sessionUserId) 
				     throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, 
				     InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
				
			  return objDAO.getReportListArea_TypeMaster(startPage,pageLength,Search,orderColunm,orderType,sessionUserId);
			}

			 
			 @RequestMapping(value = "/getArea_Type_MasterTotalCount", method = RequestMethod.POST)
			public @ResponseBody long getArea_Type_MasterTotalCount(HttpSession sessionUserId,String Search,String name){
				 
				return objDAO.getReportListArea_TypeMasterTotalCount(Search);
			}
			 
			 //=============================EDIT OPEN PAGE=============================//
			 
	         @RequestMapping(value = "EditArea_TypeMasterUrl", method = RequestMethod.POST)
	         public ModelAndView EditArea_TypeMasterUrl(ModelMap Mmap,HttpSession session,
	        		 @RequestParam(value = "msg", required = false) String msg,String updateid) {

	                Session s1 = this.sessionFactory.openSession();
	                Transaction tx = s1.beginTransaction();
	                
	                String enckey = "commonPwdEncKeys";  
	                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
	                
	                Query q = null;
	                q = s1.createQuery("from AREA_TYPE where cast(area_type_id as string)=:PK");
	                q.setString("PK", DcryptedPk);
	                
	                @SuppressWarnings("unchecked")
	                List<String> list = (List<String>) q.list();
	                tx.commit();
	                s1.close();
	              
	                Mmap.put("EditAreaTypeMstCMD1", list.get(0));
	                Mmap.put("msg", msg);
	                
	         return new ModelAndView("EditAreaTypeMasterTiles","EditAreaTypeMstCMD",new AREA_TYPE());
	}
			 
	         
	       //============================UPDATE========================//
	         @RequestMapping(value = "/EditAreaTypeMasterAction" ,method = RequestMethod.POST) 
	   	  public ModelAndView EditAreaTypeMasterAction( @ModelAttribute("EditAreaMstCMD") AREA_TYPE ln, BindingResult result, 
	   	  HttpServletRequest request, ModelMap model, HttpSession session){ 

	        	 
//	        	 int errCount = 0;
//
//					if (request.getParameter("area_type").equals("") || request.getParameter("area_type") == null) {
//						errCount++;
//						model.put("area_type_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Choice Name");
//					}
//					if (errCount > 0) {
//
//						return new ModelAndView("EditAreaTypeMasterTiles");
//					}

	        	 
	        	 String area_type=request.getParameter("area_type");
					if(area_type == "" || area_type.equals("")) {
						model.put("msg", "Please Enter Area Type");		
						return new ModelAndView("redirect:AreaTypeMasterUrl");
					}
	        	 
	        	 
	        Date date = new Date();
	     	String username = session.getAttribute("username").toString();
	   	    Session sessionHQL = this.sessionFactory.openSession();
	   	    Transaction tx = sessionHQL.beginTransaction(); 
	   	    
	   	    ln.setArea_type_id(Integer.parseInt(request.getParameter("id")));
	   		ln.setArea_status_id(1);
	   	    sessionHQL.saveOrUpdate(ln); 
	   	    ln.setModified_by(username);
			ln.setModified_date(date);
			
	   	    tx.commit(); 
	   	    sessionHQL.close(); 
	   	 
	   	    model.put("msg","Data Updated Successfully"); 
	   	    return new ModelAndView("redirect:AreaTypeMasterUrl"); 
	   	  } 
			 
			 //=======================DELETE===========================//
			 @RequestMapping(value = "/DeleteArea_TypeMasterUrl", method = RequestMethod.POST) 
			  public ModelAndView DeleteArea_TypeMasterUrl(String deleteid,HttpSession session,ModelMap model) { 
				 
			  	List<String> list = new ArrayList<String>(); 
			  	list.add(objDAO.DeleteArea_TypeMaster(deleteid,session)); 
			  	
			  	model.put("msg",list);  
			  	
			    return new ModelAndView("redirect:AreaTypeMasterUrl"); 
			    
			  	}
		
}
