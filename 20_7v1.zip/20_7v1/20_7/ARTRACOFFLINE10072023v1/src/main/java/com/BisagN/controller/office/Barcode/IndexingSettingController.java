package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXING_SETTING;
import com.BisagN.models.officers.masters.AREA_M;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.PARTB_D_APPLICATION_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class IndexingSettingController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	CommonController comm;

	@RequestMapping(value = "IndexingSettingUrl", method = RequestMethod.GET)
	public ModelAndView IndexingSettingUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

		if (es_id != 0) {
			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, es_id);
			if(!UnlcokExmsch.isEmpty()) {
			Date begin_date = UnlcokExmsch.get(0).getEs_begin_date();
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			Mmap.put("es_id", es_id);
			int day = date.getDayOfMonth();
			String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

			String[] shortMonths = new DateFormatSymbols().getShortMonths();
			for (String shortMonth : shortMonths) {

			}

			Month month = date.getMonth();
			int year = date.getYear();
			String begindateShow = day + " " + month + " " + year;

			Mmap.put("begindateShow", begindateShow);
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
					: Integer.parseInt(session.getAttribute("ec_exam_id").toString());

			if (ec_exam_id != 0) {
				List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
				Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
				Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());

			}
			List<INDEXING_SETTING> bundledetails = comm.getbundledetailsforindexing(sessionFactory, es_id);
			List<EXAM_SCHEDULE>getIndexModeByEsId=comm.getUnlockExamSchedule( sessionFactory,  es_id);
			if (!bundledetails.isEmpty()) {
				Mmap.put("bundledetails", bundledetails);
				if (!getIndexModeByEsId.isEmpty()) {
					Mmap.put("indexmode", getIndexModeByEsId.get(0).getEs_index_mode());
				}
			}
			
			}

		}
		Mmap.put("msg", msg);
		return new ModelAndView("IndexingSetting_tile");
	}

	@RequestMapping(value = "/IndexingSettingACtion", method = RequestMethod.POST)
	public ModelAndView IndexingSettingACtion(@ModelAttribute("IndexingSettinCMD") INDEXING_SETTING indexingsetting,
			BindingResult result, HttpServletRequest request, ModelMap model, HttpSession session) {
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		try {

			String max_bundle = request.getParameter("ist_maxab_bundle");
			String ist_min_indexno = request.getParameter("ist_min_indexno");
			String ist_max_indexno = request.getParameter("ist_max_indexno");
			String ist_maxbundle_package = request.getParameter("ist_maxbundle_package");
			String ist_maxab_bundle_pkg = request.getParameter("ist_maxab_bundle_pkg");

			if (max_bundle.equals("")) {
				model.put("msg", "Please Enter Max Answer book Bundle");
				return new ModelAndView("redirect:IndexingSettingUrl");
			}

			if (ist_maxbundle_package.equals("")) {
				model.put("msg", "Please Enter Max Bundle Package");
				return new ModelAndView("redirect:IndexingSettingUrl");
			}

			if (ist_min_indexno.equals("")) {
				model.put("msg", "Please Enter Min Index  No");
				return new ModelAndView("redirect:IndexingSettingUrl");
			}
			if (ist_max_indexno.equals("")) {
				model.put("msg", "Please Enter Max Index  No");
				return new ModelAndView("redirect:IndexingSettingUrl");
			}

			String username = session.getAttribute("username").toString();
			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			int id = indexingsetting.getIst_id() > 0 ? indexingsetting.getIst_id() : 0;
			
			String es_index_mode = request.getParameter("es_index_mode");
			int es_id = Integer
					.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

			Query q0 = sessionHQL.createQuery(
					"select count(ist_id) from INDEXING_SETTING where ist_es_id=:ist_es_id and ist_id=:ist_id ");

			q0.setParameter("ist_es_id", es_id);
			q0.setParameter("ist_id", id);
			Long c = (Long) q0.uniqueResult();

			if (id == 0) {

				if (c == 0) {

					
					String hq14 = "update EXAM_SCHEDULE set es_index_mode=:es_index_mode  where es_id=:es_id ";
					Query query4 = sessionHQL.createQuery(hq14)
							.setParameter("es_index_mode", es_index_mode)
							.setParameter("es_id", es_id);
					query4.executeUpdate();
					
					
					
					
					indexingsetting.setCreated_by(username);
					indexingsetting.setCreated_date(date);
					indexingsetting.setIst_es_id(es_id);

					indexingsetting.setIst_max_indexno(Integer.parseInt(ist_max_indexno));
					indexingsetting.setIst_maxbundle_package(Integer.parseInt(ist_maxbundle_package));
					indexingsetting.setIst_min_indexno(Integer.parseInt(ist_min_indexno));
					indexingsetting.setIst_maxab_bundle(Integer.parseInt(max_bundle));
					indexingsetting.setIst_max_bundle(Integer.parseInt(ist_maxab_bundle_pkg));

					sessionHQL.save(indexingsetting);
					sessionHQL.flush();
					sessionHQL.clear();
					tx.commit();

					model.put("msg", "Data Saved Successfully");	

					

				} else {

					model.put("msg", "Data already Exist");
				}

			}

		}

		catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}
		
		
		
		return new ModelAndView("redirect:IndexingSettingUrl");
	
	}

}