package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "examschedule_indexing", uniqueConstraints = { @UniqueConstraint(columnNames = "esi_es_id"), })
public class EXAMSCHEDULE_INDEXING {
	
	
	
	private int esi_es_id;
	private int  esi_islocked ;
	 private Date  esi_dtupdatetime;
	 private int  esi_createdby;
	    private Date esi_createdate;
	    private int  esi_updatedby;
	    private Date  esi_updateddate;
	    
	    
	    
	    @Id
		@Column(name = "esi_es_id", unique = true, nullable = false)
		public int getEsi_es_id() {
			return esi_es_id;
		}
		public void setEsi_es_id(int esi_es_id) {
			this.esi_es_id = esi_es_id;
		}
		public int getEsi_islocked() {
			return esi_islocked;
		}
		public void setEsi_islocked(int esi_islocked) {
			this.esi_islocked = esi_islocked;
		}
		public Date getEsi_dtupdatetime() {
			return esi_dtupdatetime;
		}
		public void setEsi_dtupdatetime(Date esi_dtupdatetime) {
			this.esi_dtupdatetime = esi_dtupdatetime;
		}
		public int getEsi_createdby() {
			return esi_createdby;
		}
		public void setEsi_createdby(int esi_createdby) {
			this.esi_createdby = esi_createdby;
		}
		public Date getEsi_createdate() {
			return esi_createdate;
		}
		public void setEsi_createdate(Date esi_createdate) {
			this.esi_createdate = esi_createdate;
		}
		public int getEsi_updatedby() {
			return esi_updatedby;
		}
		public void setEsi_updatedby(int esi_updatedby) {
			this.esi_updatedby = esi_updatedby;
		}
		public Date getEsi_updateddate() {
			return esi_updateddate;
		}
		public void setEsi_updateddate(Date esi_updateddate) {
			this.esi_updateddate = esi_updateddate;
		}
	    
	    
	    
	    

}
