package com.BisagN.controller.office.Generalreports;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.StyleConstants.ColorConstants;

import org.apache.poi.hssf.record.RightMarginRecord;
import org.apache.poi.ss.usermodel.Color;
import org.apache.poi.xwpf.usermodel.TextAlignment;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.ListItem;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;



public class Unfair_Means extends AbstractPdfView{

	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public Unfair_Means(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		document.setPageSize(PageSize.A4.rotate());
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		String es_year =  (String) model.get("es_year");
//		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
//		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
//		Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
		
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
	    Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 1);
	    Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
		
		
		
		
		
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		Chunk underline1 = new Chunk( "UNFAIR MEANS" , fontTableHeading1);	 
		underline1.setUnderline(0.1f, -2f);
		
		Phrase ph = new Phrase(underline1);
		ph.add("\n");
		ph.add("\n");
		ph.add("\n");
		ph.setFont(fontTableHeading1);

		
		Paragraph cell = new Paragraph(ph);
		cell.setAlignment(Element.ALIGN_LEFT);
		
		cell.setAlignment(Element.ALIGN_LEFT);
		
		
		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell);
		
		PdfPTable tabledata = new PdfPTable(5);
		tabledata.setWidths(new int[] {1,2,1,8,2});
		tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata.setWidthPercentage(100);
		
		ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");
		
		Paragraph a = new Paragraph("Ser No",fontTableHeadingSubMainHead);
		Paragraph b = new Paragraph("Personal No",fontTableHeadingSubMainHead);
		Paragraph c = new Paragraph("Rank",fontTableHeadingSubMainHead);
		Paragraph d = new Paragraph("Name",fontTableHeadingSubMainHead);
		Paragraph e = new Paragraph("Remarks",fontTableHeadingSubMainHead);
		
		
		
		
		 PdfPCell blank_cella;
		 blank_cella = new PdfPCell(a);
		 blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
		 
		 

		 PdfPCell blank_cellb;
		 blank_cellb = new PdfPCell(b);
		 blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
		 
		 
		 PdfPCell blank_cellc;
		 blank_cellc = new PdfPCell(c);
		 blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
		
		
		 PdfPCell blank_celld;
		 blank_celld = new PdfPCell(d);
		 blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
		
		 PdfPCell blank_celle;
		 blank_celle = new PdfPCell(e);
		 blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);

		 
		
		 
		 
		 
			 tabledata.addCell(blank_cella);
			 tabledata.addCell(blank_cellb);
			 tabledata.addCell(blank_cellc);
			 tabledata.addCell(blank_celld);
			 tabledata.addCell(blank_celle);
			 
//				Paragraph F2 = new Paragraph("No",fontTableHeadingSubMainHead);
//				Paragraph G2 = new Paragraph("Rk & Name",fontTableHeadingSubMainHead);
//				
//				tabledata.addCell(F2);
//				tabledata.addCell(G2);
			 
			 
			 int  index=1;
			 for(int i=0;i<list.size();i++)
			 {
			
				 List<String> l = list.get(i);
			 Paragraph a1index = new Paragraph(String.valueOf(index),fontTableHeadingdata);
			 Paragraph pers_code = new Paragraph(l.get(0),fontTableHeadingdata);
			 Paragraph rank = new Paragraph(l.get(1),fontTableHeadingdata);
			 Paragraph name = new Paragraph(l.get(2),fontTableHeadingdata);
			 Paragraph remarks = new Paragraph(l.get(3),fontTableHeadingdata);
			 
			 
			 
			 PdfPCell cell2 = new PdfPCell();
			 
				 tabledata.addCell(a1index);
				 cell2.setPhrase(pers_code);
				 cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
				 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
				 tabledata.addCell(cell2);
				 cell2.setPhrase(rank);
				 tabledata.addCell(cell2);
				 cell2.setPhrase(name);
				 cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
				 tabledata.addCell(cell2);
				 tabledata.addCell(remarks);
				 
				 //tabledata.addCell(rank);
				// tabledata.addCell(subject);
				 
				 index+=1;
				
			 }
		 
		PdfPCell cell123;
		cell123 = new PdfPCell();
		
		cell123.addElement(tableheader);
		cell123.addElement(tabledata);
		cell123.addElement(new Paragraph("\n"));
		cell123.setBorder(0);
		table.addCell(cell123);

		document.add(table);
		super.buildPdfMetadata(model, document, request);
	}

	
	
}
