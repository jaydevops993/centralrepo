package com.BisagN.dao.officer.trans;

import java.util.List;
import java.util.Map;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import org.apache.commons.codec.binary.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import org.hibernate.Session;
import java.util.ArrayList;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;


public interface Marks_entryDAO {

public List<Map<String, Object>> getReportListMarks_entry(int startPage,String pageLength,String Search,String orderColunm,String orderType,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
public long getReportListMarks_entryTotalCount(String Search);
public String Deletemarks_entry(String deleteid,HttpSession session);
}
