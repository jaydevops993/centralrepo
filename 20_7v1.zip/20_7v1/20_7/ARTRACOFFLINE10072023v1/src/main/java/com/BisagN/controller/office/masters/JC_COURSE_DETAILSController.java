package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.JC_COURSE_DETAILSDAO;
import com.BisagN.models.officers.masters.JC_COURSE_M;




@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class JC_COURSE_DETAILSController {


@Autowired
private JC_COURSE_DETAILSDAO objDAO;

@Autowired
private RoleBaseMenuDAO roledao;

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();


         @RequestMapping(value = "JC_COURSE_DETAILS_Url", method = RequestMethod.GET)
         public ModelAndView JC_COURSE_DETAILS_Url(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
  NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

        	 
        		if (request.getHeader("Referer") == null) {
    				session.invalidate();
    				Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
    				return new ModelAndView("redirect:/login");
    			}

    			String roleid1 = session.getAttribute("roleid").toString();
    			Boolean val = roledao.ScreenRedirect("JC_COURSE_DETAILS_Url", roleid1);
    			if (val == false) {
    				return new ModelAndView("AccessTiles");
    			}
        	 
             Mmap.put("msg", msg);
         return new ModelAndView("JC_COURSE_DETAILS_tile","JC_COURSE_DETAILSCMD",new JC_COURSE_M());
}
 @RequestMapping(value = "/getJC_COURSE_DETAILSReportDataList", method = RequestMethod.POST)
 public @ResponseBody List<Map<String, Object>> getJC_COURSE_DETAILSReportDataList(int startPage,String pageLength,String Search,String orderColunm,String orderType,HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
	return objDAO.getReportListJC_COURSE_DETAILS(startPage,pageLength,Search,orderColunm,orderType,sessionUserId);
}

 @RequestMapping(value = "/getJC_COURSE_DETAILSTotalCount", method = RequestMethod.POST)
public @ResponseBody long getJC_COURSE_DETAILSTotalCount(HttpSession sessionUserId,String Search,String name){
	return objDAO.getReportListJC_COURSE_DETAILSTotalCount(Search);
}
  @RequestMapping(value = "/JC_COURSE_DETAILSAction" ,method = RequestMethod.POST) 
  public ModelAndView JC_COURSE_DETAILSAction(@Valid @ModelAttribute("JC_COURSE_DETAILSCMD") JC_COURSE_M ln, BindingResult result, 
  HttpServletRequest request, ModelMap model, HttpSession session){ 

 
	  if(request.getParameter("jcc_no").equals("") || request.getParameter("jcc_no")==null ||
				request.getParameter("jcc_no")=="null" || request.getParameter("jcc_no").equals(null))
		{
			model.put("msg", "Please Enter JC Course No");
			return new ModelAndView("redirect:JC_COURSE_DETAILS_Url");
		}
	     String jcc_beg_date=request.getParameter("jcc_beg_date");
		String jcc_end_date=request.getParameter("jcc_end_date");
		
	  if (jcc_beg_date.equals("DD/MM/YYYY") || jcc_beg_date.equals("") || jcc_beg_date == "" || jcc_beg_date == "DD/MM/YYYY") {
			model.put("msg", "Please Enter Begin Date");
			return new ModelAndView("redirect:JC_COURSE_DETAILS_Url");
		}
	  if (jcc_end_date.equals("DD/MM/YYYY") || jcc_end_date.equals("") || jcc_end_date == "" || jcc_end_date == "DD/MM/YYYY") {
			model.put("msg", "Please Enter End Date");
			return new ModelAndView("redirect:JC_COURSE_DETAILS_Url");
		}
// int errCount=0;
//
//    if(request.getParameter("jcc_beg_date").equals("") || request.getParameter("jcc_beg_date") == null) 
//    { 
// errCount ++;
// model.put("jcc_beg_date_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter BEG DATE");
//    } 
//    if(request.getParameter("jcc_end_date").equals("") || request.getParameter("jcc_end_date") == null) 
//    { 
// errCount ++;
// model.put("jcc_end_date_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter END DATE");
//    } 
//    if(request.getParameter("jcc_no").equals("") || request.getParameter("jcc_no") == null) 
//    { 
// errCount ++;
// model.put("jcc_no_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter JC COURSE No");
//    } 
// if(errCount > 0) {
//
//     return new ModelAndView("JC_COURSE_DETAILS_tile");
//  }

 int id = ln.getJcc_id() > 0 ? ln.getJcc_id() : 0;
	Date date = new Date();
	String username = session.getAttribute("username").toString();
	 Session sessionHQL = this.sessionFactory.openSession();
	    Transaction tx = sessionHQL.beginTransaction(); 

	try {

		Query q0 = sessionHQL.createQuery(
				"select count(id) from JC_COURSE_M where   jcc_no=:jcc_no and jcc_id!=:jcc_id");

		q0.setParameter("jcc_no", ln.getJcc_no());
		q0.setParameter("jcc_id", id);
		Long c = (Long) q0.uniqueResult();

		
		if (id == 0) {
			ln.setJcc_created_by(username);
			ln.setJcc_creation_date(date);
			ln.setJcc_status_id(1);
			
			if (c == 0) {

				sessionHQL.save(ln);
				sessionHQL.flush();
				sessionHQL.clear();
				model.put("msg", "Data Saved Successfully.");

			} else {
				model.put("msg", "Data already Exist.");
			}
		}

	
		tx.commit();
	} catch (RuntimeException e) {
		try {
			tx.rollback();
			model.put("msg", "roll back transaction");
		} catch (RuntimeException rbe) {
			model.put("msg", "Couldn�t roll back transaction " + rbe);
		}
		throw e;
	} finally {
		if (sessionHQL != null) {
			sessionHQL.close();
		}
	}

	return new ModelAndView("redirect:JC_COURSE_DETAILS_Url");
}
  
         @RequestMapping(value = "EditJC_COURSE_DETAILSUrl", method = RequestMethod.POST)
         public ModelAndView EditJC_COURSE_DETAILSUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String updateid) {


                Session s1 = this.sessionFactory.openSession();
                Transaction tx = s1.beginTransaction();
                String enckey = "commonPwdEncKeys";  
                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
                Query q = null;
                q = s1.createQuery("from JC_COURSE_M where cast(id as string)=:PK");
                q.setString("PK", DcryptedPk);
                @SuppressWarnings("unchecked")
                List<String> list = (List<String>) q.list();
                tx.commit();
                s1.close();
                Mmap.put("EditJC_COURSE_DETAILSCMD1", list.get(0));
                Mmap.put("msg", msg);
         return new ModelAndView("EditJC_COURSE_DETAILS_tile","EditJC_COURSE_DETAILSCMD",new JC_COURSE_M());
}
  @RequestMapping(value = "/EditJC_COURSE_DETAILSAction" ,method = RequestMethod.POST) 
  public ModelAndView EditJC_COURSE_DETAILSAction(@Valid @ModelAttribute("EditJC_COURSE_DETAILSCMD") JC_COURSE_M ln, BindingResult result, 
  HttpServletRequest request, ModelMap model, HttpSession session){ 

 
// int errCount=0;
//
//    if(request.getParameter("jcc_beg_date").equals("") || request.getParameter("jcc_beg_date") == null) 
//    { 
// errCount ++;
// model.put("jcc_beg_date_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter BEG DATE");
//    } 
//    if(request.getParameter("jcc_end_date").equals("") || request.getParameter("jcc_end_date") == null) 
//    { 
// errCount ++;
// model.put("jcc_end_date_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter END DATE");
//    } 
//    if(request.getParameter("jcc_no").equals("") || request.getParameter("jcc_no") == null) 
//    { 
// errCount ++;
// model.put("jcc_no_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter JC COURSE No");
//    } 
// if(errCount > 0) {
//
//     return new ModelAndView("EditJC_COURSE_DETAILS_tile");
//  }
	  if(request.getParameter("jcc_no").equals("") || request.getParameter("jcc_no")==null ||
				request.getParameter("jcc_no")=="null" || request.getParameter("jcc_no").equals(null))
		{
			model.put("msg", "Please Enter JC Course No");
			return new ModelAndView("redirect:EditJC_COURSE_DETAILSUrl");
		}
	     String jcc_beg_date=request.getParameter("jcc_beg_date");
		String jcc_end_date=request.getParameter("jcc_end_date");
		
	  if (jcc_beg_date.equals("DD/MM/YYYY") || jcc_beg_date.equals("") || jcc_beg_date == "" || jcc_beg_date == "DD/MM/YYYY") {
			model.put("msg", "Please Enter Begin Date");
			return new ModelAndView("redirect:EditJC_COURSE_DETAILSUrl");
		}
	  if (jcc_end_date.equals("DD/MM/YYYY") || jcc_end_date.equals("") || jcc_end_date == "" || jcc_end_date == "DD/MM/YYYY") {
			model.put("msg", "Please Enter End Date");
			return new ModelAndView("redirect:EditJC_COURSE_DETAILSUrl");
		}
 
    Session sessionHQL = this.sessionFactory.openSession(); 
    Transaction tx = sessionHQL.beginTransaction(); 
    ln.setJcc_id(Integer.parseInt(request.getParameter("jcc_id")));
    sessionHQL.saveOrUpdate(ln); 
    tx.commit(); 
    sessionHQL.close(); 

 
    model.put("msg","Data Updated Successfully"); 
    return new ModelAndView("redirect:JC_COURSE_DETAILS_Url"); 
  } 
  @RequestMapping(value = "/deleteJC_COURSE_DETAILSUrl", method = RequestMethod.POST) 
  public ModelAndView deleteJC_COURSE_DETAILSUrl(String deleteid,HttpSession session,ModelMap model) { 
  	List<String> list = new ArrayList<String>(); 
  	list.add(objDAO.DeleteJC_COURSE_DETAILS(deleteid,session)); 
  	model.put("msg",list);  
    return new ModelAndView("redirect:JC_COURSE_DETAILS_Url"); 
  	}
} 
