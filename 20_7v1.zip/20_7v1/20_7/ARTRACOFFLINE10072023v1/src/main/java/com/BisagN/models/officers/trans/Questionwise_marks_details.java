package com.BisagN.models.officers.trans;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "questionwise_marks_details", uniqueConstraints = {
@UniqueConstraint(columnNames = "qmd_id"),})
public class Questionwise_marks_details {
	
	private int qmd_id;
	private int qmd_is_id;
	private int qmd_qno;
	private String qmd_marks_obtained;
	private int qmd_marks_obtained_manual;
	private int tm_ncreatedby;
	private Date tm_dtcreatedate;
	private int tm_nupdateby;
	private Date tm_updatedate;
	private int subject_id;
	private int oa_application_id;
	
	
	  @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "qmd_id", unique = true, nullable = false)
	  
	  
	
	public int getQmd_id() {
		return qmd_id;
	}
	public void setQmd_id(int qmd_id) {
		this.qmd_id = qmd_id;
	}
	public int getQmd_is_id() {
		return qmd_is_id;
	}
	public void setQmd_is_id(int qmd_is_id) {
		this.qmd_is_id = qmd_is_id;
	}
	public int getQmd_qno() {
		return qmd_qno;
	}
	public void setQmd_qno(int qmd_qno) {
		this.qmd_qno = qmd_qno;
	}
	public String getQmd_marks_obtained() {
		return qmd_marks_obtained;
	}
	public void setQmd_marks_obtained(String qmd_marks_obtained) {
		this.qmd_marks_obtained = qmd_marks_obtained;
	}
	public int getQmd_marks_obtained_manual() {
		return qmd_marks_obtained_manual;
	}
	public void setQmd_marks_obtained_manual(int qmd_marks_obtained_manual) {
		this.qmd_marks_obtained_manual = qmd_marks_obtained_manual;
	}
	public int getTm_ncreatedby() {
		return tm_ncreatedby;
	}
	public void setTm_ncreatedby(int tm_ncreatedby) {
		this.tm_ncreatedby = tm_ncreatedby;
	}
	public Date getTm_dtcreatedate() {
		return tm_dtcreatedate;
	}
	public void setTm_dtcreatedate(Date tm_dtcreatedate) {
		this.tm_dtcreatedate = tm_dtcreatedate;
	}
	public int getTm_nupdateby() {
		return tm_nupdateby;
	}
	public void setTm_nupdateby(int tm_nupdateby) {
		this.tm_nupdateby = tm_nupdateby;
	}
	public Date getTm_updatedate() {
		return tm_updatedate;
	}
	public void setTm_updatedate(Date tm_updatedate) {
		this.tm_updatedate = tm_updatedate;
	}
	public int getSubject_id() {
		return subject_id;
	}
	public void setSubject_id(int subject_id) {
		this.subject_id = subject_id;
	}
	public int getOa_application_id() {
		return oa_application_id;
	}
	public void setOa_application_id(int oa_application_id) {
		this.oa_application_id = oa_application_id;
	}
	
	
	

}
