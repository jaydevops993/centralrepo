package com.BisagN.dao.officer.course;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.models.officers.masters.Reason_M;


@Service
public class MeritandResultGenerationDaoImpl implements MeritandResultGenerationDao {
	
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();



@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

CommonController comm = new CommonController();


	public ArrayList<ArrayList<String>> getcourseandmeritlist(int es_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();

		Connection conn = null;
		String q = "";
		String qry = "";

		try {
			
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			
		q="select ROW_NUMBER() OVER(order by dcvr.id) as serno, cm.name, dcvr.reserve, dcvr.vacancy, dcvr.course_id from dssc_course_vacancy_reserve  dcvr\n"
				+ "inner join course_master cm on dcvr.course_id=cm.choice_id\n"
				+ "where dcvr.es_id=? order by course_id";

			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			System.err.println("course========1603==="+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();

				list.add(rs.getString("name"));// 0
				list.add(rs.getString("reserve"));// 1
				list.add(rs.getString("vacancy"));// 2
				list.add(rs.getString("serno"));// 2
				list.add(rs.getString("course_id"));// 2
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;

	}
	
	
	
public ArrayList<ArrayList<String>> getcourseandmeritlistfordssc(int es_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();

		Connection conn = null;
		String q = "";
		String qry = "";

		try {
			
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			
		q="select  ROW_NUMBER() OVER(order by dcvr.id) as serno, cm.name, dcvr.reserve, dcvr.vacancy,dcvr.course_id\n"
				+ ",count(dcvr.course_id) \n"
				+ "from dssc_course_vacancy_reserve  dcvr\n"
				+ "inner join course_master cm on dcvr.course_id=cm.choice_id\n"
				+ "inner join qualified_officers qo on qo.course_id = dcvr.course_id\n"
				+ "where dcvr.es_id= ? and qo.status_id='1' and qo.nominatedfor !='DSSC Res'  and qo.nominatedfor !='DSTSC Res' and qo.nominatedfor !='ALMC Res' and qo.nominatedfor !='ISC Res'  group by 2,3,4,dcvr.id,dcvr.course_id";

			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			System.err.println("course========1603==="+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();

				list.add(rs.getString("name"));// 0
				list.add(rs.getString("reserve"));// 1
				list.add(rs.getString("vacancy"));// 2
				list.add(rs.getString("serno"));// 3
				list.add(rs.getString("count"));// 4
				list.add(rs.getString("course_id"));// 5
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;

	}
	
	
public ArrayList<ArrayList<String>> getwithdrawList(int startPage, int pageLength, String Search,
		String orderColunm, String orderType,int es_id,String personalcode ) {		
	
//	

	String pageL = "";
	if (pageLength == -1) {
		pageL = "ALL";
	} else {
		pageL = String.valueOf(pageLength);
	}
	List<Reason_M>getreasonlist=comm.getreasonlist(sessionFactory);
	
	ArrayList<ArrayList<String>> list = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String q1="";
	String q2="";
	if (!personalcode.equals("")) {			
			
			//using commaon controller searchwithout zero
		q2=comm.getSearchIcNumberwithoutZero(personalcode);
			 System.err.println("opc_code==========="+personalcode);
//			 q1+="and lower(vpd.opc_personal_code::text) like ?";
				 
		}
String SearchValue = GenerateQueryWhereCandiList(Search,q2);
	try {
		conn = dataSource.getConnection();			
		
		q = " select oid,qo.oa_applicant_id,vpd.opc_personal_code,vpd.opc_suffix_code,rc_rank_name,opd_officer_name ,vpd.ac_arm_description ,qo.nominatedfor  from qualified_officers qo\n"
				+ "inner join officer_application ofa on ofa.oa_application_id=qo.oa_applicant_id\n"
				+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
				+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
				+ "where  ofa.es_id= ? and qo.status_id=1 "+ SearchValue +" \n"
			  + " ORDER BY " + orderColunm + " " + orderType + " limit " + pageL + " OFFSET " + startPage + "";
		
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereCandiList(stmt, Search,q2);
		stmt.setInt(1, es_id);

		ResultSet rs = stmt.executeQuery();
		
		System.err.println("stmt============"+stmt);
		int i = 1;
		while (rs.next()) {
			ArrayList<String> alist = new ArrayList<String>();
			alist.add(String.valueOf(i));
			
			String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
   			String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));
   			System.err.println("===============opc_code==============="+opc_code);
			alist.add(opc_code);
			
			alist.add(rs.getString("rc_rank_name"));
			alist.add(rs.getString("opd_officer_name"));
			alist.add(rs.getString("ac_arm_description"));
			alist.add(rs.getString("nominatedfor"));
			
			String dropdwon = " <select id='reason' name='reason'	class='form-control'  >\n"
					+ "										<option value='0'>--Select--</option>\n"
					+ "										<c:forEach var='item' items='${getreasonlist}' varStatus='num'  >\n"
					+ "										<option value='${item.id}'>${item.reason_name}</option>\n"
					+ "										</c:forEach>\n"
					+ "									</select>";
			
//			alist.add(dropdwon);
			String f = "";
			String Update = "onclick=\"  if (confirm('Are You Sure You Want to Withdraw This  ?') ){withdraw("
					+ rs.getString("oid") + ",'" + rs.getString("oa_applicant_id") + "')}else{ return false;}\"";
			f += " <a  data-toggle='modal' data-target='#myModal'  class='action_icons action_update '  "+Update+" ></a>";
			f = "<input type='button' id='withid' name ='withid'   value='WITHDRAWAL' " + f + " ";
			
			alist.add(f);
			i++;
			list.add(alist);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	return list;
}

public long getReportListwithdrawTotalCount(String Search,int es_id,String personalcode) {
	
	
	int total = 0;
	String q = null;
	String q1="";
	Connection conn = null;
	try {
		
		String q2="";
		if (!personalcode.equals("")) {			
				
				//using commaon controller searchwithout zero
			q2=comm.getSearchIcNumberwithoutZero(personalcode);
				 System.err.println("opc_code==========="+personalcode);
//				 q1+="and lower(vpd.opc_personal_code::text) like ?";
					 
			}
		String SearchValue = GenerateQueryWhereCandiList(Search,q2);

		conn = dataSource.getConnection();

		q = "select count (*) from(select oid,qo.oa_applicant_id,opc_personal_code,rc_rank_name,opd_officer_name ,vpd.ac_arm_description   from qualified_officers qo\n"
				+ "inner join officer_application ofa on ofa.oa_application_id=qo.oa_applicant_id\n"
				+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
				+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
				+ "where ofa.es_id= ? and qo.status_id=1   "+SearchValue+") a ";

		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereCandiList(stmt, Search,q2);
//		stmt.setString(1,(personalcode) );
		stmt.setInt(1, es_id);
//		if (!personalcode.equals("")) {	
//			stmt.setString(2,personalcode );
//			}
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		conn.close();

	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	return (long) total;

}

public String GenerateQueryWhereCandiList(String Search,String personalcode) {
	String SearchValue ="";
	
	if (!personalcode.equals("")) {			
		
		//using commaon controller searchwithout zero
		personalcode=comm.getSearchIcNumberwithoutZero(personalcode);
		 System.err.println("opc_code==========="+personalcode);
		 SearchValue+="and lower(vpd.opc_personal_code::text) like ?";
			 
	}
		if(!Search.equals("")) {
		Search = Search.toLowerCase();
			SearchValue =" and ( ";
			SearchValue +=" lower(opc_personal_code) like ? or lower(rc_rank_name) like ? or lower(opd_officer_name) like ? or lower(vpd.ac_arm_description ) like ? )";
//		 SearchValue +=" lower(sm.state_name) like ? or lower(dis.district) like ? or lower(pin.pincode) like ? )";
		}
return SearchValue;
}



public PreparedStatement setQueryWhereCandiList(PreparedStatement stmt, String Search,String personalcode) {

	int flag = 1;
	try {

		if (!personalcode.equals("")) {	
			flag += 1;
			stmt.setString(flag,"%"+personalcode+"%");
			}
		if(!Search.equals("")) {
				
				flag += 1;
				Search=comm.getSearchIcNumberwithoutZero(Search);

				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				flag += 1;
				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				flag += 1;
				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				flag += 1;
				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
//				flag += 1;
//				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				
			}
	} catch (Exception e) {
		e.printStackTrace();
	}

	return stmt;
}

	
	
	
	
	public ArrayList<ArrayList<String>> getupgradationmeritList(int startPage, int pageLength, String Search,
			String orderColunm, String orderType,int es_id,String choice_type_id ) {

		String pageL = "";
		if (pageLength == -1) {
			pageL = "ALL";
		} else {
			pageL = String.valueOf(pageLength);
		}

		String SearchValue = GenerateupgradationmeritList(Search);
		ArrayList<ArrayList<String>> list = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String q1 = "";
		try {
			conn = dataSource.getConnection();
			
		

			if(choice_type_id.equals("5"))  {
				
				q1="and qo.nominatedfor in ('DSSC COMPETITIVE','DSSC')";
				
			}
			
			if(choice_type_id.equals("6"))  {
				
				q1="and qo.nominatedfor in ('DSTSC')";
				
			}
			
          if(choice_type_id.equals("1"))  {
				
				q1="and qo.nominatedfor in ('DSSC Res','DSTSC Res')";
				
			}
          
          if(choice_type_id.equals("2"))  {
				
				q1="and qo.nominatedfor in ('ALMC','ALMC Res','ISC','ISC Res')";
				
			}
			
		
			
			
			
			
			
		
			
			
			q = " select DISTINCT qo.meritid,qo.oid,vpd.opc_personal_code,vpd.opc_suffix_code,rc_rank_name,opd_officer_name ,vpd.ac_arm_description ,qo.nominatedfor,qo.oa_applicant_id,\n"
					+ "string_agg(case when dsch.course_preference::text='1' and (dsch.course_applied='5' or dsch.course_applied='6')   then cm.name else '0' end, ','::text)  as DSSC\n"
					+ ",string_agg(case when dsch.course_preference::text='2'  and (dsch.course_applied='5' or dsch.course_applied='6')   then cm.name else '0'  end, ','::text) as  DSTSC,\n"
					+ "string_agg(case when dsch.course_preference::text='3'  and  (dsch.course_applied='8' or dsch.course_applied='13')   then cm.name else '0'  end, ','::text) as ALMC,\n"
					+ "string_agg(case when dsch.course_preference::text='4'  and  (dsch.course_applied='8' or dsch.course_applied='13')   then cm.name else '0'  end, ','::text) as ISC\n"
					+ "from qualified_officers qo\n"
					+ "					inner join officer_application ofa on ofa.oa_application_id=qo.oa_applicant_id\n"
					+ "					inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
					+ "					inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
					+ "					inner join dssc_choice_tbl dsch on dssc.id = dsch.dscc_app_id\n"
					+ "					inner join course_master cm on cm.choice_id=dsch.course_applied\n"
					+ "			where  ofa.es_id=? and qo.status_id=1 "+q1+"  \n"
					+ "					group by 1,2,3,4,5,6,7  "+ SearchValue +" \n"
				  + " ORDER BY qo.oid " + orderType + " limit " + pageL + " OFFSET " + startPage + "";
			
			PreparedStatement stmt = conn.prepareStatement(q);
			stmt = setQueryWhereupgradationmeritList(stmt, Search);
			stmt.setInt(1, es_id);
			
			
			
			ResultSet rs = stmt.executeQuery();
			
			System.err.println("stmt============"+stmt);
			int i = 1;
			while (rs.next()) {
				ArrayList<String> alist = new ArrayList<String>();
				
				
				String Data = rs.getString("opc_personal_code");
				String DataPre = "";
				String DataM = "";
				if (Data.contains("NTR") || Data.contains("NTS")) {
					DataPre = Data.substring(0, 3);
					DataM = Data.substring(4);
				} else {
					DataPre = Data.substring(0, 2);
					DataM = Data.substring(3);
				}
				//System.err.println("DataPre " + DataPre);
				//System.err.println("DataM " + DataM);

				Data = DataPre + DataM;
				
				alist.add(Data + "  " + (rs.getString("opc_suffix_code")));
				alist.add(rs.getString("rc_rank_name"));
				alist.add(rs.getString("opd_officer_name"));
				alist.add(rs.getString("ac_arm_description"));
		
				alist.add(rs.getString("DSSC"));
				alist.add(rs.getString("DSTSC"));
				alist.add(rs.getString("ALMC"));
				
				alist.add(rs.getString("ISC"));
			
				
				alist.add(rs.getString("nominatedfor"));
				alist.add(rs.getString("meritid"));
				
				
				String dropdwon = "<select id='course_id"+rs.getString("oid")+"' name='course_id"+rs.getString("oid")+"' class='form-control'>\n"
						+ "														<option value='0'>--Select--</option>\n"
						+ "														<option value='DSSC'>DSSC</option>\n"
						+ "														<option value='DSTSC'>DSTSC</option>\n"
						+ "														<option value='ALMC'>ALMC</option>\n"
						+ "														<option value='ISC'>ISC</option>\n"
						+ "													</select>";
				
			alist.add(dropdwon);
			
			String Update2 = "onclick=\"  if (confirm('Are You Sure You Want to Upgrade This  ?') ){UpgradeData("
					+ rs.getString("oid") + ",'" + rs.getString("oa_applicant_id") + "')}else{ return false;}\"";
			
			String updateButton = "<i class='action_icons action_update' " + Update2 + " title='Edit Data'></i>";
			
			alist.add(updateButton);
//			alist.add(rs.getString("meritid"));
				list.add(alist);
				//System.err.println("alist============="+alist);
				i++;
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}

	public long getReportListupgradationmeritTotalCount(String Search,int es_id,String choice_type_id) {
		
		String SearchValue = GenerateupgradationmeritList(Search);
		int total = 0;
		String q = null;
		String q1="";
		Connection conn = null;
		try {
			conn = dataSource.getConnection();

			
        if(choice_type_id.equals("5"))  {
				
				q1+="and qo.nominatedfor in ('DSSC COMPETITIVE','DSSC')";
				
			}
			
			if(choice_type_id.equals("6"))  {
				
				q1+="and qo.nominatedfor in ('DSTSC','DSTSC Res')";
				
			}
			
          if(choice_type_id.equals("1"))  {
				
				q1+="and qo.nominatedfor in ('DSSC Res','DSTSC Res')";
				
			}
          
          if(choice_type_id.equals("2"))  {
				
				q1+="and qo.nominatedfor in ('ALMC','ALMC Res','ISC','ISC Res')";
				
			}
			q = "select count (*) from(select DISTINCT qo.oid,opc_personal_code,rc_rank_name,opd_officer_name ,vpd.ac_arm_description ,qo.nominatedfor,qo.oa_applicant_id,\n"
					+ "string_agg(case when dsch.course_preference::text='1' and (qo.course_id='5' or qo.course_id='6')  then cm.name else dsch.course_preference::text end, ','::text)  as DSSC\n"
					+ ",string_agg(case when dsch.course_preference::text='2'  and  (qo.course_id='5' or qo.course_id='6')  then cm.name else dsch.course_preference::text  end, ','::text) as  DSTSC,\n"
					+ "string_agg(case when dsch.course_preference::text='3'  and  (qo.course_id='8' or qo.course_id='13')  then cm.name else dsch.course_preference::text  end, ','::text) as ALMC,\n"
					+ "string_agg(case when dsch.course_preference::text='4'  and  (qo.course_id='8' or qo.course_id='13')  then cm.name else dsch.course_preference::text  end, ','::text) as ISC\n"
					+ "from qualified_officers qo\n"
					+ "					inner join officer_application ofa on ofa.oa_application_id=qo.oa_applicant_id\n"
					+ "					inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
					+ "					inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
					+ "					inner join dssc_choice_tbl dsch on dssc.id = dsch.dscc_app_id\n"
					+ "					inner join course_master cm on cm.choice_id=dsch.course_applied\n"
					+ "			where  ofa.es_id = ? and qo.status_id=1  "+q1+"\n"
					+ "					group by 1,2,3,4,5,6,7 order by qo.oid"+SearchValue+") a ";

			PreparedStatement stmt = conn.prepareStatement(q);
			stmt = setQueryWhereupgradationmeritList(stmt, Search);
			stmt.setInt(1, es_id);

			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				total = rs.getInt(1);
			}
			rs.close();
			stmt.close();
			conn.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return (long) total;

	}


	public String GenerateupgradationmeritList(String Search) {
		String SearchValue ="";
  		if(!Search.equals("")) {
			Search = Search.toLowerCase();
//  			SearchValue =" and ( ";
//  		 SearchValue +=" lower(sm.state_name) like ? or lower(dis.district) like ? or lower(pin.pincode) like ? )";
 		}
   return SearchValue;
 }

	

	public PreparedStatement setQueryWhereupgradationmeritList(PreparedStatement stmt, String Search) {

		int flag = 0;
		try {


    		if(!Search.equals("")) {
 				
// 				flag += 1;
// 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 				flag += 1;
// 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 				flag += 1;
// 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				
 			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return stmt;
	}
	
	
	
	//=====
	
	public List<Map<String, Object>> getMeritReportDataList(int startPage, String pageLength, String Search,
			String orderColunm, String orderType, HttpSession session,int es_id)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search);

		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		String q = "";

		try {
			conn = dataSource.getConnection();

			q = "SELECT cm.name,sub_course,dsm.total_vacancy,dsm.division,dsm.priority_merit,dsm.priority_result,dsm.type  ,\n"
					+ "case when dsm.division='yes' then 'YES' \n"
					+ " when dsm.division is null then '-' else  'NO' end as abc\n"
					+ "FROM public.dssc_merit_result_gen_tbl  dsm\n"
					+ "inner join  course_master cm on cm.choice_id=dsm.course_id\n"
					+ "where es_id= ? \n"
					+ "order by choice_id" + SearchValue +" limit " + pageLength + " OFFSET " + startPage;

			PreparedStatement stmt = conn.prepareStatement(q);
			stmt = setQueryWhereClause_SQL(stmt, Search);
			
			
			stmt.setInt(1, es_id);
			ResultSet rs = stmt.executeQuery();
			System.out.println("stmt+" + stmt);
			ResultSetMetaData metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();
			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
					columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
				list.add(columns);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return list;
	}

	public long getMeritTotalCount(String Search,int es_id) {
		String SearchValue = GenerateQueryWhereClause_SQL(Search);
		int total = 0;
		String q = null;
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			
			q ="select count(*) from(SELECT cm.name,sub_course,dsm.total_vacancy,dsm.division,dsm.priority_merit,dsm.priority_result,dsm.type  ,\n"
					
					+ "case when dsm.division='yes' then 'YES' \n"
					+ " when dsm.division is null then '-' else  'NO' end as abc\n"
					+ "FROM public.dssc_merit_result_gen_tbl  dsm\n"
					+ "inner join  course_master cm on cm.choice_id=dsm.course_id\n"
					+ "where es_id= ? \n"
					+ "order by choice_id"+SearchValue+" )a" ;
			
			PreparedStatement stmt = conn.prepareStatement(q);
			stmt = setQueryWhereClause_SQL(stmt, Search);
			stmt.setInt(1, es_id);
			ResultSet rs = stmt.executeQuery();
			System.out.println("stmt+" + stmt);
			while (rs.next()) {
				total = rs.getInt(1);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search) {
		String SearchValue = "";
		if (!Search.equals("")) {
			Search = Search.toLowerCase();
			SearchValue = " and ( ";
			SearchValue += " lower(area_type) like ? )";
		}
		return SearchValue;
	}


	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt, String Search) {
		int flag = 0;
		try {
			if (!Search.equals("")) {
				
				
				flag += 1;
				stmt.setString(flag, "%" + Search.toLowerCase() + "%");
				
			}
		} catch (Exception e) {
		}
		return stmt;
	}
	
	
}
