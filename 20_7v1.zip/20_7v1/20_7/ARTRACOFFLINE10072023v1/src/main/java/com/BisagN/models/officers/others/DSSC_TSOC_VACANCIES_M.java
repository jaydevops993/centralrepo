package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "dssc_tsoc_vacancies", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class DSSC_TSOC_VACANCIES_M {

      private int id;
      private int es_id;
      private int dssc_vacancy;
      private int dssc_reserves;
      private int tsoc_vacancy;
      private int tsoc_reserves;

      private int  almc_vacancy ;
      private int  almc_reserves ;
      private int  isc_vacancy;
      private int  isc_reserves;

      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getEs_id() {
           return es_id;
      }
      public void setEs_id(int es_id) {
	  this.es_id = es_id;
      }
      public int getDssc_vacancy() {
           return dssc_vacancy;
      }
      public void setDssc_vacancy(int dssc_vacancy) {
	  this.dssc_vacancy = dssc_vacancy;
      }
      public int getDssc_reserves() {
           return dssc_reserves;
      }
      public void setDssc_reserves(int dssc_reserves) {
	  this.dssc_reserves = dssc_reserves;
      }
      public int getTsoc_vacancy() {
           return tsoc_vacancy;
      }
      public void setTsoc_vacancy(int tsoc_vacancy) {
	  this.tsoc_vacancy = tsoc_vacancy;
      }
      public int getTsoc_reserves() {
           return tsoc_reserves;
      }
      public void setTsoc_reserves(int tsoc_reserves) {
	  this.tsoc_reserves = tsoc_reserves;
      }
	public int getAlmc_vacancy() {
		return almc_vacancy;
	}
	public void setAlmc_vacancy(int almc_vacancy) {
		this.almc_vacancy = almc_vacancy;
	}
	public int getAlmc_reserves() {
		return almc_reserves;
	}
	public void setAlmc_reserves(int almc_reserves) {
		this.almc_reserves = almc_reserves;
	}
	public int getIsc_vacancy() {
		return isc_vacancy;
	}
	public void setIsc_vacancy(int isc_vacancy) {
		this.isc_vacancy = isc_vacancy;
	}
	public int getIsc_reserves() {
		return isc_reserves;
	}
	public void setIsc_reserves(int isc_reserves) {
		this.isc_reserves = isc_reserves;
	}
      
      
      
}
