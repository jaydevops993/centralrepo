package com.BisagN.controller.office.Course;

import java.io.File;
import java.io.FileInputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.course.CourseDao;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class ImpoerJcCourseGradingController {
	
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private CourseDao courseDAO;
	
	@Autowired
	private RoleBaseMenuDAO roledao;
	
	
	@Autowired
	CommonController comm= new CommonController();
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	//===========================OPEN PAGE============================//
			@RequestMapping(value = "ImportJcCourseGardingUrl", method = RequestMethod.GET)
			public ModelAndView ImportJcCourseGardingUrl(ModelMap Mmap, HttpSession session,HttpServletRequest request,
					@RequestParam(value = "msg", required = false) String msg)
					throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
					NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

				  Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
			        if(flashMap != null){
			        	ArrayList<ArrayList<String>> errorList =  (ArrayList<ArrayList<String>>) flashMap.get("errorlist");
			            System.out.println("==================="+errorList);
			            //return "home";
			            Mmap.put("errorList",errorList);
			        }
			        
			        if (request.getHeader("Referer") == null) {
						session.invalidate();
						Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
						return new ModelAndView("redirect:/login");
					}

					String roleid1 = session.getAttribute("roleid").toString();
					Boolean val = roledao.ScreenRedirect("ImportJcCourseGardingUrl", roleid1);
					if (val == false) {
						return new ModelAndView("AccessTiles");
					}
				   
//				 Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
				Mmap.put("msg", msg);
				return new ModelAndView("Import_Jc_CourseGrading_tiles");
			}
			//Download DEMO EXCEL
					@RequestMapping(value = "/DemoCandidateExcelForImoprtJcCourseGarding", method = RequestMethod.POST)
					public ModelAndView DemoCandidateExcelForImoprtJcCourseGarding(HttpServletRequest request,ModelMap model,HttpSession session,String typeReport1) {
						
//						
					ArrayList<ArrayList<String>> listexport=new ArrayList<ArrayList<String>>();
					List<String> TH = new ArrayList<String>();
				    	TH.add("SER_NO");
				    	 TH.add("IC_NO");
					    TH.add("JC_COURSE_NO");
					    TH.add("JC_NUMBER");
					    TH.add("JC_GRADING");
					    
						String Heading = "\n";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList", listexport);
					}
					
					
					//UPLOAD CANDIDATE DATA
					@RequestMapping(value = "/UploadJcCourseGardingAction", method = RequestMethod.POST)
					public ModelAndView UploadJcCourseGardingAction(HttpServletRequest request, ModelMap model, HttpSession session,RedirectAttributes ra,
							@RequestParam(value = "fileUpload", required = false) MultipartFile fileUpload)
					{
						ArrayList<ArrayList<String>> listerror=new ArrayList<ArrayList<String>>();
						Session sessionHQL = this.sessionFactory.openSession();
						Transaction tx = sessionHQL.beginTransaction();
						
//					if(fileUpload==null) {
//							 model.put("msg","Please Upload Copy Of File Upload");
//							  return new ModelAndView("redirect:PCtoSS_Officers_detailsUrl");
//						  }
						
						if(fileUpload.isEmpty()) {
							ra.addAttribute("msg","Please Upload Copy Of File Upload");
							  return new ModelAndView("redirect:ImportJcCourseGardingUrl");
						}
						
						try {

							


							
							int errorcount=0;
							String errormsg= "";
							File file = new File(comm.fileupload2(fileUpload.getBytes(), fileUpload.getOriginalFilename(), "doc_contract",""));
							FileInputStream fis = new FileInputStream(file);
							@SuppressWarnings("resource")
							XSSFWorkbook wb = new XSSFWorkbook(fis);
							XSSFSheet sheet = wb.getSheetAt(0);
							Row row_head = sheet.getRow(0);
							
							String cpsc_status= request.getParameter("opd_cpsc_on_off");
							
						
							for (int i = 1; i <= sheet.getLastRowNum(); i++) {
								ArrayList<String> listData = new ArrayList<String>();
								Row row = sheet.getRow(i);
								String ic_no="";
								String jc_course_no="";
								String jc_no="";
								String jc_grading="";
								
								
								
								
								if (row.getCell(0) == null) {
									break;
								}
								
								for (int j = 1; j < 4; j++) {

									Cell cell = row.getCell(j);
									
									

									String value = "";
									switch (cell.getCellType()) {
									case Cell.CELL_TYPE_STRING:
										value = cell.getStringCellValue();
										break;
									case Cell.CELL_TYPE_NUMERIC:
										if (HSSFDateUtil.isCellDateFormatted(cell)) {
											value = String.valueOf(cell.getDateCellValue());
										} else {
											value = String.valueOf((long) cell.getNumericCellValue());
										}
										break;
									case Cell.CELL_TYPE_BOOLEAN:
										value = String.valueOf(cell.getBooleanCellValue());
										break;
									default:
									}
									if (row_head.getCell(j).getStringCellValue().equals("IC_NO")) {
										ic_no=value;
									}
									
									
									if (row_head.getCell(j).getStringCellValue ().equals("JC_NUMBER")) {
										jc_no=value;
										
									}
									if (row_head.getCell(j).getStringCellValue().equals("JC_GRADING")) {
										jc_grading=value;
										System.err.println("value=========="+value);
								     }
									
									
									
									
									
								}
								
								List<OFFICER_PERSONAL_CODE_M> opdpers_id= comm.getopdIdbycode( sessionFactory, ic_no);
								
								if(opdpers_id.isEmpty()) {
									
									 listData.add(ic_no);
									 listData.add(jc_course_no);
									 listData.add(jc_no);
									 listData.add(jc_grading);
								     listData.add("The Personal Number is Wrong");
									 errormsg= ic_no +"The Personal Number is Wrong";
										model.put("msg",errormsg);
										errorcount++;
								}
								else {
								

								int opd_pers_id= opdpers_id.get(0).getOpd_personal_id();
							
								
								String hq1l = "update OFFICER_PERSONAL_DETAILS_M set opd_jc_course_grading=:opd_jc_course_grading,opd_jc_number=:opd_jc_number  where opd_personal_id=:opd_personal_id ";
								Query query1 = sessionHQL.createQuery(hq1l)
										.setParameter("opd_jc_course_grading", jc_grading)
											.setParameter("opd_jc_number", jc_no)
								.setParameter("opd_personal_id",opd_pers_id);
								query1.executeUpdate();
							
			                         
									
								
									
								tx.commit();
								sessionHQL.close();

								ra.addAttribute("msg","Data Saved Successfully");
											
								}
								if(!listData.isEmpty()) {
									System.err.println("listData======="+listData);
									listerror.add(listData);
								}
									
								
									
								model.put("errorlist", listerror);
									
									
									
								} 

							
						}
					
						 catch (Exception e) {
							//tx.rollback();
							e.printStackTrace();
						} finally {
							if (sessionHQL != null) {
								sessionHQL.close();
							}
						}
						
						ra.addFlashAttribute("errorlist",listerror);
						ra.addFlashAttribute("errorlistSize",listerror.size());
						return new ModelAndView("redirect:ImportJcCourseGardingUrl");
					}		
}
