package com.BisagN.models.officers.trans;


import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "answer_book", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class ANSWER_BOOK_M {

      private int id;
      private int oa_application_id;
      private int sc_subject_id;
      private int ab_first_entry;
      private int ab_second_entry;
      private int ab_marks_obtained;
      private int ab_unfair_status;
      private int ab_status_id;
      private String ab_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date ab_creation_date;
      private String ab_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date ab_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getOa_application_id() {
           return oa_application_id;
      }
      public void setOa_application_id(int oa_application_id) {
	  this.oa_application_id = oa_application_id;
      }
      public int getSc_subject_id() {
           return sc_subject_id;
      }
      public void setSc_subject_id(int sc_subject_id) {
	  this.sc_subject_id = sc_subject_id;
      }
      public int getAb_first_entry() {
           return ab_first_entry;
      }
      public void setAb_first_entry(int ab_first_entry) {
	  this.ab_first_entry = ab_first_entry;
      }
      public int getAb_second_entry() {
           return ab_second_entry;
      }
      public void setAb_second_entry(int ab_second_entry) {
	  this.ab_second_entry = ab_second_entry;
      }
      public int getAb_marks_obtained() {
           return ab_marks_obtained;
      }
      public void setAb_marks_obtained(int ab_marks_obtained) {
	  this.ab_marks_obtained = ab_marks_obtained;
      }
      public int getAb_unfair_status() {
           return ab_unfair_status;
      }
      public void setAb_unfair_status(int ab_unfair_status) {
	  this.ab_unfair_status = ab_unfair_status;
      }
      public int getAb_status_id() {
           return ab_status_id;
      }
      public void setAb_status_id(int ab_status_id) {
	  this.ab_status_id = ab_status_id;
      }
      public String getAb_created_by() {
           return ab_created_by;
      }
      public void setAb_created_by(String ab_created_by) {
	  this.ab_created_by = ab_created_by;
      }
      public Date getAb_creation_date() {
           return ab_creation_date;
      }
      public void setAb_creation_date(Date ab_creation_date) {
	  this.ab_creation_date = ab_creation_date;
      }
      public String getAb_modified_by() {
           return ab_modified_by;
      }
      public void setAb_modified_by(String ab_modified_by) {
	  this.ab_modified_by = ab_modified_by;
      }
      public Date getAb_modification_date() {
           return ab_modification_date;
      }
      public void setAb_modification_date(Date ab_modification_date) {
	  this.ab_modification_date = ab_modification_date;
      }
}
