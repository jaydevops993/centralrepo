package com.BisagN.controller.office.Generalreports;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.PartDreports.ArmServiceWiseAnalysisOfResultPartD;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.controller.office.reports.ChancewiseAnalysisReportPDF;
import com.BisagN.dao.officer.others.ExaminationschedulepartdDao;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.report.GeneralReportDao;
import com.BisagN.dao.officer.report.PartB_ReportDAO;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class General_ReportController {
	
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	
	@Autowired
	private GeneralReportDao GenRptDao;
	
	
	@Autowired
	CommonController comm;
	
	
	@Autowired
	PartB_ReportDAO partbreportDao;

	@Autowired
	private ExaminationschedulepartdDao ExaminationscheduleDAO;
	
	@RequestMapping(value = "ReportUrl", method = RequestMethod.GET)
	public ModelAndView ReportUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) 
			 throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
	NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{
		
		
	    Mmap.put("msg", msg);
	    Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
	    
	return new ModelAndView("GeneralReport_tiles");

	}
	
	
	@RequestMapping(value = "/getreportPDF", method = RequestMethod.POST)
	public ModelAndView getreportPDF(ModelMap Mmap, HttpSession session,  HttpServletRequest request, String typeReport, String reportname1, 
			String ec_exam_id1, String year1,String t_chnace1, String fr_chnace1) {
		try {



			if(reportname1.equals("1") ) {
				
				ArrayList<ArrayList<String>> list = GenRptDao.getComChanceGenReport(year1, Integer.parseInt(ec_exam_id1));
				if (list.size() == 0) {
					Mmap.put("msg", "Data Not Available.");
						} else {
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (list.size() > 0) {

						List<String> TH = new ArrayList<String>();


						String Heading = "";
						String username = session.getAttribute("username").toString();

						return new ModelAndView(new Waivers_Compensatory_Chance("L", TH, Heading, username));

					}
				}
			}
			}
			else if(reportname1.equals("2")) {
				ArrayList<ArrayList<String>>getattemptData=GenRptDao.getAttemptInExamReport(Integer.parseInt(year1));
				if (getattemptData.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {
					Mmap.put("list", getattemptData);
					Mmap.put("list.size()", getattemptData.size());
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (getattemptData.size() > 0) {

						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(new Attempts_in_Exam("L", TH, Heading, username),"userList",getattemptData);

					}
				}
				
				}
			}
        else if(reportname1.equals("3")) {
        	
        	ArrayList<ArrayList<String>>list =GenRptDao.getUnfairmeansData(ec_exam_id1,Integer.parseInt(year1));
				
        	if (list.size() == 0) {

				Mmap.put("msg", "Data Not Available.");
			} else {
				Mmap.put("list", list);
				Mmap.put("list.size()", list.size());
			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list.size() > 0) {

					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new Unfair_Means("L", TH, Heading, username),"userList",list);

				}
			}
			
			}
			}
      
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("redirect:ReportUrl");
	}
	
	@RequestMapping(value = "/getGeneral_Excel", method = RequestMethod.POST)
	public ModelAndView getGeneral_Excel(ModelMap Mmap, HttpSession session,HttpServletRequest request, String typeReport1, String es_id2, 
			String reportname2, String subject_id2,String centre_id2,String chance2, String f_percntg2,String t_percntg2,String marks2, String exmsh_date2,
			String ec_exam_id2,	String t_chnace2, String fr_chnace2) {
		try {
			
			
//			if(!exmsh_date2.equals("")) {
//				String es_year = exmsh_date2.split("/")[2];
//				Mmap.put("es_year", es_year);
			
			System.err.println("reportname2======"+reportname2);
			if(reportname2.equals("4")) {
				
				
				ArrayList<ArrayList<String>> list = partbreportDao.ChanceWisAnalysisReport(fr_chnace2, t_chnace2);
				//System.err.println("list======"+list);
				if (list.size() > 0) {
					List<String> TH = new ArrayList<String>();
					TH.add("Ser No");
					TH.add("Personal No");
					TH.add("Name");
					TH.add("Arm/Service");
					TH.add("Chances");
					TH.add("Status");
					
					String Heading = "\n";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList",
							list);
				} else {
					Mmap.put("msg", "Data Not Available.");
					return new ModelAndView("redirect:ReportUrl");
				}
			}
	else  if(reportname2.equals("5")) {
				
				ArrayList<ArrayList<String>> list = partbreportDao.getparamountcardlist(Integer.parseInt(ec_exam_id2));

				if (list.size() > 0) {
					List<String> TH = new ArrayList<String>();
					TH.add("SerNo");
					TH.add("Personal No");
					TH.add("Rank");
					TH.add("Name");
					TH.add("Code");
					
					String Heading = "\n";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList",
							list);
				} else {
					Mmap.put("msg", "Data Not Available.");
					return new ModelAndView("redirect:ReportUrl");
				}
				}
			
		
//			}
//		}

		
	} catch (Exception e) {
		e.printStackTrace();
	}

	return new ModelAndView("redirect:ReportUrl");
	}
	 @RequestMapping(value = "/getsubjectlistforreport", method = RequestMethod.POST)
		@ResponseBody
		public List<Map<String, Object>> getsubjectlistforreport(String exmsch_id) {

		 List<Map<String, Object>> list = ExaminationscheduleDAO.editgetdatafromsubmst(exmsch_id);
		 
			return list;
			
			

		}
	 

}
