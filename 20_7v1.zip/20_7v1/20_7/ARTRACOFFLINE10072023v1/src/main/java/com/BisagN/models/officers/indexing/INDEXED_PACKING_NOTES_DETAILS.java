package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "indexed_packing_notes_details", uniqueConstraints = {
@UniqueConstraint(columnNames = "ipnd_id"),})
public class INDEXED_PACKING_NOTES_DETAILS {
	
	private int ipnd_id;
	private int ipnd_ipnm_id;
	private int ipnd_ibm_id;
	
	
	
	 @Id
     @GeneratedValue(strategy = IDENTITY)
     @Column(name = "ipnd_id", unique = true, nullable = false)
	public int getIpnd_id() {
		return ipnd_id;
	}
	public void setIpnd_id(int ipnd_id) {
		this.ipnd_id = ipnd_id;
	}
	public int getIpnd_ipnm_id() {
		return ipnd_ipnm_id;
	}
	public void setIpnd_ipnm_id(int ipnd_ipnm_id) {
		this.ipnd_ipnm_id = ipnd_ipnm_id;
	}
	public int getIpnd_ibm_id() {
		return ipnd_ibm_id;
	}
	public void setIpnd_ibm_id(int ipnd_ibm_id) {
		this.ipnd_ibm_id = ipnd_ibm_id;
	}
	
	
	
	

}
 