package com.BisagN.dao.officer.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class ExportPartD_DaoImpl implements ExportPartD_DAO{
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

public boolean checkIsIntegerValue(String Search) {
	
return Search.matches("[0-9]+");
}
public ArrayList<ArrayList<String>> getexportPartDexmCandidateReport(int startPage, String pageLength, String Search,
		String orderColunm, String orderType, String exam_schedule_dt2, String min_year2,String es_consider_date1,int es_id,String table,String btn_value,String max_year2,String partb_status2, HttpSession session)
		throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
		InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	if (pageLength.equals("-1")) {
		pageLength = "ALL";
	}
	String SearchValue = GenerateQueryWhereClause_SQL(Search);
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String q1 = "";
	String q2 = "";
	String q3 = "";
	
	if(es_consider_date1.equals("opd_date_of_seniority")) {
		
		q1= "opd_date_of_seniority";
	}
	if(es_consider_date1.equals("opd_date_of_comm")) {
		q1="opd_date_of_comm";
	}
if(btn_value.equals("APPLNS YET TO BE GENERATED")) {
		
		q2="and ofa.oa_application_id is  null";
	}
	
if(partb_status2 != null) {
if(partb_status2.equals("yes")) {
	
	q3+="and vw.opd_partb !=0";
}
	}
	
	
	try {
		conn = dataSource.getConnection();
		

		q="SELECT ROW_NUMBER() OVER(order by vw.opd_personal_id) as sr_no,ofa.oa_application_id,   \n"
				+ "vw.opd_officer_name,vw.cc_command_name,vw.opd_personal_id,\n"
				+ "TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority ,\n"
				+ "date_part('year',age('"+ exam_schedule_dt2 + "',"+q1+")) as total_service,\n"
				+ "TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm ,\n"
				+ "vw.opc_suffix_code,vw.opd_unit,vw.opc_personal_code,\n"
				+ "vw.ac_arm_code,vw.ac_arm_description,\n"
				+ "TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob,vw.ct_comm_type,vw.rc_rank_name,getSubjectNameFromCode(vw.pbda_sub_code,2) as sunma,vw.pbda_sub_code,a.subcode\n"
				+ "from vw_personal_details vw	"
				+ "left join officer_application ofa on ofa.opd_personal_id = vw.opd_personal_id  and ofa.es_id="+es_id+"	\n"
				+ "		inner join (select distinct string_agg(sc.sc_subject_code::text,',')  as subcode,sum(sc.sc_subject_code) as sub_sum,sct.arm_id,sc.ec_exam_id from subject_code sc\n"
				+ "				inner join subject_code_child_tbl sct on sc.sc_subject_id=sct.sub_id\n"
				+ "					group by 3,4) as a on a.arm_id=vw.ac_arm_id and a.ec_exam_id=2\n"
				+ "		where vw.opd_status_id='1' and vw.opd_partd=0 and vw.opd_isactive='yes' "+q3+"\n"
				+ "		and  date_part('year',age('"+ exam_schedule_dt2 + "',"+q1+")) >= "+min_year2+" and   date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) <= "+max_year2+" "+q2+" "+SearchValue+" \n"
						+ "					ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage;



		PreparedStatement stmt = conn.prepareStatement(q);

		stmt = setQueryWhereClause_SQL(stmt, Search);

		System.err.println("stmt========bbbb======"+stmt);

		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("sr_no"));//0
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			
			Data=DataPre+DataM;
			list.add(Data+(rs.getString("opc_suffix_code")));
			list.add(rs.getString("opd_officer_name"));//2
			list.add(rs.getString("ac_arm_description"));//3
			list.add(rs.getString("opd_dob"));//4	
			list.add(rs.getString("opd_date_of_comm"));//5	
			list.add(rs.getString("ct_comm_type"));//6
			list.add(rs.getString("rc_rank_name"));//7		
			
			list.add(rs.getString("opd_date_of_seniority"));//8
			
			
			StringBuilder input1 = new StringBuilder();
			input1.append(rs.getString("sunma"));
			input1.reverse();
			list.add(input1.toString());
			
			System.err.println("table-----------"+table);
			if(!table.equals("excelL")) {
			list.add(rs.getString("pbda_sub_code"));//10
			list.add(rs.getString("opc_personal_code"));
			}
		
			list.add(rs.getString("oa_application_id"));//10	
//			list.add(Data+(rs.getString("opc_suffix_code")));
//			list.add(rs.getString("opd_officer_name"));//2
//			list.add(rs.getString("ac_arm_description"));//3
//			list.add(rs.getString("opd_date_of_seniority"));//8
//			list.add(rs.getString("total_service"));//6
//
//			
//			
//			StringBuilder input1 = new StringBuilder();
//			input1.append(rs.getString("sunma"));
//			input1.reverse();
//			list.add(input1.toString());
//			if(!table.equals("excelL")) {
//			list.add(rs.getString("pbda_sub_code"));//10
//			list.add(rs.getString("opc_personal_code")+(rs.getString("opc_suffix_code")));
//			}
//		
//			list.add(rs.getString("oa_application_id"));//10	
			
			alist.add(list);
			
			
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

public long getexportPartDexmCandidatereportTotalCount(String Search, String exam_schedule_dt2,String min_year2,String es_consider_date1,int es_id,String btn_value,String max_year2,String partb_status2) {
String SearchValue = GenerateQueryWhereClause_SQL(Search);
int total = 0;
String q = null;
Connection conn = null;
try {
	String q1 = "";
	String q2 = "";
	String q3 = "";
	
	
if(es_consider_date1.equals("opd_date_of_seniority")) {
		
		q1= "opd_date_of_seniority";
	}
	if(es_consider_date1.equals("opd_date_of_comm")) {
		q1="opd_date_of_comm";
	}
	
if(btn_value.equals("APPLNS YET TO BE GENERATED")) {
		
		q2="and ofa.oa_application_id is  null";
	}
	
System.err.println("partb_status========="+partb_status2);
if(partb_status2 != null) {
if(partb_status2.equals("yes")) {

q3+="and vw.opd_partb !=0";
}
}


	conn = dataSource.getConnection();
	q="select count(*) from (SELECT ROW_NUMBER() OVER(order by vw.opd_personal_id) as sr_no,ofa.oa_application_id,   \n"
			+ "vw.opd_officer_name,vw.cc_command_name,vw.opd_personal_id,\n"
			+ "TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority ,\n"
			+ "date_part('year',age('"+ exam_schedule_dt2 + "',"+q1+")) as total_service,\n"
			+ "TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm ,\n"
			+ "vw.opc_suffix_code,vw.opd_unit,vw.opc_personal_code,\n"
			+ "vw.ac_arm_code,vw.ac_arm_description,\n"
			+ "TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob,vw.ct_comm_type,vw.rc_rank_name,getSubjectNameFromCode(vw.pbda_sub_code,2) as sunma,vw.pbda_sub_code,a.subcode\n"
			+ "from vw_personal_details vw	"
			+ "left join officer_application ofa on ofa.opd_personal_id = vw.opd_personal_id  and ofa.es_id="+es_id+"	\n"
			+ "		inner join (select distinct string_agg(sc.sc_subject_code::text,',')  as subcode,sum(sc.sc_subject_code) as sub_sum,sct.arm_id,sc.ec_exam_id from subject_code sc\n"
			+ "				inner join subject_code_child_tbl sct on sc.sc_subject_id=sct.sub_id\n"
			+ "					group by 3,4) as a on a.arm_id=vw.ac_arm_id and a.ec_exam_id=2\n"
			+ "		where vw.opd_status_id='1'and vw.opd_partd=0 and vw.opd_isactive='yes' "+q3+"\n"
			+ "		and  date_part('year',age('"+ exam_schedule_dt2 +"',"+q1+")) >= "+min_year2+" and   date_part('year',age('"+exam_schedule_dt2+"',"+q1+")) <= "+max_year2+" "+q2+"   )ab "+SearchValue 
			;
	PreparedStatement stmt = conn.prepareStatement(q);
	stmt = setQueryWhereClause_SQL(stmt,Search);
	System.out.println("stmt===gggg===="+stmt);
	ResultSet rs = stmt.executeQuery();
	while (rs.next()) {
		total = rs.getInt(1);
	}
	rs.close();
	stmt.close();
	conn.close();
} catch (SQLException e) {
	e.printStackTrace();
} finally {
	if (conn != null) {
		try {
			conn.close();
		} catch (SQLException e) {
		}
	}
}
return (long) total;
}


public String GenerateQueryWhereClause_SQL(String Search) {
String SearchValue ="";
if(!Search.equals("")) {
Search = Search.toLowerCase();
	SearchValue =" and ( ";


	SearchValue +=" lower(opd_unit) like ? or"
		+" lower(opc_personal_code) like ? or "
			+ "lower(opd_officer_name) like ? or to_char(opd_date_of_seniority,'dd-MM-yyyy') like ? or  "
			+ " lower(ac_arm_description) like ? )";
}
return SearchValue;

}


public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search) {
int flag = 0;
try {
if(!Search.equals("")) {
		
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
	
		
	}
}catch (Exception e) {}
return stmt;
}


public ArrayList<ArrayList<String>> getExportPartDForExcel(int es_id, String partb_status2) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	String whr = "";

	try {
System.err.println("partb_status2==========="+partb_status2);
if(partb_status2 != null) {
		if(partb_status2.equals("yes")) {
			whr="and vpd.opd_partb != 0";
		}
}
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
	
		
		q="select ROW_NUMBER() OVER(order by vpd.opd_personal_id) as sr_no, vpd.opc_personal_code, vpd.opc_suffix_code, vpd.opd_officer_name, vpd.ac_arm_description,TO_CHAR(vpd.opd_dob,'DD/MM/YYYY') as opd_dob,\n"
				+ "TO_CHAR(vpd.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm,\n"
				+ "TO_CHAR(vpd.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority,\n"
				+ "vpd.rc_rank_name, vpd.ct_comm_type,\n"
				+ " getSubjectNameFromCode(vpd.pbda_sub_code,2) as sunma,vpd.pbda_sub_code,\n"
				+ " ofa.oa_application_id\n"
				+ "\n"
				+ "from officer_application ofa \n"
				+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
				+ "inner join partb_d_application pbd on pbd.oa_application_id = ofa.oa_application_id\n"
				+ "where es_id=? and ofa.oa_status_id=1 and vpd.opd_status_id=1 and vpd.opd_isactive='yes' "+whr+"";
		
		stmt = conn.prepareStatement(q);
		int i=0;
	
		stmt.setInt(1, es_id);
		System.err.println("stmt==========="+stmt);
		ResultSet rs = stmt.executeQuery();
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("sr_no"));//0
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			
			Data=DataPre+DataM;
			
			list.add(Data+(rs.getString("opc_suffix_code")));
			list.add(rs.getString("opd_officer_name"));//2
			list.add(rs.getString("ac_arm_description"));//3
			list.add(rs.getString("opd_dob"));//4	
			list.add(rs.getString("opd_date_of_comm"));//5	
			list.add(rs.getString("ct_comm_type"));//6
			list.add(rs.getString("rc_rank_name"));//7		
			
			list.add(rs.getString("opd_date_of_seniority"));//8
			
			
			StringBuilder input1 = new StringBuilder();
			input1.append(rs.getString("sunma"));
			input1.reverse();
			list.add(input1.toString());
			
//			if(!table.equals("excelL")) {
//			list.add(rs.getString("pbda_sub_code"));//10
//			list.add(rs.getString("opc_personal_code")+(rs.getString("opc_suffix_code")));
//			}
		
			list.add(rs.getString("oa_application_id"));//10	
			
			alist.add(list);
			
			
			
			
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}
}