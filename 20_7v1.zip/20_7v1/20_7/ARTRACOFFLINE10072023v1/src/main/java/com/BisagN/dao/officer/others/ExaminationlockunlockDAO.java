package com.BisagN.dao.officer.others;

import java.util.ArrayList;

public interface ExaminationlockunlockDAO {
	
	public ArrayList<ArrayList<String>> getbegindatefrmexmschedule(int exm_name);
	public ArrayList<ArrayList<String>> getstatusfrmexmschedule(String exm_name);
	public ArrayList<ArrayList<String>> getBeignDateForGnrtbooklet(String exm_name);

}
