package com.BisagN.controller.office.others;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.apache.poi.hssf.usermodel.DVConstraint;
//import org.apache.poi.hssf.usermodel.HSSFDataValidation;
//import org.apache.poi.hssf.usermodel.HSSFDataValidation;
//import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellCopyPolicy;
import org.apache.poi.ss.usermodel.CellStyle;
//import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFDataValidation;
import org.apache.poi.xssf.usermodel.XSSFDataValidationConstraint;
import org.apache.poi.xssf.usermodel.XSSFDataValidationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.springframework.web.servlet.view.document.AbstractXlsView;
import org.springframework.web.servlet.view.document.AbstractXlsxView;


public  class ExportExcel_genExcelController extends AbstractXlsxView  {
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	String SubjectName = "";
	String Exm_name = "";
	String begindateShow = "";
	ArrayList<ArrayList<String>> indexlist;
	public ExportExcel_genExcelController(String Type, List<String> TH, String Heading, String username,ArrayList<ArrayList<String>> indexlist,String SubjectName,String Exm_name,String begindateShow) {
		this.Type = Type;
		this.TH = TH;
		this.Heading = Heading;
		this.username = username;
		this.indexlist=indexlist;
		this.SubjectName=SubjectName;
		this.Exm_name=Exm_name;
		this.begindateShow=begindateShow;
	}

	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest arg2,
			HttpServletResponse response) throws Exception {
//		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
//		String file_name = datetimestamp.currentDateWithTimeStampString();
		response.setHeader("Content-disposition", "attachment; filename=\"" + "20/04/20201" + ".xlsx\"");

		@SuppressWarnings("unchecked")
		ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("userList");
		String que_count= list.get(0).get(5);
		String section_count= list.get(0).get(2);
		System.err.println("section_count========"+section_count);

		Font fontBoldItalic = workbook.createFont();
		fontBoldItalic.setBold(true);
		fontBoldItalic.setUnderline(XSSFFont.U_SINGLE);
		fontBoldItalic.setItalic(false);
		
		CellStyle csr123 = workbook.createCellStyle();
		csr123.setAlignment(HorizontalAlignment.CENTER);
		csr123.setFont(fontBoldItalic);
		
		CellStyle csr4 = workbook.createCellStyle();
		csr4.setAlignment(HorizontalAlignment.CENTER);
		csr4.setLocked(false);
		
		CellStyle indccs = workbook.createCellStyle();
		indccs.setAlignment(HorizontalAlignment.CENTER);
		

		XSSFSheet sheet = (XSSFSheet) workbook.createSheet("User List");
		
	    final CellCopyPolicy options = new CellCopyPolicy();
		options.setCopyCellValue(false);
		
		CellRangeAddress mergedRegion1 = new CellRangeAddress(0,0,0,Integer.parseInt(que_count)+2); 
		sheet.addMergedRegion(mergedRegion1);
		CellRangeAddress mergedRegion2 = new CellRangeAddress(1,1,0,Integer.parseInt(que_count)+2); 
		sheet.addMergedRegion(mergedRegion2);

		int rowNum0 = 0;
			Row row = sheet.createRow(rowNum0++);
			for (int j = 0; j < 2; j++) {
				Cell cell = row.createCell(j);
				cell.setCellValue(" "+Exm_name+" PROMOTION EXAMINATION : "+begindateShow);
				cell.setCellStyle(csr123);
			}
		
		int rowNum1 = 1;
		for (int i = 0; i < 1; i++) {
			 row = sheet.createRow(rowNum1++);
			for (int j = 0; j < 2; j++) {
				Cell cell = row.createCell(j);
				cell.setCellValue("MARKS SCORED BY CANDIDATES APPEARING IN "+SubjectName+" ");
				cell.setCellStyle(csr123);
			}
		}
		
		int rowNum2 = 2;
		int section_Que_count=0;
			row = sheet.createRow(rowNum2);
			int k1=2;
			int secno=1;	
			Cell cellr;
			for (int j = 2,i=0; j <= Integer.parseInt(section_count)+1; j++,i++) {
				section_Que_count+= Integer.parseInt(list.get(i).get(4));
				
					 cellr = row.createCell(k1);
					int k2=k1+Integer.parseInt(list.get(i).get(4));
					if(Integer.parseInt(list.get(i).get(4)) != 1) {
					CellRangeAddress mergedRegion3 = new CellRangeAddress(2,2,k1,k2-1); // row 1 to 14 col A to C
					
					sheet.addMergedRegion(mergedRegion3);
					}
					cellr.setCellValue("Sec "+ secno+" Max Marks "+list.get(i).get(6));
					cellr.setCellStyle(csr123);
				k1=k2;
				secno++;
			}
			int ttlsec=section_Que_count+2;
			
			Cell cell_Se = row.createCell(ttlsec);
			cell_Se.setCellValue("TOTAL OF SECTION");
			if(Integer.parseInt(section_count)!=1) {
				CellRangeAddress mergedRegion5 = new CellRangeAddress(2,2,ttlsec,(ttlsec+secno)-2);
				sheet.addMergedRegion(mergedRegion5);
			}
			cell_Se.setCellStyle(csr123);
		
		int rowNum3 = 3;
			Row row2 = sheet.createRow(rowNum3++);
			Cell cell1 = row2.createCell(0);
			cell1.setCellValue("S.No");
			cell1.setCellStyle(csr123);
			
			Cell cell2 = row2.createCell(1);
			cell2.setCellValue("Index No");
			cell2.setCellStyle(csr123);
			int k=1;
		
		
			for (int j = 2; j <(section_Que_count)+2; j++) {
				Cell cell = row2.createCell(j);
				cell.setCellValue("Q"+k+"");
				cell.setCellStyle(csr123);
				k++;
			}
			
			ttlsec=section_Que_count+2;
			for(int i=1;i<secno;i++) {
				Cell cell3 = row2.createCell(ttlsec);
				cell3.setCellValue("Sec "+i);
				cell3.setCellStyle(csr123);
				ttlsec++;
			}
			Cell cell3 = row2.createCell(ttlsec);
			cell3.setCellValue("Total Marks");
			cell3.setCellStyle(csr123);

		int rowNum4 = 4;
		Cell cellm = null;
		for (int i3 = 0,k2=1; i3 < indexlist.size(); i3++,k2++) {
			List<String> l = indexlist.get(i3);
			Row row3 = sheet.createRow(rowNum4);
			Cell cell = row3.createCell(0);
			cell.setCellValue(k2);
			Cell celli = row3.createCell(1);
			celli.setCellValue(l.get(1));
			celli.setCellStyle(indccs);
			
			int m2=2;
				for (int i=0; i < Integer.parseInt(section_count);i++) {
					 int j =m2;
					for(int m=0;m<Integer.parseInt(list.get(i).get(4));m++) {
						 cellm = row3.createCell(j);
						 cellm.setCellStyle(csr4);
						CellRangeAddressList addressList = new CellRangeAddressList( rowNum4,rowNum4, j, j);
						XSSFDataValidationHelper dvHelper = new XSSFDataValidationHelper((XSSFSheet) sheet);
				        XSSFDataValidationConstraint dvConstraint = (XSSFDataValidationConstraint) dvHelper.createNumericConstraint(
				                XSSFDataValidationConstraint.ValidationType.INTEGER,
				                XSSFDataValidationConstraint.OperatorType.BETWEEN, "0", String.valueOf(list.get(i).get(6)));
				        XSSFDataValidation validation = (XSSFDataValidation) dvHelper.createValidation(dvConstraint, addressList);
				        validation.setSuppressDropDownArrow(true);
				        validation.setShowErrorBox(true);
				        sheet.addValidationData(validation);
								 j++;
					}
					m2=m2+Integer.parseInt(list.get(i).get(4));
				}
				
				ttlsec=section_Que_count+2;
				int r1=2;
				for(int i=0;i<list.size();i++) {
					Cell cell4 = row3.createCell(ttlsec);
					int r2=r1+Integer.parseInt(list.get(i).get(4))-1;
					cell4.setCellFormula("SUM("+CellReference.convertNumToColString(r1)+""+(rowNum4+1)+":"+CellReference.convertNumToColString(r2)+""+(rowNum4+1)+")");
					ttlsec++;
					r1=r2+1;
				}
				r1=2;
				Cell cell4 = row3.createCell(ttlsec);
				cell4.setCellFormula("SUM("+CellReference.convertNumToColString(r1)+""+(rowNum4+1)+":"+CellReference.convertNumToColString((section_Que_count+1))+""+(rowNum4+1)+")");
			rowNum4++;
		}
		
		
		int rowNum5 = rowNum4;
	 
			 row = sheet.createRow(rowNum5++);
			 
				Cell cell = row.createCell(1);
				cell.setCellValue("Average");
				cell.setCellStyle(csr123);
			 
		int colmcont = 2;
		
		int lastrowcont = rowNum5-1;
		
		
		for (int j = 2; j <(section_Que_count)+2; j++) {
 
			 cell = row.createCell(j);
		 
			cell.setCellFormula("AVERAGE("+CellReference.convertNumToColString(colmcont)+"4:"+CellReference.convertNumToColString((colmcont))+""+(lastrowcont)+")");
		 
			
			colmcont++;
		 
		}
		

		for (int d = 0; d < ((section_Que_count+ttlsec)+3); d++) {
			sheet.autoSizeColumn(d, true);
		}
		sheet.protectSheet("ripal@123");
	}


	}