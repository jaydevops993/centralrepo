package com.BisagN.dao.officer.report;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;

@Service
public class DSSC_DSTSC_REPORTDAOImpl implements DSSC_DSTSC_REPORTDAO {

	@Autowired
	private DataSource dataSource;

	CommonController comm = new CommonController();

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	public ArrayList<ArrayList<String>> getWithDrawalsDSSC(int es_id) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "select vpd.opc_personal_code,vpd.opc_suffix_code, vpd.opd_officer_name,vpd.ac_arm_description,vpd.rc_rank_name,vpd.opd_officer_name,vpd.opd_unit from withdrawal_application wd \n"
					+ "inner join officer_application ofa on ofa.oa_application_id = wd.oa_application_id\n"
					+ "inner join vw_personal_details vpd on vpd.opd_personal_id=ofa.opd_personal_id\n"
					+ "where ofa.es_id=? order by vpd.opc_personal_code asc   ";

			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);

			System.err.println("withdrawal====" + stmt);
			ResultSet rs = stmt.executeQuery();
			int i = 1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				
				String Data = rs.getString("opc_personal_code");
				String DataPre = "";
				String DataM = "";
				if (Data.contains("NTR") || Data.contains("NTS")) {
					DataPre = Data.substring(0, 3);
					DataM = Data.substring(4);
				} else {
					DataPre = Data.substring(0, 2);
					DataM = Data.substring(3);
				}
				//System.err.println("DataPre " + DataPre);
				//System.err.println("DataM " + DataM);

				Data = DataPre + DataM;
				list.add(String.valueOf(i));
				list.add(Data + "  " + (rs.getString("opc_suffix_code")));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("ac_arm_description"));
				list.add(rs.getString("opd_unit"));
				
				alist.add(list);
				i++;

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	@SuppressWarnings("unused")
	public ArrayList<ArrayList<String>> getJcCourseCandidateWiseDetails() {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "select vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_jc_course_grading,\n"
					+ "vpd.opd_officer_name from vw_personal_details vpd  order by vpd.opc_personal_code asc ";

			stmt = conn.prepareStatement(q);
//		stmt.setInt(1, es_id);

			System.err.println("withdrawal====" + stmt);
			ResultSet rs = stmt.executeQuery();
			int i = 1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();

				String Data = rs.getString("opc_personal_code");
				String DataPre = "";
				String DataM = "";
				if (Data.contains("NTR") || Data.contains("NTS")) {
					DataPre = Data.substring(0, 3);
					DataM = Data.substring(4);
				} else {
					DataPre = Data.substring(0, 2);
					DataM = Data.substring(3);
				}
				//System.err.println("DataPre " + DataPre);
				//System.err.println("DataM " + DataM);

				Data = DataPre + DataM;
				
				list.add(Data + "  " + (rs.getString("opc_suffix_code")));
				list.add(rs.getString("opd_officer_name"));

				String jc_course = rs.getString("opd_jc_course_grading");
				System.out.println("jc_course----" + jc_course);
				if (rs.getString("opd_jc_course_grading") == "null" || rs.getString("opd_jc_course_grading") == null) {

					list.add("No");
					list.add("NA");

				}
				if (rs.getString("opd_jc_course_grading") != "null" || rs.getString("opd_jc_course_grading") != null) {
					list.add("Yes");
					list.add(rs.getString("opd_jc_course_grading"));
				}

				alist.add(list);
				i++;

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	public ArrayList<ArrayList<String>> getCompensatoryChnaceReport(String es_year) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "select vpd.opc_personal_code, vpd.opc_suffix_code , vpd.opd_officer_name,vpd.rc_rank_name, dsch.dcc_compens_year from dssc_compens_chance_new dsch \n"
					+ "inner join vw_personal_details vpd on vpd.opd_personal_id = dsch.opd_personal_id\n"
					+ "where dsch.dcc_compens_year::text=? order by vpd.opc_personal_code asc ";

			stmt = conn.prepareStatement(q);
			stmt.setString(1, es_year);

			System.err.println("comps====" + stmt);
			ResultSet rs = stmt.executeQuery();
			int i = 1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();

				
				String Data = rs.getString("opc_personal_code");
				String DataPre = "";
				String DataM = "";
				if (Data.contains("NTR") || Data.contains("NTS")) {
					DataPre = Data.substring(0, 3);
					DataM = Data.substring(4);
				} else {
					DataPre = Data.substring(0, 2);
					DataM = Data.substring(3);
				}
				//System.err.println("DataPre " + DataPre);
				//System.err.println("DataM " + DataM);

				Data = DataPre + DataM;
				list.add(Data + "  " + (rs.getString("opc_suffix_code")));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("rc_rank_name"));

				list.add(rs.getString("dcc_compens_year"));

				alist.add(list);
				i++;

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

//===========================PART ABSENTEES=======================//

	public ArrayList<ArrayList<String>> PartAbsenteesForDSSC_DSTSC(int es_id) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "select a.opd_personal_id,vpd.rc_rank_name , vpd.opc_personal_code , vpd.opd_officer_name ,string_agg(a.sub,',')as \n"
					+ "subject,vpd.opc_suffix_code, vpd.opd_unit,ecc.ecc_name from (select oa.opd_personal_id,sc.sc_subject_id,sc.sc_subject_name as sub,oa.oa_center_granted												\n"
					+ "	from officer_application oa, dssc_tsoc_application pbd,subject_code sc										\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and (oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =70)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 70 and ab_marks_obtained is null))										\n"
					+ "union all												\n"
					+ "	select oa.opd_personal_id,sc.sc_subject_id,sc.sc_subject_name as sub,oa.oa_center_granted											\n"
					+ "	from officer_application oa, dssc_tsoc_application pbd,subject_code sc												\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and 											\n"
					+ "	(oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =71)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 71 and ab_marks_obtained is null))										\n"
					+ "union all												\n"
					+ "	select oa.opd_personal_id,sc.sc_subject_id,sc.sc_subject_name as sub,oa.oa_center_granted											\n"
					+ "	from officer_application oa, dssc_tsoc_application pbd,subject_code sc												\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and 											\n"
					+ "	(oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =72)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 72 and ab_marks_obtained is null))										\n"
					+ "												   union all\n"
					+ "	select oa.opd_personal_id,sc.sc_subject_id,sc.sc_subject_name as sub,oa.oa_center_granted											\n"
					+ "	from officer_application oa, dssc_tsoc_application pbd,subject_code sc											\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and 											\n"
					+ "	(oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =73)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 73 and ab_marks_obtained is null))										\n"
					+ "												   union all\n"
					+ "	select oa.opd_personal_id,sc.sc_subject_id,sc.sc_subject_name as sub,oa.oa_center_granted											\n"
					+ "	from officer_application oa, dssc_tsoc_application pbd,subject_code sc												\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and 											\n"
					+ "	(oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =74)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 74 and ab_marks_obtained is null))\n"
					+ "	union all\n"
					+ "	\n"
					+ "	select oa.opd_personal_id,sc.sc_subject_id,sc.sc_subject_name as sub,oa.oa_center_granted											\n"
					+ "	from officer_application oa, dssc_tsoc_application pbd,subject_code sc												\n"
					+ "	where oa.oa_application_id = pbd.oa_application_id											\n"
					+ "	and es_id = ?											\n"
					+ "	and oa.in_index_id<>0											\n"
					+ "	and oa.oa_status_id=1											\n"
					+ "	and 											\n"
					+ "	(oa.oa_application_id not in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id =75)or 										\n"
					+ "	oa.oa_application_id in											\n"
					+ "		(select oa_application_id from answer_book where sc_subject_id= 75 and ab_marks_obtained is null)))a\n"
					+ "	inner join vw_personal_details vpd on vpd.opd_personal_id=a.opd_personal_id  \n"
					+ "	inner join exam_center_code ecc on a.oa_center_granted=ecc.ecc_center_code"
					+ "inner join subject_code sc on sc.sc_subject_id=a.sc_subject_id\n"
					+ "	group by 1,2,3,4,vpd.opc_suffix_code,vpd.opd_unit,ecc.ecc_name";

			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			stmt.setInt(2, es_id);
			stmt.setInt(3, es_id);
			stmt.setInt(4, es_id);
			stmt.setInt(5, es_id);
			stmt.setInt(6, es_id);
			ResultSet rs = stmt.executeQuery();
			System.err.println("absentees========" + stmt);
			int i=0;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data = rs.getString("opc_personal_code");
				String DataPre = "";
				String DataM = "";
				if (Data.contains("NTR") || Data.contains("NTS")) {
					DataPre = Data.substring(0, 3);
					DataM = Data.substring(4);
				} else {
					DataPre = Data.substring(0, 2);
					DataM = Data.substring(3);
				}
				//System.err.println("DataPre " + DataPre);
				//System.err.println("DataM " + DataM);

				Data = DataPre + DataM;

				//System.err.println("pers_cde==rrrrr=====" + Data);
				list.add(String.valueOf(i+1));
				list.add(Data + "  " + rs.getString("opc_suffix_code"));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("opd_unit"));
				list.add(rs.getString("ecc_name"));
				
				list.add(rs.getString("subject"));
				alist.add(list);
				i++;

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

//========================ArmWise Analysis=======================//
	public ArrayList<ArrayList<String>> getArmwiseAnalysisReport(int es_id) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "select vw.ac_arm_description, ac.ac_arm_order,\n"
					+ "count(ofa.oa_application_id) filter(where ofa.in_index_id != 0) as Total_appeared,\n"
					+ "Count(qua.oa_applicant_id) filter(where qua.nominatedfor='COMPETITIVE') as Comp_count,\n"
					+ "count(qua.oa_applicant_id) filter (where qua.nominatedfor='DSSC')  as dssc_count,\n"
					+ "count(qua.oa_applicant_id) filter (where qua.nominatedfor='DSTSC')  as dstsc_count,\n"
					+ "count(qua.oa_applicant_id) filter (where qua.nominatedfor='DSSC Res') as dssc_reserve,\n"
					+ "count(qua.oa_applicant_id) filter (where qua.nominatedfor='DSTSC Res' ) as dstsc_reserve\n"
					+ "from vw_personal_details vw\n" + "inner join arm_codes ac on ac.ac_arm_id = vw.ac_arm_id\n"
					+ "inner join officer_application ofa on ofa.opd_personal_id = vw.opd_personal_id\n"
					+ "inner join qualified_officers qua on ofa.oa_application_id=qua.oa_applicant_id\n"
					+ "where ofa.es_id=? group by 1,ac.ac_arm_order order by ac.ac_arm_order";

			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);

			System.err.println("comps====" + stmt);
			ResultSet rs = stmt.executeQuery();
			double total_appeared_t = 0;
			double Comp_count_appeared_t = 0;
			double dssc_count_appeared_t = 0;
			double dstsc_count_appeared_t = 0;
			double dssc_reserve_appeared_t = 0;
			double dssc_dstsc_reserve_appeared_t = 0;

			
			DecimalFormat df_double = new DecimalFormat("0.00");
			DecimalFormat df_int = new DecimalFormat("0");
			
			int i = 1;
			int sum = 0;
			while (rs.next()) {

				double total_candidate_appeared = Integer.parseInt(rs.getString("Total_appeared"));
				total_appeared_t += total_candidate_appeared;

				double Comp_count_appeared = Integer.parseInt(rs.getString("Comp_count"));
				Comp_count_appeared_t += Comp_count_appeared;

				double dssc_count_appeared = Integer.parseInt(rs.getString("dssc_count"));
				dssc_count_appeared_t += dssc_count_appeared;

				double dstsc_count_appeared = Integer.parseInt(rs.getString("dstsc_count"));
				dstsc_count_appeared_t += dstsc_count_appeared;

				double dssc_dstsc_reserve_appeared = Integer.parseInt(rs.getString("dssc_reserve")) + Integer.parseInt(rs.getString("dstsc_reserve"));
				dssc_dstsc_reserve_appeared_t += dssc_dstsc_reserve_appeared;

				ArrayList<String> list = new ArrayList<String>();

				list.add(rs.getString("ac_arm_description"));
				list.add(rs.getString("Total_appeared"));
				list.add(rs.getString("Comp_count"));
				list.add(rs.getString("dssc_count"));
				list.add(rs.getString("dstsc_count"));
				String dssc_reserve = rs.getString("dssc_reserve");
				String dstsc_reserve = rs.getString("dstsc_reserve");
				sum = Integer.parseInt(dssc_reserve) + Integer.parseInt(dstsc_reserve);
				list.add(String.valueOf(sum));
				alist.add(list);
				
				
				
				

			}
			
			
			ArrayList<String> list2 = new ArrayList<String>();
			list2.add("Total");
			list2.add(df_int.format(total_appeared_t));
			list2.add(df_int.format(Comp_count_appeared_t));
			list2.add(df_int.format(dssc_count_appeared_t));
			list2.add(df_int.format(dstsc_count_appeared_t));
			list2.add(df_int.format(dssc_dstsc_reserve_appeared_t));
			alist.add(list2);
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	// ========================Compatative merit list=======================//
	public ArrayList<ArrayList<String>> getcompatativemeritlistReport(int es_id) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "select vpd.opc_personal_code,vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name,vpd.ac_arm_order,vpd.ac_arm_description,\n"
					+ "vpd.opd_unit  from vw_personal_details vpd \n"
					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
					+ "inner join qualified_officers qua on ofa.oa_application_id=qua.oa_applicant_id\n"
					+ "where ofa.es_id= ? and qua.nominatedfor='COMPETITIVE' order by vpd.ac_arm_order,vpd.opc_personal_code ";

			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);

			System.err.println("comps====" + stmt);
			ResultSet rs = stmt.executeQuery();
			int i = 1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				list.add(String.valueOf(i));
				list.add(Data + "  " + rs.getString("opc_suffix_code"));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("opd_unit"));
				list.add(rs.getString("ac_arm_description"));
				alist.add(list);
				i++;
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	// ========================nominated dssc list=======================//
	public ArrayList<ArrayList<String>> getnominateddssclistReport(int es_id) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			q = "select vpd.opc_personal_code,vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name,vpd.ac_arm_description,\n"
					+ "vpd.opd_unit  from vw_personal_details vpd \n"
					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
					+ "inner join qualified_officers qua on ofa.oa_application_id=qua.oa_applicant_id\n"
					+ "where ofa.es_id= ? and qua.nominatedfor='DSSC' order by vpd.ac_arm_order,vpd.opc_personal_code ";

			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			System.err.println("nominated dssc list " + stmt);
			ResultSet rs = stmt.executeQuery();
			int i = 1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				System.out.println("DSSCDATA=========="+Data);
				list.add(String.valueOf(i));
				list.add(Data + "  " + rs.getString("opc_suffix_code"));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("opd_unit"));
				list.add(rs.getString("ac_arm_description"));
				alist.add(list);
				i++;
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	// ========================nominated dstsc list=======================//
	public ArrayList<ArrayList<String>> getnominateddstsclistReport(int es_id) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			q = "select vpd.opc_personal_code,vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name,vpd.ac_arm_description,\n"
					+ "vpd.opd_unit  from vw_personal_details vpd \n"
					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
					+ "inner join qualified_officers qua on ofa.oa_application_id=qua.oa_applicant_id\n"
					+ "where ofa.es_id= ? and qua.nominatedfor='DSTSC' order by vpd.ac_arm_order,vpd.opc_personal_code";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			System.err.println("nominated dstsc list " + stmt);
			ResultSet rs = stmt.executeQuery();
			int i = 1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				
				list.add(String.valueOf(i));
				list.add(Data + "  " + rs.getString("opc_suffix_code"));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("opd_unit"));
				list.add(rs.getString("ac_arm_description"));
				alist.add(list);
				i++;
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	// ========================reserve dssc list=======================//
	public ArrayList<ArrayList<String>> getreserveofficeristReport(int es_id) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			q = "select DISTINCT ofa.oa_application_id,vpd.opc_personal_code,vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name,vpd.ac_arm_description,vpd.ac_arm_order,\n"
					+ "vpd.opd_unit,  string_agg(cm.name,',') filter(where dsch.course_preference=1) as ch1,\n"
					+ "string_agg(cm.name,',') filter(where dsch.course_preference=2) as ch2 from vw_personal_details vpd \n"
					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
					+ "inner join qualified_officers qua on ofa.oa_application_id=qua.oa_applicant_id\n"
					+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
					+ "left join dssc_choice_tbl dsch on dsch.dscc_app_id = dssc.id\n"
					+ "inner join course_master cm on cm.choice_id=dsch.course_applied\n" + "\n"
					+ "where ofa.es_id=? and (qua.nominatedfor='DSSC Res' or qua.nominatedfor='DSTSC Res') \n"
					+ "group by 1,2,3,4,5,6,7,8 order by vpd.ac_arm_order,vpd.opc_personal_code ";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			System.err.println("reserve===========" + stmt);
			ResultSet rs = stmt.executeQuery();

			int i = 1;
			int sum = 0;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				list.add(String.valueOf(i));
				list.add(Data + "  " + rs.getString("opc_suffix_code"));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("opd_unit"));
				list.add(rs.getString("ch1"));
				list.add(rs.getString("ch2"));
				list.add(rs.getString("ac_arm_description"));
				alist.add(list);
				i++;

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	// ========================fail dssc list=======================//
	public ArrayList<ArrayList<String>> getfailofficeristReport(int es_id) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "select DISTINCT vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name, vpd.ac_arm_description,vpd.ac_arm_order,\n"
					+ "\n"
					+ "\n"
					+ " CASE WHEN (\n"
					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 70::text))\n"
					+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 70::text)\n"
					+ "		  ELSE 'ABS'\n"
					+ "		  end\n"
					+ "		  as tac_a,\n"
					+ "		  CASE WHEN (\n"
					+ "		  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 71::text))\n"
					+ "		  IS NOT NULL THEN  string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 71::text)\n"
					+ "		  ELSE 'ABS'\n"
					+ "		  end\n"
					+ "		  as tac_b\n"
					+ "          ,\n"
					+ " 		 CASE WHEN (\n"
					+ "	 	 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 72::text) )	  \n"
					+ "	     IS NOT NULL THEN 	  \n"
					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 72::text) \n"
					+ "	   	 ELSE 'ABS'\n"
					+ "		 end\n"
					+ "	   	 as adm_law,\n"
					+ "\n"
					+ "		 CASE WHEN (\n"
					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 73::text))	\n"
					+ "	  	 IS NOT NULL THEN \n"
					+ "		 string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 73::text)\n"
					+ "		 ELSE 'ABS'\n"
					+ "		 end\n"
					+ "	 	 as ca,\n"
					+ " 		 CASE WHEN (\n"
					+ "	     string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 74::text) )	\n"
					+ "	     IS NOT NULL THEN \n"
					+ "         string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 74::text) \n"
					+ "	     ELSE 'ABS'\n"
					+ "		  end\n"
					+ "	     as smts,\n"
					+ "        CASE WHEN (\n"
					+ "	    string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 75::text))\n"
					+ "	    IS NOT NULL THEN \n"
					+ "        string_agg(distinct case  when ab.ab_unfair_status=1 then 'UFM' when ab.ab_marks_obtained>= 500 then 'NP' else coalesce(ab.ab_marks_obtained::text,'0') end, ','::text\n"
					+ "		  ) filter (where ab.sc_subject_id::text = 75::text)\n"
					+ "	    ELSE 'ABS'\n"
					+ "		  end as mh\n"
					+ "from vw_personal_details vpd \n"
					+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id \n"
					+ "inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
					+ "where ofa.es_id=? and  not exists (select * from qualified_officers qua where qua.oa_applicant_id=ofa.oa_application_id and (qua.nominatedfor='DSSC Res' or qua.nominatedfor='DSTSC Res' or  qua.nominatedfor='DSTSC' or  qua.nominatedfor='DSSC' or  qua.nominatedfor='COMPETITIVE' or  qua.nominatedfor='ALMC' or  qua.nominatedfor='ISC' or qua.nominatedfor='ALMC Res' or qua.nominatedfor='ISC Res' )) \n"
					+ "group by 1,2,3,4,5,6 order by vpd.ac_arm_order\n"
					+ "";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			ResultSet rs = stmt.executeQuery();
			System.err.println("failed==========="+stmt);
			int i = 1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				list.add(String.valueOf(i));
				list.add(Data + "  " + rs.getString("opc_suffix_code"));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("ac_arm_description"));
				list.add(rs.getString("tac_a"));
				list.add(rs.getString("tac_b"));
				list.add(rs.getString("adm_law"));
				list.add(rs.getString("ca"));
				list.add(rs.getString("smts"));
				list.add(rs.getString("mh"));
				alist.add(list);
				i++;
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

//							//========================Compatative merit list=======================//
//							public ArrayList<ArrayList<String>> getALMC_ISCmeritlistReport(int es_id) {
//								
//								ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
//								Connection conn = null;
//								String q = "";
//								try {
//									conn = dataSource.getConnection();
//									PreparedStatement stmt = null;
//									q="select vpd.opc_personal_code,vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name,vpd.ac_arm_description,\n"
//											+ "vpd.opd_unit  from qualified_officers qua \n"
//											+ "inner join officer_application ofa on qua.oa_applicant_id=ofa.oa_application_id\n"
//											+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
//											+ "inner join vw_personal_details vpd on ofa.opd_personal_id = vpd.opd_personal_id\n"
//											+ "where ofa.es_id=? and ( qua.nominatedfor='ALMC' or qua.nominatedfor='ISC' or qua.nominatedfor='ALMC Res' or qua.nominatedfor='ISC Res' )";
//									stmt = conn.prepareStatement(q);
//									stmt.setInt(1, es_id);
//									System.err.println("ALMC===="+stmt);
//									ResultSet rs = stmt.executeQuery();
//							int i=1;
//									while (rs.next()) {
//										ArrayList<String> list = new ArrayList<String>();
//										list.add(String.valueOf(i));
//										list.add(rs.getString("opc_personal_code")+rs.getString("opc_suffix_code"));
//										list.add(rs.getString("rc_rank_name"));
//										list.add(rs.getString("opd_officer_name"));
//										list.add(rs.getString("opd_unit"));
//										alist.add(list);
//										i++;
//									}
//									rs.close();
//									stmt.close();
//									conn.close();
//								} catch (SQLException e) {
//									e.printStackTrace();
//								} finally {
//									if (conn != null) {
//										try {
//											conn.close();
//										} catch (SQLException e) {
//										}
//									}
//								}
//								return alist;
//							}
//							

	// ========================Compatative merit list=======================//
	public ArrayList<ArrayList<String>> getALMC_ISCmeritlistReport(int es_id) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "select vpd.opc_personal_code,vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name,vpd.ac_arm_description, \n"
					+ "											 vpd.opd_unit, vpd.ac_arm_order,\n"
					+ "											 \n"
					+ "                                             string_agg(distinct cm.name,',') filter(where dsch.course_preference=3) as ch1,\n"
					+ "                                             string_agg(distinct cm.name,',') filter(where dsch.course_preference=4) as ch2\n"
					+ "											 from qualified_officers qua  \n"
					+ "											 inner join officer_application ofa on qua.oa_applicant_id=ofa.oa_application_id \n"
					+ "											 inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id \n"
					+ "											 inner join vw_personal_details vpd on ofa.opd_personal_id = vpd.opd_personal_id \n"
					+ "											 left join dssc_choice_tbl dsch on dsch.dscc_app_id = dssc.id\n"
					+ "											inner join course_master cm on cm.choice_id=dsch.course_applied\n"
					+ "											where ofa.es_id=? and ( qua.nominatedfor='ALMC' or qua.nominatedfor='ISC' or qua.nominatedfor='ALMC Res' or qua.nominatedfor='ISC Res' ) \n"
					+ "											GROUP by 1,2,3,4,5,6,7 order by vpd.ac_arm_order";

//									q="select vpd.opc_personal_code,vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name,vpd.ac_arm_description,\n"
//											+ "vpd.opd_unit  from qualified_officers qua \n"
//											+ "inner join officer_application ofa on qua.oa_applicant_id=ofa.oa_application_id\n"
//											+ "inner join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id\n"
//											+ "inner join vw_personal_details vpd on ofa.opd_personal_id = vpd.opd_personal_id\n"
//											+ "where ofa.es_id=? and ( qua.nominatedfor='ALMC' or qua.nominatedfor='ISC' or qua.nominatedfor='ALMC Res' or qua.nominatedfor='ISC Res' )";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			System.err.println("ALMC_with_choice====" + stmt);
			ResultSet rs = stmt.executeQuery();
			int i = 1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				list.add(String.valueOf(i));
				list.add(Data + "  " + rs.getString("opc_suffix_code"));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("opd_unit"));
				list.add(rs.getString("ch1"));
				list.add(rs.getString("ch2"));
				list.add(rs.getString("ac_arm_description"));
				alist.add(list);
				i++;
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}


	// ========================Compatative merit list=======================//
	public ArrayList<ArrayList<String>> getACRndFdMarksReport(int es_id) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			q = "select vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name, vpd.opd_officer_name,\n"
					+ "cp.cpv_mks, cp.fd_service_mks from cpv cp\n"
					+ "inner join vw_personal_details vpd on vpd.opd_personal_id = cp.opd_personal_id \n"
					+ "inner join officer_application ofa on ofa.oa_application_id = cp.oa_application_id\n"
					+ "where ofa.es_id=? and ofa.in_index_id != 0";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			System.err.println("ACR and FD Marks Reports====" + stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				list.add(Data + "  " + rs.getString("opc_suffix_code"));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("cpv_mks"));
				list.add(rs.getString("fd_service_mks"));
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

}
