package com.BisagN.dao.officer.course;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface MeritandResultGenerationDao {
	
	public ArrayList<ArrayList<String>> getcourseandmeritlist(int es_id);
	public ArrayList<ArrayList<String>> getwithdrawList(int startPage, int pageLength, String Search,
			String orderColunm, String orderType,int es_id,String personal_no) ;
	public long getReportListwithdrawTotalCount(String Search,int es_id,String personal_no);
	public ArrayList<ArrayList<String>> getcourseandmeritlistfordssc(int es_id);
	
	
	public ArrayList<ArrayList<String>> getupgradationmeritList(int startPage, int pageLength, String Search,
			String orderColunm, String orderType,int es_id,String choice_type_id ) ;
	public long getReportListupgradationmeritTotalCount(String Search,int es_id,String choice_type_id);
	
	
	

	public List<Map<String, Object>> getMeritReportDataList(int startPage, String pageLength, String Search,
			String orderColunm, String orderType, HttpSession session,int es_id)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	
	public long getMeritTotalCount(String Search,int es_id);
}
