package com.BisagN.dao.officer.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class SearchResultswithheldDAOimpl implements SearchResultswithheldDAO {
	
	
	
	@Autowired
	private DataSource dataSource;
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	public boolean checkIsIntegerValue(String Search) {
		return Search.matches("[0-9]+");
	}
	
	
	public ArrayList<ArrayList<String>> getReportListResultwithheld(int startPage,String pageLength,String Search,String orderColunm,
			String orderType,int es_id,String opd_personal_id, HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, 
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{

		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search);

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
String q1= "";

if(!opd_personal_id.equals("")) {
	
	q1+= "and rw.personal_no=?";
			
}

		try {
			conn = dataSource.getConnection();

			q = "select ROW_NUMBER() OVER(order by rw.id) as sr_no, rw.personal_no,rw.off_name,rw.unit,rw.res_status_id,ofa.oa_center_granted, ecc.ecc_name,ofarm.ac_arm_id, ar.ac_arm_description,rw.id,rw.oa_appllication_id \n"
					+ "				from results_withheld rw\n"
					+ "			inner join officer_application ofa on ofa.oa_application_id=rw.oa_appllication_id\n"
					+ "			inner join exam_center_code ecc on ofa.oa_center_granted=ecc.ecc_center_code\n"
					+ "			inner join officer_arm ofarm on ofarm.opd_personal_id = ofa.opd_personal_id\n"
					+ "				inner join arm_codes ar on ar.ac_arm_id = ofarm.ac_arm_id\n"
					+ "			where ofa.es_id=? "+q1+" " + SearchValue ;
			
			

			PreparedStatement stmt = conn.prepareStatement(q);

			stmt = setQueryWhereClause_SQL(stmt, Search);
			stmt.setInt(1, es_id);

if(!opd_personal_id.equals("")) {
	
	stmt.setString(2, opd_personal_id);

}
			
			System.err.println("stmt========bbbb======"+stmt);

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("sr_no"));//2
				list.add(rs.getString("personal_no"));//3
				list.add(rs.getString("off_name"));//4	
				list.add(rs.getString("ac_arm_description"));//6
				list.add(rs.getString("oa_appllication_id"));//7		
				
				String enckey = "commonPwdEncKeys";
				Cipher c = hex_asciiDao.EncryptionSHA256Algo(session, enckey);
				String EncryptedPk = new String(
						Base64.encodeBase64(c.doFinal(rs.getString("id").toString().getBytes())));
				
				
				String EncryptedPk2 = new String(
						Base64.encodeBase64(c.doFinal(rs.getString("oa_appllication_id").toString().getBytes())));
				
System.err.println("EncryptedPk2---------"+EncryptedPk2);
				String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('" + EncryptedPk
						+ "')}else{ return false;}\"";
				String updateButton = "<i class='action_icons action_update' " + Update + " title='Release Data'></i>";
				
				
				
				String Print = "onclick=\"  if (confirm('Are you sure you want to Print?') ){printData('" + EncryptedPk2
						+ "')}else{ return false;}\"";
				String printButton = "<i class='action_icons action_view' " + Print + " title='Release Data'></i>";
				
				
				
				

				
			String res_status= rs.getString("res_status_id");
			
			if(res_status.equals("0")) {
				
				list.add("Release");
				
			}
			
          if(res_status.equals("1")) {
        	  list.add("With Held");
				
			}
          
				list.add(updateButton+printButton);
				alist.add(list);
//				System.err.println("list---------"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	public long getReportListResultwithheldCount(String Search,int es_id,String opd_personal_id) {
		
		
		String SearchValue = GenerateQueryWhereClause_SQL(Search);
		int total = 0;
		Connection conn = null;
		try {
			
			String q = "";
			String q1= "";

			if(!opd_personal_id.equals("")) {
				
				q1+= "and rw.personal_no=?";
						
			}
			conn = dataSource.getConnection();
			
			
		q="select count(*) from(select rw.id, rw.personal_no, rw.rc_rank_name,rw.off_name,rw.unit,ofa.oa_center_granted, ecc.ecc_name,ofarm.ac_arm_id, ar.ac_arm_description\n"
				+ "from results_withheld rw\n"
				+ "inner join officer_application ofa on ofa.oa_application_id=rw.oa_appllication_id\n"
				+ "inner join exam_center_code ecc on ofa.oa_center_granted=ecc.ecc_center_code\n"
				+ "inner join officer_arm ofarm on ofarm.opd_personal_id = ofa.opd_personal_id\n"
				+ "inner join arm_codes ar on ar.ac_arm_id = ofarm.ac_arm_id\n"
				+ "where ofa.es_id=?  "+q1+" "+SearchValue+") as a ";
			
			PreparedStatement stmt = conn.prepareStatement(q);
			
			stmt = setQueryWhereClause_SQL(stmt, Search);
			stmt.setInt(1, es_id);
			
			if(!opd_personal_id.equals("")) {
				
				stmt.setString(2, opd_personal_id);

			}
				
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				total = rs.getInt(1);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search) {
		String SearchValue = "";
		if (!Search.equals("")) {
			Search = Search.toLowerCase();
			SearchValue = " and ( ";
//			if (checkIsIntegerValue(Search)) {
//				SearchValue += " rw.id=? or ";
////				SearchValue += " area_id=? or ";
//				
//			}
			//SearchValue += " lower(area_name) like ? )";
			SearchValue += "lower(rw.off_name) like ? or lower(rw.personal_no) like ? or lower(ar.ac_arm_description) like ? )";
		}
		return SearchValue;
	}


	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt, String Search) {
		int flag = 1;
		try {
			if (!Search.equals("")) {
				
				if (checkIsIntegerValue(Search)) {
					flag += 1;
					stmt.setInt(flag, Integer.parseInt(Search));
				}
				
				flag += 1;
				stmt.setString(flag, "%" + Search.toLowerCase() + "%");
				
				flag += 1;
				stmt.setString(flag, "%" + Search.toLowerCase() + "%");
				
				flag += 1;
				stmt.setString(flag, "%" + Search.toLowerCase() + "%");
				
			}
		} catch (Exception e) {
		}
		return stmt;
	}

	public ArrayList<ArrayList<String>> getLatestSerno(int es_id,int repo_no) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";

		

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

//			q = "select mrw.* from mv_result_withheld mrw where mrw.es_id=?";
			
			q="select ser_no from tb_partpass_fullpass_dtl where es_id=? and result="+repo_no+"   order by ser_no desc limit 1";

		
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ser_no"));
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	

}
