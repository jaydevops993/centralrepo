package com.BisagN.dao.officer.trans;


import java.util.List;
import java.util.Map;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import org.apache.commons.codec.binary.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import org.hibernate.Session;
import java.util.ArrayList;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;


public interface Examination_centreDAO {

public List<Map<String, Object>> getReportListExamination_centre(int startPage,String pageLength,String Search,String orderColunm,
		String orderType,String command, String exam,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
public long getReportListExamination_centreTotalCount(String Search,String command, String exam);
public String Deleteexamination_centre(String deleteid,HttpSession session);
public ArrayList<ArrayList<String>> getExcelexamination_centre(int startPage, String pageLength, String Search,
		String orderColunm, String orderType,String cc_command_id2,String ec_exam_id2,String table, HttpSession session)
		throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
		InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException ;
}
