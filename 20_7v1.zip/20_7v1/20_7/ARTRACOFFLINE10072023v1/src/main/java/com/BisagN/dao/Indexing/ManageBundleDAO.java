package com.BisagN.dao.Indexing;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_MASTER;

public interface ManageBundleDAO {
	
	

	public ArrayList<ArrayList<String>> getManageBundleDetails(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,int es_id,int sc_subject_id,int sub_subject_id,String userId,String role,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	public long getTotalCountgetManageBundleDetails(String Search,int es_id,int sc_subject_id,int sub_subject_id,String userId,String role);
	public ArrayList<ArrayList<String>> GetFirstBundleByEsId(String es_id) ;
	public ArrayList<ArrayList<String>> getIndxSlipCountByIbm(int es_id,int ibm_id, int user_id,String role);

	public String DeleteBundlmaster(int deleteid);
	public ArrayList<ArrayList<String>> getBundleCount(String esi_es_id,String objid,String sc_id);
	public ArrayList<ArrayList<String>> getBundleCountforOP(String esi_es_id,String objid,String sc_id);
	
}
