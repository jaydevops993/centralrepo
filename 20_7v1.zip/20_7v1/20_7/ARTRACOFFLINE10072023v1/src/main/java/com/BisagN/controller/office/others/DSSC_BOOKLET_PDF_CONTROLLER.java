package com.BisagN.controller.office.others;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Decoder.Text;

import org.apache.poi.hssf.util.HSSFColor.WHITE;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.BisagN.models.officers.others.DSSC_COURSE_VACANCY_RESERVE;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPTableEvent;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

public class DSSC_BOOKLET_PDF_CONTROLLER extends AbstractPdfView {
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";

	ArrayList<ArrayList<String>> armwiseanalysisresult;
	ArrayList<ArrayList<String>> SubjWiseAnalysis;
	ArrayList<ArrayList<String>> commandwiseresult;
	ArrayList<ArrayList<String>> fullypassed;
	ArrayList<ArrayList<String>> result_withheld;
	ArrayList<ArrayList<String>> partially_passed;
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";
	int totalRecords = 0;
	int page = 1;
	PdfTemplate total1;

	public DSSC_BOOKLET_PDF_CONTROLLER(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH;
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {

		document.open();
//		float fntSize, lineSpacing;
//		fntSize = 6.7f;
//		lineSpacing = 10f;
////		Paragraph p = new Paragraph(new Phrase(lineSpacing, Heading, FontFactory.getFont(FontFactory.COURIER, fntSize)));
////		document.add(p);
////		

		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 16, 1);
		Font fontTableHeading2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
		Font fontTableHeadingdataheadfirstpage = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 26, 1);

		Font fontTableHeadingMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingMainHead_Ml = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);

		Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		
		
		Font fontTableHeadingSubMainHead1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false,  6.7f, 1);

		Font fontTableHeadingSubMainHead_2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 6.7f, 1);
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 7f, 0);
		Font fontTableHeadingdatabold = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9.5f, 1);
		
		Font fontTableHeadingdataforFooter = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 0);

		Font fontTableHeadingdataforML2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 0);

		Font fontTablepara = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 0);

		Font fontTableHeadingSubMainHeadNew_2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingSubMainHeadNew = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 7, 1);

		Rectangle two = new Rectangle(590, 838);
//	Rectangle two = new Rectangle(838, 590);

		String es_year = (String) model.get("es_year1");
		String letter_no = (String) model.get("letter_no1");
		String letter_date1 = (String) model.get("letter_date1");
		String start_end_month = (String) model.get("start_end_month");
		String director_name1 = (String) model.get("director_name1");

		String year2 = (String) model.get("es_year1");
		String b_month = (String) model.get("b_month");
		String e_month = (String) model.get("e_month");

		String b_month2 = (String) model.get("b_month2");
		String e_month2 = (String) model.get("e_month2");

		String bdrday = (String) model.get("bdrday");
		String bedday = (String) model.get("bedday");
		
//		ArrayList<List<String>> getdsscCourseVacancyReserveList = (ArrayList<List<String>>) model.get("getdsscCourseVacancyReserveList");
//		List<String> l = getdsscCourseVacancyReserveList.get(0);
		
		String dsscCourseNo = (String) model.get("getdsscCourseVacancyReserveListForDSSC");
		String dstscCourseNo = (String) model.get("getdsscCourseVacancyReserveListForDSTSC");
		String ALMCCourseNo = (String) model.get("getdsscCourseVacancyReserveListForALMC");
		String ISCCourseNo = (String) model.get("getdsscCourseVacancyReserveListForISC");
		
		System.out.println("dsscCourseNo====="+dsscCourseNo);
		System.out.println("dstscCourseNo====="+dstscCourseNo);
		System.out.println("ALMCCourseNo====="+ALMCCourseNo);
		System.out.println("ISCCourseNo====="+ISCCourseNo);
		
		
		PdfPTable maintable = new PdfPTable(1);
		maintable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		maintable.setWidthPercentage(100);

		PdfPTable table_m1 = new PdfPTable(1);
		table_m1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_m1.setWidthPercentage(100);

		PdfPTable tabledata_m1 = new PdfPTable(1);
		tabledata_m1.setWidths(new int[] { 5 });
		tabledata_m1.setWidthPercentage(100 / 3.5f);
		tabledata_m1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata_m1.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata_m1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Chunk underline_m4 = new Chunk("RESTRICTED \n", fontTableHeading2);
		Chunk underline_m5 = new Chunk("EXAM SECTION ", fontTableHeading2);
		Chunk underline_m6 = new Chunk("DSSC/DSTSC ENTRANCE EXAM", fontTableHeading2);
		Chunk underline_m7 = new Chunk("(DSSC- " + dsscCourseNo + " & DSTSC- " + dstscCourseNo + " )", fontTableHeading2);

		Chunk underline_m8 = new Chunk("" + e_month + " " + year2, fontTableHeading2);
		Chunk underline_m9 = new Chunk("RESULTS", fontTableHeading2);

		underline_m4.setUnderline(0.1f, -2f);
		Phrase ph_m4 = new Phrase(underline_m4);
		ph_m4.setFont(fontTableHeading2);
		Paragraph cell_Mr = new Paragraph(ph_m4);
		cell_Mr.setAlignment(Element.ALIGN_CENTER);

		underline_m5.setUnderline(0.1f, -2f);
		Phrase ph_m5 = new Phrase(underline_m5);
		ph_m5.setFont(fontTableHeading2);
		Paragraph cell_M5 = new Paragraph(ph_m5);
		cell_M5.setAlignment(Element.ALIGN_CENTER);

		underline_m6.setUnderline(0.1f, -2f);
		Phrase ph_m6 = new Phrase(underline_m6);
		ph_m6.setFont(fontTableHeading2);
		Paragraph cell_M6 = new Paragraph(ph_m6);
		cell_M6.setAlignment(Element.ALIGN_CENTER);

		underline_m7.setUnderline(0.1f, -2f);
		Phrase ph_m7 = new Phrase(underline_m7);
		ph_m6.setFont(fontTableHeading2);
		Paragraph cell_M7 = new Paragraph(ph_m7);
		cell_M7.setAlignment(Element.ALIGN_CENTER);

		underline_m8.setUnderline(0.1f, -2f);
		Phrase ph_m8 = new Phrase(underline_m8);
		ph_m8.setFont(fontTableHeading2);
		Paragraph cell_M8 = new Paragraph(ph_m8);
		cell_M8.setAlignment(Element.ALIGN_CENTER);

		underline_m9.setUnderline(0.1f, -2f);
		Phrase ph_m9 = new Phrase(underline_m9);
		ph_m9.setFont(fontTableHeading2);
		Paragraph cell_M9 = new Paragraph(ph_m9);
		cell_M9.setAlignment(Element.ALIGN_CENTER);

		Image logo = null;
		try {
			@SuppressWarnings("deprecation")
			String dgis_logo = request.getRealPath("/") + "admin" + File.separator + "layout_file" + File.separator
					+ "images" + File.separator + "logo.png";
			logo = Image.getInstance(dgis_logo);
		} catch (BadElementException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		logo.setAlignment(Image.MIDDLE);
		logo.scaleAbsoluteHeight(80);
		logo.scaleAbsoluteWidth(80);
		logo.scalePercent(90);

		Chunk chunk = new Chunk(logo, 0, 100);
		// table_m1.addCell(new Phrase(chunk));

		Phrase ph1 = new Phrase();
		ph1.add(table_m1);

		PdfPCell cell_m1;
		cell_m1 = new PdfPCell();
		cell_m1.addElement(cell_Mr);
		cell_m1.addElement(new Paragraph("\n"));

		cell_m1.addElement(chunk);
		cell_m1.addElement(cell_M5);
		cell_m1.addElement(cell_M6);
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(cell_M7);
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(cell_M8);

		cell_m1.addElement(cell_M9);
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(cell_Mr);
		cell_m1.setBorder(0);
		table_m1.addCell(cell_m1);

//	document.add(table_m1);

//	super.buildPdfMetadata(model, document, request);

//super.buildPdfMetadata(model, document, request);

//==============Covering-letter===============//

		PdfPTable table_c2 = new PdfPTable(1);
		table_c2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_c2.setWidthPercentage(100);

		PdfPTable tabledata_C12 = new PdfPTable(1);
		tabledata_C12.setWidths(new int[] { 4 });
		tabledata_C12.setWidthPercentage(100 / 1f);
		tabledata_C12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C12.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C12.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable tabledata_C1 = new PdfPTable(1);
		tabledata_C1.setWidths(new int[] { 7 });
		tabledata_C1.setWidthPercentage(100 / 3f);
		tabledata_C1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C1.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable tabledata_C2 = new PdfPTable(1);
		tabledata_C2.setWidths(new int[] { 8 });
		tabledata_C2.setWidthPercentage(100 / 7.4f);
		tabledata_C2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C2.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C2.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable tabledata_C3 = new PdfPTable(2);
		tabledata_C3.setWidths(new int[] { 70, 30 });
		tabledata_C3.setWidthPercentage(100);
		tabledata_C3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C3.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C3.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable tabledata_C66 = new PdfPTable(1);
		tabledata_C66.setWidths(new int[] { 4 });
		tabledata_C66.setWidthPercentage(100 / 5.5f);
		tabledata_C66.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C66.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C66.getDefaultCell().setBorder(Rectangle.NO_BORDER);

//	Chunk underline_c12 = new Chunk("REGISTERED \n", fontTableHeading2);
//	underline_c12.setUnderline(0.1f, -2f);
//	Phrase ph_m45 = new Phrase(underline_c12);
//	ph_m45.setFont(fontTableHeading2);
//	Paragraph cell_Cr = new Paragraph(ph_m45);
//	cell_Cr.setAlignment(Element.ALIGN_CENTER);

		Paragraph head_c0 = new Paragraph("Headquarters", fontTableHeadingMainHead_Ml);
		Paragraph head_c1 = new Paragraph("Army Training Command", fontTableHeadingMainHead_Ml);
		Paragraph head_c2 = new Paragraph("Pin - 908548", fontTableHeadingMainHead_Ml);
		Paragraph head_c3 = new Paragraph("C/O 56 APO", fontTableHeadingMainHead_Ml);

//	tabledata_C1.addCell(cell_Cr);
		tabledata_C1.addCell(head_c0);
		tabledata_C1.addCell(head_c1);
		tabledata_C1.addCell(head_c2);
		tabledata_C1.addCell(head_c3);

		Paragraph head_c4 = new Paragraph("Tele : 2822", fontTableHeadingSubMainHead);
		PdfPCell blank_head_c4 = new PdfPCell(head_c4);
		blank_head_c4.setHorizontalAlignment(Element.ALIGN_LEFT);
		blank_head_c4.setPaddingTop(20f);

		blank_head_c4.setBorder(0);
		tabledata_C12.addCell(blank_head_c4);
		Paragraph head_c5 = new Paragraph("A/16014/B/2021/GS/Exam Sec", fontTableHeadingdataforML2);
		blank_head_c4 = new PdfPCell(head_c5);
		blank_head_c4.setHorizontalAlignment(Element.ALIGN_TOP);
		blank_head_c4.setPaddingBottom(15f);
		blank_head_c4.setBorder(0);
		tabledata_C3.addCell(blank_head_c4);
		Paragraph head_c6 = new Paragraph("HQ Southern Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c7 = new Paragraph("HQ Eastern Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c701 = new Paragraph("HQ Western Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c8 = new Paragraph("HQ Central Command (GS/Trg))", fontTableHeadingMainHead_Ml);
		Paragraph head_c9 = new Paragraph("HQ Northern Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c10 = new Paragraph("HQ South Western Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c13 = new Paragraph("HQ ARTRAC (GS Br)", fontTableHeadingMainHead_Ml);
		Paragraph head_c11 = new Paragraph("Andaman & Nicobar Command (Comd Trg Offr)", fontTableHeadingMainHead_Ml);
		Paragraph head_c12 = new Paragraph("DSSC, Wellington ", fontTableHeadingMainHead_Ml);
		Paragraph head_c121 = new Paragraph("MILIT, Girinagar, Pune ", fontTableHeadingMainHead_Ml);
		Paragraph head_c1212 = new Paragraph("CMM, Jabalpur ", fontTableHeadingMainHead_Ml);
		Paragraph head_c1213 = new Paragraph("MINTSD, Pune ", fontTableHeadingMainHead_Ml);

		tabledata_C3.addCell(new Paragraph("" + e_month + " " + year2, fontTableHeadingMainHead_Ml));
		tabledata_C3.addCell(head_c6);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c7);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c701);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c8);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c9);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c10);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c13);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c11);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c12);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c121);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c1213);

		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c1212);
		tabledata_C3.addCell("");

		Chunk underlinec1 = new Chunk("RESULTS: DEFENCE SERVICES STAFFF COURSE - "+ dsscCourseNo + "\n" + "ENTRANCE EXAM " + b_month
				+ "-" + e_month + "  " + year2 + "", fontTableHeadingMainHead_Ml);

		underlinec1.setUnderline(0.1f, -2f);

		Phrase phhc2 = new Phrase(underlinec1);
		phhc2.setFont(fontTableHeading2);

		Paragraph cell_c12 = new Paragraph(phhc2);
		cell_c12.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableC153 = new PdfPTable(1);
		tableC153.setWidths(new int[] { 100 });
		tableC153.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC153.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		tableC153.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC153.setWidthPercentage(100);
		tableC153.setSpacingBefore(5);
		
		
		
		

		tableC153.addCell(new Paragraph(
				"1." + "\t \t \t The results of Defence Services Staff Course- "+dsscCourseNo+" Entrance Exam held from " + bdrday
						+ "  to " + bedday + " " + e_month2 + " " + year2 + " are appended as follows:-",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph(
				"\t \t \t \t \t(a)      Analysis of Results                                -   Appendix 'A'   \n ",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph(
				"\t \t \t \t \t(b)      Competitive Merit                                   -   Appendix 'B'   \n ",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph(
				"\t \t \t \t \t(c)      Nominated List: DSSC & DSTSC           -   Appendix 'C'   \n ", fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(
				new Paragraph("\t \t \t \t \t(d)      Reserves List: DSSC & DSTSC             -   Appendix 'D'   \n ",
						fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph(
				"\t \t \t \t \t(e)      Short Listed Officers : ALMC / ISC         -   Appendix 'E'   \n ",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(
				new Paragraph("\t \t \t \t \t(f)      List of Candidates who did not Qualify    -   Appendix 'F'   \n ",
						fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph(
				"\t \t \t \t \t(g)      List of Absentees                                     -   Appendix 'G'   \n ",
				fontTablepara));

//	tableC153.addCell("");
		tableC153.addCell(new Paragraph(
				"\t \t \t \t \t(h)      List of Withdrawals                                  -   Appendix 'H'   \n ",
				fontTablepara));

		tableC153.addCell("");
//	tableC153.addCell("");

		tableC153.addCell(new Paragraph("2."
				+ "\t \t \t The Course is scheduled from 11 Jun 2022 to 20 Apr 2023. Nominated officers will join the \ncourse on the authority of this letter. NO separate instructions will be"
				+ " issued by DGMT (MT-2). Units of officers who have been nominated or placed in reserve will be informed directly"
				+ "by DGMT (MT-2). Officers earmarked as reserves will atted the course only if subsequently nominated by DGMT (MT-2).\n",
				fontTablepara));
//	tableC153.addCell("The sch of Courses will be promulgated shortly");

		tableC153.addCell("");

		tableC153.addCell(new Paragraph("\n3."
				+ "\t \t \t Joining instructions for the course will be issued to the nominated officers directly by the Defence Services Staff College"
				+ "(DSSC), Wellington. DSSC will ensure that joining instruction to the officers earmarked as reserves specifically state that they will move to DSSC, Wellington only if nominated by the DGMT (MT-2)"
				+ "to attend the Defence Services Staff Course.\n", fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n4"
				+ "\t \t \t Instructions for nomination on Staff Courses abroad, if any, will follow separately.\n",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n\n\n5"
				+ "\t \t \t Nominated and reserve officers will be governed by the provisions of SAO 1/S/2013/GS.\n",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n6"
				+ "\t \t \t Qualification on JC course prior to joining DSSC- "+ dsscCourseNo +"is a mandatory requirement failing"
				+ " which nomination of the affected officer will become null and void.\n", fontTablepara));

		tableC153.addCell("");

		tableC153.addCell(new Paragraph("\n7"
				+ "\t \t \t Discipline.  Officer being nominated for DSSC- "+ dsscCourseNo +"should be under acceptable discipline criterie (ref Appendix Q of SAO 1/S/2013/GS). Nominated officers should be cleared by the Discipline and Vigilance Directorate, falling which the Nominated of affected officers will stand to be null and void.\n",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n8"
				+ "\t \t \t The units will directly inform DGMT (MT-2) immediately on occurrence of the following in the respect of the officers nominated/earmarked as reserve on the course:- \n",
				fontTablepara));
//	tableC153.addCell("Nomination ofs officers is provisional, subject the meeting QR as per 10/2018/GSA(MT-2) and amdts thereafter prior to joining DSSC/DSTSC as applicable.\n");
		tableC153.addCell(new Paragraph("\n\t\t\t\t\t\t\t\t(a)    Hospitalization. \n", fontTablepara));
		tableC153.addCell(new Paragraph(
				"\n\t\t\t\t\t\t\t\t(b)    Change in permanent/temporary medical category along with details and a copy of the last medical board proceedings. \n",
				fontTablepara));
		tableC153.addCell(new Paragraph(
				"\n\t\t\t\t\t\t\t\t(c)     Involvement  in  a  disciplinary  case where a prime-facie case is  established against the officer, or if the officer has been placed under ban by the DV Dte. \n",
				fontTablepara));
		tableC153.addCell(new Paragraph(
				"\n\t\t\t\t\t\t\t\t(d)     Non-availability of the officer for the course for any other reason. \n",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n9"
				+ "\t \t \t Movement order  or arrival report of the officers will NOT be endorsed to DGMT (MT-2) by the parent unit.  DSSC, Wellington will submit a consolidated report to DGMT (MT-2) and HQ IDS(TSI).",
				fontTablepara));
//	tableC153.addCell("Instruction for nomination on Staff Course abroad, if any, follow separately.\n");

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n10"
				+ "\t \t \t officers on the Competitive and Nominated Lists and those on the Reserves List who are nominated subsequently (on occurrence of any vacancy at the DSSC,Wellington) WILL NOT be\n"
				+ "detailed on any other course/study leave exceeding 26 weeks since it makes them ineligible for attending the Staff Course as per Para 12 (c) of SAO 1/S/2013/GS.",
				fontTablepara));
//	tableC153.addCell("Nominated and reserved officers will be governed by the provision of AO 10/2018/GSA(MT-2) and amdts thereafter.\n");

//	tableC153.addCell("11");
//	tableC153.addCell("Qualification on JC Course prior to joining DSSC-78 & DSTSC-05 is a mandatory requirement failing which nomination of the affected officers will become null and void.\n");
//
//	
//	tableC153.addCell("12");
//	tableC153.addCell("Discipline. Officers being nominated DSSC-78 & DSTSC-05 should be under acceptable discipline criteria(ref Appendix Q of AO 10/2018/GSA(MT-2).Nominated officer(s) should be cleared by the Discipline and Vigilance Directorate failing which the Nomination of,\n"
//			+ "affected officer(s) will become void and null");
//
//	tableC153.addCell("13");
//	tableC153.addCell("The units will directly inform ARTRAC (EXAM SEC) immediately on occurrence of the following in respect of the officers nominated/earmarked  as reserve on the course:~\n");
//
//	tableC153.addCell("");
//	tableC153.addCell("(a) Hospitalization  \n ");
//
//	tableC153.addCell("");
//	tableC153.addCell("(b)Change in permanent/temporary medical category along with details and a copy of the last medical board proceedings.\n ");
//
//	tableC153.addCell("");
//	tableC153.addCell("(c)Involvement in disciplinary case where a prima-facie case is established against the officer, or if the officer has been placed under ban by the DV Dte. \n ");
//
//	tableC153.addCell("");
//	tableC153.addCell("(d)Non-availability of the officer for the course for any other reason.\n ");
//	
//	
//	tableC153.addCell("14");
//	tableC153.addCell("Movement  orders or arrival reports of the officers will not be endorsed  to ARTRAC (EXAM SEC) by the parent unit. DSSC, Wellington & MILIT,Pune will submit a consolidated report to ARTRAC (EXAM SEC) and HQ IDS(TSI.) \n ");
//
//	
//	tableC153.addCell("15");
//	tableC153.addCell("Officers on the Competitive and Nominated lists and those on the Reserve list who are nominated subsequently WILL NOT  be detailed on any other course/study leave exceeding 26 weeks since it makes them ineligible for attending the Staff Course as per Para 12 (c) of AO 10/2018/GSA(MT-2)   \n ");

		PdfPCell cell123_C1;
		cell123_C1 = new PdfPCell();

		cell123_C1.addElement(tabledata_C12);

		cell123_C1.addElement(tabledata_C1);
		cell123_C1.addElement(tabledata_C66);
		cell123_C1.addElement(new Paragraph("\n"));
		cell123_C1.addElement(tabledata_C2);
		cell123_C1.addElement(tabledata_C3);
		cell123_C1.addElement(cell_c12);
		cell123_C1.addElement(new Paragraph("\n"));
		cell123_C1.addElement(tableC153);

		cell123_C1.setBorder(0);
		cell123_C1.setPaddingLeft(30f);
		cell123_C1.setPaddingRight(30f);
		table_c2.addCell(cell123_C1);

//document.add(table_c2);

//super.buildPdfMetadata(model, document, request);

//==============Covering-letter 2===============//
		PdfPTable table_c3 = new PdfPTable(1);
		table_c3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_c3.setWidthPercentage(100);

		PdfPTable tableC253 = new PdfPTable(2);
		tableC253.setWidths(new int[] { 5, 100 });
		tableC253.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC253.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		tableC253.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC253.setWidthPercentage(100);
		tableC253.setSpacingBefore(5);

		tableC253.addCell("");
		tableC253.addCell("");

		PdfPTable tabledata_C4 = new PdfPTable(2);
		tabledata_C4.setWidths(new int[] { 70, 30 });
		tabledata_C4.setWidthPercentage(100 / 3f);
		tabledata_C4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C4.setHorizontalAlignment(Element.ALIGN_LEFT);

		tabledata_C4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head_c44 = new Paragraph("Sd/- " + director_name1 + "", fontTableHeadingSubMainHead);
		Paragraph head_c45 = new Paragraph("(DR Rai)", fontTableHeadingSubMainHead);
		Paragraph head_c48 = new Paragraph("Col", fontTableHeadingSubMainHead);
		Paragraph head_c46 = new Paragraph("Dir MT-2", fontTableHeadingSubMainHead);
		Paragraph head_c47 = new Paragraph("For DCOAS (IS&T)", fontTableHeadingSubMainHead);

		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c44);
		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c45);
		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c48);
		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c46);
		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c47);

		Chunk underlinec2 = new Chunk("\t \t \t \t \t \t Copy to:-", fontTableHeadingMainHead);

//		underlinec2.setUnderline(0.1f, -2f);

		Phrase phhc212 = new Phrase(underlinec2);
		phhc212.setFont(fontTableHeading2);

		Paragraph cell_c1222 = new Paragraph(phhc212);
		cell_c1222.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableC254 = new PdfPTable(1);
		tableC254.setWidths(new int[] { 100 });
		tableC254.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC254.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableC254.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC254.setWidthPercentage(100);
		tableC254.setSpacingBefore(5);
		tableC254.getDefaultCell().setPaddingLeft(33f);
		tableC254.getDefaultCell().setPaddingRight(30f);

		tableC254.addCell("");
		tableC254.addCell(new Paragraph(
				"All HQs  Corps , Divs, Areas, Cat A Ests, HQ SFC, HQ IMTRAT, DGAR & CDA (O), Pune (Ink signed copy).",
				fontTablepara));

		tableC254.addCell("");

		Chunk underlinec3 = new Chunk("\t \t \t \t \t \t Internal:-", fontTableHeadingMainHead);

//		underlinec3.setUnderline(0.1f, -2f);

		Phrase phhc2123 = new Phrase(underlinec3);
		phhc2123.setFont(fontTableHeading2);

		Paragraph cell_c1223 = new Paragraph(phhc2123);
		cell_c1223.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableC255 = new PdfPTable(1);
		tableC255.setWidths(new int[] { 100 });
		tableC255.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC255.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		tableC255.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC255.setWidthPercentage(100);
		tableC255.setSpacingBefore(5);
		tableC255.getDefaultCell().setPaddingLeft(33f);
		tableC255.getDefaultCell().setPaddingRight(30f);
		tableC255.addCell("");
		tableC255.addCell(new Paragraph(
				"MA to COAS, MA to VCOAS,MA to DCOAS (IS&T), MA to DCOAS (P&S), PS to DGMT, S to   MS,   SO to AG,   ALL  Branches at Army Hqs,Duty Room Sena Bhavan, MO Dte  (Ops Room),"
						+ "IG NSG,  DGRR,  DG INF, DGFM,  DG Avn, DGNCC,  DGBR,  IG SFF, Min of Def (R&D and DGI), MISO (PSG), HQ IDS (TSI), SD-1, SD-3, MT-4, MT-9, MT-10, MT-1,MT-2, MT-6, MT-8, MT-9,MT-11, MT-13, MT-14, MT-15, MT-16, MT-17, MT-18, MS Info, MO (Ops Room), DV Dte and file.\n",
				fontTablepara));

		PdfPCell cell123_C2;
		cell123_C2 = new PdfPCell();

		cell123_C2.setPaddingBottom(25f);
		cell123_C2.setBorder(0);
		table_c3.addCell(cell123_C2);
		table_c3.addCell(tableC253);
		cell123_C2.setPaddingBottom(25f);
		cell123_C2.setBorder(0);
		table_c3.addCell(cell123_C2);
		cell123_C2.setPaddingBottom(25f);
		table_c3.addCell(tabledata_C4);

		cell123_C2.setPaddingBottom(15f);
		cell123_C2.setBorder(0);
		cell123_C2.setPaddingLeft(30f);
		cell123_C2.setPaddingRight(30f);
//		cell_c1222.setPaddingLeft(30f);
//		cell_c1222.setPaddingRight(30f);
//		tableC254.setPaddingLeft(30f);
//		tableC254.setPaddingRight(30f);
//		cell_c1223.setPaddingLeft(30f);
//		cell_c1223.setPaddingRight(30f);
//		tableC255.setPaddingLeft(30f);
//		tableC255.setPaddingRight(30f);
		table_c3.addCell(cell123_C2);
		table_c3.addCell(cell_c1222);
		table_c3.addCell(tableC254);
		table_c3.addCell(cell_c1223);
		table_c3.addCell(tableC255);

//document.add(table_c3);

//super.buildPdfMetadata(model, document, request);
		// ==============================Arm/Service wise analysis of result
		// ==================//

		document.setPageSize(two);
		document.setMargins(30, 20, 20, 20);
		document.newPage();

		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(90);

		PdfPTable tabledata1 = new PdfPTable(1);
		tabledata1.setWidths(new int[] { 7 });
		tabledata1.setWidthPercentage(100 / 3.5f);
		tabledata1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata1.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head1 = new Paragraph("Appendix 'A'", fontTableHeadingMainHead_l);
		Paragraph head2 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head4 = new Paragraph("letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head5 = new Paragraph("dated" + "           " + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata1.addCell(head1);
		tabledata1.addCell(head2);
		tabledata1.addCell(head4);
		tabledata1.addCell(head5);

		Chunk underline1 = new Chunk("ARMY TRAINING COMMAND (EXAM SEC)" + "\n" + "DSSC - "+dsscCourseNo+" / DSTSC -" + dstscCourseNo + " ENTRANCE EXAM" + "\n"
				+ "ARM/SERVICES WISE ANALYSIS OF RESULTS ", fontTableHeadingSubMainHead);

		Phrase phh2 = new Phrase(underline1);
		underline1.setUnderline(0.1f, -2f);
		Paragraph cell12 = new Paragraph(phh2);
		cell12.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell12);

		PdfPTable tabledata = new PdfPTable(6);
		tabledata.setWidths(new int[] { 3, 3, 3, 3, 3, 3 });
		tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
		tabledata.setWidthPercentage(100);		 
 		tabledata.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph A1 = new Paragraph("ARM / SERVICE", fontTableHeadingSubMainHead_2);
		Paragraph B1 = new Paragraph("TOTAL APPEARED", fontTableHeadingSubMainHead_2);
		Paragraph C1 = new Paragraph("COMPETITIVE", fontTableHeadingSubMainHead_2);
		Paragraph D1 = new Paragraph("NOMINATED FOR DSSC", fontTableHeadingSubMainHead_2);
		Paragraph E1 = new Paragraph("NOMINATED FOR DSTSC", fontTableHeadingSubMainHead_2);
		Paragraph F1 = new Paragraph("RESERVE", fontTableHeadingSubMainHead_2);

//	PdfPCell blank_cella;
//	blank_cella = new PdfPCell();
//	blank_cella.addElement(A1);
//	blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
//	blank_cella.setPadding(10);
//	tabledata.addCell(blank_cella);

		PdfPCell blank_cella = new PdfPCell(A1);
		blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella.setPadding(5);
		blank_cella.setBorder(Rectangle.BOTTOM);
		tabledata.addCell(blank_cella);

		PdfPCell blank_cellb = new PdfPCell(B1);
		blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellb.setPadding(5);
		blank_cellb.setBorder(Rectangle.BOTTOM);
		tabledata.addCell(blank_cellb);

		PdfPCell blank_cellc = new PdfPCell(C1);
		blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellc.setPadding(5);
		blank_cellc.setBorder(Rectangle.BOTTOM);
		tabledata.addCell(blank_cellc);

		PdfPCell blank_celld = new PdfPCell(D1);
		blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_celld.setPadding(5);
		blank_celld.setBorder(Rectangle.BOTTOM);
		tabledata.addCell(blank_celld);

		PdfPCell blank_celle = new PdfPCell(E1);
//	blank_celle.setRowspan(2);
		blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_celle.setPadding(5);
		blank_celle.setBorder(Rectangle.BOTTOM);
		tabledata.addCell(blank_celle);

		PdfPCell blank_cellf = new PdfPCell(F1);
		blank_cellf.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf.setPadding(5);
		blank_cellf.setBorder(Rectangle.BOTTOM);

		tabledata.addCell(blank_cellf);

		ArrayList<List<String>> armresult = (ArrayList<List<String>>) model.get("getArmwiseAnalysisReport");

		for (int i = 0; i < armresult.size(); i++) {

			
			
			List<String> l = armresult.get(i);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
			Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdata);

			PdfPCell cellar = new PdfPCell();
		
//			cellar.setFixedHeight(20f);
			if (i % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}

			cellar.setPhrase(blank1);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellar.setBorder(Rectangle.NO_BORDER);
			tabledata.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cellar);

			cellar.setPhrase(blank6);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cellar);

//		tabledata.addCell(blank1);
//		tabledata.addCell(blank2);
//		tabledata.addCell(blank3);
//		tabledata.addCell(blank4);
//		tabledata.addCell(blank5);
//		tabledata.addCell(blank6);

		}
		
//		tabledata.getDefaultCell().setBorder(Rectangle.BOX);

		PdfPTable tabledataend = new PdfPTable(1);
		tabledataend.setWidths(new int[] { 5 });
		tabledataend.setWidthPercentage(100);
		tabledataend.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledataend.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
		tabledataend.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		
		
		
		
		
//		
//		PdfPCell cell123 = new PdfPCell();
//		cell123.addElement(new Paragraph("\n"));
//		cell123.addElement(tabledata1);
//		cell123.addElement(new Paragraph("\n"));
//		cell123.addElement(tableheader);
//		cell123.addElement(new Paragraph("\n"));
//		cell123.addElement(tabledata);
//		// cell123.addElement(tabledataend);
//		cell123.setBorder(0);
//		cell123.setPaddingLeft(30f);
//		cell123.setPaddingRight(30f);
//		table.addCell(cell123);
		
		
		
		table.setSplitLate(false);
		PdfPCell cell123;
		cell123 = new PdfPCell();
//		cell123.setPaddingLeft(30f);
//		cell123.setPaddingRight(30f);
		
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(new Paragraph("\n"));
		
		cell123.addElement(tabledata1);
		cell123.addElement(tableheader);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(new Paragraph("\n"));
		cell123.setBorder(Rectangle.NO_BORDER);
//		cell123.setBorder(Rectangle.CELL);
		table.addCell(cell123);
		
		PdfPCell cell1235612 ;
		cell1235612 = new PdfPCell();
		cell1235612.setBorder(Rectangle.BOX);
		
//		cell1235612.setPaddingLeft(30f);
//		cell1235612.setPaddingRight(30f);
		cell1235612.addElement(tabledata);
	 
		table.addCell(cell1235612);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		PdfPCell cell123 = new PdfPCell();
//		cell123.addElement(new Paragraph("\n"));
//		cell123.addElement(tabledata1);
//		cell123.addElement(new Paragraph("\n"));
//		cell123.addElement(tableheader);
//		cell123.addElement(new Paragraph("\n"));
//		cell123.addElement(tabledata);
//		// cell123.addElement(tabledataend);
//		cell123.setBorder(0);
//		cell123.setPaddingLeft(30f);
//		cell123.setPaddingRight(30f);
//		table.addCell(cell123);

		table.setSplitLate(true);
		
		PdfPCell cell124 = new PdfPCell();
		cell124.setVerticalAlignment(Element.ALIGN_BOTTOM);
		cell124.setBorder(0);
		cell124.addElement(tabledataend);
		table.getDefaultCell().setBottom(0);
		cell124.setPaddingLeft(30f);
		cell124.setPaddingRight(30f);
		table.addCell(cell124);

//===========================Competitive Merit List=============//

		PdfPTable table1 = new PdfPTable(1);
		table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table1.setWidthPercentage(90);

		PdfPTable tabledata12 = new PdfPTable(1);
		tabledata12.setWidths(new int[] { 7 });
		tabledata12.setWidthPercentage(100 / 3.5f);
		tabledata12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata12.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata12.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head_B1 = new Paragraph("Appendix 'B'", fontTableHeadingMainHead_l);
		Paragraph head_B2 = new Paragraph("(Refers to Para 1(B) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head_B3 = new Paragraph("letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head_B4 = new Paragraph("dated" + "           " + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata12.addCell(head_B1);
		tabledata12.addCell(head_B2);
		tabledata12.addCell(head_B3);
		tabledata12.addCell(head_B4);

		Chunk chunk1 = new Chunk();

		Chunk underline12 = new Chunk("COMPETITIVE MERIT LIST", fontTableHeadingSubMainHead);
		underline12.setUnderline(0.1f, -2f);
		Phrase phh12 = new Phrase(underline12);
		phh12.add("\n");
		phh12.add("\n");

		phh12.setFont(fontTableHeadingSubMainHead);

		Paragraph cell11 = new Paragraph(phh12);
		cell12.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader1 = new PdfPTable(1);
		tableheader1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader1.setWidthPercentage(100);
		tableheader1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader1.addCell(cell11);
		tableheader1.addCell(new Paragraph(
				"THE UNDER MENTIONED OFFICERS LISTED IN THEIR ORDER OF SENIORITY BY ARMS AND \n"
						+ "SERVICES HAVE SECURED THE FIRST 20 COMPETITIVE MERIT VACANCIES IN THE DEFENCE \n"
						+ "SERVICES STAFF COLLEGE ENTRANCE EXAMINATION FOR DSSC - "+dsscCourseNo +"\n\n\n   ",
				fontTableHeadingSubMainHeadNew_2));

		PdfPTable tabledata13 = new PdfPTable(5);
		tabledata13.setWidths(new int[] { 2, 3, 4, 7, 8 });
		tabledata13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		tabledata13.setWidthPercentage(100);

		Paragraph a = new Paragraph("SER NO", fontTableHeadingSubMainHead_2);
		Paragraph f = new Paragraph("PERS NO", fontTableHeadingSubMainHead_2);
		Paragraph b = new Paragraph("RANK", fontTableHeadingSubMainHead_2);
		Paragraph c = new Paragraph("NAME", fontTableHeadingSubMainHead_2);
		Paragraph d = new Paragraph("UNIT", fontTableHeadingSubMainHead_2);
//		Paragraph e = new Paragraph("ARM DESC", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cella1 = new PdfPCell(a);
		blank_cella1.setPadding(5);
//		blank_cella1.disableBorderSide(Rectangle.RIGHT);
		blank_cella1.setBorder(  Rectangle.BOTTOM );
//		blank_cella1.setBorder(Rectangle.BOTTOM);
//		blank_cella1.setBorder(Rectangle.LEFT);
		blank_cella1.setHorizontalAlignment(Element.ALIGN_LEFT);
//		table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell blank_cellb1 = new PdfPCell(b);
		blank_cellb1.setPadding(5);
		blank_cellb1.setBorder( Rectangle.BOTTOM);
		blank_cellb1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellc1 = new PdfPCell(c);
		blank_cellc1.setPadding(5);
		blank_cellc1.setBorder(  Rectangle.BOTTOM);
		blank_cellc1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_celld1 = new PdfPCell(d);
		blank_celld1.setPadding(5);
		blank_celld1.setBorder(  Rectangle.BOTTOM );
		blank_celld1.setHorizontalAlignment(Element.ALIGN_CENTER);

//		PdfPCell blank_celle1 = new PdfPCell(e);
//		blank_celle1.setPadding(5);
//		blank_celle1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellF1 = new PdfPCell(f);
		blank_cellF1.setPadding(5);
		blank_cellF1.setBorder(  Rectangle.BOTTOM);
		blank_cellF1.setHorizontalAlignment(Element.ALIGN_CENTER);

		tabledata13.addCell(blank_cella1);
		tabledata13.addCell(blank_cellF1);
		tabledata13.addCell(blank_cellb1);
		tabledata13.addCell(blank_cellc1);
		tabledata13.addCell(blank_celld1);
//		tabledata13.addCell(blank_celle1);
		String arm = "";
		ArrayList<List<String>> getcompatative = (ArrayList<List<String>>) model.get("getcompatativemeritlistReport");
		System.err.println("getcompatative===========" + getcompatative);
		for (int i = 0; i < getcompatative.size(); i++) {

		 
			
			
			List<String> l = getcompatative.get(i);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
			Paragraph blank6 = new Paragraph(l.get(5) + "\n", fontTableHeadingMainHead);

			PdfPCell cellar = new PdfPCell();

//			cellar.setFixedHeight(20f);
			if (i % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}

			if (!l.get(5).equals(arm)) {
				arm = l.get(5);
				PdfPCell cellarow = new PdfPCell();
				cellarow.setColspan(6);
				cellarow.setPhrase(blank6);
				cellarow.setBorder(Rectangle.NO_BORDER);
				cellarow.setPadding(2);
				cellarow.setPaddingBottom(8f);
				cellarow.setHorizontalAlignment(Element.ALIGN_CENTER);
//				cellarow.setBorder(Rectangle.LEFT | Rectangle.RIGHT);
				tabledata13.addCell(cellarow);
			}
			

				cellar.setPhrase(blank1);
				cellar.setBorder(Rectangle.NO_BORDER);
				cellar.setPadding(2);
				cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//				cellar.setBorder(Rectangle.LEFT);
				tabledata13.addCell(cellar);

				cellar.setPhrase(blank2);
				cellar.setPadding(2);
				cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//				cellar.setBorder(Rectangle.NO_BORDER);
				tabledata13.addCell(cellar);

				cellar.setPhrase(blank3);
				cellar.setPadding(2);
				cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cellar);

				cellar.setPhrase(blank4);
				cellar.setPadding(2);
				cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
				tabledata13.addCell(cellar);

				cellar.setPhrase(blank5);
				cellar.setPadding(2);
				cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//				cellar.setBorder(Rectangle.RIGHT);
				tabledata13.addCell(cellar);
			
 

		} 	 
		
		table1.setSplitLate(false);
		PdfPCell cell1231;
		cell1231 = new PdfPCell(); 
		cell1231.addElement(new Paragraph("\n"));
		cell1231.addElement(tabledata12);
		cell1231.addElement(new Paragraph("\n"));
		cell1231.addElement(tableheader1);
		 
		 
		cell1231.setBorder(Rectangle.NO_BORDER);
//		cell123.setBorder(Rectangle.CELL);
		table1.addCell(cell1231);
		
		PdfPCell cell123112 ;
		cell123112 = new PdfPCell();
		cell123112.setBorder(Rectangle.BOX);
		 
		cell123112.addElement(tabledata13);
	 
		table1.addCell(cell123112);
		
		

//==================DSSC====================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table4 = new PdfPTable(1);
		table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table4.setWidthPercentage(90);

		PdfPTable tabledata4 = new PdfPTable(1);
		tabledata4.setWidths(new int[] { 7 });
		tabledata4.setWidthPercentage(100 / 3.5f);
		tabledata4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata4.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head45 = new Paragraph("Appendix 'C'", fontTableHeadingMainHead_l);
		Paragraph head41 = new Paragraph("(Refers to Para 1(C) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head43 = new Paragraph("letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head44 = new Paragraph("dated" + "           " + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata4.addCell(head45);
		tabledata4.addCell(head41);
		tabledata4.addCell(head43);
		tabledata4.addCell(head44);

		Chunk army_training_command_heading = new Chunk("LIST OF NOMINATED OFFICERS FOR DSSC - " + dsscCourseNo,
				fontTableHeadingSubMainHead);
		army_training_command_heading.setUnderline(0.1f, -2f);
		Paragraph army_training_command_paragraph = new Paragraph(army_training_command_heading);
		army_training_command_paragraph.setFont(fontTableHeading1);
		army_training_command_paragraph.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader4 = new PdfPTable(1);
		tableheader4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader4.setWidthPercentage(100);
		tableheader4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader4.addCell(army_training_command_paragraph);
		tableheader4.addCell(new Paragraph(
				"THE UNDER MENTIONED OFFICERS LISTED IN THEIR ORDER OF SENIORITY BY ARMS AND \n  "
						+ "         SERVICES HAVE BEEN NOMINATED TO ATTEND THE DEFENCE SERVICES STAFF COLLEGE COURSE",
				fontTableHeadingSubMainHeadNew_2));
//		COMMENCING IN JUNE 2022 
		PdfPTable tabledata412 = new PdfPTable(1);
		tabledata412.getDefaultCell().setBorder(Rectangle.BOX);
		tabledata412.setWidthPercentage(100);
		tabledata412.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		 
		PdfPTable tabledata41 = new PdfPTable(5);
//	tabledata41.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tabledata41.setWidths(new int[] { 2, 2, 2, 6, 5 });
		tabledata41.setWidthPercentage(100);
		tabledata41.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata41.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		tabledata41.setHeaderRows(1);
		tabledata41.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		
	
		
		ArrayList<List<String>> fullypassed = (ArrayList<List<String>>) model.get("fullypassed_D");
		Paragraph a_C = new Paragraph("SER NO", fontTableHeadingSubMainHead_2);
		Paragraph f_C = new Paragraph("PERS NO", fontTableHeadingSubMainHead_2);

		Paragraph b_C = new Paragraph("RANK", fontTableHeadingSubMainHead_2);
		Paragraph c_C = new Paragraph("NAME", fontTableHeadingSubMainHead_2);
		Paragraph d_C = new Paragraph("UNIT", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cella1_C = new PdfPCell(a_C);
		blank_cella1_C.setPadding(5);
		blank_cella1_C.setPaddingLeft(15f);
		blank_cella1_C.setHorizontalAlignment(Element.ALIGN_LEFT);
		blank_cella1_C.setVerticalAlignment(Element.ALIGN_TOP);
		blank_cella1_C.setBorder(Rectangle.BOTTOM);

		PdfPCell blank_cella2_C = new PdfPCell(f_C);
		blank_cella2_C.setPadding(5);
		blank_cella2_C.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella2_C.setBorder(Rectangle.BOTTOM);

		PdfPCell blank_cella3_C = new PdfPCell(b_C);
		blank_cella3_C.setPadding(5);
		blank_cella3_C.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella3_C.setBorder(Rectangle.BOTTOM);

		PdfPCell blank_cella4_C = new PdfPCell(c_C);
		blank_cella4_C.setPadding(5);
		blank_cella4_C.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella4_C.setBorder(Rectangle.BOTTOM);

		PdfPCell blank_cella5_C = new PdfPCell(d_C);
		blank_cella5_C.setPadding(5);
		blank_cella5_C.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella5_C.setBorder(Rectangle.BOTTOM);

		tabledata41.addCell(blank_cella1_C);
		tabledata41.addCell(blank_cella2_C);
		tabledata41.addCell(blank_cella3_C);
		tabledata41.addCell(blank_cella4_C);
		tabledata41.addCell(blank_cella5_C);

 
		
		String armForDSSC = "";
		
		int flag_first_page = 42;
		int flag_first_page_fix = 42;
		
		ArrayList<List<String>> getnominateddssclistReport = (ArrayList<List<String>>) model.get("getnominateddssclistReport");

		
		for (int i = 0; i < getnominateddssclistReport.size();i++) {
			//if(i > 45){ flag_first_page_fix = 66;}
				
			
			
			List<String> l = getnominateddssclistReport.get(i);
			PdfPCell celle_fl = new PdfPCell();
				 
				if(flag_first_page > (flag_first_page_fix-flag_first_page_fix) && flag_first_page <= (flag_first_page_fix)) {
					
					Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdatabold);
					
					if (!l.get(5).equals(armForDSSC)) {
						armForDSSC = l.get(5);
						PdfPCell cellarow = new PdfPCell();
						cellarow.setColspan(5);
						cellarow.setPhrase(blank6);
						cellarow.setBorder(Rectangle.NO_BORDER);
						cellarow.setPadding(2f);
						cellarow.setPaddingBottom(7.4f);
						cellarow.setHorizontalAlignment(Element.ALIGN_CENTER);
						tabledata41.addCell(cellarow);
						flag_first_page -= 1;
					}
					
					
					Paragraph ser_no = new Paragraph(l.get(0), fontTableHeadingdata);
					 celle_fl = new PdfPCell(ser_no);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					 celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					 celle_fl.setPadding(3);
					 if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					 tabledata41.addCell(celle_fl);
					Paragraph ic_number = new Paragraph(l.get(1), fontTableHeadingdata);
					celle_fl = new PdfPCell(ic_number);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata41.addCell(celle_fl);
					Paragraph rank = new Paragraph(l.get(2), fontTableHeadingdata);
					celle_fl = new PdfPCell(rank);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata41.addCell(celle_fl);
					Paragraph pers_name = new Paragraph(l.get(3), fontTableHeadingdata);
					celle_fl = new PdfPCell(pers_name);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata41.addCell(celle_fl);
					Paragraph arm1 = new Paragraph(l.get(4), fontTableHeadingdata);
					celle_fl = new PdfPCell(arm1);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata41.addCell(celle_fl);
						
					
				}
			 
			if(flag_first_page==((flag_first_page_fix-flag_first_page_fix)+1)){
				tabledata412.addCell(tabledata41);
				tabledata41 = new PdfPTable(5);
//				tabledata41.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					tabledata41.setWidths(new int[] { 2, 2, 2, 6, 5 });
					tabledata41.setWidthPercentage(100);
					tabledata41.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					tabledata41.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
					tabledata41.setHeaderRows(1);
					tabledata41.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					tabledata41.addCell(blank_cella1_C);
					tabledata41.addCell(blank_cella2_C);
					tabledata41.addCell(blank_cella3_C);
					tabledata41.addCell(blank_cella4_C);
					tabledata41.addCell(blank_cella5_C);

			}
			 
			if(getnominateddssclistReport.size() == (i+1) & flag_first_page > (flag_first_page_fix-flag_first_page_fix) & flag_first_page < ((flag_first_page_fix)+1)){
			
				tabledata412.addCell(tabledata41);
				tabledata41 = new PdfPTable(5);
//				tabledata41.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					tabledata41.setWidths(new int[] { 2, 2, 2, 6, 5 });
					tabledata41.setWidthPercentage(100);
					tabledata41.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					tabledata41.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
					tabledata41.setHeaderRows(1);
					tabledata41.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					tabledata41.addCell(blank_cella1_C);
					tabledata41.addCell(blank_cella2_C);
					tabledata41.addCell(blank_cella3_C);
					tabledata41.addCell(blank_cella4_C);
					tabledata41.addCell(blank_cella5_C);
			}			
			flag_first_page -= 1;
			if(flag_first_page == 0) {
				flag_first_page_fix = 50;
				flag_first_page = flag_first_page_fix;				
			}
		}
		
		 
 	
		table4.setSplitLate(false);
		PdfPCell cell1236_f;
		cell1236_f = new PdfPCell();
 
		cell1236_f.addElement(tabledata4);
		cell1236_f.addElement(tableheader4);
		 
		cell1236_f.setBorder(Rectangle.NO_BORDER);
 
		table4.addCell(cell1236_f);
		
		 
		
		PdfPCell cell1236_f1 ;
		cell1236_f1 = new PdfPCell();
		 
		cell1236_f1.setBorder(Rectangle.NO_BORDER);
	
		cell1236_f1.addElement(tabledata412);
		
		 
		PdfPTable table4a1 = new PdfPTable(1);
		table4a1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table4a1.setWidthPercentage(100);
		
		table4a1.addCell(cell1236_f1);
		
		PdfPCell cell1236_f12 ;
		cell1236_f12 = new PdfPCell();
		cell1236_f12.setPaddingTop(30f);
		cell1236_f12.setPaddingBottom(25.6f); 
		cell1236_f12.setBorder(Rectangle.NO_BORDER);
	
		cell1236_f12.addElement( table4a1);
		 
		
		table4.addCell(cell1236_f12);
		
		
		
		
		
		
		

//		PdfPCell cell1236_f;
//		cell1236_f = new PdfPCell();
//		cell1236_f.addElement(tabledata4);
//		cell1236_f.addElement(new Paragraph("\n"));
//
//		cell1236_f.addElement(tableheader4);
//
//		cell1236_f.addElement(tabledata41);
//		cell1236_f.addElement(new Paragraph("\n"));
//		cell1236_f.addElement(new Paragraph("\n"));
//		cell1236_f.setBorder(0);
//		cell1236_f.setPaddingLeft(30f);
//		cell1236_f.setPaddingRight(30f);
//		table4.addCell(cell1236_f);
		
		
		
		
		// writeFooterTable(arg2,document,table4);

		// ==================DSTSC====================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table5_2 = new PdfPTable(1);
		table5_2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table5_2.setWidthPercentage(90);

		PdfPTable tabledata4_2 = new PdfPTable(1);
		tabledata4_2.setWidths(new int[] { 7 });
		tabledata4_2.setWidthPercentage(100 / 3.5f);
		tabledata4_2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata4_2.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata4_2.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head45_2 = new Paragraph("Appendix 'C' Contd.", fontTableHeadingMainHead_l);

		tabledata4_2.addCell(head45_2);

		Chunk DSTSC_heading = new Chunk("LIST OF NOMINATED OFFICERS FOR DSTSC -" + dstscCourseNo, fontTableHeadingSubMainHead);
		DSTSC_heading.setUnderline(0.1f, -2f);
		Paragraph DSTSC_paragraph = new Paragraph(DSTSC_heading);
		DSTSC_paragraph.setFont(fontTableHeading1);
		DSTSC_paragraph.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader4_DSTSC = new PdfPTable(1);
		tableheader4_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader4_DSTSC.setWidthPercentage(100);
		tableheader4_DSTSC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader4_DSTSC.addCell(DSTSC_paragraph);
		tableheader4_DSTSC.addCell(new Paragraph(
				"THE UNDER MENTIONED OFFICERS LISTED IN THEIR ORDER OF SENIORITY BY ARMS AND \n  "
						+ "SERVICES HAVE BEEN NOMINATED TO ATTEND THE DEFENCE SERVICES TECHNICAL STAFF COLLEGE COURSE\n\n",
				fontTableHeadingSubMainHeadNew_2));
		
//		 COMMENCING-5
		
		
		PdfPTable tabledata412_DSTSC = new PdfPTable(1); 
		tabledata412_DSTSC.setWidthPercentage(100);
		tabledata412_DSTSC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata412_DSTSC.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		
		

		PdfPTable tabledata41_DSTSC = new PdfPTable(5);
//	tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tabledata41_DSTSC.setWidths(new int[] { 2, 2, 2, 7, 4 });
		tabledata41_DSTSC.setWidthPercentage(100);
		tabledata41_DSTSC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata41_DSTSC.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata41_DSTSC.setHeaderRows(1);
		tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		
		ArrayList<List<String>> DSTSC = (ArrayList<List<String>>) model.get("fullypassed_D");
		Paragraph a_C2 = new Paragraph("SER NO", fontTableHeadingSubMainHead_2);
		Paragraph f_C2 = new Paragraph("PERS NO", fontTableHeadingSubMainHead_2);

		Paragraph b_C2 = new Paragraph("RANK", fontTableHeadingSubMainHead_2);
		Paragraph c_C2 = new Paragraph("NAME", fontTableHeadingSubMainHead_2);
		Paragraph d_C2 = new Paragraph("UNIT", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cella1_C1 = new PdfPCell(a_C2);
		blank_cella1_C1.setPadding(5);
		blank_cella1_C1.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C1.setBorder(Rectangle.BOTTOM);
		

		PdfPCell blank_cella2_C1 = new PdfPCell(f_C2);
		blank_cella2_C1.setPadding(5);
		blank_cella2_C1.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella2_C1.setBorder(Rectangle.BOTTOM);

		PdfPCell blank_cella3_C1 = new PdfPCell(b_C2);
		blank_cella3_C1.setPadding(5);
		blank_cella3_C1.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella3_C1.setBorder(Rectangle.BOTTOM);

		PdfPCell blank_cella4_C1 = new PdfPCell(c_C2);
		blank_cella4_C1.setPadding(5);
		blank_cella4_C1.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella4_C1.setBorder(Rectangle.BOTTOM);

		PdfPCell blank_cella5_C1 = new PdfPCell(d_C2);
		blank_cella5_C1.setPadding(5);
		blank_cella5_C1.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella5_C1.setBorder(Rectangle.BOTTOM);

		tabledata41_DSTSC.addCell(blank_cella1_C1);
		tabledata41_DSTSC.addCell(blank_cella2_C1);
		tabledata41_DSTSC.addCell(blank_cella3_C1);
		tabledata41_DSTSC.addCell(blank_cella4_C1);
		tabledata41_DSTSC.addCell(blank_cella5_C1);

		String armForDSTSC = "";
		ArrayList<List<String>> getnominateddstsclistReport = (ArrayList<List<String>>) model.get("getnominateddstsclistReport");

		
		
	String armFor_DSTSC = "";
		
		int flag_first_page_DSTSC = 42;
		int flag_first_page_fix_DSTSC = 42;
		
	 
		for (int i = 0; i < getnominateddstsclistReport.size();i++) {
			//if(i > 45){ flag_first_page_fix = 66;}
				
			
			
			List<String> l = getnominateddstsclistReport.get(i);
			PdfPCell celle_fl = new PdfPCell();
				 
				if(flag_first_page_DSTSC > (flag_first_page_fix_DSTSC-flag_first_page_fix_DSTSC) && flag_first_page_DSTSC <= (flag_first_page_fix_DSTSC)) {
					
					Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdatabold);
					
					if (!l.get(5).equals(armFor_DSTSC)) {
						armFor_DSTSC = l.get(5);
						PdfPCell cellarow = new PdfPCell();
						cellarow.setColspan(5);
						cellarow.setPhrase(blank6);
						cellarow.setBorder(Rectangle.NO_BORDER);
						cellarow.setPadding(2f);
						cellarow.setPaddingBottom(7.4f);
						cellarow.setHorizontalAlignment(Element.ALIGN_CENTER);
						tabledata41_DSTSC.addCell(cellarow);
						flag_first_page_DSTSC -= 1;
					}
					
					
					Paragraph ser_no = new Paragraph(l.get(0), fontTableHeadingdata);
					 celle_fl = new PdfPCell(ser_no);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					 celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					 celle_fl.setPadding(3);
					 if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					 tabledata41_DSTSC.addCell(celle_fl);
					Paragraph ic_number = new Paragraph(l.get(1), fontTableHeadingdata);
					celle_fl = new PdfPCell(ic_number);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata41_DSTSC.addCell(celle_fl);
					Paragraph rank = new Paragraph(l.get(2), fontTableHeadingdata);
					celle_fl = new PdfPCell(rank);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata41_DSTSC.addCell(celle_fl);
					Paragraph pers_name = new Paragraph(l.get(3), fontTableHeadingdata);
					celle_fl = new PdfPCell(pers_name);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata41_DSTSC.addCell(celle_fl);
					Paragraph arm1 = new Paragraph(l.get(4), fontTableHeadingdata);
					celle_fl = new PdfPCell(arm1);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata41_DSTSC.addCell(celle_fl);
						
					
				}
			 
			if(flag_first_page_DSTSC==((flag_first_page_fix_DSTSC-flag_first_page_fix_DSTSC)+1)){
				tabledata412_DSTSC.addCell(tabledata41_DSTSC);
				tabledata41_DSTSC = new PdfPTable(5);
//				tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					tabledata41_DSTSC.setWidths(new int[] { 2, 2, 2, 7, 4 });
					tabledata41_DSTSC.setWidthPercentage(100);
					tabledata41_DSTSC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					tabledata41_DSTSC.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
					tabledata41_DSTSC.setHeaderRows(1);
					tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				tabledata41_DSTSC.addCell(blank_cella1_C1);
				tabledata41_DSTSC.addCell(blank_cella2_C1);
				tabledata41_DSTSC.addCell(blank_cella3_C1);
				tabledata41_DSTSC.addCell(blank_cella4_C1);
				tabledata41_DSTSC.addCell(blank_cella5_C1);


			}
			 
			if(getnominateddstsclistReport.size() == (i+1) & flag_first_page_DSTSC > (flag_first_page_fix_DSTSC-flag_first_page_fix_DSTSC) & flag_first_page_DSTSC < ((flag_first_page_fix_DSTSC)+1)){
			
				tabledata412_DSTSC.addCell(tabledata41_DSTSC);
				tabledata41_DSTSC = new PdfPTable(5);
//				tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					tabledata41_DSTSC.setWidths(new int[] { 2, 2, 2, 7, 4 });
					tabledata41_DSTSC.setWidthPercentage(100);
					tabledata41_DSTSC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					tabledata41_DSTSC.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
					tabledata41_DSTSC.setHeaderRows(1);
					tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			
				tabledata41_DSTSC.addCell(blank_cella1_C1);
				tabledata41_DSTSC.addCell(blank_cella2_C1);
				tabledata41_DSTSC.addCell(blank_cella3_C1);
				tabledata41_DSTSC.addCell(blank_cella4_C1);
				tabledata41_DSTSC.addCell(blank_cella5_C1);

			}			
			flag_first_page_DSTSC -= 1;
			if(flag_first_page_DSTSC == 0) {
				flag_first_page_fix_DSTSC = 50;
				flag_first_page_DSTSC = flag_first_page_fix_DSTSC;				
			}
		}
		 
		

		table5_2.setSplitLate(false);
		PdfPCell cell1236__DSTSC;
		cell1236__DSTSC = new PdfPCell();
 
		cell1236__DSTSC.addElement(tabledata4_2);
		cell1236__DSTSC.addElement(tableheader4_DSTSC);
		 
		cell1236__DSTSC.setBorder(Rectangle.NO_BORDER);
 
		table5_2.addCell(cell1236__DSTSC);
		
		 
		
		PdfPCell cell1236_DSTSC ;
		cell1236_DSTSC = new PdfPCell();
		 
		cell1236_DSTSC.setBorder(Rectangle.NO_BORDER);
	
		cell1236_DSTSC.addElement(tabledata412_DSTSC);
		
		
		 
		PdfPTable table4a1_DSTSC = new PdfPTable(1);
		table4a1_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table4a1_DSTSC.setWidthPercentage(100);
		
		table4a1_DSTSC.addCell(cell1236_DSTSC);
		
		PdfPCell cell12361_DSTSC ;
		cell12361_DSTSC = new PdfPCell();
		cell12361_DSTSC.setPaddingTop(30f);
		cell12361_DSTSC.setPaddingBottom(22.6f); 
		cell12361_DSTSC.setBorder(Rectangle.NO_BORDER);
	
		cell12361_DSTSC.addElement( table4a1_DSTSC);
		 
		
		table5_2.addCell(cell12361_DSTSC);
		
		
		
		
 
		// =================Reserve====================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table5 = new PdfPTable(1);
		table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table5.setWidthPercentage(90);

		PdfPTable tabledata5 = new PdfPTable(1);
		tabledata5.setWidths(new int[] { 5 });
		tabledata5.setWidthPercentage(100 / 3.5f);
		tabledata5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata5.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata5.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head55 = new Paragraph("Appendix 'D'", fontTableHeadingMainHead_l);
		Paragraph head51 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head52 = new Paragraph("letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head53 = new Paragraph("dated" + "           " + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata5.addCell(head55);
		tabledata5.addCell(head51);
		tabledata5.addCell(head52);
		tabledata5.addCell(head53);

	 
		Chunk underline5 = new Chunk("LIST OF RESERVE OFFICERS FOR DSSC - "+ dsscCourseNo + " / DSTSC - " + dstscCourseNo, fontTableHeadingSubMainHead);
		underline5.setUnderline(0.1f, -2f);
		Phrase phh5 = new Phrase(underline5);

		phh5.add("\n");
		phh5.add("\n");
		phh5.setFont(fontTableHeadingSubMainHead);

		Paragraph cell51 = new Paragraph(phh5);
		cell51.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader5 = new PdfPTable(1);
		tableheader5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader5.setWidthPercentage(100);
		tableheader5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader5.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader5.addCell(cell51);

		PdfPTable tabledata51 = new PdfPTable(7);

		tabledata51.setWidths(new int[] { 3, 4, 3, 9, 5, 5, 5 });
		tabledata51.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata51.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata51.setWidthPercentage(100);

		
		

		PdfPTable tabledata51_reserve = new PdfPTable(1);

		tabledata51_reserve.setWidths(new int[] { 1});
		tabledata51_reserve.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata51_reserve.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata51_reserve.setWidthPercentage(100);
		
		
		ArrayList<List<String>> result_withheld = (ArrayList<List<String>>) model.get("resultwithheld_d");

		Paragraph a5 = new Paragraph("SER NO", fontTableHeadingSubMainHead_2);
		Paragraph b5 = new Paragraph("PERS NO", fontTableHeadingSubMainHead_2);
		Paragraph c5 = new Paragraph("RANK", fontTableHeadingSubMainHead_2);
		Paragraph d5 = new Paragraph("NAME", fontTableHeadingSubMainHead_2);
		Paragraph e5 = new Paragraph("UNIT", fontTableHeadingSubMainHead_2);
		Paragraph f5 = new Paragraph("CH 1", fontTableHeadingSubMainHead_2);
		Paragraph g5 = new Paragraph("CH 2", fontTableHeadingSubMainHead_2);
//		Paragraph h5 = new Paragraph("ARM DESC", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cellA1 = new PdfPCell(a5);
		blank_cellA1.setPadding(5);
		blank_cellA1.setBorder( Rectangle.BOTTOM );
		blank_cellA1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellB1 = new PdfPCell(b5);
		blank_cellB1.setPadding(5);
		blank_cellB1.setBorder( Rectangle.BOTTOM );
		blank_cellB1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellC1 = new PdfPCell(c5);
		blank_cellC1.setPadding(5);
		blank_cellC1.setBorder( Rectangle.BOTTOM );
		blank_cellC1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellD1 = new PdfPCell(d5);
		blank_cellD1.setPadding(5);
		blank_cellD1.setBorder( Rectangle.BOTTOM );
		blank_cellD1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellE1 = new PdfPCell(e5);
		blank_cellE1.setPadding(5);
		blank_cellE1.setBorder( Rectangle.BOTTOM );
		blank_cellE1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellF11 = new PdfPCell(f5);
		blank_cellF11.setPadding(5);
		blank_cellF11.setBorder( Rectangle.BOTTOM );
		blank_cellF11.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellG1 = new PdfPCell(g5);
		blank_cellG1.setPadding(5);
		blank_cellG1.setBorder( Rectangle.BOTTOM );
		blank_cellG1.setHorizontalAlignment(Element.ALIGN_CENTER);

		
		
		tabledata51.addCell(blank_cellA1);
		tabledata51.addCell(blank_cellB1);
		tabledata51.addCell(blank_cellC1);
		tabledata51.addCell(blank_cellD1);
		tabledata51.addCell(blank_cellE1);
		tabledata51.addCell(blank_cellF11);
		tabledata51.addCell(blank_cellG1);
//		tabledata51.addCell(h5);
		String Rarm = "";
		ArrayList<List<String>> getreserveofficeristReport = (ArrayList<List<String>>) model
				.get("getreserveofficeristReport");

		System.out.println("getreserveofficeristReport=========" + getreserveofficeristReport); 

 	
			
			String armFor_reserve = "";
			
			int flag_first_page_reserve = 42;
			int flag_first_page_fix_reserve= 42;
			
		 
			for (int i = 0; i < getreserveofficeristReport.size();i++) {
				//if(i > 45){ flag_first_page_fix = 66;}
					
				
				
				List<String> l = getreserveofficeristReport.get(i);
				PdfPCell celle_fl = new PdfPCell();
					 
					if(flag_first_page_reserve > (flag_first_page_fix_reserve-flag_first_page_fix_reserve) && flag_first_page_reserve <= (flag_first_page_fix_reserve)) {
						
						Paragraph blank8 = new Paragraph(l.get(7), fontTableHeadingdatabold);
						
						if (!l.get(7).equals(armFor_reserve)) {
							armFor_reserve = l.get(7);
							PdfPCell cellarow = new PdfPCell();
							cellarow.setColspan(7);
							cellarow.setPhrase(blank8);
							cellarow.setBorder(Rectangle.NO_BORDER);
							cellarow.setPadding(2f);
							cellarow.setPaddingBottom(7.4f);
							cellarow.setHorizontalAlignment(Element.ALIGN_CENTER);
							tabledata51.addCell(cellarow);
							flag_first_page_reserve -= 1;
						}
						
						
						Paragraph ser_no = new Paragraph(l.get(0), fontTableHeadingdata);
						 celle_fl = new PdfPCell(ser_no);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						 celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//						 celle_fl.setPadding(3);
						 if (i % 2 == 0) {
								celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						 tabledata51.addCell(celle_fl);
						 
						Paragraph ic_number = new Paragraph(l.get(1), fontTableHeadingdata);
						celle_fl = new PdfPCell(ic_number);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata51.addCell(celle_fl);
						
						Paragraph rank = new Paragraph(l.get(2), fontTableHeadingdata);
						celle_fl = new PdfPCell(rank);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata51.addCell(celle_fl);
						
						Paragraph pers_name = new Paragraph(l.get(3), fontTableHeadingdata);
						celle_fl = new PdfPCell(pers_name);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata51.addCell(celle_fl);
						
						Paragraph arm1 = new Paragraph(l.get(4), fontTableHeadingdata);
						celle_fl = new PdfPCell(arm1);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata51.addCell(celle_fl);
						
						
						arm1 = new Paragraph(l.get(5), fontTableHeadingdata);
						celle_fl = new PdfPCell(arm1);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata51.addCell(celle_fl);
						
						
						
						arm1 = new Paragraph(l.get(6), fontTableHeadingdata);
						celle_fl = new PdfPCell(arm1);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata51.addCell(celle_fl);
						
						
//						arm1 = new Paragraph(l.get(7), fontTableHeadingdata);
//						celle_fl = new PdfPCell(arm1);
//						 celle_fl.setBorder(Rectangle.NO_BORDER);
//						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
////						celle_fl.setPadding(3);
//						if (i % 2 == 0) {
//							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
//						}
//						tabledata51.addCell(celle_fl);
							
						
					}
				 
				if(flag_first_page_reserve==((flag_first_page_fix_reserve-flag_first_page_fix_reserve)+1)){
					tabledata51_reserve.addCell(tabledata51);
					tabledata51 = new PdfPTable(7);

					tabledata51.setWidths(new int[] { 3, 4, 3, 9, 5, 5, 5 });
					tabledata51.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata51.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
					tabledata51.setWidthPercentage(100);

					
					tabledata51.addCell(blank_cellA1);
					tabledata51.addCell(blank_cellB1);
					tabledata51.addCell(blank_cellC1);
					tabledata51.addCell(blank_cellD1);
					tabledata51.addCell(blank_cellE1);
					tabledata51.addCell(blank_cellF11);
					tabledata51.addCell(blank_cellG1);


				}
				 
				if(getreserveofficeristReport.size() == (i+1) & flag_first_page_reserve > (flag_first_page_fix_reserve-flag_first_page_fix_reserve) & flag_first_page_reserve < ((flag_first_page_fix_reserve)+1)){
				
					tabledata51_reserve.addCell(tabledata51);
					tabledata51 = new PdfPTable(7);

					tabledata51.setWidths(new int[] { 3, 4, 3, 9, 5, 5, 5 });
					tabledata51.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata51.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
					tabledata51.setWidthPercentage(100);

					
					tabledata51.addCell(blank_cellA1);
					tabledata51.addCell(blank_cellB1);
					tabledata51.addCell(blank_cellC1);
					tabledata51.addCell(blank_cellD1);
					tabledata51.addCell(blank_cellE1);
					tabledata51.addCell(blank_cellF11);
					tabledata51.addCell(blank_cellG1);

				}			
				flag_first_page_reserve -= 1;
				if(flag_first_page_reserve == 0) {
					flag_first_page_fix_reserve = 50;
					flag_first_page_reserve = flag_first_page_fix_reserve;				
				}
			}
			
			
 
		
		
		
		table5.setSplitLate(false);
		PdfPCell cell1235;
		cell1235 = new PdfPCell();
//		cell123.setPaddingLeft(30f);
//		cell123.setPaddingRight(30f);
		cell1235.addElement(tabledata5);
		cell1235.addElement(tableheader5);
//		cell123.addElement(new Paragraph("\n"));
//		cell123.addElement(new Paragraph("\n"));
		cell1235.setBorder(Rectangle.NO_BORDER);
//		cell123.setBorder(Rectangle.CELL);
		table5.addCell(cell1235);
		
		PdfPCell cell1235255 ;
		cell1235255 = new PdfPCell();
		cell1235255.setBorder(Rectangle.NO_BORDER);
	
		cell1235255.addElement(tabledata51_reserve);
	 
		
		
		
		PdfPTable table5a1 = new PdfPTable(1);
		table5a1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table5a1.setWidthPercentage(100);
		
		table5a1.addCell(cell1235255);
		
		PdfPCell cell1236_C12236 ;
		cell1236_C12236 = new PdfPCell();
		cell1236_C12236.setPaddingTop(6.4f);
		cell1236_C12236.setPaddingBottom(29f); 
		cell1236_C12236.setBorder(Rectangle.NO_BORDER);
	
		cell1236_C12236.addElement( table5a1);
		
		
		
		
		table5.addCell(cell1236_C12236);
		
		
		
		 
		
		
		

		// ==============ALMC

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table4_4 = new PdfPTable(1);
		table4_4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table4_4.setWidthPercentage(90);

		PdfPTable tabledata4_4 = new PdfPTable(1);
		tabledata4_4.setWidths(new int[] { 7 });
		tabledata4_4.setWidthPercentage(100 / 3.5f);
		tabledata4_4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata4_4.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata4_4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head45_21 = new Paragraph("Appendix 'E' Contd.", fontTableHeadingMainHead_l);
		Paragraph head6122 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head632 = new Paragraph("letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head642 = new Paragraph("dated" + "           " + letter_date1 + ")", fontTableHeadingMainHead_l);
		tabledata4_4.addCell(head45_21);
		tabledata4_4.addCell(head6122);
		tabledata4_4.addCell(head632);
		tabledata4_4.addCell(head642);

		Chunk ALMC_heading = new Chunk("LIST OF NOMINATED OFFICERS FOR ALMC/ISC", fontTableHeadingSubMainHead);
		ALMC_heading.setUnderline(0.1f, -2f);
		Paragraph ALMC_paragraph = new Paragraph(ALMC_heading);
		ALMC_paragraph.setFont(fontTableHeading1);
		ALMC_paragraph.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader4_ALMC = new PdfPTable(1);
		tableheader4_ALMC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader4_ALMC.setWidthPercentage(100);
		tableheader4_ALMC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader4_ALMC.addCell(ALMC_paragraph);
		tableheader4_ALMC.addCell(new Paragraph(
				"THE UNDER MENTIONED OFFICERS LISTED IN THEIR ORDER OF SENIORITY BY ARMS AND \n  "
						+ "         SERVICES HAVE BEEN NOMINATED TO ATTEND THE DEFENCE SERVICES TECHNICAL STAFF COLLEGE COURSE\n\n\n",
				fontTableHeadingSubMainHeadNew_2));
		
//		 COMMENCING-5 
		
		
PdfPTable tabledata412_ALMC = new PdfPTable(1);
		
 	 
tabledata412_ALMC.setWidthPercentage(100);
tabledata412_ALMC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata412_ALMC.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	 
	 
		

		PdfPTable tabledata41_ALMC = new PdfPTable(7);
		
//		tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tabledata41_ALMC.setWidths(new int[] { 1, 3, 2, 7, 6, 3, 3 });
		tabledata41_ALMC.setWidthPercentage(100);
		tabledata41_ALMC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata41_ALMC.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata41_ALMC.setHeaderRows(1);
		tabledata41_ALMC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
//		
		ArrayList<List<String>> fullypassed1 = (ArrayList<List<String>>) model.get("fullypassed_D");
		Paragraph a_C22 = new Paragraph("SER NO", fontTableHeadingSubMainHead_2);
		Paragraph f_C22 = new Paragraph("PERS NO", fontTableHeadingSubMainHead_2);
		Paragraph b_C22 = new Paragraph("RANK", fontTableHeadingSubMainHead_2);
		Paragraph c_C22 = new Paragraph("NAME", fontTableHeadingSubMainHead_2);
		Paragraph d_C22 = new Paragraph("UNIT", fontTableHeadingSubMainHead_2);
		Paragraph e_C22 = new Paragraph("CH 1", fontTableHeadingSubMainHead_2);
		Paragraph g_C22 = new Paragraph("CH 2", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cella1_C122 = new PdfPCell(a_C22);
//		blank_cella1_C122.setPadding(5);
		blank_cella1_C122.setBorder(Rectangle.BOTTOM);
		blank_cella1_C122.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella2_C12 = new PdfPCell(f_C22);
//		blank_cella2_C12.setPadding(5);
		blank_cella2_C12.setBorder(Rectangle.BOTTOM);
		blank_cella2_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella3_C12 = new PdfPCell(b_C22);
//		blank_cella3_C12.setPadding(5);
		blank_cella3_C12.setBorder(Rectangle.BOTTOM);
		blank_cella3_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella4_C12 = new PdfPCell(c_C22);
//		blank_cella4_C12.setPadding(5);
		blank_cella4_C12.setBorder(Rectangle.BOTTOM);
		blank_cella4_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella5_C12 = new PdfPCell(d_C22);
//		blank_cella5_C12.setPadding(5);
		blank_cella5_C12.setBorder(Rectangle.BOTTOM);
		blank_cella5_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		
		
		PdfPCell blank_cella6_C12 = new PdfPCell(e_C22);
//		blank_cella6_C12.setPadding(5);
		blank_cella6_C12.setBorder(Rectangle.BOTTOM);
		blank_cella6_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella7_C12 = new PdfPCell(g_C22);
//		blank_cella7_C12.setPadding(5);
		blank_cella7_C12.setBorder(Rectangle.BOTTOM);
		blank_cella7_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		tabledata41_ALMC.addCell(blank_cella1_C122);
		tabledata41_ALMC.addCell(blank_cella2_C12);
		tabledata41_ALMC.addCell(blank_cella3_C12);
		tabledata41_ALMC.addCell(blank_cella4_C12);
		tabledata41_ALMC.addCell(blank_cella5_C12);
		tabledata41_ALMC.addCell(blank_cella6_C12);
		tabledata41_ALMC.addCell(blank_cella7_C12);
		
		String armForALMCISC = "";
		ArrayList<List<String>> getALMCISCList = (ArrayList<List<String>>) model.get("getALMCISCList");
		
		
 
			int flag_first_page_ALMC = 42;
			int flag_first_page_fix_ALMC = 42;
			
		 
			for (int i = 0; i < getALMCISCList.size();i++) {
				//if(i > 45){ flag_first_page_fix = 66;}
					
				
				
				List<String> l = getALMCISCList.get(i);
				PdfPCell celle_fl = new PdfPCell();
					 
					if(flag_first_page_ALMC > (flag_first_page_fix_ALMC-flag_first_page_fix_ALMC) && flag_first_page_ALMC <= (flag_first_page_fix_ALMC)) {
						
						Paragraph blank8 = new Paragraph(l.get(7), fontTableHeadingdatabold);
						if (!l.get(7).equals(armForALMCISC)) {
							armForALMCISC = l.get(7);
							PdfPCell cellarow = new PdfPCell();
							cellarow.setColspan(7);
							cellarow.setPhrase(blank8);
							cellarow.setBorder(Rectangle.NO_BORDER);
							cellarow.setPadding(1);
							cellarow.setPaddingBottom(9.38f);
							cellarow.setHorizontalAlignment(Element.ALIGN_CENTER);
							tabledata41_ALMC.addCell(cellarow);
							flag_first_page_ALMC -= 1;
						}
						
						Paragraph ser_no = new Paragraph(l.get(0), fontTableHeadingdata);
						 celle_fl = new PdfPCell(ser_no);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						 celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						 celle_fl.setPadding(3);
						 if (i % 2 == 0) {
								celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						 tabledata41_ALMC.addCell(celle_fl);
						 
						 
						Paragraph ic_number = new Paragraph(l.get(1), fontTableHeadingdata);
						celle_fl = new PdfPCell(ic_number);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata41_ALMC.addCell(celle_fl);
						
						
						Paragraph rank = new Paragraph(l.get(2), fontTableHeadingdata);
						celle_fl = new PdfPCell(rank);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata41_ALMC.addCell(celle_fl);
						
						
						Paragraph pers_name = new Paragraph(l.get(3), fontTableHeadingdata);
						celle_fl = new PdfPCell(pers_name);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata41_ALMC.addCell(celle_fl);
						
						
						Paragraph arm1 = new Paragraph(l.get(4), fontTableHeadingdata);
						celle_fl = new PdfPCell(arm1);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata41_ALMC.addCell(celle_fl);
							
						String CH1 = "";
						System.out.println("ALMCISC========="+l.get(6));
						if ( l.get(6)==null) {
							CH1 = "";
						}
						else if (l.get(6).equals( "ALMC")) {
							CH1 = "A";
						}
						else if (l.get(6).equals( "ISC")) {
							CH1 = "I";
						}
						Paragraph blank5 = new Paragraph(CH1, fontTableHeadingdata);	
						celle_fl = new PdfPCell(blank5);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata41_ALMC.addCell(celle_fl);
							String CH2 = "";
						System.out.println("ALMCISC========="+l.get(6));
						if ( l.get(6)==null) {
							CH2 = "";
						}
						else if (l.get(6).equals( "ALMC")) {
							CH2 = "A";
						}
						else if (l.get(6).equals( "ISC")) {
							CH2 = "I";
						}
						Paragraph blank6 = new Paragraph(CH2, fontTableHeadingdata);
						celle_fl = new PdfPCell(blank6);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata41_ALMC.addCell(celle_fl);
							
						 
						
					}
				 
				if(flag_first_page_ALMC==((flag_first_page_fix_ALMC-flag_first_page_fix_ALMC)+1)){
					tabledata412_ALMC.addCell(tabledata41_ALMC);
					  tabledata41_ALMC = new PdfPTable(7);
					
//					tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					tabledata41_ALMC.setWidths(new int[] { 1, 3, 2, 7, 6, 3, 3 });
					tabledata41_ALMC.setWidthPercentage(100);
					tabledata41_ALMC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					tabledata41_ALMC.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
					tabledata41_ALMC.setHeaderRows(1);
					tabledata41_ALMC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
//					 
					tabledata41_ALMC.addCell(blank_cella1_C122);
					tabledata41_ALMC.addCell(blank_cella2_C12);
					tabledata41_ALMC.addCell(blank_cella3_C12);
					tabledata41_ALMC.addCell(blank_cella4_C12);
					tabledata41_ALMC.addCell(blank_cella5_C12);
					tabledata41_ALMC.addCell(blank_cella6_C12);
					tabledata41_ALMC.addCell(blank_cella7_C12);


				}
				 
				if(getALMCISCList.size() == (i+1) & flag_first_page_ALMC > (flag_first_page_fix_ALMC-flag_first_page_fix_ALMC) & flag_first_page_ALMC < ((flag_first_page_fix_ALMC)+1)){
				
					tabledata412_ALMC.addCell(tabledata41_ALMC);
					  tabledata41_ALMC = new PdfPTable(7);
					
//					tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					tabledata41_ALMC.setWidths(new int[] { 1, 3, 2, 7, 6, 3, 3 });
					tabledata41_ALMC.setWidthPercentage(100);
					tabledata41_ALMC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
					tabledata41_ALMC.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
					tabledata41_ALMC.setHeaderRows(1);
					tabledata41_ALMC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
//					 
					tabledata41_ALMC.addCell(blank_cella1_C122);
					tabledata41_ALMC.addCell(blank_cella2_C12);
					tabledata41_ALMC.addCell(blank_cella3_C12);
					tabledata41_ALMC.addCell(blank_cella4_C12);
					tabledata41_ALMC.addCell(blank_cella5_C12);
					tabledata41_ALMC.addCell(blank_cella6_C12);
					tabledata41_ALMC.addCell(blank_cella7_C12);

				}			
				flag_first_page_ALMC -= 1;
				if(flag_first_page_ALMC == 0) {
					flag_first_page_fix_ALMC = 50;
					flag_first_page_ALMC = flag_first_page_fix_ALMC;				
				}
			}
		 
			
			
		table4_4.setSplitLate(false);
		PdfPCell cell1236_C122;
		cell1236_C122 = new PdfPCell();
//		cell123.setPaddingLeft(30f);
//		cell123.setPaddingRight(30f);
		cell1236_C122.addElement(tabledata4_4);
		cell1236_C122.addElement(tableheader4_ALMC);
//		cell123.addElement(new Paragraph("\n"));
//		cell123.addElement(new Paragraph("\n"));
		cell1236_C122.setBorder(Rectangle.NO_BORDER);
//		cell123.setBorder(Rectangle.CELL);
		table4_4.addCell(cell1236_C122);
		
		 
		PdfPCell cell1236_4_4_f1 ;
		cell1236_4_4_f1 = new PdfPCell();
		 
		cell1236_4_4_f1.setBorder(Rectangle.NO_BORDER);
	
		cell1236_4_4_f1.addElement(tabledata412_ALMC);
		
		 
		PdfPTable table4_4a1 = new PdfPTable(1);
		table4_4a1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table4_4a1.setWidthPercentage(100);
		
		table4_4a1.addCell(cell1236_4_4_f1);
		
		PdfPCell cell1236_C1223 ;
		cell1236_C1223 = new PdfPCell();
		cell1236_C1223.setPaddingTop(6.4f);
		cell1236_C1223.setPaddingBottom(29f); 
		cell1236_C1223.setBorder(Rectangle.NO_BORDER);
	
		cell1236_C1223.addElement( table4_4a1);
		 
		
		table4_4.addCell(cell1236_C1223);
		
		 
		
		// writeFooterTable(arg2,document,table4);

		// =====================================Failed========================//
		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table6 = new PdfPTable(1);
		table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table6.setWidthPercentage(90);

		PdfPTable tabledata6 = new PdfPTable(1);
		tabledata6.setWidths(new int[] { 5 });
		tabledata6.setWidthPercentage(100 / 3.5f);
		tabledata6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata6.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata6.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head61 = new Paragraph("Appendix 'F'", fontTableHeadingMainHead_l);
		Paragraph head612 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head63 = new Paragraph("letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head64 = new Paragraph("dated" + "           " + letter_date1 + ") \n\n\n", fontTableHeadingMainHead_l);

//		tabledata6.addCell( new Paragraph("\n"));
//		tabledata6.addCell( new Paragraph("\n"));
//		tabledata6.addCell( new Paragraph("\n"));
		 
		
		tabledata6.addCell(head61);
		tabledata6.addCell(head612);
		tabledata6.addCell(head63);
		tabledata6.addCell(head64);

		Chunk underline6 = new Chunk( "DSSC-"+ dsscCourseNo +"/ DSTSC - "+ dstscCourseNo +" ENTRANCE EXAM" + "\n\n" + "MARKS OF OFFICERS WHO DID NOT QUALIFY",
				fontTableHeadingSubMainHead);
		
//		Chunk underline6 = new Chunk( "DSSC-"+ dsscCourseNo +"/ DSTSC - "+ dstscCourseNo +" ENTRANCE EXAM SEP 2020" + "\n\n" + "MARKS OF OFFICERS WHO DID NOT QUALIFY",
//				fontTableHeadingSubMainHead);

		Phrase phh6 = new Phrase(underline6);
		underline6.setUnderline(0.1f, -2f);
		phh6.add("\n");
		phh6.add("\n");
		phh6.setFont(fontTableHeadingSubMainHead);

		Paragraph cell61 = new Paragraph(phh6);
		cell61.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader6 = new PdfPTable(1);
		tableheader6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader6.setWidthPercentage(100);
		tableheader6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader6.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader6.addCell(cell61);
		
		PdfPTable tabledataman61 = new PdfPTable(1);

		tabledataman61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledataman61.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledataman61.setWidthPercentage(100);
		tabledataman61.getDefaultCell().setBorder(Rectangle.BOX);

 
		
		
		PdfPTable tabledata61 = new PdfPTable(11);

		tabledata61.setWidths(new int[] { 2, 4, 3, 12, 3, 3, 3, 3, 3, 3,3});
		tabledata61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata61.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata61.setWidthPercentage(100);
		tabledata61.setHeaderRows(2);

 
		
		

		Paragraph a6 = new Paragraph("SER NO",fontTableHeadingSubMainHead1);
		Paragraph b6 = new Paragraph("PERS NO",fontTableHeadingSubMainHead1);
		Paragraph c6 = new Paragraph("RANK",fontTableHeadingSubMainHead1);
		Paragraph d6 = new Paragraph("NAME",fontTableHeadingSubMainHead1);
		Paragraph e6 = new Paragraph("ARM /" +"\n"+ "SERVICE",fontTableHeadingSubMainHead1);
		Paragraph f6 = new Paragraph("MARKS OUT OF 500 EACH",fontTableHeadingSubMainHead1);
		
		
		
		PdfPCell blank_cella1_C11 = new PdfPCell(a6);
//		blank_cella1_C11.setRowspan(2);
		blank_cella1_C11.setBorder(Rectangle.RIGHT);

		 
		blank_cella1_C11.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C11.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		
		PdfPCell blank_cella1_C12 = new PdfPCell(b6);
//		blank_cella1_C12.setRowspan(2);
		blank_cella1_C12.setBorder(Rectangle.RIGHT);

		 
		blank_cella1_C12.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C12.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		PdfPCell blank_cella1_C13 = new PdfPCell(c6);
//		blank_cella1_C13.setRowspan(2);
		blank_cella1_C13.setBorder(Rectangle.RIGHT);

	 
		blank_cella1_C13.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C13.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		
		PdfPCell blank_cella1_C14 = new PdfPCell(d6);
//		blank_cella1_C14.setRowspan(2);
		blank_cella1_C14.setBorder(Rectangle.RIGHT);

	 
		blank_cella1_C14.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C14.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		
		PdfPCell blank_cella1_C15 = new PdfPCell(e6);
//		blank_cella1_C15.setRowspan(2);
		blank_cella1_C15.setBorder(Rectangle.RIGHT); 
blank_cella1_C15.setHorizontalAlignment(Element.ALIGN_CENTER);
blank_cella1_C15.setVerticalAlignment(Element.ALIGN_MIDDLE);
	 
		
		PdfPCell blank_cella1_C16 = new PdfPCell(f6);
		blank_cella1_C16.setColspan(6);
		blank_cella1_C16.setBorder(Rectangle.BOTTOM);

		blank_cella1_C16.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C16.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		
		
		
		

		tabledata61.addCell(blank_cella1_C11);
		tabledata61.addCell(blank_cella1_C12);
		tabledata61.addCell(blank_cella1_C13);
		tabledata61.addCell(blank_cella1_C14);
		tabledata61.addCell(blank_cella1_C15);
		tabledata61.addCell(blank_cella1_C16);
		
		
		Paragraph a66 = new Paragraph("TAC A",fontTableHeadingSubMainHead1);
		Paragraph b66 = new Paragraph("TAC B",fontTableHeadingSubMainHead1);
		Paragraph c66 = new Paragraph("A & L",fontTableHeadingSubMainHead1);
		Paragraph d66 = new Paragraph("CA",fontTableHeadingSubMainHead1);
		Paragraph e66 = new Paragraph("SMT",fontTableHeadingSubMainHead1);
		Paragraph f66 = new Paragraph("MH",fontTableHeadingSubMainHead1);
		
//		5
		String rdp="";
		
		PdfPCell blank_cella2_rdp= new PdfPCell(new Paragraph(rdp)); 
		blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
		blank_cella2_rdp.setPaddingLeft(13f);
	tabledata61.addCell(blank_cella2_rdp);
	
	blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
	blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
	blank_cella2_rdp.setPaddingLeft(13f);
	tabledata61.addCell(blank_cella2_rdp);
	
	blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
	blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
	blank_cella2_rdp.setPaddingLeft(13f);
	tabledata61.addCell(blank_cella2_rdp);
	
	blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
	blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
	blank_cella2_rdp.setPaddingLeft(13f);
	tabledata61.addCell(blank_cella2_rdp);
	
	blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
	blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
	blank_cella2_rdp.setPaddingLeft(13f);
	tabledata61.addCell(blank_cella2_rdp);
 
		
		PdfPCell blank_cella1_C66 = new PdfPCell(a66);
	 
		blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//		blank_cella1_C66.setPaddingLeft(70f);
		blank_cella1_C66.setPaddingLeft(5f);
		tabledata61.addCell(blank_cella1_C66);
		
		
		blank_cella1_C66 = new PdfPCell(b66);
		 		blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//		blank_cella1_C66.setPaddingLeft(70f);
		 		blank_cella1_C66.setPaddingLeft(5f);
		tabledata61.addCell(blank_cella1_C66);
		
		blank_cella1_C66 = new PdfPCell(c66);
		 
		blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//		blank_cella1_C66.setPaddingLeft(70f);
		blank_cella1_C66.setPaddingLeft(5f);
		tabledata61.addCell(blank_cella1_C66);
		
		
		blank_cella1_C66 = new PdfPCell(d66);
	 
		blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//		blank_cella1_C66.setPaddingLeft(70f);
		blank_cella1_C66.setPaddingLeft(14f);
		tabledata61.addCell(blank_cella1_C66);
		
		blank_cella1_C66 = new PdfPCell(e66);
		 
		blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//		blank_cella1_C66.setPaddingLeft(70f);
		blank_cella1_C66.setPaddingLeft(14f);
		tabledata61.addCell(blank_cella1_C66);
		
		blank_cella1_C66 = new PdfPCell(f66);
		 
		blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//		blank_cella1_C66.setPaddingLeft(70f);
		blank_cella1_C66.setPaddingLeft(14f);
		tabledata61.addCell(blank_cella1_C66);
		
		ArrayList<List<String>> getfailofficeristReport = (ArrayList<List<String>>) model.get("getfailofficeristReport");
		
		
		int flag_first_page2 = 40;
		int flag_first_page_fix2 = 40;
		 
		
 	
		
		for (int i = 0; i < getfailofficeristReport.size();i++) {
			//if(i > 45){ flag_first_page_fix = 66;}
				
			
			
			List<String> l = getfailofficeristReport.get(i);
			PdfPCell celle_fl = new PdfPCell();
			celle_fl.setBorder(Rectangle.RIGHT); 
				if(flag_first_page2 > (flag_first_page_fix2-flag_first_page_fix2) && flag_first_page2 <= (flag_first_page_fix2)) {
					Paragraph ser_no = new Paragraph(l.get(0), fontTableHeadingdata);
					 celle_fl = new PdfPCell(ser_no);
						celle_fl.setBorder(Rectangle.RIGHT); 
					 celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					 celle_fl.setPadding(3);
					 if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					 tabledata61.addCell(celle_fl);
					Paragraph ic_number = new Paragraph(l.get(1), fontTableHeadingdata);
					celle_fl = new PdfPCell(ic_number);
					celle_fl.setBorder(Rectangle.RIGHT); 
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata61.addCell(celle_fl);
					Paragraph rank = new Paragraph(l.get(2), fontTableHeadingdata);
					celle_fl = new PdfPCell(rank);
					celle_fl.setBorder(Rectangle.RIGHT); 
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata61.addCell(celle_fl);
					Paragraph pers_name = new Paragraph(l.get(3), fontTableHeadingdata);
					celle_fl = new PdfPCell(pers_name);
					celle_fl.setBorder(Rectangle.RIGHT); 
					celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
//					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata61.addCell(celle_fl);
					Paragraph arm15 = new Paragraph(l.get(4), fontTableHeadingdata);
					celle_fl = new PdfPCell(arm15);
					celle_fl.setBorder(Rectangle.RIGHT); 
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata61.addCell(celle_fl);
						
					
					
					Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdata);
					
					celle_fl = new PdfPCell(blank6);
					celle_fl.setBorder(Rectangle.NO_BORDER); 
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					celle_fl.setPaddingLeft(5f);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata61.addCell(celle_fl);
					
					Paragraph blank7 = new Paragraph(l.get(6), fontTableHeadingdata);
					
					celle_fl = new PdfPCell(blank7);
					celle_fl.setPaddingLeft(5f);
					celle_fl.setBorder(Rectangle.NO_BORDER); 
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata61.addCell(celle_fl);
					
					Paragraph blank8 = new Paragraph(l.get(7), fontTableHeadingdata);
					
					celle_fl = new PdfPCell(blank8);
					
					celle_fl.setPaddingLeft(5f);
					
					celle_fl.setBorder(Rectangle.NO_BORDER); 
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata61.addCell(celle_fl);
					
					Paragraph blank9 = new Paragraph(l.get(8), fontTableHeadingdata);
					
					celle_fl = new PdfPCell(blank9);
					
					celle_fl.setPaddingLeft(5f);
					
					celle_fl.setBorder(Rectangle.NO_BORDER); 
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata61.addCell(celle_fl);
					
					Paragraph blank10 = new Paragraph(l.get(9), fontTableHeadingdata);
					
					celle_fl = new PdfPCell(blank10);
					celle_fl.setPaddingLeft(5f);

					celle_fl.setBorder(Rectangle.NO_BORDER); 
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata61.addCell(celle_fl);
					
					Paragraph blank11 = new Paragraph(l.get(10), fontTableHeadingdata);
					
					celle_fl = new PdfPCell(blank11);
					celle_fl.setBorder(Rectangle.NO_BORDER); 
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata61.addCell(celle_fl);
					
				}
			 
			if(flag_first_page2==((flag_first_page_fix2-flag_first_page_fix2)+1)){
				tabledataman61.addCell(tabledata61);
				  tabledata61 = new PdfPTable(11);

				tabledata61.setWidths(new int[] { 2, 4, 3, 10, 4, 3, 3, 3, 3, 3,3});
				tabledata61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata61.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
				tabledata61.setWidthPercentage(100);
				tabledata61.setHeaderRows(2);

				tabledata61.addCell(blank_cella1_C11);
				tabledata61.addCell(blank_cella1_C12);
				tabledata61.addCell(blank_cella1_C13);
				tabledata61.addCell(blank_cella1_C14);
				tabledata61.addCell(blank_cella1_C15);
				tabledata61.addCell(blank_cella1_C16);
				
				
				  a66 = new Paragraph("TAC A",fontTableHeadingSubMainHead1);
				 b66 = new Paragraph("TAC B",fontTableHeadingSubMainHead1);
				 c66 = new Paragraph("A & L",fontTableHeadingSubMainHead1);
				  d66 = new Paragraph("CA",fontTableHeadingSubMainHead1);
			  e66 = new Paragraph("SMT",fontTableHeadingSubMainHead1);
				  f66 = new Paragraph("MH",fontTableHeadingSubMainHead1);
				
//				5
				  rdp="";
				
				  blank_cella2_rdp= new PdfPCell(new Paragraph(rdp)); 
				blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
				blank_cella2_rdp.setPaddingLeft(13f);
			tabledata61.addCell(blank_cella2_rdp);
			
			blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
			blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
			blank_cella2_rdp.setPaddingLeft(13f);
			tabledata61.addCell(blank_cella2_rdp);
			
			blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
			blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
			blank_cella2_rdp.setPaddingLeft(13f);
			tabledata61.addCell(blank_cella2_rdp);
			
			blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
			blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
			blank_cella2_rdp.setPaddingLeft(13f);
			tabledata61.addCell(blank_cella2_rdp);
			
			blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
			blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
			blank_cella2_rdp.setPaddingLeft(13f);
			tabledata61.addCell(blank_cella2_rdp);
		 
				
			blank_cella1_C66 = new PdfPCell(a66);
			 
			blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//			blank_cella1_C66.setPaddingLeft(70f);
			blank_cella1_C66.setPaddingLeft(5f);
			tabledata61.addCell(blank_cella1_C66);
			
			
			blank_cella1_C66 = new PdfPCell(b66);
			 		blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//			blank_cella1_C66.setPaddingLeft(70f);
			 		blank_cella1_C66.setPaddingLeft(5f);
			tabledata61.addCell(blank_cella1_C66);
			
			blank_cella1_C66 = new PdfPCell(c66);
			 
			blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//			blank_cella1_C66.setPaddingLeft(70f);
			blank_cella1_C66.setPaddingLeft(7f);
			tabledata61.addCell(blank_cella1_C66);
			
			
			blank_cella1_C66 = new PdfPCell(d66);
		 
			blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//			blank_cella1_C66.setPaddingLeft(70f);
			blank_cella1_C66.setPaddingLeft(14f);
			tabledata61.addCell(blank_cella1_C66);
			
			blank_cella1_C66 = new PdfPCell(e66);
			 
			blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//			blank_cella1_C66.setPaddingLeft(70f);
			blank_cella1_C66.setPaddingLeft(14f);
			tabledata61.addCell(blank_cella1_C66);
			
			blank_cella1_C66 = new PdfPCell(f66);
			 
			blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//			blank_cella1_C66.setPaddingLeft(70f);
			blank_cella1_C66.setPaddingLeft(14f);
			tabledata61.addCell(blank_cella1_C66);
				

			}
			
		 
			if(getfailofficeristReport.size() == (i+1) & flag_first_page2 > (flag_first_page_fix2-flag_first_page_fix2) & flag_first_page2 < ((flag_first_page_fix2)+1)){
			
				tabledataman61.addCell(tabledata61);
				 tabledata61 = new PdfPTable(11);

					tabledata61.setWidths(new int[] { 2, 4, 3, 10, 4, 3, 3, 3, 3, 3,3});
					tabledata61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
					tabledata61.setWidthPercentage(100);
					tabledata61.setHeaderRows(2);
 
					tabledata61.addCell(blank_cella1_C11);
					tabledata61.addCell(blank_cella1_C12);
					tabledata61.addCell(blank_cella1_C13);
					tabledata61.addCell(blank_cella1_C14);
					tabledata61.addCell(blank_cella1_C15);
					tabledata61.addCell(blank_cella1_C16);
					
					
					  a66 = new Paragraph("TAC A",fontTableHeadingSubMainHead1);
					 b66 = new Paragraph("TAC B",fontTableHeadingSubMainHead1);
					 c66 = new Paragraph("A & L",fontTableHeadingSubMainHead1);
					  d66 = new Paragraph("CA",fontTableHeadingSubMainHead1);
				  e66 = new Paragraph("SMT",fontTableHeadingSubMainHead1);
					  f66 = new Paragraph("MH",fontTableHeadingSubMainHead1);
					
 
					  rdp="";
					
					  blank_cella2_rdp= new PdfPCell(new Paragraph(rdp)); 
					blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
					blank_cella2_rdp.setPaddingLeft(13f);
				tabledata61.addCell(blank_cella2_rdp);
				
				blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
				blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
				blank_cella2_rdp.setPaddingLeft(13f);
				tabledata61.addCell(blank_cella2_rdp);
				
				blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
				blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
				blank_cella2_rdp.setPaddingLeft(13f);
				tabledata61.addCell(blank_cella2_rdp);
				
				blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
				blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
				blank_cella2_rdp.setPaddingLeft(13f);
				tabledata61.addCell(blank_cella2_rdp);
				
				blank_cella2_rdp = new PdfPCell(new Paragraph(rdp)); 
				blank_cella2_rdp.setBorder( Rectangle.BOTTOM | Rectangle.RIGHT );
				blank_cella2_rdp.setPaddingLeft(13f);
				tabledata61.addCell(blank_cella2_rdp);
			 
					
				blank_cella1_C66 = new PdfPCell(a66);
				 
				blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//				blank_cella1_C66.setPaddingLeft(70f);
				blank_cella1_C66.setPaddingLeft(5f);
				tabledata61.addCell(blank_cella1_C66);
				
				
				blank_cella1_C66 = new PdfPCell(b66);
				 		blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//				blank_cella1_C66.setPaddingLeft(70f);
				 		blank_cella1_C66.setPaddingLeft(5f);
				tabledata61.addCell(blank_cella1_C66);
				
				blank_cella1_C66 = new PdfPCell(c66);
				 
				blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//				blank_cella1_C66.setPaddingLeft(70f);
				blank_cella1_C66.setPaddingLeft(7f);
				tabledata61.addCell(blank_cella1_C66);
				
				
				blank_cella1_C66 = new PdfPCell(d66);
			 
				blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//				blank_cella1_C66.setPaddingLeft(70f);
				blank_cella1_C66.setPaddingLeft(14f);
				tabledata61.addCell(blank_cella1_C66);
				
				blank_cella1_C66 = new PdfPCell(e66);
				 
				blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//				blank_cella1_C66.setPaddingLeft(70f);
				blank_cella1_C66.setPaddingLeft(14f);
				tabledata61.addCell(blank_cella1_C66);
				
				blank_cella1_C66 = new PdfPCell(f66);
				 
				blank_cella1_C66.setBorder(Rectangle.BOTTOM);
//				blank_cella1_C66.setPaddingLeft(70f);
				blank_cella1_C66.setPaddingLeft(14f);
				tabledata61.addCell(blank_cella1_C66);
					
					
			}			
			flag_first_page2 -= 1;
			if(flag_first_page2 == 0) {
				flag_first_page_fix2 =52;
				flag_first_page2 = flag_first_page_fix2;				
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		table6.setSplitLate(false);
		PdfPCell cell12356;
		cell12356 = new PdfPCell();
//		cell123.setPaddingLeft(30f);
//		cell123.setPaddingRight(30f);
		cell12356.addElement(tabledata6);
		cell12356.addElement(tableheader6);
//		cell123.addElement(new Paragraph("\n"));
//		cell123.addElement(new Paragraph("\n"));
		cell12356.setBorder(Rectangle.NO_BORDER);
//		cell123.setBorder(Rectangle.CELL);
		table6.addCell(cell12356);
		
		 
		PdfPCell cell12356_f1 ;
		cell12356_f1 = new PdfPCell();
		 
		cell12356_f1.setBorder(Rectangle.NO_BORDER);
	
		cell12356_f1.addElement(tabledataman61);
		
		 
		PdfPTable table6a1 = new PdfPTable(1);
		table6a1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table6a1.setWidthPercentage(100);
		
		table6a1.addCell(cell12356_f1);
		
		PdfPCell cell12356_2 ;
		cell12356_2 = new PdfPCell();
		cell12356_2.setPaddingTop(25f);
//		cell12356_2.setPaddingBottom(32.4f); 
		cell12356_2.setBorder(Rectangle.NO_BORDER);
	
		cell12356_2.addElement(table6a1);
		 
		
		table6.addCell(cell12356_2);

		// =====================================Absenteess========================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table7 = new PdfPTable(1);
		table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table7.setWidthPercentage(90);

		PdfPTable tabledata7 = new PdfPTable(1);
		tabledata7.setWidths(new int[] { 5 });
		tabledata7.setWidthPercentage(100 / 3.5f);
		tabledata7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata7.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata7.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head71 = new Paragraph("Appendix 'G'", fontTableHeadingMainHead_l);
		Paragraph head72 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head73 = new Paragraph("letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head74 = new Paragraph("dated" + "           " + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata7.addCell(head71);
		tabledata7.addCell(head72);
		tabledata7.addCell(head73);
		tabledata7.addCell(head74);

		Chunk underline7 = new Chunk(
				"LIST OF ABSENTEES - DSSC- " + dsscCourseNo +" /DSTSC - " + dstscCourseNo + "\n" + "ENTRANCE EXAMINATION \n",
				fontTableHeadingSubMainHead);

		Phrase phh7 = new Phrase(underline7);
		underline7.setUnderline(0.1f, -2f);

		phh7.add("\n");
		phh7.setFont(fontTableHeadingSubMainHead);

		Paragraph cell71 = new Paragraph(phh7);
		cell71.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader7 = new PdfPTable(1);
		tableheader7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader7.setWidthPercentage(100);
		tableheader7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader7.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader7.addCell(cell71);

		PdfPTable tabledata712 = new PdfPTable(1); 
		tabledata712.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata712.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata712.setWidthPercentage(100);
		tabledata712.getDefaultCell().setBorder(Rectangle.BOX);
		
		PdfPTable tabledata71 = new PdfPTable(7);

		tabledata71.setWidths(new int[] { 3, 5, 4, 8, 5, 5, 5 });
		tabledata71.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata71.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata71.setWidthPercentage(100);
		tabledata71.getDefaultCell().setBorder(Rectangle.BOTTOM);
		tabledata71.getDefaultCell().setPadding(5);
	

		tabledata71.setHeaderRows(1);
		
		Paragraph a7 = new Paragraph("SER NO", fontTableHeadingSubMainHead1);
		Paragraph b7 = new Paragraph("PERS NO", fontTableHeadingSubMainHead1);
		Paragraph c7 = new Paragraph("RANK", fontTableHeadingSubMainHead1);
		Paragraph d7 = new Paragraph("NAME", fontTableHeadingSubMainHead1);
		Paragraph e7 = new Paragraph("UNIT", fontTableHeadingSubMainHead1);
		Paragraph f7 = new Paragraph("EXAM CENTRE", fontTableHeadingSubMainHead1);

		Paragraph g7 = new Paragraph("SUBJECTS", fontTableHeadingSubMainHead1);

		tabledata71.addCell(a7);
		tabledata71.addCell(b7);
		tabledata71.addCell(c7);
		tabledata71.addCell(d7);
		tabledata71.addCell(e7);
		tabledata71.addCell(f7);
		tabledata71.addCell(g7);

		ArrayList<List<String>> PartAbsenteesForDSSC_DSTSC = (ArrayList<List<String>>) model
				.get("PartAbsenteesForDSSC_DSTSC");
		
		
		
		
		
		
		
		
		
	String armFor_Absenteess = "";
		
		int flag_first_page_Absenteess = 42;
		int flag_first_page_fix_Absenteess = 42;
		
	 
		for (int i = 0; i < PartAbsenteesForDSSC_DSTSC.size();i++) {
			//if(i > 45){ flag_first_page_fix = 66;}
				
			
			
			List<String> l = PartAbsenteesForDSSC_DSTSC.get(i);
			PdfPCell celle_fl = new PdfPCell();
				 
				if(flag_first_page_Absenteess > (flag_first_page_fix_Absenteess-flag_first_page_fix_Absenteess) && flag_first_page_Absenteess <= (flag_first_page_fix_Absenteess)) {
//					
//					Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdatabold);
//					
//					if (!l.get(5).equals(armFor_Absenteess)) {
//						armFor_Absenteess = l.get(5);
//						PdfPCell cellarow = new PdfPCell();
//						cellarow.setColspan(5);
//						cellarow.setPhrase(blank6);
//						cellarow.setBorder(Rectangle.NO_BORDER);
//						cellarow.setPadding(2f);
//						cellarow.setPaddingBottom(7.4f);
//						cellarow.setHorizontalAlignment(Element.ALIGN_CENTER);
//						tabledata41_DSTSC.addCell(cellarow);
//					}
//					
					
					Paragraph ser_no = new Paragraph(l.get(0), fontTableHeadingdata);
					 celle_fl = new PdfPCell(ser_no);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					 celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					 celle_fl.setPadding(3);
					 if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					 tabledata71.addCell(celle_fl);
					 
					 
					Paragraph ic_number = new Paragraph(l.get(1), fontTableHeadingdata);
					celle_fl = new PdfPCell(ic_number);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata71.addCell(celle_fl);
					
					
					Paragraph rank = new Paragraph(l.get(2), fontTableHeadingdata);
					celle_fl = new PdfPCell(rank);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata71.addCell(celle_fl);
					
					
					Paragraph pers_name = new Paragraph(l.get(3), fontTableHeadingdata);
					celle_fl = new PdfPCell(pers_name);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata71.addCell(celle_fl);
					
					
					Paragraph arm1 = new Paragraph(l.get(4), fontTableHeadingdata);
					celle_fl = new PdfPCell(arm1);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata71.addCell(celle_fl);
						
					Paragraph blank5 = new Paragraph(l.get(5), fontTableHeadingdata);
					celle_fl = new PdfPCell(blank5);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata71.addCell(celle_fl);
						
					
					Paragraph blank6 = new Paragraph(l.get(6), fontTableHeadingdata);
					celle_fl = new PdfPCell(blank6);
					 celle_fl.setBorder(Rectangle.NO_BORDER);
					celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
					celle_fl.setPadding(3);
					if (i % 2 == 0) {
						celle_fl.setBackgroundColor(java.awt.Color.lightGray);
					}
					tabledata71.addCell(celle_fl);
						
					 
					
				}
			 
			if(flag_first_page_Absenteess==((flag_first_page_fix_Absenteess-flag_first_page_fix_Absenteess)+1)){
				tabledata712.addCell(tabledata71);
				tabledata71 = new PdfPTable(7);

				tabledata71.setWidths(new int[] { 3, 5, 4, 8, 5, 5, 5 });
				tabledata71.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata71.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
				tabledata71.setWidthPercentage(100);
				tabledata71.getDefaultCell().setBorder(Rectangle.BOTTOM);
  
				tabledata71.addCell(a7);
				tabledata71.addCell(b7);
				tabledata71.addCell(c7);
				tabledata71.addCell(d7);
				tabledata71.addCell(e7);
				tabledata71.addCell(f7);
				tabledata71.addCell(g7);


			}
			 
			if(PartAbsenteesForDSSC_DSTSC.size() == (i+1) & flag_first_page_Absenteess > (flag_first_page_fix_Absenteess-flag_first_page_fix_Absenteess) & flag_first_page_Absenteess < ((flag_first_page_fix_Absenteess)+1)){
			
				tabledata712.addCell(tabledata71);
				tabledata71 = new PdfPTable(7);

				tabledata71.setWidths(new int[] { 3, 5, 4, 8, 5, 5, 5 });
				tabledata71.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata71.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
				tabledata71.setWidthPercentage(100);
				tabledata71.getDefaultCell().setBorder(Rectangle.BOTTOM);
  
				tabledata71.addCell(a7);
				tabledata71.addCell(b7);
				tabledata71.addCell(c7);
				tabledata71.addCell(d7);
				tabledata71.addCell(e7);
				tabledata71.addCell(f7);
				tabledata71.addCell(g7);

			}			
			flag_first_page_Absenteess -= 1;
			if(flag_first_page_Absenteess == 0) {
				flag_first_page_fix_Absenteess = 50;
				flag_first_page_Absenteess = flag_first_page_fix_Absenteess;				
			}
		}
		  
		
		table7.setSplitLate(false);
		PdfPCell cell1235_7;
		cell1235_7 = new PdfPCell();
 
		cell1235_7.addElement(tabledata7);
		cell1235_7.addElement(tableheader7);
//		cell1235_7.addElement(tabledata712);
		cell1235_7.setBorder(Rectangle.NO_BORDER);
 
		table7.addCell(cell1235_7);
		
		 
		PdfPCell cell12356_f7 ;
		cell12356_f7 = new PdfPCell();
		 
		cell12356_f7.setBorder(Rectangle.NO_BORDER);
	
		cell12356_f7.addElement(tabledata712);
		 
		table7.addCell(cell12356_f7);

 

		// =====================================Withdrawals========================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table8 = new PdfPTable(1);
		table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table8.setWidthPercentage(90);

		PdfPTable tabledata8 = new PdfPTable(1);
		tabledata8.setWidths(new int[] { 5 });
		tabledata8.setWidthPercentage(100 / 3.5f);
		tabledata8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata8.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata8.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head811 = new Paragraph("Appendix 'H'", fontTableHeadingMainHead_l);
		Paragraph head82 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head83 = new Paragraph("letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head84 = new Paragraph("dated" + "           " + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata8.addCell(head811);
		tabledata8.addCell(head82);
		tabledata8.addCell(head83);
		tabledata8.addCell(head84);

		Chunk underline8 = new Chunk(
				"LIST OF WITHDRAWALS - DSSC- " + dsscCourseNo +" DSTSC - " + dstscCourseNo +"\n" + "ENTRANCE EXAMINATION \n",
				fontTableHeadingSubMainHead);

		Phrase phh8 = new Phrase(underline8);
		underline8.setUnderline(0.1f, -2f);

		phh8.add("\n");
		phh8.setFont(fontTableHeadingSubMainHead);

		Paragraph cell81 = new Paragraph(phh8);
		cell81.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader8 = new PdfPTable(1);
		tableheader8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader8.setWidthPercentage(100);
		tableheader8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader8.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader8.addCell(cell81);
		
		
		PdfPTable tabledata812 = new PdfPTable(1);

	 
		tabledata812.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata812.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata812.setWidthPercentage(100);
		tabledata812.getDefaultCell().setBorder(Rectangle.BOX);
			

		PdfPTable tabledata81 = new PdfPTable(6);

		tabledata81.setWidths(new int[] { 3, 5, 3, 9, 4, 5 });
		tabledata81.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata81.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata81.setWidthPercentage(100);
		tabledata81.getDefaultCell().setBorder(Rectangle.BOTTOM);
		tabledata81.getDefaultCell().setPadding(5);

//					ArrayList<List<String>> result_withheld = (ArrayList<List<String>>) model.get("resultwithheld_d");

		Paragraph a8 = new Paragraph("SER NO", fontTableHeadingSubMainHead1);
		Paragraph b8 = new Paragraph("PERS NO", fontTableHeadingSubMainHead1);
		Paragraph c8 = new Paragraph("RANK", fontTableHeadingSubMainHead1);
		Paragraph d8 = new Paragraph("NAME", fontTableHeadingSubMainHead1);
		Paragraph e8 = new Paragraph("ARM / SERVICE", fontTableHeadingSubMainHead1);
		Paragraph f8 = new Paragraph("UNIT", fontTableHeadingSubMainHead1);

		tabledata81.addCell(a8);
		tabledata81.addCell(b8);
		tabledata81.addCell(c8);
		tabledata81.addCell(d8);
		tabledata81.addCell(e8);
		tabledata81.addCell(f8);

		ArrayList<List<String>> getWithDrawalsDSSC = (ArrayList<List<String>>) model.get("getWithDrawalsDSSC");
		 
		
		
		String armFor_WithDrawal = "";
			
			int flag_first_page_WithDrawal= 42;
			int flag_first_page_fix_WithDrawal = 42;
			
		 
			for (int i = 0; i < getWithDrawalsDSSC.size();i++) {
				//if(i > 45){ flag_first_page_fix = 66;}
					
				
				
				List<String> l = getWithDrawalsDSSC.get(i);
				PdfPCell celle_fl = new PdfPCell();
					 
					if(flag_first_page_WithDrawal > (flag_first_page_fix_WithDrawal-flag_first_page_fix_WithDrawal) && flag_first_page_WithDrawal <= (flag_first_page_fix_WithDrawal)) {
//						
//						Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdatabold);
//						
//						if (!l.get(5).equals(armFor_Absenteess)) {
//							armFor_Absenteess = l.get(5);
//							PdfPCell cellarow = new PdfPCell();
//							cellarow.setColspan(5);
//							cellarow.setPhrase(blank6);
//							cellarow.setBorder(Rectangle.NO_BORDER);
//							cellarow.setPadding(2f);
//							cellarow.setPaddingBottom(7.4f);
//							cellarow.setHorizontalAlignment(Element.ALIGN_CENTER);
//							tabledata41_DSTSC.addCell(cellarow);
//						}
//						
						
						Paragraph ser_no = new Paragraph(l.get(0), fontTableHeadingdata);
						 celle_fl = new PdfPCell(ser_no);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						 celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						 celle_fl.setPadding(3);
						 if (i % 2 == 0) {
								celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						 tabledata81.addCell(celle_fl);
						 
						 
						Paragraph ic_number = new Paragraph(l.get(1), fontTableHeadingdata);
						celle_fl = new PdfPCell(ic_number);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata81.addCell(celle_fl);
						
						
						Paragraph rank = new Paragraph(l.get(2), fontTableHeadingdata);
						celle_fl = new PdfPCell(rank);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata81.addCell(celle_fl);
						
						
						Paragraph pers_name = new Paragraph(l.get(3), fontTableHeadingdata);
						celle_fl = new PdfPCell(pers_name);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata81.addCell(celle_fl);
						
						
						Paragraph arm1 = new Paragraph(l.get(4), fontTableHeadingdata);
						celle_fl = new PdfPCell(arm1);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata81.addCell(celle_fl);
							
						Paragraph blank5 = new Paragraph(l.get(5), fontTableHeadingdata);
						celle_fl = new PdfPCell(blank5);
						 celle_fl.setBorder(Rectangle.NO_BORDER);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tabledata81.addCell(celle_fl);
							
						
					 
						
					}
				 
				if(flag_first_page_WithDrawal==((flag_first_page_fix_WithDrawal-flag_first_page_fix_WithDrawal)+1)){
					tabledata812.addCell(tabledata81);
					 tabledata81 = new PdfPTable(6);

					tabledata81.setWidths(new int[] { 3, 5, 3, 9, 4, 5 });
					tabledata81.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata81.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
					tabledata81.setWidthPercentage(100);
					tabledata81.getDefaultCell().setBorder(Rectangle.BOTTOM);

 				 
					tabledata81.addCell(a8);
					tabledata81.addCell(b8);
					tabledata81.addCell(c8);
					tabledata81.addCell(d8);
					tabledata81.addCell(e8);
					tabledata81.addCell(f8);

				}
				 
				if(getWithDrawalsDSSC.size() == (i+1) & flag_first_page_WithDrawal > (flag_first_page_fix_WithDrawal-flag_first_page_fix_WithDrawal) & flag_first_page_WithDrawal < ((flag_first_page_fix_WithDrawal)+1)){
				
					tabledata812.addCell(tabledata81);
					 tabledata81 = new PdfPTable(6);

						tabledata81.setWidths(new int[] { 3, 5, 3, 9, 4, 5 });
						tabledata81.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						tabledata81.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
						tabledata81.setWidthPercentage(100);
						tabledata81.getDefaultCell().setBorder(Rectangle.BOTTOM);

	 				 
						tabledata81.addCell(a8);
						tabledata81.addCell(b8);
						tabledata81.addCell(c8);
						tabledata81.addCell(d8);
						tabledata81.addCell(e8);
						tabledata81.addCell(f8);
				}			
				flag_first_page_WithDrawal -= 1;
				if(flag_first_page_WithDrawal == 0) {
					flag_first_page_fix_WithDrawal = 50;
					flag_first_page_WithDrawal = flag_first_page_fix_WithDrawal;				
				}
			}
		
		
		
		
		
		
		
		 
		
		table8.setSplitLate(false);
		
		PdfPCell cell1235_8;
		cell1235_8 = new PdfPCell();
 
		cell1235_8.addElement(tabledata8);
		cell1235_8.addElement(tableheader8);
 
		cell1235_8.setBorder(Rectangle.NO_BORDER);
 
		table8.addCell(cell1235_8);
		
		 
		PdfPCell cell12356_f8 ;
		cell12356_f8 = new PdfPCell();
		 
		cell12356_f8.setBorder(Rectangle.NO_BORDER);
	
		cell12356_f8.addElement(tabledata812);
		 
		table8.addCell(cell12356_f8);
		
		
//
//		PdfPCell cell1235_8;
//		cell1235_8 = new PdfPCell();
//		cell1235_8.addElement(tabledata8);
//		cell1235_8.addElement(tableheader8);
//		cell1235_8.addElement(tabledata81);
//
//		cell1235_8.setBorder(0);
//		cell1235_8.setPaddingLeft(30f);
//		cell1235_8.setPaddingRight(30f);
//		table8.addCell(cell1235_8);
//		
		
		
//		===================================================================================

		PageNumeration event = new PageNumeration(arg2);
		arg2.setPageEvent(event);
		document.setPageCount(1);

		document.add(table_m1);

		document.add(table_c2);
		document.add(table_c3);

		table.setTableEvent(new ImageBackgroundEvent("table", ""));
		document.add(table);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table1.setTableEvent(new ImageBackgroundEvent("table1", ""));
		document.add(table1);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table4.setTableEvent(new ImageBackgroundEvent("table4", ""));
		document.add(table4);

//		document.setPageSize(two);
//		document.setMargins(20, 20, 20, 20);
//		document.newPage();
//		table4_4.setTableEvent(new ImageBackgroundEvent("table4_4", ""));
//		document.add(table4_4);
		
		
		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table5_2.setTableEvent(new ImageBackgroundEvent("table5_2", ""));
		document.add(table5_2);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table5.setTableEvent(new ImageBackgroundEvent("table5", ""));
		document.add(table5);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table4_4.setTableEvent(new ImageBackgroundEvent("table4_4", ""));
		document.add(table4_4);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table6.setTableEvent(new ImageBackgroundEvent("table6", ""));
		document.add(table6);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table7.setTableEvent(new ImageBackgroundEvent("table7", ""));
		document.add(table7);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table8.setTableEvent(new ImageBackgroundEvent("table8", ""));
		document.add(table8);

		// ============Index-page1=======================//
		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		PdfPTable table_m2 = new PdfPTable(1);
		table_m2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_m2.setWidthPercentage(100);

		Chunk underline_m11 = new Chunk("INDEX \n", fontTableHeading2);

		underline_m11.setUnderline(0.1f, -2f);
		Phrase ph_m51 = new Phrase(underline_m11);
		ph_m51.setFont(fontTableHeading2);
		Paragraph cell_Mr_I = new Paragraph(ph_m51);
		cell_Mr_I.setAlignment(Element.ALIGN_CENTER);

		PdfPTable table153 = new PdfPTable(4);
		table153.setWidths(new int[] { 20, 80, 20, 20 });
		table153.getDefaultCell().setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
		table153.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		table153.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table153.setWidthPercentage(100);
		table153.setSpacingBefore(5);

		table153.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		table153.addCell("Ser No \n");
		table153.addCell("	");

		table153.getDefaultCell().setColspan(2);
		table153.addCell("Page No");
		table153.getDefaultCell().setColspan(1);

		table153.addCell("");
		table153.addCell("");
		table153.addCell("From");
		table153.addCell("To");

		table153.addCell("1.");
		table153.addCell("General Instruction");
		table153.addCell("1");
		table153.addCell("3");

		table153.addCell("2.");
		table153.addCell("Analysis of Result : Arms/Service wise");
		table153.addCell(String.valueOf(table_from));
		table153.addCell(String.valueOf(table_to));

		table153.addCell("3.");
		table153.addCell("List of Officers in Competitive List");
		table153.addCell(String.valueOf(table_from1));
		table153.addCell(String.valueOf(table_to1));

		table153.addCell("4.");
		table153.addCell("List of Nominated Officers : DSSC");
		table153.addCell(String.valueOf(table_from4));
		table153.addCell(String.valueOf(table_to4));

		table153.addCell("5.");
		table153.addCell("List of Nominated Officers : DSTSC");
		table153.addCell(String.valueOf(table_from_ab));
		table153.addCell(String.valueOf(table_to_ab));

		table153.addCell("6.");
		table153.addCell("Officers in Reserve List");
		table153.addCell(String.valueOf(table_from5));
		table153.addCell(String.valueOf(table_to5));

		table153.addCell("7.");
		table153.addCell("List of Nominated Officers : ALMC/ISC");
		table153.addCell(String.valueOf(table_from4_4));
		table153.addCell(String.valueOf(table_to4_4));
		
		table153.addCell("8.");
		table153.addCell("Marks of Officers Who did not Qualify");
		table153.addCell(String.valueOf(table_from6));
		table153.addCell(String.valueOf(table_to6));
		 

		table153.addCell("9.");
		table153.addCell("List of Absentees");
		table153.addCell(String.valueOf(table_from7));
		table153.addCell(String.valueOf(table_to7));

		table153.addCell("10.");
		table153.addCell("List of Withdrawals");
		table153.addCell(String.valueOf(table_from8));
		table153.addCell(String.valueOf(table_to8));

		PdfPCell cell_i1;
		cell_i1 = new PdfPCell();
		cell_i1.addElement(cell_Mr_I);
		cell_i1.addElement(new Paragraph("\n"));
		cell_i1.addElement(table153);
		cell_i1.setBorder(0);
		cell_i1.setPaddingLeft(30f);
		cell_i1.setPaddingRight(30f);
		table_m2.addCell(cell_i1);

		document.add(table_m2);

		super.buildPdfMetadata(model, document, request);
	}

	public String getSpace(int no) {
		String space = "";
		if (no == 1) {
			space = " ";
		}
		if (no == 2) {
			space = "  ";
		}
		if (no == 3) {
			space = "   ";
		}
		if (no == 4) {
			space = "    ";
		}
		if (no == 5) {
			space = "     ";
		}
		if (no == 6) {
			space = "      ";
		}
		if (no == 7) {
			space = "       ";
		}
		if (no == 8) {
			space = "        ";
		}
		if (no == 9) {
			space = "          ";
		}
		if (no == 10) {
			space = "           ";
		}
		if (no == 11) {
			space = "           ";
		}
		if (no == 12) {
			space = "            ";
		}
		if (no == 13) {
			space = "             ";
		}
		if (no == 14) {
			space = "              ";
		}
		if (no == 15) {
			space = "               ";
		}
		if (no == 16) {
			space = "                ";
		}
		if (no == 17) {
			space = "                 ";
		}
		if (no == 18) {
			space = "                  ";
		}
		if (no == 19) {
			space = "                   ";
		}
		if (no == 20) {
			space = "                    ";
		}
		return space;
	}

	String pagNum = "";

	class PageNumeration extends PdfPageEventHelper {
		PdfTemplate total;
		PdfTemplate total1;
		PdfTemplate footer1;

		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				total1 = writer.getDirectContent().createTemplate(30, 16);
				footer1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {

		}

		public void onEndPage(PdfWriter writer, Document document) {

			Font pgNo = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 0);
			PdfPTable table = new PdfPTable(1);
			try {

				table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

				if ((writer.getPageNumber() - 1) > 0) {
					pagNum = String.valueOf((writer.getPageNumber() - 1));
				}

				PdfPCell cell1 = new PdfPCell(new Paragraph(pagNum, pgNo));
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_TOP);
				table.addCell(cell1);

//				PdfPCell cell2 = new PdfPCell(Image.getInstance(footer1));
//				table.addCell(String.format("abndfgsjd"));
//				cell2.setBorder(Rectangle.NO_BORDER);
//				table.addCell(cell2);

				table.writeSelectedRows(0, -1, document.leftMargin() + 260, document.topMargin() + 810,
						writer.getDirectContent());
				Font fontTableHeadingdataforFooter = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 0);
				PdfContentByte cb = writer.getDirectContent();

				table.writeSelectedRows(0, -1, document.leftMargin() + 260, document.topMargin() + 810,
						writer.getDirectContent());

				int ftable_from = table_from4 + 1;
				int ftable_to = table_to4;

				if (page > ftable_from && table_from4 != 0 && ftable_to <= page && table_from_ab < ftable_to) {
					Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
					ColumnText.showTextAligned(cb, Element.ALIGN_LEFT,
							new Phrase(String.format("Appendix 'C' Contd.../- "), fontTableHeadingMainHead_l),
							document.right() - 150, document.top(), 0);
				}
				
				int ftable_from4_2 = table_from_ab + 1;
				int ftable_to4_2 = table_to_ab;

				if (page > ftable_from4_2 && table_from_ab != 0 && ftable_to4_2 <= page && table_from5 < ftable_to) {
					Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
					ColumnText.showTextAligned(cb, Element.ALIGN_LEFT,
							new Phrase(String.format("Appendix 'C' Contd.../- "), fontTableHeadingMainHead_l),
							document.right() - 150, document.top(), 0);
				}
				
				
				int ftable_from5 = table_from5 + 1;
				int ftable_to5 = table_to5;
				
				if (page > ftable_from5 && table_from5 != 0 && ftable_to5 <= page && table_from4_4 < ftable_to5) {
					Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
					ColumnText.showTextAligned(cb, Element.ALIGN_LEFT,
							new Phrase(String.format("Appendix 'D' Contd.../- "), fontTableHeadingMainHead_l),
							document.right() - 150, document.top()-5, 0);
				}
				
				
				int ftable_from4_4 = table_from4_4 + 1;
				int ftable_to4_4 = table_to4_4;
				
				if (page > ftable_from4_4 && table_from4_4 != 0 && ftable_to4_4 <= page && table_from6 < ftable_to4_4) {
					Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
					ColumnText.showTextAligned(cb, Element.ALIGN_LEFT,
							new Phrase(String.format("Appendix 'E' Contd.../- "), fontTableHeadingMainHead_l),
							document.right() - 150, document.top(), 0);
				}
				
				
				int ftable_from7 = table_from6 + 1;
				int ftable_to7 = table_to6;
				
				if (page > ftable_from7 && table_from6 != 0 && ftable_to7 <= page && table_from7 < ftable_to7) {
					Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
					ColumnText.showTextAligned(cb, Element.ALIGN_LEFT,
							new Phrase(String.format("Appendix 'F' Contd.../- "), fontTableHeadingMainHead_l),
							document.right() - 150, document.top()-20, 0);
				}

//			 if(page >= 4 & page <=5) {
//				 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("Appd : Appeared", writer.getPageNumber()),fontTableHeadingdataforFooter),document.left(),document.bottom(), 0);
//			 }
//
//			 int rtable_from = table_from4+1;
//			 int rtable_to = table_to4;
//			
//			
//			 if(page > rtable_from && table_from4!=0 && rtable_to <= page && table_from6 < rtable_to) {
//			 Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
//			 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("Appendix 'B' Contd. "),fontTableHeadingMainHead_l),document.right()-150,document.top(), 0);
//			 }
			 int ftable_from_Bottom1=table_from4_4+1;
			 int ftable_to_Bottom1 = table_to4_4;
//			 
//			 if(page > ftable_from && table_from6!=0 && ftable_to <= page && table_from5 < ftable_to) {
//				 Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
//				 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("Appendix 'C' Contd. "),fontTableHeadingMainHead_l),document.right()-150,document.top(), 0);
//				 }
//			 
//			 
//			 System.err.println("page==============="+page);
//			 System.err.println("ftable_from  :"+ftable_from_Bottom1   +"ftable_to   :"+ftable_to_Bottom1);
//			 IF(PAGE >= FTABLE_FROM && TABLE_FROM6!=0 && FTABLE_TO <= PAGE && TABLE_FROM5 < FTABLE_TO) {
//				 SYSTEM.ERR.PRINTLN("FTABLE_FROM  :"+FTABLE_FROM);
//				 COLUMNTEXT.SHOWTEXTALIGNED(CB, ELEMENT.ALIGN_LEFT, NEW PHRASE(STRING.FORMAT(" T:TAC  A:ADM    L:LAW    H:MIL HISTORY    C:CURRENT AFFAIRS  S:SPL TO CORPS     NP:NOW PASSED   PP:PREVIOUSLY PASSED    ABS:ABSENT   NA:EXEMPTED" , WRITER.GETPAGENUMBER()),FONTTABLEHEADINGDATAFORFOOTER),DOCUMENT.LEFT(),DOCUMENT.BOTTOM(), 0);
//			 }

			 
			 int ftable_from4_4_1 = table_from4_4;
			 int ftable_to4_4_1 = table_to4_4;
				
				
			 if(page > ftable_from4_4_1 && table_from4_4 != 0 && ftable_to4_4_1 <= page && table_from6 < ftable_to4_4_1) {
//				 SYSTEM.ERR.PRINTLN("FTABLE_FROM  :"+FTABLE_FROM);
				 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format(" I:ISC  A:ALMC" , writer.getPageNumber()),fontTableHeadingdataforFooter),document.left() + 30,document.bottom(), 0);
			 }

			 
//			 int ftable_from5 = table_from5;
//			 int ftable_to5 = table_to5;
			 
			 if(page > ftable_from5 && table_from5 != 0 && ftable_to5 <= page && table_from4_4 < ftable_to5) {
//				 SYSTEM.ERR.PRINTLN("FTABLE_FROM  :"+FTABLE_FROM);
				 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format(" D:DSSC  T:DSTSC" , writer.getPageNumber()),fontTableHeadingdataforFooter),document.left() + 30,document.bottom(), 0);
			 }
				 
				 
//           if(page >= table_from6 & page <=table_to6 ) {
//				 
//				 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("hiiiiii", writer.getPageNumber()),fontTableHeadingdataforFooter),document.left(),document.bottom(), 0);
//			 }
				page++;
				/*
				 * // * if (Integer.parseInt(String.valueOf(writer.getPageNumber())) > 2) {
				 * page++; } //
				 */
			} catch (Exception de) {
				throw new ExceptionConverter(de);
			}
		}

//	public void onCloseDocument(PdfWriter writer, Document document) {
//		
//	}
	}

	int table_from = 0;
	int table_to = 0;

	int table_from1 = 0;
	int table_to1 = 0;

	int table_from3 = 0;
	int table_to3 = 0;

	int table_from4 = 0;
	int table_to4 = 0;
	
	int table_from4_2 = 0;
	int table_to4_2 = 0;
	
	
	int table_from4_4 = 0;
	int table_to4_4 = 0;

	int table_from6 = 0;
	int table_to6 = 0;

	int table_from5 = 0;
	int table_to5 = 0;

	int table_from7 = 0;
	int table_to7 = 0;

	int table_from8 = 0;
	int table_to8 = 0;

	int table_from9 = 0;
	int table_to9 = 0;

	int table_from_ab = 0;
	int table_to_ab = 0;

	class ImageBackgroundEvent implements PdfPTableEvent {
		protected Image image;
		String tableName;
		String val;

		ImageBackgroundEvent(String tableName, String val) {
			this.tableName = tableName;
			this.val = val;
		}

		public void tableLayout(PdfPTable table, float[][] widths, float[] heights, int headerRows, int rowStart,
				PdfContentByte[] canvases) {

			if (tableName.equals("table") && table_from == 0) {
				table_from = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table")) {
				table_to = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table1") && table_from1 == 0) {
				table_from1 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table1")) {
				table_to1 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table3") && table_from3 == 0) {
				table_from3 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table3")) {
				table_to3 = Integer.parseInt(pagNum) + 1;
			}

			 
			if (tableName.equals("table4") && table_from4 == 0) {
				table_from4 = Integer.parseInt(pagNum) + 1;
			}
			 
			if (tableName.equals("table4") && !tableName.equals("table4_4")) {
				table_to4 = Integer.parseInt(pagNum) + 1;
			}
			
			
			if (tableName.equals("table4_2") && table_from4_2 == 0) {
				table_from4_2 = Integer.parseInt(pagNum) + 1;
			}
			 

			if (tableName.equals("table4_2")) {
				table_to4_2 = Integer.parseInt(pagNum) + 1;
			}
			
			
			
			 
			if (tableName.equals("table4_4") && table_from4_4 == 0) {
				table_from4_4 = Integer.parseInt(pagNum) + 1;
			}
			 

			if (tableName.equals("table4_4")) {
				table_to4_4 = Integer.parseInt(pagNum) + 1;
			}
			 
			
			
			
			
			if (tableName.equals("table5") && table_from5 == 0) {
				table_from5 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table5")) {
				table_to5 = Integer.parseInt(pagNum) + 1;
			}
			
			if (tableName.equals("table6") && table_from6 == 0) {
				table_from6 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table6")) {
				table_to6 = Integer.parseInt(pagNum) + 1;
			}

			
			
			
			if (tableName.equals("table7") && table_from7 == 0) {
				table_from7 = Integer.parseInt(pagNum) + 1;
			} 
			if (tableName.equals("table7")) {
				table_to7 = Integer.parseInt(pagNum) + 1;
			} 
			
			if (tableName.equals("table8") && table_from8 == 0) {
				table_from8 = Integer.parseInt(pagNum) + 1;
			}
			 
			if (tableName.equals("table8")) {
				table_to8 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table9") && table_from9 == 0) {
				table_from9 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table9")) {
				table_to9 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table5_2") && table_from_ab == 0) {
				table_from_ab = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table5_2")) {
				table_to_ab = Integer.parseInt(pagNum) + 1;
			}

		}
	}

}
