package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.Indexing.IndexingDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXING_SETTING;
import com.BisagN.models.officers.indexing.INDEX_NO;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MANUAL;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MASTER;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class ManageIndexingController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	CommonController comm;

	@Autowired
	IndexingDAO indxDao;

	@RequestMapping(value = "ManageIndexingUrl", method = RequestMethod.GET)
	public ModelAndView ManageIndexingUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		if (ec_exam_id != 0) {
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());

		}
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
		System.err.println("es_id====="+es_id);
		if (es_id != 0) {
			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, es_id);

			String index_mode= UnlcokExmsch.get(0).getEs_index_mode();
			Date begin_date = UnlcokExmsch.get(0).getEs_begin_date();
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

			int day = date.getDayOfMonth();
			String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

			String[] shortMonths = new DateFormatSymbols().getShortMonths();
			for (String shortMonth : shortMonths) {

			}

			Month month = date.getMonth();
			int year = date.getYear();
			String begindateShow = day + " " + month + " " + year;

			Mmap.put("begindateShow", begindateShow);
			Mmap.put("index_mode", index_mode);
			Mmap.put("es_id", es_id);
			
			List<INDEXING_SETTING> bundledetails = comm.getbundledetailsforindexing(sessionFactory, es_id);
				
				Mmap.put("getIndexSettingDetails", bundledetails);
				
				List<OFFICER_APPLICATION_M>CheckREgisterDataUpload=comm.getOappIdbyEsID(sessionFactory, es_id);
				int oa_center_granted=CheckREgisterDataUpload.get(0).getOa_center_granted();
				Mmap.put("oa_center_granted", oa_center_granted);

		}

	
		Mmap.put("msg", msg);
		return new ModelAndView("ManageIndexingTiles");
	}

	@RequestMapping(value = "/ExamScheduleIndexingTiming", method = RequestMethod.POST)
	public ModelAndView ExamScheduleIndexingTiming(ModelMap Mmap, HttpSession session, HttpServletRequest request,
			String index_mode, String subject_id1,String copies1, String sub_subject_id1) {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		System.err.println("sub_subject_id1============="+sub_subject_id1);
		Date date = new Date();
		
		EXAMSCHEDULE_INDEXING_DETAIL exindx = new EXAMSCHEDULE_INDEXING_DETAIL();

		int es_id = Integer.parseInt(
				session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		List<INDEXING_SETTING> bundledetails = comm.getbundledetailsforindexing(sessionFactory, es_id);
		if (!bundledetails.isEmpty()) {

			if (index_mode.equals("START INDEXING")) {
				exindx.setEsid_createdate(date);
				exindx.setEsid_dtindexdate(date);
			
				exindx.setEsid_es_id(es_id);
				exindx.setEsid_startdatetime(date);
				exindx.setNo_of_copies(Integer.parseInt(copies1));
				exindx.setEsid_sc_subject_id(Integer.parseInt(subject_id1));
				if(Integer.parseInt(sub_subject_id1) != 0){
					exindx.setEsid_sub_subject_id(Integer.parseInt(sub_subject_id1));
					exindx.setEsid_sc_subject_id(0);
				}
				
				sessionHQL.save(exindx);
				Mmap.put("msg", "START INDEXING Successfully");
				EXAMSCHEDULE_INDEXING_DETAIL ewid = (EXAMSCHEDULE_INDEXING_DETAIL) sessionHQL
						.get(EXAMSCHEDULE_INDEXING_DETAIL.class, es_id);
				request.getSession().setAttribute("esid_sc_subject_id", ewid.getEsid_sc_subject_id());
				request.getSession().setAttribute("esid_es_id", ewid.getEsid_es_id());
				request.getSession().setAttribute("esid_sub_subject_id", ewid.getEsid_sub_subject_id());

			}

		
	
	
			if (index_mode.equals("STOP INDEXING")){
			

				String hq15 = "update EXAMSCHEDULE_INDEXING_DETAIL set esid_enddatetime=:esid_enddatetime,esid_updatedate=:esid_updatedate where esid_enddatetime is null ";
				Query query5 = sessionHQL.createQuery(hq15).setParameter("esid_enddatetime", date)
						.setParameter("esid_updatedate", date);
				query5.executeUpdate();

				Mmap.put("msg", "STOP INDEXING Successfully");
				
				
		}

		tx.commit();
		}else {
			
			Mmap.put("msg","Please Enter the  Details in Indexing Setting");
		}
		return new ModelAndView("redirect:ManageIndexingUrl");

	}

	@RequestMapping(value = "/GetSubjectWiseIndexingDetails", method = RequestMethod.POST)
	public @ResponseBody ArrayList<ArrayList<String>> GetSubjectWiseIndexingDetails(int startPage, String pageLength,
			String Search, String orderColunm, String orderType, String sc_subject_id, HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		int es_id = Integer.parseInt(
				sessionUserId.getAttribute("es_id") == null ? "0" : sessionUserId.getAttribute("es_id").toString());
		return indxDao.getSubjectWiseIndxDetails(startPage, pageLength, Search, orderColunm, orderType, es_id,
				sc_subject_id, sessionUserId);
	}

	@RequestMapping(value = "/GetCountSubjectWiseIndexingDetails", method = RequestMethod.POST)
	public @ResponseBody long GetCountSubjectWiseIndexingDetails(HttpSession sessionUserId, String Search,
			String sc_subject_id) {

		int es_id = Integer.parseInt(
				sessionUserId.getAttribute("es_id") == null ? "0" : sessionUserId.getAttribute("es_id").toString());
		return indxDao.getTotalCountSubjectWiseIndxDetails(Search, es_id, sc_subject_id);
	}

	@RequestMapping(value = "/getSubjectWiseIndexing", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getSubjectWiseIndexing(HttpSession session, String sc_subject_id) {

		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		ArrayList<ArrayList<String>> list = indxDao.GetSubjectWiseIndexingDetails(es_id, sc_subject_id);
		return list;

	}
	
	
	@RequestMapping(value = "/getSubSubjectDetails", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getSubSubjectDetails(HttpSession session, String sc_subject_id) {

		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		ArrayList<ArrayList<String>> list = indxDao.getSubSubjectDetails(sc_subject_id);
		return list;

	}

	@RequestMapping(value = "/getStatusForIndexing", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getStatusForIndexing(HttpSession session) {

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		ArrayList<ArrayList<String>> list = indxDao.GetLockUnlockIndexingDetails(es_id);
		return list;

	}

	@RequestMapping(value = "/getSubjectWiseIndexingMode", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getSubjectWiseIndexingMode(HttpSession session, String Subject_id) {

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		ArrayList<ArrayList<String>> list = indxDao.GetSubjectWiseIndexingDetails(es_id, Subject_id);
		return list;

	}
	  @RequestMapping(value = "/ManageIndexngACtion" ,method = RequestMethod.POST) 
	  public ModelAndView PackageAction( @ModelAttribute("ManageIndexCMD") EXAMSCHEDULE_INDEXING_DETAIL ExmSch_index, BindingResult result, 
	  HttpServletRequest request, ModelMap model, HttpSession session){ 
		  Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			try {
				
				
			Date date = new Date();
			String userId = session.getAttribute("userId").toString();
			String subject_id= request.getParameter("sc_subject_id");
			String no_of_copies= request.getParameter("no_of_copies");
			int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		if(esid_es_id != 0) {
		
			  
			
			String hq15 = "update EXAMSCHEDULE_INDEXING_DETAIL set no_of_copies=:no_of_copies,esid_updateby=:esid_updateby,esid_updatedate=:esid_updatedate where esid_es_id=:esid_es_id and esid_sc_subject_id=:esid_sc_subject_id";
			Query query5 = sessionHQL.createQuery(hq15)
					.setParameter("no_of_copies",Integer.parseInt(no_of_copies))
					.setParameter("esid_updateby", Integer.parseInt(userId))
					.setParameter("esid_updatedate", date)
			.setParameter("esid_es_id", esid_es_id)
			.setParameter("esid_sc_subject_id", Integer.parseInt(subject_id));
			query5.executeUpdate();

	
				
				
				model.put("msg","Data Updated Successfully"); 
				 }
			
				   
			tx.commit();
	 
			} 
		
			
			catch (RuntimeException e) {
				try {
					tx.rollback();
					model.put("msg", "roll back transaction");
				} catch (RuntimeException rbe) {
					model.put("msg", "Couldn�t roll back transaction " + rbe);
				}
				throw e;
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}

			return new ModelAndView("redirect:ManageIndexingUrl"); 
			}
}
