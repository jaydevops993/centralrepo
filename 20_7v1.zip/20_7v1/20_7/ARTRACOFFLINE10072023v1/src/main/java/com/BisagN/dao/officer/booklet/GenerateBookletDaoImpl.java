package com.BisagN.dao.officer.booklet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class GenerateBookletDaoImpl implements GenerateBookletDao {

	
	@Autowired
    private DataSource dataSource;
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;
	
	public ArrayList<ArrayList<String>> getResultStatusForExamSchedule(String es_id) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		String whr = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			
			
			q="select count(*) as num from tb_partpass_fullpass_dtl where es_id=?  ";
			
			stmt = conn.prepareStatement(q);
			
			if(!es_id.equals("")) {
			stmt.setInt(1, Integer.parseInt(es_id));
			
			}
		
			
			ResultSet rs = stmt.executeQuery();
			
		
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("num"));//1
			
				
				alist.add(list);
				
				
			}

			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

}
