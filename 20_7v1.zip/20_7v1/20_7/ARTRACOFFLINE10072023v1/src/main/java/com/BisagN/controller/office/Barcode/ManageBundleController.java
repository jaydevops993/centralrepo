package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.Indexing.IndexingDAO;
import com.BisagN.dao.Indexing.ManageBundleDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_DETAILS;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_MASTER;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_DETAILS;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_MASTER;
import com.BisagN.models.officers.indexing.INDEXING_SETTING;
import com.BisagN.models.officers.indexing.KITBAGMASTER;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class ManageBundleController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	CommonController comm;

	@Autowired
	ManageBundleDAO MbindxDao;

	@RequestMapping(value = "ManageBundleDetails_Url", method = RequestMethod.GET)
	public ModelAndView ManageBundleDetails_Url(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		if (es_id != 0) {

			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, es_id);
			String index_mode = UnlcokExmsch.get(0).getEs_index_mode();
			Mmap.put("index_mode", index_mode);
			Mmap.put("es_id", es_id);

		}
		int esid_es_id = Integer.parseInt(
				session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		if (esid_es_id != 0) {
			List<EXAMSCHEDULE_INDEXING_DETAIL> UnlcokExmsch = comm.getActiveIndxSubject(sessionFactory, esid_es_id);
			if(!UnlcokExmsch.isEmpty()) {
			int indx_esid = UnlcokExmsch.get(0).getEsid_es_id();
			List<EXAM_SCHEDULE> getbegindate = comm.getUnlockExamSchedule(sessionFactory, es_id);
			
			Date begin_date= getbegindate.get(0).getEs_begin_date();
			System.err.println("begin_date=-============"+begin_date);
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			List<INDEXING_SETTING> bundledetails = comm.getbundledetailsforindexing(sessionFactory, esid_es_id);
			
			int booklet_no=bundledetails.get(0).getIst_maxab_bundle();
			Mmap.put("booklet_no", booklet_no);
			
			
			int day = date.getDayOfMonth();
			String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

			String[] shortMonths = new DateFormatSymbols().getShortMonths();
			

			Month month = date.getMonth();
			int year = date.getYear();
			String begindateShow = day + " " + month + " " + year;

			Mmap.put("begindateShow", begindateShow);

			Mmap.put("esid_es_id", esid_es_id);

			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
					: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
			if (esid_sc_subject_id != 0) {
				List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
				Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
				Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());

				List<SUBJECT_CODE_M> ActiveSubName = comm.getsubjectIdbysubname(sessionFactory, esid_sc_subject_id,
						ec_exam_id);

				Mmap.put("ActiveSub", ActiveSubName.get(0).getSc_subject_name());

			
			Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL(sessionFactory));
			Mmap.put("msg", msg);
		}
			
			int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
			
			System.err.println("esid_sub_subject_id==========="+esid_sub_subject_id);
			if (esid_sub_subject_id != 0) {
				List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
				String sub_subject_name=SubSubject.get(0).getSub_subject();
				Mmap.put("sub_subject_name", sub_subject_name);
			}
			System.err.println("esid_sub_subject_id========="+esid_sub_subject_id);
			}	
		}
		return new ModelAndView("ManageBundleTiles");

	}

	@RequestMapping(value = "/GetBundleDetails", method = RequestMethod.POST)
	public @ResponseBody ArrayList<ArrayList<String>> GetBundleDetails(int startPage, String pageLength, String Search,
			String orderColunm, String orderType, String sc_subject_id, HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		int esid_es_id = Integer.parseInt(sessionUserId.getAttribute("esid_es_id") == null ? "0"
				: sessionUserId.getAttribute("esid_es_id").toString());
		
		String userId = sessionUserId.getAttribute("userId").toString();
		String role = sessionUserId.getAttribute("role").toString();
		

		if (esid_es_id != 0) {
			int esid_sc_subject_id = sessionUserId.getAttribute("esid_sc_subject_id") == null ? 0
					: Integer.parseInt(sessionUserId.getAttribute("esid_sc_subject_id").toString());
			int esid_sub_subject_id = sessionUserId.getAttribute("esid_sub_subject_id") == null ? 0
					: Integer.parseInt(sessionUserId.getAttribute("esid_sub_subject_id").toString());
			return MbindxDao.getManageBundleDetails(startPage, pageLength, Search, orderColunm, orderType, esid_es_id,
			
					esid_sc_subject_id,esid_sub_subject_id,userId,role, sessionUserId);
		}
		return null;
	}

	@RequestMapping(value = "/GetCountBundleDetails", method = RequestMethod.POST)
	public @ResponseBody long GetCountBundleDetails(HttpSession sessionUserId, String Search, String sc_subject_id) {

		int esid_es_id = Integer.parseInt(sessionUserId.getAttribute("esid_es_id") == null ? "0"
				: sessionUserId.getAttribute("esid_es_id").toString());
		String userId = sessionUserId.getAttribute("userId").toString();
		String role = sessionUserId.getAttribute("role").toString();
		if (esid_es_id != 0) {
			int esid_sc_subject_id = sessionUserId.getAttribute("esid_sc_subject_id") == null ? 0
					: Integer.parseInt(sessionUserId.getAttribute("esid_sc_subject_id").toString());
			int esid_sub_subject_id = sessionUserId.getAttribute("esid_sub_subject_id") == null ? 0
					: Integer.parseInt(sessionUserId.getAttribute("esid_sub_subject_id").toString());
			
			
			
			return MbindxDao.getTotalCountgetManageBundleDetails(Search, esid_es_id, esid_sc_subject_id,esid_sub_subject_id,userId,role);
		}
		return 0;
	}

	@RequestMapping(value = "/ManageBundleACtion", method = RequestMethod.POST)
	public ModelAndView ManageBundleACtion(@ModelAttribute("ManageBundleCMD") INDEXED_BUNDLE_MASTER indx_bundle,
			BindingResult result, HttpServletRequest request, ModelMap Mmap, HttpSession session) {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		try {

			String userId = session.getAttribute("userId").toString();
			Date date = new Date();

			int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
			String role = session.getAttribute("role").toString();
			String id = request.getParameter("id");
			
			List<INDEXING_SETTING> bundledetails = comm.getbundledetailsforindexing(sessionFactory, esid_es_id);
			int bundlepacking_size = bundledetails.get(0).getIst_max_bundle();
			String abCount = request.getParameter("ibm_abcount");
			
			String abCount_hid = request.getParameter("ibm_abcount_hid");
			int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());

			
			int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());

			
			Query q0 = sessionHQL
					.createQuery("select count(*) from INDEXED_BUNDLE_MASTER  where ibm_es_id=:ibm_es_id and ibm_nsubjectid=:ibm_nsubjectid");
			q0.setParameter("ibm_es_id", esid_es_id);
			q0.setParameter("ibm_nsubjectid", esid_sc_subject_id);
			Long c = (Long) q0.uniqueResult();
			if(Integer.parseInt(id) == 0) {

				if (c == 0) {

					Session sessionHQL23 = this.sessionFactory.openSession();
					Transaction tx23 = sessionHQL23.beginTransaction();
					
					indx_bundle.setIbm_abcount(Integer.parseInt(abCount_hid));
					indx_bundle.setIbm_nsubjectid(esid_sc_subject_id);
					indx_bundle.setIbm_bundle_no("1");
					indx_bundle.setIbm_bundle_prefix("A");
					indx_bundle.setIbm_es_id(esid_es_id);
					indx_bundle.setIbm_iu_user_id(Integer.parseInt(userId));
					indx_bundle.setIbm_masterab_status_id(0);
					indx_bundle.setIbm_exmsheet_status_id(0);
					indx_bundle.setIbm_status_id(1);
					indx_bundle.setIbm_sub_subject_id(esid_sub_subject_id);
					int bundle_master_id = (int) sessionHQL.save(indx_bundle);
					

					tx23.commit();

					INDEXED_PACKING_NOTES_MASTER pkm = new INDEXED_PACKING_NOTES_MASTER();
					Session sessionHQL2 = this.sessionFactory.openSession();
					Transaction tx2 = sessionHQL2.beginTransaction();
					pkm.setIpnm_createddate(date);
					pkm.setIpnm_es_id(esid_es_id);
					pkm.setIpnm_bag_no("A");
					pkm.setIpnm_no("1");
					pkm.setIpnm_iu_user_id(Integer.parseInt(userId));
					int packing_master_id = (int) sessionHQL2.save(pkm);
					tx2.commit();

					INDEXED_PACKING_NOTES_DETAILS ipnd = new INDEXED_PACKING_NOTES_DETAILS();
					Session sessionHQL3 = this.sessionFactory.openSession();
					Transaction tx3 = sessionHQL3.beginTransaction();
					ipnd.setIpnd_ibm_id(bundle_master_id);
					ipnd.setIpnd_ipnm_id(packing_master_id);
					sessionHQL3.save(ipnd);
					tx3.commit();
					
					
					KITBAGMASTER kitbag = new KITBAGMASTER();
					Session sessionHQL4 = this.sessionFactory.openSession();
					Transaction tx4 = sessionHQL4.beginTransaction();
					kitbag.setKbm_bagname("A");
					kitbag.setKbm_createdate(date);
					kitbag.setKbm_ipnm_id(packing_master_id);
					kitbag.setKbm_es_id(esid_es_id);
					kitbag.setKbm_iu_user_id(Integer.parseInt(userId));
					kitbag.setKbm_sc_subject_id(esid_sc_subject_id);
					kitbag.setKbm_status(1);
					kitbag.setKbm_sub_subject_id(esid_sub_subject_id);
					sessionHQL4.save(kitbag);
					tx4.commit();
				

					Mmap.put("msg", "Bundle Created Successfully");

				} else {
					
					List<INDEXED_BUNDLE_MASTER>getBundlename=comm.getBundleNameList(sessionFactory, esid_es_id, Integer.parseInt(userId), esid_sc_subject_id);
				
					
				if(getBundlename.isEmpty()) {
					
					
					
					Query q = sessionHQL.createQuery(
							"from INDEXED_BUNDLE_MASTER where ibm_es_id=:ibm_es_id and ibm_nsubjectid=:ibm_nsubjectid order by ibm_id desc ");
					q.setParameter("ibm_es_id", esid_es_id);
					q.setParameter("ibm_nsubjectid", esid_sc_subject_id);
					@SuppressWarnings("unchecked")
					List<INDEXED_BUNDLE_MASTER> list2 = (List<INDEXED_BUNDLE_MASTER>) q.list();
					
					
				if(!list2.isEmpty()) {
					
					List<INDEXED_BUNDLE_MASTER>InactiveBundleprefix=comm.getInactivebundlemsterId(sessionFactory,esid_es_id,esid_sc_subject_id);
					if(InactiveBundleprefix.isEmpty()) {
					String b_prifix = list2.get(0).getIbm_bundle_prefix();
					String b_no = list2.get(0).getIbm_bundle_no();
					
					int new_bagno2= Integer.parseInt(b_no)+1;
					
					List<INDEXED_PACKING_NOTES_MASTER>getPackingnoteId=comm.getBundlePrefixList(sessionFactory, esid_es_id,esid_sc_subject_id);
					int paking_note_master_id= getPackingnoteId.get(0).getIpnm_id();
					
					Session sessionHQL23 = this.sessionFactory.openSession();
					Transaction tx23 = sessionHQL23.beginTransaction();
					
					indx_bundle.setIbm_abcount(Integer.parseInt(abCount_hid));
					indx_bundle.setIbm_nsubjectid(esid_sc_subject_id);
					indx_bundle.setIbm_sub_subject_id(esid_sub_subject_id);
					indx_bundle.setIbm_bundle_no(String.valueOf(new_bagno2));
					indx_bundle.setIbm_bundle_prefix(b_prifix);
					indx_bundle.setIbm_es_id(esid_es_id);
					indx_bundle.setIbm_iu_user_id(Integer.parseInt(userId));
					indx_bundle.setIbm_masterab_status_id(0);
					indx_bundle.setIbm_exmsheet_status_id(0);
					indx_bundle.setIbm_status_id(1);
					int bundle_master_id = (int) sessionHQL.save(indx_bundle);
					
                     tx23.commit();
                     
                     
                     INDEXED_PACKING_NOTES_DETAILS ipnd = new INDEXED_PACKING_NOTES_DETAILS();
	 					Session sessionHQL3 = this.sessionFactory.openSession();
	 					Transaction tx3 = sessionHQL3.beginTransaction();
	 					ipnd.setIpnd_ibm_id(bundle_master_id);
	 					ipnd.setIpnd_ipnm_id(paking_note_master_id);
	 					sessionHQL3.save(ipnd);
	 					tx3.commit();
					
					Mmap.put("msg", "Bundle Created Successfully");
					}else {
					String Inactive_bundleprifix= InactiveBundleprefix.get(0).getIbm_bundle_prefix();	
					String Inactive_bundleno = InactiveBundleprefix.get(0).getIbm_bundle_no();
					int Iactive_bundle_id= InactiveBundleprefix.get(0).getIbm_id();
					List<INDEXED_PACKING_NOTES_MASTER>getPackingnoteId=comm.getBundlePrefixList(sessionFactory, esid_es_id,esid_sc_subject_id);
					int paking_note_master_id= getPackingnoteId.get(0).getIpnm_id();
					
					Session sessionHQL23 = this.sessionFactory.openSession();
					Transaction tx23 = sessionHQL23.beginTransaction();
					
					indx_bundle.setIbm_abcount(Integer.parseInt(abCount_hid));
					indx_bundle.setIbm_nsubjectid(esid_sc_subject_id);
					indx_bundle.setIbm_sub_subject_id(esid_sub_subject_id);
					indx_bundle.setIbm_bundle_no(String.valueOf(Inactive_bundleno));
					indx_bundle.setIbm_bundle_prefix(Inactive_bundleprifix);
					indx_bundle.setIbm_es_id(esid_es_id);
					indx_bundle.setIbm_iu_user_id(Integer.parseInt(userId));
					indx_bundle.setIbm_masterab_status_id(0);
					indx_bundle.setIbm_exmsheet_status_id(0);
					indx_bundle.setIbm_status_id(1);
					int bundle_master_id = (int) sessionHQL.save(indx_bundle);
					
                     tx23.commit();
                     
                     
                     INDEXED_PACKING_NOTES_DETAILS ipnd = new INDEXED_PACKING_NOTES_DETAILS();
	 					Session sessionHQL3 = this.sessionFactory.openSession();
	 					Transaction tx3 = sessionHQL3.beginTransaction();
	 					ipnd.setIpnd_ibm_id(bundle_master_id);
	 					ipnd.setIpnd_ipnm_id(paking_note_master_id);
	 					sessionHQL3.save(ipnd);
	 					tx3.commit();
					
					Mmap.put("msg", "Bundle Created Successfully");
					String mm= MbindxDao.DeleteBundlmaster(Iactive_bundle_id); 
					}
				}else {
					List<INDEXED_PACKING_NOTES_MASTER>lastpackingno=comm.getBundlePrefixList(sessionFactory,esid_es_id,esid_sc_subject_id);
					String lastpackingprefix=lastpackingno.get(0).getIpnm_bag_no();
					char x= lastpackingprefix.charAt(0);
					x+=1;
					if(x != 'I') {
						 
						 String packing_no=Character.toString(x);
						 
							
						 Query q03 = sessionHQL.createQuery("select count(*) from INDEXED_PACKING_NOTES_MASTER where ipnm_bag_no=:ipnm_bag_no and ipnm_es_id=:ipnm_es_id ");

						 q03.setParameter("ipnm_bag_no",packing_no );
						 q03.setParameter("ipnm_es_id", esid_es_id);
					Long c3 = (Long) q03.uniqueResult();
					
					if (c3 == 0  ) {
						
						Session sessionHQL234 = this.sessionFactory.openSession();
						Transaction tx52= sessionHQL234.beginTransaction();
						indx_bundle.setIbm_abcount(Integer.parseInt(abCount_hid));
						indx_bundle.setIbm_nsubjectid(esid_sc_subject_id);
						indx_bundle.setIbm_bundle_no("1");
						indx_bundle.setIbm_sub_subject_id(esid_sub_subject_id);
						indx_bundle.setIbm_bundle_prefix(packing_no);
						indx_bundle.setIbm_es_id(esid_es_id);
						indx_bundle.setIbm_iu_user_id(Integer.parseInt(userId));
						indx_bundle.setIbm_masterab_status_id(0);
						indx_bundle.setIbm_exmsheet_status_id(0);
						indx_bundle.setIbm_status_id(1);
						int bundle_master_id = (int) sessionHQL.save(indx_bundle);
						
						tx52.commit();
						
						
						Session sessionHQL2344 = this.sessionFactory.openSession();
						Transaction tx523= sessionHQL2344.beginTransaction();
						INDEXED_PACKING_NOTES_MASTER index_pack_no = new INDEXED_PACKING_NOTES_MASTER();
						index_pack_no.setIpnm_bag_no(packing_no);
						index_pack_no.setIpnm_createddate(date);
						index_pack_no.setIpnm_es_id(esid_es_id);
						index_pack_no.setIpnm_iu_user_id(Integer.parseInt(userId));
						index_pack_no.setIpnm_no("1");
						int index_pack_id = (int)sessionHQL.save(index_pack_no);
						tx523.commit();
						 
						 
						 
						 
						 INDEXED_PACKING_NOTES_DETAILS ipnd = new INDEXED_PACKING_NOTES_DETAILS();
							Session sessionHQL5 = this.sessionFactory.openSession();
							Transaction tx5 = sessionHQL5.beginTransaction();
							ipnd.setIpnd_ibm_id(bundle_master_id);
							ipnd.setIpnd_ipnm_id(index_pack_id);
							sessionHQL5.save(ipnd);
							tx5.commit();
						
							KITBAGMASTER kitbag = new KITBAGMASTER();
							Session sessionHQL4 = this.sessionFactory.openSession();
							Transaction tx4 = sessionHQL4.beginTransaction();
							kitbag.setKbm_bagname(packing_no);
							kitbag.setKbm_createdate(date);
							kitbag.setKbm_ipnm_id(index_pack_id);
							kitbag.setKbm_es_id(esid_es_id);
							kitbag.setKbm_iu_user_id(Integer.parseInt(userId));
							kitbag.setKbm_sc_subject_id(esid_sc_subject_id);
							kitbag.setKbm_sub_subject_id(esid_sub_subject_id);
							kitbag.setKbm_status(1);
							sessionHQL4.save(ipnd);
							tx4.commit();
							
							Mmap.put("msg", "Bundle Created Successfully");
							
							
					}
					}
					
				}
				}else {
					
					
					List<INDEXED_BUNDLE_MASTER>getBundlenameuserWise=comm.getBundleNameList(sessionFactory, esid_es_id, Integer.parseInt(userId),esid_sc_subject_id);
					int ibm_id=getBundlenameuserWise.get(0).getIbm_id();
					
					 
				
					Query q = sessionHQL.createQuery(
							"from INDEXED_BUNDLE_MASTER where ibm_es_id=:ibm_es_id and ibm_nsubjectid=:ibm_nsubjectid order by ibm_id desc ");
					q.setParameter("ibm_es_id", esid_es_id);
					q.setParameter("ibm_nsubjectid", esid_sc_subject_id);
					@SuppressWarnings("unchecked")
					List<INDEXED_BUNDLE_MASTER> list2 = (List<INDEXED_BUNDLE_MASTER>) q.list();
					
					String b_prifix = list2.get(0).getIbm_bundle_prefix();
					String b_no = list2.get(0).getIbm_bundle_no();
					
					List<INDEXED_PACKING_NOTES_MASTER>getPackingnoteId=comm.getBundlePrefixList(sessionFactory, esid_es_id,esid_sc_subject_id);
					int paking_note_master_id= getPackingnoteId.get(0).getIpnm_id();
					
					
					ArrayList<ArrayList<String>>countslipscan= MbindxDao.getIndxSlipCountByIbm(esid_es_id, ibm_id,  Integer.parseInt(userId),role);
				
				
					if(!countslipscan.isEmpty()) {
					String slip_count=countslipscan.get(0).get(0);
					String ab_count=countslipscan.get(0).get(1);
					String ibm_master_status_id= countslipscan.get(0).get(2);
					String ibm_exm_status_id= countslipscan.get(0).get(3);
					
					System.err.println("ibm_master_status_id=============="+ibm_master_status_id);
					System.err.println("ibm_exm_status_id=============="+ibm_exm_status_id);
					
					if(ibm_master_status_id.equals("m_ablist") && ibm_exm_status_id.equals("exm_sheet")) {
					if(Integer.parseInt(slip_count)== Integer.parseInt(ab_count)) {
						
					int new_bagno= Integer.parseInt(b_no)+1;
					
					if(bundlepacking_size >= new_bagno ) {

					Session sessionHQL23 = this.sessionFactory.openSession();
					Transaction tx23 = sessionHQL23.beginTransaction();
					indx_bundle.setIbm_abcount(Integer.parseInt(abCount_hid));
					indx_bundle.setIbm_nsubjectid(esid_sc_subject_id);
					indx_bundle.setIbm_sub_subject_id(esid_sub_subject_id);
					indx_bundle.setIbm_bundle_no(String.valueOf(new_bagno));
					indx_bundle.setIbm_bundle_prefix(b_prifix);
					indx_bundle.setIbm_es_id(esid_es_id);
					indx_bundle.setIbm_iu_user_id(Integer.parseInt(userId));
					indx_bundle.setIbm_masterab_status_id(0);
					indx_bundle.setIbm_exmsheet_status_id(0);
					indx_bundle.setIbm_status_id(1);
					int bundle_master_id = (int) sessionHQL.save(indx_bundle);
					

					tx23.commit();
					
					
					INDEXED_PACKING_NOTES_DETAILS ipnd = new INDEXED_PACKING_NOTES_DETAILS();
					Session sessionHQL3 = this.sessionFactory.openSession();
					Transaction tx3 = sessionHQL3.beginTransaction();
					ipnd.setIpnd_ibm_id(bundle_master_id);
					
					ipnd.setIpnd_ipnm_id(paking_note_master_id);
					sessionHQL3.save(ipnd);
					tx3.commit();
					
					Mmap.put("msg", "Bundle Created Successfully");
					
					}
					
					else {
						
						List<INDEXED_PACKING_NOTES_MASTER>lastpackingno=comm.getBundlePrefixList(sessionFactory,esid_es_id,esid_sc_subject_id);
						String lastpackingprefix=lastpackingno.get(0).getIpnm_bag_no();
						char x= lastpackingprefix.charAt(0);
						x+=1;
						if(x != 'I') {
							 
							 String packing_no=Character.toString(x);
							 
								
							 Query q03 = sessionHQL.createQuery("select count(*) from INDEXED_PACKING_NOTES_MASTER where ipnm_bag_no=:ipnm_bag_no and ipnm_es_id=:ipnm_es_id ");

							 q03.setParameter("ipnm_bag_no",packing_no );
							 q03.setParameter("ipnm_es_id", esid_es_id);
						Long c3 = (Long) q03.uniqueResult();
						
						if (c3 == 0  ) {
							
							Session sessionHQL234 = this.sessionFactory.openSession();
							Transaction tx52= sessionHQL234.beginTransaction();
							indx_bundle.setIbm_abcount(Integer.parseInt(abCount_hid));
							indx_bundle.setIbm_nsubjectid(esid_sc_subject_id);
							indx_bundle.setIbm_sub_subject_id(esid_sub_subject_id);
							indx_bundle.setIbm_bundle_no("1");
							indx_bundle.setIbm_bundle_prefix(packing_no);
							indx_bundle.setIbm_es_id(esid_es_id);
							indx_bundle.setIbm_iu_user_id(Integer.parseInt(userId));
							indx_bundle.setIbm_masterab_status_id(0);
							indx_bundle.setIbm_exmsheet_status_id(0);
							indx_bundle.setIbm_status_id(1);
							int bundle_master_id = (int) sessionHQL.save(indx_bundle);
							
							tx52.commit();
							
							
							Session sessionHQL2344 = this.sessionFactory.openSession();
							Transaction tx523= sessionHQL2344.beginTransaction();
							INDEXED_PACKING_NOTES_MASTER index_pack_no = new INDEXED_PACKING_NOTES_MASTER();
							index_pack_no.setIpnm_bag_no(packing_no);
							index_pack_no.setIpnm_createddate(date);
							index_pack_no.setIpnm_es_id(esid_es_id);
							index_pack_no.setIpnm_iu_user_id(Integer.parseInt(userId));
							index_pack_no.setIpnm_no("1");
							int index_pack_id = (int)sessionHQL.save(index_pack_no);
							tx523.commit();
							 
							 
							 
							 
							 INDEXED_PACKING_NOTES_DETAILS ipnd = new INDEXED_PACKING_NOTES_DETAILS();
								Session sessionHQL5 = this.sessionFactory.openSession();
								Transaction tx5 = sessionHQL5.beginTransaction();
								ipnd.setIpnd_ibm_id(bundle_master_id);
								ipnd.setIpnd_ipnm_id(index_pack_id);
								sessionHQL5.save(ipnd);
								tx5.commit();
							
								KITBAGMASTER kitbag = new KITBAGMASTER();
								Session sessionHQL4 = this.sessionFactory.openSession();
								Transaction tx4 = sessionHQL4.beginTransaction();
								kitbag.setKbm_bagname(packing_no);
								kitbag.setKbm_createdate(date);
								kitbag.setKbm_ipnm_id(index_pack_id);
								kitbag.setKbm_es_id(esid_es_id);
								kitbag.setKbm_iu_user_id(Integer.parseInt(userId));
								kitbag.setKbm_sc_subject_id(esid_sc_subject_id);
								kitbag.setKbm_sub_subject_id(esid_sub_subject_id);
								kitbag.setKbm_status(1);
								sessionHQL4.save(ipnd);
								tx4.commit();
								
								Mmap.put("msg", "Bundle Created Successfully");
								
								
						}
						}
						
					}
					
					}else {
						Mmap.put("msg", "Please Scan all  Answerbook ");
						
					
					}
					}else {
						Mmap.put("msg", "Please Print the Master AB List and Examiner Sheet for the Previous Bundle ");
					}
					
					}else {
						
						Mmap.put("msg", "Please Scan all  Answerbook ");
					}
					
				}
				
				
				}
				
}else {
					
	
	ArrayList<ArrayList<String>>countslipscan= MbindxDao.getIndxSlipCountByIbm(esid_es_id, Integer.parseInt(id),  Integer.parseInt(userId),role);
	
	if(!countslipscan.isEmpty()) { 
		
		String slip_count=countslipscan.get(0).get(0);
 	
		if ( Integer.parseInt(slip_count) <  Integer.parseInt(abCount) || Integer.parseInt(slip_count) ==  Integer.parseInt(abCount)) {
			
		
	
					String hql = "update INDEXED_BUNDLE_MASTER set ibm_abcount=:ibm_abcount,ibm_updatedby=:ibm_updatedby  where ibm_id=:ibm_id ";
					Query query = sessionHQL.createQuery(hql).setInteger("ibm_abcount", Integer.parseInt(abCount))
							.setInteger("ibm_updatedby", Integer.parseInt(userId))
							
							.setInteger("ibm_id",Integer.parseInt(id));
					query.executeUpdate();
					
					
					Mmap.put("msg","Data Updated Successfully"); 
					
		}
		else {
			Mmap.put("msg","Data Not Updated"); 
		}
					
	}else {
		Mmap.put("msg","Data Not Updated"); 
	}
					
				}
			tx.commit();
		} catch (RuntimeException e) {
			try {
				tx.rollback();
				Mmap.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				Mmap.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return new ModelAndView("redirect:ManageBundleDetails_Url");
	}

	@RequestMapping(value = "/getfirstbudlebyEsId", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> getfirstbudlebyEsId(String es_id) {

		ArrayList<ArrayList<String>> list = MbindxDao.GetFirstBundleByEsId(es_id);
		return list;

	}
	
	
	
	  @RequestMapping(value = "/deletecommand_ManageBundle", method = RequestMethod.POST) 
	  public ModelAndView deletecommand_ManageBundle (
			  @RequestParam(value = "msg", required = false) String msg,
	  String deleteid,String deleteidibm_abcount,HttpSession sessionUserId,HttpSession session,ModelMap model) { 
	  	List<String> list = new ArrayList<String>(); 
	  	
		String role = sessionUserId.getAttribute("role").toString();
		
	  	String userId = session.getAttribute("userId").toString();
	  	
	  	int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		
	  	int ibm_id= Integer.parseInt(deleteid);
	  	
		ArrayList<ArrayList<String>>countslipscan= MbindxDao.getIndxSlipCountByIbm(esid_es_id, ibm_id,  Integer.parseInt(userId),role);
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		
		if(countslipscan.isEmpty()) { 
			
			
			String hql = "update INDEXED_BUNDLE_MASTER set ibm_status_id=:ibm_status_id  where ibm_id=:ibm_id ";
			Query query = sessionHQL.createQuery(hql)
					.setInteger("ibm_status_id", 0)
					
					.setInteger("ibm_id",Integer.parseInt(deleteid));
			query.executeUpdate();
			tx.commit();
			model.put("msg","Deleted Successfully");
//	  	list.add(MbindxDao.Deletecommand_code_master(deleteid,deleteidibm_abcount)); 
//	  	model.put("msg",list);  
	  	
	  	}else {
	  		model.put("msg","Can't delete as scanned records exist. Pl contact admin, If you want to delete");  
	  	}
		return new ModelAndView("redirect:ManageBundleDetails_Url"); 
	  }
}
