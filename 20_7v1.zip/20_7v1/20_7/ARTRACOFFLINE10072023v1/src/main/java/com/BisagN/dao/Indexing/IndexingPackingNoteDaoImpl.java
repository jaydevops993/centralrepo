package com.BisagN.dao.Indexing;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class IndexingPackingNoteDaoImpl implements IndexingPackingNoteDAO  {
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	public ArrayList<ArrayList<String>> GetPackingnoteDetailsSubwise(int indx_esId, int  subject_id,int esid_sub_subject_id) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
		
		
		
			String q = "select DISTINCT  ipnm.ipnm_bag_no,ipnm.ipnm_id ,ipnm.ipnm_status_id from indexed_packing_notes_master ipnm\n"
					+ "inner join indexed_packing_notes_details ipnd on ipnd.ipnd_ipnm_id=ipnm.ipnm_id\n"
					+ "inner join indexed_bundle_master ibm on ipnd.ipnd_ibm_id=ibm.ibm_id\n"
					+ "where ipnm.ipnm_es_id=? and ibm.ibm_nsubjectid=?  and ipnm_status_id=0 and ipnm.ipnm_final_status_id=0  \n"
					+ "\n"
					+ "";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, indx_esId);
			stmt.setInt(2, subject_id);
		
System.err.println("pakkkk================="+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ipnm_bag_no"));//0
				list.add(rs.getString("ipnm_id"));//0
				list.add(rs.getString("ipnm_status_id"));//0
			
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	public ArrayList<ArrayList<String>> GetpackedPackingnoteDetailsSubwise(int indx_esId, int subject_id,int esid_sub_subject_id,String packed_status) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q1="";
			String q2="";
			
		
          
//          if(esid_sub_subject_id != 0) {
//  			q2+="and ibm.ibm_sub_subject_id=?";
//  			
//  		}
//		if(subject_id != 0) {
//			q2+="and ibm.ibm_nsubjectid=?";
//			
//		}
		
		
			String q = "select DISTINCT  ipnm.ipnm_bag_no,ipnm.ipnm_id ,ipnm.ipnm_status_id from indexed_packing_notes_master ipnm\n"
					+ "inner join indexed_packing_notes_details ipnd on ipnd.ipnd_ipnm_id=ipnm.ipnm_id\n"
//					+ "inner join indexed_bundle_master ibm on ipnd.ipnd_ibm_id=ibm.ibm_id\n"
					+ "where ipnm.ipnm_es_id=? or ipnm_status_id=1  and ipnm.ipnm_final_status_id=0 "+q1+"  "+q2+" \n"
					+ "\n"
					+ "";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, indx_esId);
//			if(subject_id != 0) {
//			stmt.setInt(2,subject_id);
//			}
//			if(esid_sub_subject_id != 0) {
//				stmt.setInt(3, esid_sub_subject_id);
//			}
			ResultSet rs = stmt.executeQuery();
			
			System.err.println("stmt=============="+stmt);
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ipnm_bag_no"));//0
				list.add(rs.getString("ipnm_id"));//0
				list.add(rs.getString("ipnm_status_id"));//0
			
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	
	public ArrayList<ArrayList<String>> GetUnpackedPackingnoteDetailsSubwise(int indx_esId, int subject_id,int esid_sub_subject_id,String packed_status) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q1="";
			String q2="";
			
		
          
//          if(esid_sub_subject_id != 0) {
//  			q2+="and ibm.ibm_sub_subject_id=?";
//  			
//  		}
//		if(subject_id != 0) {
//			q2+="and ibm.ibm_nsubjectid=?";
//			
//		}
		
		
			String q = "select DISTINCT  ipnm.ipnm_bag_no,ipnm.ipnm_id ,ipnm.ipnm_status_id from indexed_packing_notes_master ipnm\n"
					+ "inner join indexed_packing_notes_details ipnd on ipnd.ipnd_ipnm_id=ipnm.ipnm_id\n"
//					+ "inner join indexed_bundle_master ibm on ipnd.ipnd_ibm_id=ibm.ibm_id\n"
					+ "where ipnm.ipnm_es_id=? and ipnm.ipnm_status_id=0   and ipnm.ipnm_final_status_id=0 "+q1+"  "+q2+" \n"
					+ "\n"
					+ "";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, indx_esId);
//			if(subject_id != 0) {
//			stmt.setInt(2,subject_id);
//			}
//			if(esid_sub_subject_id != 0) {
//				stmt.setInt(3, esid_sub_subject_id);
//			}
			ResultSet rs = stmt.executeQuery();
			
			System.err.println("stmt=============="+stmt);
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ipnm_bag_no"));//0
				list.add(rs.getString("ipnm_id"));//0
				list.add(rs.getString("ipnm_status_id"));//0
			
				alist.add(list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	public ArrayList<ArrayList<String>> GetBundleListByPackingNote(int indx_esId, String packing_note_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select DISTINCT  ipnd.ipnd_ibm_id, ibm.ibm_bundle_prefix,ibm.ibm_bundle_no,ibm.ibm_abcount,count(ismn.is_id) as total_candidate,\n"
					+ "sum(ismn.is_abs)as total_ab,ibm.ibm_masterab_status_id,ibm.ibm_exmsheet_status_id\n"
					+ "from indexed_packing_notes_master ipnm\n"
					+ "inner join indexed_packing_notes_details ipnd on ipnd.ipnd_ipnm_id=ipnm.ipnm_id\n"
					+ "inner join indexed_bundle_master ibm on ipnd.ipnd_ibm_id=ibm.ibm_id\n"
					+ "inner join index_slip_manual ismn on ismn.is_ibm_id=ibm.ibm_id \n"
					+ "where ipnm.ipnm_es_id=? and ipnm.ipnm_id=? and ipnm.ipnm_final_status_id=0  group by 1,2,3,4,7,8\n";
					
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, indx_esId);
			stmt.setInt(2, Integer.parseInt(packing_note_id));
		
System.err.println("pppppp============"+stmt);
			ResultSet rs = stmt.executeQuery();
			int i=1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(String.valueOf(i));
				list.add(rs.getString("ipnd_ibm_id"));//0
				list.add(rs.getString("ibm_bundle_prefix")+rs.getString("ibm_bundle_no"));//0
				list.add(rs.getString("total_candidate"));//0
				list.add(rs.getString("total_ab"));//0
				list.add(rs.getString("ibm_abcount"));//0
				
				list.add(rs.getString("ibm_bundle_prefix"));//0
				list.add(rs.getString("ibm_masterab_status_id"));//0
				list.add(rs.getString("ibm_exmsheet_status_id"));//0
				alist.add(list);
				i++;
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	public ArrayList<ArrayList<String>> getPackingNoteReportDetails(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,int es_id,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		
		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search,es_id);
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String q1 = "";
		
		
		

		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			 q = "select ipnm.ipnm_id, ipnm.ipnm_bag_no  from indexed_packing_notes_master ipnm where ipnm.ipnm_es_id=? "+q1+"  "+SearchValue+" \n"
					+ "ORDER BY ipnm_id    "+orderType +" limit "  +pageLength+" OFFSET "+startPage;
			
			
			
			
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			
			ResultSet rs = stmt.executeQuery();
			int i=1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(String.valueOf(i));
				list.add(rs.getString("ipnm_bag_no"));//0

				alist.add(list);
				
			i++;
				

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	public long getTotalCountgetPackingNoteReportDetails(String Search,int es_id ) {

		String SearchValue = GenerateQueryWhereClause_SQL(Search,es_id);
	int total = 0;
	String q = null;
	String q1 = "";
	Connection conn = null;
	try {
		


		conn = dataSource.getConnection();
		q ="select count(*) from (select ipnm.ipnm_id, ipnm.ipnm_bag_no  from indexed_packing_notes_master ipnm where ipnm.ipnm_es_id=? ORDER BY ipnm_id asc "  +SearchValue +"   ) ab " ;
		
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereClause_SQL(stmt,Search,es_id);
		stmt.setInt(1, es_id);
		
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search,int es_id) {
		String SearchValue = "";

		try {
		
			
		

			
		
			
			
			if (!Search.equals("")) {
				Search = Search.toLowerCase();
				SearchValue = " and ( ";
				SearchValue += " lower(opc_personal_code) like ?  or lower(opd_officer_name) like ? or lower(ac_arm_description) like ?)";
						
			}
		} catch (Exception e) {
			
		}

		return SearchValue;

	}

	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,int es_id) {
		int flag = 1;
		
	try {
		
		
			
			
		

		if(!Search.equals("")) {
			
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				
			
		}
	}catch (Exception e) {
		
	}
	return stmt;
	}
public ArrayList<ArrayList<String>> GetFinalPackageNameListByEsid(int indx_esId) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select DISTINCT ipnm_bag_no,count(DISTINCT ipnm_bag_no) as bag_count,ipnm_id,eid.no_of_copies,count(ismn.is_id) as total_candidate,sum(ismn.is_abs)as total_ab,"
					+ "count(DISTINCT ibm.ibm_id)filter(where ibm.ibm_es_id=134 ) as bundle_count,ipnm.ipnm_status_id \n"
					+ "from indexed_packing_notes_master ipnm\n"
					+ "inner join indexed_packing_notes_details ipnd on ipnd.ipnd_ipnm_id=ipnm.ipnm_id\n"
					+ "inner join indexed_bundle_master ibm on ipnd.ipnd_ibm_id=ibm.ibm_id\n"
					+ "inner join index_slip_manual ismn on ismn.is_ibm_id=ipnd.ipnd_ibm_id \n"
					+ "inner join examschedule_indexing_detail eid on eid.esid_es_id=ipnm.ipnm_es_id\n"
					+ "where ipnm_es_id=?  group by 1,3,4\n";
					
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, indx_esId);
		
System.err.println("finalpacking============"+stmt);
			ResultSet rs = stmt.executeQuery();
			int i=1;
			int total_can_count_t=0;
			int total_ab_count_t=0;
			int total_bundle_count_t=0;
			int total_bag_count_t=0;
			int total_no_copies=0;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(String.valueOf(i));
				list.add(rs.getString("ipnm_bag_no"));//0
				list.add(rs.getString("bag_count"));//0
//				list.add(rs.getString("bundle_count"));//0
				list.add(rs.getString("no_of_copies"));//0
				list.add(rs.getString("total_candidate"));//0
				list.add(rs.getString("total_ab"));//0
				list.add(rs.getString("ipnm_status_id"));//0
			
				
				
				
				
				alist.add(list);
				
				
				int total_bundle_count = Integer.parseInt(rs.getString("bundle_count"));
				total_bundle_count_t +=total_bundle_count;
				

				int total_can_count = Integer.parseInt(rs.getString("total_candidate"));
				total_can_count_t +=total_can_count;
				
				

				int total_ab_count = Integer.parseInt(rs.getString("total_ab"));
				total_ab_count_t +=total_ab_count;
				
				

				int total_bag_count = Integer.parseInt(rs.getString("bag_count"));
				total_bag_count_t +=total_bag_count;
				
				System.err.println("total_bundle_count_t=============="+total_bundle_count_t);
				System.err.println("total_can_count_t=============="+total_can_count_t);
				System.err.println("total_ab_count_t=============="+total_ab_count_t);
				total_no_copies=Integer.parseInt(rs.getString("no_of_copies"));

				
				i++;
				
			}	
				ArrayList<String> list = new ArrayList<String>();
				list.add("Total");
//				list.add(String.valueOf(i));
				list.add(String.valueOf(total_bag_count_t));
				list.add(String.valueOf(total_bundle_count_t));
				list.add(String.valueOf(total_no_copies));
				list.add(String.valueOf(total_can_count_t));
				list.add(String.valueOf(total_ab_count_t));
				
				
				alist.add(list);
				
				
				
				rs.close();
				stmt.close();
				conn.close();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}



}
