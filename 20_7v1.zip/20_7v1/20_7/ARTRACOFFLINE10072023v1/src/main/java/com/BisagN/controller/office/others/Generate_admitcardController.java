package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.office.Generalreports.Attempts_in_Exam;
import com.BisagN.controller.office.Generalreports.Unfair_Means;
import com.BisagN.controller.office.Generalreports.Waivers_Compensatory_Chance;
import com.BisagN.dao.officer.others.AdmitcardDao;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Generate_admitcardController {
	
	@Autowired
	private PartB_ExaminationDAO partbDAO;
	
	
	@Autowired
	AdmitcardDao admDao;
		
	@RequestMapping(value = "/Generate_admitcardUrl", method = RequestMethod.GET)
    public ModelAndView Generate_admitcardUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) 
   		 throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

		String es_begindate = session.getAttribute("es_begin_date") == null ? "": session.getAttribute("es_begin_date").toString();		
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		if (ec_exam_id == 3) {
			if (!es_begindate.equals("")) {
				Mmap.put("dssc_begindate", es_begindate.substring(0, 10));
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
			if (ec_exam_id != 0) {
				Mmap.put("ec_exam_id", ec_exam_id);
				 ArrayList<ArrayList<String>>list2= partbDAO.getdatafromExaminationCentre(3);
				 System.err.println(list2);
				   Mmap.put("getexamcentrelist",list2);
			}
		}
		Mmap.put("msg",msg);
    return new ModelAndView("Generate_admitcardtiles");
}
	
	@RequestMapping(value = "/getAdmitCardPDF", method = RequestMethod.POST)
	public ModelAndView getAdmitCardPDF(ModelMap Mmap, HttpSession session,  HttpServletRequest request, String typeReport, String reportname1, 
			String opd_personal_name1) {
		try {


			ArrayList<ArrayList<String>>list= admDao.getOfrsAdmitCardDetails(opd_personal_name1);
			System.err.println("list==========="+list);
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (list.size() > 0) {
						
						Mmap.put("admitcardno", list.get(0).get(0));
						Mmap.put("rank", list.get(0).get(1));
						Mmap.put("opdname", list.get(0).get(2));
						Mmap.put("unit", list.get(0).get(3));
						Mmap.put("exmcentre", list.get(0).get(4));
						

						List<String> TH = new ArrayList<String>();


						String Heading = "";
						String username = session.getAttribute("username").toString();

						return new ModelAndView(new AdmitCardPDFController("L", TH, Heading, username));

					}
				}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("PartDReport_tiles");
	}
	
	
	@RequestMapping(value = "/getAdmitcardForDsscOfrs", method = RequestMethod.POST)
	@ResponseBody public  ArrayList<ArrayList<String>> getAdmitcardForDsscOfrs(String opd_personal_code) { 
		
		ArrayList<ArrayList<String>>list2= admDao.getOfrsAdmitCardDetails(opd_personal_code);
	
		System.err.println(list2);
		
	return list2; 
	}
}
