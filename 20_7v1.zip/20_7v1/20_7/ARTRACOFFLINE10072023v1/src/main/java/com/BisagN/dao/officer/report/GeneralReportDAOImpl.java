package com.BisagN.dao.officer.report;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;


@Service
public class GeneralReportDAOImpl implements GeneralReportDao {

	@Autowired
    private DataSource dataSource;
	
	
	CommonController comm = new CommonController();
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	public ArrayList<ArrayList<String>> getComChanceGenReport(String Year,int exam_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";
//	if(!oa_application_id.equals("")) {
//		
//		whr+= "and oapp.oa_application_id=?";
//	}
//		

		try {
			
			
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			
			q="select vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name,vpd.opd_officer_name,pbdch.pcc_granted_year from partbd_compens_chance pbdch\n"
					+ "inner join vw_personal_details vpd on pbdch.opd_personal_id=vpd.opd_personal_id\n"
					+ "where pbdch.pcc_granted_year=? and pbdch.ec_exam_id=? order by vpd.opc_personal_code ";


		
			stmt = conn.prepareStatement(q);
			stmt.setString(1, Year);
			stmt.setInt(2, exam_id);
			
			
			System.err.println("smt====fu===="+stmt);
			ResultSet rs = stmt.executeQuery();
	int i=1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				
				list.add(String.valueOf(i));
				list.add(Data+(rs.getString("opc_suffix_code")));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				
				
				alist.add(list);
				i++;
				//System.err.println("list============"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
public ArrayList<ArrayList<String>> getAttemptInExamReport(int es_year) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";
//	if(!oa_application_id.equals("")) {
//		
//		whr+= "and oapp.oa_application_id=?";
//	}
//		

		try {
			
			
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
		q="select * from (select vpd.opc_personal_code, vpd.opc_suffix_code, vpd.rc_rank_name, vpd.opd_officer_name,\n" + 
				"count(ofa.in_index_id) filter(where  es.ec_exam_id=1 and ofa.in_index_id is not null) as partb_count,\n" + 
				"count(ofa.in_index_id) filter(where  es.ec_exam_id=2 and ofa.in_index_id is not null) as partd_count,\n" + 
				"case when vpd.opd_partb =0 then string_agg(distinct getsubjectnamefromcode(vpd.pbda_sub_code,1),',') filter (where vpd.opd_partb =0)  when \n" + 
				" vpd.opd_partb !=0  then string_agg(distinct getsubjectnamefromcode(vpd.pbda_sub_code,2),',') filter (where vpd.opd_partd =0) else '' end as   yes_topass\n" + 
				"from vw_personal_details vpd\n" + 
				"inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n" + 
				"inner join exam_schedule es on es.es_id = ofa.es_id\n" + 
				"inner join exam_code exm ON exm.ec_exam_id = es.ec_exam_id\n" + 
				"where vpd.opd_status_id=1 and vpd.opd_isactive='yes' \n" + 
				"and  (extract(year FROM es.es_begin_date )::int ) =? \n" + 
				"group by 1,2,3,4,vpd.opd_partb,vpd.opd_partd order by 1 ) s where yes_topass is not null\n" ;
			

		
			stmt = conn.prepareStatement(q);
			
			stmt.setInt(1, es_year);
			System.err.println("smt====fu===="+stmt);
			ResultSet rs = stmt.executeQuery();
	int i=1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				
				list.add(Data+(rs.getString("opc_suffix_code")));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("partb_count"));
				list.add(rs.getString("partd_count"));
				list.add(rs.getString("yes_toPass"));
				
				
				
				
				alist.add(list);
				i++;
				//System.err.println("list============"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
public ArrayList<ArrayList<String>> getUnfairmeansData(String exam_id, int Year) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	String whr = "";
	String whr1 = "";
	String whr2 = "";
//if(!oa_application_id.equals("")) {
//	
//	whr+= "and oapp.oa_application_id=?";
//}
//	

	try {
		
		
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
		
		
		q="select DISTINCT vpd.opc_personal_code, vpd.opc_suffix_code, vpd.opd_officer_name,vpd.rc_rank_name, ufm.um_remarks from vw_personal_details vpd\n"
				+ "inner join officer_application ofa on ofa.opd_personal_id = vpd.opd_personal_id\n"
				+ "inner join unfair_means ufm on ufm.opd_personal_id = ofa.opd_personal_id\n"
				+ "inner join exam_schedule esd on esd.es_id = ofa.es_id\n"
				+ "where  esd.ec_exam_id= ? and (extract(year FROM esd.es_begin_date )::int ) =? ";


	
		stmt = conn.prepareStatement(q);
		
		stmt.setInt(1, Integer.parseInt(exam_id));
		stmt.setInt(2,Year);
		System.err.println("smt====fu===="+stmt);
		ResultSet rs = stmt.executeQuery();
int i=1;
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			String Data=rs.getString("opc_personal_code");
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(3);
			}
			
			Data=DataPre+DataM;
			
			list.add(Data+(rs.getString("opc_suffix_code")));
			list.add(rs.getString("rc_rank_name"));
			list.add(rs.getString("opd_officer_name"));
			list.add(rs.getString("um_remarks"));
			
			
			
			
			
			
			
			alist.add(list);
			i++;
			//System.err.println("list============"+list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}


}
