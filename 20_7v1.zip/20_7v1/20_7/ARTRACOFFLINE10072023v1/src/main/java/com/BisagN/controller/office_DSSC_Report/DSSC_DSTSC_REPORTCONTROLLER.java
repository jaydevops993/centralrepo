package com.BisagN.controller.office_DSSC_Report;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.reports.AbsenteesPDF;
import com.BisagN.controller.office.reports.ArmServiceWiseAnalysisOfResult;
import com.BisagN.controller.office.reports.CandidateScoring25PermarksPDF;
import com.BisagN.controller.office.reports.ChancewiseAnalysisReportPDF;
import com.BisagN.controller.office.reports.CommandWiseAnalysic_Controller_Pdf;
import com.BisagN.controller.office.reports.FullyPassed_Controller_Pdf;
import com.BisagN.controller.office.reports.IndexNoAgainstMarksObtainedController_Pdf;
import com.BisagN.controller.office.reports.IndexNoAgainstPersonalNoController_Pdf;
import com.BisagN.controller.office.reports.IneligibleCandidateReportController;
import com.BisagN.controller.office.reports.PartiallyPassed_Controller_Pdf;
import com.BisagN.controller.office.reports.Result_withheldPdf;
import com.BisagN.controller.office.reports.SubjectWiseAnalysic_Controller_Pdf;
import com.BisagN.dao.officer.others.ExaminationlockunlockDAO;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.report.DSSC_DSTSC_REPORTDAO;
import com.BisagN.dao.officer.report.PartB_ReportDAO;
import com.BisagN.models.officers.masters.EXAM_CODE_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class DSSC_DSTSC_REPORTCONTROLLER {
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private ExaminationlockunlockDAO exmunlockDao;

	@Autowired
	PartB_ReportDAO partbreportDao;
	

@Autowired
private PartB_ExaminationDAO partBDao;

	CommonController comm = new CommonController();

	@Autowired
	private DSSC_DSTSC_REPORTDAO DSSCDao;
	
	@RequestMapping(value = "DSSC_DSTSC_ReportUrl", method = RequestMethod.GET)
	public ModelAndView DSSC_DSTSC_ReportUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) 
			 throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
	NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{
		
		
		

			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory,3));
			ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(3);
			Mmap.put("getexamcentrelist", examcentrelist);
			ArrayList<ArrayList<String>>list2= exmunlockDao.getbegindatefrmexmschedule(3);
		    Mmap.put("DSSC_Begindate", list2);
	    Mmap.put("msg", msg);
		

	return new ModelAndView("DSSC_DSTSCReport_tiles");

	}
	
	
	@RequestMapping(value = "/getDSSC_DSTSC_Report", method = RequestMethod.POST)
	public ModelAndView getDSSC_DSTSC_Report(ModelMap Mmap, HttpSession session,HttpServletRequest request, String typeReport, String es_id, 
			String reportname1, String subject_id1,String centre_id1,String chance1, String f_percntg1,String t_percntg1,String marks1, String exmsh_date1, String subject_name_hid1,
			String t_chnace1, String fr_chnace1) {
		try {
			
			
			
			System.err.println("subject_name_hid1======"+subject_name_hid1);
			if(!exmsh_date1.equals("")) {
			String es_year = exmsh_date1.split("/")[2];
			Mmap.put("es_year", es_year);
			
			if(es_id.equals("0")) {
				Mmap.put("msg","Please Select Subject");
				  return new ModelAndView("redirect:DSSC_DSTSC_ReportUrl");
			  }
			
			
			if(reportname1.equals("0")) {
				Mmap.put("msg","Please Select Report");
				  return new ModelAndView("redirect:DSSC_DSTSC_ReportUrl");
			  }
			
			
			 List<EXAM_CODE_M>getExamName=comm.getExamNamebyExmID( sessionFactory, 3) ;
			 String ExamName=getExamName.get(0).getEc_exam_name();
			 Mmap.put("ExamName", ExamName);
			
			
		
			if(reportname1.equals("1")) {
				
				System.err.println("es_year----------"+es_year);
				ArrayList<ArrayList<String>> list = DSSCDao.getWithDrawalsDSSC(Integer.parseInt(es_id));
				
				if (list.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {
					Mmap.put("list", list);
					Mmap.put("list.size()", list.size());
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (list.size() > 0) {

						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(new WithdrwalPDFController("L", TH, Heading, username),"userList",list);

					}
				}
				
				}
			}
			else if(reportname1.equals("2")) {
					
				ArrayList<ArrayList<String>> list = DSSCDao.getJcCourseCandidateWiseDetails();
				
			if (list.size() == 0) {

				Mmap.put("msg", "Data Not Available.");
			} else {
				Mmap.put("list", list);
				Mmap.put("list.size()", list.size());
			}
				
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (list.size() > 0) {
						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(new JcCourseGradingReportPdfController("L", TH, Heading, username),"userList",list);


					}
				}
			}
			
			
			else if(reportname1.equals("3")) {
				
				ArrayList<ArrayList<String>> list = partbreportDao.IndexagainstmarksObtained(Integer.parseInt(es_id),Integer.parseInt(subject_id1));

				if (list.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {
					Mmap.put("list", list);
					Mmap.put("list.size()", list.size());
						
					Mmap.put("subject_name_hid1", subject_name_hid1);
					if (typeReport != null && typeReport.equals("pdfL")) {
						if (list.size() > 0) {
							List<String> TH = new ArrayList<String>();
							String Heading = "";
							String username = session.getAttribute("username").toString();
							return new ModelAndView(new IndexNoAgainstMarksObtainedController_Pdf("L", TH, Heading, username));

						}
					}
				}
			}
			
			
			else if(reportname1.equals("4")) {
				
				
				System.err.println("centre_id1======="+centre_id1);
				ArrayList<ArrayList<String>> list = partbreportDao.IndexagainstPersonNo(Integer.parseInt(es_id),Integer.parseInt(centre_id1));

				if (list.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {
					Mmap.put("list", list);
					Mmap.put("list.size()", list.size());
						
				
				
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (list.size() > 0) {
						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(new IndexNoAgainstPersonalNoController_Pdf("L", TH, Heading, username),"userList",list);
					}
					}
				   }
			}

		else if(reportname1.equals("5")) {
			
	ArrayList<ArrayList<String>> list = DSSCDao.getCompensatoryChnaceReport(es_year);
			
			if (list.size() == 0) {

				Mmap.put("msg", "Data Not Available.");
			} else {
				Mmap.put("list", list);
				Mmap.put("list.size()", list.size());
			
			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list.size() > 0) {
					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new CompensatoryChancPdfController("L", TH, Heading, username),"userList",list);

				}
			}
			
			}
		}
			
		else if(reportname1.equals("6")) {
			
			ArrayList<ArrayList<String>> list = DSSCDao.getACRndFdMarksReport(Integer.parseInt(es_id));
					
					if (list.size() == 0) {

						Mmap.put("msg", "Data Not Available.");
					} else {
						Mmap.put("list", list);
						Mmap.put("list.size()", list.size());
					
					if (typeReport != null && typeReport.equals("pdfL")) {
						if (list.size() > 0) {
							List<String> TH = new ArrayList<String>();
							String Heading = "";
							String username = session.getAttribute("username").toString();
							return new ModelAndView(new ACRndFDMarksReportController("L", TH, Heading, username),"userList",list);

						}
					}
					
					}
				}
			
			

		else if(reportname1.equals("7")) {
			
	ArrayList<ArrayList<String>> list = DSSCDao.PartAbsenteesForDSSC_DSTSC(Integer.parseInt(es_id));
			
			if (list.size() == 0) {

				Mmap.put("msg", "Data Not Available.");
			} else {
				Mmap.put("list", list);
				Mmap.put("list.size()", list.size());
			
			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list.size() > 0) {
					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new AbsenteesDSSCDSTSCReportControllerPDF("L", TH, Heading, username),"userList",list);

				}
			}
			
			}
		}
			
	else if(reportname1.equals("8")) {
		ArrayList<ArrayList<String>> list = DSSCDao.getArmwiseAnalysisReport(Integer.parseInt(es_id));
	
	if (list.size() == 0) {
	
		Mmap.put("msg", "Data Not Available.");
	} else {
		Mmap.put("list", list);
		Mmap.put("list.size()", list.size());
	
			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list.size() > 0) {
					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new ArmWiseAnalysisDssc_dstscPdfReportController("L", TH, Heading, username),"userList",list);
	
				}
			}
		}
	}	
	else  if(reportname1.equals("9")) {
			
			ArrayList<ArrayList<String>> list = DSSCDao.getreserveofficeristReport(Integer.parseInt(es_id));
		
		if (list.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {
			Mmap.put("list", list);
			Mmap.put("list.size()", list.size());
				
				if (typeReport != null && typeReport.equals("pdfL")) {
				if (list.size() > 0) {
						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(new ReserveListDSSC_DSTSCPdfReportController("L", TH, Heading, username));


					}
				}
			}
		}
		
	else if (reportname1.equals("10")) {

		ArrayList<ArrayList<String>> list = DSSCDao.getfailofficeristReport(Integer.parseInt(es_id));

		if (list.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {

			Mmap.put("list", list);
			Mmap.put("list.size()", list.size());

			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list.size() > 0) {
					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new FailedCadidatePDFReportController("L", TH, Heading, username));

				}
			}
		}
	}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("redirect:DSSC_DSTSC_ReportUrl");
	}

}
