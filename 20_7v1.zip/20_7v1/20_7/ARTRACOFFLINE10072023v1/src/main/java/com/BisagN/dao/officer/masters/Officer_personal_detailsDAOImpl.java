package com.BisagN.dao.officer.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class Officer_personal_detailsDAOImpl implements Officer_personal_detailsDAO {

	@Autowired
	private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	 CommonController comm= new CommonController();

	

	public boolean checkIsIntegerValue(String Search) {
		return Search.matches("[0-9]+");
	}

	public List<Map<String, Object>> getReportListOfficer_personal_details(int startPage, String pageLength,
			String Search, String orderColunm, String orderType, String pers_no, String pers_name, String arm,
			String doc, HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search, pers_no, pers_name, arm, doc);
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		String q = "";
		String q1 = "";
		String q2 = "";
		String q3 = "";
		String q4 = "";
		
	if (!pers_no.equals("")) {
			
			
			pers_no=comm.getSearchIcNumberwithoutZero(pers_no);
			 
		}

		try {

			conn = dataSource.getConnection();

			q = "select vw.opd_personal_id ,vw.opc_personal_code,  vw.opd_officer_name,vw.opc_suffix_code,vw.cc_command_name,TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm,vw.opd_unit,\n"
					+ "					TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority, TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob \n"
					+ "					from vw_personal_details vw where vw.opd_status_id='1'  " + SearchValue
					+ " ORDER BY " + orderColunm + " " + orderType + " limit " + pageLength + " OFFSET " + startPage;
			PreparedStatement stmt = conn.prepareStatement(q);

			stmt = setQueryWhereClause_SQL(stmt, Search, pers_no, pers_name, arm, doc);

			System.err.println("op=====" + stmt);

			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();
			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
					columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
				String enckey = "commonPwdEncKeys";
				Cipher c = hex_asciiDao.EncryptionSHA256Algo(session, enckey);
				String EncryptedPk = new String(
						Base64.encodeBase64(c.doFinal(rs.getString("opd_personal_id").toString().getBytes())));

				String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"
						+ EncryptedPk + "')}else{ return false;}\"";
				String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>";
				String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('" + EncryptedPk
						+ "')}else{ return false;}\"";
				String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>";
				String f = "";

				 String f1 = "";
                 f += updateButton;
//		                      f += deleteButton;
				
				 String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
				 String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));
				 f1 += opc_code;
                 columns.put("action",f);
                 columns.put("opc_code",f1);
                columns.put(metaData.getColumnLabel(1), f);
		list.add(columns);
			}

			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return list;
	}

	public long getReportListOfficer_personal_detailsTotalCount(String Search, String pers_no, String pers_name,
			String arm, String doc) {
		String SearchValue = GenerateQueryWhereClause_SQL(Search, pers_no, pers_name, arm, doc);
		int total = 0;
		String q = null;
		Connection conn = null;
		String q1 = "";
		String q2 = "";
		String q3 = "";
		String q4 = "";

		try {
			conn = dataSource.getConnection();

			q = "select count(*) from (select DISTINCT vw.opd_personal_id, vw.opc_personal_code, vw.opd_officer_name,vw.cc_command_name,TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm,vw.opd_unit,\n"
					+ "					TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority, TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob from vw_personal_details vw where vw.opd_status_id='1'    "
					+ SearchValue + ") ab";
			PreparedStatement stmt = conn.prepareStatement(q);
			stmt = setQueryWhereClause_SQL(stmt, Search, pers_no, pers_name, arm, doc);
			System.err.println("op=====" + stmt);

			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				total = rs.getInt(1);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return (long) total;
	}

	public String GenerateQueryWhereClause_SQL(String Search, String pers_no, String pers_name, String arm,
			String doc) {
		String SearchValue = "";

		if (!pers_no.equals("") && pers_no != "" && pers_no != null) {

// 			SearchValue += " and lower(vw.opc_personal_code) like ?"; 
			SearchValue += " and lower(vw.opc_personal_code) like ?";
		}

		if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
			System.out.println("name====" + pers_name);
			SearchValue += " and lower(vw.opd_officer_name) like ?";
		}

		if (!arm.equals("0") && arm != "0") {
			SearchValue += "and vw.ac_arm_id=?";
		}

		if (!doc.equals("DD/MM/YYYY")) {
			SearchValue += "and TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY')=?";
		}

		if (!Search.equals("")) {
			Search = Search.toLowerCase();
			SearchValue = " and ( ";
			if (checkIsIntegerValue(Search)) {
				SearchValue += " id=? or ";
			}
			String ct_comm_id = "";
			if (checkIsIntegerValue(Search)) {
				ct_comm_id += " ct_comm_id= ? ";
			}
			SearchValue += " lower(vw.opc_personal_code)like ? or lower(vw.opd_officer_name)like ?)";
		}
		return SearchValue;
	}

	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt, String Search, String pers_no,
			String pers_name, String arm, String doc) {
		int flag = 0;
		try {

			if (!pers_no.equals("") && pers_no != "" && pers_no != null) {
				System.err.println("pers_no===========" + pers_no);
				flag += 1;
				stmt.setString(flag, "%" + pers_no.toLowerCase() + "%");
			}

			if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
				System.err.println("pers_name===========" + pers_name);
				flag += 1;
				stmt.setString(flag, "%" + pers_name.toLowerCase() + "%");
			}

			if (!arm.equals("0") && arm != "0") {
				flag += 1;
				stmt.setInt(flag, Integer.parseInt(arm));
			}

			if (!doc.equals("DD/MM/YYYY")) {
				flag += 1;
				stmt.setString(flag, doc);
			}
			if (!Search.equals("")) {
				if (checkIsIntegerValue(Search)) {
					flag += 1;
					stmt.setInt(flag, Integer.parseInt(Search));
				}
				if (checkIsIntegerValue(Search)) {
					flag += 1;
					stmt.setInt(flag, Integer.parseInt(Search));
				}
				flag += 1;
				Search=comm.getSearchIcNumberwithoutZero(Search);

				stmt.setString(flag, "%" + Search + "%");
				flag += 1;
				stmt.setString(flag, "%" + Search + "%");
// 				flag += 1;
// 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 				flag += 1;
//				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 				flag += 1;
//				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 				flag += 1;

			}
		} catch (Exception e) {
		}
		return stmt;
	}

	public String Deleteofficer_personal_details(String deleteid, HttpSession session1) {

		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) deleteid, enckey, session1);
		String hql = "Delete from OFFICER_PERSONAL_DETAILS_M  where cast(id as string) = :deleteid";
		Query q = session.createQuery(hql).setString("deleteid", DcryptedPk);
		int rowCount = q.executeUpdate();
		tx.commit();
		session.close();
		if (rowCount > 0) {
			return "Deleted Successfully";
		} else {
			return "Deleted not Successfully";
		}
	}

	public List<Map<String, Object>> getpersdetails(String pers_no) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "SELECT DISTINCT opd.opd_officer_name,cc.cc_command_name,opd.opd_personal_id,ofcode.opc_suffix_code,ofcode.opc_personal_code,orank.rc_rank_id,\n"
					+ "TO_CHAR(opd.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority ,TO_CHAR(opd.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm ,\n"
					+ " 						opd.opd_unit,ofcode.opc_personal_code,ofarm.ac_arm_id,opd.opd_unit,ar.ac_arm_description,TO_CHAR(opd.opd_dob,'DD/MM/YYYY') as opd_dob,com.ct_comm_type,rc.rc_rank_name,opd.opd_unit_address2,opd.opd_unit_address3,opd.opd_partd,opd_isactive from officer_personal_code  opc\n"
					+ " 						inner join officer_personal_details opd on opc.opd_personal_id =opd.opd_personal_id\n"
					+ " 						inner join commission_type com on com.ct_comm_id = opd.ct_comm_id\n"
					+ " 					inner join officer_personal_code ofcode on ofcode.opd_personal_id = opc.opd_personal_id\n"
					+ "					inner join officer_arm ofarm on ofarm.opd_personal_id = opd.opd_personal_id\n"
					+ "					inner join arm_codes ar on ar.ac_arm_id=ofarm.ac_arm_id\n"
					+ "left join command_code cc on cc.cc_command_id=opd.cc_command_id  inner join officer_rank orank on orank.opd_personal_id::text=opd.opd_personal_id::text\n"
					+ "					inner join rank_code rc on rc.rc_rank_id = orank.rc_rank_id where  opd.opd_personal_id=? and ofcode.opc_status_id='1'";
			stmt = conn.prepareStatement(q);

			if (!pers_no.equals("")) {
				stmt.setInt(1, Integer.parseInt(pers_no));
			}
			System.out.println("stmt---------getpersdetails------" + stmt);

			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();
			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
					columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
				list.add(columns);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return list;
	}

	public String getcommnadidbycommnadname(String commnad_name) {

		Connection conn = null;
		String status = "";

		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String query = "";
			query = "select cc_command_id from command_code where cc_command_name=?";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, commnad_name);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				status = rs.getString("cc_command_id");

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return status;
	}

	public String getcommsssionidbycommissionname(String comm_type) {

		Connection conn = null;
		String status = "";

		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String query = "";
			query = "select ct_comm_id from commission_type where ct_comm_type=?";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, comm_type);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				comm_type = rs.getString("ct_comm_id");

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return comm_type;
	}

	public String gearmidbyarmname(String arm_code) {

		Connection conn = null;
		String status = "";

		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String query = "";
			query = "select ac_arm_id from arm_codes where ac_arm_description=?";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, arm_code);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				arm_code = rs.getString("ac_arm_id");

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return arm_code;
	}

	public String geRankidbyRankname(String rank_name) {

		Connection conn = null;
		String status = "";

		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String query = "";
			query = "select rc_rank_id from rank_code where rc_rank_name=?";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, rank_name);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				rank_name = rs.getString("rc_rank_id");

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return rank_name;
	}

	public List<Map<String, Object>> getarmcodeforIASTcase(String pers_no) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select arc.ac_arm_description , ofarm.ac_arm_id from officer_arm ofarm \n"
					+ "inner join arm_codes arc on ofarm.ac_arm_id = arc.ac_arm_id where ofarm.opd_personal_id=? ";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, Integer.parseInt(pers_no));
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();
			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
					columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
				list.add(columns);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return list;
	}

}
