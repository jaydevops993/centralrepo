package com.BisagN.controller.office.Administrator;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.Year;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.models.officers.masters.ARM_CODES_M;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.others.OFFICER_ARM_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.OFFICER_RANK_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class UploadexcelController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	private PartB_ExaminationDAO partBDao;

	CommonController comm = new CommonController();

	@Autowired
	private Officer_personal_detailsDAO ofc_Dao;

	@RequestMapping(value = "/UploadDataUrl", method = RequestMethod.GET)
	public ModelAndView UploadDataUrl(ModelMap model, HttpServletRequest request, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg) {

		model.put("msg", msg);
		Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		if (flashMap != null) {
			ArrayList<ArrayList<String>> errorList = (ArrayList<ArrayList<String>>) flashMap.get("errorlist");
			model.put("errorList", errorList);
		}

		return new ModelAndView("UploadCandidateTiles");
	}

	@RequestMapping(value = "/DemoCandidateExcel", method = RequestMethod.POST)
	public ModelAndView DemoCandidateExcel(HttpServletRequest request, ModelMap model, HttpSession session,
			String typeReport1) {

		ArrayList<ArrayList<String>> listexport = new ArrayList<ArrayList<String>>();
		List<String> TH = new ArrayList<String>();
		TH.add("PERSONAL_NO");
		TH.add("SUFFIX_CODE");
		TH.add("OFFICER_NAME");
		TH.add("ARM_SERVICE");
		TH.add("DATE_OF_BIRTH");
		TH.add("COMM_DATE");
		TH.add("COMM_TYPE");
		TH.add("RANK");
		TH.add("DATE_SENIORITY");
		TH.add("TYPE_OF_ENTRY");

		String Heading = "\n";
		String username = session.getAttribute("username").toString();
		return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList",
				listexport);
	}

	@RequestMapping(value = "/UploadDataAction", method = RequestMethod.POST)
	public ModelAndView UploadDataAction(HttpServletRequest request, ModelMap model, HttpSession session,
			RedirectAttributes ra, @RequestParam(value = "fileUpload", required = false) MultipartFile fileUpload) {

		ArrayList<ArrayList<String>> listerror = new ArrayList<ArrayList<String>>();

		Session sessionHQL = this.sessionFactory.openSession();

		if (fileUpload.isEmpty()) {
			ra.addAttribute("msg", "Please Upload Copy Of File Upload");
			return new ModelAndView("redirect:UploadDataUrl");
		}

		try {

			Date date = new Date();
			String username = session.getAttribute("username").toString();

			SimpleDateFormat sdf = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy", Locale.ENGLISH);
//			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);

			File file = new File(
					comm.fileupload2(fileUpload.getBytes(), fileUpload.getOriginalFilename(), "doc_contract", ""));
			FileInputStream fis = new FileInputStream(file);
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheetAt(0);
			Row row_head = sheet.getRow(0);

			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				OFFICER_PERSONAL_DETAILS_M opd = new OFFICER_PERSONAL_DETAILS_M();
				OFFICER_PERSONAL_CODE_M op_pers_code = new OFFICER_PERSONAL_CODE_M();
				OFFICER_ARM_M of_arm = new OFFICER_ARM_M();
				OFFICER_RANK_M of_rank = new OFFICER_RANK_M();
				Row row = sheet.getRow(i);

				if (row.getCell(0) == null) {
					break;
				}

				ArrayList<String> listData = new ArrayList<String>();

				Session sessionHQL6 = this.sessionFactory.openSession();
				Transaction tx = sessionHQL6.beginTransaction();
				int errorcount = 0;
				int succeesscount = 0;
				String errormsg = "";
				String suffix_code = "";
				String rank = "";
				String arm_service = "";
				String dob = "";
				String personal_no = "";
				int arm_code_id = 0;
				String pbda_code = "";
				String commissiontype = "";
				String commissionDate = "";
				String SeniorityDate = "";
				String type_of_entry = "";
				String officerName = "";
				for (int j = 0; j < 10; j++) {

					Cell cell = row.getCell(j);

					String value = "";
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						value = cell.getStringCellValue();
						break;
					case Cell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							value = String.valueOf(cell.getDateCellValue());
						} else {
							value = String.valueOf((long) cell.getNumericCellValue());
						}
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						value = String.valueOf(cell.getBooleanCellValue());
						break;
					default:
					}

					if (row_head.getCell(j).getStringCellValue().equals("OFFICER_NAME")) {
						officerName = value;
						opd.setOpd_officer_name(value);
					}
					if (row_head.getCell(j).getStringCellValue().equals("TYPE_OF_ENTRY")) {
						type_of_entry = value;
						opd.setOpd_type_of_entry(type_of_entry);

					}
					if (row_head.getCell(j).getStringCellValue().equals("DATE_OF_BIRTH")) {
						dob = value;
						
						Date parsedDate = sdf.parse( dob);
						opd.setOpd_dob(parsedDate);
					}

					if (row_head.getCell(j).getStringCellValue().equals("COMM_DATE")) {
						commissionDate = value;
						Date parsedDate = sdf.parse(commissionDate);
						opd.setOpd_date_of_comm(parsedDate);
					}

					if (row_head.getCell(j).getStringCellValue().equals("DATE_SENIORITY")) {
						SeniorityDate = value;
						Date parsedDate = sdf.parse(SeniorityDate);
						opd.setOpd_date_of_seniority(parsedDate);
					}
					if (row_head.getCell(j).getStringCellValue().equals("COMM_TYPE")) {
						commissiontype = value;
						String commissiontype_id = ofc_Dao.getcommsssionidbycommissionname(value);
						opd.setCt_comm_id(Integer.parseInt(commissiontype_id));

					}

					if (row_head.getCell(j).getStringCellValue().equals("PERSONAL_NO")) {
						personal_no = value;

					}

					if (row_head.getCell(j).getStringCellValue().equals("SUFFIX_CODE")) {
						suffix_code = value;

					}

					if (row_head.getCell(j).getStringCellValue().equals("ARM_SERVICE")) {

						arm_service = value;
						List<ARM_CODES_M> armdetails = comm.getarmdetailsbyarmId(sessionFactory, arm_service);
						arm_code_id = armdetails.get(0).getAc_arm_id();
						String arm_code = armdetails.get(0).getAc_arm_code();
						of_arm.setAc_arm_code(arm_code);
						of_arm.setAc_arm_id(arm_code_id);

					}

					if (row_head.getCell(j).getStringCellValue().equals("RANK")) {
						rank = value;
						String rank_id = ofc_Dao.geRankidbyRankname(value);
						of_rank.setRc_rank_id(Integer.parseInt(rank_id));

					}

				}
				String max_age = request.getParameter("max_age");

				int id = op_pers_code.getOpd_personal_id() > 0 ? op_pers_code.getOpd_personal_id() : 0;
				Query q0 = sessionHQL6.createQuery(
						"select count(*) from OFFICER_PERSONAL_CODE_M where  opc_personal_code=:opc_personal_code and opd_personal_id!=:opd_personal_id");

				q0.setParameter("opc_personal_code", personal_no);

				q0.setParameter("opd_personal_id", id);
				Long c = (Long) q0.uniqueResult();

				if (c == 0) {

					String dateStr = dob;
					DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
//					DateFormat formatter = new SimpleDateFormat("MMM dd yyyy");
					Date newdate = (Date) formatter.parse(dateStr);
//						System.out.println(newdate);        
					 Format f = new SimpleDateFormat("dd-MMM-yyyy");
				      String dobformateddate = f.format(newdate);
//					DateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
//					Date newdate = (Date) formatter.parse(dateStr);
//						System.out.println(newdate);        

					Calendar cal = Calendar.getInstance();
					cal.setTime(newdate);
					int formatedYear = cal.get(Calendar.YEAR);
//						System.out.println("formatedDate : " + formatedYear);    

//						System.out.println("dob+++++++++++" + dob);

					int ageCalculate = Year.now().getValue() - formatedYear;
//						System.out.println("Age Calculated+++++++++++" + ageCalculate);

					if (!max_age.equals("")) {
						
						
						
						
						if (ageCalculate > Integer.parseInt(max_age)) {
							
//							String dateStr1 = dob;
//
//							 SimpleDateFormat dt = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
//						        Date newdate1 = dt.parse(dateStr1);
//						        
//						        
//						        SimpleDateFormat dt1 = new SimpleDateFormat("dd-MMM-yyyy");
//						        System.out.println(dt1.format(newdate1));
//						        
//						        dob=(dt1.format(newdate)).toString();
//							
//							

							listData.add(personal_no);
							listData.add(suffix_code);
							listData.add(officerName);
							listData.add(arm_service);
							listData.add(dob);
							listData.add(commissionDate);
							listData.add(commissiontype);
							listData.add(rank);
							listData.add(SeniorityDate);
							listData.add(type_of_entry);

							listData.add("You are Not Eligible");

							errormsg = personal_no + "You are Not Eligible";
							model.put("msg", errormsg);
							model.put("msg", "  You are Not Eligible");
							errorcount++;
						}
					}

					else {

						ArrayList<ArrayList<String>> list = partBDao.getSubjectList("Part B",
								String.valueOf(arm_code_id));

						int sum = 0;
						if (!list.isEmpty()) {
							for (int i1 = 0; i1 < list.size(); i1++) {

								String sub = list.get(i1).get(2);

								sum += Integer.parseInt(sub);

							}
						} else {

							ArrayList<ArrayList<String>> list2 = partBDao.getSubjectList("Part D",
									String.valueOf(arm_code_id));
							for (int i2 = 0; i2 < list2.size(); i2++) {

								String sub = list2.get(0).get(2);
								sum += Integer.parseInt(sub);
								opd.setOpd_partb(1111);
							}
						}

						opd.setAuth_letter_no(request.getParameter("auth_letter_no"));
						opd.setOpd_isactive("yes");
						opd.setCourse_no(request.getParameter("course_no"));
						opd.setOpd_status_id(1);
						opd.setOpd_created_by(username);
						opd.setOpd_creation_date(date);

						opd.setPbda_sub_code(sum);
						int mid = (int) sessionHQL6.save(opd);

						tx.commit();
						sessionHQL6.close();

						Session sessionHQL1 = this.sessionFactory.openSession();
						Transaction tx1 = sessionHQL1.beginTransaction();
						op_pers_code.setOpc_creation_date(date);
						op_pers_code.setOpc_created_by(username);
						op_pers_code.setOpc_personal_code(personal_no);
						op_pers_code.setOpc_suffix_code(suffix_code);

						op_pers_code.setOpd_personal_id(mid);
						op_pers_code.setAuth_letter_no(request.getParameter("auth_letter_no"));
						op_pers_code.setOpc_status_id(1);
						sessionHQL1.save(op_pers_code);

						tx1.commit();
						sessionHQL1.close();

						Session sessionHQL2 = this.sessionFactory.openSession();
						Transaction tx2 = sessionHQL2.beginTransaction();

						of_arm.setOa_created_by(username);
						of_arm.setOa_creation_date(date);
						of_arm.setOa_status_id(1);
						of_arm.setOpd_personal_id(mid);
						sessionHQL2.save(of_arm);

						tx2.commit();
						sessionHQL2.close();

						Session sessionHQL3 = this.sessionFactory.openSession();
						Transaction tx3 = sessionHQL3.beginTransaction();

						of_rank.setOpd_personal_id(mid);
						of_rank.setOr_created_by(username);
						of_rank.setOr_creation_date(date);
						of_rank.setOr_status_id(1);

						sessionHQL3.save(of_rank);

						tx3.commit();
						sessionHQL3.close();
						ra.addAttribute("msg", "Data Save Successfully");

					}
				}
//				
				else {
					
//					String dateStr = dob;
//
//					 SimpleDateFormat dt = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
//				        Date newdate = dt.parse(dateStr);
//				        
//				        
//				        SimpleDateFormat dt1 = new SimpleDateFormat("dd-MMM-yyyy");
//				        System.out.println(dt1.format(newdate));
//				        
//					dob=(dt1.format(newdate)).toString();
//					
//					
//					
					
					
					listData.add(personal_no);
					listData.add(suffix_code);
					listData.add(officerName);
					listData.add(arm_service);
					listData.add(dateformat(dob) );
					listData.add(dateformat(commissionDate) );
					listData.add(commissiontype);
					listData.add(rank);
					listData.add(dateformat(SeniorityDate ));
					System.err.println("type_of_entry==============" + type_of_entry);
					listData.add(type_of_entry);
					listData.add("Data Already Exits");
					model.put("msg", "Data Already Exits.");
				}
//					

				if (!listData.isEmpty()) {

					listerror.add(listData);
				}
			}

			model.put("errorlist", listerror);
			model.put("errorlistSize", listerror.size());

		} catch (Exception e) {
			// tx.rollback();
			e.printStackTrace();
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}
		ra.addFlashAttribute("errorlist", listerror);
		ra.addFlashAttribute("errorlistSize", listerror.size());

		return new ModelAndView("redirect:UploadDataUrl");

	}

	
	public String dateformat(String dateStr) throws ParseException
	{
	 
	 SimpleDateFormat dt = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
       Date newdate = dt.parse(dateStr);
       
       
       SimpleDateFormat dt1 = new SimpleDateFormat("dd-MMM-yyyy");
       System.out.println(dt1.format(newdate));
       
       dateStr=(dt1.format(newdate)).toString();
	
	return dateStr;
	}
	
}
