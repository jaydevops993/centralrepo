package com.BisagN.controller.office_DSSC_MeritRerport;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.CenterwiseCountApplicationPDF;
import com.BisagN.controller.office.reports.DateWithTimeStampController;
//import com.BisagN.controller.office_DSSC_Report.ACRndFDMarksReportController.PageNumeration;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

public class UpgradationReservetoAlmcIsc extends AbstractPdfView {

	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	String exam="";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	int totalRecords=0;

	private static final DecimalFormat decfor = new DecimalFormat("0.00");  

	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public UpgradationReservetoAlmcIsc(String Type, List<String> TH, String Heading, String username,String exam) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
		this.exam = exam;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		document.setPageSize(PageSize.A4.rotate()); 
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
		//response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingSubMainHead1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 1);
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		

		String dsscCourseNo = (String) model.get("getdsscCourseVacancyReserveListForDSSC");
		String dstscCourseNo = (String) model.get("getdsscCourseVacancyReserveListForDSTSC");
		String ALMCCourseNo = (String) model.get("getdsscCourseVacancyReserveListForALMC");
		String ISCCourseNo = (String) model.get("getdsscCourseVacancyReserveListForISC");
		
		
	PdfPTable table6 = new PdfPTable(1);
	table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	table6.setWidthPercentage(100);


	PdfPTable tabledata6 = new PdfPTable(1);
	tabledata6.setWidths(new int[] {5});
	tabledata6.setWidthPercentage(100/ 3.5f);
	tabledata6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata6.setHorizontalAlignment(Element.ALIGN_RIGHT);
	tabledata6.getDefaultCell().setBorder(Rectangle.NO_BORDER);


	 
	
	Chunk underline6 = new Chunk("UPGRADATION REPORT FROM ALMC/ ISC TO DSSC/DSTSC  :  DSSC-  "+dsscCourseNo+" /DSTSC-  "+dstscCourseNo, fontTableHeadingSubMainHead1);


//		Chunk underline6 = new Chunk("UPGRADATION REPORT FROM ALMC/ ISC TO DSSC/DSTSC  :  DSSC-/DSTSC-", fontTableHeadingSubMainHead1);

		underline6.setUnderline(0.1f, -2f);

	Phrase phh6 = new Phrase(underline6);

	phh6.add("\n");
	phh6.add("\n");
	phh6.setFont(fontTableHeadingSubMainHead);






	Paragraph cell61 = new Paragraph(phh6);
	cell61.setAlignment(Element.ALIGN_LEFT);


	PdfPTable tableheader6 = new PdfPTable(1);
	tableheader6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	tableheader6.setWidthPercentage(100);
	tableheader6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	tableheader6.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	tableheader6.addCell(cell61);


	 
	 PdfPTable tabledata61 = new PdfPTable(6);
		

	 tabledata61.setWidths(new int[] {3,3,3,10,6,5});
	 tabledata61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	 tabledata61.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	 tabledata61.setWidthPercentage(100);
		
		
		
	
		Paragraph a6 = new Paragraph("SER NO",fontTableHeadingSubMainHead);
		Paragraph aa6 = new Paragraph("PERS NO",fontTableHeadingSubMainHead);
		Paragraph f6 = new Paragraph("RANK",fontTableHeadingSubMainHead);
		Paragraph f7 = new Paragraph("NAME",fontTableHeadingSubMainHead);
		Paragraph f8 = new Paragraph("UPGRADED FROM",fontTableHeadingSubMainHead);	
		Paragraph f9 = new Paragraph("UPGRADED TO",fontTableHeadingSubMainHead);
		

		
		
		
		PdfPCell blank_cella1_C11 = new PdfPCell(a6);
//		blank_cella1_C11.setPaddingLeft(29f);
		blank_cella1_C11.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C11.setBorder(Rectangle.BOTTOM);

		PdfPCell blank_cella1_C111 = new PdfPCell(aa6);
//		blank_cella1_C111.setPaddingLeft(13f);
		blank_cella1_C111.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C111.setBorder(Rectangle.BOTTOM);
		
		PdfPCell blank_cella1_C112 = new PdfPCell(f6);
//		blank_cella1_C112.setPaddingLeft(40f);
		blank_cella1_C112.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C112.setBorder(Rectangle.BOTTOM);
		
		PdfPCell blank_cella1_C113 = new PdfPCell(f7);
		blank_cella1_C113.setPaddingLeft(35f);
		blank_cella1_C113.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C113.setBorder(Rectangle.BOTTOM);
		
		PdfPCell blank_cella1_C114 = new PdfPCell(f8);
		blank_cella1_C114.setPaddingLeft(40f);
		blank_cella1_C114.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C114.setBorder(Rectangle.BOTTOM);
		
		PdfPCell blank_cella1_C115 = new PdfPCell(f9);
		blank_cella1_C115.setPaddingLeft(45f);
		blank_cella1_C115.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella1_C115.setBorder(Rectangle.BOTTOM);
		
		
		
		

		tabledata61.addCell(blank_cella1_C11);	
		tabledata61.addCell(blank_cella1_C111);
		tabledata61.addCell(blank_cella1_C112);
		tabledata61.addCell(blank_cella1_C113);
		tabledata61.addCell(blank_cella1_C114);
		tabledata61.addCell(blank_cella1_C115);
		
		
			
		ArrayList<List<String>> getcutoffofficerlistReport = (ArrayList<List<String>>) model.get("list");
			 int  index5=1;
			 for(int i5=0;i5<getcutoffofficerlistReport.size();i5++)
			 {
			
				 List<String> l = getcutoffofficerlistReport.get(i5);
				 Paragraph blank1 = new Paragraph(l.get(0),fontTableHeadingdata);
					Paragraph blank2 = new Paragraph(l.get(1),fontTableHeadingdata);
					Paragraph blank3 = new Paragraph(l.get(2),fontTableHeadingdata);
					Paragraph blank4 = new Paragraph(l.get(3),fontTableHeadingdata);
					Paragraph blank5 = new Paragraph(l.get(4),fontTableHeadingdata);
					Paragraph blank6 = new Paragraph(l.get(5),fontTableHeadingdata);
					


					PdfPCell cellar = new PdfPCell();
					
					cellar.setFixedHeight(20f);
					
					if (i5 % 2 == 0) {
						cellar.setBackgroundColor(java.awt.Color.lightGray);
						
					}

					cellar.setPhrase(blank1);
					cellar.setPadding(2);
//					cellar.setPaddingLeft(20f);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					cellar.setBorder(Rectangle.NO_BORDER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank2);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank3);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank4);
					cellar.setPadding(2);
					cellar.setPaddingLeft(20f);
					cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank5);
					cellar.setPadding(2);
					cellar.setPaddingLeft(40f);

					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank6);
					cellar.setPadding(2);
					cellar.setPaddingLeft(40f);

					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					

			 }
			 
			 
			 
			 PageNumeration event = new PageNumeration(arg2);
				arg2.setPageEvent(event);
				document.setPageCount(1);				 
				
				
		 
//		PdfPCell cell12356;
//		cell12356 = new PdfPCell();
//		cell12356.addElement(tabledata6);
//		cell12356.addElement(tableheader6);
//		cell12356.addElement(tabledata61);
//		
//		cell12356.setBorder(0);
				
				
				table6.setSplitLate(false);
				PdfPCell cell12356;
				cell12356 = new PdfPCell(); 
				cell12356.addElement(tableheader6); 
				cell12356.setBorder(Rectangle.NO_BORDER);
				 
				table6.addCell(cell12356);
				
				PdfPCell cell1235612 ;
				cell1235612 = new PdfPCell();
				cell1235612.setBorder(Rectangle.BOX);
				 
				cell1235612.addElement(tabledata61);
			 
				table6.addCell(cell1235612);
//		table6.addCell(cell12356);
		document.add(table6);
		super.buildPdfMetadata(model, document, request);
	}
	
	class PageNumeration extends PdfPageEventHelper {
		PdfTemplate total;
		PdfTemplate total1;

		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				total1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {
			// total = writer.getDirectContent().createTemplate(30, 12);
		}

		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			String ip = "";
			try {
				table.setWidths(new int[] { 15,6,1});  
				table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				Date now = new Date();
				String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
				table.addCell(dateString);  //table.addCell("TOTAL SHEET :");
				
				
				PdfPCell cell1 = new PdfPCell(Image.getInstance(total1));
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			//	table.addCell(cell1);
								
			
				//String watermark = " Generated by "+username+" on "+dateString +" with IP " +ip ;
				
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Pages %d of", writer.getPageNumber()));
				//table.addCell("Month :");
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.NO_BORDER);				
				table.addCell(cell);
				
				table.writeSelectedRows(0, -1, document.leftMargin(), document.topMargin() + 0, writer.getDirectContent());
			} catch (DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT, new Phrase(String.valueOf(writer.getPageNumber() - 1)), 2, 2, 0);
			ColumnText.showTextAligned(total1, Element.ALIGN_LEFT, new Phrase(String.valueOf(totalRecords)), 2, 2, 0);
		}
	}
	

}
