package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "arm_cutt_off", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class ARM_CUTT_OFF_M {

      private int id;
      private int es_id;
      private int sc_subject_id;
      private int ac_arm_id;
      private int aco_cut_off;
      private int aco_status_id;
      private String aco_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date aco_creation_date;
      private String aco_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date aco_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getEs_id() {
           return es_id;
      }
      public void setEs_id(int es_id) {
	  this.es_id = es_id;
      }
      public int getSc_subject_id() {
           return sc_subject_id;
      }
      public void setSc_subject_id(int sc_subject_id) {
	  this.sc_subject_id = sc_subject_id;
      }
      public int getAc_arm_id() {
           return ac_arm_id;
      }
      public void setAc_arm_id(int ac_arm_id) {
	  this.ac_arm_id = ac_arm_id;
      }
      public int getAco_cut_off() {
           return aco_cut_off;
      }
      public void setAco_cut_off(int aco_cut_off) {
	  this.aco_cut_off = aco_cut_off;
      }
      public int getAco_status_id() {
           return aco_status_id;
      }
      public void setAco_status_id(int aco_status_id) {
	  this.aco_status_id = aco_status_id;
      }
      public String getAco_created_by() {
           return aco_created_by;
      }
      public void setAco_created_by(String aco_created_by) {
	  this.aco_created_by = aco_created_by;
      }
      public Date getAco_creation_date() {
           return aco_creation_date;
      }
      public void setAco_creation_date(Date aco_creation_date) {
	  this.aco_creation_date = aco_creation_date;
      }
      public String getAco_modified_by() {
           return aco_modified_by;
      }
      public void setAco_modified_by(String aco_modified_by) {
	  this.aco_modified_by = aco_modified_by;
      }
      public Date getAco_modification_date() {
           return aco_modification_date;
      }
      public void setAco_modification_date(Date aco_modification_date) {
	  this.aco_modification_date = aco_modification_date;
      }
}
