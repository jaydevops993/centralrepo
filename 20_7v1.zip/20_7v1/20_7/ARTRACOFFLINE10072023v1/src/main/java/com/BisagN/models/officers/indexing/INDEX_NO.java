package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "index_no", uniqueConstraints = { @UniqueConstraint(columnNames = "id"), })
public class INDEX_NO {

	private int index_no;
	private int es_id;
	private int id;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIndex_no() {
		return index_no;
	}

	public void setIndex_no(int index_no) {
		this.index_no = index_no;
	}

	public int getEs_id() {
		return es_id;
	}

	public void setEs_id(int es_id) {
		this.es_id = es_id;
	}

}
