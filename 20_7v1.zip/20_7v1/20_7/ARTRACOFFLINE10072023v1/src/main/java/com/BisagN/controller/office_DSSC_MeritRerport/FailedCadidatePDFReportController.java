package com.BisagN.controller.office_DSSC_MeritRerport;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

public class FailedCadidatePDFReportController extends AbstractPdfView {

	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	int totalRecords=0;

	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public FailedCadidatePDFReportController(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingSubMainHead1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 1);

		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		
	PdfPTable table6 = new PdfPTable(1);
	table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	table6.setWidthPercentage(100);


	PdfPTable tabledata6 = new PdfPTable(1);
	tabledata6.setWidths(new int[] {5});
	tabledata6.setWidthPercentage(100/ 3.5f);
	tabledata6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata6.setHorizontalAlignment(Element.ALIGN_RIGHT);
	tabledata6.getDefaultCell().setBorder(Rectangle.NO_BORDER);


	 
	


		Chunk underline6 = new Chunk("ARMY TRAINING COMMAND (EXAM SEC)" + "\n" + "DSSC-78/DSTSC-05 ENTRANCE Exam" + "\n" + "MARKS OF OFFICERS WHO DID NOT QUALIFIED", fontTableHeadingSubMainHead);

		underline6.setUnderline(0.1f,-2f);

	Phrase phh6 = new Phrase(underline6);

	phh6.add("\n");
	phh6.add("\n");
	phh6.setFont(fontTableHeadingSubMainHead);






	Paragraph cell61 = new Paragraph(phh6);
	cell61.setAlignment(Element.ALIGN_LEFT);


	PdfPTable tableheader6 = new PdfPTable(1);
	tableheader6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	tableheader6.setWidthPercentage(100);
	tableheader6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	tableheader6.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	tableheader6.addCell(cell61);






	 
	 PdfPTable tabledata61 = new PdfPTable(11);
		

	 tabledata61.setWidths(new int[] {3,7,4,11,5,4,4,4,4,4,4});
	 tabledata61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	 tabledata61.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	 tabledata61.setWidthPercentage(100);
		
		
		

		Paragraph a6 = new Paragraph("S NO.",fontTableHeadingSubMainHead1);
		Paragraph b6 = new Paragraph("PERSONAL NO",fontTableHeadingSubMainHead1);
		Paragraph c6 = new Paragraph("RANK",fontTableHeadingSubMainHead1);
		Paragraph d6 = new Paragraph("NAME",fontTableHeadingSubMainHead1);
		Paragraph e6 = new Paragraph("ARM /" +"\n"+ "SERVICE",fontTableHeadingSubMainHead1);
		Paragraph f6 = new Paragraph("Marks out of 500 Each",fontTableHeadingSubMainHead1);
		
		
		
		PdfPCell blank_cella1_C11 = new PdfPCell(a6);
		blank_cella1_C11.setRowspan(2);
		blank_cella1_C11.setPaddingLeft(5f);
		
		PdfPCell blank_cella1_C12 = new PdfPCell(b6);
		blank_cella1_C12.setRowspan(2);
		blank_cella1_C12.setPaddingLeft(5f);

		
		PdfPCell blank_cella1_C13 = new PdfPCell(c6);
		blank_cella1_C13.setRowspan(2);
		blank_cella1_C13.setPaddingLeft(8f);

		
		
		PdfPCell blank_cella1_C14 = new PdfPCell(d6);
		blank_cella1_C14.setRowspan(2);
		blank_cella1_C14.setPaddingLeft(40f);

		
		
		PdfPCell blank_cella1_C15 = new PdfPCell(e6);
		blank_cella1_C15.setRowspan(2);
		
		PdfPCell blank_cella1_C16 = new PdfPCell(f6);
		blank_cella1_C16.setColspan(6);
		blank_cella1_C16.setPaddingLeft(70f);

		
		
		
		
		

		tabledata61.addCell(blank_cella1_C11);
		tabledata61.addCell(blank_cella1_C12);
		tabledata61.addCell(blank_cella1_C13);
		tabledata61.addCell(blank_cella1_C14);
		tabledata61.addCell(blank_cella1_C15);
		tabledata61.addCell(blank_cella1_C16);
		
		
		Paragraph a66 = new Paragraph("TAC A",fontTableHeadingSubMainHead1);
		Paragraph b66 = new Paragraph("TAC B",fontTableHeadingSubMainHead1);
		Paragraph c66 = new Paragraph("A & L",fontTableHeadingSubMainHead1);
		Paragraph d66 = new Paragraph("CA",fontTableHeadingSubMainHead1);
		Paragraph e66 = new Paragraph("SMT",fontTableHeadingSubMainHead1);
		Paragraph f66 = new Paragraph("MH",fontTableHeadingSubMainHead1);
		
		
		
		tabledata61.addCell(a66);
		tabledata61.addCell(b66);
		tabledata61.addCell(c66);
		tabledata61.addCell(d66);
		tabledata61.addCell(e66);
		tabledata61.addCell(f66);
			
		ArrayList<List<String>> getfailofficeristReport = (ArrayList<List<String>>) model.get("list");
			 int  index5=1;
			 for(int i5=0;i5<getfailofficeristReport.size();i5++)
			 {
			
				 List<String> l = getfailofficeristReport.get(i5);
					Paragraph blank1 = new Paragraph(l.get(0),fontTableHeadingdata);
					Paragraph blank2 = new Paragraph(l.get(1),fontTableHeadingdata);
					Paragraph blank3 = new Paragraph(l.get(2),fontTableHeadingdata);
					Paragraph blank4 = new Paragraph(l.get(3),fontTableHeadingdata);
					Paragraph blank5 = new Paragraph(l.get(4),fontTableHeadingdata);
					Paragraph blank6 = new Paragraph(l.get(5),fontTableHeadingdata);
					Paragraph blank7 = new Paragraph(l.get(6),fontTableHeadingdata);
					Paragraph blank8 = new Paragraph(l.get(7),fontTableHeadingdata);
					Paragraph blank9 = new Paragraph(l.get(8),fontTableHeadingdata);
					Paragraph blank10 = new Paragraph(l.get(9),fontTableHeadingdata);
					Paragraph blank11 = new Paragraph(l.get(10),fontTableHeadingdata);
					
					PdfPCell cellar = new PdfPCell();
					
					cellar.setFixedHeight(20f);
					if (i5 % 2 == 0) {
						cellar.setBackgroundColor(java.awt.Color.lightGray);
					}

					cellar.setPhrase(blank1);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank2);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank3);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank4);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank5);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank6);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank7);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank8);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank9);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

					cellar.setPhrase(blank10);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank11);
					cellar.setPadding(2);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);

//					tabledata61.addCell(blank1);
//					tabledata61.addCell(blank2);
//					tabledata61.addCell(blank3);
//					tabledata61.addCell(blank4);
//					
//					tabledata61.addCell(blank5);
//					tabledata61.addCell(blank6);
//					tabledata61.addCell(blank7);
//					tabledata61.addCell(blank8);
//					tabledata61.addCell(blank9);
//					tabledata61.addCell(blank10);
//					tabledata61.addCell(blank11);
			
			 }
//				table6.addCell(cell12356);
//				document.add(table6);
			 
				 
			 PageNumeration event = new PageNumeration(arg2);
				arg2.setPageEvent(event);
				document.setPageCount(1);
				

		 
		 
			 
		PdfPCell cell12356;
		cell12356 = new PdfPCell();
		cell12356.addElement(tabledata6);
		cell12356.addElement(tableheader6);
		cell12356.addElement(tabledata61);
		
		cell12356.setBorder(0);
		table6.addCell(cell12356);
		document.add(table6);
		super.buildPdfMetadata(model, document, request);
	}
	
	class PageNumeration extends PdfPageEventHelper {
		PdfTemplate total;
		PdfTemplate total1;

		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				total1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {
			// total = writer.getDirectContent().createTemplate(30, 12);
		}

		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			String ip = "";
			try {
				table.setWidths(new int[] { 15,6,1});  
				table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				Date now = new Date();
				String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
				table.addCell(dateString);  //table.addCell("TOTAL SHEET :");
				
				
				PdfPCell cell1 = new PdfPCell(Image.getInstance(total1));
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			//	table.addCell(cell1);
								
			
				//String watermark = " Generated by "+username+" on "+dateString +" with IP " +ip ;
				
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Pages %d of", writer.getPageNumber()));
				//table.addCell("Month :");
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.NO_BORDER);				
				table.addCell(cell);
				
				table.writeSelectedRows(0, -1, document.leftMargin(), document.topMargin() + 0, writer.getDirectContent());
			} catch (DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT, new Phrase(String.valueOf(writer.getPageNumber() - 1)), 2, 2, 0);
			ColumnText.showTextAligned(total1, Element.ALIGN_LEFT, new Phrase(String.valueOf(totalRecords)), 2, 2, 0);
		}
	}
	

}
