package com.BisagN.dao.officer.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Service
public class SUBJECT_MASTERDAOimpl implements SUBJECT_MASTERDAO{
	
	
	
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();


  public boolean checkIsIntegerValue(String Search) {
	return Search.matches("[0-9]+");
}


public List<Map<String, Object>> getReportListSubject_master(int startPage,String pageLength,String Search,String orderColunm,String orderType,
		String exam,String ec_exam_id2,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		if(pageLength.equals("-1")){
 			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search);

 		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			q = "select distinct sub.ec_exam_id, exm.ec_exam_name, sub.sc_subject_id as id, sub.sc_subject_name, sub.sc_max_marks\n"
					+ "   from subject_code sub\n"
					+ "inner join exam_code exm on exm.ec_exam_id=sub.ec_exam_id where sub.ec_exam_id=? and sub.sc_status_id='1'  "+SearchValue+" ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
			PreparedStatement stmt = conn.prepareStatement(q);
			stmt = setQueryWhereClause_SQL(stmt,Search,ec_exam_id2);
			stmt.setInt(1, Integer.parseInt(exam));
			ResultSet rs = stmt.executeQuery();
			
			ResultSetMetaData metaData = rs.getMetaData();
 			int columnCount = metaData.getColumnCount();
 			
 			System.err.println("stmt==========="+stmt);
 			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
				    columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
                      String enckey ="commonPwdEncKeys";
	                    Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
	                    String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("id").toString().getBytes())));
                      String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"+EncryptedPk+"')}else{ return false;}\""; 
                      String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
                      String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('"+EncryptedPk+"')}else{ return false;}\""; 
                      String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>"; 
                      String f = "";

                      f += updateButton;
                      f += deleteButton;
                      
                      columns.put("action", f);
                     columns.put(metaData.getColumnLabel(1), f);
			list.add(columns);
	}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {
	e.printStackTrace();
} finally {
if (conn != null) {
try {
	conn.close();
} catch (SQLException e) {
}
}
}
return list;
}

public long getReportListSubject_masterTotalCount(String Search,String exam,String ec_exam_id2) {
 		String SearchValue = GenerateQueryWhereClause_SQL(Search);
 		int total = 0;
 		String q = null;
 		Connection conn = null;
 		try {
 			conn = dataSource.getConnection();
 			q ="select count(*) from (select distinct sub.ec_exam_id, exm.ec_exam_name,  sub.sc_subject_name, sub.sc_max_marks\n"
 					+ "   from subject_code sub\n"
 					+ "inner join exam_code exm on exm.ec_exam_id=sub.ec_exam_id where sub.ec_exam_id=? and sub.sc_status_id='1' "+SearchValue+")a" ;
 			PreparedStatement stmt = conn.prepareStatement(q);
 			stmt = setQueryWhereClause_SQL(stmt,Search,ec_exam_id2);
 			stmt.setInt(1, Integer.parseInt(exam));
 			ResultSet rs = stmt.executeQuery();
 			System.err.println("stmt==="+stmt);
 			while (rs.next()) {
 				total = rs.getInt(1);
 			}
  			rs.close();
  			stmt.close();
  			conn.close();
  		} catch (SQLException e) {
  			e.printStackTrace();
  		} finally {
  			if (conn != null) {
  				try {
  					conn.close();
  				} catch (SQLException e) {
  				}
 			}
  		}
  		return (long) total;
  	}


  	public String GenerateQueryWhereClause_SQL(String Search) {
 		String SearchValue ="";
  		if(!Search.equals("")) {
			Search = Search.toLowerCase();
  			SearchValue =" and  (";
  			SearchValue +=" lower(exm.ec_exam_name) like ? or lower(sub.sc_subject_name) like ? or (sub.sc_max_marks::text) like  ?)";
 		}
  		
  		System.err.println("SearchValue============"+SearchValue);
   return SearchValue;
 }


  public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,String ec_exam_id2) {
 		int flag = 1;
 		try {
           
// 			if (!ec_exam_id2.equals("")) {
//				flag += 1;
//				stmt.setString(flag, ec_exam_id2);
//			}
 			
    		if(!Search.equals("")) {
    			System.err.println("flag==="+flag);
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 			
 				
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 				stmt.setInt(flag, Integer.parseInt(Search));
 				
// 				flag += 1;
//				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 				
// 				
// 				flag += 1;
// 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 			}
    		
 		}catch (Exception e) {}
 		return stmt;
 	}
   public String DeleteSubject_master(String deleteid,HttpSession session1) {

      	Session session = this.sessionFactory.openSession();
      	Transaction tx = session.beginTransaction();
      	String enckey = "commonPwdEncKeys";
		    String DcryptedPk = hex_asciiDao.decrypt((String) deleteid,enckey,session1);
		    
	      	String hql = "update SUBJECT_CODE_M set sc_status_id=:sc_status_id where cast(id as string) = :deleteid";
          Query q = session.createQuery(hql).setInteger("sc_status_id", 0).setString("deleteid",DcryptedPk);
      	int rowCount = q.executeUpdate();
      	tx.commit();
          session.close();
	    if(rowCount > 0) {
 			return "Deleted Successfully";
  		}else {
  		return "Deleted not Successfully";
   	}
  	}


   public List<Map<String, Object>> getarmcodeforsubjectmst(String sub_id) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select string_agg(arm_id::text,',') as arm_id from subject_code_child_tbl\n"
					+ " where sub_id=?";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, Integer.parseInt(sub_id));
			System.err.println("strmt--------ASASD========"+stmt);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();
			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
					columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
				list.add(columns);
				
//				System.out.println("list---------------"+list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return list;
	}
   
   
   public ArrayList<ArrayList<String>> getExcelSubject_master(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,String ec_exam_id2, String table, HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search);
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "",whr="";
		String q1 = "";
		String q2 = "";
		
		

		try {
			conn = dataSource.getConnection();
			
			if(!ec_exam_id2.equals("")) {
				whr += " and sub.ec_exam_id = ? ";
			}
			

			q="select distinct  ROW_NUMBER() OVER(order by sub.ec_exam_id) as serno , sub.sc_subject_id as id, sub.sc_subject_name, sub.sc_subject_code,sub.sc_form_caption\n"
					+ "from subject_code sub\n"
					
					+ "where  sub.sc_status_id='1'  "+ whr +SearchValue+" \n"
							+ "					ORDER BY "+ orderColunm +""+orderType +" limit " +pageLength+" OFFSET "+startPage;



			PreparedStatement stmt = conn.prepareStatement(q);

			stmt = setQueryWhereClause_SQL(stmt, Search,ec_exam_id2);

			System.err.println("stmt========bbbb======"+stmt);
			int j = 1;
			if (!ec_exam_id2.equals("")) {

				stmt.setInt(j, Integer.parseInt(ec_exam_id2));

				j += 1;

			}
			
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				
				list.add(rs.getString("serno"));
				
				list.add(rs.getString("id"));
				
				list.add(rs.getString("sc_subject_name"));
				
				list.add(rs.getString("sc_subject_code"));
				
				list.add(rs.getString("sc_form_caption"));

				
				
					
					
				
				alist.add(list);
//				System.err.println("list---------"+list);
				
				
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
   
   
   
}
