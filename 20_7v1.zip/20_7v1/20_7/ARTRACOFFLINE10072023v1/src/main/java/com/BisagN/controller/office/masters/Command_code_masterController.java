package com.BisagN.controller.office.masters;


import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.Command_code_masterDAO;
import com.BisagN.models.officers.masters.COMMAND_CODE_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Command_code_masterController {

	

	@Autowired
	private Command_code_masterDAO objDAO;

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	 @Autowired
		private RoleBaseMenuDAO roledao;  
	 
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	         @RequestMapping(value = "Command_code_master_Url", method = RequestMethod.GET)
	         public ModelAndView Command_code_master_Url(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
	  NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

	        	 if(request.getHeader("Referer") == null ) { 
	    			 session.invalidate();
	    			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
	    			 return new ModelAndView("redirect:/login");
	    		 }

	        	 String roleid1 = session.getAttribute("roleid").toString();
	    		 Boolean val = roledao.ScreenRedirect("Command_code_master_Url", roleid1);		
	    			if(val == false) {
	    				return new ModelAndView("AccessTiles");
	    		}	
	    		
	        	 
	             Mmap.put("msg", msg);
	         return new ModelAndView("Command_code_master_tile","command_code_masterCMD",new COMMAND_CODE_M());
	}
	 @RequestMapping(value = "/getCommand_code_masterReportDataList", method = RequestMethod.POST)
	 public @ResponseBody List<Map<String, Object>> getCommand_code_masterReportDataList(int startPage,String pageLength,String Search,String orderColunm,String orderType,HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
		return objDAO.getReportListCommand_code_master(startPage,pageLength,Search,orderColunm,orderType,sessionUserId);
	}

	 @RequestMapping(value = "/getCommand_code_masterTotalCount", method = RequestMethod.POST)
	public @ResponseBody long getCommand_code_masterTotalCount(HttpSession sessionUserId,String Search,String name){
		return objDAO.getReportListCommand_code_masterTotalCount(Search);
	}
	  @RequestMapping(value = "/command_code_masterAction" ,method = RequestMethod.POST) 
	  public ModelAndView command_code_masterAction( @ModelAttribute("command_code_masterCMD") COMMAND_CODE_M ln, BindingResult result, 
	  HttpServletRequest request, ModelMap model, HttpSession session){ 

	 
		  if(request.getParameter("cc_command_name").equals("") || request.getParameter("cc_command_name")==null ||
					request.getParameter("cc_command_name")=="null" || request.getParameter("cc_command_name").equals(null))
			{
				model.put("msg", "Please Enter Command Name");
				return new ModelAndView("redirect:Command_code_master_Url");
			}
//	 int errCount=0;
//
//	    if(request.getParameter("cc_command_name").equals("") || request.getParameter("cc_command_name") == null) 
//	    { 
//	 errCount ++;
//	 model.put("cc_command_name_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Command Name");
//	    } 
//	    if(request.getParameter("cc_command_order").equals("") || request.getParameter("cc_command_order") == null) 
//	    { 
//	 errCount ++;
//	 model.put("cc_command_order_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Command Order");
//	    } 
//	 if(errCount > 0) {
//
//	     return new ModelAndView("Command_code_master_tile");
//	  }
	 int id = ln.getCc_command_id() > 0 ? ln.getCc_command_id() : 0;
		Date date = new Date();
		String username = session.getAttribute("username").toString();
		 Session sessionHQL = this.sessionFactory.openSession();
		    Transaction tx = sessionHQL.beginTransaction(); 

		try {
			
	

			Query q0 = sessionHQL.createQuery(
					"select count(cc_command_id) from COMMAND_CODE_M where (LOWER(cc_command_name)=:cc_command_name or  cc_command_order=:cc_command_order) and cc_command_id!=:cc_command_id");

			q0.setParameter("cc_command_name", ln.getCc_command_name().toLowerCase());
			q0.setParameter("cc_command_order", ln.getCc_command_order());
			q0.setParameter("cc_command_id", id);
			Long c = (Long) q0.uniqueResult();

			
			if (id == 0) {
				ln.setCc_created_by(username);
				ln.setCc_creation_date(date);
				ln.setCc_status_id(1);
				if (c == 0) {

					sessionHQL.save(ln);
					sessionHQL.flush();
					sessionHQL.clear();
					model.put("msg", "Data Saved Successfully.");

				} else {
					model.put("msg", "Data already Exist.");
				}
			}

		
			tx.commit();
		} catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return new ModelAndView("redirect:Command_code_master_Url");
	}
	 
	   
	         @RequestMapping(value = "EditCommand_code_masterUrl", method = RequestMethod.POST)
	         public ModelAndView EditCommand_code_masterUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String updateid) {


	                Session s1 = this.sessionFactory.openSession();
	                Transaction tx = s1.beginTransaction();
	                String enckey = "commonPwdEncKeys";  
	                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
	                Query q = null;
	                q = s1.createQuery("from COMMAND_CODE_M where cast(cc_command_id as string)=:PK");
	                q.setString("PK", DcryptedPk);
	                @SuppressWarnings("unchecked")
	                List<String> list = (List<String>) q.list();
	                tx.commit();
	                s1.close();
	                Mmap.put("Editcommand_code_masterCMD1", list.get(0));
	                Mmap.put("msg", msg);
	         return new ModelAndView("EditCommand_code_master_tile","Editcommand_code_masterCMD",new COMMAND_CODE_M());
	}
	  @RequestMapping(value = "/Editcommand_code_masterAction" ,method = RequestMethod.POST) 
	  public ModelAndView Editcommand_code_masterAction( @ModelAttribute("Editcommand_code_masterCMD") COMMAND_CODE_M ln, BindingResult result, 
	  HttpServletRequest request, ModelMap model, HttpSession session){ 

	 
		  if(request.getParameter("cc_command_name").equals("") || request.getParameter("cc_command_name")==null ||
					request.getParameter("cc_command_name")=="null" || request.getParameter("cc_command_name").equals(null))
			{
				model.put("msg", "Please Enter Command Name");
				return new ModelAndView("redirect:Command_code_master_Url");
			}
//	 int errCount=0;
//
//	    if(request.getParameter("cc_command_name").equals("") || request.getParameter("cc_command_name") == null) 
//	    { 
//	 errCount ++;
//	 model.put("cc_command_name_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Command Name");
//	    } 
//	    if(request.getParameter("cc_command_order").equals("") || request.getParameter("cc_command_order") == null) 
//	    { 
//	 errCount ++;
//	 model.put("cc_command_order_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Command Order");
//	    } 
//	 if(errCount > 0) {
//
//	     return new ModelAndView("EditCommand_code_master_tile");
//	  }

	 
	    Session sessionHQL = this.sessionFactory.openSession();
	    Transaction tx = sessionHQL.beginTransaction(); 
	    ln.setCc_command_id(Integer.parseInt(request.getParameter("cc_command_id")));
	    ln.setCc_status_id(1);
	    sessionHQL.saveOrUpdate(ln); 
	    tx.commit(); 
	    sessionHQL.close(); 

	 
	    model.put("msg","Data Updated Successfully"); 
	    return new ModelAndView("redirect:Command_code_master_Url"); 
	  } 
	  @RequestMapping(value = "/deletecommand_code_masterUrl", method = RequestMethod.POST) 
	  public ModelAndView deletecommand_code_masterUrl(String deleteid,HttpSession session,ModelMap model) { 
	  	List<String> list = new ArrayList<String>(); 
	  	list.add(objDAO.Deletecommand_code_master(deleteid,session)); 
	  	model.put("msg",list);  
	    return new ModelAndView("redirect:Command_code_master_Url"); 
	  	}
	  
	  
	    //-----Excel
		@RequestMapping(value = "/Export_Command_code_master", method = RequestMethod.POST)
		public ModelAndView Export_Command_code_master(HttpServletRequest request, ModelMap model, HttpSession session, String typeReport1,
				String exam_schedule_dt2, String min_year2, String es_consider_date3, String exam_schedule_dthid2)
				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

			
			
			
			ArrayList<ArrayList<String>> exportRank_code = objDAO.getExcelCommand_code_master(0, "-1", "", "1", "ASC",typeReport1,session);
		
		
			
			
			if (exportRank_code.size() > 0) {
				List<String> TH = new ArrayList<String>();
				
				TH.add("SER_NO");
				TH.add("COMMAND_ID");
				TH.add("COMMAND_NAME");
				
				
				
				String Heading = "\n";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList",
						exportRank_code);
			} else {
				model.put("msg", "Data Not Available.");
				return new ModelAndView("redirect:Command_code_master_Url");
			}
		
		}
	  
	  
	  
	  
	} 

