package com.BisagN.controller.office.trans;


import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.trans.Examination_centreDAO;
import com.BisagN.models.officers.masters.COMMAND_CODE_M;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.trans.EXAM_CENTER_CODE_M;





@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Examination_centreController {


@Autowired
private Examination_centreDAO objDAO;
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;


@Autowired
private RoleBaseMenuDAO roledao;  

@Autowired
CommonController comm= new CommonController();
  
 
         @RequestMapping(value = "Searchexamination_centreUrl", method = RequestMethod.GET)
         public ModelAndView Searchexamination_centreUrl(ModelMap Mmap,HttpServletRequest request,HttpSession session,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
  NoSuchPaddingException, InvalidKeySpecException,InvalidAlgorithmParameterException{
        	 
        	 
        	 if(request.getHeader("Referer") == null ) { 
    			 session.invalidate();
    			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
    			 return new ModelAndView("redirect:/login");
    		 }

        	 String roleid1 = session.getAttribute("roleid").toString();
    		 Boolean val = roledao.ScreenRedirect("Searchexamination_centreUrl", roleid1);		
    			if(val == false) {
    				return new ModelAndView("AccessTiles");
    		}		
    		
        	 
        	 
        	 
        	 Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
               Mmap.put("msg", msg);
               Mmap.put("getecexamnameListDDL", comm.getecexamnameListDDL(sessionFactory));
         return new ModelAndView("SearchExamination_centre_tile");
}
 @RequestMapping(value = "/getExamcentreReport", method = RequestMethod.POST)
 public @ResponseBody List<Map<String, Object>> getExamination_centreReportDataList(int startPage,String pageLength,String Search,String orderColunm,String orderType, String command, String exam, HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
	
	
	 return objDAO.getReportListExamination_centre(startPage,pageLength,Search,orderColunm,orderType,command, exam,sessionUserId);
}

 @RequestMapping(value = "/getTotalCountexamcenter", method = RequestMethod.POST)
public @ResponseBody long getExamination_centreTotalCount(HttpSession sessionUserId,String Search,String command, String exam){
	return objDAO.getReportListExamination_centreTotalCount(Search,command, exam);
}
 
 
 
 
  @RequestMapping(value = "/examination_centreAction", method = RequestMethod.POST ) 
  public ModelAndView examination_centreAction( @ModelAttribute("examination_centreCMD") EXAM_CENTER_CODE_M ln, BindingResult result, 
  HttpServletRequest request, ModelMap model, HttpSession session){ 
	  
	  String cc_command_id=request.getParameter("cc_command_id");
		if(cc_command_id == "" || cc_command_id.equals("0")) {
			model.put("msg", "Please Select Command Name");		
			return new ModelAndView("redirect:Searchexamination_centreUrl");
		}
		
		 if(request.getParameter("ecc_name").equals("") || request.getParameter("ecc_name")==null ||
					request.getParameter("ecc_name")=="null" || request.getParameter("ecc_name").equals(null))
			{
				model.put("msg", "Please Enter Center Name");
				return new ModelAndView("redirect:Searchexamination_centreUrl");
			}
		 
	  String ec_exam_id=request.getParameter("ec_exam_id");
		if(ec_exam_id == "null" || ec_exam_id.equals("0")) {
			model.put("msg", "Please Select Exam Name");		
			return new ModelAndView("redirect:Searchexamination_centreUrl");
		}
	 
		 if(request.getParameter("ecc_cond_formation").equals("") || request.getParameter("ecc_cond_formation")==null ||
					request.getParameter("ecc_cond_formation")=="null" || request.getParameter("ecc_cond_formation").equals(null))
			{
				model.put("msg", "Please Enter Valid Arm Code");
				return new ModelAndView("redirect:Searchexamination_centreUrl");
			}
		  
	     if(request.getParameter("center_code").equals("") || request.getParameter("center_code")==null ||
					request.getParameter("center_code")=="null" || request.getParameter("center_code").equals(null))
			{
				model.put("msg", "Please Enter Centre Code");
				return new ModelAndView("redirect:Searchexamination_centreUrl");
			}

// int errCount=0;
//
//    if(request.getParameter("cc_command_id").equals("0") || request.getParameter("cc_command_id").equals("")) 
//    { 
// errCount ++;
// model.put("cc_command_id_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Command Name");
//    } 
//    if(request.getParameter("ec_exam_id").equals("0") || request.getParameter("ec_exam_id").equals("")) 
//    { 
// errCount ++;
// model.put("ec_exam_id_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Exam Name");
//    } 
//    if(request.getParameter("ecc_name").equals("") || request.getParameter("ecc_name") == null) 
//    { 
// errCount ++;
// model.put("ecc_name_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Exam Name");
//    } 
//    if(request.getParameter("ecc_cond_formation").equals("") || request.getParameter("ecc_cond_formation") == null) 
//    { 
// errCount ++;
// model.put("ecc_cond_formation_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Conduction Formation");
//    } 
//    if(request.getParameter("ecc_name").equals("") || request.getParameter("ecc_name") == null) 
//    { 
// errCount ++;
// model.put("center_name_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Centre Name");
//    } 
// if(errCount > 0) {
//
//     return new ModelAndView("Examination_centre_tile");
//  }
 int id = ln.getEcc_center_code() > 0 ? ln.getEcc_center_code() : 0;
	Date date = new Date();
	String username = session.getAttribute("username").toString();
	 Session sessionHQL = this.sessionFactory.openSession();
	    Transaction tx = sessionHQL.beginTransaction(); 

	try {

		Query q0 = sessionHQL.createQuery("select count(ecc_center_code) from EXAM_CENTER_CODE_M where   LOWER(ecc_name)=:ecc_name and ecc_center_code!=:ecc_center_code");

		q0.setParameter("ecc_name", ln.getEcc_name().toLowerCase());
		q0.setParameter("ecc_center_code", id);
		Long c = (Long) q0.uniqueResult();

		
		if (id == 0) {
			ln.setEcc_created_by(username);
			ln.setEcc_creation_date(date);
			ln.setEcc_status_id(1);
			if (c == 0) {

				sessionHQL.save(ln);
				sessionHQL.flush();
				sessionHQL.clear();
				model.put("msg", "Data Saved Successfully.");

			} else {
				model.put("msg", "Data already Exist.");
			}
		}

	
		tx.commit();
	} catch (RuntimeException e) {
		try {
			tx.rollback();
			model.put("msg", "roll back transaction");
		} catch (RuntimeException rbe) {
			model.put("msg", "Couldn�t roll back transaction " + rbe);
		}
		throw e;
	} finally {
		if (sessionHQL != null) {
			sessionHQL.close();
		}
	}

	return new ModelAndView("redirect:Searchexamination_centreUrl");
}
 
   
         @RequestMapping(value = "EditExamination_centreUrl", method = RequestMethod.POST)
         public ModelAndView EditExamination_centreUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String updateid) {


                Session s1 = this.sessionFactory.openSession();
                Transaction tx = s1.beginTransaction();
                String enckey = "commonPwdEncKeys";  
                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
                System.err.println("DcryptedPk=============="+DcryptedPk);
                Query q = null;
                q = s1.createQuery("from EXAM_CENTER_CODE_M where cast(id as string)=:PK");
                q.setString("PK", DcryptedPk);
                @SuppressWarnings("unchecked")
                List<String> list = (List<String>) q.list();
                tx.commit();
                s1.close();
                Mmap.put("Editexamination_centreCMD1", list.get(0));
             Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
             Mmap.put("getecexamnameListDDL", comm.getecexamnameListDDL(sessionFactory));
                Mmap.put("msg", msg);
                Mmap.put("id", DcryptedPk);
         return new ModelAndView("EditExamination_centre_tile","Editexamination_centreCMD",new EXAM_CENTER_CODE_M());
}
  @RequestMapping(value = "/Editexamination_centreAction" ,method = RequestMethod.POST) 
  public ModelAndView Editexamination_centreAction( @ModelAttribute("Editexamination_centreCMD") EXAM_CENTER_CODE_M ln, BindingResult result, 
  HttpServletRequest request, ModelMap model, HttpSession session){ 
	  
	  String cc_command_id=request.getParameter("cc_command_id");
		if(cc_command_id == "" || cc_command_id.equals("0")) {
			model.put("msg", "Please Select Command Name");		
			return new ModelAndView("redirect:Searchexamination_centreUrl");
		}
	 if(request.getParameter("center_code").equals("") )
		{
			model.put("msg", "Please Enter Center Name");
			return new ModelAndView("redirect:Searchexamination_centreUrl");
		}
	  String ec_exam_id=request.getParameter("ec_exam_id");
		if(ec_exam_id == "null" || ec_exam_id.equals("0")) {
			model.put("msg", "Please Select Exam Name");		
			return new ModelAndView("redirect:Searchexamination_centreUrl");
		}
	  if(request.getParameter("ecc_cond_formation").equals("") || request.getParameter("ecc_cond_formation")==null ||
				request.getParameter("ecc_cond_formation")=="null" || request.getParameter("ecc_cond_formation").equals(null))
		{
			model.put("msg", "Please Enter Valid Arm Code");
			return new ModelAndView("redirect:Searchexamination_centreUrl");
		}
// int errCount=0;
//
//    if(request.getParameter("cc_command_id").equals("0") || request.getParameter("cc_command_id").equals("")) 
//    { 
// errCount ++;
// model.put("cc_command_id_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Command Name");
//    } 
//    if(request.getParameter("ec_exam_id").equals("0") || request.getParameter("ec_exam_id").equals("")) 
//    { 
// errCount ++;
// model.put("ec_exam_id_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Exam Name");
//    } 
//    if(request.getParameter("ecc_name").equals("") || request.getParameter("ecc_name") == null) 
//    { 
// errCount ++;
// model.put("ecc_name_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Exam Name");
//    } 
//    if(request.getParameter("ecc_cond_formation").equals("") || request.getParameter("ecc_cond_formation") == null) 
//    { 
// errCount ++;
// model.put("ecc_cond_formation_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Conduction Formation");
//    } 
//    if(request.getParameter("ecc_name").equals("") || request.getParameter("ecc_name") == null) 
//    { 
// errCount ++;
// model.put("center_name_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Centre Name");
//    } 
// if(errCount > 0) {
//
//     return new ModelAndView("EditExamination_centre_tile");
//  }

 
    Session sessionHQL = this.sessionFactory.openSession();
    Transaction tx = sessionHQL.beginTransaction(); 
    
	Date date = new Date();
	String username = session.getAttribute("username").toString();
    
    String id= request.getParameter("id");
    String ecc_name= request.getParameter("ecc_name");
    String center_code= request.getParameter("center_code");
    String ecc_cond_formation= request.getParameter("ecc_cond_formation");

	String hql = "update EXAM_CENTER_CODE_M set cc_command_id=:cc_command_id,ec_exam_id=:ec_exam_id,ecc_name=:ecc_name,ecc_cond_formation=:ecc_cond_formation,"
			+ "center_code=:center_code,ecc_status_id=:ecc_status_id,ecc_modified_by=:ecc_modified_by,ecc_modification_date=:ecc_modification_date  where ecc_center_code=:ecc_center_code";
	Query query = sessionHQL.createQuery(hql)
			.setParameter("cc_command_id", Integer.parseInt(cc_command_id))
			.setParameter("ec_exam_id",Integer.parseInt(ec_exam_id))
			.setParameter("ecc_name",  ecc_name)
			.setParameter("ecc_cond_formation",ecc_cond_formation)
			.setParameter("center_code", center_code)
			.setParameter("ecc_status_id", 1)
			.setParameter("ecc_modified_by",username)
			.setParameter("ecc_modification_date",date)
			.setParameter("ecc_center_code",Integer.parseInt(id));
	query.executeUpdate();
	tx.commit();
	 model.put("msg","Data Updated Successfully");
    sessionHQL.close(); 

 
    
    return new ModelAndView("redirect:Searchexamination_centreUrl"); 
  } 
  @RequestMapping(value = "/deleteexamination_centreUrl", method = RequestMethod.POST) 
  public ModelAndView deleteexamination_centreUrl(String deleteid,HttpSession session,ModelMap model) { 
  	List<String> list = new ArrayList<String>(); 
  	list.add(objDAO.Deleteexamination_centre(deleteid,session)); 
  	model.put("msg",list);  
    return new ModelAndView("redirect:Searchexamination_centreUrl"); 
  	}
  
  @RequestMapping(value = "Exam_Centre_Url", method = RequestMethod.POST)
  public ModelAndView Exam_Centre_Url(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String Subjectid) {
  
  
    Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
    Mmap.put("getecexamnameListDDL", comm.getecexamnameListDDL(sessionFactory));
    Mmap.put("msg", msg);
return new ModelAndView("Examination_centre_tile","examination_centreCMD",new EXAM_CENTER_CODE_M());
	   
    
}
  
//  @RequestMapping(value = "/getExamcentreReport", method = RequestMethod.POST)
//	public @ResponseBody List<Map<String, Object>> getReportListExamination_centre(int startPage, String pageLength,
//			String Search, String orderColunm, String orderType, HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
//		return objDAO.getReportListExamination_centre(startPage, pageLength, Search, orderColunm, orderType,sessionUserId);
//
//	}
//
//	@RequestMapping(value = "/getTotalCountexamcenter", method = RequestMethod.POST)
//	public @ResponseBody long getTotalCountDistrictwiseReport(HttpSession sessionUserId, String Search) {
//		return objDAO.getReportListExamination_centreTotalCount(Search);
//	}
  
  
//-----Excel
	@RequestMapping(value = "/Export_examination_centre", method = RequestMethod.POST)
	public ModelAndView Export_examination_centre(HttpServletRequest request, ModelMap model, HttpSession session, String typeReport1,
			String cc_command_id2,String ec_exam_id2)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		
		
		if (ec_exam_id2 != null) {
		ArrayList<ArrayList<String>> exportSubject = objDAO.getExcelexamination_centre(0, "-1", "", "1", "ASC",cc_command_id2,ec_exam_id2,typeReport1,session);
	
	
		
		
		if (exportSubject.size() > 0) {
			List<String> TH = new ArrayList<String>();
			
			TH.add("SER_NO");
			TH.add("TEST_CENTER_CODE");
			TH.add("TEST_CENTER");
			
			
			
			String Heading = "\n";
			String username = session.getAttribute("username").toString();
			return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList",
					exportSubject);
		} 
		else {
			model.put("msg", "Data Not Available.");
			return new ModelAndView("redirect:Searchexamination_centreUrl");
		   }
		  }
		
		return new ModelAndView("redirect:Searchexamination_centreUrl");
	}
 
  
  
} 
