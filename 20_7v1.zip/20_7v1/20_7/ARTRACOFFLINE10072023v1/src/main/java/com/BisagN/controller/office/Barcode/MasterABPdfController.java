package com.BisagN.controller.office.Barcode;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPTableEvent;
import com.lowagie.text.pdf.PdfWriter;

public class MasterABPdfController extends AbstractPdfView{
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public MasterABPdfController(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		document.setPageSize(PageSize.A4);
		
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
		//response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		String es_year1 =  (String) model.get("es_year1");
		String exam_name =  (String) model.get("exam_name");
		String begin_month =  (String) model.get("begin_month");
		String sc_subject_id1 =  (String) model.get("ActiveSubName");
		String Bundle =  (String) model.get("Bundle");
		
		
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
//		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 1);
		Font fontTableHeadingSubMainHead1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 0);
//		Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		
		
		Chunk underline1 = new Chunk("MASTER AB LIST", fontTableHeading1);
//		Chunk underline1 = new Chunk("1" +"\n"+ "LIST OF ABSENTEES" +"\n"+ "PART B:"+es_year+"" , fontTableHeadingSubMainHead);	 
		underline1.setUnderline(0.1f, -2f);
		
		Phrase ph = new Phrase(underline1);
		ph.add("\n");
		ph.add("\n");
		ph.add("\n");
		ph.setFont(fontTableHeading1);

		
		Paragraph cell = new Paragraph(ph);
		cell.setAlignment(Element.ALIGN_LEFT);
		
		cell.setAlignment(Element.ALIGN_LEFT);
		
		
		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell);
		
		
		
		PdfPTable table1 = new PdfPTable(4);
		table1.setWidths(new int[] {2,5,3,5});
		table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		table1.setWidthPercentage(80);
		
		Paragraph a_1 = new Paragraph("Exam",fontTableHeadingSubMainHead);
		Paragraph b_1 = new Paragraph(": "+exam_name,fontTableHeadingSubMainHead1);
		Paragraph c_1 = new Paragraph("Type",fontTableHeadingSubMainHead);
		Paragraph d_1 = new Paragraph(": Promotion Examination",fontTableHeadingSubMainHead1);
		
		Paragraph e_1 = new Paragraph("Month",fontTableHeadingSubMainHead);
		Paragraph f_1 = new Paragraph(": "+begin_month,fontTableHeadingSubMainHead1);
		Paragraph g_1 = new Paragraph("Year",fontTableHeadingSubMainHead);
		Paragraph h_1 = new Paragraph(": "+es_year1,fontTableHeadingSubMainHead1);
		
		Paragraph i_1 = new Paragraph("Subject",fontTableHeadingSubMainHead);
		Paragraph j_1 = new Paragraph(": "+sc_subject_id1,fontTableHeadingSubMainHead1);
		Paragraph k_1 = new Paragraph("Bundle No",fontTableHeadingSubMainHead);
		Paragraph l_1 = new Paragraph(": "+Bundle,fontTableHeadingSubMainHead1);
		
		
		 PdfPCell cella_1;
		 cella_1 = new PdfPCell(a_1);
		 cella_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 cella_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell cellb_1;
		 cellb_1 = new PdfPCell(b_1);
		 cellb_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 cellb_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell cellc_1;
		 cellc_1 = new PdfPCell(c_1);
		 cellc_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 cellc_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell celld_1;
		 celld_1 = new PdfPCell(d_1);
		 celld_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 celld_1.setBorder(Rectangle.NO_BORDER);
//		 
		 
		 PdfPCell celle_1;
		 celle_1 = new PdfPCell(e_1);
		 celle_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 celle_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell cellf_1;
		 cellf_1 = new PdfPCell(f_1);
		 cellf_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 cellf_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell cellg_1;
		 cellg_1 = new PdfPCell(g_1);
		 cellg_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 cellg_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell cellh_1;
		 cellh_1 = new PdfPCell(h_1);
		 cellh_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 cellh_1.setBorder(Rectangle.NO_BORDER);
		 
		 
		 PdfPCell celli_1;
		 celli_1 = new PdfPCell(i_1);
		 celli_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 celli_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell cellj_1;
		 cellj_1 = new PdfPCell(j_1);
		 cellj_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 cellj_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell cellk_1;
		 cellk_1 = new PdfPCell(k_1);
		 cellk_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 cellk_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell celll_1;
		 celll_1 = new PdfPCell(l_1);
		 celll_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 celll_1.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 
		 
		 
		 
		
		
		
		 table1.addCell(cella_1);
		 table1.addCell(cellb_1);
		 table1.addCell(cellc_1);
		 table1.addCell(celld_1);
		 table1.addCell(celle_1);
		 table1.addCell(cellf_1);
		 table1.addCell(cellg_1);
		 table1.addCell(cellh_1);
		 table1.addCell(celli_1);
		 table1.addCell(cellj_1);
		 table1.addCell(cellk_1);
		 table1.addCell(celll_1);

		
		
		
		
		PdfPTable tabledata = new PdfPTable(4);
		tabledata.setWidths(new int[] {1,3,3,2});
		tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata.setWidthPercentage(80);
		
		ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");
		
		Paragraph a = new Paragraph("Ser No",fontTableHeadingSubMainHead);
		Paragraph b = new Paragraph("Army No",fontTableHeadingSubMainHead);
		Paragraph c = new Paragraph("Index No",fontTableHeadingSubMainHead);
		Paragraph d = new Paragraph("No of ABs",fontTableHeadingSubMainHead);
		
		
		 PdfPCell blank_cella;
		 blank_cella = new PdfPCell(a);
//		 blank_cella.addElement(a);
		 blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella.setPadding(8);
		 
		 PdfPCell blank_cellb;
		 blank_cellb = new PdfPCell(b);
//		 blank_cellb.addElement(b);
		 blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cellb.setPadding(8);
		 
		 PdfPCell blank_cellc;
		 blank_cellc = new PdfPCell(c);
//		 blank_cellc.addElement(c);
		 blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cellc.setPadding(8);
		 
		 PdfPCell blank_celld;
		 blank_celld = new PdfPCell(d);
//		 blank_celld.addElement(d);
		 blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_celld.setPadding(8);
		 
		 
		 
		 
		 
			 tabledata.addCell(blank_cella);
			 tabledata.addCell(blank_cellb);
			 tabledata.addCell(blank_cellc);
			 tabledata.addCell(blank_celld);
			 
			 int Total_count= list.size();
		 int  index=1;
		 for(int i=0;i<list.size();i++)
		 { 
			 
			 List<String> l = list.get(i);
		 Paragraph a1index = new Paragraph(String.valueOf(index),fontTableHeadingdata);
		 Paragraph pers_code = new Paragraph(l.get(1),fontTableHeadingdata);
		 Paragraph index_no = new Paragraph(l.get(2),fontTableHeadingdata);
		 Paragraph no_abs = new Paragraph(l.get(3),fontTableHeadingdata);
		
		 
		 
		 
		 PdfPCell cell2 = new PdfPCell();
		 
			 tabledata.addCell(a1index);
			 cell2.setPhrase(pers_code);
			 //cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
			 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			 tabledata.addCell(cell2);
			 cell2.setPhrase(index_no);
			 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			 tabledata.addCell(cell2);
			 cell2.setPhrase(no_abs); 
			 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			 tabledata.addCell(cell2);
			 
			 index+=1;
		
		 }
		
		
		
			 
			 
			 
			 
			 PdfPTable tabledata_2 = new PdfPTable(4);
			 tabledata_2.setWidths(new int[] {3,3,5,5});
			 tabledata_2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			 tabledata_2.setWidthPercentage(80);
			 tabledata_2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			 
			 Paragraph a_2 = new Paragraph("No of Candidates:",fontTableHeadingdata);
			 Paragraph b_2 = new Paragraph(String.valueOf(Total_count),fontTableHeadingSubMainHead);
			 Paragraph c_2 = new Paragraph("",fontTableHeadingdata);
			 Paragraph d_2 = new Paragraph(".....................................",fontTableHeadingdata);
			 
			 
			 Paragraph e_2 = new Paragraph("",fontTableHeadingdata);
			 Paragraph f_2 = new Paragraph("",fontTableHeadingdata);
			 Paragraph g_2 = new Paragraph("",fontTableHeadingdata);
			 Paragraph h_2 = new Paragraph("Assistant Examiner",fontTableHeadingdata);
			 
			 Paragraph i_2 = new Paragraph("",fontTableHeadingdata);
			 Paragraph j_2 = new Paragraph("",fontTableHeadingdata);
			 Paragraph k_2 = new Paragraph("",fontTableHeadingdata);
			 Paragraph l_2 = new Paragraph("\n\n\n.....................................",fontTableHeadingdata);
//			 Paragraph l_3 = new Paragraph("Date",fontTableHeadingdata);
			 Paragraph m_2 = new Paragraph("Date :",fontTableHeadingdata);
			 Paragraph n_2 = new Paragraph("",fontTableHeadingdata);
			 Paragraph o_2 = new Paragraph("",fontTableHeadingdata);
			 Paragraph p_2 = new Paragraph("Signature of Presiding Officer",fontTableHeadingdata);
			 
			 
//			 Paragraph q_2 = new Paragraph("Date:",fontTableHeadingdata);
			 Paragraph r_2 = new Paragraph("",fontTableHeadingdata);
			 Paragraph s_2 = new Paragraph("",fontTableHeadingdata);
			 Paragraph t_2 = new Paragraph("",fontTableHeadingdata);
			 
			 PdfPCell blank_cella_2;
			 blank_cella_2 = new PdfPCell(a_2);
			 blank_cella_2.setHorizontalAlignment(Element.ALIGN_LEFT);
			 blank_cella_2.setBorder(Rectangle.NO_BORDER);
			 
			 PdfPCell blank_cellb_2;
			 blank_cellb_2 = new PdfPCell(b_2);
			 blank_cellb_2.setHorizontalAlignment(Element.ALIGN_LEFT);
			 blank_cellb_2.setBorder(Rectangle.NO_BORDER);
			 
			 PdfPCell blank_cellc_2;
			 blank_cellc_2 = new PdfPCell(c_2);
			 blank_cellc_2.setHorizontalAlignment(Element.ALIGN_CENTER);
			 blank_cellc_2.setBorder(Rectangle.NO_BORDER);
			 
			 PdfPCell blank_celld_2;
			 blank_celld_2 = new PdfPCell(d_2);
			 blank_celld_2.setHorizontalAlignment(Element.ALIGN_CENTER);
			 blank_celld_2.setBorder(Rectangle.NO_BORDER);
			 
			 
			 
//			 PdfPCell blank_cellq_2;
//			 blank_cellq_2 = new PdfPCell(q_2);
//			 blank_cellq_2.setHorizontalAlignment(Element.ALIGN_LEFT);
//			 blank_cellq_2.setBorder(Rectangle.NO_BORDER);
			 
			 PdfPCell blank_cellm_2;
			 blank_cellm_2 = new PdfPCell(m_2);
			 blank_cellm_2.setHorizontalAlignment(Element.ALIGN_LEFT);
			 blank_cellm_2.setBorder(Rectangle.NO_BORDER);
			 
			 
			 PdfPCell blank_cellr_2;
			 blank_cellr_2 = new PdfPCell(r_2);
			 blank_cellr_2.setHorizontalAlignment(Element.ALIGN_LEFT);
			 blank_cellr_2.setBorder(Rectangle.NO_BORDER);
			 
			 
			 
			 
			 
			 tabledata_2.addCell(blank_cella_2);
			 tabledata_2.addCell(blank_cellb_2);
			 tabledata_2.addCell(blank_cellc_2);
			 tabledata_2.addCell(blank_celld_2);
			 tabledata_2.addCell(e_2);
			 tabledata_2.addCell(f_2);
			 tabledata_2.addCell(g_2);
			 tabledata_2.addCell(h_2);
			 tabledata_2.addCell(i_2);
			 tabledata_2.addCell(j_2);
			 tabledata_2.addCell(k_2);
			 tabledata_2.addCell(l_2);
//			 tabledata_2.addCell(l_3);
			 tabledata_2.addCell(blank_cellm_2);
			 tabledata_2.addCell(n_2);
			 tabledata_2.addCell(o_2);
			 tabledata_2.addCell(p_2);
//			 tabledata_2.addCell(blank_cellq_2);
			 tabledata_2.addCell(blank_cellr_2);
			 tabledata_2.addCell(s_2);
			 tabledata_2.addCell(t_2);
			 
			 
			 
			 
			 

		PdfPCell cell123;
		cell123 = new PdfPCell();
		
		cell123.addElement(tableheader);
		cell123.addElement(table1);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tabledata);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tabledata_2);
		cell123.setBorder(0);
		table.addCell(cell123);
		table.setTableEvent(new ImageBackgroundEvent(request,list.get(0).get(5),list.get(0).get(5) ));  // use for watermark
		document.add(table);
		super.buildPdfMetadata(model, document, request);
	}
	int page = 1;
	class ImageBackgroundEvent implements PdfPTableEvent {
		protected Image image;
		HttpServletRequest request;
		String created_by;
		String ce_created_date;
		
		ImageBackgroundEvent(HttpServletRequest request,String created_by,String ce_created_date){
			this.request = request;
			this.created_by = created_by;
			this.ce_created_date = ce_created_date;
		}
		
		public void tableLayout(PdfPTable table, float[][] widths, float[] heights, int headerRows, int rowStart,PdfContentByte[] canvases) {
			String ip = "";
			if (request != null) {
		        ip = request.getHeader("X-FORWARDED-FOR");
		        if (ip == null || "".equals(ip)) {
		            ip = request.getRemoteAddr();
		        }
		    }
			
			Date now = new Date();
			String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
			String watermark = " Generated by "+created_by +" on   " +dateString  +"\n"+ " For Exam Section Only"; //by "+username+"
//			String watermark1 = "For Exam Section Only"; //by "+username+"
			
			Image img = null;
			BufferedImage bufferedImage = new BufferedImage((int) table.getTotalWidth(), 50,BufferedImage.TYPE_INT_ARGB);
			Graphics graphics = bufferedImage.getGraphics();
			//graphics.setColor(Color.lightGray);
			graphics.setColor(Color.decode("#f2f2f2")); //#e6e6e6
			//graphics.setFont(new java.awt.Font("Arial Black", Font.NORMAL, 12));
			//graphics.drawString(watermark+watermark,0, 20);
			graphics.setFont(new java.awt.Font("Arial Black", Font.NORMAL, 15));
			graphics.drawString(watermark,0, 20);
			try {
				try {
					img = Image.getInstance(bufferedImage, null);
				} catch (IOException e) {
					e.getMessage();
				}
			} catch (BadElementException e) {
				e.getMessage();
			}
			this.image = img;
			
			try {
				PdfContentByte cb = canvases[PdfPTable.BACKGROUNDCANVAS];

				/*int tableWidth = (int) table.getTotalWidth();
				int first = 0;
				if (tableWidth == 523) {
					first = 750;
				}
				if (tableWidth == 770) {
					first = 440;
				}

				int last = first - (int) table.getRowHeight(0);
		        while (first > last) {
					image.setAbsolutePosition(40, first);
					cb.addImage(image, false);
					first -= 30;
				}*/
		        
		        // Portrait Page size 700 * 523
				// Landscape page size 453 * 770
				int tableWidth = (int) table.getTotalWidth();
				if (tableWidth == 523) {  // Portrait page
					image.setAbsolutePosition(60, 300);  // image.setAbsolutePosition(left-right, up-down);
					image.setRotationDegrees(0-50);      // image.setRotationDegrees(0-degree rotate);
					cb.addImage(image, false);
				}
				if (tableWidth == 770) { // landscape page
					image.setAbsolutePosition(40, 50);
					image.setRotationDegrees(30);
					cb.addImage(image, false);
				}
			} catch (DocumentException e) {
				throw new ExceptionConverter(e);
			}
		}
	}
}
