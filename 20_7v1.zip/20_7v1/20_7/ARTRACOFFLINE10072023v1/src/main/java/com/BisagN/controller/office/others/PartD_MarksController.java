package com.BisagN.controller.office.others;

import java.io.File;
import java.io.FileInputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.Indexing.IndexingDAO;
import com.BisagN.dao.Indexing.SubjectWiseSecDetailsDao;
import com.BisagN.dao.officer.others.ExaminationschedulepartdDao;
import com.BisagN.dao.officer.others.ExportPartBDao;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.others.PartB_marksDAO;
import com.BisagN.dao.officer.others.SearchResultswithheldDAO;
import com.BisagN.dao.officer.report.PartB_ReportDAO;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_DETAILS;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_MASTER;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_DETAILS;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_MASTER;
import com.BisagN.models.officers.indexing.INDEXING_SETTING;
import com.BisagN.models.officers.indexing.INDEX_NO;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MANUAL;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MASTER;
import com.BisagN.models.officers.indexing.INDEX_SLIP_SCANNED;
import com.BisagN.models.officers.indexing.KITBAGMASTER;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_ARM_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.OFFICER_RESULTS_M;
import com.BisagN.models.officers.others.PARTB_D_APPLICATION_M;
import com.BisagN.models.officers.trans.ANSWER_BOOK_M;
import com.BisagN.models.officers.trans.TB_PARTPASS_FULLPASS_DTL;
import com.BisagN.models.officers.trans.UNFAIR_MEANS_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class PartD_MarksController {
	
	@Autowired
	PartB_marksController partb = new PartB_marksController();
	
	
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private PartB_marksDAO partBmarksDao;
 
	
	
	@Autowired
	private SubjectWiseSecDetailsDao subwisesecDAO;
	 
	@Autowired
	private PartB_ExaminationDAO PartBDAo;
	

	@Autowired
	PartB_ReportDAO partbreportDao;
	
	
	@Autowired
	private SearchResultswithheldDAO resDao;
	
	
	
	@Autowired
	IndexingDAO indexDao;	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	@Autowired
	private RoleBaseMenuDAO roledao;  
	
	CommonController comm = new CommonController();
	
	@RequestMapping(value = "PartD_marks_Url", method = RequestMethod.GET)
    public ModelAndView PartD_marks_Url(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg) 
   		 throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{
		
		
		
		 if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

    	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("PartD_marks_Url", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}
			
		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? ""
				: session.getAttribute("es_begin_dateshow").toString();
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

		if (ec_exam_id == 2) {
			if (ec_exam_id != 0) {
				Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, 2));
				
			}
			if (!es_begindate.equals("")) {
				Mmap.put("es_begindate", es_begindate);
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
		}

		
		
       
			
		Mmap.put("msg", msg);
    return new ModelAndView("PartD_marks_tile");
}

	
	
	 @RequestMapping(value = "AddPartD_marks_ApplicationURL", method = RequestMethod.POST)
	  public ModelAndView AsddPartD_marks_ApplicationURL(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String deleteid) {

		 
		 String es_begindate = session.getAttribute("es_begin_date") == "" ? "": session.getAttribute("es_begin_date").toString();
			int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0": session.getAttribute("ec_exam_id").toString());
			int es_id = Integer
					.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			if(ec_exam_id != 0) {
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory,ec_exam_id));
			
			}
			if(!es_begindate.equals("")) {
	         Mmap.put("es_begindate", es_begindate.substring(0, 10));
	         
			}
			
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
	  return new ModelAndView("ADDPartD_marks_tile");
	}
	 
		
		@RequestMapping(value = "UploadPartDMarksURL", method = RequestMethod.GET)
		public ModelAndView UploadPartDMarksURL(ModelMap Mmap, HttpSession session,HttpServletRequest request,
				@RequestParam(value = "msg", required = false) String msg) {
	 
		  Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
			
		  String es_begindate = session.getAttribute("es_begin_dateshow") == "" ? ""
					: session.getAttribute("es_begin_dateshow").toString();
		  
		  
		  System.out.println("es_begindate============="+es_begindate);
			int ec_exam_id = Integer.parseInt(
					session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
			if (ec_exam_id != 0) {
			if (ec_exam_id == 2) {
		
				Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));

			}
			if (!es_begindate.equals("")) {
				Mmap.put("es_begindate", es_begindate);
			}
			}
			Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
			if (flashMap != null) {
				ArrayList<ArrayList<String>> errorList = (ArrayList<ArrayList<String>>) flashMap.get("errorlist");
				// return "home";
				Mmap.put("errorList", errorList);
			}
			Mmap.put("msg", msg);
     return new ModelAndView("ImportPartDMArks_tile");
}
	  
	  
		
		
		// Download DEMO EXCEL
		@RequestMapping(value = "/DemoCandidateExcelFORUploadPartD_MArsk", method = RequestMethod.POST)
		public ModelAndView DemoCandidateExcelFORUploadPartD_MArsk(HttpServletRequest request,ModelMap model,HttpSession session,String typeReport1) {
			 

			ArrayList<ArrayList<String>> listexport = new ArrayList<ArrayList<String>>();
			List<String> TH = new ArrayList<String>();

			TH.add("SER_NO");
			TH.add("APPLICATION_NO");
			TH.add("MONTH_YEAR");
			TH.add("CENTER_CODE");
			TH.add("MARKS");
			TH.add("ARM_SERVICE");
			TH.add("COMMAND");
			TH.add("SUBJECT");
			TH.add("GENDER");
			TH.add("STATUS");
			TH.add("MOBILE_NO");

			String Heading = "\n";
			String username = session.getAttribute("username").toString();
			return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList", listexport);
		}

		// UPLOAD CANDIDATE DATA
		@RequestMapping(value = "/UploadPartDMarksAction", method = RequestMethod.POST)
		public ModelAndView UploadPartDMarksAction(HttpServletRequest request, ModelMap model, HttpSession session,
				@RequestParam(value = "fileUpload", required = false) MultipartFile fileUpload,
				RedirectAttributes ra) {

			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			
			

			ArrayList<ArrayList<String>> listerror = new ArrayList<ArrayList<String>>();
			try {
				String userId = session.getAttribute("userId").toString();
				String in_sub_id = request.getParameter("subject_id");
				if (in_sub_id.equals("0")) {
					ra.addAttribute("msg", "Please Select Subject");
					return new ModelAndView("redirect:UploadPartDMarksURL");
				}
				if (fileUpload.isEmpty()) {
					ra.addAttribute("msg", "Please Choose File");
					return new ModelAndView("redirect:UploadPartDMarksURL");
				}
//				String file = request.getParameter("fileUpload");
//				if (file.equals("")) {
//					ra.addAttribute("msg", "Please Upload Copy Of File Upload For Part B Marks");
//					return new ModelAndView("redirect:UploadPartBMarksURL");
//				}
				Date date = new Date();
				String username = session.getAttribute("username").toString();

				int count = Integer.parseInt(request.getParameter("count"));

				int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
				int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
				 String es_begindate = session.getAttribute("es_begin_date") == "" ? "": session.getAttribute("es_begin_date").toString();
					String es_year1 = es_begindate.split("-")[0];
				ANSWER_BOOK_M ansbook = new ANSWER_BOOK_M();

				String errormsg = "";
				List<INDEXING_SETTING> bundledetails = comm.getbundledetailsforindexing(sessionFactory, es_id);


				if (!bundledetails.isEmpty()) {
					int bundleminno = bundledetails.get(0).getIst_min_indexno();
					int bundlemaxno = bundledetails.get(0).getIst_max_indexno();
					int bundlepacking_size = bundledetails.get(0).getIst_maxbundle_package();
					int answerbookbundleSize = bundledetails.get(0).getIst_maxab_bundle();
					int ibmid = 0;
					int indexNo = bundleminno;
					ArrayList<ArrayList<String>> totalindexList = indexDao.GetCountforIndexing(es_id,
							Integer.parseInt(in_sub_id));
					String S_totalindex = totalindexList.get(0).get(0);
					long totalindex = Long.parseLong(S_totalindex);
					INDEX_NO in = new INDEX_NO();
					List<INDEX_NO> indexno = comm.getIndexNoByEsid(sessionFactory, es_id);
					if (totalindex != 0) {
						in = comm.getIndexNoByEsid(sessionFactory, es_id).get(0);

					} else {

						if (indexno.isEmpty()) {
							in.setEs_id(es_id);
							in.setIndex_no(bundleminno);
							int inid = (int) sessionHQL.save(in);
							in.setId(inid);
						} else {
							in = indexno.get(0);
							indexNo = indexno.get(0).getIndex_no();
						}
					}

					int ismid = 0;
					int ibm_abcount = 1;
					int ibm_bundleno = 1;
					int errorcount=0;
					int j2 = (int) (totalindex + 1);
					
					

					File file = new File(comm.fileupload2(fileUpload.getBytes(), fileUpload.getOriginalFilename(), "doc_contract",""));
					FileInputStream fis = new FileInputStream(file);
					@SuppressWarnings("resource")
					XSSFWorkbook wb = new XSSFWorkbook(fis);
					XSSFSheet sheet = wb.getSheetAt(0);
					Row row_head = sheet.getRow(0);
					

					for (int i = 1; i <= sheet.getLastRowNum(); i++) {
//					for (int i = 0; i < count; i++) {

						Row row = sheet.getRow(i);
						

						String month_year = "";
						String status = "";
						String arm_service="";
						String gender="";
						String  personal_no="";
						String mobile_no="";
						String application_no="";
						String Excel_subject_id="";
						String command="";
						String marks="";
						String center_code ="";
						
						if (row.getCell(0) == null) {
							break;
						}
						
						for (int j = 1; j < 10; j++) {

							Cell cell = row.getCell(j);
							
							

							String value = "";
							switch (cell.getCellType()) {
							case Cell.CELL_TYPE_STRING:
								value = cell.getStringCellValue();
								break;
							case Cell.CELL_TYPE_NUMERIC:
								if (HSSFDateUtil.isCellDateFormatted(cell)) {
									value = String.valueOf(cell.getDateCellValue());
								} else {
									value = String.valueOf((long) cell.getNumericCellValue());
								}
								break;
							case Cell.CELL_TYPE_BOOLEAN:
								value = String.valueOf(cell.getBooleanCellValue());
								break;
							default:
							}
						
				
							
							if (row_head.getCell(j).getStringCellValue().equals("APPLICATION_NO")) {
								application_no=value;
							}
							if (row_head.getCell(j).getStringCellValue ().equals("MONTH_YEAR")) {
								month_year=value;
								
							}
							if (row_head.getCell(j).getStringCellValue().equals("CENTER_CODE")) {
								center_code=value;
						     }
							
							if (row_head.getCell(j).getStringCellValue().equals("MARKS")) {
								marks=value;
							}
							
							if (row_head.getCell(j).getStringCellValue().equals("ARM_SERVICE")) {
								arm_service=value;
							}
							if (row_head.getCell(j).getStringCellValue().equals("COMMAND")) {
								command=value;
								
								
							}
							
							if (row_head.getCell(j).getStringCellValue().equals("SUBJECT")) {
								Excel_subject_id=value;
							
						
								
							}
							
							if (row_head.getCell(j).getStringCellValue().equals("GENDER")) {
								gender=value;
								
								}
							
							
							if (row_head.getCell(j).getStringCellValue().equals("STATUS")) {
								
								status=value;
									
								}
							
							
							if (row_head.getCell(j).getStringCellValue().equals("MOBILE_NO")) {
								mobile_no=value;
							    
								}		
							
							
						}
						ArrayList<String> listData = new ArrayList<String>();
						
						
					
						List<OFFICER_APPLICATION_M> opdpers_id = comm.getOpdIdbyOappId(sessionFactory,
								Integer.parseInt(application_no), es_id);
						
						
				
					
					
					

//						List<SUBJECT_CODE_M> SubjectIdBySubName = comm.getSubjectIdBySubName(sessionFactory, sub_name,
//								ec_exam_id);
//						int excel_sub_id = SubjectIdBySubName.get(0).getSc_subject_id();

						if (opdpers_id.isEmpty()) {
							listData.add(application_no);
							listData.add(month_year);
							listData.add(center_code);
							listData.add(marks);
							listData.add(arm_service);
							listData.add(command);
							listData.add(Excel_subject_id);
							listData.add(gender);
							listData.add(status);
							
							
						
						
							listData.add("The Application Number is Wrong");
							errormsg = application_no + "The Personal Number is Wrong";
							model.put("msg", errormsg);
							errorcount++;

						} else {
							int opd_pers_id = opdpers_id.get(0).getOpd_personal_id();
							List<OFFICER_APPLICATION_M> Oapp_id = comm.getOappIdbyopdId(sessionFactory, opd_pers_id, es_id);
							int ofid = Oapp_id.get(0).getOa_application_id();
							List<SUBJECT_CODE_M> subjectlist = comm.getsubjectIdbysubname(sessionFactory, Integer.parseInt(Excel_subject_id),
									ec_exam_id);
							int excel_sub_code = subjectlist.get(0).getSc_subject_code();
							String M_es_year = month_year.split("-")[1];

							
							List<OFFICER_PERSONAL_CODE_M> personal_code = comm.getPersCodebyOpdID(sessionFactory,
									opd_pers_id);
							String opc_personal_code = personal_code.get(0).getOpc_personal_code();
							
							
							List<OFFICER_PERSONAL_DETAILS_M> ofc_pbdaSubCode = comm.getpbdasumbyopdid(sessionFactory,opd_pers_id);
							int pbda_subject_code = ofc_pbdaSubCode.get(0).getPbda_sub_code();

							

							List<SUBJECT_CODE_M> ExamWiseSubjectlist = comm.getsubjectlist(sessionFactory, ec_exam_id);
							ArrayList<Integer> subtotallist = Part_b_examinationController.getsubjectListFromTotal(pbda_subject_code, ExamWiseSubjectlist);
							
							



						  	if(es_year1.equals(M_es_year)) {
						  		
						  		if(Integer.parseInt(in_sub_id) == Integer.parseInt(Excel_subject_id) ) {
						  			if(subtotallist.contains(excel_sub_code)) {
						

							int r_index_no = (int) (Math.random() * (bundlemaxno - bundleminno + 1) + bundleminno);

							if (Oapp_id.get(0).getIn_index_id() == 0) {
								INDEX_SLIP_MASTER index_slip_m = new INDEX_SLIP_MASTER();
								index_slip_m.setIsm_armyno(opc_personal_code);
								index_slip_m.setIsm_dtcreateddate(date);
								index_slip_m.setIsm_es_id(es_id);
								index_slip_m.setIsm_indexno(r_index_no);
								index_slip_m.setCenter_code(Integer.parseInt(center_code));
								index_slip_m.setCommand_id(Integer.parseInt(command));
								index_slip_m.setIsm_userid(Integer.parseInt(userId));
								ismid = (int) sessionHQL.save(index_slip_m);

								String hq15 = "update OFFICER_APPLICATION_M set oa_center_granted=:oa_center_granted, in_index_id=:in_index_id where oa_application_id=:oa_application_id and es_id=:es_id ";
								Query query5 = sessionHQL.createQuery(hq15)
										.setParameter("oa_center_granted", Integer.parseInt(center_code))
										.setParameter("in_index_id", r_index_no)

										.setParameter("oa_application_id", ofid).setParameter("es_id", es_id);
								query5.executeUpdate();

							} else {
								List<INDEX_SLIP_MASTER> ISL = comm.getIndexNoByICnumber(sessionFactory, opc_personal_code,
										String.valueOf(es_id));
								if (!ISL.isEmpty())
									ismid = ISL.get(0).getIsm_id();

							}

							INDEX_SLIP_MANUAL ism = new INDEX_SLIP_MANUAL();
							int id_slip = ism.getIs_id() > 0 ? ism.getIs_id() : 0;
							Query q0 = sessionHQL.createQuery(
									"select count(is_id) from INDEX_SLIP_MANUAL where   is_ism_id=:is_ism_id and  is_sc_subject_id=:is_sc_subject_id and is_id!=:is_id");

							q0.setParameter("is_ism_id", ismid);
							q0.setParameter("is_sc_subject_id", Integer.parseInt(Excel_subject_id));
							q0.setParameter("is_id", id_slip);
							Long c = (Long) q0.uniqueResult();


							if (c == 0) {
								if (j2 % answerbookbundleSize == 1) {

									INDEXED_BUNDLE_MASTER ibm = new INDEXED_BUNDLE_MASTER();
									ibm_abcount = 1;
									ibm.setIbm_abcount(ibm_abcount);
									ibm.setIbm_bundle_no(String.valueOf(ibm_bundleno));
									ibm.setIbm_bundle_prefix("A");
									ibm.setIbm_es_id(es_id);
									ibm.setIbm_nsubjectid(Integer.parseInt(Excel_subject_id));
									ibm.setIbm_ac_arm_id(0);
									ibm.setIbm_iu_user_id(Integer.parseInt(userId));
									ibmid = (int) sessionHQL.save(ibm);
									ibm_bundleno++;

								} else {

									List<INDEXED_BUNDLE_MASTER> IBM = comm.getbundlemsterId(sessionFactory, es_id,
											Integer.parseInt(Excel_subject_id));

									if (!IBM.isEmpty())
										ibmid = IBM.get(0).getIbm_id();

									INDEXED_BUNDLE_MASTER ibmold = sessionHQL.get(INDEXED_BUNDLE_MASTER.class, ibmid);

									ibmold.setIbm_abcount(++ibm_abcount);
									sessionHQL.saveOrUpdate(ibmold);
//									 

								}

								if (j2 % (bundlepacking_size) == 1) {

									INDEXED_PACKING_NOTES_MASTER ipnm = new INDEXED_PACKING_NOTES_MASTER();
									ipnm.setIpnm_bag_no("A");
									ipnm.setIpnm_es_id(es_id);
									ipnm.setIpnm_no("1");
									ipnm.setIpnm_createddate(date);
									ipnm.setIpnm_iu_user_id(Integer.parseInt(userId));
									int ipnmid = (int) sessionHQL.save(ipnm);

									INDEXED_PACKING_NOTES_DETAILS ipnd = new INDEXED_PACKING_NOTES_DETAILS();

									ipnd.setIpnd_ibm_id(ibmid);
									ipnd.setIpnd_ipnm_id(ipnmid);

									int ipndid = (int) sessionHQL.save(ipnd);

									KITBAGMASTER kitbag = new KITBAGMASTER();
									kitbag.setKbm_bagname("A");
									kitbag.setKbm_es_id(es_id);
									kitbag.setKbm_sc_subject_id(Integer.parseInt(Excel_subject_id));
									kitbag.setKbm_createdate(date);
									kitbag.setKbm_status(1);
									kitbag.setKbm_ipnm_id(ipnmid);
									kitbag.setKbm_iu_user_id(Integer.parseInt(userId));
									int kitbagid = (int) sessionHQL.save(kitbag);
								}

								ism.setIs_abs(0);
								ism.setIs_ac_arm_id(Integer.parseInt(arm_service));
								ism.setIs_commandid(Integer.parseInt(command));
								ism.setIs_ecc_center_code(Integer.parseInt(center_code));
								ism.setIs_sc_subject_id(Integer.parseInt(Excel_subject_id));
								ism.setIs_status(1);
								ism.setIs_ibm_id(ibmid);
								ism.setIs_ism_id(ismid);
								ism.setIs_iu_user_id(Integer.parseInt(userId));
								int ismaid = (int) sessionHQL.save(ism);

								INDEX_SLIP_SCANNED iss = new INDEX_SLIP_SCANNED();
								iss.setIs_armyno(opc_personal_code);
								iss.setIs_ac_arm_id(arm_service);
								iss.setIs_commandcode(command);
								iss.setIs_ecc_center_code(center_code);
								iss.setIs_es_id(String.valueOf(es_id));
								iss.setIs_sc_subject_id(String.valueOf(Integer.parseInt(Excel_subject_id)));
								iss.setIs_ic_user_id(Integer.parseInt(userId));
								int issID = (int) sessionHQL.save(iss);

								INDEXED_BUNDLE_DETAILS ibd = new INDEXED_BUNDLE_DETAILS();
								ibd.setIbd_ibm_id(ibmid);
								ibd.setIbm_is_id(ismid);
								ibd.setCreated_by(username);
								ibd.setCreated_date(date);
								int ibdid = (int) sessionHQL.save(ibd);

								in.setIndex_no(indexNo);
								sessionHQL.saveOrUpdate(in);

								j2++;

								List<OFFICER_ARM_M> pers_armID = comm.getarmcode(sessionFactory, opd_pers_id);
								int pers_armId = pers_armID.get(0).getAc_arm_id();

//								ArrayList<ArrayList<String>> ForPartbubjectList = PartBDAo.getSubjectList("Part D",
//										String.valueOf(pers_armId));
//								int PartD_SubCode = 0;
//								for (int i1 = 0; i1 < ForPartbubjectList.size(); i1++) {
//
//									String sub = ForPartbubjectList.get(i1).get(2);
//
//									PartD_SubCode += Integer.parseInt(sub);
//
//								}
								int O_app_id = Oapp_id.get(0).getOa_application_id();

							
								

								Session sessionHQL3 = this.sessionFactory.openSession();
								Transaction tx3 = sessionHQL3.beginTransaction();
								OFFICER_RESULTS_M off_result = new OFFICER_RESULTS_M();
								if (!status.equals("R")) {
									
									
									Session sessionHQL4 = this.sessionFactory.openSession();
									Transaction tx4 = sessionHQL4.beginTransaction();
									
									UNFAIR_MEANS_M ln = new UNFAIR_MEANS_M();
									ln.setUm_created_by(username);
									ln.setUm_creation_date(date);
									ln.setEs_id(es_id);
									ln.setOpd_personal_id(opd_pers_id);
									ln.setSc_subject_id(Integer.parseInt(Excel_subject_id));
									ln.setUm_status_id(1);
									sessionHQL4.save(ln);

									ansbook.setAb_marks_obtained(0);
									ansbook.setAb_created_by(username);
									ansbook.setAb_creation_date(date);
									ansbook.setAb_status_id(3);
									ansbook.setAb_unfair_status(1);
									ansbook.setOa_application_id(O_app_id);
									ansbook.setSc_subject_id(Integer.parseInt(Excel_subject_id));
									ansbook.setAb_first_entry(0);
									sessionHQL4.save(ansbook);

									String hq1uf = "update OFFICER_PERSONAL_DETAILS_M set opd_gender=:opd_gender, opd_status_id=:opd_status_id, mobile_no=:mobile_no  where opd_personal_id=:opd_personal_id ";
									Query queryuf = sessionHQL4.createQuery(hq1uf).setParameter("opd_gender", Integer.parseInt(gender))
											.setParameter("opd_status_id", 3)
											.setParameter("mobile_no", mobile_no)
											.setParameter("opd_personal_id", opd_pers_id);
									queryuf.executeUpdate();
									
									off_result.setOr_subject_pass(0);
									off_result.setEs_id(es_id);
									off_result.setSc_subject_id(Integer.parseInt(Excel_subject_id));
									off_result.setOpd_personal_id(opd_pers_id);
									sessionHQL4.save(off_result);
									sessionHQL4.flush();
									sessionHQL4.clear();

									tx4.commit();
									sessionHQL4.close();

								}

								else {
									
									

									String hq142 = "update OFFICER_PERSONAL_DETAILS_M set opd_gender=:opd_gender,opd_status_id=:opd_status_id, mobile_no=:mobile_no where opd_personal_id=:opd_personal_id ";
									Query query42 = sessionHQL3.createQuery(hq142).setParameter("opd_gender", Integer.parseInt(gender))
											.setParameter("opd_status_id", 1)
											.setParameter("mobile_no", mobile_no)
											.setParameter("opd_personal_id", opd_pers_id);
									query42.executeUpdate();

									ansbook.setAb_marks_obtained(Integer.parseInt(marks));
									ansbook.setAb_created_by(username);
									ansbook.setAb_creation_date(date);
									ansbook.setAb_status_id(0);
									ansbook.setOa_application_id(O_app_id);
									ansbook.setSc_subject_id(Integer.parseInt(Excel_subject_id));
									ansbook.setAb_first_entry(Integer.parseInt(marks));
									ansbook.setAb_unfair_status(0);
									sessionHQL3.save(ansbook);

									ArrayList<ArrayList<String>> pass_marks = partBmarksDao.PartBOfficerresult(es_id,
											Integer.parseInt(Excel_subject_id));

									String passingmarks = pass_marks.get(0).get(0);
									
									int latest_pbdacode=0;
								
									if (Integer.parseInt(passingmarks) <= Integer.parseInt(marks)) {
										
										off_result.setOr_subject_pass(1);

										latest_pbdacode= pbda_subject_code - excel_sub_code;
										String hq14 = "update OFFICER_PERSONAL_DETAILS_M set pbda_sub_code=:pbda_sub_code  where opd_personal_id=:opd_personal_id ";
										Query query4 = sessionHQL3.createQuery(hq14)
												.setParameter("pbda_sub_code", pbda_subject_code - excel_sub_code)
												.setParameter("opd_personal_id", opd_pers_id);
										query4.executeUpdate();

									}

									else {
										latest_pbdacode=pbda_subject_code;
										off_result.setOr_subject_pass(0);
									}

									off_result.setEs_id(es_id);
									off_result.setSc_subject_id(Integer.parseInt(Excel_subject_id));
									off_result.setOpd_personal_id(opd_pers_id);

									sessionHQL3.save(off_result);

									sessionHQL3.flush();
									sessionHQL3.clear();

									tx3.commit();
									sessionHQL3.close();

									Session sessionHQL1 = this.sessionFactory.openSession();
									Transaction tx1 = sessionHQL1.beginTransaction();

									List<SUBJECT_CODE_M> subjectList = comm.getsubjectlist(sessionFactory, ec_exam_id);
									int sub_size = subjectList.size();
							System.err.println("lates_pbdacode================="+latest_pbdacode);
							
									Query q02 = sessionHQL1.createQuery(
											"select count(id) from OFFICER_RESULTS_M  where or_subject_pass=:or_subject_pass and opd_personal_id=:opd_personal_id ");
									q02.setParameter("or_subject_pass", 1);
									q02.setParameter("opd_personal_id", opd_pers_id);
									Long c2 = (Long) q02.uniqueResult();

									if (latest_pbdacode == 0) {
										String hq16 = "update OFFICER_PERSONAL_DETAILS_M set opd_partd=:opd_partd,pbda_sub_code=:pbda_sub_code   where opd_personal_id=:opd_personal_id ";
										Query query6 = sessionHQL1.createQuery(hq16)
												.setParameter("opd_partd", Integer.parseInt(es_year1))
												.setParameter("pbda_sub_code", 0)
												.setParameter("opd_personal_id", opd_pers_id);
										query6.executeUpdate();

									}

									tx1.commit();
									sessionHQL1.close();

									ra.addAttribute("msg", "Data Saved Successfully");
								}
								
							}
							
						  			}
								else {
									listData.add(application_no);
									listData.add(month_year);
									listData.add(center_code);
									listData.add(marks);
									listData.add(arm_service);
									listData.add(command);
									listData.add(Excel_subject_id);
									listData.add(gender);
									listData.add(status);
									 listData.add("You are Not Eligible for this Subject");
									
					  				model.put("msg", "You are Not Eligible for this Subject");
					  			}
					  		}	else {
					  			listData.add(application_no);
								listData.add(month_year);
								listData.add(center_code);
								listData.add(marks);
								listData.add(arm_service);
								listData.add(command);
								listData.add(Excel_subject_id);
								listData.add(gender);
								listData.add(status);
								 listData.add("Subject is Not Matched");
								
					  			model.put("msg", "Subject is Not Matched");
					  		}
					}else {
						
						
						listData.add(application_no);
						listData.add(month_year);
						listData.add(center_code);
						listData.add(marks);
						listData.add(arm_service);
						listData.add(command);
						listData.add(Excel_subject_id);
						listData.add(gender);
						listData.add(status);
						 listData.add("Exam Schedule Not Matched with Current Exam Schedule");
					
						model.put("msg", "Exam Schedule Not Matched with Current Exam Schedule.");
					}
							
						}
						if(!listData.isEmpty()) {
							listerror.add(listData);
						}
					}
					
				}else {
					
					 ra.addAttribute("msg","Please Enter the  Details in Indexing Setting");
				}
				model.put("errorlist", listerror);
				model.put("errorlistsize", listerror.size());
				tx.commit();
			}

			catch (Exception e) {
				tx.rollback();
				e.printStackTrace();
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}
			ra.addFlashAttribute("errorlist", listerror);
			ra.addFlashAttribute("errorlistsize", listerror.size());
			return new ModelAndView("redirect:UploadPartDMarksURL");
		}
		
		 @RequestMapping(value = "/PartD_MARKSAction" ,method = RequestMethod.POST) 
		  public ModelAndView PartD_MARKSAction( @ModelAttribute("PartBMarksCMD") ANSWER_BOOK_M ab, BindingResult result, 
		  HttpServletRequest request, ModelMap model, HttpSession session){ 
		
				Session sessionHQL = this.sessionFactory.openSession();
		
			try {
			
				
				Transaction tx = sessionHQL.beginTransaction();
				Date date = new Date();
				String username = session.getAttribute("username").toString();

			
				int id = ab.getId() > 0 ? ab.getId() : 0;
				
				
				
				String pers_code = request.getParameter("opd_personal_id");
				List<OFFICER_PERSONAL_CODE_M> opdpers_id= comm.getopdIdbycode( sessionFactory, pers_code);
				int opd_pers_id= opdpers_id.get(0).getOpd_personal_id();
				
				
				  int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
			
				
				List<OFFICER_APPLICATION_M> Oapp_id= comm.getOappIdbyopdId( sessionFactory, opd_pers_id,es_id);
				int O_app_id= Oapp_id.get(0).getOa_application_id();
				int Sc_subjectid = Integer.parseInt(request.getParameter("sc_subject_id"));
				int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0": session.getAttribute("ec_exam_id").toString());
				List<SUBJECT_CODE_M> sublist=comm.getsubjectIdbysubname(sessionFactory,Sc_subjectid,ec_exam_id);
				
				
				List<OFFICER_PERSONAL_DETAILS_M> pbda_sumBy_opdId= comm.getpbdasumbyopdid( sessionFactory, opd_pers_id);
				
				int pbda_subject_code= pbda_sumBy_opdId.get(0).getPbda_sub_code();
				
				int subjectId = sublist.get(0).getSc_subject_id();
				
				int sub_code= sublist.get(0).getSc_subject_code();
				
				
				
				List<OFFICER_ARM_M> pers_armID= comm.getarmcode( sessionFactory, opd_pers_id);
				int pers_armId= pers_armID.get(0).getAc_arm_id();
//				ArrayList<ArrayList<String>> ForPartDSubjectList = PartBDAo.getSubjectList("Part D",String.valueOf(pers_armId));
//				 int PartD_SubCode = 0;
//		            for (int i1=0;i1<ForPartDSubjectList.size();i1++) {
//		            	System.err.println(ForPartDSubjectList.get(i1).get(2));
//		            	
//		            	String sub= ForPartDSubjectList.get(i1).get(2);
//		          
//		            	PartD_SubCode += Integer.parseInt(sub);
//		            	 
//		            	 
//		            }
		            
		            
		            List<SUBJECT_CODE_M> ExamWiseSubjectlist = comm.getsubjectlist(sessionFactory, ec_exam_id);
					ArrayList<Integer> subtotallist = Part_b_examinationController.getsubjectListFromTotal(pbda_subject_code, ExamWiseSubjectlist);
					

				Query q0 = sessionHQL.createQuery(
						"select count(id) from ANSWER_BOOK_M where  (oa_application_id=:oa_application_id and sc_subject_id=:sc_subject_id) and id!=:id");
				
				q0.setParameter("oa_application_id", O_app_id);
				q0.setParameter("sc_subject_id",Sc_subjectid );
				q0.setParameter("id",id );
			
				Long c = (Long) q0.uniqueResult();
					
					if (c == 0) {
						
						
						if(subtotallist.contains(sub_code)) {
				
				ANSWER_BOOK_M ansbook = new ANSWER_BOOK_M();
				
			String marks= request.getParameter("partb_marks");
				ansbook.setAb_marks_obtained(Integer.parseInt(marks));
				ansbook.setAb_created_by(username);
				ansbook.setAb_creation_date(date);
				ansbook.setAb_status_id(1);
				ansbook.setOa_application_id(O_app_id);
				ansbook.setSc_subject_id(Sc_subjectid);
				sessionHQL.save(ansbook);
			String es_begindate = session.getAttribute("es_begin_date") == "" ? "": session.getAttribute("es_begin_date").toString();
				
				 
				   
				   ArrayList<ArrayList<String>> pass_marks = partBmarksDao.PartBOfficerresult(es_id, subjectId);
				   
				   
				   String passingmarks= pass_marks.get(0).get(0);
				   
				OFFICER_RESULTS_M off_result= new OFFICER_RESULTS_M();
				
				if(Integer.parseInt(passingmarks) <= Integer.parseInt( marks )  ) {
					
					off_result.setOr_subject_pass(1);
					
					String hq14 = "update OFFICER_PERSONAL_DETAILS_M set pbda_sub_code=:pbda_sub_code  where opd_personal_id=:opd_personal_id ";
					Query query4 = sessionHQL.createQuery(hq14)
								.setParameter("pbda_sub_code", pbda_subject_code - sub_code)			
								.setParameter("opd_personal_id",   opd_pers_id);
					query4.executeUpdate();
					
				}
				
				if(Integer.parseInt(passingmarks) >=  Integer.parseInt( marks )) {
					
					off_result.setOr_subject_pass(0);
				}
				
				
				
				
				off_result.setEs_id(es_id);
				off_result.setSc_subject_id(subjectId);
				off_result.setOpd_personal_id(opd_pers_id);
				
				sessionHQL.save(off_result);
				
				sessionHQL.flush();
				 sessionHQL.clear();
			
				
				
					tx.commit();
				
				
				
			

				
					Session sessionHQL1 = this.sessionFactory.openSession();
					Transaction tx1 = sessionHQL1.beginTransaction();
					
					List<SUBJECT_CODE_M>subjectList= comm.getsubjectlist(sessionFactory, ec_exam_id);
					int sub_size= subjectList.size();
				      String es_year= es_begindate.split("-")[0];
				  	System.err.println("es_year=========="+es_year);
				  	
				  	
				  	
					Query q01 = sessionHQL1.createQuery("select count(id) from OFFICER_RESULTS_M  where or_subject_pass=:or_subject_pass and opd_personal_id=:opd_personal_id ");
					q01.setParameter("or_subject_pass",1 );
					q01.setParameter("opd_personal_id",opd_pers_id );
					Long c1 = (Long) q01.uniqueResult();
					
					System.err.println("c1========="+c1);
					if(c1 == sub_size) {
						String hq16 = "update OFFICER_PERSONAL_DETAILS_M set opd_partd=:opd_partd  where opd_personal_id=:opd_personal_id ";
						Query query6 = sessionHQL1.createQuery(hq16)
									.setParameter("opd_partd",Integer.parseInt(es_year) )	
									.setParameter("opd_personal_id",   opd_pers_id);
						query6.executeUpdate();
						
						
					}
				
					tx1.commit();		
					model.put("msg", "Data Saved Successfully.");
					}
					else {
						
						model.put("msg", "You are Not Eligible for this Subject");
					}
						
					}
					
					else {
						model.put("msg", "Data Already Exits.");
					}
				
				}		
					
			
				
			
			
			 catch (Exception e) {
				//tx.rollback();
				e.printStackTrace();
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}
			return new ModelAndView("redirect:PartD_marks_Url");
		}	
		  
		 @RequestMapping(value = "EditPartDMarksURL", method = RequestMethod.POST)
         public ModelAndView EditPartDMarksURL(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) 
         String msg,String updateid, String subjectid,HttpServletRequest request) {


			 
			 
                Session s1 = this.sessionFactory.openSession();
                Transaction tx = s1.beginTransaction();
                String enckey = "commonPwdEncKeys";  
                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
                System.err.println("subjectid==============="+subjectid);
               
                
            
                String es_begindate = session.getAttribute("es_begin_date") == "" ? ""
        				: session.getAttribute("es_begin_date").toString();
        		int ec_exam_id = Integer.parseInt(
        				session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
        		Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
        		Mmap.put("es_begindate", es_begindate.substring(0, 10));
        		
        		Mmap.put("EditPartBMarks_details",partBmarksDao.getpartbMarksdtl(DcryptedPk,subjectid));
        		Mmap.put("updateid", DcryptedPk);
                
                
         return new ModelAndView("EditPartD_marks_tile","EditPartDMarksCMD",new PARTB_D_APPLICATION_M());
}
	    
	    
	    @RequestMapping(value = "/EditPartD_MARKSAction" ,method = RequestMethod.POST) 
	    public ModelAndView EditPartD_MARKSAction(@Valid @ModelAttribute("EditPartDMarksCMD") OFFICER_PERSONAL_DETAILS_M ln, BindingResult result, 
	    HttpServletRequest request, ModelMap model, HttpSession session){ 

	   
	   

	   
	      Session sessionHQL = this.sessionFactory.openSession(); 
	      Transaction tx = sessionHQL.beginTransaction(); 
	      
	      Date date = new Date();
	  	String username = session.getAttribute("username").toString();
	  	

	  	
	  	
	  	
	    String opd_personalcode =request.getParameter("opd_personal_id");
	    System.err.println("opd_personalcode============="+opd_personalcode);
	      String index_no= request.getParameter("index_no");
	  	String sc_subject_id = request.getParameter("sc_subject_id");
	      String marks= request.getParameter("marks");
	      String oapp_id= request.getParameter("update_id");
	        
	      if (index_no == "" || index_no.equals("")) {
				model.put("msg", " Please Enter Index No ");
				return new ModelAndView("redirect:PartD_marks_Url");
			}
	        
	      if (marks == "" || marks.equals("")) {
				model.put("msg", " Please Enter Marks ");
				return new ModelAndView("redirect:PartD_marks_Url");
			}
	      
	  	try {
	  	String hql = "update ANSWER_BOOK_M set sc_subject_id=:sc_subject_id,ab_marks_obtained=:ab_marks_obtained, ab_status_id=:ab_status_id,"
	  	   + "ab_modified_by=:ab_modified_by,ab_modification_date=:ab_modification_date  where oa_application_id=:oa_application_id and sc_subject_id=:sc_subject_id";
	  	Query query = sessionHQL.createQuery(hql)
	  				.setParameter("sc_subject_id", Integer.parseInt(sc_subject_id))	
	  				.setParameter("ab_marks_obtained", Integer.parseInt(marks))		
	  				.setParameter("ab_status_id", 1)		
	  				.setParameter("ab_modified_by", username)	
	  				.setParameter("ab_modification_date", date)	
	  				.setParameter("oa_application_id", Integer.parseInt(oapp_id))
	  				.setParameter("sc_subject_id", Integer.parseInt(sc_subject_id));
	  		query.executeUpdate();
	  		
	  		
	  		
	  
			int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0": session.getAttribute("ec_exam_id").toString());
			List<SUBJECT_CODE_M> sublist=comm.getsubjectIdbysubname(sessionFactory,Integer.parseInt(sc_subject_id),ec_exam_id);
			
			List<OFFICER_PERSONAL_CODE_M> opd_id=  comm.getopdIdbycode( sessionFactory, opd_personalcode);
			int opd_pers_id= opd_id.get(0).getOpd_personal_id();
			System.err.println("opd_pers_id============="+opd_pers_id);
			List<OFFICER_PERSONAL_DETAILS_M> pbda_sumBy_opdId= comm.getpbdasumbyopdid( sessionFactory, opd_pers_id);
			
			int pbda_sub= pbda_sumBy_opdId.get(0).getPbda_sub_code();
			
			
			int sub_code= sublist.get(0).getSc_subject_code();
	  		
	  	  int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
		   
		   ArrayList<ArrayList<String>> pass_marks = partBmarksDao.PartBOfficerresult(es_id, Integer.parseInt(sc_subject_id));
		   
		   
		   String passingmarks= pass_marks.get(0).get(0);
		   
		OFFICER_RESULTS_M off_result= new OFFICER_RESULTS_M();
		
		if(Integer.parseInt(passingmarks) <= Integer.parseInt( marks ) || Integer.parseInt(passingmarks) == Integer.parseInt( marks ) ) {
			
			off_result.setOr_subject_pass(1);
			
			
			String hq13 = "update OFFICER_RESULTS_M set sc_subject_id=:sc_subject_id, or_subject_pass=:or_subject_pass  where opd_personal_id=:opd_personal_id ";
			Query query3 = sessionHQL.createQuery(hq13)
						.setParameter("sc_subject_id", Integer.parseInt(sc_subject_id))		
						.setParameter("or_subject_pass", 1)	
						.setParameter("opd_personal_id",   opd_pers_id);
			query3.executeUpdate();
			
			String hq14 = "update OFFICER_PERSONAL_DETAILS_M set pbda_sub_code=:pbda_sub_code  where opd_personal_id=:opd_personal_id ";
			Query query4 = sessionHQL.createQuery(hq14)
						.setParameter("pbda_sub_code", pbda_sub - sub_code)			
						.setParameter("opd_personal_id",   opd_pers_id);
			query4.executeUpdate();
			
		}
		
		if(Integer.parseInt(passingmarks) >=  Integer.parseInt( marks )) {
			
			
			String hq133 = "update OFFICER_RESULTS_M set sc_subject_id=:sc_subject_id, or_subject_pass=:or_subject_pass  where opd_personal_id=:opd_personal_id ";
			Query query33 = sessionHQL.createQuery(hq133)
						.setParameter("sc_subject_id", Integer.parseInt(sc_subject_id))		
						.setParameter("or_subject_pass", 0)	
						.setParameter("opd_personal_id",   opd_pers_id);
			query33.executeUpdate();
		}
		
		
		
		
		
		
					
					String hq15 = "update OFFICER_APPLICATION_M set in_index_id=:in_index_id  where opd_personal_id=:opd_personal_id and es_id=:es_id ";
					Query query5 = sessionHQL.createQuery(hq15)
								.setParameter("in_index_id", Integer.parseInt(index_no) )			
								.setParameter("opd_personal_id",   opd_pers_id)
					.setParameter("es_id",   es_id);
					query5.executeUpdate();
					
					
					
	      tx.commit(); 
	      sessionHQL.close(); 

	   
	      model.put("msg","Data Updated Successfully"); 
	  	}catch(RuntimeException e){
	  		e.printStackTrace();
	  		tx.rollback();
	  		
	  		model.put("msg","Server side Error");
	  		
	  	}
	  	        
	          return new ModelAndView("redirect:PartD_marks_Url");
	  }
	    
	    
	    
	    @RequestMapping(value = "/deletePartD_Marks_detailsUrl", method = RequestMethod.POST) 
	    public ModelAndView deletePartD_Marks_detailsUrl(String deleteid2,HttpSession session,ModelMap model) { 
	  	  
	  	  System.err.println("deleteid==========="+deleteid2);
	  		String	msg="";
	  		Session sessionHQL =  this.sessionFactory.openSession(); 
	  		Transaction	tx = sessionHQL.beginTransaction();
	        
		      Date date = new Date();
		  	String username = session.getAttribute("username").toString();
	  		  String enckey = "commonPwdEncKeys";  
	            String DcryptedPk = hex_asciiDao.decrypt((String) deleteid2,enckey,session); 
	            System.out.println(DcryptedPk+"==========DcryptedPk");
	  		try {
	  			String hql = "update ANSWER_BOOK_M set ab_status_id=:ab_status_id,"
	 			  	   + "ab_modified_by=:ab_modified_by,ab_modification_date=:ab_modification_date  where oa_application_id=:oa_application_id ";
	 			  	Query query = sessionHQL.createQuery(hql)
	 			  				.setParameter("ab_status_id", 0)		
	 			  			
	 			  				.setParameter("ab_modified_by", username)	
	 			  				.setParameter("ab_modification_date", date)	
	 			  				.setParameter("oa_application_id", Integer.parseInt(DcryptedPk));
	 			  		query.executeUpdate();
	 			  		
	 		
//	 						Query qry = ((Session) session).createQuery("delete from OFFICER_RESULTS_M where where opd_personal_id=:opd_personal_id");
//	 						int app = qry.setInteger("id", id).executeUpdate();
//	 						session.getTransaction().commit();
//	 						session.close();
//	 						if (app > 0) {
//	 							liststr.add("Data Deleted Successfully.");
//	 						} else {
//	 							liststr.add("Data not Deleted.");
//	 						}
//	 						model.put("msg", liststr.get(0));
	  				
	  				
	  			
	  				 model.put("msg",msg);
	  			     model.put("msg", "Delete Successfully");	
	  		      
	  		       tx.commit();
	  			}catch(RuntimeException e){
	  				e.printStackTrace();
	  				tx.rollback();
	  				
	  				model.put("msg","Server side Error");
	  				
	  			}
	  			        
	  		        return new ModelAndView("redirect:PartD_marks_Url");
	  		}	
		@RequestMapping(value = "/getIndexnumberByOpd_id", method = RequestMethod.POST)
		@ResponseBody public List<OFFICER_APPLICATION_M> getOappIdbyopdId(HttpSession session,ModelMap model,int opd_id, int es_id) { 
			
			
			
			
			List<OFFICER_APPLICATION_M>list2= comm.getOappIdbyopdId(sessionFactory, opd_id, es_id);
	       if(list2.get(0).getIn_index_id() !=0) {
			
		return list2; 
		}
	return null;
		}
		
		@RequestMapping(value = "/getPartDMarks", method = RequestMethod.POST)
		public @ResponseBody List<Map<String, Object>> getPartDMarks(int startPage,
				String pageLength, String Search, String orderColunm, String orderType, String sub_id,String es_id,String opd_personal_id,String officername,
				String indexno, HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException,
				NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException,
				IllegalBlockSizeException, BadPaddingException {
			
			
			System.err.println('+'+opd_personal_id);
			
			System.err.println("es_id=====dddddddddd======"+es_id);
						if(!es_id.equals("")) {
							return partBmarksDao.getPartBMarksDetails(startPage, pageLength, Search, orderColunm,orderType, sub_id, es_id,opd_personal_id,
									officername, indexno,sessionUserId);
						}
							return null;
			
		}

		@RequestMapping(value = "/getPartDMarksTotalCount", method = RequestMethod.POST)
		public @ResponseBody long getPartDMarksTotalCount(HttpSession sessionUserId, String Search,
				String sub_id,String es_id,String opd_personal_id,String officername,
				String indexno) {
			System.err.println("es_id==========="+es_id);
					if(!es_id.equals("")) {
									return partBmarksDao.getPartBMarksdetailsTotalCount(Search,sub_id,es_id,opd_personal_id,
											officername, indexno);
					}
						return 0;
		}
		
		
		@RequestMapping(value = "EditPartdMarks_Question_URL", method = RequestMethod.POST)
		public ModelAndView EditPartbMarks_Question_URL(ModelMap Mmap, HttpSession session,
				@RequestParam(value = "msg", required = false) String msg, String application_id1,String subjectid1, HttpServletRequest request) {
			
			Session s1 = this.sessionFactory.openSession();
			Transaction tx = s1.beginTransaction();
			String enckey = "commonPwdEncKeys";
			String DcryptedPk = hex_asciiDao.decrypt((String) application_id1, enckey, session);
			
			System.err.println("DcryptedPk==============="+DcryptedPk);

			String es_begindate = session.getAttribute("es_begin_dateshow") == "" ? ""
					: session.getAttribute("es_begin_dateshow").toString();
			int ec_exam_id = Integer.parseInt(
					session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			Mmap.put("es_begindate", es_begindate);

			Mmap.put("EditPartBMarks_details", partBmarksDao.getpartbMarksdtl(DcryptedPk,subjectid1));
			
			Mmap.put("ec_exam_Name", comm.getExamNamebyExmID(sessionFactory,ec_exam_id).get(0).getEc_exam_name());
			
			Mmap.put("updateid", DcryptedPk);
			Mmap.put("ansbk_status", partBmarksDao.getpartbMarksdtl(DcryptedPk,subjectid1).get(0).get(5));

			Mmap.put("questiondtl", partBmarksDao.getpartbMarksquestiondtl(subjectid1,DcryptedPk));
			
			
			int es_id = Integer
					.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

			
			ArrayList<ArrayList<String>> list = subwisesecDAO.GetSubwiseQueDetails(es_id, Integer.parseInt(subjectid1),
					"Excel");
		
			String section_count = list.get(0).get(2);
	 
			Mmap.put("section_count", section_count);
			
			Mmap.put("alldatalist", list);
			Mmap.put("list",Getlist(es_id , subjectid1 ,  DcryptedPk)); 
			
			
			
			return new ModelAndView("EditPartB_marks_Question_tile");
		}

		
		public ArrayList<ArrayList<String>> Getlist(int es_id ,String subject_id ,String oapp_id)  
		{
			ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
			
			ArrayList<ArrayList<String>> partbMarksquestiondtlList = partBmarksDao
					.getpartbMarksquestiondtl(subject_id.toString(), oapp_id.toString());

				ArrayList<ArrayList<String>> list = subwisesecDAO.GetSubwiseQueDetails(es_id, Integer.parseInt(subject_id),
						"Excel");
			
				String section_count = list.get(0).get(2);
			//	String section_count_marks = list.get(0).get(6);
				
				int qmd_qno=0;
	 
				int qmd_qno_old=0;
				
				int i1_old=0;
				
				int j1_old=0;
				
				for (int j = 0; j < Integer.parseInt(section_count); j++) {

					ArrayList<String> list1 = new ArrayList<String>();
					list1.add(""+list.get(j).get(6));
					qmd_qno=Integer.parseInt(list.get(j).get(4));
					for (int i = 0; i < partbMarksquestiondtlList.size(); i++) {
						
						System.out.println("qmd_qno========" + qmd_qno);
						
						int i1 = i + 1;
						
						if ( i1 > qmd_qno+i1_old) {
							qmd_qno_old=qmd_qno;
							i1_old=i1-1;
							break;
						}
						
						if (i1 <qmd_qno_old) {
							i1=i1_old+1;
							i = i1_old;
						}
						
						
						
						list1.add(""+i1);
						
						
						 
					}
					
					alist.add(list1);
				}
			 //System.err.println("alist============"+alist);
			return alist;
		}
		 
		
		@RequestMapping(value = "/EditPartD_MARKS_QuestionAction", method = RequestMethod.POST)
		public ModelAndView EditPartD_MARKS_QuestionAction(@Valid @ModelAttribute("EditPartBMarksCMD") OFFICER_PERSONAL_DETAILS_M ln,
				BindingResult result, HttpServletRequest request, ModelMap model, HttpSession session) {

			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();

			Date date = new Date();
			String username = session.getAttribute("username").toString();

			String opd_personalcode = request.getParameter("opd_personal_id");
			String sc_subject_id = request.getParameter("sc_subject_id");
			String marks = request.getParameter("marks");
			String oapp_id = request.getParameter("update_id");
			String ansbk_status = request.getParameter("ansbk_status");
			
			
			int totalmarks=0;
			
			
			int es_id = Integer
					.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

			
			
			if (sc_subject_id.equals("0")) {
				model.put("msg", " Please Select Centre");
				return new ModelAndView("redirect:PartD_marks_Url");

			}
			if (marks == "" || marks.equals("")) {
				model.put("msg", " Please Enter Marks ");
				return new ModelAndView("redirect:PartD_marks_Url");
			}

			int ec_exam_id = Integer.parseInt(
					session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
			
			if (ec_exam_id == 2) {
				
			
			try {
				
				
//				======================
//				qmd_qno;
//				private String qmd_marks_obtained;
//		 qmd_marks_obtained_manual;
//				private int tm_ncreatedby;
//				private Date tm_dtcreatedate;
//				private int tm_nupdateby;
//				private Date tm_updatedate;
//				private int subject_id;
//				private int oa_application_id;
				
//			===========================	Question  ===============================
				
				
				
//				String qmd_marks_obtained = request.getParameter("qmd_marks_obtained");
				String subject_id = sc_subject_id;
//				String qmd_qno = request.getParameter("qmd_qno");

				ArrayList<ArrayList<String>> partbMarksquestiondtlList = partBmarksDao
						.getpartbMarksquestiondtl(subject_id.toString(), oapp_id.toString());

				ArrayList<ArrayList<String>> list = subwisesecDAO.GetSubwiseQueDetails(es_id, Integer.parseInt(subject_id),
						"Excel");
			
				String section_count = list.get(0).get(2);
				
				int qmd_qno=0;
	 
				int qmd_qno_old=0;
				
				int i1_old=0;
				
				for (int j = 0; j < Integer.parseInt(section_count); j++) {

					int attemp = 0;
					qmd_qno=Integer.parseInt(list.get(j).get(4));
					for (int i = 0; i < partbMarksquestiondtlList.size(); i++) {
						
						System.out.println("qmd_qno========" + qmd_qno);
						
						int i1 = i + 1;
						
						if ( i1 > qmd_qno+i1_old) {
							qmd_qno_old=qmd_qno;
							i1_old=i1-1;
							break;
						}
						
						if (i1 <qmd_qno_old) {
							i1=i1_old+1;
							i = i1_old;
						}
					 
						

	 
						String qmd_marks_obtained = request.getParameter("Questionno" + i1);


						
						if(Integer.parseInt(qmd_marks_obtained)>Integer.parseInt(list.get(j).get(6))) {
							model.put("msg", "Marks out of bound");

							return new ModelAndView("redirect:PartD_marks_Url");
							}
						
						
						
						if (!qmd_marks_obtained.equals("0")) {
							
							totalmarks+=Integer.parseInt(qmd_marks_obtained);
							
							attemp++;
						}
						System.out.println("totalmarks========" + totalmarks);
						if (attemp > Integer.parseInt(list.get(j).get(7))) {
							model.put("msg", "Question out of bound");

							return new ModelAndView("redirect:PartD_marks_Url");

						}
						else {
						String hql = "update Questionwise_marks_details set qmd_marks_obtained=:qmd_marks_obtained"
								+ " where  subject_id=:subject_id and oa_application_id=:oa_application_id and qmd_qno=:qmd_qno ";
						Query query = sessionHQL.createQuery(hql).setParameter("qmd_marks_obtained", qmd_marks_obtained)
								.setParameter("qmd_qno", i1).setParameter("subject_id", Integer.parseInt(subject_id))
								.setParameter("oa_application_id", Integer.parseInt(oapp_id));
						query.executeUpdate();
						}
					}
				}
					 
//				================================================================
				
		
				
				
				
				
				
				
				
				if(ansbk_status.equals("1")) {
				String hql = "update ANSWER_BOOK_M set sc_subject_id=:sc_subject_id,ab_second_entry=:ab_second_entry,ab_marks_obtained=:ab_marks_obtained,  ab_status_id=:ab_status_id,"
						+ "ab_modified_by=:ab_modified_by,ab_modification_date=:ab_modification_date  where oa_application_id=:oa_application_id and sc_subject_id=:sc_subject_id ";
				Query query = sessionHQL.createQuery(hql).setParameter("sc_subject_id", Integer.parseInt(sc_subject_id))
						.setParameter("ab_second_entry", totalmarks).setParameter("ab_marks_obtained",  totalmarks).setParameter("ab_status_id", 1)
						.setParameter("ab_modified_by", username).setParameter("ab_modification_date", date)
						.setParameter("oa_application_id", Integer.parseInt(oapp_id)).setParameter("sc_subject_id", Integer.parseInt(sc_subject_id));
				query.executeUpdate();
				}else {
					
					String hql = "update ANSWER_BOOK_M set sc_subject_id=:sc_subject_id,ab_first_entry=:ab_first_entry,ab_marks_obtained=:ab_marks_obtained,  ab_status_id=:ab_status_id,"
							+ "ab_modified_by=:ab_modified_by,ab_modification_date=:ab_modification_date  where oa_application_id=:oa_application_id and sc_subject_id=:sc_subject_id";
					Query query = sessionHQL.createQuery(hql).setParameter("sc_subject_id", Integer.parseInt(sc_subject_id))
							.setParameter("ab_first_entry", totalmarks).setParameter("ab_marks_obtained", totalmarks).setParameter("ab_status_id", 0)
							.setParameter("ab_modified_by", username).setParameter("ab_modification_date", date)
							.setParameter("oa_application_id", Integer.parseInt(oapp_id)).setParameter("sc_subject_id", Integer.parseInt(sc_subject_id));
					query.executeUpdate();	
				}
				
				List<SUBJECT_CODE_M> sublist = comm.getsubjectIdbysubname(sessionFactory, Integer.parseInt(sc_subject_id),
						ec_exam_id);

				List<OFFICER_PERSONAL_CODE_M> opd_id = comm.getopdIdbycode(sessionFactory, opd_personalcode);
				int opd_pers_id = opd_id.get(0).getOpd_personal_id();
				List<OFFICER_PERSONAL_DETAILS_M> pbda_sumBy_opdId = comm.getpbdasumbyopdid(sessionFactory, opd_pers_id);

				int pbda_sub = pbda_sumBy_opdId.get(0).getPbda_sub_code();

				int sub_code = sublist.get(0).getSc_subject_code();

//				int es_id = Integer
//						.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

				String es_begindate = session.getAttribute("es_begin_date") == "" ? ""
						: session.getAttribute("es_begin_date").toString();

				ArrayList<ArrayList<String>> pass_marks = partBmarksDao.PartBOfficerresult(es_id,
						Integer.parseInt(sc_subject_id));

				String passingmarks = pass_marks.get(0).get(0);

				OFFICER_RESULTS_M off_result = new OFFICER_RESULTS_M();
				int latest_pbdacode=0;
				if (Integer.parseInt(passingmarks) <= totalmarks) {

					off_result.setOr_subject_pass(1);
					latest_pbdacode= pbda_sub - sub_code;
					String hq13 = "update OFFICER_RESULTS_M set  or_subject_pass=:or_subject_pass  where opd_personal_id=:opd_personal_id and sc_subject_id=:sc_subject_id ";
					Query query3 = sessionHQL.createQuery(hq13)
							
							.setParameter("or_subject_pass", 1).setParameter("opd_personal_id", opd_pers_id)
							.setParameter("sc_subject_id", Integer.parseInt(sc_subject_id));
					query3.executeUpdate();

					String hq14 = "update OFFICER_PERSONAL_DETAILS_M set pbda_sub_code=:pbda_sub_code  where opd_personal_id=:opd_personal_id ";
					Query query4 = sessionHQL.createQuery(hq14).setParameter("pbda_sub_code", pbda_sub - sub_code)
							.setParameter("opd_personal_id", opd_pers_id);
					query4.executeUpdate();

				}

				else {
					
					latest_pbdacode= pbda_sub - sub_code;

					String hq133 = "update OFFICER_RESULTS_M set or_subject_pass=:or_subject_pass  where opd_personal_id=:opd_personal_id and  sc_subject_id=:sc_subject_id";
					Query query33 = sessionHQL.createQuery(hq133)
							
							.setParameter("or_subject_pass", 0).setParameter("opd_personal_id", opd_pers_id).setParameter("sc_subject_id", Integer.parseInt(sc_subject_id));
					query33.executeUpdate();
				}



				List<OFFICER_ARM_M> pers_armID = comm.getarmcode(sessionFactory, opd_pers_id);
				int pers_armId = pers_armID.get(0).getAc_arm_id();
				ArrayList<ArrayList<String>> ForPartDSubjectList = PartBDAo.getSubjectList("Part D",
						String.valueOf(pers_armId));
				int PartD_SubCode = 0;
				for (int i1 = 0; i1 < ForPartDSubjectList.size(); i1++) {

					String sub = ForPartDSubjectList.get(i1).get(2);

					PartD_SubCode += Integer.parseInt(sub);

				}

				List<SUBJECT_CODE_M> subjectList = comm.getsubjectlist(sessionFactory, ec_exam_id);
				int sub_size = subjectList.size();
				String es_year = es_begindate.split("-")[0];

				Query q01 = sessionHQL.createQuery(
						"select count(id) from OFFICER_RESULTS_M  where or_subject_pass=:or_subject_pass and opd_personal_id=:opd_personal_id ");
				q01.setParameter("or_subject_pass", 1);
				q01.setParameter("opd_personal_id", opd_pers_id);
				Long c1 = (Long) q01.uniqueResult();
				
				if(ec_exam_id == 1) {
				if (latest_pbdacode == 0) {
					String hq16 = "update OFFICER_PERSONAL_DETAILS_M set opd_partb=:opd_partb,pbda_sub_code=:pbda_sub_code   where opd_personal_id=:opd_personal_id ";
					Query query6 = sessionHQL.createQuery(hq16).setParameter("opd_partb", Integer.parseInt(es_year))
							.setParameter("pbda_sub_code", PartD_SubCode).setParameter("opd_personal_id", opd_pers_id);
					query6.executeUpdate();
				}
					
					ArrayList<ArrayList<String>> Fully_list = partbreportDao.getFullyPassedForPartB(es_id, String.valueOf(oapp_id));
					
					ArrayList<ArrayList<String>> getSerno = resDao.getLatestSerno(es_id,1);
					String ser_no= getSerno.get(0).get(0);
					int latest_Serno= Integer.parseInt(ser_no)+1;
					
					TB_PARTPASS_FULLPASS_DTL pfd= new TB_PARTPASS_FULLPASS_DTL();
					pfd.setEs_id(es_id);
					pfd.setOpd_personal_id(opd_pers_id);
					pfd.setResult(1);
					pfd.setSer_no(latest_Serno);
					pfd.setOa_app_id(Integer.parseInt(oapp_id));
					sessionHQL.save(pfd);

				}
				
				
				if(ec_exam_id == 2) {
					
					if (latest_pbdacode == 0) {
						String hq16 = "update OFFICER_PERSONAL_DETAILS_M set opd_partd=:opd_partd,pbda_sub_code=:pbda_sub_code   where opd_personal_id=:opd_personal_id ";
						Query query6 = sessionHQL.createQuery(hq16)
								.setParameter("opd_partd", Integer.parseInt(es_year))
								.setParameter("pbda_sub_code", 0)
								.setParameter("opd_personal_id", opd_pers_id);
						query6.executeUpdate();
						
					}
					}

				tx.commit();
				sessionHQL.close();

				model.put("msg", "Data Updated Successfully");
			} catch (RuntimeException e) {
				e.printStackTrace();
				tx.rollback();

				model.put("msg", "Server side Error");

			}

			return new ModelAndView("redirect:PartD_marks_Url");
		}
			
			return new ModelAndView("redirect:PartD_marks_Url");
		}
		
		
}
