package com.BisagN.controller.office.others;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;

public class PartiallyPassPDFController extends AbstractPdfView{

	
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public PartiallyPassPDFController(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		document.setPageSize(PageSize.A4.rotate());
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		
		response.setContentType("application/pdf");
	response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");

//		Font fontTableHeadingSubMainHead = FontFactory.getFont(FontFactory.TIMES_BOLD, 12);;
//		Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
	
	Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
	Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 1);
	Font fontTableHeadingSubMainHead1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 0);
	Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
	
	
	int latest_Serno = (int) model.get("latest_Serno");
	
	
	PdfPTable table = new PdfPTable(1);
	table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	table.setWidthPercentage(100);
	

	PdfPTable table_2 = new PdfPTable(2);
	table_2.setWidths(new int[] {5,90});
	table_2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	table_2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	table_2.setWidthPercentage(100);
	
	
	Paragraph a_2 = new Paragraph("1. ",fontTableHeadingSubMainHead1);
	Paragraph b_2 = new Paragraph("    Further to HQ Army Training Comd letter No A/160015/D/2021 Exam Sec dt 24 Jan 2022.",fontTableHeadingSubMainHead1);
	Paragraph c_2 = new Paragraph("2. ",fontTableHeadingSubMainHead1);
	Paragraph d_2 = new Paragraph("    Add Serial No."+latest_Serno+"  at Appx 'C' (Partially Passed) result booklet of Promotion Exam Part B Oct 2022.",fontTableHeadingSubMainHead1);
	
	
	PdfPCell blank_cella_2;
	blank_cella_2 = new PdfPCell(a_2);
	blank_cella_2.setHorizontalAlignment(Element.ALIGN_LEFT);
	blank_cella_2.setBorder(Rectangle.NO_BORDER);
	
	PdfPCell blank_cellb_2;
	blank_cellb_2 = new PdfPCell(b_2);
	blank_cellb_2.setHorizontalAlignment(Element.ALIGN_LEFT);
	blank_cellb_2.setBorder(Rectangle.NO_BORDER);
	
	PdfPCell blank_cellc_2;
	blank_cellc_2 = new PdfPCell(c_2);
	blank_cellc_2.setHorizontalAlignment(Element.ALIGN_LEFT);
	blank_cellc_2.setBorder(Rectangle.NO_BORDER);
	
	PdfPCell blank_celld_2;
	blank_celld_2 = new PdfPCell(d_2);
	blank_celld_2.setHorizontalAlignment(Element.ALIGN_LEFT);
	blank_celld_2.setBorder(Rectangle.NO_BORDER);
	
	
	table_2.addCell(blank_cella_2);
	table_2.addCell(blank_cellb_2);
	table_2.addCell(blank_cellc_2);
	table_2.addCell(blank_celld_2);
	
	
	PdfPTable tabledata = new PdfPTable(12);
	tabledata.setWidths(new int[] {4,5,4,7,5,3,3,3,3,3,5,5});
	tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	tabledata.setWidthPercentage(100);
	
//	ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");
	

	
	
	Paragraph a = new Paragraph("Ser No",fontTableHeadingSubMainHead);
	Paragraph b = new Paragraph("Personal No ",fontTableHeadingSubMainHead);
	Paragraph c = new Paragraph("Rank",fontTableHeadingSubMainHead);
	Paragraph d = new Paragraph("Name",fontTableHeadingSubMainHead);
	Paragraph e = new Paragraph("Arm/Service",fontTableHeadingSubMainHead);
	Paragraph f = new Paragraph("A",fontTableHeadingSubMainHead);
	Paragraph g = new Paragraph("L",fontTableHeadingSubMainHead);
	Paragraph h = new Paragraph("H",fontTableHeadingSubMainHead);
	Paragraph i = new Paragraph("C",fontTableHeadingSubMainHead);
	Paragraph j = new Paragraph("T",fontTableHeadingSubMainHead);
	Paragraph k = new Paragraph("Yet To Pass",fontTableHeadingSubMainHead);
	Paragraph l = new Paragraph("Personal No ",fontTableHeadingSubMainHead);
	
	
	

	
	 ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");
	
	
	
	 PdfPCell blank_cella;
	 blank_cella = new PdfPCell(a);
	 blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	 PdfPCell blank_cellb;
	 blank_cellb = new PdfPCell(b);
	 blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	 PdfPCell blank_cellc;
	 blank_cellc = new PdfPCell(c);
	 blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
	
	 PdfPCell blank_celld;
	 blank_celld = new PdfPCell(d);
	 blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	 PdfPCell blank_celle;
	 blank_celle = new PdfPCell(e);
	 blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
	
	 
	 PdfPCell blank_cellf;
	 blank_cellf = new PdfPCell(f);
	 blank_cellf.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	 PdfPCell blank_cellg;
	 blank_cellg = new PdfPCell(g);
	 blank_cellg.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	 PdfPCell blank_cellh;
	 blank_cellh = new PdfPCell(h);
	 blank_cellh.setHorizontalAlignment(Element.ALIGN_CENTER);
	
	 PdfPCell blank_celli;
	 blank_celli = new PdfPCell(i);
	 blank_celli.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	 PdfPCell blank_cellj;
	 blank_cellj = new PdfPCell(j);
	 blank_cellj.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	 PdfPCell blank_cellk;
	 blank_cellk = new PdfPCell(k);
	 blank_cellk.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	 PdfPCell blank_celll;
	 blank_celll = new PdfPCell(l);
	 blank_celll.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	
	

	 
	 
	 
		 tabledata.addCell(blank_cella);
		 tabledata.addCell(blank_cellb);
		 tabledata.addCell(blank_cellc);
		 tabledata.addCell(blank_celld);
		 tabledata.addCell(blank_celle);
		 tabledata.addCell(blank_cellf);
		 tabledata.addCell(blank_cellg);
		 tabledata.addCell(blank_cellh);
		 tabledata.addCell(blank_celli);
		 tabledata.addCell(blank_cellj);
		 tabledata.addCell(blank_cellk);
		 tabledata.addCell(blank_celll);
		 
		 
		 StringBuilder input1 = new StringBuilder();
	        input1.append(list.get(0).get(10));
	        input1.reverse();
		 System.err.println("list========="+list);
		 Paragraph a1index = new Paragraph(String.valueOf(latest_Serno),fontTableHeadingdata);
	     Paragraph a1 =  new Paragraph(list.get(0).get(1),fontTableHeadingdata);
		Paragraph b1 =  new Paragraph(list.get(0).get(2),fontTableHeadingdata);
		Paragraph c1 = new Paragraph(list.get(0).get(3),fontTableHeadingdata);
		Paragraph d1=  new Paragraph(list.get(0).get(4),fontTableHeadingdata);
		Paragraph e1 =  new Paragraph(list.get(0).get(5),fontTableHeadingdata);
		Paragraph f1 =  new Paragraph(list.get(0).get(6),fontTableHeadingdata);
		Paragraph g1 =  new Paragraph(list.get(0).get(7),fontTableHeadingdata);
		Paragraph h1 = new Paragraph(list.get(0).get(8),fontTableHeadingdata);
		Paragraph i1 = new Paragraph(list.get(0).get(9),fontTableHeadingdata);
		Paragraph j1 =  new Paragraph(input1.toString(),fontTableHeadingdata);
		Paragraph k1 =  new Paragraph(list.get(0).get(1),fontTableHeadingdata);
		 
		 
		
		
		tabledata.addCell(a1index);
		
		tabledata.addCell(a1);
		tabledata.addCell(b1);
		tabledata.addCell(c1);
		 tabledata.addCell(d1);
		 tabledata.addCell(e1);
		 tabledata.addCell(f1);
		 tabledata.addCell(g1);
		 tabledata.addCell(h1);
		 tabledata.addCell(i1);
		 tabledata.addCell(j1);
		 tabledata.addCell(k1);
		 
		 PdfPTable table_3 = new PdfPTable(2);
		 table_3.setWidths(new int[] {5,90});
		 table_3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		 table_3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		 table_3.setWidthPercentage(100);
			
			
			Paragraph a_3 = new Paragraph("3. ",fontTableHeadingSubMainHead1);
			Paragraph b_3 = new Paragraph("    Rest no change.",fontTableHeadingSubMainHead1);
			Paragraph c_3 = new Paragraph("4. ",fontTableHeadingSubMainHead1);
			Paragraph d_3 = new Paragraph("    For info and necessary action please",fontTableHeadingSubMainHead1);
			
			
			PdfPCell blank_cella_3;
			blank_cella_3 = new PdfPCell(a_3);
			blank_cella_3.setHorizontalAlignment(Element.ALIGN_LEFT);
			blank_cella_3.setBorder(Rectangle.NO_BORDER);
			
			PdfPCell blank_cellb_3;
			blank_cellb_3 = new PdfPCell(b_3);
			blank_cellb_3.setHorizontalAlignment(Element.ALIGN_LEFT);
			blank_cellb_3.setBorder(Rectangle.NO_BORDER);
			
			PdfPCell blank_cellc_3;
			blank_cellc_3 = new PdfPCell(c_3);
			blank_cellc_3.setHorizontalAlignment(Element.ALIGN_LEFT);
			blank_cellc_3.setBorder(Rectangle.NO_BORDER);
			
			PdfPCell blank_celld_3;
			blank_celld_3 = new PdfPCell(d_3);
			blank_celld_3.setHorizontalAlignment(Element.ALIGN_LEFT);
			blank_celld_3.setBorder(Rectangle.NO_BORDER);
			
			
			table_3.addCell(blank_cella_3);
			table_3.addCell(blank_cellb_3);
			table_3.addCell(blank_cellc_3);
			table_3.addCell(blank_celld_3);
		 
		 
		 
		 
		 
		 
		 
		// data bind
//		 int  index=1;
//		 for(int i=0;i<list.size();i++)
//		 {
//		
//			 List<String> l = list.get(i);
//		 Paragraph a1index = new Paragraph(String.valueOf(index),fontTableHeadingdata);
//		 Paragraph pers_code = new Paragraph(l.get(0),fontTableHeadingdata);
//		 Paragraph rank = new Paragraph(l.get(1),fontTableHeadingdata);
//		 Paragraph subject = new Paragraph(l.get(2),fontTableHeadingdata);
//		
//		 
//		 
//		 
//		 PdfPCell cell2 = new PdfPCell();
//		 
//			 tabledata.addCell(a1index);
//			 cell2.setPhrase(pers_code);
//			 //cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
//			 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
//			 tabledata.addCell(cell2);
//			 cell2.setPhrase(rank);
//			 cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
//			 tabledata.addCell(cell2);
//			 cell2.setPhrase(subject);
//			 tabledata.addCell(cell2);
//			 //tabledata.addCell(pers_code);
//			 
//			 //tabledata.addCell(rank);
//			// tabledata.addCell(subject);
//			 
//			 index+=1;
//			
//		 }
	 
	PdfPCell cell123;
	cell123 = new PdfPCell();
	
	
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(table_2);
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(tabledata);
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(table_3);
	cell123.setBorder(0);
	table.addCell(cell123);

	document.add(table);
	super.buildPdfMetadata(model, document, request);
}

	
	
}
