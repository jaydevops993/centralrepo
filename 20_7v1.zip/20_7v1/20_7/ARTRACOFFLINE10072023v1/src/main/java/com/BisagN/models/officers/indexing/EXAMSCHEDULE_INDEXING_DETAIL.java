package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "examschedule_indexing_detail", uniqueConstraints = { @UniqueConstraint(columnNames = "esid_es_id"), })
public class EXAMSCHEDULE_INDEXING_DETAIL {
	
	
	
	private int esid_es_id;
	private int  esid_sc_subject_id ;
	    private Date esid_dtindexdate ;
	    private Date  esid_startdatetime; 
	    private Date  esid_enddatetime ;
	    private int    esid_createdby;
	    private Date esid_createdate ;
	    private int  esid_updateby ;
	    private Date  esid_updatedate;
	    private int  no_of_copies; 
	    private int esid_sub_subject_id;
	    
		@Id
		
		@Column(name = "esid_es_id", unique = true, nullable = false)
		public int getEsid_es_id() {
			return esid_es_id;
		}
		public void setEsid_es_id(int esid_es_id) {
			this.esid_es_id = esid_es_id;
		}
		public int getEsid_sc_subject_id() {
			return esid_sc_subject_id;
		}
		public void setEsid_sc_subject_id(int esid_sc_subject_id) {
			this.esid_sc_subject_id = esid_sc_subject_id;
		}
		public Date getEsid_dtindexdate() {
			return esid_dtindexdate;
		}
		public void setEsid_dtindexdate(Date esid_dtindexdate) {
			this.esid_dtindexdate = esid_dtindexdate;
		}
		public Date getEsid_startdatetime() {
			return esid_startdatetime;
		}
		public void setEsid_startdatetime(Date esid_startdatetime) {
			this.esid_startdatetime = esid_startdatetime;
		}
		public Date getEsid_enddatetime() {
			return esid_enddatetime;
		}
		public void setEsid_enddatetime(Date esid_enddatetime) {
			this.esid_enddatetime = esid_enddatetime;
		}
		public int getEsid_createdby() {
			return esid_createdby;
		}
		public void setEsid_createdby(int esid_createdby) {
			this.esid_createdby = esid_createdby;
		}
		public Date getEsid_createdate() {
			return esid_createdate;
		}
		public void setEsid_createdate(Date esid_createdate) {
			this.esid_createdate = esid_createdate;
		}
		public int getEsid_updateby() {
			return esid_updateby;
		}
		public void setEsid_updateby(int esid_updateby) {
			this.esid_updateby = esid_updateby;
		}
		public Date getEsid_updatedate() {
			return esid_updatedate;
		}
		public void setEsid_updatedate(Date esid_updatedate) {
			this.esid_updatedate = esid_updatedate;
		}
		public int getNo_of_copies() {
			return no_of_copies;
		}
		public void setNo_of_copies(int no_of_copies) {
			this.no_of_copies = no_of_copies;
		}
		public int getEsid_sub_subject_id() {
			return esid_sub_subject_id;
		}
		public void setEsid_sub_subject_id(int esid_sub_subject_id) {
			this.esid_sub_subject_id = esid_sub_subject_id;
		}
	    
	    

	    

}
