package com.BisagN.dao.officer.others;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
@Service
public class ProcessResultDaoImpl implements ProcessResultDao {
	@Autowired
    private DataSource dataSource;
	
	
	CommonController comm = new CommonController();
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	
	public ArrayList<ArrayList<String>> getFullyPassedForProcessResult(int es_id, String oa_application_id,int exam_id) {
		
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		String whr = "";
		String whr1 = "";
		String whr2 = "";
	if(!oa_application_id.equals("")) {
		
		whr+= "and oapp.oa_application_id=?";
	}
	
	
if(exam_id == 1) {
		
		whr2+= "AND vw.opd_partb <> 0";
	}

if(exam_id == 2) {
	
	whr2+= "AND vw.opd_partd <> 0";
}
		

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			q = "SELECT oapp.es_id,\n"
					+ "    vw.opd_personal_id,\n"
					+ "    vw.opc_personal_code,  vw.opc_suffix_code,\n"
					+ "    vw.rc_rank_name,\n"
					+ "    vw.opd_officer_name,\n"
					+ "    vw.ac_arm_description,\n"
					+ "    vw.ac_arm_code,oapp.oa_application_id\n"
					+ "   FROM vw_personal_details vw\n"
					+ "     JOIN officer_application oapp ON oapp.opd_personal_id = vw.opd_personal_id and oapp.oa_status_id=1\n"
					+ "  WHERE oapp.oa_status_id= 1 and oapp.es_id=?  "+whr2+" AND vw.opd_status_id = 1 "+whr+" order by vw.opc_personal_code";

		
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, es_id);
			if(!oa_application_id.equals("")) {
				stmt.setInt(2,Integer.parseInt(oa_application_id));
			}
			System.out.println("fully_pass ------------------"+stmt);
			ResultSet rs = stmt.executeQuery();
	int i=1;
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				String Data=rs.getString("opc_personal_code");
				String DataPre="";
				String DataM="";
				if(Data.contains("NTR") || Data.contains("NTS")) {
					DataPre= Data.substring(0,3);
					DataM = Data.substring(4);
				}else {
					DataPre= Data.substring(0,2);
					DataM = Data.substring(3);
				}
				
				Data=DataPre+DataM;
				
				list.add(String.valueOf(i));
				list.add(Data+(rs.getString("opc_suffix_code")));
				list.add(rs.getString("rc_rank_name"));
				list.add(rs.getString("opd_officer_name"));
				list.add(rs.getString("ac_arm_description")+"("+(rs.getString("ac_arm_code")+")"));
				list.add(rs.getString("opd_personal_id"));
				list.add(rs.getString("oa_application_id"));
				alist.add(list);
				i++;
				//System.err.println("list============"+list);

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

}
