package com.BisagN.controller.office_DSSC_Report;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.BisagN.controller.office_DSSC_Report.WithdrwalPDFController.PageNumeration;
//import com.BisagN.controller.office.reports.IndexNoAgainstMarksObtainedController_Pdf.PageNumeration;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;

public class AbsenteesDSSCDSTSCReportControllerPDF extends AbstractPdfView{
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	int totalRecords=0;
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";
	private static final DecimalFormat decfor = new DecimalFormat("0.00");  
	public AbsenteesDSSCDSTSCReportControllerPDF(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		String es_year =  (String) model.get("es_year");


		Chunk underline7 = new Chunk("LIST OF ABSENTEES" +"\n\n"+ "DSSC/DSTSC - "+es_year+"" ,fontTableHeading1);

		Phrase phh7 = new Phrase(underline7);
		underline7.setUnderline(0.1f, -2f);

		phh7.add("\n");
		phh7.setFont(fontTableHeadingSubMainHead);

		Paragraph cell71 = new Paragraph(phh7);
		cell71.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader7 = new PdfPTable(1);
		tableheader7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader7.setWidthPercentage(100);
		tableheader7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader7.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader7.addCell(cell71);

		PdfPTable tabledata71 = new PdfPTable(7);

		tabledata71.setWidths(new int[] { 3, 5, 3, 10, 5, 5, 5 });
		tabledata71.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata71.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata71.setWidthPercentage(100);

		Paragraph a7 = new Paragraph("SER NO", fontTableHeadingSubMainHead);
		Paragraph b7 = new Paragraph("PERS NO", fontTableHeadingSubMainHead);
		Paragraph c7 = new Paragraph("RANK", fontTableHeadingSubMainHead);
		Paragraph d7 = new Paragraph("NAME", fontTableHeadingSubMainHead);
		Paragraph e7 = new Paragraph("UNIT", fontTableHeadingSubMainHead);
		Paragraph f7 = new Paragraph("  EXAM CENTRE", fontTableHeadingSubMainHead);
		Paragraph g7 = new Paragraph("SUBJECTS", fontTableHeadingSubMainHead);
		
//
//		tabledata71.addCell(a7);
//		tabledata71.addCell(b7);
//		tabledata71.addCell(c7);
//		tabledata71.addCell(d7);
//		tabledata71.addCell(e7);
//		tabledata71.addCell(f7);
//		tabledata71.addCell(g7);

		
		
		PdfPCell blank_cella;
		blank_cella = new PdfPCell();
		blank_cella.addElement(a7);
		blank_cella.setBorder(Rectangle.BOTTOM);
		blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella.setPaddingLeft(2f);

		PdfPCell blank_cellb;
		blank_cellb = new PdfPCell();
		blank_cellb.addElement(b7);
		blank_cellb.setBorder(Rectangle.BOTTOM);

		blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellb.setPaddingLeft(15f);

		PdfPCell blank_cellc;
		blank_cellc = new PdfPCell();
		blank_cellc.addElement(c7);
		blank_cellc.setBorder(Rectangle.BOTTOM);

		blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellc.setPaddingLeft(10f);

		PdfPCell blank_celld;
		blank_celld = new PdfPCell();
		blank_celld.addElement(d7);
		blank_celld.setBorder(Rectangle.BOTTOM);

		blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_celld.setPaddingLeft(40f);

		PdfPCell blank_celle;
		blank_celle = new PdfPCell();
		blank_celle.addElement(e7);
		blank_celle.setBorder(Rectangle.BOTTOM);

		blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_celle.setPaddingLeft(25f);
		
		PdfPCell blank_cellf;
		blank_cellf = new PdfPCell();
		blank_cellf.addElement(f7);
		blank_cellf.setBorder(Rectangle.BOTTOM);

		blank_cellf.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf.setPaddingLeft(15f);
		
		PdfPCell blank_cellg;
		blank_cellg = new PdfPCell();
		blank_cellg.addElement(g7);
		blank_cellg.setBorder(Rectangle.BOTTOM);

		blank_cellg.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellg.setPaddingLeft(5f);

		tabledata71.addCell(blank_cella);
		tabledata71.addCell(blank_cellb);
		tabledata71.addCell(blank_cellc);
		tabledata71.addCell(blank_celld);
		tabledata71.addCell(blank_celle);
		tabledata71.addCell(blank_cellf);
		tabledata71.addCell(blank_cellg);
		ArrayList<List<String>> PartAbsenteesForDSSC_DSTSC = (ArrayList<List<String>>) model.get("userList");
		for (int i5 = 0; i5 < PartAbsenteesForDSSC_DSTSC.size(); i5++) {

			List<String> l = PartAbsenteesForDSSC_DSTSC.get(i5);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
			Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdata);
			Paragraph blank7 = new Paragraph(l.get(6), fontTableHeadingdata);

			PdfPCell cellar = new PdfPCell();

			cellar.setFixedHeight(20f);
			if (i5 % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}

			cellar.setPhrase(blank1);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellar.setBorder(Rectangle.NO_BORDER);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank6);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank7);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata71.addCell(cellar);

//			tabledata71.addCell(blank1);
//			tabledata71.addCell(blank2);
//			tabledata71.addCell(blank3);
//			tabledata71.addCell(blank4);
//			tabledata71.addCell(blank5);
//			tabledata71.addCell(blank6);
//			tabledata71.addCell(blank7);

		}
		
		PageNumeration event = new PageNumeration(arg2);
		arg2.setPageEvent(event);
		document.setPageCount(1);

//		PdfPCell cell1235_7;
//		cell1235_7 = new PdfPCell();
//		//cell1235_7.addElement(tabledata7);//
//		cell1235_7.addElement(tableheader7);
//		cell1235_7.addElement(tabledata71);
//
//		cell1235_7.setBorder(0);
//		cell1235_7.setPaddingLeft(30f);
//		cell1235_7.setPaddingRight(30f);
//		table.addCell(cell1235_7);
		
		table.setSplitLate(false);
		PdfPCell cell12356;
		cell12356 = new PdfPCell(); 
		cell12356.addElement(tableheader7); 
		cell12356.setBorder(Rectangle.NO_BORDER);
		 
		table.addCell(cell12356);
		
		PdfPCell cell1235612 ;
		cell1235612 = new PdfPCell();
		cell1235612.setBorder(Rectangle.BOX);
		 
		cell1235612.addElement(tabledata71);
	 
		table.addCell(cell1235612);
				
				
		document.add(table);
		super.buildPdfMetadata(model, document, request);
	}
	
	class PageNumeration extends PdfPageEventHelper {
		PdfTemplate total;
		PdfTemplate total1;

		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				total1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {
			// total = writer.getDirectContent().createTemplate(30, 12);
		}

		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			String ip = "";
			try {
				table.setWidths(new int[] { 15,6,1});  
				table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				Date now = new Date();
				String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
				table.addCell(dateString);  //table.addCell("TOTAL SHEET :");
				
				
				PdfPCell cell1 = new PdfPCell(Image.getInstance(total1));
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			//	table.addCell(cell1);
								
			
				//String watermark = " Generated by "+username+" on "+dateString +" with IP " +ip ;
				
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Pages %d of", writer.getPageNumber()));
				//table.addCell("Month :");
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.NO_BORDER);				
				table.addCell(cell);
				
				table.writeSelectedRows(0, -1, document.leftMargin(), document.topMargin() + 0, writer.getDirectContent());
			} catch (DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT, new Phrase(String.valueOf(writer.getPageNumber() - 1)), 2, 2, 0);
			ColumnText.showTextAligned(total1, Element.ALIGN_LEFT, new Phrase(String.valueOf(totalRecords)), 2, 2, 0);
		}
	}
}
