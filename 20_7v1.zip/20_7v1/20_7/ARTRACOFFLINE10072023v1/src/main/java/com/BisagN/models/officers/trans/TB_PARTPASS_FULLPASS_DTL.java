package com.BisagN.models.officers.trans;

import static javax.persistence.GenerationType.IDENTITY;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "tb_partpass_fullpass_dtl", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})
public class TB_PARTPASS_FULLPASS_DTL {

	
	private int  id;
	private int  es_id;
	private int  opd_personal_id;
	private int result;
	private int  ser_no;
	private int pbda_code;
	private int oa_app_id;
	   @Id
	      @GeneratedValue(strategy = IDENTITY)
	      @Column(name = "id", unique = true, nullable = false)
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getEs_id() {
		return es_id;
	}
	public void setEs_id(int es_id) {
		this.es_id = es_id;
	}
	public int getOpd_personal_id() {
		return opd_personal_id;
	}
	public void setOpd_personal_id(int opd_personal_id) {
		this.opd_personal_id = opd_personal_id;
	}
	public int getResult() {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
	public int getSer_no() {
		return ser_no;
	}
	public void setSer_no(int ser_no) {
		this.ser_no = ser_no;
	}
	public int getPbda_code() {
		return pbda_code;
	}
	public void setPbda_code(int pbda_code) {
		this.pbda_code = pbda_code;
	}
	public int getOa_app_id() {
		return oa_app_id;
	}
	public void setOa_app_id(int oa_app_id) {
		this.oa_app_id = oa_app_id;
	}
	
	
	
}
