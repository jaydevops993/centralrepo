package com.BisagN.dao.officer.booklet;

import java.util.ArrayList;

public interface GenerateBookletDao {
	public ArrayList<ArrayList<String>> getResultStatusForExamSchedule(String es_id);
}
