package com.BisagN.dao.officer.others;

import java.util.ArrayList;

 
public interface Officer_pers_DAO {
	
	public  ArrayList<ArrayList<String>> Officer_pers_data(String personal_code);

	public  ArrayList<ArrayList<String>> Officer_pers_data_part_b(String personal_code);
	
	public  ArrayList<ArrayList<String>> Officer_pers_data_part_d(String personal_code);
	
	public  ArrayList<ArrayList<String>> Officer_pers_data_DSSC(String personal_code); 
	
	public  ArrayList<ArrayList<String>> Officer_pers_data_withheld(String personal_code ,int exam_id);
	
}
