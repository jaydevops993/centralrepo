package com.BisagN.dao.officer.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class Unfair_meansDAOImpl implements Unfair_meansDAO {
	@Autowired
         private DataSource dataSource;
//         public void setDataSource(DataSource dataSource) {
//	       this.dataSource = dataSource;
//         }
 HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
 
 CommonController comm= new CommonController();

 @Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;



  public boolean checkIsIntegerValue(String Search) {
	return Search.matches("[0-9]+");
}


  public List<Map<String, Object>> getReportListUnfair_means(int startPage,String pageLength,String Search,String orderColunm,String orderType,
			String exam_schedule_dt_id,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
			if(pageLength.equals("-1")){
	 			pageLength = "ALL";
			}
			String SearchValue = GenerateQueryWhereClause_SQL(Search);

	 		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
			Connection conn = null;
			String q = "";
			String q1="";
			
			if(!exam_schedule_dt_id.equals("")) {
				
//				q1+="and um.es_id=?";
				q1+="   where um.es_id=?";
			}
			try {
				conn = dataSource.getConnection();
				q = "select um.id,opc.opc_personal_code,opc.opc_suffix_code, sc.sc_subject_name,um.um_remarks ,um.um_status_id from unfair_means um \n"
						+ "inner join subject_code sc on sc.sc_subject_id=um.sc_subject_id\n"
						+ "inner join officer_personal_code opc on um.opd_personal_id = opc.opd_personal_id   "+q1+" "+SearchValue+" ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
//				um.um_status_id=1
				PreparedStatement stmt = conn.prepareStatement(q);
				if(!exam_schedule_dt_id.equals("")) {
					
					stmt.setInt(1, Integer.parseInt(exam_schedule_dt_id));
				}
				stmt = setQueryWhereClause_SQL(stmt,Search);
				System.err.println(stmt);
				ResultSet rs = stmt.executeQuery();
				ResultSetMetaData metaData = rs.getMetaData();
	 			int columnCount = metaData.getColumnCount();
	 			while (rs.next()) {
					Map<String, Object> columns = new LinkedHashMap<String, Object>();
					for (int i = 1; i <= columnCount; i++) {
					    columns.put(metaData.getColumnLabel(i), rs.getObject(i));
					}
					
//					  ======================================================
	                String status=rs.getString("um_status_id");
	                String aaa="";
	                if(status.equals("0"))
	                {
	              	  aaa ="Clear UFM";
	                }
	                else
	                {
	              	  aaa ="Active";
	                }
	                status=aaa;
	                columns.put("stat", aaa);
//	                ===========
					
					
					
	                      String enckey ="commonPwdEncKeys";
		                    Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
		                    String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("id").toString().getBytes())));
	                      String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"+EncryptedPk+"')}else{ return false;}\""; 
	                      String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
	                      String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('"+EncryptedPk+"','"+status+"')}else{ return false;}\""; 
	                      String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>"; 
	                      String f = "";
	                      String f1 = "";
	                      f += updateButton;
//	                    f += deleteButton;

	                    String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
	           			String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));
	          			f1 += opc_code;
	                      columns.put("action",f);
	                      columns.put("opc_code",f1);
	                     columns.put(metaData.getColumnLabel(1), f);
				list.add(columns);
		}
	rs.close();
	stmt.close();
	conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
	if (conn != null) {
	try {
		conn.close();
	} catch (SQLException e) {
	}
	}
	}
	return list;
	}

public long getReportListUnfair_meansTotalCount(String Search,String exam_schedule_dt_id) {
 		String SearchValue = GenerateQueryWhereClause_SQL(Search);
 		int total = 0;
 		String q = null;
 		String q1 = "";
 		Connection conn = null;
 		
if(!exam_schedule_dt_id.equals("")) {
			
			q1+="and um.es_id=?";
		}
 		try {
 			conn = dataSource.getConnection();
 			q ="select count(*) from (select um.id,opc.opc_personal_code, sc.sc_subject_name,um.um_remarks from unfair_means um \n"
 					+ "inner join subject_code sc on sc.sc_subject_id=um.sc_subject_id\n"
 					+ "inner join officer_personal_code opc on um.opd_personal_id = opc.opd_personal_id  where um.um_status_id=1 "+q1+" "+SearchValue +"  ) ab " ;
 			PreparedStatement stmt = conn.prepareStatement(q);
 			if(!exam_schedule_dt_id.equals("")) {
				
				stmt.setInt(1, Integer.parseInt(exam_schedule_dt_id));
			}
 			stmt = setQueryWhereClause_SQL(stmt,Search);
 			ResultSet rs = stmt.executeQuery();
 			while (rs.next()) {
 				total = rs.getInt(1);
 			}
  			rs.close();
  			stmt.close();
  			conn.close();
  		} catch (SQLException e) {
  			e.printStackTrace();
  		} finally {
  			if (conn != null) {
  				try {
  					conn.close();
  				} catch (SQLException e) {
  				}
 			}
  		}
  		return (long) total;
  	}


  	public String GenerateQueryWhereClause_SQL(String Search) {
 		String SearchValue ="";
  		if(!Search.equals("")) {
			Search = Search.toLowerCase();
  			SearchValue =" and ( ";
//  			if(checkIsIntegerValue(Search)) {
//  				SearchValue +=" id=? or ";
//  			}
//  			String opd_personal_id = ""; 
//  			if(checkIsIntegerValue(Search)) {
//  				opd_personal_id +=" opd_personal_id= ? or ";
//  			}
// 			SearchValue +=" "+   opc_personal_code, sc.sc_subject_name+"lower(um_remarks) like ?  )";
 		  			SearchValue +=" lower(opc_personal_code) like ? or lower(sc.sc_subject_name) like ? or lower(um_remarks) like ?)";
  		}
   return SearchValue;
 }


  	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search) {
 		int flag = 1;
 		try {
  		
    		if(!Search.equals("")) {
    			System.err.println("flag==="+flag);
 				flag += 1;
 				Search=comm.getSearchIcNumberwithoutZero(Search);

 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 			
 				
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 			}
 		}catch (Exception e) {}
 		return stmt;
 	}
   public String Deleteunfair_means(String deleteid,HttpSession session1) {

      	Session session = this.sessionFactory.openSession();
      	Transaction tx = session.beginTransaction();
      	String enckey = "commonPwdEncKeys";
		    String DcryptedPk = hex_asciiDao.decrypt((String) deleteid,enckey,session1);
	      	String hql = "Delete from UNFAIR_MEANS_M  where cast(id as string) = :deleteid";
          Query q = session.createQuery(hql).setString("deleteid",DcryptedPk);
      	int rowCount = q.executeUpdate();
      	tx.commit();
          session.close();
	    if(rowCount > 0) {
 			return "Deleted Successfully";
  		}else {
  		return "Deleted not Successfully";
   	}
  	}
   
   
   public ArrayList<ArrayList<String>> getsubjectlist(String exm_name) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		String whr = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			
		
			
			q="select id,sc_subject_name from subject_code where ec_exam_id::text=? ";
			
			stmt = conn.prepareStatement(q);
			int i=0;
		
			stmt.setString(1, exm_name);
			System.err.println(stmt);
			
			ResultSet rs = stmt.executeQuery();
			
		
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("id"));//1
				list.add(rs.getString("sc_subject_name"));//1
				
				
				
				alist.add(list);
				
				
			}

			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

}
