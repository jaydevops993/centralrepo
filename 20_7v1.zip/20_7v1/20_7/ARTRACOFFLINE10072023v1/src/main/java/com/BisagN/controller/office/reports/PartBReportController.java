package com.BisagN.controller.office.reports;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.officer.others.ExaminationlockunlockDAO;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.report.PartB_ReportDAO;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_MASTER;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class PartBReportController {

	

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;


@Autowired
private ExaminationlockunlockDAO exmunlockDao;


@Autowired
PartB_ReportDAO partbreportDao;



@Autowired
private PartB_ExaminationDAO partBDao;

CommonController comm = new CommonController();


@RequestMapping(value = "PartB_ReportUrl", method = RequestMethod.GET)
public ModelAndView PartB_ReportUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) 
		 throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{
	
	
	

	int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
	//if(ec_exam_id != 0) {
		Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, 1));
		ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(1);
		Mmap.put("getexamcentrelist", examcentrelist);
		ArrayList<ArrayList<String>>list2= exmunlockDao.getbegindatefrmexmschedule(1);
	    Mmap.put("PartB_Begindate", list2);
		//}
    Mmap.put("msg", msg);
	

return new ModelAndView("PartBReport_tiles");

}
@RequestMapping(value = "/getPartB_Report", method = RequestMethod.POST)
public ModelAndView getPartB_Report(ModelMap Mmap, HttpSession session,HttpServletRequest request, String typeReport, String es_id, 
		String reportname1, String subject_id1,String centre_id1,String chance1, String f_percntg1,String t_percntg1,String marks1, String exmsh_date1, String subject_name_hid1,
		String t_chnace1, String fr_chnace1) {
	try {
		
		if(!exmsh_date1.equals("")) {
		String es_year = exmsh_date1.split("/")[2];
		Mmap.put("es_year", es_year);
		
		
	
		if(es_id.equals("0")) {
			Mmap.put("msg","Please Select Subject");
			  return new ModelAndView("redirect:PartB_ReportUrl");
		  }
		
		
		if(reportname1.equals("0")) {
			Mmap.put("msg","Please Select Report");
			  return new ModelAndView("redirect:PartB_ReportUrl");
		  }
		
		
		 List<EXAM_CODE_M>getExamName=comm.getExamNamebyExmID( sessionFactory, 1) ;
		 String ExamName=getExamName.get(0).getEc_exam_name();
		 int exam_id=getExamName.get(0).getId();
		 Mmap.put("ExamName", ExamName);
	
		if(reportname1.equals("1")) {
			
			System.err.println("es_year----------"+es_year);
			ArrayList<ArrayList<String>> list = partbreportDao.getArmServiceAnalysisResultsPartB(Integer.parseInt(es_id), es_year);
			
			if (list.size() == 0) {

				Mmap.put("msg", "Data Not Available.");
			} else {
				Mmap.put("list", list);
				Mmap.put("list.size()", list.size());
			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list.size() > 0) {

					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new ArmServiceWiseAnalysisOfResult("L", TH, Heading, username),"userList",list);

				}
			}
			
			}
		}
		else if(reportname1.equals("2")) {
				
			ArrayList<ArrayList<String>> list = partbreportDao.getArmsubsummaryresult(Integer.parseInt(es_id));
			
		if (list.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {
			Mmap.put("list", list);
			Mmap.put("list.size()", list.size());
		}
			
			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list.size() > 0) {
					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new SubjectWiseAnalysic_Controller_Pdf("L", TH, Heading, username),"userList",list);


				}
			}
		}
		
else if(reportname1.equals("3")) {
	
	ArrayList<ArrayList<String>> list = partbreportDao.getCommandAnalysisResultsPartB(Integer.parseInt(es_id),es_year);
	if (list.size() == 0) {
		Mmap.put("msg", "Data Not Available.");
	} else {
		Mmap.put("list", list);
		Mmap.put("list.size()", list.size());
	}
	
	
			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list.size() > 0) {
					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new CommandWiseAnalysic_Controller_Pdf("L", TH, Heading, username),"userList",list);

				}
			}
		}
		
		
	else if(reportname1.equals("4")) {
		
		ArrayList<ArrayList<String>> list = partbreportDao.getFullyPassedForPartB(Integer.parseInt(es_id),"");
		
		System.err.println("list=========="+list);
		
		if (list.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {
			Mmap.put("list", list);
			Mmap.put("list.size()", list.size());

			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list.size() > 0) {
					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new FullyPassed_Controller_Pdf("L", TH, Heading, username),"userList",list);
					

				}
			}
		}
	}
	else if(reportname1.equals("5")) {
		
ArrayList<ArrayList<String>> list = partbreportDao.getPartPassedandFailures(es_year,"");
		
		if (list.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {
			Mmap.put("list", list);
			Mmap.put("list.size()", list.size());
		
		if (typeReport != null && typeReport.equals("pdfL")) {
			if (list.size() > 0) {
				List<String> TH = new ArrayList<String>();
				String Heading = "";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(new PartiallyPassed_Controller_Pdf("L", TH, Heading, username),"userList",list);

			}
		}
		
		}
	}
		

		
		
else  if(reportname1.equals("7")) {
		
		ArrayList<ArrayList<String>> list = partbreportDao.getdetailsResultWithHeld(Integer.parseInt(es_id),0);
	
	if (list.size() == 0) {

		Mmap.put("msg", "Data Not Available.");
	} else {
		Mmap.put("list", list);
		Mmap.put("list.size()", list.size());
			
			if (typeReport != null && typeReport.equals("pdfL")) {
			if (list.size() > 0) {
					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new Result_withheldPdf("L", TH, Heading, username),"userList",list);


				}
			}
		}
	}
		
		
		

		
		
else  if(reportname1.equals("9")) {
	

	ArrayList<ArrayList<String>> list = partbreportDao.Candidate25PersmarksDetails(Integer.parseInt(es_id),f_percntg1, t_percntg1,marks1, subject_id1);

if (list.size() == 0) {

	Mmap.put("msg", "Data Not Available.");
} else {
	Mmap.put("list", list);
	Mmap.put("list.size()", list.size());
	Mmap.put("f_percntg1", f_percntg1);
	Mmap.put("t_percntg1", t_percntg1);
	Mmap.put("marks1", marks1);
		
		if (typeReport != null && typeReport.equals("pdfL")) {
		if (list.size() > 0) {
				List<String> TH = new ArrayList<String>();
				String Heading = "";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(new CandidateScoring25PermarksPDF("L", TH, Heading, username),"userList",list);


			}
		}
	}
}

		
//else if (reportname1.equals("10")) {
//
//	ArrayList<ArrayList<String>> list = partbreportDao.ChanceWisAnalysisReport(Integer.parseInt(es_id),fr_chnace1, t_chnace1);
//
//	if (list.size() == 0) {
//
//		Mmap.put("msg", "Data Not Available.");
//	} else {
//
//		Mmap.put("list", list);
//		Mmap.put("list.size()", list.size());
//
//		if (typeReport != null && typeReport.equals("pdfL")) {
//			if (list.size() > 0) {
//				List<String> TH = new ArrayList<String>();
//				String Heading = "";
//				String username = session.getAttribute("username").toString();
//				return new ModelAndView(new ChancewiseAnalysisReportPDF("L", TH, Heading, username));
//
//			}
//		}
//	}
//}
		
		
else  if(reportname1.equals("11")) {
	
	
	ArrayList<ArrayList<String>> list = partbreportDao.CenterWiseListOfSubject(Integer.parseInt(es_id),Integer.parseInt(subject_id1),Integer.parseInt(centre_id1));
	
	if (list.size() == 0) {

		Mmap.put("msg", "Data Not Available.");
	} else {

		Mmap.put("list", list);
		Mmap.put("list.size()", list.size());
		Mmap.put("subject_name_hid1", subject_name_hid1);

		
		if (typeReport != null && typeReport.equals("pdfL")) {
			if (list.size() > 0) {
				List<String> TH = new ArrayList<String>();
				String Heading = "";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(new CentreWiseOffAppearedagainstsubjectPDF("L", TH, Heading, username));

			}
		}
	}
}	

else if (reportname1.equals("12")) {

	ArrayList<ArrayList<String>> list = partbreportDao.PartAbsentees(Integer.parseInt(es_id));

	if (list.size() == 0) {

		Mmap.put("msg", "Data Not Available.");
	} else {

		Mmap.put("list", list);
		Mmap.put("list.size()", list.size());

		if (typeReport != null && typeReport.equals("pdfL")) {
			if (list.size() > 0) {
				List<String> TH = new ArrayList<String>();
				String Heading = "";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(new AbsenteesPDF("L", TH, Heading, username));

			}
		}
	}
}	
		

		
//	else if(reportname1.equals("13")) {
//		
//		if (typeReport != null && typeReport.equals("pdfL")) {
//			//if (list.size() > 0) {
//				List<String> TH = new ArrayList<String>();
//				String Heading = "";
//				String username = session.getAttribute("username").toString();
//				return new ModelAndView(new WrongApperiance_Controller_Pdf("L", TH, Heading, username));
//
//			//}
//		}
//	}
//		
		
	else  if(reportname1.equals("14")) {
		

		
		ArrayList<ArrayList<String>> list = partbreportDao.ResultApprovalSheet(es_year);
		
		

		if (list.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {

			Mmap.put("list", list);
			Mmap.put("list.size()", list.size());
			Mmap.put("es_year", es_year);
		
		if (typeReport != null && typeReport.equals("pdfL")) {
			if (list.size() > 0) {
				List<String> TH = new ArrayList<String>();
				String Heading = "";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(new ResultApproval_Controller_Pdf("L", TH, Heading, username));

			}
		}
	}
	}	
		
	else if(reportname1.equals("15")) {
		
		
	
		ArrayList<ArrayList<String>> list = partbreportDao.IndexagainstPersonNo(Integer.parseInt(es_id),Integer.parseInt(subject_id1));

		if (list.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {
			Mmap.put("list", list);
			Mmap.put("list.size()", list.size());
			Mmap.put("subject_name_hid1", subject_name_hid1);	
		
		
		if (typeReport != null && typeReport.equals("pdfL")) {
			if (list.size() > 0) {
				List<String> TH = new ArrayList<String>();
				String Heading = "";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(new IndexNoAgainstPersonalNoController_Pdf("L", TH, Heading, username),"userList",list);
			}
			}
		   }
//		}
	}
		else if(reportname1.equals("16")) {
			
			ArrayList<ArrayList<String>> list = partbreportDao.IndexagainstmarksObtained(Integer.parseInt(es_id),Integer.parseInt(subject_id1));

			if (list.size() == 0) {

				Mmap.put("msg", "Data Not Available.");
			} else {
				Mmap.put("list", list);
				Mmap.put("list.size()", list.size());
				
//				Mmap.put("ExamName", ExamName);
				
				Mmap.put("subject_name_hid1", subject_name_hid1);
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (list.size() > 0) {
						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(new IndexNoAgainstMarksObtainedController_Pdf("L", TH, Heading, username));

					}
				}
			}
		}
		else  if(reportname1.equals("17")) {
			
			ArrayList<ArrayList<String>> list = partbreportDao.IndexagainstPersAndname(Integer.parseInt(es_id));

			if (list.size() == 0) {

				Mmap.put("msg", "Data Not Available.");
			} else {
				Mmap.put("list", list);
				Mmap.put("list.size()", list.size());
				
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (list.size() > 0) {
						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(new IndexNoAgainstPersonalNoandNameController_Pdf("L", TH, Heading, username),"userList",list);

					}
				}
			}
		}
else  if(reportname1.equals("18")) {
			
			ArrayList<ArrayList<String>> list = partbreportDao.SummaryPartB(Integer.parseInt(es_id),exam_id);

			if (list.size() == 0) {

				Mmap.put("msg", "Data Not Available.");
			} else {
				Mmap.put("list", list);
				Mmap.put("list.size()", list.size());
			
			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list.size() > 0) {
					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new SummaryPdfController("L", TH, Heading, username),"userList",list);

				}
			}
		}
		}	
		
		}

	} catch (Exception e) {
		e.printStackTrace();
	}

	return new ModelAndView("redirect:PartB_ReportUrl");
}



}