package com.BisagN.dao.officer.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface DSSCMarksDAO {

	

	public List<Map<String, Object>> getDSSCCMarksDetails(int startPage,String pageLength,String Search,String orderColunm,String orderType,String sub_id,String es_id,
			String opd_personal_id,String officername,	String indexno,	HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException; 
	
	public long getDSSCCMarksdetailsTotalCount(String Search,String sub_id,String es_id,String opd_personal_id,String officername,
			String indexno);
	
	public ArrayList<ArrayList<String>> getDSSCMarksDetails(String oapp_id,String subjectid);
	
}
