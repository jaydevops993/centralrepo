package com.BisagN.controller.office.reports;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;

public class ChancewiseAnalysisReportPDF extends AbstractPdfView {
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public ChancewiseAnalysisReportPDF(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		document.setPageSize(PageSize.A4.rotate());
		super.buildPdfMetadata(model, document, request);
	}
	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();
		String es_year =  (String) model.get("es_year");
		
		response.setContentType("application/pdf");
	response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");

		
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
		Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
		Font fontTableHeadingSubMainHead = FontFactory.getFont(FontFactory.TIMES_BOLD, 12);;
		
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
				
		Chunk underline1 = new Chunk("1" +"\n"+ "CHANCE WISE ANALYSIS" +"\n"+ "PART B:"+es_year+"" , fontTableHeadingSubMainHead);	 
		underline1.setUnderline(0.1f, -2f);
		
		Phrase ph = new Phrase(underline1);
		ph.add("\n");
		ph.add("\n");
		ph.add("\n");
		ph.setFont(fontTableHeading1);
		Paragraph cell = new Paragraph(ph);
		cell.setAlignment(Element.ALIGN_LEFT);
		
		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell);
	
		 
		 PdfPTable tabledata = new PdfPTable(6);
			
			tabledata.setWidths(new int[] {5,5,5,5,5,5});
			tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tabledata.setWidthPercentage(100);
			
			ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");
			
			Paragraph a = new Paragraph("Ser No",fontTableHeadingSubMainHead);
			Paragraph b = new Paragraph("Personal No",fontTableHeadingSubMainHead);
			Paragraph c = new Paragraph("Name",fontTableHeadingSubMainHead);
			Paragraph d = new Paragraph("Arm/Service",fontTableHeadingSubMainHead);
			Paragraph e = new Paragraph("Chance",fontTableHeadingSubMainHead);
			Paragraph f = new Paragraph("Status",fontTableHeadingSubMainHead);
				
				 tabledata.addCell(a);
				 tabledata.addCell(b);
				 tabledata.addCell(c);
				 tabledata.addCell(d);
				 tabledata.addCell(e);
				 tabledata.addCell(f);
				 
				 
				 //data bind
				 int  index=1;
				 for(int i=0;i<list.size();i++)
				 {
				
					 List<String> l = list.get(i);
				 Paragraph a1index = new Paragraph(String.valueOf(index),fontTableHeadingdata);
				 Paragraph pers_code = new Paragraph(l.get(1),fontTableHeadingdata);
				 Paragraph pers_name = new Paragraph(l.get(2),fontTableHeadingdata);
				 Paragraph armservice = new Paragraph(l.get(3),fontTableHeadingdata);
				 Paragraph chance = new Paragraph(l.get(4),fontTableHeadingdata);
				 Paragraph status = new Paragraph(l.get(5),fontTableHeadingdata);
				
//					 tabledata.addCell(a1index);
//					 tabledata.addCell(pers_code);
//					 tabledata.addCell(pers_name);
//					 tabledata.addCell(armservice);
//					 tabledata.addCell(chance);
//					 tabledata.addCell(status);
					 
					 
					 PdfPCell cell2 = new PdfPCell();
						if(i % 2 == 0){
							cell2.setBackgroundColor(java.awt.Color.lightGray);
						}
						cell2.setPhrase(a1index);
						tabledata.addCell(cell2);
						 cell2.setPhrase(pers_code);
						 tabledata.addCell(cell2);
						 cell2.setPhrase(pers_name);
						 tabledata.addCell(cell2);
						 cell2.setPhrase(armservice);
						 tabledata.addCell(cell2);
						 cell2.setPhrase(chance);
						 tabledata.addCell(cell2);
						 cell2.setPhrase(status);
						 tabledata.addCell(cell2);
					
					 index+=1;
					 
				 }
				 
			PdfPCell cell123;
			cell123 = new PdfPCell();
			
			cell123.addElement(tableheader);
			cell123.addElement(tabledata);
			
			cell123.setBorder(0);
			table.addCell(cell123);

			document.add(table);
			super.buildPdfMetadata(model, document, request);
		}


}
