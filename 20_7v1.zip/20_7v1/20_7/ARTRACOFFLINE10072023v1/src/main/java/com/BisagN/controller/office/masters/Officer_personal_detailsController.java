package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.Part_b_examinationController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.models.officers.masters.ARM_CODES_M;
import com.BisagN.models.officers.masters.COMMAND_CODE_M;
import com.BisagN.models.officers.masters.COMMISSION_TYPE_M;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.masters.RANK_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.OFFICER_ARM_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.OFFICER_RANK_M;
import com.BisagN.models.officers.others.TBL_ARM_HISTORY_M;
import com.BisagN.models.officers.trans.EXAM_CENTER_CODE_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Officer_personal_detailsController {

	@Autowired
	private Officer_personal_detailsDAO objDAO;
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private RoleBaseMenuDAO roledao; 
	
	@Autowired
	private PartB_ExaminationDAO partBDao;

	CommonController comm = new CommonController();

	// ----- Open Page Url-----//

	@RequestMapping(value = "Searchofficer_personal_detailsUrl", method = RequestMethod.GET)
	public ModelAndView Searchofficer_personal_detailsUrl(ModelMap Mmap, HttpServletRequest request,
			HttpSession session, @RequestParam(value = "msg", required = false) String msg, String opd_pers_no1,
			String opd_name1) {

//        	 String opd_personal_id=request.getParameter("opd_personal_id");
//				if(opd_personal_id == "" || opd_personal_id.equals("")) {
//					Mmap.put("msg", "Please Enter Personal No");		
//					return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
//				}
//        	 
//				 String opd_officer_name=request.getParameter("opd_officer_name");
//					if(opd_officer_name == "" || opd_officer_name.equals("")) {
//						Mmap.put("msg", "Please Enter Officer Name");		
//						return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
//					}
//					String cc_command_id=request.getParameter("cc_command_id");
//					if(cc_command_id == "" || cc_command_id.equals("0")) {
//						Mmap.put("msg", "Please Select Command");		
//						return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
//					}
//					
//					String opd_arm_service=request.getParameter("opd_arm_service");
//					if(opd_arm_service == "" || opd_arm_service.equals("0")) {
//						Mmap.put("msg", "Please Select Arm/Service");		
//						return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
//					}

		try {
			
			
			if(request.getHeader("Referer") == null ) { 
   			 session.invalidate();
   			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
   			 return new ModelAndView("redirect:/login");
   		 }

       	 String roleid1 = session.getAttribute("roleid").toString();
   		 Boolean val = roledao.ScreenRedirect("Searchofficer_personal_detailsUrl", roleid1);		
   			if(val == false) {
   				return new ModelAndView("AccessTiles");
   		}	
   		
			
			

			Mmap.put("msg", msg);
			Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL(sessionFactory));

			Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("SearchOfficer_personal_details_tile");
	}

	@RequestMapping(value = "/admin/Search_data", method = RequestMethod.POST)
	public ModelAndView Search_data(ModelMap Mmap, HttpSession session, HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg, String opd_pers_no1, String opd_name1) {

		return new ModelAndView("SearchOfficer_personal_details_tile");
	}

	/// ===========Data-table=================///

	@RequestMapping(value = "/getOfficer_personal_detailsReportDataList", method = RequestMethod.POST)
	public @ResponseBody List<Map<String, Object>> getOfficer_personal_detailsReportDataList(int startPage,
			String pageLength, String Search, String orderColunm, String orderType, String pers_no, String pers_name,
			 String arm,String doc, HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
System.err.println("doc=========="+doc);
		return objDAO.getReportListOfficer_personal_details(startPage, pageLength, Search, orderColunm, orderType,
				pers_no, pers_name, arm, doc, sessionUserId);
	}

	@RequestMapping(value = "/getOfficer_personal_detailsTotalCount", method = RequestMethod.POST)
	public @ResponseBody long getOfficer_personal_detailsTotalCount(HttpSession sessionUserId, String Search,
			String pers_no, String pers_name, String arm, String doc) {

		return objDAO.getReportListOfficer_personal_detailsTotalCount(Search, pers_no, pers_name, arm, doc);
	}

	
	
	@RequestMapping(value = "OfficerPerssetailURL", method = RequestMethod.POST)
	public ModelAndView OfficerPerssetailURL(ModelMap Mmap, HttpSession session,HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg, String ofcpersid) {

		if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

   	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("Searchofficer_personal_detailsUrl", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}	
		
		Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
		Mmap.put("getctcommtypeListDDL", comm.getctcommtypeListDDL(sessionFactory));
		Mmap.put("getctranktypeListDDL", comm.getctranktypeListDDL(sessionFactory));
		Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL(sessionFactory));
		System.out.println("Keval============"+comm.getPersonalType(sessionFactory));
		Mmap.put("getPersonalType", comm.getPersonalType(sessionFactory));

		Mmap.put("msg", msg);
		return new ModelAndView("Officer_personal_details_tile", "officer_personal_detailsCMD",
				new OFFICER_PERSONAL_DETAILS_M());
	}
	// ============== Save Action ============//

	@RequestMapping(value = "/officer_personal_detailsAction", method = RequestMethod.POST)
	public @ResponseBody String officer_personal_detailsAction(
			@Valid @ModelAttribute("officer_personal_detailsCMD") OFFICER_PERSONAL_DETAILS_M ln, BindingResult result,
			HttpServletRequest request, ModelMap model, HttpSession session) {
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		String save = "";

		try {

			String persnl_no1 = request.getParameter("persnl_no1");
			String opd_date_of_seniority = request.getParameter("opd_date_of_seniority");
			String opd_date_of_comm = request.getParameter("opd_date_of_comm");
			DateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
			Date birth_dt = null;
			
			
			
			System.err.println("persnl_no1========" + persnl_no1);
			if (persnl_no1.equals("-1")) {
				return "Please Select Personal No";
			}

			String opd_personal_no = request.getParameter("opd_personal_no");
			if (opd_personal_no == "" || opd_personal_no.equals("")) {
				return "Please Enter Personal No";
			}

			String opd_suffix_code1 = request.getParameter("opd_suffix_code");
			if (opd_suffix_code1 == "" || opd_suffix_code1.equals("")) {
				return "Please Enter Personal No";
			}
			String opd_officer_name = request.getParameter("opd_officer_name");
			if (opd_officer_name == "" || opd_officer_name.equals("")) {
				return "Please Enter Officer Name";
			}
//			String opd_unit = request.getParameter("opd_unit");
//			if (opd_unit == "" || opd_unit.equals("")) {
//				return "Please Enter Unit Name";
//			}
			String opd_rank1 = request.getParameter("opd_rank");
			if (opd_rank1 == "" || opd_rank1.equals("0")) {
				return "Please Select Rank";
			}
			String opd_dob = request.getParameter("opd_dob");
			if (opd_dob.equals("DD/MM/YYYY") || opd_dob.equals("") || opd_dob == "" || opd_dob == "DD/MM/YYYY") {
				return "Please Select Date of Birth";
			}

			Date date1=null;
			if (opd_dob!=null && !opd_dob.equals("") && !opd_dob.equals("DD/MM/YYYY") ) {
				birth_dt = format.parse(opd_dob);
				String is = opd_dob + "-01";
				date1 = format.parse(is);
			}
			if (comm.calculate_age(birth_dt, format.parse(opd_date_of_comm)) < 16) {
				return"Please enter age above 16";
			}
			
			if (comm.calculate_age(birth_dt, new Date()) < 16) {
				return "Please enter age above 16";
			}
			String opd_arm_service1 = request.getParameter("opd_arm_service");
			if (opd_arm_service1 == "" || opd_arm_service1.equals("0")) {
				return "Please Select Arm/Service";
			}
		
			if (opd_date_of_comm.equals("DD/MM/YYYY") || opd_date_of_comm.equals("") || opd_date_of_comm == ""
					|| opd_date_of_comm == "DD/MM/YYYY") {
				return "Please Select Date of Commission";
			}
			

			if (opd_dob != null && opd_date_of_seniority != null) {
				if (date1.compareTo(format.parse(opd_date_of_seniority)) > 0) {
					return  "  Date of Seniority  should not be before Date of Birth ";
				}
			}
			String ct_comm_id = request.getParameter("ct_comm_id");
			if (ct_comm_id == "" || ct_comm_id.equals("0")) {
				return "Please Select Commission Type";
			}
			
			if (opd_date_of_seniority.equals("DD/MM/YYYY") || opd_date_of_seniority.equals("")
					|| opd_date_of_seniority == "" || opd_date_of_seniority == "DD/MM/YYYY") {
				return "Please Select Date of Seniority";
			}
			

			
			String cc_command_id = request.getParameter("cc_command_id");
			if (cc_command_id == "" || cc_command_id.equals("0")) {
				return "Please Select Command";
			}


			try {
				String opd_personal_id = request.getParameter("opd_personal_id");

				String opd_arm_service = request.getParameter("opd_arm_service");
				String opd_rank = request.getParameter("opd_rank");
				System.err.println("opd_rank=============" + opd_rank);

				System.err.println("opd_arm_service=============" + opd_arm_service);
				String personal_code = request.getParameter("persnl_no1") + request.getParameter("opd_personal_no");
				String opd_suffix_code = request.getParameter("opd_suffix_code");

				String opd_remark = request.getParameter("opd_remarks");

				int id = ln.getOpd_personal_id() > 0 ? ln.getOpd_personal_id() : 0;
				Date date = new Date();
				String username = session.getAttribute("username").toString();
				OFFICER_PERSONAL_CODE_M ofcode = new OFFICER_PERSONAL_CODE_M();
				try {

					Query q0 = sessionHQL.createQuery(
							"select count(*) from OFFICER_PERSONAL_CODE_M where  opc_personal_code=:opc_personal_code and opd_personal_id!=:opd_personal_id");

					q0.setParameter("opc_personal_code", personal_code);

					q0.setParameter("opd_personal_id", id);
					Long c = (Long) q0.uniqueResult();
					System.err.println("c=========" + comm.convertStringToDate(request.getParameter("opd_dob")));

					

					if (id == 0) {

						if (c == 0 ) {

							ln.setOpd_isactive("yes");
							ln.setOpd_remarks(opd_remark);
							ln.setOpd_status_id(1);
							ln.setCourse_no(request.getParameter("course_no"));
							ln.setOpd_unit(request.getParameter("opd_unit"));
							ln.setOpd_type_of_entry(request.getParameter("opd_type_of_entry"));
							ln.setOpd_cpsc_course(request.getParameter("opd_cpsc_course"));
							ln.setOpd_jc_course_grading(request.getParameter("opd_jc_grading"));
							ln.setOpd_cpsc_on_off(request.getParameter("opd_cpsc_on_off"));
							ln.setOpd_jc_course_no(request.getParameter("opd_jc_number"));
							
							ArrayList<ArrayList<String>> list = partBDao.getSubjectList("Part B", opd_arm_service);
							
							System.err.println("list----"+list);
							int sum = 0;
							
							if(!list.isEmpty()) {
							for (int i = 0; i < list.size(); i++) {
								System.err.println(list.get(i).get(2));

								String sub = list.get(i).get(2);

								sum += Integer.parseInt(sub);

							}
							}else {
								
								ArrayList<ArrayList<String>> list2 = partBDao.getSubjectList("Part D", opd_arm_service);
								for (int i = 0; i < list2.size(); i++) {
									System.err.println(list2.get(i).get(2));

									String sub = list2.get(i).get(2);

									sum += Integer.parseInt(sub);
									ln.setOpd_partb(1111);
								}
								
							}
							ln.setPbda_sub_code(sum);
							int mid = (int) sessionHQL.save(ln);
							sessionHQL.flush();
							sessionHQL.clear();

							tx.commit();

							OFFICER_PERSONAL_CODE_M op_pers_code = new OFFICER_PERSONAL_CODE_M();

							Session sessionHQL1 = this.sessionFactory.openSession();
							Transaction tx1 = sessionHQL1.beginTransaction();
							op_pers_code.setOpc_personal_code(personal_code);
							op_pers_code.setOpc_suffix_code(opd_suffix_code);
							op_pers_code.setOpc_creation_date(date);
							op_pers_code.setOpc_created_by(username);
							op_pers_code.setOpc_status_id(1);
							op_pers_code.setOpd_personal_id(mid);
							sessionHQL1.save(op_pers_code);
							tx1.commit();

							OFFICER_ARM_M of_arm = new OFFICER_ARM_M();
							Session sessionHQL2 = this.sessionFactory.openSession();
							Transaction tx2 = sessionHQL1.beginTransaction();
							of_arm.setAc_arm_id(Integer.parseInt(opd_arm_service));
							of_arm.setAc_arm_code(opd_arm_service);
							of_arm.setOa_created_by(username);
							of_arm.setOa_creation_date(date);
							of_arm.setOa_status_id(1);
							of_arm.setOpd_personal_id(mid);
							sessionHQL2.save(of_arm);
							tx2.commit();

							OFFICER_RANK_M of_rank = new OFFICER_RANK_M();
							Session sessionHQL3 = this.sessionFactory.openSession();
							Transaction tx3 = sessionHQL1.beginTransaction();
							of_rank.setOpd_personal_id(mid);
							of_rank.setOr_created_by(username);
							of_rank.setOr_creation_date(date);
							of_rank.setRc_rank_id(Integer.parseInt(opd_rank));
							of_rank.setOr_status_id(1);
							sessionHQL3.save(of_rank);
							tx3.commit();

							save = "Data Saved Successfully.";

						} else {
							save = "Data already Exist.";
						}
					}

				} catch (RuntimeException e) {
					try {
						tx.rollback();
						model.put("msg", "roll back transaction");
					} catch (RuntimeException rbe) {
						model.put("msg", "Couldn�t roll back transaction " + rbe);
					}
					throw e;
				} finally {
					if (sessionHQL != null) {
						sessionHQL.close();
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}

		return save;

	}

	@RequestMapping(value = "EditOfficer_personal_detailsUrl", method = RequestMethod.POST)
	public ModelAndView EditOfficer_personal_detailsUrl(ModelMap Mmap, HttpSession session,HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg, String updateid) {

		if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

   	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("Searchofficer_personal_detailsUrl", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}
			
			
		Session s1 = this.sessionFactory.openSession();
		Transaction tx = s1.beginTransaction();
		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);
		Query q = null;
		q = s1.createQuery("from OFFICER_PERSONAL_DETAILS_M where cast(id as string)=:PK");
		q.setString("PK", DcryptedPk);
		@SuppressWarnings("unchecked")
		List<String> list = (List<String>) q.list();
		tx.commit();
		s1.close();

		Mmap.put("Editofficer_personal_detailsCMD1", list.get(0));
		Mmap.put("Edit_pers_details", objDAO.getpersdetails(DcryptedPk));
		Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
		Mmap.put("getctcommtypeListDDL", comm.getctcommtypeListDDL(sessionFactory));
		Mmap.put("getctranktypeListDDL", comm.getctranktypeListDDL(sessionFactory));
		Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL(sessionFactory));
		Mmap.put("getPersonalType", comm.getPersonalType(sessionFactory));
		Mmap.put("msg", msg);
		return new ModelAndView("EditOfficer_personal_details_tile", "Editofficer_personal_detailsCMD",
				new OFFICER_PERSONAL_DETAILS_M());
	}

	@RequestMapping(value = "/Editofficer_personal_detailsAction", method = RequestMethod.POST)
	public ModelAndView Editofficer_personal_detailsAction(
			@Valid @ModelAttribute("Editofficer_personal_detailsCMD") OFFICER_PERSONAL_DETAILS_M ln,
			BindingResult result, HttpServletRequest request, ModelMap model, HttpSession session) {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();

		Date date = new Date();
		String username = session.getAttribute("username").toString();

		String opd_id = request.getParameter("opd_personal_id");
		String pers_code = request.getParameter("persnl_no1") + request.getParameter("opd_personal_no");
		String opd_officer_name = request.getParameter("opd_officer_name");
		String ct_comm_id = request.getParameter("ct_comm_id");
		String cc_command_id = request.getParameter("cc_command_id");
		String opd_unit = request.getParameter("opd_unit");
		String opd_unit_address2 = request.getParameter("opd_unit_address1");
		String opd_unit_address3 = request.getParameter("opd_unit_address2");
		String opd_dob = request.getParameter("opd_dob");
		String opd_date_of_comm = request.getParameter("opd_date_of_comm");
		String opd_date_of_seniority = request.getParameter("opd_date_of_seniority");
		String opd_isactive = request.getParameter("opd_isactive");
		System.err.println("========================opd_isactive=================="+opd_isactive);

	        if (opd_isactive == null)
	        {
	        	opd_isactive="no";
	        }
	        else
	        {
	        	opd_isactive = "yes";
	        }
	         
		String opd_remarks = request.getParameter("opd_remarks");
		String auth_letter_no = request.getParameter("auth_letter_no");

		String opd_suffix_code = request.getParameter("opd_suffix_code");

		int opd_rank = Integer.parseInt(request.getParameter("opd_rank"));

		String opd_arm_service = request.getParameter("opd_arm_service");

		ln.setOpd_personal_id(Integer.parseInt(request.getParameter("opd_personal_id")));

		String persnl_no1 = request.getParameter("persnl_no1");
		if (persnl_no1 == "" || persnl_no1.equals("-1")) {
			model.put("msg", "Please Select Personal No");
			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
		}

		String opd_personal_no = request.getParameter("opd_personal_no");
		if (opd_personal_no == "" || opd_personal_no.equals("")) {
			model.put("msg", "Please Enter Personal No");
			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
		}

		String opd_suffix_code1 = request.getParameter("opd_suffix_code");
		if (opd_suffix_code1 == "" || opd_suffix_code1.equals("")) {
			model.put("msg", "Please Enter Personal No");
			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
		}
		String opd_officer_name1 = request.getParameter("opd_officer_name");
		if (opd_officer_name == "" || opd_officer_name.equals("")) {
			model.put("msg", "Please Enter Officer Name");
			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
		}
		// String opd_unit=request.getParameter("opd_unit");
//		if (opd_unit == "" || opd_unit.equals("")) {
//			model.put("msg", "Please Enter Unit Name");
//			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
//		}
		String opd_rank1 = request.getParameter("opd_rank");
		if (opd_rank1 == "" || opd_rank1.equals("0")) {
			model.put("msg", "Please Select Rank");
			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
		}
		// String opd_dob=request.getParameter("opd_dob");
		if (opd_dob.equals("DD/MM/YYYY") || opd_dob.equals("") || opd_dob == "" || opd_dob == "DD/MM/YYYY") {
			model.put("msg", "Please Select Date of Birth");
			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
		}
		String opd_arm_service1 = request.getParameter("opd_arm_service");
		if (opd_arm_service1 == "" || opd_arm_service1.equals("0")) {
			model.put("msg", "Please Select Arm/Service");
			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
		}
		// String opd_date_of_comm=request.getParameter("opd_date_of_comm");
		if (opd_date_of_comm.equals("DD/MM/YYYY") || opd_date_of_comm.equals("") || opd_date_of_comm == ""
				|| opd_date_of_comm == "DD/MM/YYYY") {
			model.put("msg", "Please Select Date of Commission");
			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
		}
		// String ct_comm_id=request.getParameter("ct_comm_id");
		if (ct_comm_id == "" || ct_comm_id.equals("0")) {
			model.put("msg", "Please Select Commission Type");
			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
		}
		// String opd_date_of_seniority=request.getParameter("opd_date_of_seniority");
		if (opd_date_of_seniority.equals("DD/MM/YYYY") || opd_date_of_seniority.equals("")
				|| opd_date_of_seniority == "" || opd_date_of_seniority == "DD/MM/YYYY") {
			model.put("msg", "Please Select Date of Seniority");
			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
		}
		// String cc_command_id=request.getParameter("cc_command_id");
		if (cc_command_id == "" || cc_command_id.equals("0")) {
			model.put("msg", "Please Select Command");
			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
		}

//		String opd_unit_address1 = request.getParameter("opd_unit_address1");
//		if (opd_unit_address1 == "" || opd_unit_address1.equals("")) {
//			model.put("msg", "Please Enter Unit Address");
//			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
//		}
		// String opd_unit_address2=request.getParameter("opd_unit_address2");
//		if (opd_unit_address2 == "" || opd_unit_address2.equals("")) {
//			model.put("msg", "Please Enter Unit Address");
//			return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
//		}

		try {
			String hql = "update OFFICER_PERSONAL_DETAILS_M set ct_comm_id=:ct_comm_id,cc_command_id=:cc_command_id, opd_officer_name=:opd_officer_name,opd_unit=:opd_unit,"
					+ "opd_unit_address1=:opd_unit_address1,opd_unit_address2=:opd_unit_address2,opd_dob=:opd_dob,opd_date_of_comm=:opd_date_of_comm,opd_date_of_seniority=:opd_date_of_seniority,"
					+ "opd_isactive=:opd_isactive, opd_remarks=:opd_remarks, auth_letter_no=:auth_letter_no, opd_status_id=:opd_status_id,opd_modified_by=:opd_modified_by,opd_modification_date=:opd_modification_date,opd_type_of_entry=:opd_type_of_entry,"
					+ "opd_cpsc_course=:opd_cpsc_course,opd_jc_course_grading=:opd_jc_course_grading,opd_cpsc_on_off=:opd_cpsc_on_off,opd_jc_number=:opd_jc_number where opd_personal_id=:opd_personal_id ";
			Query query = sessionHQL.createQuery(hql).setParameter("ct_comm_id", Integer.parseInt(ct_comm_id))
					.setParameter("cc_command_id", Integer.parseInt(cc_command_id))
					.setParameter("opd_officer_name", opd_officer_name).setParameter("opd_unit", opd_unit)
					.setParameter("opd_unit_address1", opd_unit_address2)
					.setParameter("opd_unit_address2", opd_unit_address3)
					.setParameter("opd_dob", comm.convertStringToDate(opd_dob))
					.setParameter("opd_date_of_comm", comm.convertStringToDate(opd_date_of_comm))
					.setParameter("opd_date_of_seniority", comm.convertStringToDate(opd_date_of_seniority))
					.setParameter("opd_isactive", opd_isactive).setParameter("opd_remarks", opd_remarks)
					.setParameter("auth_letter_no", auth_letter_no).setParameter("opd_status_id", 1)
					.setParameter("opd_modified_by", username).setParameter("opd_modification_date", date)
					.setParameter("opd_type_of_entry", request.getParameter("opd_type_of_entry"))
					.setParameter("opd_cpsc_course", request.getParameter("opd_cpsc_course"))
					.setParameter("opd_jc_course_grading", request.getParameter("opd_jc_grading"))
					.setParameter("opd_cpsc_on_off", request.getParameter("opd_cpsc_on_off"))
					.setParameter("opd_jc_number", request.getParameter("opd_jc_number"))
					.setParameter("opd_personal_id", Integer.parseInt(opd_id));
			query.executeUpdate();

			String hq1l = "update OFFICER_PERSONAL_CODE_M set opc_personal_code=:opc_personal_code, opc_suffix_code=:opc_suffix_code,opd_personal_id=:opd_personal_id,"
					+ "opc_status_id=:opc_status_id,opc_modified_by=:opc_modified_by, opc_modification_date=:opc_modification_date  where opd_personal_id=:opd_personal_id ";
			Query query1 = sessionHQL.createQuery(hq1l).setParameter("opc_personal_code", pers_code)
					.setParameter("opc_suffix_code", opd_suffix_code)
					.setParameter("opd_personal_id", Integer.parseInt(opd_id)).setParameter("opc_status_id", 1)
					.setParameter("opc_modified_by", username).setParameter("opc_modification_date", date)
//					.setParameter("opd_isactive", Integer.parseInt("opd_isactive"),"NO")
					.setParameter("opd_personal_id", Integer.parseInt(opd_id));
			query1.executeUpdate();

			String hq13 = "update OFFICER_RANK_M set rc_rank_id=:rc_rank_id, opd_personal_id=:opd_personal_id, or_status_id=:or_status_id,or_modified_by=:or_modified_by,"
					+ "or_modification_date=:or_modification_date  where opd_personal_id=:opd_personal_id ";
			Query query3 = sessionHQL.createQuery(hq13).setParameter("rc_rank_id", opd_rank)
					.setParameter("opd_personal_id", Integer.parseInt(opd_id)).setParameter("or_status_id", 1)
					.setParameter("or_modified_by", username).setParameter("or_modification_date", date)
//					.setParameter("opd_isactive", Integer.parseInt("opd_isactive"),"NO")
					.setParameter("opd_personal_id", Integer.parseInt(opd_id));
			query3.executeUpdate();

			String hql4 = "update OFFICER_ARM_M set ac_arm_id=:ac_arm_id,opd_personal_id=:opd_personal_id, ac_arm_code=:ac_arm_code, oa_status_id=:oa_status_id,"
					+ "oa_modified_by=:oa_modified_by, oa_modification_date=:oa_modification_date  where opd_personal_id=:opd_personal_id ";
			Query query4 = sessionHQL.createQuery(hql4).setParameter("ac_arm_id", Integer.parseInt(opd_arm_service))
					.setParameter("ac_arm_code", opd_arm_service)
					.setParameter("opd_personal_id", Integer.parseInt(opd_id)).setParameter("oa_status_id", 1)
					.setParameter("oa_modified_by", username).setParameter("oa_modification_date", date)
//					.setParameter("opd_isactive", Integer.parseInt("opd_isactive"),"NO")
					.setParameter("opd_personal_id", Integer.parseInt(opd_id));
			query4.executeUpdate();

			tx.commit();
			sessionHQL.close();

			model.put("msg", "Data Updated Successfully");
		} catch (RuntimeException e) {
			e.printStackTrace();
			tx.rollback();

			model.put("msg", "Server side Error");

		}

		return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
	}

	@RequestMapping(value = "/deleteofficer_personal_detailsUrl", method = RequestMethod.POST)
	public ModelAndView deleteofficer_personal_detailsUrl(String deleteid, HttpSession session, ModelMap model) {

		System.err.println("deleteid===========" + deleteid);
		String msg = "";
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();

		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) deleteid, enckey, session);
		System.out.println(DcryptedPk + "==========DcryptedPk");
		try {
			String hql = "update OFFICER_PERSONAL_CODE_M set opc_status_id=:opc_status_id  where opd_personal_id=:opd_personal_id ";
			Query query = sessionHQL.createQuery(hql).setParameter("opc_status_id", 0).setParameter("opd_personal_id",
					Integer.parseInt(DcryptedPk));
			query.executeUpdate();

			String hq1l = "update OFFICER_ARM_M set oa_status_id=:oa_status_id  where opd_personal_id=:opd_personal_id ";
			Query query1 = sessionHQL.createQuery(hq1l).setParameter("oa_status_id", 0).setParameter("opd_personal_id",
					Integer.parseInt(DcryptedPk));
			query1.executeUpdate();

			String hq13 = "update OFFICER_RANK_M set or_status_id=:or_status_id  where opd_personal_id=:opd_personal_id ";
			Query query3 = sessionHQL.createQuery(hq13).setParameter("or_status_id", 0).setParameter("opd_personal_id",
					Integer.parseInt(DcryptedPk));
			query3.executeUpdate();

			String hq14 = "update OFFICER_PERSONAL_DETAILS_M set opd_status_id=:opd_status_id  where opd_personal_id=:opd_personal_id ";
			Query query4 = sessionHQL.createQuery(hq14).setParameter("opd_status_id", 0).setParameter("opd_personal_id",
					Integer.parseInt(DcryptedPk));
			query4.executeUpdate();

			model.put("msg", msg);
			model.put("msg", "Delete Successfully");

			tx.commit();
		} catch (RuntimeException e) {
			e.printStackTrace();
			tx.rollback();

			model.put("msg", "Server side Error");

		}

		return new ModelAndView("redirect:Searchofficer_personal_detailsUrl");
	}

	

}
