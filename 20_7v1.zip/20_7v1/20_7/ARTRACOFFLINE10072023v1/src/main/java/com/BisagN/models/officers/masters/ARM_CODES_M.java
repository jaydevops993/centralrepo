package com.BisagN.models.officers.masters;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "arm_codes", uniqueConstraints = {
@UniqueConstraint(columnNames = "ac_arm_id"),})
public class ARM_CODES_M {

      private int ac_arm_id;
      private String ac_arm_code;
      private String ac_arm_description;
      private int ac_status_id;
      private int ac_arm_order;
      private String ac_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date ac_creation_date;
      private String ac_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date ac_modification_date;



  
	@Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "ac_arm_id", unique = true, nullable = false)
    	
	public int getAc_arm_id() {
		return ac_arm_id;
	}
	public void setAc_arm_id(int ac_arm_id) {
		this.ac_arm_id = ac_arm_id;
	}
      public String getAc_arm_code() {
           return ac_arm_code;
      }
      
	public void setAc_arm_code(String ac_arm_code) {
	  this.ac_arm_code = ac_arm_code;
      }
      public String getAc_arm_description() {
           return ac_arm_description;
      }
      public void setAc_arm_description(String ac_arm_description) {
	  this.ac_arm_description = ac_arm_description;
      }
      public int getAc_status_id() {
           return ac_status_id;
      }
      public void setAc_status_id(int ac_status_id) {
	  this.ac_status_id = ac_status_id;
      }
      public int getAc_arm_order() {
           return ac_arm_order;
      }
      public void setAc_arm_order(int ac_arm_order) {
	  this.ac_arm_order = ac_arm_order;
      }
      public String getAc_created_by() {
           return ac_created_by;
      }
      public void setAc_created_by(String ac_created_by) {
	  this.ac_created_by = ac_created_by;
      }
      public Date getAc_creation_date() {
           return ac_creation_date;
      }
      public void setAc_creation_date(Date ac_creation_date) {
	  this.ac_creation_date = ac_creation_date;
      }
      public String getAc_modified_by() {
           return ac_modified_by;
      }
      public void setAc_modified_by(String ac_modified_by) {
	  this.ac_modified_by = ac_modified_by;
      }
      public Date getAc_modification_date() {
           return ac_modification_date;
      }
      public void setAc_modification_date(Date ac_modification_date) {
	  this.ac_modification_date = ac_modification_date;
      }
}
