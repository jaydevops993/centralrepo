package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.Group_MasterDAO;
import com.BisagN.dao.officer.masters.Reason_MasterDAO;
import com.BisagN.models.officers.masters.GROUP_M;
import com.BisagN.models.officers.masters.Reason_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Reason_Mst_Controller {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	private Reason_MasterDAO objDAO;

	@Autowired
	private RoleBaseMenuDAO roledao;

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

	// ===========================OPEN PAGE============================//
	@RequestMapping(value = "ReasonMasterUrl", method = RequestMethod.GET)
	public ModelAndView ReasonMasterUrl(ModelMap Mmap, HttpSession session, HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		if (request.getHeader("Referer") == null) {
			session.invalidate();
			Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			return new ModelAndView("redirect:/login");
		}

		String roleid1 = session.getAttribute("roleid").toString();
		Boolean val = roledao.ScreenRedirect("ReasonMasterUrl", roleid1);
		if (val == false) {
			return new ModelAndView("AccessTiles");
		}

		Mmap.put("msg", msg);
		return new ModelAndView("ReasonMasterTiles");
	}

	// ============================SAVE==========================//

	@RequestMapping(value = "/ReasonMasterAction", method = RequestMethod.POST)
	public ModelAndView ReasonMasterAction(@ModelAttribute("ReasonMstCMD") Reason_M ln, BindingResult result,
			HttpServletRequest request, ModelMap model, HttpSession session) {

		String reasonName = request.getParameter("reason_name");
		if (reasonName == "" || reasonName.equals("")) {
			model.put("msg", "Please Enter Reason Name");
			return new ModelAndView("redirect:ReasonMasterUrl");
		}

		int id = ln.getId() > 0 ? ln.getId() : 0;

		// System.err.println("id================"+id);
		Date date = new Date();
		String username = session.getAttribute("username").toString();
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();

		try {

			Query q0 = sessionHQL
					.createQuery("select count(id) from Reason_M where LOWER(reason_name)=:reason_name and id!=:id");
//																							and area_type_id!=:id

			q0.setParameter("reason_name", ln.getReason_name().toLowerCase());
			q0.setParameter("id", id);
			Long c = (Long) q0.uniqueResult();

			if (id == 0) {

				if (c == 0) {

					ln.setCreated_by(username);
					ln.setCreated_date(date);
					ln.setStatus(1);
					sessionHQL.save(ln);
					sessionHQL.flush();
					sessionHQL.clear();
					model.put("msg", "Data Saved Successfully.");

				} else {
					model.put("msg", "Data already Exist.");
				}
			}

			tx.commit();
		} catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return new ModelAndView("redirect:ReasonMasterUrl");
	}

	// =======================SEARCH============================//

	@RequestMapping(value = "/getReason_MasterReportDataList", method = RequestMethod.POST)
	public @ResponseBody List<Map<String, Object>> getReason_MasterReportDataList(int startPage, String pageLength,
			String Search, String orderColunm, String orderType, HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		return objDAO.getReportListReason_Master(startPage, pageLength, Search, orderColunm, orderType, sessionUserId);
	}

	@RequestMapping(value = "/getReason_MasterTotalCount", method = RequestMethod.POST)
	public @ResponseBody long getReason_MasterTotalCount(HttpSession sessionUserId, String Search, String name) {

		return objDAO.getReportListReason_MasterTotalCount(Search);
	}

	// =============================EDIT OPEN PAGE=============================//

	@RequestMapping(value = "EditReasonMasterUrl", method = RequestMethod.POST)
	public ModelAndView EditReasonMasterUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String updateid) {

		Session s1 = this.sessionFactory.openSession();
		Transaction tx = s1.beginTransaction();

		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);

		Query q = null;
		q = s1.createQuery("from Reason_M where cast(id as string)=:PK");
		q.setString("PK", DcryptedPk);

		@SuppressWarnings("unchecked")
		List<String> list = (List<String>) q.list();
		tx.commit();
		s1.close();

		Mmap.put("EditReasonMstCMD1", list.get(0));
		Mmap.put("msg", msg);

		return new ModelAndView("EditReasonMasterTiles", "EditReasonMstCMD", new Reason_M());
//		, "EditReasonMstCMD", new Reason_M()
	}

	// ============================UPDATE========================//
	@RequestMapping(value = "/EditReasonMasterAction", method = RequestMethod.POST)
	public ModelAndView EditReasonMasterAction(@ModelAttribute("EditReasonMstCMD") Reason_M ln, BindingResult result,
			HttpServletRequest request, ModelMap model, HttpSession session) {

//   	 int errCount = 0;
//
//			if (request.getParameter("gm_groupname").equals("") || request.getParameter("gm_groupname") == null) {
//				errCount++;
//				model.put("gm_groupname_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Choice Name");
//			}
//			if (errCount > 0) {
//
//				return new ModelAndView("EditGroupMasterTiles");
//			}

//    	 System.out.println(request.getParameter("rm_reasonname"));
		String rm_reason_name = request.getParameter("reason_name");

		if (rm_reason_name == "" || rm_reason_name.equals("")) {
			model.put("msg", "Please Enter Reason Name");
			return new ModelAndView("redirect:ReasonMasterUrl");
		}

		Date date = new Date();
		String username = session.getAttribute("username").toString();
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();

		ln.setId(Integer.parseInt(request.getParameter("id")));
		ln.setStatus(1);
//		ln.setReason_name(rm_reason_name);
		sessionHQL.saveOrUpdate(ln);
		ln.setModified_by(username);
		ln.setModified_date(date);

		tx.commit();
		sessionHQL.close();

		model.put("msg", "Data Updated Successfully");
		return new ModelAndView("redirect:ReasonMasterUrl");
	}
	
	 //=======================DELETE===========================//
	 @RequestMapping(value = "/DeleteReasonMasterUrl", method = RequestMethod.POST) 
	  public ModelAndView DeleteReasonMasterUrl(String deleteid,HttpSession session,ModelMap model) { 
		 
	  	List<String> list = new ArrayList<String>(); 
	  	list.add(objDAO.DeleteReasonMaster(deleteid,session)); 
	  	
	  	model.put("msg",list);  
	  	
	    return new ModelAndView("redirect:ReasonMasterUrl"); 
	    
	  	}

}
