package com.BisagN.models.officers.trans;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "upload_dssc_data_tbl_dum", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})
public class UPLOAD_DSSC_DATA_TBL_DUM {
	
		private int id;
		private String arms;
		private String ic_no;
		private String rank;
		private String ind_name;
		private String unit;
		private String loc_unit;
		private String regt;
		private String comd;
		private String type_entry;
		private Date doc;
		private Date dos;
		private String medcat;
		private String cpsc;
		private String c_apply;
		private String first_choice;
		private String second_choice;
		private String tech_nontech;
		private String ist;
		private String second;
		private String cc_mndtry;
		private String attmpt;
		private String exm_centre_alct;
		private String m_tech_yr;
		private String jc_course;
		private String  phone_no;
		private String fd_duration;
		private Date dob;
		private Date ante_dt_sene;
		private Date tors;
		private String appt;
		private String email;
		private String first_atmp_yr;
		private String secnd_atmp_yr;
		private String thrd_atmp_yr;
		private String yr_auth;
		private String yos;
		private String part_d;
		private String partd_auth;
		private String long_course;
		private String fd_ser;
		
		 @Id
	      @GeneratedValue(strategy = IDENTITY)
	      @Column(name = "id", unique = true, nullable = false)
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getArms() {
			return arms;
		}
		public void setArms(String arms) {
			this.arms = arms;
		}
		public String getIc_no() {
			return ic_no;
		}
		public void setIc_no(String ic_no) {
			this.ic_no = ic_no;
		}
		public String getRank() {
			return rank;
		}
		public void setRank(String rank) {
			this.rank = rank;
		}
		public String getInd_name() {
			return ind_name;
		}
		public void setInd_name(String ind_name) {
			this.ind_name = ind_name;
		}
		public String getUnit() {
			return unit;
		}
		public void setUnit(String unit) {
			this.unit = unit;
		}
		public String getLoc_unit() {
			return loc_unit;
		}
		public void setLoc_unit(String loc_unit) {
			this.loc_unit = loc_unit;
		}
		public String getRegt() {
			return regt;
		}
		public void setRegt(String regt) {
			this.regt = regt;
		}
		public String getComd() {
			return comd;
		}
		public void setComd(String comd) {
			this.comd = comd;
		}
		public String getType_entry() {
			return type_entry;
		}
		public void setType_entry(String type_entry) {
			this.type_entry = type_entry;
		}
		public Date getDoc() {
			return doc;
		}
		public void setDoc(Date doc) {
			this.doc = doc;
		}
		public Date getDos() {
			return dos;
		}
		public void setDos(Date dos) {
			this.dos = dos;
		}
		public String getMedcat() {
			return medcat;
		}
		public void setMedcat(String medcat) {
			this.medcat = medcat;
		}
		public String getCpsc() {
			return cpsc;
		}
		public void setCpsc(String cpsc) {
			this.cpsc = cpsc;
		}
		public String getC_apply() {
			return c_apply;
		}
		public void setC_apply(String c_apply) {
			this.c_apply = c_apply;
		}
		public String getFirst_choice() {
			return first_choice;
		}
		public void setFirst_choice(String first_choice) {
			this.first_choice = first_choice;
		}
		public String getSecond_choice() {
			return second_choice;
		}
		public void setSecond_choice(String second_choice) {
			this.second_choice = second_choice;
		}
		public String getTech_nontech() {
			return tech_nontech;
		}
		public void setTech_nontech(String tech_nontech) {
			this.tech_nontech = tech_nontech;
		}
		public String getIst() {
			return ist;
		}
		public void setIst(String ist) {
			this.ist = ist;
		}
		public String getSecond() {
			return second;
		}
		public void setSecond(String second) {
			this.second = second;
		}
		public String getCc_mndtry() {
			return cc_mndtry;
		}
		public void setCc_mndtry(String cc_mndtry) {
			this.cc_mndtry = cc_mndtry;
		}
		public String getAttmpt() {
			return attmpt;
		}
		public void setAttmpt(String attmpt) {
			this.attmpt = attmpt;
		}
		public String getExm_centre_alct() {
			return exm_centre_alct;
		}
		public void setExm_centre_alct(String exm_centre_alct) {
			this.exm_centre_alct = exm_centre_alct;
		}
		public String getM_tech_yr() {
			return m_tech_yr;
		}
		public void setM_tech_yr(String m_tech_yr) {
			this.m_tech_yr = m_tech_yr;
		}
		public String getJc_course() {
			return jc_course;
		}
		public void setJc_course(String jc_course) {
			this.jc_course = jc_course;
		}
		public String getPhone_no() {
			return phone_no;
		}
		public void setPhone_no(String phone_no) {
			this.phone_no = phone_no;
		}
		public String getFd_duration() {
			return fd_duration;
		}
		public void setFd_duration(String fd_duration) {
			this.fd_duration = fd_duration;
		}
		public Date getDob() {
			return dob;
		}
		public void setDob(Date dob) {
			this.dob = dob;
		}
		public Date getAnte_dt_sene() {
			return ante_dt_sene;
		}
		public void setAnte_dt_sene(Date ante_dt_sene) {
			this.ante_dt_sene = ante_dt_sene;
		}
		public Date getTors() {
			return tors;
		}
		public void setTors(Date tors) {
			this.tors = tors;
		}
		public String getAppt() {
			return appt;
		}
		public void setAppt(String appt) {
			this.appt = appt;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getFirst_atmp_yr() {
			return first_atmp_yr;
		}
		public void setFirst_atmp_yr(String first_atmp_yr) {
			this.first_atmp_yr = first_atmp_yr;
		}
		public String getSecnd_atmp_yr() {
			return secnd_atmp_yr;
		}
		public void setSecnd_atmp_yr(String secnd_atmp_yr) {
			this.secnd_atmp_yr = secnd_atmp_yr;
		}
		public String getThrd_atmp_yr() {
			return thrd_atmp_yr;
		}
		public void setThrd_atmp_yr(String thrd_atmp_yr) {
			this.thrd_atmp_yr = thrd_atmp_yr;
		}
		public String getYr_auth() {
			return yr_auth;
		}
		public void setYr_auth(String yr_auth) {
			this.yr_auth = yr_auth;
		}
		public String getYos() {
			return yos;
		}
		public void setYos(String yos) {
			this.yos = yos;
		}
		public String getPart_d() {
			return part_d;
		}
		public void setPart_d(String part_d) {
			this.part_d = part_d;
		}
		public String getPartd_auth() {
			return partd_auth;
		}
		public void setPartd_auth(String partd_auth) {
			this.partd_auth = partd_auth;
		}
		public String getLong_course() {
			return long_course;
		}
		public void setLong_course(String long_course) {
			this.long_course = long_course;
		}
		public String getFd_ser() {
			return fd_ser;
		}
		public void setFd_ser(String fd_ser) {
			this.fd_ser = fd_ser;
		}
		
		
		
		

}
 


