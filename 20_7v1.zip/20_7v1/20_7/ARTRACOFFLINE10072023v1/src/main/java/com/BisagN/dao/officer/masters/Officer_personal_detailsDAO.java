package com.BisagN.dao.officer.masters;


import java.util.List;
import java.util.Map;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import org.apache.commons.codec.binary.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import org.hibernate.Session;
import java.util.ArrayList;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;


public interface Officer_personal_detailsDAO {

	public List<Map<String, Object>> getReportListOfficer_personal_details(int startPage,String pageLength,String Search,String orderColunm,String orderType,String pers_no,String pers_name,String arm,String doc, HttpSession session) 
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	public long getReportListOfficer_personal_detailsTotalCount(String Search,String pers_no,String pers_name,String arm, String doc);

	
	public String Deleteofficer_personal_details(String deleteid,HttpSession session);
	public List<Map<String, Object>> getpersdetails(String pers_no);
	   public String getcommnadidbycommnadname(String commnad_name) ;
	   
	   public String getcommsssionidbycommissionname(String comm_type) ;
	   public String gearmidbyarmname(String arm_code);
	   public String geRankidbyRankname(String rank_name);
	   public List<Map<String, Object>> getarmcodeforIASTcase(String pers_no) ;
}
