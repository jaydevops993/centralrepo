package com.BisagN.controller.office_DSSC_MeritRerport;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
//import com.BisagN.controller.office_DSSC_Report.ArmWiseAnalysisDssc_dstscPdfReportController.PageNumeration;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;

public class ReserveListDSSC_DSTSCPdfReportController extends AbstractPdfView {
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	int totalRecords = 0;
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public ReserveListDSSC_DSTSCPdfReportController(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH;
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {

		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);

		Chunk chunk = new Chunk();

		Chunk underline1 = new Chunk("Reserve List DSSC/DSTSC ", fontTableHeading1);
		underline1.setUnderline(0.1f, -2f);

		Chunk glue = new Chunk(new VerticalPositionMark());

		Phrase phh2 = new Phrase(underline1);
		phh2.add("\n");
		phh2.add("\n");

		Paragraph cell12 = new Paragraph(phh2);
		cell12.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell12);

		PdfPTable tabledata = new PdfPTable(7);
		tabledata.setWidths(new int[] { 2, 4, 3, 9, 5, 3, 3 });
		tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata.setWidthPercentage(100);

		Paragraph a = new Paragraph("S.NO", fontTableHeadingdata);
		Paragraph b = new Paragraph("PERSONAL NO", fontTableHeadingdata);
		Paragraph c = new Paragraph("RANK", fontTableHeadingdata);
		Paragraph d = new Paragraph("NAME", fontTableHeadingdata);
		Paragraph e = new Paragraph("UNIT", fontTableHeadingdata);
		Paragraph f = new Paragraph("1ST CH", fontTableHeadingdata);
		Paragraph G = new Paragraph("2ND CH", fontTableHeadingdata);

		PdfPCell blank_cella;
		blank_cella = new PdfPCell();
		blank_cella.addElement(a);
		blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella.setPaddingLeft(6f);

		PdfPCell blank_cellb;
		blank_cellb = new PdfPCell();
		blank_cellb.addElement(b);
		blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellb.setPaddingLeft(3f);

		PdfPCell blank_cellc;
		blank_cellc = new PdfPCell();
		blank_cellc.addElement(c);
		blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellc.setPaddingLeft(15f);

		PdfPCell blank_celld;
		blank_celld = new PdfPCell();
		blank_celld.addElement(d);
		blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_celld.setPaddingLeft(50f);

		PdfPCell blank_celle;
		blank_celle = new PdfPCell();
		blank_celle.addElement(e);
		blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_celle.setPaddingLeft(35f);

		PdfPCell blank_cellf;
		blank_cellf = new PdfPCell();
		blank_cellf.addElement(f);
		blank_cellf.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf.setPaddingLeft(10f);

		PdfPCell blank_cellG;
		blank_cellG = new PdfPCell();
		blank_cellG.addElement(G);
		blank_cellG.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellG.setPaddingLeft(10f);

		tabledata.addCell(blank_cella);
		tabledata.addCell(blank_cellb);
		tabledata.addCell(blank_cellc);
		tabledata.addCell(blank_celld);
		tabledata.addCell(blank_celle);
		tabledata.addCell(blank_cellf);
		tabledata.addCell(blank_cellG);

		ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");
//				
//			 
		int index = 1;
		for (int i = 0; i < list.size(); i++) {

			List<String> l = list.get(i);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
			Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdata);
			Paragraph blank7 = new Paragraph(l.get(6), fontTableHeadingdata);

			PdfPCell cell2 = new PdfPCell();

			if (i % 2 == 0) {
				cell2.setBackgroundColor(java.awt.Color.lightGray);
			}

			cell2.setPhrase(blank1);
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cell2);

			cell2.setPhrase(blank2);
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cell2);

			cell2.setPhrase(blank3);
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cell2);

			cell2.setPhrase(blank4);
			cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata.addCell(cell2);

			cell2.setPhrase(blank5);
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cell2);

			cell2.setPhrase(blank6);
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cell2);

			cell2.setPhrase(blank7);
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cell2);

//					tabledata.addCell(blank1);
//					tabledata.addCell(blank2);
//					tabledata.addCell(blank3);
//					tabledata.addCell(blank4);
//					tabledata.addCell(blank5);
//					tabledata.addCell(blank6);
//					tabledata.addCell(blank7);

		}

		PageNumeration event = new PageNumeration(arg2);
		arg2.setPageEvent(event);
		document.setPageCount(1);

		PdfPCell cell123;
		cell123 = new PdfPCell();
		cell123.addElement(tableheader);
		cell123.addElement(tabledata);
		cell123.addElement(new Paragraph("\n"));
		cell123.setBorder(0);
		table.addCell(cell123);

		document.add(table);
		super.buildPdfMetadata(model, document, request);
	}
	
	class PageNumeration extends PdfPageEventHelper {
		PdfTemplate total;
		PdfTemplate total1;

		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				total1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {
			// total = writer.getDirectContent().createTemplate(30, 12);
		}

		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			String ip = "";
			try {
				table.setWidths(new int[] { 15,6,1});  
				table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				Date now = new Date();
				String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
				table.addCell(dateString);  //table.addCell("TOTAL SHEET :");
				
				
				PdfPCell cell1 = new PdfPCell(Image.getInstance(total1));
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			//	table.addCell(cell1);
								
			
				//String watermark = " Generated by "+username+" on "+dateString +" with IP " +ip ;
				
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Pages %d of", writer.getPageNumber()));
				//table.addCell("Month :");
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.NO_BORDER);				
				table.addCell(cell);
				
				table.writeSelectedRows(0, -1, document.leftMargin(), document.topMargin() + 0, writer.getDirectContent());
			} catch (DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT, new Phrase(String.valueOf(writer.getPageNumber() - 1)), 2, 2, 0);
			ColumnText.showTextAligned(total1, Element.ALIGN_LEFT, new Phrase(String.valueOf(totalRecords)), 2, 2, 0);
		}
	}

}
