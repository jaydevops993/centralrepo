package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.officer.masters.CPSC_MasterDAO;
import com.BisagN.models.officers.masters.CHOICE_M;
import com.BisagN.models.officers.masters.CPSC_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})

public class CPSC_MASTERController {
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private CPSC_MasterDAO objDAO;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	//===========================OPEN PAGE============================//
		@RequestMapping(value = "CPSCMasterUrl", method = RequestMethod.GET)
		public ModelAndView SearchSubject_master_Url(ModelMap Mmap, HttpSession session,
				@RequestParam(value = "msg", required = false) String msg)
				throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
				NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

			Mmap.put("msg", msg);
			return new ModelAndView("CpscMasterTiles", "CPSCMstCMD", new CPSC_M());
		}
		
		
		//============================SAVE==========================//
		  
		  @RequestMapping(value = "/CpscMasterAction" ,method = RequestMethod.POST) 
		  public ModelAndView CpscMasterAction( @ModelAttribute("CPSCMstCMD") CPSC_M ln, BindingResult result, 
		  HttpServletRequest request, ModelMap model, HttpSession session){ 
			  
//				int errCount = 0;
//
//				if (request.getParameter("name").equals("") || request.getParameter("name") == null) {
//					errCount++;
//					model.put("name_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Cpsc Name");
//				}
//				if (errCount > 0) {
//
//					return new ModelAndView("CpscMasterTiles");
//				}
			  
			  
			  
			  String name=request.getParameter("name");
				if(name == "" || name.equals("")) {
					model.put("msg", "Please Enter Cpsc Name");		
					return new ModelAndView("redirect:CPSCMasterUrl");
				}

				int id = ln.getCpsc_id() > 0 ? ln.getCpsc_id() : 0;
				Date date = new Date();
				String username = session.getAttribute("username").toString();
				Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction(); 

			try {

				Query q0 = sessionHQL.createQuery(
						"select count(id) from CPSC_M where LOWER(name)=:name and cpsc_id!=:id");

				q0.setParameter("name", ln.getName().toLowerCase());
				q0.setParameter("id", id);
				Long c = (Long) q0.uniqueResult();

				
				if (id == 0) {
					ln.setCreated_by(username);
					ln.setCreated_date(date);
					ln.setStatus_id(1);
					
					if (c == 0) {

						sessionHQL.save(ln);
						sessionHQL.flush();
						sessionHQL.clear();
						model.put("msg", "Data Saved Successfully.");

					} else {
						model.put("msg", "Data already Exist.");
					}
				}

			
				tx.commit();
			} catch (RuntimeException e) {
				try {
					tx.rollback();
					model.put("msg", "roll back transaction");
				} catch (RuntimeException rbe) {
					model.put("msg", "Couldn�t roll back transaction " + rbe);
				}
				throw e;
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}

			return new ModelAndView("redirect:CPSCMasterUrl");
		}
		  
		  
		//=======================SEARCH============================//
		  
		  @RequestMapping(value = "/getCPSC_MasterReportDataList", method = RequestMethod.POST)
			 public @ResponseBody List<Map<String, Object>> getCPSC_MasterReportDataList(int startPage,
					 String pageLength,String Search,String orderColunm,String orderType,HttpSession sessionUserId) 
				     throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, 
				     InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
				
			  return objDAO.getReportListCPSC_Master(startPage,pageLength,Search,orderColunm,orderType,sessionUserId);
			}

			 
			 @RequestMapping(value = "/getCPSC_MasterTotalCount", method = RequestMethod.POST)
			public @ResponseBody long getCPSC_MasterTotalCount(HttpSession sessionUserId,String Search,String name){
				 
				return objDAO.getReportListCPSC_MasterTotalCount(Search);
			}
			 
			 
			//=============================EDIT OPEN PAGE=============================//
			 
				@RequestMapping(value = "EditCpsc_MasterUrl", method = RequestMethod.POST)
				public ModelAndView EditCpsc_MasterUrl(ModelMap Mmap, HttpSession session,
						@RequestParam(value = "msg", required = false) String msg, String updateid) {

					Session s1 = this.sessionFactory.openSession();
					Transaction tx = s1.beginTransaction();

					String enckey = "commonPwdEncKeys";
					String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);

					Query q = null;
					q = s1.createQuery("from CPSC_M where cast(cpsc_id as string)=:PK");
					q.setString("PK", DcryptedPk);

					@SuppressWarnings("unchecked")
					List<String> list = (List<String>) q.list();
					tx.commit();
					s1.close();

					Mmap.put("EditCpscMstCMD1", list.get(0));
					Mmap.put("msg", msg);

					return new ModelAndView("EditCpscMasterTiles", "EditCpscMstCMD", new CPSC_M());
				}

				

		         //============================UPDATE========================//
		         @RequestMapping(value = "/EditCpscMasterAction" ,method = RequestMethod.POST) 
		   	  public ModelAndView EditCpscMasterAction( @ModelAttribute("EditCpscMstCMD") CPSC_M ln, BindingResult result, 
		   	  HttpServletRequest request, ModelMap model, HttpSession session){ 
		        	 
//					int errCount = 0;
//
//					if (request.getParameter("name").equals("") || request.getParameter("name") == null) {
//						errCount++;
//						model.put("name_lbl", "<i class='fa fa-exclamation'></i>&nbsp;Please Enter Cpsc Name");
//					}
//					if (errCount > 0) {
//
//						return new ModelAndView("EditCpscMasterTiles");
//					}
		        	 
		        	 
		        	 String name=request.getParameter("name");
						if(name == "" || name.equals("")) {
							model.put("msg", "Please Enter Cpsc Name");		
							return new ModelAndView("redirect:CPSCMasterUrl");
						}
		        	 
		        Date date = new Date();
		     	String username = session.getAttribute("username").toString();
		   	    Session sessionHQL = this.sessionFactory.openSession();
		   	    Transaction tx = sessionHQL.beginTransaction(); 
		   	    
		   	    ln.setCpsc_id(Integer.parseInt(request.getParameter("id")));
		   	    sessionHQL.saveOrUpdate(ln); 
		   	    ln.setModified_by(username);
				ln.setModified_date(date);
				ln.setStatus_id(1);
		   	    tx.commit(); 
		   	    sessionHQL.close(); 
		   	 
		   	    model.put("msg","Data Updated Successfully"); 
		   	    return new ModelAndView("redirect:CPSCMasterUrl"); 
		   	  } 
		         
			 
			 //=======================DELETE===========================//
			 @RequestMapping(value = "/DeleteCpsc_MasterUrl", method = RequestMethod.POST) 
			  public ModelAndView DeleteCpsc_MasterUrl(String deleteid,HttpSession session,ModelMap model) { 
				 
			  	List<String> list = new ArrayList<String>(); 
			  	list.add(objDAO.DeleteCpsc_Master(deleteid,session)); 
			  	
			  	model.put("msg",list);  
			  	
			    return new ModelAndView("redirect:CPSCMasterUrl"); 
			    
			  	}

}
