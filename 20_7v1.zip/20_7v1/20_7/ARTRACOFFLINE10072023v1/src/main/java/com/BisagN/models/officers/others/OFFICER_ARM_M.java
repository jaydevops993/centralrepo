package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "officer_arm", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class OFFICER_ARM_M {

      private int id;
      private int ac_arm_id;
      private int opd_personal_id;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date oa_effective_date;
      private String ac_arm_code;
      private int oa_status_id;
      private String oa_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date oa_creation_date;
      private String oa_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date oa_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getAc_arm_id() {
           return ac_arm_id;
      }
      public void setAc_arm_id(int ac_arm_id) {
	  this.ac_arm_id = ac_arm_id;
      }
      public int getOpd_personal_id() {
           return opd_personal_id;
      }
      public void setOpd_personal_id(int opd_personal_id) {
	  this.opd_personal_id = opd_personal_id;
      }
      public Date getOa_effective_date() {
           return oa_effective_date;
      }
      public void setOa_effective_date(Date oa_effective_date) {
	  this.oa_effective_date = oa_effective_date;
      }
      public String getAc_arm_code() {
           return ac_arm_code;
      }
      public void setAc_arm_code(String ac_arm_code) {
	  this.ac_arm_code = ac_arm_code;
      }
      public int getOa_status_id() {
           return oa_status_id;
      }
      public void setOa_status_id(int oa_status_id) {
	  this.oa_status_id = oa_status_id;
      }
      public String getOa_created_by() {
           return oa_created_by;
      }
      public void setOa_created_by(String oa_created_by) {
	  this.oa_created_by = oa_created_by;
      }
      public Date getOa_creation_date() {
           return oa_creation_date;
      }
      public void setOa_creation_date(Date oa_creation_date) {
	  this.oa_creation_date = oa_creation_date;
      }
      public String getOa_modified_by() {
           return oa_modified_by;
      }
      public void setOa_modified_by(String oa_modified_by) {
	  this.oa_modified_by = oa_modified_by;
      }
      public Date getOa_modification_date() {
           return oa_modification_date;
      }
      public void setOa_modification_date(Date oa_modification_date) {
	  this.oa_modification_date = oa_modification_date;
      }
}
