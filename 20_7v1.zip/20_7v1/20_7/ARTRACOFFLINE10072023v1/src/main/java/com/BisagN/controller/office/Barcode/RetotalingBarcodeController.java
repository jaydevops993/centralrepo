package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.models.officers.indexing.INDEXING_SETTING;
import com.BisagN.models.officers.indexing.INDEX_NO;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MASTER;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;



@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class RetotalingBarcodeController {

	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	

	
	
	@Autowired
	CommonController comm;
	
	@RequestMapping(value = "RetotalingBarcodeUrl", method = RequestMethod.GET)
	public ModelAndView RetotalingBarcodeUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
  	
   	String es_begindate = session.getAttribute("es_begin_date") == null ? "": session.getAttribute("es_begin_date").toString();
	  int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
	  
		
	   	String es_begin_dateshow = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();
	  
	  int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0": session.getAttribute("ec_exam_id").toString());
	System.err.println("es_begindate=============="+es_begindate);
	
	
	 if(!es_begin_dateshow.equals("")) {
			
		 Mmap.put("partb_begindate", es_begin_dateshow);
	}
	 
	 
	 if(es_id != 0) {
		 List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
		 Mmap.put("es_id", es_id);
		 String index_mode= UnlcokExmsch.get(0).getEs_index_mode();
		 Mmap.put("index_mode", index_mode);
	}
	 
	 
	 if (ec_exam_id != 0) {
			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
			
		}
	 Mmap.put("msg",msg);
	 return new ModelAndView("RetotalingBarcodetile");
}
	
	
	
	 
	 
	 
	 @RequestMapping(value = "/GenerateIndexingAction" ,method = RequestMethod.POST) 
	  public ModelAndView GenerateIndexingAction( @ModelAttribute("GenerateIndexingCMD") INDEX_SLIP_MASTER index_slip_m, BindingResult result, 
	  HttpServletRequest request, ModelMap model, HttpSession session){ 
		  Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction();
			try {
				
				
		     String username = session.getAttribute("username").toString();
			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			int id = index_slip_m.getIsm_id() > 0 ? index_slip_m.getIsm_id() : 0;
			
			  int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
			
				 Query q0 = sessionHQL.createQuery(
							"select count(id) from INDEX_NO  where  es_id=:es_id ");

					q0.setParameter("es_id", es_id);
			Long c = (Long) q0.uniqueResult();
			
			
			

			if(id == 0) {
				
		//if (c == 0  ) {
				
String pers_code = request.getParameter("opd_personal_id");
				List<OFFICER_PERSONAL_CODE_M> opdpers_id = comm.getopdIdbycode(sessionFactory, pers_code);
				int opd_pers_id = opdpers_id.get(0).getOpd_personal_id();
				List<INDEXING_SETTING> bundledetails = comm.getbundledetailsforindexing(sessionFactory, es_id);

				int bundleminno = bundledetails.get(0).getIst_min_indexno();
				int bundlepacking_size = bundledetails.get(0).getIst_maxab_bundle();
				int answerbookbundleSize = bundledetails.get(0).getIst_maxbundle_package();
				int indexNo = bundleminno;
				indexNo++;
//				long totalindex = comm.getIndexNocountByEsid(sessionFactory, es_id);
				INDEX_NO in = new INDEX_NO();
			
				if (c != 0) {
					in = comm.getIndexNoByEsid(sessionFactory, es_id).get(0);
					
					System.err.println("in---------------"+in);
				} else {
					List<INDEX_NO> indexno = comm.getIndexNoByEsid(sessionFactory, es_id);
					if (indexno.isEmpty()) {
						in.setEs_id(es_id);
						in.setIndex_no(bundleminno);
						int inid = (int) sessionHQL.save(in);
						in.setId(inid);
					}
				}
				
				index_slip_m.setIsm_armyno(pers_code);
				index_slip_m.setIsm_dtcreateddate(date);
				
				index_slip_m.setIsm_es_id(es_id);
				index_slip_m.setIsm_indexno(indexNo);
				sessionHQL.save(index_slip_m);
				
				
				
				String hq15 = "update OFFICER_APPLICATION_M set in_index_id=:in_index_id  where opd_personal_id=:opd_personal_id and es_id=:es_id ";
				Query query5 = sessionHQL.createQuery(hq15)
							.setParameter("in_index_id", indexNo )			
							.setParameter("opd_personal_id",   opd_pers_id)
				.setParameter("es_id",   es_id);
				query5.executeUpdate();
				
				
				model.put("msg","Data Saved Successfully"); 
	    
				
				
				tx.commit();
				
//				}else {
//					
//					model.put("msg","Data already Exist"); 
//				}
				   
			}
	 
			} 
			
			
			catch (RuntimeException e) {
				try {
					tx.rollback();
					model.put("msg", "roll back transaction");
				} catch (RuntimeException rbe) {
					model.put("msg", "Couldn�t roll back transaction " + rbe);
				}
				throw e;
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}

			return new ModelAndView("redirect:IndexingSettingUrl"); 
			}	
	
}
