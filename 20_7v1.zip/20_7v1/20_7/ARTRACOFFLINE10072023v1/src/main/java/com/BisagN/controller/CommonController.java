package com.BisagN.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.models.officers.barcode.SUBJECTWISE_SECTIONDETAILS;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_MASTER;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_DETAILS;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_MASTER;
import com.BisagN.models.officers.indexing.INDEXING_SETTING;
import com.BisagN.models.officers.indexing.INDEX_NO;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MANUAL;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MASTER;
import com.BisagN.models.officers.indexing.TB_BARCODE_COUNT;
import com.BisagN.models.officers.masters.AREA_M;
import com.BisagN.models.officers.masters.AREA_TYPE;
import com.BisagN.models.officers.masters.ARM_CODES_M;
import com.BisagN.models.officers.masters.CHOICE_M;
import com.BisagN.models.officers.masters.COMMAND_CODE_M;
import com.BisagN.models.officers.masters.COMMISSION_TYPE_M;
import com.BisagN.models.officers.masters.CPSC_M;
import com.BisagN.models.officers.masters.ENTERY_TYPE_M;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.masters.RANK_CODE_M;
import com.BisagN.models.officers.masters.REGIMENT_M;
import com.BisagN.models.officers.masters.Reason_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST;
import com.BisagN.models.officers.others.DSSC_COURSE_VACANCY_RESERVE;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_ARM_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.OFFICER_RANK_M;
import com.BisagN.models.officers.others.RESULTS_WITHHELD_M;
import com.BisagN.models.officers.trans.DSSC_ADMIT_CARD_TBL;
import com.BisagN.models.officers.trans.EXAM_CENTER_CODE_M;
import com.BisagN.models.officers.trans.QUALIFIED_OFFICERS;


@Controller
@RequestMapping(value = {"admin","/" ,"user"}) 
public class CommonController {

	
//	@Autowired
//	@Qualifier("sessionFactory")
//	private SessionFactory sessionFactory;
	@Autowired
	private SessionFactory sessionFactory;

	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	
	public Date convertStringToDate(String sdate) {
		Date date = null;
		try {
			
			if(sdate.contains("/")) {
				date = new SimpleDateFormat("dd/MM/yyyy").parse(sdate);
			}
			if(sdate.contains("-")) {
				
				date = new SimpleDateFormat("dd-MM-yyyy").parse(sdate);
			}
		} catch (ParseException e) {
			System.out.println("convertStringToDate : "+ e.getMessage());
		}
		
		 System.err.println("commmm=======date===="+date);
		return date;
	}
	
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getAdvertisementList",method=RequestMethod.POST)
	public @ResponseBody List<Map<String, Object>> getAdvmstDetailsList_proStatus(HttpSession sessionU,String getcolumnname) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query q = null;
		if(getcolumnname != "") {
			q = session.createQuery("select distinct opd_personal_id,opc_personal_code from OFFICER_PERSONAL_CODE_M where upper(opc_personal_code) like:getcolumnname and opc_status_id='1'  order by opc_personal_code").setMaxResults(15);		
	        q.setParameter("getcolumnname", "%"+getcolumnname.toUpperCase()+"%");
		}
		else {
			q = session.createQuery("select distinct '' as dummy,opc_personal_code from OFFICER_PERSONAL_CODE_M where opc_status_id='1' order by opc_personal_code").setMaxResults(15);
		}
        List<Object[]>  list = (List<Object[]> ) q.list();
       // System.out.println("list-----------"+list);
		tx.commit();
		session.close();
		return getDDLCommonList(sessionU,list);
	}
	
	
	

	
	
	//-------------------- INC-DESC Common DDL List------------------------------------
			public @ResponseBody List<Map<String, Object>> getDDLCommonList(HttpSession sessionUserId,List<Object[]>  list) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
				String enckey = hex_asciiDao.getAlphaNumericString();
				Cipher c = hex_asciiDao.EncryptionSHA256Algo(sessionUserId,enckey);
				List<Map<String, Object>> FinalList = new ArrayList<Map<String, Object>>();

				for(Object[] listObject: list){
			    	String columnName = (String)listObject[1].toString();
			   		String columnCode = (String)listObject[0].toString();
			   		byte[] enccolumnName = c.doFinal(columnName.getBytes());
				    String base64EncodedEncryptedcolumnName = new String(Base64.encodeBase64(enccolumnName));
				    
				    byte[] enccolumnCode = c.doFinal(columnCode.getBytes());
				    String base64EncodedEncryptedcolumnCode = new String(Base64.encodeBase64(enccolumnCode));
			   		
				    Map<String, Object> EncList = new LinkedHashMap<String, Object>();
			   		EncList.put("columnName",base64EncodedEncryptedcolumnName);
				    EncList.put("columnCode",base64EncodedEncryptedcolumnCode);
				    FinalList.add(EncList);
			   	}
				//Enc Key Append Last value of List
				Map<String, Object> EncKeyList = new LinkedHashMap<String, Object>();
				String a1=enckey+"4bsjyg==";
			    if(list.size() != 0) {
			    	EncKeyList.put("columnName1",a1);
			    	EncKeyList.put("columnCode1","gDKfjjU+/PZ6k4WWTJB1IA==");
			    }
			    FinalList.add(EncKeyList);
				return FinalList;
			}
			
			@SuppressWarnings("unchecked")
			@RequestMapping(value = "/getJccourseList",method=RequestMethod.POST)
			public @ResponseBody List<Map<String, Object>> getJccourseList(HttpSession sessionU,String getcolumnname) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
				Session session = this.sessionFactory.openSession();
				Transaction tx = session.beginTransaction();
				Query q = null;
				if(getcolumnname != "") {
					q = session.createQuery("select distinct '' as dummy,jcc_no from JC_COURSE_M where upper(jcc_no) like:getcolumnname  order by jcc_no").setMaxResults(15);		
			        q.setParameter("getcolumnname", "%"+getcolumnname.toUpperCase()+"%");
				}
				else {
					q = session.createQuery("select distinct '' as dummy,jcc_no from JC_COURSE_M order by jcc_no").setMaxResults(15);
				}
		        List<Object[]>  list = (List<Object[]> ) q.list();
//		        System.out.println("list-----------"+list);
				tx.commit();
				session.close();
				return getDDLCommonList(sessionU,list);
			}	
			
			
			
			 public List<COMMAND_CODE_M> getcccommandnameListDDL(SessionFactory sessionFactory) {
				 Session session = sessionFactory.openSession();
						Transaction tx = session.beginTransaction();
						Query q = session.createQuery("from COMMAND_CODE_M order by id");
						@SuppressWarnings("unchecked")
						List<COMMAND_CODE_M>  list = (List<COMMAND_CODE_M>) q.list();
						tx.commit();
						session.close();
						return list;
					}
				 public List<COMMISSION_TYPE_M> getctcommtypeListDDL(SessionFactory sessionFactory) {
					 Session session = sessionFactory.openSession();
						Transaction tx = session.beginTransaction();
						Query q = session.createQuery("from COMMISSION_TYPE_M order by id");
						@SuppressWarnings("unchecked")
						List<COMMISSION_TYPE_M>  list = (List<COMMISSION_TYPE_M>) q.list();
						tx.commit();
						session.close();
						return list;
					}
				 
				 public List<RANK_CODE_M> getctranktypeListDDL(SessionFactory sessionFactory) {
					 Session session = sessionFactory.openSession();
							Transaction tx = session.beginTransaction();
							Query q = session.createQuery("from RANK_CODE_M order by id");
							@SuppressWarnings("unchecked")
							List<RANK_CODE_M>  list = (List<RANK_CODE_M>) q.list();
							tx.commit();
							session.close();
							return list;
						}
				 
				 public List<ARM_CODES_M> getctarmcodetypeListDDL(SessionFactory sessionFactory) {
					 Session session = sessionFactory.openSession();
							Transaction tx = session.beginTransaction();
							Query q = session.createQuery("from ARM_CODES_M order by ac_arm_id");
							@SuppressWarnings("unchecked")
							List<ARM_CODES_M>  list = (List<ARM_CODES_M>) q.list();
							tx.commit();
							session.close();
							return list;
						}
				 
				 
				 public List<AREA_M> getAreaListDDL(SessionFactory sessionFactory) {
					 Session session = sessionFactory.openSession();
							Transaction tx = session.beginTransaction();
							Query q = session.createQuery("from AREA_M order by area_id");
							@SuppressWarnings("unchecked")
							List<AREA_M>  list = (List<AREA_M>) q.list();
							tx.commit();
							session.close();
							return list;
						}
				 
				 
				 public List<EXAM_CENTER_CODE_M> getexamcentreListDDL(SessionFactory sessionFactory) {
					 Session session = sessionFactory.openSession();
							Transaction tx = session.beginTransaction();
							Query q = session.createQuery("from EXAM_CENTER_CODE_M order by id");
							@SuppressWarnings("unchecked")
							List<EXAM_CENTER_CODE_M>  list = (List<EXAM_CENTER_CODE_M>) q.list();
							
							tx.commit();
							session.close();
							return list;
						}
				 
				
				 
				 
				 public @ResponseBody List<SUBJECT_CODE_M> getsubjectlist(SessionFactory sessionFactory,int ec_exam_id) {

						Session session = sessionFactory.openSession();
						Transaction tx = session.beginTransaction();
						Query q = session.createQuery(" from SUBJECT_CODE_M where ec_exam_id=:ec_exam_id order by sc_subject_code");
									q.setParameter("ec_exam_id", ec_exam_id);
						@SuppressWarnings("unchecked")
						List<SUBJECT_CODE_M> list = (List<SUBJECT_CODE_M>) q.list();
						tx.commit();
						session.close();
						return list;
					}
				 
				 
				 public @ResponseBody List<OFFICER_ARM_M> getarmcode(SessionFactory sessionFactory,int opd_id) {

						Session session = sessionFactory.openSession();
						Transaction tx = session.beginTransaction();
						Query q = session.createQuery(" from OFFICER_ARM_M where opd_personal_id=:opd_personal_id");
									q.setParameter("opd_personal_id", opd_id);
						@SuppressWarnings("unchecked")
						List<OFFICER_ARM_M> list = (List<OFFICER_ARM_M>) q.list();
						tx.commit();
						session.close();
						return list;
					}
				 
				 
				 
				 public List<String> getPersonalType(SessionFactory sessionFactory) {

						Session sessionHQL = sessionFactory.openSession();

						Transaction tx = sessionHQL.beginTransaction();

						try {

							Query q1 = sessionHQL.createQuery(

									"select label,codevalue from T_Domain_Value where domainid='PERSONAL_TYPE' order by codevalue ");

							@SuppressWarnings("unchecked")

							List<String> list = (List<String>) q1.list();

							tx.commit();

							return list;

						} catch (RuntimeException e) {

							return null;

						} finally {

							if (sessionHQL != null) {

								sessionHQL.close();

							}

						}
				  }
				  
				 
				 

				 public int saveFunction(Object obj)
					{
						Session session1 = this.sessionFactory.openSession();
						session1.beginTransaction();
						int id=(Integer)session1.save(obj);
						session1.getTransaction().commit();
						session1.close();
						return id;
					}
				 
					 public List<EXAM_CODE_M> getecexamnameListDDL(SessionFactory sessionFactory) {
							Session session = sessionFactory.openSession();
							Transaction tx = session.beginTransaction();
							Query q = session.createQuery("from EXAM_CODE_M order by ec_exam_id");
							@SuppressWarnings("unchecked")
							List<EXAM_CODE_M>  list = (List<EXAM_CODE_M>) q.list();
							tx.commit();
							session.close();
							return list;
						}
					 
					 
					 
					 
					 public @ResponseBody List<OFFICER_PERSONAL_CODE_M> getopdIdbycode(SessionFactory sessionFactory,String pers_code) {
						 
							Session session = sessionFactory.openSession();
							Transaction tx = session.beginTransaction();
							Query q = session.createQuery("from OFFICER_PERSONAL_CODE_M where opc_personal_code=:opc_personal_code");
										q.setParameter("opc_personal_code",pers_code);
							@SuppressWarnings("unchecked")
							List<OFFICER_PERSONAL_CODE_M> list = (List<OFFICER_PERSONAL_CODE_M>) q.list();
							
							//System.err.println("list============="+list);
							tx.commit();
							session.close();
							return list;
						}
					 
					 

public @ResponseBody List<OFFICER_APPLICATION_M> getOappIdbyopdId(SessionFactory sessionFactory,int opd_pers_id,int es_id) {
	 

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query q = session.createQuery(" from OFFICER_APPLICATION_M where opd_personal_id=:opd_personal_id and es_id=:es_id ");
					q.setParameter("opd_personal_id", opd_pers_id);
					q.setParameter("es_id", es_id);
		@SuppressWarnings("unchecked")
		List<OFFICER_APPLICATION_M> list = (List<OFFICER_APPLICATION_M>) q.list();
		tx.commit();
		session.close();
		return list;
	}


public @ResponseBody List<OFFICER_PERSONAL_DETAILS_M> getpbdasumbyopdid(SessionFactory sessionFactory,int opd_pers_id) {
	 

	Session session = sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
	Query q = session.createQuery(" from OFFICER_PERSONAL_DETAILS_M where opd_personal_id=:opd_personal_id");
				q.setParameter("opd_personal_id", opd_pers_id);
	@SuppressWarnings("unchecked")
	List<OFFICER_PERSONAL_DETAILS_M> list = (List<OFFICER_PERSONAL_DETAILS_M>) q.list();
	tx.commit();
	session.close();
	return list;
}
					 
public @ResponseBody List<SUBJECT_CODE_M> getsubjectIdbysubname(SessionFactory sessionFactory,int sc_subject_id,int ec_exam_id) {

	Session session = sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
	Query q = session.createQuery(" from SUBJECT_CODE_M where sc_subject_id=:sc_subject_id and ec_exam_id=:ec_exam_id order by sc_subject_code");
				q.setParameter("sc_subject_id",sc_subject_id);
				q.setParameter("ec_exam_id", ec_exam_id);
	@SuppressWarnings("unchecked")
	List<SUBJECT_CODE_M> list = (List<SUBJECT_CODE_M>) q.list();
	tx.commit();
	session.close();
	return list;
}
		




public @ResponseBody List<OFFICER_RANK_M> getRankIdbyopdId(SessionFactory sessionFactory,int opd_pers_id) {
	 

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query q = session.createQuery(" from OFFICER_RANK_M where opd_personal_id=:opd_personal_id");
					q.setParameter("opd_personal_id", opd_pers_id);
		@SuppressWarnings("unchecked")
		List<OFFICER_RANK_M> list = (List<OFFICER_RANK_M>) q.list();
		tx.commit();
		session.close();
		return list;
	}



public List<AREA_TYPE> getAreaTypeListDDL(SessionFactory sessionFactory) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from AREA_TYPE order by area_type_id");
			@SuppressWarnings("unchecked")
			List<AREA_TYPE>  list = (List<AREA_TYPE>) q.list();
			tx.commit();
			session.close();
			return list;
		}


public List<ENTERY_TYPE_M> getEntryTypeListDDL(SessionFactory sessionFactory) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from ENTERY_TYPE_M order by entry_type_id");
			@SuppressWarnings("unchecked")
			List<ENTERY_TYPE_M>  list = (List<ENTERY_TYPE_M>) q.list();
			tx.commit();
			session.close();
			return list;
		}


public List<CHOICE_M> getChoicemstListDDL(SessionFactory sessionFactory) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from CHOICE_M  where status_id=1 order by id");
			@SuppressWarnings("unchecked")
			List<CHOICE_M>  list = (List<CHOICE_M>) q.list();
			tx.commit();
			session.close();
			return list;
		}


public List<CPSC_M> getCPSCmstListDDL(SessionFactory sessionFactory) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from CPSC_M order by cpsc_id");
			@SuppressWarnings("unchecked")
			List<CPSC_M>  list = (List<CPSC_M>) q.list();
			tx.commit();
			session.close();
			return list;
		}


public List<ARM_CODES_M> getarmdetailsbyarmId(SessionFactory sessionFactory,String ac_arm_description) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from ARM_CODES_M  where  ac_arm_description=:ac_arm_description");
			q.setParameter("ac_arm_description", ac_arm_description);
			@SuppressWarnings("unchecked")
			List<ARM_CODES_M>  list = (List<ARM_CODES_M>) q.list();
			tx.commit();
			session.close();
			return list;
		}
			


public List<INDEXING_SETTING> getbundledetailsforindexing(SessionFactory sessionFactory,int es_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEXING_SETTING  where  ist_es_id=:ist_es_id");
			q.setParameter("ist_es_id", es_id);
			@SuppressWarnings("unchecked")
			List<INDEXING_SETTING>  list = (List<INDEXING_SETTING>) q.list();
			System.err.println(list);
			tx.commit();
			session.close();
			return list;
		}


public List<INDEX_NO> getIndexNoByEsid(SessionFactory sessionFactory,int es_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEX_NO  where  es_id=:es_id");
			q.setParameter("es_id", es_id);
			@SuppressWarnings("unchecked")
			List<INDEX_NO>  list = (List<INDEX_NO>) q.list();
			tx.commit();
			session.close();
			return list;
		}

public long getIndexNocountByEsid(SessionFactory sessionFactory,int es_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("select count(id) from INDEX_NO  where  es_id=:es_id");
			q.setParameter("es_id", es_id);
			@SuppressWarnings("unchecked")
			Long c = (Long) q.uniqueResult();
			tx.commit();
			session.close();
			return c;
		}
			
public long getIndexslipcountBysubjectId(SessionFactory sessionFactory,int is_sc_subject_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("select count(is_id) from INDEX_SLIP_MANUAL  where  is_sc_subject_id=:is_sc_subject_id");
			q.setParameter("is_sc_subject_id", is_sc_subject_id);
			@SuppressWarnings("unchecked")
			Long c = (Long) q.uniqueResult();
			tx.commit();
			session.close();
			return c;
		}

public List<COMMAND_CODE_M> getCommandbycommandname(SessionFactory sessionFactory,String cc_command_name) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from COMMAND_CODE_M where cc_command_name=:cc_command_name");
			q.setParameter("cc_command_name", cc_command_name);
			@SuppressWarnings("unchecked")
			List<COMMAND_CODE_M>  list = (List<COMMAND_CODE_M>) q.list();
			tx.commit();
			session.close();
			return list;
		}	




public List<INDEX_SLIP_MASTER> getIndexNoByICnumber(SessionFactory sessionFactory,String ic_number, String es_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEX_SLIP_MASTER where ism_armyno=:ism_armyno and ism_es_id=:ism_es_id");
			q.setParameter("ism_armyno", ic_number);
			q.setParameter("ism_es_id", Integer.parseInt(es_id));
			@SuppressWarnings("unchecked")
			List<INDEX_SLIP_MASTER>  list = (List<INDEX_SLIP_MASTER>) q.list();
			tx.commit();
			session.close();
			return list;
		}	


public List<EXAM_CODE_M>getExamNamebyExmID(SessionFactory sessionFactory,int ec_exam_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from EXAM_CODE_M where  ec_exam_id=:ec_exam_id");
			q.setParameter("ec_exam_id", ec_exam_id);
			@SuppressWarnings("unchecked")
			List<EXAM_CODE_M>  list = (List<EXAM_CODE_M>) q.list();
			tx.commit();
			session.close();
			return list;
		}	


public List<EXAM_SCHEDULE>getActiveExamSchedule(SessionFactory sessionFactory) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from EXAM_SCHEDULE where es_status_id='1'");
			@SuppressWarnings("unchecked")
			List<EXAM_SCHEDULE>  list = (List<EXAM_SCHEDULE>) q.list();
			tx.commit();
			session.close();
			return list;
		}	


public @ResponseBody List<SUBJECT_CODE_M> getSubjectIdBySubName(SessionFactory sessionFactory,String sub_name,int ec_exam_id) {

	Session session = sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
	Query q = session.createQuery("from SUBJECT_CODE_M where sc_subject_name=:sc_subject_name and ec_exam_id=:ec_exam_id order by sc_subject_code");
				q.setParameter("sc_subject_name",sub_name);
				q.setParameter("ec_exam_id", ec_exam_id);
	@SuppressWarnings("unchecked")
	List<SUBJECT_CODE_M> list = (List<SUBJECT_CODE_M>) q.list();
	tx.commit();
	session.close();
	return list;
}


public long getRankCountByRankName(SessionFactory sessionFactory,String rank) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("select count(id) from RANK_CODE_M  where  rc_rank_name=:rc_rank_name");
			q.setParameter("rc_rank_name", rank);
			@SuppressWarnings("unchecked")
			Long c = (Long) q.uniqueResult();
			tx.commit();
			session.close();
			return c;
		}


public List<INDEXED_BUNDLE_MASTER> getbundlemsterId(SessionFactory sessionFactory,int es_id, int subject_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEXED_BUNDLE_MASTER where ibm_es_id=:ibm_es_id and ibm_nsubjectid=:ibm_nsubjectid order by ibm_id desc").setMaxResults(1);
			q.setParameter("ibm_es_id",es_id);
			q.setParameter("ibm_nsubjectid",subject_id );
			@SuppressWarnings("unchecked")
			List<INDEXED_BUNDLE_MASTER>  list = (List<INDEXED_BUNDLE_MASTER>) q.list();
			tx.commit();
			session.close();
			return list;
		}	

public INDEXED_BUNDLE_MASTER getIndexedBundleMster(SessionFactory sessionFactory,int ibm_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEXED_BUNDLE_MASTER where ibm_id=:ibm_id").setMaxResults(1);
			q.setParameter("ibm_id",ibm_id);
			@SuppressWarnings("unchecked")
			INDEXED_BUNDLE_MASTER  list = (INDEXED_BUNDLE_MASTER) q.uniqueResult();
			tx.commit();
			session.close();
			return list;
		}


public int calculate_age(Date from_date, Date to_date) {
	if (from_date != null && to_date != null) {
		if (to_date.compareTo(from_date) > 0) {
			Instant frominstant = from_date.toInstant();
			ZonedDateTime fromzone = frominstant.atZone(ZoneId.systemDefault());
			LocalDate fromgivenDate = fromzone.toLocalDate();

			Instant toinstant = to_date.toInstant();
			ZonedDateTime tozone = toinstant.atZone(ZoneId.systemDefault());
			LocalDate togivenDate = tozone.toLocalDate();

			Period period = Period.between(fromgivenDate, togivenDate);
			return period.getYears();
		} else
			return 0;

	} else {
		return 0;
	}

}


public @ResponseBody List<OFFICER_APPLICATION_M> getOpdIdbyOappId(SessionFactory sessionFactory,int oa_app_id,int es_id) {
	 

	Session session = sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
	Query q = session.createQuery(" from OFFICER_APPLICATION_M where oa_application_id=:oa_application_id and es_id=:es_id ");
				q.setParameter("oa_application_id", oa_app_id);
				q.setParameter("es_id", es_id);
	@SuppressWarnings("unchecked")
	List<OFFICER_APPLICATION_M> list = (List<OFFICER_APPLICATION_M>) q.list();
	tx.commit();
	session.close();
	return list;
}



public @ResponseBody List<OFFICER_PERSONAL_CODE_M> getPersCodebyOpdID(SessionFactory sessionFactory,int opd_pers_id) {
	 

	Session session = sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
	Query q = session.createQuery("from OFFICER_PERSONAL_CODE_M where opd_personal_id=:opd_personal_id ");
				q.setParameter("opd_personal_id", opd_pers_id);
	@SuppressWarnings("unchecked")
	List<OFFICER_PERSONAL_CODE_M> list = (List<OFFICER_PERSONAL_CODE_M>) q.list();
	tx.commit();
	session.close();
	return list;
}


public List<EXAM_SCHEDULE>getUnlockExamSchedule(SessionFactory sessionFactory, int esi_es_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from EXAM_SCHEDULE where es_id=:es_id");
			q.setParameter("es_id", esi_es_id);
			@SuppressWarnings("unchecked")
			List<EXAM_SCHEDULE>  list = (List<EXAM_SCHEDULE>) q.list();
			tx.commit();
			session.close();
			return list;
		}


public List<EXAMSCHEDULE_INDEXING_DETAIL>getActiveIndxSubject(SessionFactory sessionFactory, int esi_es_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from EXAMSCHEDULE_INDEXING_DETAIL where esid_es_id=:esid_es_id");
			q.setParameter("esid_es_id", esi_es_id);
			@SuppressWarnings("unchecked")
			List<EXAMSCHEDULE_INDEXING_DETAIL>  list = (List<EXAMSCHEDULE_INDEXING_DETAIL>) q.list();
			tx.commit();
			session.close();
			return list;
		}



public List<INDEXED_BUNDLE_MASTER>getBundleNameList(SessionFactory sessionFactory, int esi_es_id,int user_id, int subject_id) {
	 		Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEXED_BUNDLE_MASTER where ibm_es_id=:ibm_es_id and ibm_iu_user_id=:ibm_iu_user_id and ibm_nsubjectid=:ibm_nsubjectid and ibm_status_id=1 order by ibm_id desc ");
			q.setParameter("ibm_es_id", esi_es_id);
			q.setParameter("ibm_iu_user_id", user_id);
			q.setParameter("ibm_nsubjectid", subject_id);
			@SuppressWarnings("unchecked")
			List<INDEXED_BUNDLE_MASTER>  list = (List<INDEXED_BUNDLE_MASTER>) q.list();
			tx.commit();
			session.close();
			return list;
		}



public @ResponseBody List<OFFICER_APPLICATION_M> getOappIdbyEsID(SessionFactory sessionFactory,int es_id) {
	 

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query q = session.createQuery(" from OFFICER_APPLICATION_M where  es_id=:es_id ");
					q.setParameter("es_id", es_id);
		@SuppressWarnings("unchecked")
		List<OFFICER_APPLICATION_M> list = (List<OFFICER_APPLICATION_M>) q.list();
		tx.commit();
		session.close();
		return list;
	}



public List<EXAM_CENTER_CODE_M> getexamcentreListByEcc_Code(SessionFactory sessionFactory,int ecc_code) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from EXAM_CENTER_CODE_M where ecc_center_code=:ecc_center_code");
			q.setParameter("ecc_center_code", ecc_code);
			@SuppressWarnings("unchecked")
			List<EXAM_CENTER_CODE_M>  list = (List<EXAM_CENTER_CODE_M>) q.list();
			
			tx.commit();
			session.close();
			return list;
		}

public List<RESULTS_WITHHELD_M> getStatusForResulWithHeld(SessionFactory sessionFactory,String id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from RESULTS_WITHHELD_M where id=:id");
			q.setParameter("id",Integer.parseInt(id));
			@SuppressWarnings("unchecked")
			List<RESULTS_WITHHELD_M>  list = (List<RESULTS_WITHHELD_M>) q.list();
			
			tx.commit();
			session.close();
			return list;
		}


public List<INDEXED_PACKING_NOTES_MASTER> getBundlePrefixList(SessionFactory sessionFactory,int ibm_es_id,int sc_subject_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("select distinct ipnm from INDEXED_PACKING_NOTES_MASTER ipnm,INDEXED_PACKING_NOTES_DETAILS ipnd,INDEXED_BUNDLE_MASTER ibm where ibm.ibm_id=ipnd.ipnd_ibm_id and ipnd.ipnd_ipnm_id=ipnm.ipnm_id and ipnm_es_id=:ipnm_es_id and ibm.ibm_nsubjectid=:jay ");
			q.setParameter("ipnm_es_id",ibm_es_id);
			q.setParameter("jay",sc_subject_id);

			@SuppressWarnings("unchecked")
			List<INDEXED_PACKING_NOTES_MASTER>  list = (List<INDEXED_PACKING_NOTES_MASTER>) q.list();
			
			tx.commit();
			session.close();
			return list;
		}


public List<INDEXED_PACKING_NOTES_DETAILS> getPakcingnoteID(SessionFactory sessionFactory,int bundle_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEXED_PACKING_NOTES_DETAILS where ipnd_ibm_id=:ipnd_ibm_id order by ipnd_id desc");
			q.setParameter("ipnd_ibm_id",bundle_id);
			@SuppressWarnings("unchecked")
			List<INDEXED_PACKING_NOTES_DETAILS>  list = (List<INDEXED_PACKING_NOTES_DETAILS>) q.list();
			
			tx.commit();
			session.close();
			return list;
		}

public List<SUBJECTWISE_SECTIONDETAILS> getsubjectwiseSecDetails(SessionFactory sessionFactory,int ssd_es_id,int ssd_subject_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from SUBJECTWISE_SECTIONDETAILS where ssd_es_id=:ssd_es_id and ssd_subject_id=:ssd_subject_id");
			q.setParameter("ssd_es_id",ssd_es_id);
			q.setParameter("ssd_subject_id",ssd_subject_id);
			@SuppressWarnings("unchecked")
			List<SUBJECTWISE_SECTIONDETAILS>  list = (List<SUBJECTWISE_SECTIONDETAILS>) q.list();
			
			tx.commit();
			session.close();
			return list;
		}


public List<INDEX_SLIP_MANUAL>getABsCountByIbmID(SessionFactory sessionFactory,int ibm_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("select (*) from INDEX_SLIP_MANUAL where is_ibm_id=:is_ibm_id");
			q.setParameter("is_ibm_id", ibm_id);
			@SuppressWarnings("unchecked")
			List<INDEX_SLIP_MANUAL>  list = (List<INDEX_SLIP_MANUAL>) q.list();
			tx.commit();
			session.close();
			return list;
		}

public INDEX_SLIP_MANUAL getIndexSlipManual(SessionFactory sessionFactory,int is_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEX_SLIP_MANUAL where is_id=:is_id").setMaxResults(1);
			q.setParameter("is_id", is_id);
			@SuppressWarnings("unchecked")
			INDEX_SLIP_MANUAL  list = (INDEX_SLIP_MANUAL) q.uniqueResult();
			tx.commit();
			session.close();
			return list;
		}

public INDEX_SLIP_MASTER getIndexSlipMaster(SessionFactory sessionFactory,int ism_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEX_SLIP_MASTER where ism_id=:ism_id").setMaxResults(1);
			q.setParameter("ism_id", ism_id);
			@SuppressWarnings("unchecked")
			INDEX_SLIP_MASTER  list = (INDEX_SLIP_MASTER) q.uniqueResult();
			tx.commit();
			session.close();
			return list;
		}


public List<REGIMENT_M> getRegimentMstListDDL(SessionFactory sessionFactory) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from REGIMENT_M order by r_id");
			@SuppressWarnings("unchecked")
			List<REGIMENT_M>  list = (List<REGIMENT_M>) q.list();
			tx.commit();
			session.close();
			return list;
		}

public List<DSSC_ADMIT_CARD_TBL> getAdmitcardlistforopdId(SessionFactory sessionFactory,int opd_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from DSSC_ADMIT_CARD_TBL where opd_personal_id=:opd_personal_id");
			q.setParameter("opd_personal_id", opd_id);
			@SuppressWarnings("unchecked")
			List<DSSC_ADMIT_CARD_TBL>  list = (List<DSSC_ADMIT_CARD_TBL>) q.list();
			tx.commit();
			session.close();
			return list;
		}

public List<EXAM_CENTER_CODE_M> getexamcentreListbyCenterNameDDL(SessionFactory sessionFactory,String ecc_name) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from EXAM_CENTER_CODE_M where ecc_name=:ecc_name and ecc_status_id=1");
			q.setParameter("ecc_name", ecc_name);
			@SuppressWarnings("unchecked")
			List<EXAM_CENTER_CODE_M>  list = (List<EXAM_CENTER_CODE_M>) q.list();
			
			tx.commit();
			session.close();
			return list;
		}


public List<CHOICE_M> getChoicemstIdByChoiceName(SessionFactory sessionFactory,String choice_name) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from CHOICE_M  where status_id=1 and name=:name order by id");
			q.setParameter("name", choice_name);
			@SuppressWarnings("unchecked")
			List<CHOICE_M>  list = (List<CHOICE_M>) q.list();
			tx.commit();
			session.close();
			return list;
		}



public long getDifferenceDays(Date d1, Date d2) {
    long diff = d2.getTime() - d1.getTime();
    return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
}

public List<DSSC_COURSE_VACANCY_RESERVE> getDsscTotalVacancyAndReserve(SessionFactory sessionFactory,int es_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from DSSC_COURSE_VACANCY_RESERVE  where  es_id=:es_id order by id");
			q.setParameter("es_id", es_id);
			@SuppressWarnings("unchecked")
			List<DSSC_COURSE_VACANCY_RESERVE>  list = (List<DSSC_COURSE_VACANCY_RESERVE>) q.list();
			tx.commit();
			session.close();
			return list;
		}


public List<REGIMENT_M> getRegimentIdMstListDDL(SessionFactory sessionFactory, String regtName) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from REGIMENT_M where r_name=:r_name");
			q.setParameter("r_name", regtName);
			@SuppressWarnings("unchecked")
			List<REGIMENT_M>  list = (List<REGIMENT_M>) q.list();
			tx.commit();
			session.close();
			return list;
		}



public List<TB_BARCODE_COUNT> getBarcodeDetails(SessionFactory sessionFactory, String barcode_no) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from TB_BARCODE_COUNT where barcode_no=:barcode_no");
			q.setParameter("barcode_no", barcode_no);
			@SuppressWarnings("unchecked")
			List<TB_BARCODE_COUNT>  list = (List<TB_BARCODE_COUNT>) q.list();
			tx.commit();
			session.close();
			return list;
		}


public List<SUB_SUBJECT_MST> getSubSubjectBySubId(SessionFactory sessionFactory, int sub_subject_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from SUB_SUBJECT_MST where id=:id and subsubject_status=1");
			q.setParameter("id", sub_subject_id);
			@SuppressWarnings("unchecked")
			List<SUB_SUBJECT_MST>  list = (List<SUB_SUBJECT_MST>) q.list();
			tx.commit();
			session.close();
			return list;
		}



public List<ARM_CODES_M> getarmNameByArmID(SessionFactory sessionFactory,int ac_arm_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from ARM_CODES_M  where  ac_arm_id=:ac_arm_id");
			q.setParameter("ac_arm_id", ac_arm_id);
			@SuppressWarnings("unchecked")
			List<ARM_CODES_M>  list = (List<ARM_CODES_M>) q.list();
			tx.commit();
			session.close();
			return list;
		}



public @ResponseBody List<SUBJECT_CODE_M> getSubjectIdBySubName(SessionFactory sessionFactory,int sc_subject_id) {

	Session session = sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
	Query q = session.createQuery("from SUBJECT_CODE_M where sc_subject_id=:sc_subject_id ");
				q.setParameter("sc_subject_id",sc_subject_id);
	@SuppressWarnings("unchecked")
	List<SUBJECT_CODE_M> list = (List<SUBJECT_CODE_M>) q.list();
	tx.commit();
	session.close();
	return list;
}



public @ResponseBody List<OFFICER_APPLICATION_M> getOfficerApplicationByIndexNo(SessionFactory sessionFactory,int index_no,int es_id) {
	 

	Session session = sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
	Query q = session.createQuery(" from OFFICER_APPLICATION_M where in_index_id=:in_index_id and es_id=:es_id ");
				q.setParameter("in_index_id", index_no);
				q.setParameter("es_id", es_id);
	@SuppressWarnings("unchecked")
	List<OFFICER_APPLICATION_M> list = (List<OFFICER_APPLICATION_M>) q.list();
	tx.commit();
	session.close();
	return list;
}


public  @ResponseBody List<INDEX_SLIP_MANUAL>  getSlipManualIDforOfc(SessionFactory sessionFactory,int indx_slpmstid, int subject_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEX_SLIP_MANUAL where is_ism_id=:is_ism_id and is_sc_subject_id=:is_sc_subject_id").setMaxResults(1);
			q.setParameter("is_ism_id", indx_slpmstid);
			q.setParameter("is_sc_subject_id", subject_id);
			@SuppressWarnings("unchecked")
			List<INDEX_SLIP_MANUAL>  list = (List<INDEX_SLIP_MANUAL>) q.list();
			tx.commit();
			session.close();
			return list;
		}


public @ResponseBody List<Reason_M> getreasonlist(SessionFactory sessionFactory) {
	 

	Session session = sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
	Query q = session.createQuery(" from Reason_M where  status='1' ");
	@SuppressWarnings("unchecked")
	List<Reason_M> list = (List<Reason_M>) q.list();
	tx.commit();
	session.close();
	return list;
}


public List<INDEX_SLIP_MASTER> getIndexSlipId(SessionFactory sessionFactory,int index_no, int es_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEX_SLIP_MASTER where ism_indexno=:ism_indexno and ism_es_id=:ism_es_id");
			q.setParameter("ism_indexno", index_no);
			q.setParameter("ism_es_id", es_id);
			@SuppressWarnings("unchecked")
			List<INDEX_SLIP_MASTER>  list = (List<INDEX_SLIP_MASTER>) q.list();
			tx.commit();
			session.close();
			return list;
		}



public List<QUALIFIED_OFFICERS> getMeritIdbyEsID(SessionFactory sessionFactory, int es_id, int oa_application_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from QUALIFIED_OFFICERS where es_id=:es_id and oa_applicant_id=:oa_applicant_id");
			q.setParameter("es_id", es_id);
			q.setParameter("oa_applicant_id", oa_application_id);
			@SuppressWarnings("unchecked")
			List<QUALIFIED_OFFICERS>  list = (List<QUALIFIED_OFFICERS>) q.list();
			tx.commit();
			session.close();
			return list;
		}


public List<DSSC_COURSE_VACANCY_RESERVE> getdsscCourseVacancyReserveList(SessionFactory sessionFactory,int es_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from DSSC_COURSE_VACANCY_RESERVE where es_id=:es_id");
			q.setParameter("es_id", es_id);
			@SuppressWarnings("unchecked")
			List<DSSC_COURSE_VACANCY_RESERVE>  list = (List<DSSC_COURSE_VACANCY_RESERVE>) q.list();
//			
			tx.commit();
			System.out.println("DSSC_COURSE_VACANCY_RESERVE=================="+list);
			session.close();
			return list;
		}



public List<EXAMSCHEDULE_INDEXING_DETAIL>getActiveIndxSubject(SessionFactory sessionFactory, int esi_es_id, int subject_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from EXAMSCHEDULE_INDEXING_DETAIL where esid_es_id=:esid_es_id");
			q.setParameter("esid_es_id", esi_es_id);
			@SuppressWarnings("unchecked")
			List<EXAMSCHEDULE_INDEXING_DETAIL>  list = (List<EXAMSCHEDULE_INDEXING_DETAIL>) q.list();
			tx.commit();
			session.close();
			return list;
		}


public List<INDEXED_BUNDLE_MASTER> getInactivebundlemsterId(SessionFactory sessionFactory,int es_id, int subject_id) {
	 Session session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query q = session.createQuery("from INDEXED_BUNDLE_MASTER where ibm_es_id=:ibm_es_id and ibm_nsubjectid=:ibm_nsubjectid and ibm_status_id=0 order by ibm_id desc").setMaxResults(1);
			q.setParameter("ibm_es_id",es_id);
			q.setParameter("ibm_nsubjectid",subject_id );
			@SuppressWarnings("unchecked")
			List<INDEXED_BUNDLE_MASTER>  list = (List<INDEXED_BUNDLE_MASTER>) q.list();
			tx.commit();
			session.close();
			return list;
		}
//-------------------------------START TO GET PATH OF UPLOAD EXCEL COMMON METHOD---------------------------//

	public String fileupload2(byte[] b,String name,String module_name,String type)
	{
		String extension = "";
	   	String fname ="";		  
		try{
			byte[] bytes =b; 
		    // Creating the directory to store file
			//String rootPath = System.getProperty("catalina.home");
		  // File dir = new File(rootPath + File.separator + "CCEP//"+id);
		    File dir = new File("/srv/ACR/"+module_name);  
		    if (!dir.exists())
			    dir.mkdirs();
		         
		    String filename =name;
		
		    int i = filename.lastIndexOf('.');
		    if (i >= 0) {
		    	extension = filename.substring(i+1);
			}
		    
		    // Create the file on server
		   // fname = dir.getAbsolutePath() + File.separator+"__" + dateUpload.currentDateWithTimeStampString()+ "."+extension;
		    fname = dir.getAbsolutePath() + File.separator+""+type+"_" + currentDateWithTimeStampString()+ "."+extension;
	   		File serverFile = new File(fname);	    
	        BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
	        stream.write(bytes);	                
	        stream.close();			
		}catch (Exception e) {
			e.getMessage();
		}
		System.out.println("----------fname--------------"+fname);
		return fname;
	}
	public String currentDateWithTimeStampString(){
		java.util.Date date = new java.util.Date();  
		Timestamp ts=new Timestamp(date.getTime());  
		return ts.toString().replace("-", "_").replace(":", "_").replace(" ", "_").replace(".", "_");
	}
	//-------------------------------END TO GET PATH OF UPLOAD EXCEL COMMON METHOD---------------------------//
	
	
	
	//================================search ic number with-out zero=============================//
	public String getSearchIcNumberwithoutZero(String opd_personal_id) {
		
			String Data=opd_personal_id.toString();
			String DataPre="";
			String DataM="";
			if(Data.contains("NTR") || Data.contains("NTS")) {
				DataPre= Data.substring(0,3);
				DataM = Data.substring(4);
			}else {
				DataPre= Data.substring(0,2);
				DataM = Data.substring(2);
			}

			opd_personal_id=DataPre+"%"+DataM;
			
			 return opd_personal_id;
		}

	
	
	
	//================================ic number with-out zero=============================//
	public String getIcNumberwithoutZero(String opc_personal_code) {
		
		String Data=opc_personal_code;
		String DataPre="";
		String DataM="";
		if(Data.contains("NTR") || Data.contains("NTS")) {
			DataPre= Data.substring(0,3);
			DataM = Data.substring(4);
		}else {
			DataPre= Data.substring(0,2);
			DataM = Data.substring(3);
		}
		
		Data=DataPre+DataM;
//		System.err.println("Data==--------"+Data);
		return Data;
		
	}
			
		


		
}
