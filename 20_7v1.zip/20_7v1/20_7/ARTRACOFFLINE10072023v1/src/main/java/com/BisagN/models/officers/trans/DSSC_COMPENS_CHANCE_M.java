package com.BisagN.models.officers.trans;


import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "dssc_compens_chance_new", uniqueConstraints = {
@UniqueConstraint(columnNames = "dcc_id"),})

public class DSSC_COMPENS_CHANCE_M {

      private int dcc_id;
      private int opd_personal_id;
      private int dcc_dispes_year;
      private int dcc_compens_year;
      private String dcc_remarks;
      private int dcc_compens_status;
      private int dcc_status_id;
      private String dcc_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dcc_creation_date;
      private String dcc_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dcc_modification_date;
      private String dcc_auth_doc;
  
  

  @Id
  @GeneratedValue(strategy = IDENTITY)
  @Column(name = "dcc_id", unique = true, nullable = false)



public int getDcc_id() {
	return dcc_id;
}
public void setDcc_id(int dcc_id) {
	this.dcc_id = dcc_id;
}
public int getOpd_personal_id() {
	return opd_personal_id;
}
public void setOpd_personal_id(int opd_personal_id) {
	this.opd_personal_id = opd_personal_id;
}
public int getDcc_dispes_year() {
	return dcc_dispes_year;
}
public void setDcc_dispes_year(int dcc_dispes_year) {
	this.dcc_dispes_year = dcc_dispes_year;
}
public int getDcc_compens_year() {
	return dcc_compens_year;
}
public void setDcc_compens_year(int dcc_compens_year) {
	this.dcc_compens_year = dcc_compens_year;
}
public String getDcc_remarks() {
	return dcc_remarks;
}
public void setDcc_remarks(String dcc_remarks) {
	this.dcc_remarks = dcc_remarks;
}
public int getDcc_compens_status() {
	return dcc_compens_status;
}
public void setDcc_compens_status(int dcc_compens_status) {
	this.dcc_compens_status = dcc_compens_status;
}
public int getDcc_status_id() {
	return dcc_status_id;
}
public void setDcc_status_id(int dcc_status_id) {
	this.dcc_status_id = dcc_status_id;
}
public String getDcc_created_by() {
	return dcc_created_by;
}
public void setDcc_created_by(String dcc_created_by) {
	this.dcc_created_by = dcc_created_by;
}
public Date getDcc_creation_date() {
	return dcc_creation_date;
}
public void setDcc_creation_date(Date dcc_creation_date) {
	this.dcc_creation_date = dcc_creation_date;
}
public String getDcc_modified_by() {
	return dcc_modified_by;
}
public void setDcc_modified_by(String dcc_modified_by) {
	this.dcc_modified_by = dcc_modified_by;
}
public Date getDcc_modification_date() {
	return dcc_modification_date;
}
public void setDcc_modification_date(Date dcc_modification_date) {
	this.dcc_modification_date = dcc_modification_date;
}
public String getDcc_auth_doc() {
	return dcc_auth_doc;
}
public void setDcc_auth_doc(String dcc_auth_doc) {
	this.dcc_auth_doc = dcc_auth_doc;
}

  



      
}
