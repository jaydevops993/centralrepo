package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.Indexing.SubjectWiseSecDetailsDao;
import com.BisagN.dao.officer.others.ExaminationlockunlockDAO;
import com.BisagN.models.officers.barcode.SECTIONWISEQUESTIONDETAILS;
import com.BisagN.models.officers.barcode.SUBJECTWISE_SECTIONDETAILS;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.PARTB_D_APPLICATION_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class SubjectWiseSectionDetailsController {
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	
	CommonController comm = new CommonController();
	
	
	@Autowired
	private SubjectWiseSecDetailsDao subwisesecDAO;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	@RequestMapping(value = "SearchSubjectWiseSectionDetails_Url", method = RequestMethod.GET)
	public ModelAndView SearchSubjectWiseSectionDetails_Url(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			{
		Mmap.put("msg", msg);
		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();	
		System.err.println("es_begindate==========="+es_begindate);
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		System.err.println("esid_es_id=============="+esi_es_id);
		if(esi_es_id != 0) {
		List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esi_es_id);
		Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
		LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		
		  int day = date.getDayOfMonth();
		  String[] months = {"Jan", "Feb", "Mar", "Apr" ,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		  
		  String[] shortMonths = new DateFormatSymbols().getShortMonths();
	        for (String shortMonth : shortMonths) {
	            
	      	 
	        }
		  
		  Month month = date.getMonth();
		  int year = date.getYear();
		  System.err.println(day+""+month+""+year);
		  System.err.println("o====="+month + ' ' + day + ' ' + year);
		String begindateShow= day +" "+ month + " "+ year;
		 
		 Mmap.put("begindateShow",begindateShow);
		 Mmap.put("esid_es_id",esi_es_id);
		
		
		if (ec_exam_id != 0) {
		List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
		Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
		Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
		
	}
		
		
		  
		 
		}
		
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
		  
		if(es_id != 0) {
			 List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
			 Mmap.put("es_id", es_id);
			 String index_mode= UnlcokExmsch.get(0).getEs_index_mode();
			 Mmap.put("index_mode", index_mode);
		}
		

		int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
		
		if (esid_sub_subject_id != 0) {
			List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
			String sub_subject_name=SubSubject.get(0).getSub_subject();
			Mmap.put("sub_subject_name", sub_subject_name);
		}
	     Mmap.put("msg", msg);
		


		return new ModelAndView("SearchSubjectWiseSectionDetails_tile");
	}

	
	
	@RequestMapping(value = "SubjectWiseSectionDetails_Url", method = RequestMethod.POST)
	public ModelAndView SubjectWiseSectionDetails_Url(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg) {

		int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		if(esi_es_id != 0) {
			
		
			
		List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esi_es_id);
		Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
		LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		
		  int day = date.getDayOfMonth();
		  String[] months = {"Jan", "Feb", "Mar", "Apr" ,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		  
		  String[] shortMonths = new DateFormatSymbols().getShortMonths();
	        for (String shortMonth : shortMonths) {
	            
	      	 
	        }
		  
		  Month month = date.getMonth();
		  int year = date.getYear();
		  System.err.println(day+""+month+""+year);
		  System.err.println("o====="+month + ' ' + day + ' ' + year);
		String begindateShow= day +" "+ month + " "+ year;
		 
		 Mmap.put("begindateShow",begindateShow);
		 Mmap.put("esid_es_id",esi_es_id);
		
		
		List<EXAMSCHEDULE_INDEXING_DETAIL>ActiveSubject = comm.getActiveIndxSubject(sessionFactory,esi_es_id);
		int Active_sub= ActiveSubject.get(0).getEsid_sc_subject_id();
		
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		System.err.println("ec_exam_id-----------"+ec_exam_id);
		if (ec_exam_id != 0) {
		List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
		Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
		Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
		
	}
		
		int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
		
		
		System.err.println("esid_sub_subject_id=============="+esid_sub_subject_id);
		
		if (esid_sub_subject_id != 0) {
			List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
			String sub_subject_name=SubSubject.get(0).getSub_subject();
			Mmap.put("sub_subject_name", sub_subject_name);
		}
		 
		}
	     Mmap.put("msg", msg);
	     
		
	     return new ModelAndView("SubjectWiseSectionDetails_tile");
		
	}
	
	
	
	




	         
	         
	         @RequestMapping(value = "/SubjectwiseSectionAction" ,method = RequestMethod.POST) 
	         public ModelAndView SubjectwiseSectionAction( @ModelAttribute("SubjectwiseSectionCMD") SUBJECTWISE_SECTIONDETAILS sub, BindingResult result, 
	         HttpServletRequest request, ModelMap model, HttpSession session){ 
	       	  Session sessionHQL = this.sessionFactory.openSession();
	       			Transaction tx = sessionHQL.beginTransaction();
	       		try {
	       			
	       			
	       	     String username = session.getAttribute("username").toString();
	       		Date date = new Date();
	       		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	       		int id = sub.getSsd_id() > 0 ? sub.getSsd_id() : 0;
	       		
	       		int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
	       		
	       		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
	       		
	       		String subject_id= request.getParameter("ssd_subject_id");
	       		String sub_ssd_subject_id=request.getParameter("sub_ssd_subject_id");
	       		
	       		  
	       			 Query q0 = sessionHQL.createQuery("select count(*) from SUBJECTWISE_SECTIONDETAILS where ssd_es_id=:ssd_es_id and ssd_subject_id=:ssd_subject_id");

	       				q0.setParameter("ssd_es_id", esid_es_id);
	       				q0.setParameter("ssd_subject_id", Integer.parseInt(subject_id));
	       		Long c = (Long) q0.uniqueResult();
	       		
	       		
	       		

	       	System.err.println("c------------"+c);
	       		if(id == 0) {
	       			
	       	if (c == 0  ) {
	       				
	       			
	       		sub.setSsd_es_id(esid_es_id);
	       		sub.setSsd_subject_id(Integer.parseInt(subject_id));
	       		if(!sub_ssd_subject_id.equals("")) {
	       			
	       		}
	       	
	       		sub.setSsd_createdate(date);
	       		int total_sec= Integer.parseInt(request.getParameter("ssd_total_sections"));
	       		
	       		int total_que= Integer.parseInt(request.getParameter("ssd_totalquestions"));
	    		int totalmark= Integer.parseInt(request.getParameter("ssd_totalmarks"));
	       		
	       		sub.setSsd_total_sections(total_sec);
	       		sub.setSsd_totalquestions(total_que);
	       		sub.setSsd_totalmarks(totalmark);
	       		 int mid = (int)sessionHQL.save(sub);
	       		 sessionHQL.flush();
	       		 sessionHQL.clear();
	       		 tx.commit();

	       			
	       		SECTIONWISEQUESTIONDETAILS sec = new SECTIONWISEQUESTIONDETAILS();
	       		 
	       		 Session sessionHQL1 = this.sessionFactory.openSession();
	       			Transaction tx1 = sessionHQL1.beginTransaction();
	       			
	       			String countimg = request.getParameter("count_img");
	       			for (int j = 1; j <= Integer.parseInt(countimg); j++) {
	       				sec.setSqd_createddate(date);
	       				String section_no = request.getParameter("sqd_sectionno"+j);
	       				String sqd_totalquestions = request.getParameter("sqd_totalquestions_tb"+j);
	       				String sqd_markablequestions = request.getParameter("sqd_markablequestions"+j);
	       				String sqd_marksperquestion = request.getParameter("sqd_marksperquestion"+j);
	       				
		       			sec.setSqd_marksperquestion(Integer.parseInt(sqd_marksperquestion));
		       			sec.setSqd_markablequestions(Integer.parseInt(sqd_markablequestions));
		       			sec.setSqd_sectionno(section_no);
		       			sec.setSqd_totalquestions(Integer.parseInt(sqd_totalquestions));
		       			sec.setSqd_ssd_id(mid);
		       			sessionHQL1.save(sec); 
		       			
		       			sessionHQL1.flush();
		       			sessionHQL1.clear();
	       			}
	       			
	       			
	       		
	       			 tx1.commit();

	       			
	       			model.put("msg","Data Saved Successfully"); 
	           
	       			
	       			}else {
	       				
	       				model.put("msg","Data already Exist"); 
	       			}
	       			   
	       		}
	        
	       		
	         } 
	       		
	       		
	       		catch (RuntimeException e) {
	       			try {
	       				tx.rollback();
	       				model.put("msg", "roll back transaction");
	       			} catch (RuntimeException rbe) {
	       				model.put("msg", "Couldn�t roll back transaction " + rbe);
	       			}
	       			throw e;
	       		} finally {
	       			if (sessionHQL != null) {
	       				sessionHQL.close();
	       			}
	       		}

	       		return new ModelAndView("redirect:SearchSubjectWiseSectionDetails_Url"); 
	       		}
	         
	         @RequestMapping(value = "/getSubwiseSecDetails", method = RequestMethod.POST)
	 		public @ResponseBody ArrayList<ArrayList<String>> getSubwiseSecDetails(int startPage, String pageLength,
	 				String Search, String orderColunm, String orderType, String subject_id,String subsubject_id,HttpSession sessionUserId)
	 				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
	 				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	 		  if(!subject_id.equals("")) {
	 			int esi_es_id = Integer.parseInt(sessionUserId.getAttribute("esid_es_id") == null ? "0" : sessionUserId.getAttribute("esid_es_id").toString());
	 			return subwisesecDAO.getSubwiseSecDetails(startPage, pageLength, Search, orderColunm, orderType,esi_es_id, subject_id,subsubject_id,sessionUserId);
	 		}
			return null;
	         }
	 		@RequestMapping(value = "/getTotalCountSubwiseSecDetails", method = RequestMethod.POST)
	 		public @ResponseBody long getTotalCountSubwiseSecDetails(HttpSession sessionUserId, String Search, String subject_id,String subsubject_id) {
	 			  if(!subject_id.equals("")) {
	 			int esi_es_id = Integer.parseInt(sessionUserId.getAttribute("esid_es_id") == null ? "0" : sessionUserId.getAttribute("esid_es_id").toString());
	 			return subwisesecDAO.getTotalCountSubwiseSecDetails(Search, esi_es_id,subject_id,subsubject_id);
	 		}
				return 0;
	 		}
	         
	 		@SuppressWarnings("unused")
			@RequestMapping(value = "/ExportManualMarkExcel", method = RequestMethod.POST)
	 		public ModelAndView ExportManualMarkExcel(HttpServletRequest request, ModelMap model, HttpSession session, String typeReport1,
	 				String subjectid2,String subsubjectid2)
	 				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
	 				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	 			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
	 					: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
	 			int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
	 			if (esi_es_id != 0) {
	 				
	 			    String enckey = "commonPwdEncKeys";  
	                String subjectId = hex_asciiDao.decrypt((String) subjectid2,enckey,session); 
	                
	                
	                String enckey2 = "commonPwdEncKeys";  
	                String SubsubjectId = hex_asciiDao.decrypt((String) subsubjectid2,enckey,session); 
	                
	                List<SUBJECT_CODE_M>getSubjectName=comm.getsubjectIdbysubname( sessionFactory, Integer.parseInt(subjectId), ec_exam_id) ;
	                String SubjectName=getSubjectName.get(0).getSc_subject_name();
	                
	                List<SUB_SUBJECT_MST>getSubsubjectName=comm.getSubSubjectBySubId(sessionFactory, Integer.parseInt(SubsubjectId));
	                if(!getSubsubjectName.isEmpty()) {
	                	  SubjectName=getSubsubjectName.get(0).getSub_subject();
	                }
	              
	            	List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esi_es_id);
	 				Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
	 				LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	 				
	 				  int day = date.getDayOfMonth();
	 				  String[] months = {"Jan", "Feb", "Mar", "Apr" ,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
	 				  
	 				  String[] shortMonths = new DateFormatSymbols().getShortMonths();
	 			        for (String shortMonth : shortMonths) {
	 			            
	 			      	 
	 			        }
	 				  
	 				  Month month = date.getMonth();
	 				  int year = date.getYear();
	 				  System.err.println(day+""+month+""+year);
	 				  System.err.println("o====="+month + ' ' + day + ' ' + year);
	 				String begindateShow=   month + " "+ year;
	                
	                
	                List<EXAM_CODE_M> getExamName= comm.getExamNamebyExmID( sessionFactory, ec_exam_id);
					 String Exm_name= getExamName.get(0).getEc_exam_name();
	 				
	 				 ArrayList<ArrayList<String>>subjectwiseSecDetails=subwisesecDAO.GetSubwiseQueDetails( esi_es_id, Integer.parseInt(subjectId), "Excel");
	 				 
	 				 System.err.println("SubjectName============"+SubjectName);
           
	 				 
           	ArrayList<ArrayList<String>> listexport=subwisesecDAO.GetIndexNoForExcel( esi_es_id,   Integer.parseInt(subjectId), "Excel");
	 				 
	 			if (subjectwiseSecDetails.size() > 0) {
	 				
                   
	 				List<String> TH = new ArrayList<String>();
	 				model.put("SubjectName", SubjectName);
	 				String Heading = "\n";
	 				String username = session.getAttribute("username").toString();
	 				return new ModelAndView(new ExportExcel_genExcelController("L", TH, Heading, username,listexport,SubjectName,Exm_name,begindateShow), "userList",
	 						subjectwiseSecDetails);
	 				} 
	 			else {
	 				model.put("msg", "Data Not Available.");
	 				return new ModelAndView("redirect:SearchSubjectWiseSectionDetails_Url");
	 			}
	 			
	 		}
	 			return null;
	 		}
	 		
	 		@SuppressWarnings("unchecked")
	 		@RequestMapping(value = "/CheckCountForManExcelSubWise", method = RequestMethod.POST)
	 		@ResponseBody
	 		public List<SUBJECTWISE_SECTIONDETAILS>CheckCountForManExcelSubWise(HttpSession session,
	 				String subject_id) {
	 			
	 			int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());

	 			List<SUBJECTWISE_SECTIONDETAILS>checkCount=comm.getsubjectwiseSecDetails( sessionFactory, esi_es_id, Integer.parseInt(subject_id)) ;
				return checkCount;

	 	
	 		}
	 		
	 		
	 		
	 		
	 		
	 		
	 		
	 		
	 		
	 		
	 		@RequestMapping(value = "UpdateManualMarkExcel", method = RequestMethod.POST)
	 		public ModelAndView UpdateManualMarkExcel(ModelMap Mmap, HttpSession session,String subjectid3,String totalmartks1,String subsubjectid3,String ssd_id3,	 				@RequestParam(value = "msg", required = false) String msg) {
	 			String enckey = "commonPwdEncKeys";
	 			int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
	 			if(esi_es_id != 0) {
	 				
	 				
	 				
	 				
	 				 Mmap.put("subjectid3",hex_asciiDao.decrypt((String) subjectid3,enckey,session));
	 				 
	 				 Mmap.put("subsubjectid3",hex_asciiDao.decrypt((String) subsubjectid3,enckey,session));
	 				
	 			List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esi_es_id);
	 			Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
	 			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	 			
	 			  int day = date.getDayOfMonth();
	 			  String[] months = {"Jan", "Feb", "Mar", "Apr" ,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
	 			  
	 			  String[] shortMonths = new DateFormatSymbols().getShortMonths();
	 		        for (String shortMonth : shortMonths) {
	 		            
	 		      	 
	 		        }
	 			  
	 			  Month month = date.getMonth();
	 			  int year = date.getYear();
	 			  System.err.println(day+""+month+""+year);
	 			  System.err.println("o====="+month + ' ' + day + ' ' + year);
	 			String begindateShow= day +" "+ month + " "+ year;
	 			 
	 			 Mmap.put("begindateShow",begindateShow);
	 			 Mmap.put("esid_es_id",esi_es_id);
	 			
	 			
	 			List<EXAMSCHEDULE_INDEXING_DETAIL>ActiveSubject = comm.getActiveIndxSubject(sessionFactory,esi_es_id);
	 			int Active_sub= ActiveSubject.get(0).getEsid_sc_subject_id();
	 			
	 			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
	 			System.err.println("ec_exam_id-----------"+ec_exam_id);
	 			if (ec_exam_id != 0) {
	 			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
	 			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
	 			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
	 			
	 		}
	 			
	 			int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
	 					: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
	 			
	 			
	 			System.err.println("esid_sub_subject_id=============="+esid_sub_subject_id);
	 			
	 			if (esid_sub_subject_id != 0) {
	 				List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
	 				String sub_subject_name=SubSubject.get(0).getSub_subject();
	 				Mmap.put("sub_subject_name", sub_subject_name);
	 			}
	 			 
	 			}
	 			
	 			int es_id = Integer
	 					.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
	 		
	 			String subjectid1=	hex_asciiDao.decrypt((String) subjectid3,enckey,session);
	 			
	 			ArrayList<ArrayList<String>> list = subwisesecDAO.GetSubwiseQueDetails(es_id, Integer.parseInt(subjectid1),
	 					"Excel");
	 		
	 			String section_count = list.get(0).get(2);
	 	 
	 			Mmap.put("section_count", section_count);
	 			
	 			Mmap.put("alldatalist", list);
	 			
	 			
	 			
	 			Mmap.put("totalmartks", totalmartks1);
	 			
	 		     Mmap.put("msg", msg);
	 		    Mmap.put("ssd_id3", ssd_id3);
	 		     
	 			
	 		     return new ModelAndView("SubjectWiseSectionDetailsUpdate_tile");
	 			
	 		} 
	 		
	 		
	 		
	 		
	 		
	 		
	 		
	 	   @RequestMapping(value = "/UPdateSubjectwiseSectionAction" ,method = RequestMethod.POST) 
	         public ModelAndView UPdateSubjectwiseSectionAction( @ModelAttribute("SubjectwiseSectionCMD") SUBJECTWISE_SECTIONDETAILS sub, BindingResult result, 
	         HttpServletRequest request, ModelMap model, HttpSession session){ 
	       	 
	 		  Session sessionHQL = this.sessionFactory.openSession();
     			Transaction tx = sessionHQL.beginTransaction();
     		try {
     			
     			String enckey = "commonPwdEncKeys";
     			
     	     String username = session.getAttribute("username").toString();
     		Date date = new Date();
     		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
     		int id = sub.getSsd_id() > 0 ? sub.getSsd_id() : 0;
     		
     		int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
     		
     		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
     		
     		String subject_id= request.getParameter("ssd_subject_id");
     		String sub_ssd_subject_id=request.getParameter("sub_ssd_subject_id");
     		
     		  String ssd_id3=hex_asciiDao.decrypt((String) request.getParameter("ssd_id3"),enckey,session);
     		  
     		  System.err.println("ssd_id3================"+ssd_id3);
     		  
//     		 subwisesecDAO.deletedate( Integer.parseInt(ssd_id3));
     		 
     		String hql4 = "DELETE from SECTIONWISEQUESTIONDETAILS where sqd_ssd_id=:sqd_ssd_id ";
			Query query4 = sessionHQL.createQuery(hql4) 
				
					.setParameter("sqd_ssd_id", Integer.parseInt(ssd_id3));
			int row= query4.executeUpdate();

//			tx.commit();
     		
 
     		
     		int total_sec= Integer.parseInt(request.getParameter("ssd_total_sections"));
       		
       		int total_que= Integer.parseInt(request.getParameter("ssd_totalquestions"));
    		int totalmark= Integer.parseInt(request.getParameter("ssd_totalmarks"));
       		
    		int sub_subject_id=0; 

    		if (! (sub_ssd_subject_id == null) ) {
    			sub_subject_id =Integer.parseInt(sub_ssd_subject_id);
			}
    		else
    		{
    			sub_subject_id =0;
			}
    		
    		
			String hql45 = "update SUBJECTWISE_SECTIONDETAILS set ssd_subject_id=:ssd_subject_id,sub_ssd_subject_id=:sub_ssd_subject_id, ssd_total_sections=:ssd_total_sections, ssd_totalquestions=:ssd_totalquestions,"
					+ "ssd_totalmarks=:ssd_totalmarks where ssd_id=:ssd_id ";
			Query query45 = sessionHQL.createQuery(hql45) 
					.setParameter("ssd_subject_id", Integer.parseInt(subject_id))
					.setParameter("sub_ssd_subject_id",sub_subject_id).setParameter("ssd_total_sections", total_sec)
					.setParameter("ssd_totalquestions", total_que).setParameter("ssd_totalmarks", totalmark)
					.setParameter("ssd_id", Integer.parseInt(ssd_id3));
			int row2= query45.executeUpdate();

			tx.commit();
     		
     			
     		SECTIONWISEQUESTIONDETAILS sec = new SECTIONWISEQUESTIONDETAILS();
     		 
     		 Session sessionHQL1 = this.sessionFactory.openSession();
     			Transaction tx1 = sessionHQL1.beginTransaction();
     			
     			String countimg = request.getParameter("count_img");
     			for (int j = 1; j <= Integer.parseInt(countimg); j++) {
     				sec.setSqd_createddate(date);
     				String section_no = request.getParameter("sqd_sectionno"+j);
     				String sqd_totalquestions = request.getParameter("sqd_totalquestions_tb"+j);
     				String sqd_markablequestions = request.getParameter("sqd_markablequestions"+j);
     				String sqd_marksperquestion = request.getParameter("sqd_marksperquestion"+j);
     				
	       			sec.setSqd_marksperquestion(Integer.parseInt(sqd_marksperquestion));
	       			sec.setSqd_markablequestions(Integer.parseInt(sqd_markablequestions));
	       			sec.setSqd_sectionno(section_no);
	       			sec.setSqd_totalquestions(Integer.parseInt(sqd_totalquestions));
	       			sec.setSqd_ssd_id(Integer.parseInt(ssd_id3));
	       			sessionHQL1.save(sec); 
	       			
	       			sessionHQL1.flush();
	       			sessionHQL1.clear();
     			}
     			
     			
     		
     			 tx1.commit();

     			
     			model.put("msg","Data Update Successfully"); 
     		  

     	     			
     			   
      
     		
       } 
     		
     		
     		catch (RuntimeException e) {
     			try {
     				tx.rollback();
     				model.put("msg", "roll back transaction");
     			} catch (RuntimeException rbe) {
     				model.put("msg", "Couldn�t roll back transaction " + rbe);
     			}
     			throw e;
     		} finally {
     			if (sessionHQL != null) {
     				sessionHQL.close();
     			}
     		}
	 		    
	       		return new ModelAndView("redirect:SearchSubjectWiseSectionDetails_Url"); 
	       		}
	 		
	 		
	 		
	 		
}
	         
