package com.BisagN.dao.officer.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Service
public class IAST_CASEDaoImpl implements IAST_CasesDAO {
	
	

	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	 CommonController comm= new CommonController();



			public boolean checkIsIntegerValue(String Search) {
				return Search.matches("[0-9]+");
			}
			public List<Map<String, Object>> getReportListOfficer_personal_detailsForIAST(int startPage,String pageLength,String Search,String orderColunm,String orderType,String pers_no,String pers_name,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
				if(pageLength.equals("-1")){
		 			pageLength = "ALL";
				}
				String SearchValue = GenerateQueryWhereClause_SQL(Search,pers_no,pers_name);
		 		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
				Connection conn = null;
				String q = "";
				String q1 = "";
				String q2 = "";
				
		if (!pers_no.equals("")) {
					
					
					pers_no=comm.getSearchIcNumberwithoutZero(pers_no);
					 
				}
				
				
				try {
					conn = dataSource.getConnection();
					
					q = "select vw.opd_personal_id ,vw.opc_personal_code,vw.opd_officer_name,vw.opc_suffix_code,vw.cc_command_name,vw.ac_arm_description,TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm,vw.opd_unit,\n"
							+ "					TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority, TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob \n"
							+ "					from vw_personal_details vw where vw.opd_status_id='1'  "+SearchValue+" ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
//					

					PreparedStatement stmt = conn.prepareStatement(q);
					stmt = setQueryWhereClause_SQL(stmt,Search,pers_no,pers_name);
					
					
					System.out.println("stmt=======ssssss==fff========="+stmt);
					ResultSet rs = stmt.executeQuery();
					ResultSetMetaData metaData = rs.getMetaData();
		 			int columnCount = metaData.getColumnCount();
		 			while (rs.next()) {
						Map<String, Object> columns = new LinkedHashMap<String, Object>();
						for (int i = 1; i <= columnCount; i++) {
						    columns.put(metaData.getColumnLabel(i), rs.getObject(i));
						}
		                      String enckey ="commonPwdEncKeys";
			                    Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
			                    String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("opd_personal_id").toString().getBytes())));
			                    
			                    
		                      String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"+EncryptedPk+"')}else{ return false;}\""; 
		                      String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
		                      String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('"+EncryptedPk+"')}else{ return false;}\""; 
		                      String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>"; 
		                      String f = "";
		                      
		                      String f1 = "";
		                      f += updateButton;
		                      
		                     String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
		     				 String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));
		     				 
		     				 f1 += opc_code;
		                     columns.put("action",f);
		                     columns.put("opc_code",f1);
		                     columns.put(metaData.getColumnLabel(1), f);
		     		         list.add(columns);
			}
		           rs.close();
		           stmt.close();
		           conn.close();
		            } catch (SQLException e) {
		      	e.printStackTrace();
		    } finally {
		           if (conn != null) {
		      try {
			         conn.close();
		          } catch (SQLException e) {
		        }
		      }
		    }
		          return list;
		 }


public long getIASTCaseOfficer_personal_detailsTotalCount(String Search,String pers_no,String pers_name) {
	String SearchValue = GenerateQueryWhereClause_SQL(Search,pers_no,pers_name);
	int total = 0;
	String q = null;
	Connection conn = null;
	String q1 = "";
	String q2 = "";
	
	try {
		conn = dataSource.getConnection();
		
		
			q ="select count(*) from (select vw.opd_personal_id, vw.opc_personal_code, vw.opd_officer_name,vw.cc_command_name,vw.ac_arm_description,TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm,vw.opd_unit,\n"
					+ "					TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority, TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob from vw_personal_details vw where vw.opd_status_id='1'    "+SearchValue +") ab" ;
			
//		q ="select count(*) from (SELECT DISTINCT opd.opd_personal_id, TO_CHAR(opd.opd_dob,'DD/MM/YYYY') as opd_dob, opd.ct_comm_id, com.ct_comm_type, opd.opd_officer_name,cc.cc_command_name,\n" + 
//				"TO_CHAR(opd.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm ,TO_CHAR(opd.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority ,\n" + 
//				" 						opd.opd_unit,opd.opd_unit_address2,ofcode.opc_personal_code,ofarm.ac_arm_code,ar.ac_arm_description,rc.rc_rank_name \n" + 
//				"						from officer_personal_code  opc\n" + 
//				" 						inner join officer_personal_details opd on opc.opd_personal_id =opd.opd_personal_id\n" + 
//				" 						inner join commission_type com on com.ct_comm_id = opd.ct_comm_id\n" + 
//				" 					inner join officer_personal_code ofcode on ofcode.opd_personal_id = opc.opd_personal_id  and ofcode.opc_status_id='1' \n" + 
//				"					inner join officer_arm ofarm on ofarm.opd_personal_id = opd.opd_personal_id\n" + 
//				"					inner join arm_codes ar on ar.ac_arm_id=ofarm.ac_arm_id\n" + 
//				" 					inner join officer_rank orank on orank.opd_personal_id=opd.opd_personal_id\n" + 
//				"					inner join rank_code rc on rc.rc_rank_id = orank.rc_rank_id\n" + 
//				"					inner join command_code cc on cc.cc_command_id=opd.cc_command_id where opd.opd_status_id='1' "+SearchValue +"  ) ab " ;
//		
		PreparedStatement stmt = conn.prepareStatement(q);
		
		stmt = setQueryWhereClause_SQL(stmt,Search,pers_no,pers_name);
		
		
		ResultSet rs = stmt.executeQuery();
		
		while (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return (long) total;
}


public String GenerateQueryWhereClause_SQL(String Search,String pers_no,String pers_name) {
	String SearchValue ="";
	
	
	
	if (!pers_no.equals("") && pers_no != "" && pers_no != null) {
			SearchValue += " and lower(vw.opc_personal_code) like ?"; 
		}
		
		
		
		if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
			System.out.println("name===="+pers_name);
			SearchValue += " and lower(vw.opd_officer_name) like ?"; 
		}
		
		
		
	if(!Search.equals("")) {
	Search = Search.toLowerCase();
		SearchValue =" and ( ";
//	if (checkIsIntegerValue(Search)) {
//		SearchValue += " id=? or ";
//	}
//	
//		SearchValue +=" "+ct_comm_id+" lower(opd_unit) like ? or lower(opd_unit_address2) like ? or"
//			+" to_char(opd_dob,'dd-MM-yyyy') like ? or "
//				+ "to_char(opd_date_of_comm,'dd-MM-yyyy') like ? or to_char(opd_date_of_seniority,'dd-MM-yyyy') like ? or  "
//				+ " lower(opd_remarks) like ? )";

	SearchValue +="lower(vw.opc_personal_code) like ? or lower(vw.opd_officer_name) like ? or lower(vw.ac_arm_description) like ? )" ;
	
	}
return SearchValue;
}


public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,String pers_no,String pers_name) {
	int flag = 0;
	try {
		
		

			if (!pers_no.equals("") && pers_no != "" && pers_no != null)  {
				flag += 1;
				stmt.setString(flag, "%" + pers_no + "%");
			}
			
			if (!pers_name.equals("") && pers_name != "" && pers_name != null)  {
				flag += 1;
				stmt.setString(flag, "%" + pers_name + "%");
			}
			
			
			
	if(!Search.equals("")) {
			if(checkIsIntegerValue(Search)) {
				flag += 1;
				stmt.setInt(flag, Integer.parseInt(Search));
			}
			if(checkIsIntegerValue(Search)) {
				flag += 1;
				stmt.setInt(flag, Integer.parseInt(Search));
			}
			flag += 1;
			Search=comm.getSearchIcNumberwithoutZero(Search);

			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			
		}
	}catch (Exception e) {}
	return stmt;
}

}
