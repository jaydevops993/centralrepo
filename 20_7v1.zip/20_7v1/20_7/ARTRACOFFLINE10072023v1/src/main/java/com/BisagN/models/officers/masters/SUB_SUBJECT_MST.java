package com.BisagN.models.officers.masters;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;



@Entity
@Table(name = "sub_subject_mst_tbl", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})
public class SUB_SUBJECT_MST {

	
	
	private int id; 
	private String sub_subject;
	private int sub_spl_arm; 
	private String created_by;
	private Date created_date;
	private String modified_by;
	private Date modified_date;
	private int sc_subject_id;
	private int subsubject_status;
	
	
	  @Id
	    @GeneratedValue(strategy = IDENTITY)
	    @Column(name = "id", unique = true, nullable = false)
		
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getSub_subject() {
		return sub_subject;
	}
	public void setSub_subject(String sub_subject) {
		this.sub_subject = sub_subject;
	}
	public int getSub_spl_arm() {
		return sub_spl_arm;
	}
	public void setSub_spl_arm(int sub_spl_arm) {
		this.sub_spl_arm = sub_spl_arm;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	
	public int getSc_subject_id() {
		return sc_subject_id;
	}
	public void setSc_subject_id(int sc_subject_id) {
		this.sc_subject_id = sc_subject_id;
	}
	public int getSubsubject_status() {
		return subsubject_status;
	}
	public void setSubsubject_status(int subsubject_status) {
		this.subsubject_status = subsubject_status;
	}
	
	
	
	
	
}
