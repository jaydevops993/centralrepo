package com.BisagN.models.officers.masters;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "area_master", uniqueConstraints = {
@UniqueConstraint(columnNames = "area_id"),})

public class AREA_M {
	
	
	private int area_id;
	private String area_name;
	private int area_status_id;
	private String created_by;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date created_date;
	private String modified_by;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date modified_date;
	private String area_command_name;
	private String area_authority_letter_reference;
	
	@Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "area_id", unique = true, nullable = false)
	
	public int getArea_id() {
		return area_id;
	}
	public void setArea_id(int area_id) {
		this.area_id = area_id;
	}
	public String getArea_name() {
		return area_name;
	}
	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}
	public int getArea_status_id() {
		return area_status_id;
	}
	public void setArea_status_id(int area_status_id) {
		this.area_status_id = area_status_id;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	public String getArea_command_name() {
		return area_command_name;
	}
	public void setArea_command_name(String area_command_name) {
		this.area_command_name = area_command_name;
	}
	public String getArea_authority_letter_reference() {
		return area_authority_letter_reference;
	}
	public void setArea_authority_letter_reference(String area_authority_letter_reference) {
		this.area_authority_letter_reference = area_authority_letter_reference;
	}
	
	
	
}
