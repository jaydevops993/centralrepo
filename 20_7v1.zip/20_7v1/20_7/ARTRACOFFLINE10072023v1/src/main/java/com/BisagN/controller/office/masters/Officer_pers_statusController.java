package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.officer.others.Officer_pers_DAO;
 


@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Officer_pers_statusController {
	
	 
	@Autowired
	Officer_pers_DAO opd ;


	
	
	
	CommonController comm = new CommonController();
	
	 @RequestMapping(value = "Officer_personal_status_Url", method = RequestMethod.GET)
     public ModelAndView Officer_personal_status_Url(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

		
         Mmap.put("msg", msg);
     return new ModelAndView("officer_pers_status_tile");
}
 
	 
	 @SuppressWarnings("unchecked") 
	  @RequestMapping(value = "/getofficersdetailsvis", method = RequestMethod.POST)
	  @ResponseBody public  ArrayList<ArrayList<String>> getofficersdetailsvis(HttpSession session,
			  String opd_personal_hid) { 
		 
		 ArrayList<ArrayList<String>> list=  opd.Officer_pers_data(opd_personal_hid);
		 System.err.println("list=="+list);
	      return list;	 
}
	 
	 
	 @SuppressWarnings("unchecked") 
	  @RequestMapping(value = "/getOfficer_pers_data_part_b", method = RequestMethod.POST)
	  @ResponseBody public  ArrayList<ArrayList<String>> getOfficer_pers_data_part_b(HttpSession session,
			  String opd_personal_hid) { 
		 
		 ArrayList<ArrayList<String>> list=  opd.Officer_pers_data_part_b(opd_personal_hid);
		 System.err.println("list=="+list);
	      return list;	 
}
	 
	 
	 @SuppressWarnings("unchecked") 
	  @RequestMapping(value = "/getOfficer_pers_data_part_d", method = RequestMethod.POST)
	  @ResponseBody public  ArrayList<ArrayList<String>> getOfficer_pers_data_part_d(HttpSession session,
			  String opd_personal_hid) { 
		 
		 ArrayList<ArrayList<String>> list=  opd.Officer_pers_data_part_d(opd_personal_hid);
		 System.err.println("list=="+list);
	      return list;	 
}
	 
	 @SuppressWarnings("unchecked") 
	  @RequestMapping(value = "/getOfficer_pers_data_DSSC", method = RequestMethod.POST)
	  @ResponseBody public  ArrayList<ArrayList<String>> getOfficer_pers_data_DSSC(HttpSession session,
			  String opd_personal_hid) { 
		 
		 ArrayList<ArrayList<String>> list=  opd.Officer_pers_data_DSSC(opd_personal_hid);
//		 System.err.println("list=="+list); 
	      return list;	 
}
	 
	 @SuppressWarnings("unchecked") 
	  @RequestMapping(value = "/getOfficer_pers_data_withheld", method = RequestMethod.POST)
	  @ResponseBody public  ArrayList<ArrayList<String>> getOfficer_pers_data_withheld(HttpSession session,
			  String opd_personal_hid,int exam_id) { 
		
		 ArrayList<ArrayList<String>> list=  opd.Officer_pers_data_withheld(opd_personal_hid,exam_id);

	      return list;	 
} 
	 
}
