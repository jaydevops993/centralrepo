package com.BisagN.controller.office.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.trans.WithdrawAppDao;
import com.BisagN.models.officers.masters.AREA_M;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.PARTB_D_APPLICATION_M;
import com.BisagN.models.officers.others.WITHDRAWAL_APPLICATION_M;
import com.BisagN.models.officers.trans.DSSC_COMPENS_CHANCE_M;


@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Withdraw_applicationController {
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	
	@Autowired
	private PartB_ExaminationDAO partBDao;
	
	CommonController comm = new CommonController();
	
	@Autowired
	 Officer_personal_detailsDAO objDAO;
	
	@Autowired
	WithdrawAppDao wdDao;
	
	@Autowired
	private RoleBaseMenuDAO roledao; 
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();;
	
	@RequestMapping(value = "SearchWithdraw_applicationUrl", method = RequestMethod.GET)
	public ModelAndView SearchWithdraw_applicationUrl(ModelMap Mmap, HttpSession session,HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
		
		 if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

    	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("SearchWithdraw_applicationUrl", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}	
		
			
		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();	
		
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		if (ec_exam_id ==3) {
			if (!es_begindate.equals("")) {
				Mmap.put("DSSC_begindate", es_begindate);
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
			if (ec_exam_id != 0) {
				ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
				Mmap.put("getexamcentrelist", examcentrelist);
				Mmap.put("ec_exam_id", ec_exam_id);
			}
		}
		Mmap.put("msg", msg);
		return new ModelAndView("Searchwithdraw_tile");
	}
	
	
	
	 @RequestMapping(value = "Withdrawdssc_tsocURL", method = RequestMethod.POST)
	  public ModelAndView Withdrawdssc_tsocURL(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String deleteid) {


	      Mmap.put("msg", msg);
	  return new ModelAndView("withdrawdssctsoc_tile");
	}
	 

	  @RequestMapping(value = "/withdraAction" ,method = RequestMethod.POST) 
	  public ModelAndView withdraAction( @ModelAttribute("PartBCMD") WITHDRAWAL_APPLICATION_M withdr, BindingResult result, 
	  HttpServletRequest request, ModelMap model, HttpSession session){ 
		  
			
		  
			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			
			String opd_personal_id1=request.getParameter("opd_personal_id");
			if(opd_personal_id1 == "" || opd_personal_id1.equals("")) {
				model.put("msg", "Please Enter Personal Number");		
				return new ModelAndView("redirect:SearchWithdraw_applicationUrl");
			}
			
			String wa_remarks=request.getParameter("wa_remarks");
			if(wa_remarks == "" || wa_remarks.equals("")) {
				model.put("msg", "Please Enter Remarks");		
				return new ModelAndView("redirect:SearchWithdraw_applicationUrl");
			}
		
			try {
				
		
				
				
				  	String username = session.getAttribute("username").toString();
					Date date = new Date();
					SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
					int id = withdr.getId() > 0 ? withdr.getId() : 0;
					DateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
					
					int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
					 String opd_personal_id = request.getParameter("opd_personal_id");
					List<OFFICER_PERSONAL_CODE_M>getopdId=comm.getopdIdbycode( sessionFactory, opd_personal_id);
					if(!getopdId.isEmpty()) {
					int opd_persId= getopdId.get(0).getOpd_personal_id();
					
					List<OFFICER_APPLICATION_M> Oapp_id= comm.getOappIdbyopdId( sessionFactory, opd_persId,es_id);
					if(!Oapp_id.isEmpty()) {
					int O_app_id= Oapp_id.get(0).getOa_application_id();
					
					if(id == 0) {
						
						withdr.setWa_chance(Integer.parseInt(request.getParameter("wa_chance")));
						withdr.setWa_remarks(request.getParameter("wa_remarks"));
						withdr.setOa_application_id(O_app_id);
						sessionHQL.save(withdr); 
						
			    
						 String hq15 = "update OFFICER_APPLICATION_M set oa_status_id=:oa_status_id where oa_application_id=:oa_application_id ";
							Query query5 = sessionHQL.createQuery(hq15)
										.setParameter("oa_status_id", 5)	
										.setParameter("oa_application_id",O_app_id);
										
							query5.executeUpdate();
							
							model.put("msg","Data Saved Successfully"); 
						 
					}
					
					}else {
						model.put("msg","The Application is not Generated"); 
					}
					
					}else {
						model.put("msg","Wrong Personal Number"); 
					}
					   tx.commit(); 
					    sessionHQL.close(); 
			}
			catch (RuntimeException e) {
				try {
					tx.rollback();
					model.put("msg", "roll back transaction");
				} catch (RuntimeException rbe) {
					model.put("msg", "Couldn�t roll back transaction " + rbe);
				}
				throw e;
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}

			return new ModelAndView("redirect:SearchWithdraw_applicationUrl"); 
			
			}
	  
	  
	  @RequestMapping(value = "/getWithdrawAppReportDataList", method = RequestMethod.POST)
		public @ResponseBody List<Map<String, Object>> getWithdrawAppReportDataList(int startPage,
				String pageLength, String Search, String orderColunm, String orderType,String pers_no,String pers_name,HttpSession sessionUserId)
				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
			return wdDao.getReportListWithdrawApp(startPage, pageLength, Search, orderColunm, orderType,pers_no, pers_name,
					sessionUserId);
		}

		@RequestMapping(value = "/getWithdrawAppTotalCount", method = RequestMethod.POST)
		public @ResponseBody long getWithdrawAppTotalCount(HttpSession sessionUserId, String Search, String pers_no,String pers_name) {
			return wdDao.getReportListgetReportListWithdrawAppTotalCount(Search,pers_no, pers_name);
		}
		
		
		  @RequestMapping(value = "EditWithdrawdsscUrl", method = RequestMethod.POST)
	         public ModelAndView EditWithdrawdsscUrl(ModelMap Mmap,HttpSession session,
	        		 @RequestParam(value = "msg", required = false) String msg,String updateid) {

	                try {
						Session s1 = this.sessionFactory.openSession();
						Transaction tx = s1.beginTransaction();
						int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
						String enckey = "commonPwdEncKeys";  
						String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
						
						Query q = null;
						q = s1.createQuery("from WITHDRAWAL_APPLICATION_M where cast(id as string)=:PK");
						q.setString("PK", DcryptedPk);
						
						@SuppressWarnings("unchecked")
						List<WITHDRAWAL_APPLICATION_M> list = (List<WITHDRAWAL_APPLICATION_M>) q.list();
						tx.commit();
						s1.close();
						Mmap.put("EditWithdrawCMD1", list.get(0));
						int oa_application_id=list.get(0).getOa_application_id();
						List<OFFICER_APPLICATION_M>getopdId=comm.getOpdIdbyOappId( sessionFactory, oa_application_id, es_id);
						int opdid=getopdId.get(0).getOpd_personal_id();
						Mmap.put("Edit_pers_details", objDAO.getpersdetails(String.valueOf(opdid)));
						Mmap.put("msg", msg);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
	                
	         return new ModelAndView("EditWithdrawApptiles","EditWithdrawMstCMD",new WITHDRAWAL_APPLICATION_M());
	}
			
		  
		  @RequestMapping(value = "/EditwithdraAction", method = RequestMethod.POST)
			public ModelAndView EditwithdraAction(
					@Valid @ModelAttribute("EditWithdrawMstCMD") WITHDRAWAL_APPLICATION_M ln, BindingResult result,
					HttpServletRequest request, ModelMap model, HttpSession session) {


				

				Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction();
				String id=request.getParameter("id");
				String wa_chance=request.getParameter("wa_chance");
				String wa_remarks=request.getParameter("wa_remarks");
				
				 String hq15 = "update WITHDRAWAL_APPLICATION_M set wa_chance=:wa_chance,wa_remarks=:wa_remarks where id=:id ";
					Query query5 = sessionHQL.createQuery(hq15)
								.setParameter("wa_chance", Integer.parseInt(wa_chance))	
								.setParameter("wa_remarks",wa_remarks)
								.setParameter("id",Integer.parseInt(id));;
								
					query5.executeUpdate();
				tx.commit();
				sessionHQL.close();

				model.put("msg", "Data Updated Successfully");
				return new ModelAndView("redirect:SearchWithdraw_applicationUrl");
			}

}
