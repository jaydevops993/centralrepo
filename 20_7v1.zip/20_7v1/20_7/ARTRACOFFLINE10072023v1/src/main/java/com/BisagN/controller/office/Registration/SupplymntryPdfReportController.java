package com.BisagN.controller.office.Registration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class SupplymntryPdfReportController extends AbstractPdfView {

	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public SupplymntryPdfReportController(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		document.setPageSize(PageSize.A4.rotate());
		super.buildPdfMetadata(model, document, request);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		
		response.setContentType("application/pdf");
	response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");

	
	Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 16, 1);
	Font fontTableHeading2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 20, 1);
	
	
	
	
	Font fontTableHeadingMainHead_Ml = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 1);
	
	Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
	
	Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 0);
	
	
	Font fontTableHeadingdataforML2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 0);
	
	int latest_Serno = (int) model.get("latest_Serno");
	String es_year = (String) model.get("es_year");
	String old_Serno = (String) model.get("old_Serno");
	String report_name = (String) model.get("report_name");
	String b_month = (String) model.get("b_month");
	String exam_name1 = (String) model.get("exam_name1");
	String director_name = (String) model.get("director_name");
	String letter_no = (String) model.get("letter_no");
	

	
	
	
	PdfPTable table_c2 = new PdfPTable(1);
	table_c2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	table_c2.setWidthPercentage(100);
	
	
	

	PdfPTable tabledata_C12 = new PdfPTable(1);
	tabledata_C12.setWidths(new int[] { 4 });
	tabledata_C12.setWidthPercentage(100 / 1f);
	tabledata_C12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	tabledata_C12.setHorizontalAlignment(Element.ALIGN_RIGHT);
	tabledata_C12.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	
	
	

	PdfPTable tabledata_C1 = new PdfPTable(1);
	tabledata_C1.setWidths(new int[] { 7 });
	tabledata_C1.setWidthPercentage(100 /4.5f);
	tabledata_C1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata_C1.setHorizontalAlignment(Element.ALIGN_RIGHT);
	tabledata_C1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

	PdfPTable tabledata_C2 = new PdfPTable(1);
	tabledata_C2.setWidths(new int[] { 8 });
	tabledata_C2.setWidthPercentage(100 / 7.4f);
	tabledata_C2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata_C2.setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata_C2.getDefaultCell().setBorder(Rectangle.NO_BORDER);

	PdfPTable tabledata_C3 = new PdfPTable(1);
	tabledata_C3.setWidths(new int[] { 4 });
	tabledata_C3.setWidthPercentage(100 / 3f);
	tabledata_C3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata_C3.setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata_C3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	
	

	PdfPTable tabledata_C66 = new PdfPTable(1);
	tabledata_C66.setWidths(new int[] { 4 });
	tabledata_C66.setWidthPercentage(100 /5.5f);
	tabledata_C66.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
	tabledata_C66.setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata_C66.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	
	Chunk underline1 = new Chunk("REGD SDS" , fontTableHeadingMainHead_Ml);
	underline1.setUnderline(0.1f, -2f);
	
	Phrase phh2 = new Phrase(underline1);
	phh2.add("\n");
	phh2.add("\n");
	
	
	Paragraph cell12 = new Paragraph(phh2);
	cell12.setAlignment(Element.ALIGN_LEFT);
	
	tabledata_C1.addCell(cell12);
	
	
	Paragraph head_c1 = new Paragraph("Exam Sec", fontTableHeadingMainHead_Ml);
	Paragraph head_c58 = new Paragraph("HQ ARTRAC", fontTableHeadingMainHead_Ml);
	Paragraph head_c2 = new Paragraph("Pin - 908548", fontTableHeadingMainHead_Ml);
	Paragraph head_c3 = new Paragraph("ClO 56 APO", fontTableHeadingMainHead_Ml);

	tabledata_C1.addCell(head_c1);
	tabledata_C1.addCell(head_c58);
	tabledata_C1.addCell(head_c2);
	tabledata_C1.addCell(head_c3);


	Paragraph head_c4 = new Paragraph("Tele : 2822", fontTableHeadingSubMainHead);
	PdfPCell blank_head_c4 = new PdfPCell(head_c4);
	blank_head_c4.setHorizontalAlignment(Element.ALIGN_LEFT);
	blank_head_c4.setPaddingTop(45f);
	
	blank_head_c4.setBorder(0);
	tabledata_C12.addCell(blank_head_c4);
	Paragraph head_c5 = new Paragraph("A/16014/B/2021/GS/Exam Sec",fontTableHeadingdataforML2);
	blank_head_c4 = new PdfPCell(head_c5);
	blank_head_c4.setHorizontalAlignment(Element.ALIGN_TOP);
	blank_head_c4.setPaddingBottom(15f);
	blank_head_c4.setBorder(0);
	tabledata_C3.addCell(blank_head_c4);
	Paragraph head_c6 = new Paragraph("MS 8C, MS BRANCH", fontTableHeadingMainHead_Ml);
	Paragraph head_c7 = new Paragraph("IHQ of MoD (Army)", fontTableHeadingMainHead_Ml);
	Paragraph head_c8 = new Paragraph("DHQ PO,New Delhi-110011", fontTableHeadingMainHead_Ml);


	tabledata_C3.addCell(head_c6);
	tabledata_C3.addCell(head_c7);
	tabledata_C3.addCell(head_c8);

	Chunk underlinec1 = new Chunk("AMDTS : RESULTS OF PROMOTION EXAM "+exam_name1+" : "+b_month+" "+es_year+"",
			fontTableHeading1);

	underlinec1.setUnderline(0.1f, -2f);

	Phrase phhc2 = new Phrase(underlinec1);
	phhc2.setFont(fontTableHeading2);

	Paragraph cell_c12 = new Paragraph(phhc2);
	cell_c12.setAlignment(Element.ALIGN_CENTER);
	
	
	
	
	PdfPTable table_2 = new PdfPTable(2);
	table_2.setWidths(new int[] {5,90});
	table_2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	table_2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	table_2.setWidthPercentage(100);
	
	
	Paragraph a_2 = new Paragraph("1. ",fontTableHeadingdataforML2);
	Paragraph b_2 = new Paragraph("    Ref HQ Army Training Comd letter No "+letter_no+" Sec dt 24 Jan 2022.",fontTableHeadingdataforML2);
	Paragraph c_2 = new Paragraph("2. ",fontTableHeadingdataforML2);
	Paragraph d_2 = new Paragraph("    The following amdts are hereby made in the above mentioned results :-",fontTableHeadingdataforML2);
	
	
	PdfPCell blank_cella_2;
	blank_cella_2 = new PdfPCell(a_2);
	blank_cella_2.setHorizontalAlignment(Element.ALIGN_LEFT);
	blank_cella_2.setBorder(Rectangle.NO_BORDER);
	
	PdfPCell blank_cellb_2;
	blank_cellb_2 = new PdfPCell(b_2);
	blank_cellb_2.setHorizontalAlignment(Element.ALIGN_LEFT);
	blank_cellb_2.setBorder(Rectangle.NO_BORDER);
	
	PdfPCell blank_cellc_2;
	blank_cellc_2 = new PdfPCell(c_2);
	blank_cellc_2.setHorizontalAlignment(Element.ALIGN_LEFT);
	blank_cellc_2.setBorder(Rectangle.NO_BORDER);
	
	PdfPCell blank_celld_2;
	blank_celld_2 = new PdfPCell(d_2);
	blank_celld_2.setHorizontalAlignment(Element.ALIGN_LEFT);
	blank_celld_2.setBorder(Rectangle.NO_BORDER);
	
	
	table_2.addCell(blank_cella_2);
	table_2.addCell(blank_cellb_2);
	table_2.addCell(blank_cellc_2);
	table_2.addCell(blank_celld_2);
	
	
	
	Chunk underlinec_for = new Chunk("For",
			fontTableHeadingMainHead_Ml);

	underlinec_for.setUnderline(0.1f, -2f);

	Phrase phh = new Phrase(underlinec_for);

	Paragraph cell_c = new Paragraph(phh);
	cell_c.setAlignment(Element.ALIGN_LEFT);	
	
	

	PdfPTable tabledata = new PdfPTable(12);
	tabledata.setWidths(new int[] { 4, 5, 4, 7, 5, 3, 3, 3, 3, 3, 5, 5 });
	tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	tabledata.setWidthPercentage(100);
	
	
	
	
	ArrayList<List<String>> partially_passed = (ArrayList<List<String>>) model.get("partially_passed");
	
	Paragraph a = new Paragraph("Ser No", fontTableHeadingSubMainHead);
	Paragraph b = new Paragraph("Personal No ", fontTableHeadingSubMainHead);
	Paragraph c = new Paragraph("Rank", fontTableHeadingSubMainHead);
	Paragraph d = new Paragraph("Name", fontTableHeadingSubMainHead);
	Paragraph e = new Paragraph("Arm/Service", fontTableHeadingSubMainHead);
	Paragraph f = new Paragraph("A", fontTableHeadingSubMainHead);
	Paragraph g = new Paragraph("L", fontTableHeadingSubMainHead);
	Paragraph h = new Paragraph("H", fontTableHeadingSubMainHead);
	Paragraph i = new Paragraph("C", fontTableHeadingSubMainHead);
	Paragraph j = new Paragraph("T", fontTableHeadingSubMainHead);
	Paragraph k = new Paragraph("Yet To Pass", fontTableHeadingSubMainHead);
	Paragraph l = new Paragraph("Personal No ", fontTableHeadingSubMainHead);

	tabledata.addCell(a);
	tabledata.addCell(b);
	tabledata.addCell(c);
	tabledata.addCell(d);
	tabledata.addCell(e);
	tabledata.addCell(f);
	tabledata.addCell(g);
	tabledata.addCell(h);
	tabledata.addCell(i);
	tabledata.addCell(j);
	tabledata.addCell(k);
	tabledata.addCell(l);

	// data bind

	for (int i3 = 0; i3 < partially_passed.size(); i3++) {

		List<String> l3 = partially_passed.get(i3);
		StringBuilder input1 = new StringBuilder();
		input1.append(l3.get(10));
		input1.reverse();
		Paragraph a1index = new Paragraph(old_Serno, fontTableHeadingdata);
		Paragraph a1 = new Paragraph(partially_passed.get(0).get(1), fontTableHeadingdata);
		Paragraph b1 = new Paragraph(partially_passed.get(0).get(2), fontTableHeadingdata);
		Paragraph c1 = new Paragraph(partially_passed.get(0).get(3), fontTableHeadingdata);
		Paragraph d1 = new Paragraph(partially_passed.get(0).get(4), fontTableHeadingdata);
		Paragraph e1 = new Paragraph(partially_passed.get(0).get(5), fontTableHeadingdata);
		Paragraph f1 = new Paragraph(partially_passed.get(0).get(6), fontTableHeadingdata);
		Paragraph g1 = new Paragraph(partially_passed.get(0).get(7), fontTableHeadingdata);
		Paragraph h1 = new Paragraph(partially_passed.get(0).get(8), fontTableHeadingdata);
		Paragraph i1 = new Paragraph(partially_passed.get(0).get(9), fontTableHeadingdata);
		Paragraph j1 = new Paragraph(input1.toString(), fontTableHeadingdata);
		Paragraph k1 = new Paragraph(partially_passed.get(0).get(1), fontTableHeadingdata);
		
		
		PdfPCell cell2_pp = new PdfPCell();
		
		cell2_pp.setPhrase(a1index);
		cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.addCell(cell2_pp);
		cell2_pp.setPhrase(a1);
		tabledata.addCell(cell2_pp);
		cell2_pp.setPhrase(b1);
		cell2_pp.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata.addCell(cell2_pp);
		cell2_pp.setPhrase(c1);
		tabledata.addCell(cell2_pp);
		cell2_pp.setPhrase(d1);
		tabledata.addCell(cell2_pp);
		cell2_pp.setPhrase(e1);
		cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.addCell(cell2_pp);
		cell2_pp.setPhrase(f1);
		tabledata.addCell(cell2_pp);
		cell2_pp.setPhrase(g1);

		tabledata.addCell(cell2_pp);
		cell2_pp.setPhrase(h1);
		cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.addCell(cell2_pp);
		cell2_pp.setPhrase(i1);
		cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.addCell(cell2_pp);
		cell2_pp.setPhrase(j1);
		cell2_pp.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata.addCell(cell2_pp);
		cell2_pp.setPhrase(k1);
		cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.addCell(cell2_pp);
		

	}
	
	PdfPTable tabledata3 = new PdfPTable(12);
	tabledata3.setWidths(new int[] { 4, 5, 4, 7, 5, 3, 3, 3, 3, 3, 5, 5 });
	tabledata3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	tabledata3.setWidthPercentage(100);
	if(report_name.equals("partially")) {
		
		
		
		
		ArrayList<List<String>> Lates_partially_passed = (ArrayList<List<String>>) model.get("Latest_partially_passed");
		
		Paragraph a3 = new Paragraph("Ser No", fontTableHeadingSubMainHead);
		Paragraph b3= new Paragraph("Personal No ", fontTableHeadingSubMainHead);
		Paragraph c3 = new Paragraph("Rank", fontTableHeadingSubMainHead);
		Paragraph d3 = new Paragraph("Name", fontTableHeadingSubMainHead);
		Paragraph e3 = new Paragraph("Arm/Service", fontTableHeadingSubMainHead);
		Paragraph f3 = new Paragraph("A", fontTableHeadingSubMainHead);
		Paragraph g3 = new Paragraph("L", fontTableHeadingSubMainHead);
		Paragraph h3 = new Paragraph("H", fontTableHeadingSubMainHead);
		Paragraph i3 = new Paragraph("C", fontTableHeadingSubMainHead);
		Paragraph j3 = new Paragraph("T", fontTableHeadingSubMainHead);
		Paragraph k3 = new Paragraph("Yet To Pass", fontTableHeadingSubMainHead);
		Paragraph l3 = new Paragraph("Personal No ", fontTableHeadingSubMainHead);

		tabledata3.addCell(a3);
		tabledata3.addCell(b3);
		tabledata3.addCell(c3);
		tabledata3.addCell(d3);
		tabledata3.addCell(e3);
		tabledata3.addCell(f3);
		tabledata3.addCell(g3);
		tabledata3.addCell(h3);
		tabledata3.addCell(i3);
		tabledata3.addCell(j3);
		tabledata3.addCell(k3);
		tabledata3.addCell(l3);

		// data bind

		for (int i4 = 0; i4 < Lates_partially_passed.size(); i4++) {

			List<String> l4 = Lates_partially_passed.get(i4);
			StringBuilder input1 = new StringBuilder();
			input1.append(l4.get(10));
			input1.reverse();
			Paragraph a1index = new Paragraph(old_Serno, fontTableHeadingdata);
			Paragraph a1 = new Paragraph(Lates_partially_passed.get(0).get(1), fontTableHeadingdata);
			Paragraph b1 = new Paragraph(Lates_partially_passed.get(0).get(2), fontTableHeadingdata);
			Paragraph c1 = new Paragraph(Lates_partially_passed.get(0).get(3), fontTableHeadingdata);
			Paragraph d1 = new Paragraph(Lates_partially_passed.get(0).get(4), fontTableHeadingdata);
			Paragraph e1 = new Paragraph(Lates_partially_passed.get(0).get(5), fontTableHeadingdata);
			Paragraph f1 = new Paragraph(Lates_partially_passed.get(0).get(6), fontTableHeadingdata);
			Paragraph g1 = new Paragraph(Lates_partially_passed.get(0).get(7), fontTableHeadingdata);
			Paragraph h1 = new Paragraph(Lates_partially_passed.get(0).get(8), fontTableHeadingdata);
			Paragraph i1 = new Paragraph(Lates_partially_passed.get(0).get(9), fontTableHeadingdata);
			Paragraph j1 = new Paragraph(input1.toString(), fontTableHeadingdata);
			Paragraph k1 = new Paragraph(Lates_partially_passed.get(0).get(1), fontTableHeadingdata);
			
			PdfPCell cell2_pp = new PdfPCell();
			
			cell2_pp.setPhrase(a1index);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata3.addCell(cell2_pp);
			cell2_pp.setPhrase(a1);
			tabledata3.addCell(cell2_pp);
			cell2_pp.setPhrase(b1);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata3.addCell(cell2_pp);
			cell2_pp.setPhrase(c1);
			tabledata3.addCell(cell2_pp);
			cell2_pp.setPhrase(d1);
			tabledata3.addCell(cell2_pp);
			cell2_pp.setPhrase(e1);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata3.addCell(cell2_pp);
			cell2_pp.setPhrase(f1);
			tabledata3.addCell(cell2_pp);
			cell2_pp.setPhrase(g1);

			tabledata3.addCell(cell2_pp);
			cell2_pp.setPhrase(h1);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata3.addCell(cell2_pp);
			cell2_pp.setPhrase(i1);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata3.addCell(cell2_pp);
			cell2_pp.setPhrase(j1);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata3.addCell(cell2_pp);
			cell2_pp.setPhrase(k1);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata3.addCell(cell2_pp);
			
	}
	}	 
	PdfPTable tabledata1 = new PdfPTable(5);
	tabledata1.setWidths(new int[] {2,5,5,5,5});
	tabledata1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	tabledata1.setWidthPercentage(100);
	
	ArrayList<List<String>> fully_list = (ArrayList<List<String>>) model.get("fullylist");
	
	if(report_name.equals("fully")) {
	
	Paragraph a1 = new Paragraph("Ser No",fontTableHeadingSubMainHead);
	Paragraph b1 = new Paragraph("Pers No",fontTableHeadingSubMainHead);
	Paragraph c1 = new Paragraph("Rank",fontTableHeadingSubMainHead);
	Paragraph d1 = new Paragraph("Name",fontTableHeadingSubMainHead);
	Paragraph e1= new Paragraph("Arm/Service",fontTableHeadingSubMainHead);
	
	
	
	
	 PdfPCell blank_cella;
	 blank_cella = new PdfPCell(a1);
	 blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	 PdfPCell blank_cellb;
	 blank_cellb = new PdfPCell(b1);
	 blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	 PdfPCell blank_cellc;
	 blank_cellc = new PdfPCell(c1);
	 blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
	
	 PdfPCell blank_celld;
	 blank_celld = new PdfPCell(d1);
	 blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
	 
	 PdfPCell blank_celle;
	 blank_celle = new PdfPCell(e1);
	 blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
	

	 tabledata1.addCell(blank_cella);
	 tabledata1.addCell(blank_cellb);
	 tabledata1.addCell(blank_cellc);
	 tabledata1.addCell(blank_celld);
	 tabledata1.addCell(blank_celle);
	 
	 
	 
	 
	
	


	 
	 
	 
		 
	 PdfPCell celle_fl = new PdfPCell();
	 Paragraph a1index = new Paragraph(String.valueOf(latest_Serno),fontTableHeadingdata);
	 celle_fl = new PdfPCell(a1index);
		celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
		celle_fl.setPadding(3);
		
		tabledata1.addCell(celle_fl);
		 Paragraph ic_number = new Paragraph(fully_list.get(0).get(1),fontTableHeadingdata);
		celle_fl = new PdfPCell(ic_number);
		celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
		celle_fl.setPadding(3);
		
		tabledata1.addCell(celle_fl);
		 Paragraph pers_code = new Paragraph(fully_list.get(0).get(2),fontTableHeadingdata);
		celle_fl = new PdfPCell(pers_code);
		celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
		celle_fl.setPadding(3);

			tabledata1.addCell(celle_fl);
			 Paragraph name = new Paragraph(fully_list.get(0).get(3),fontTableHeadingdata);
		celle_fl = new PdfPCell(name);
		celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
		celle_fl.setPadding(3);
		tabledata1.addCell(celle_fl);
		 Paragraph arm_service = new Paragraph(fully_list.get(0).get(4),fontTableHeadingdata);
		celle_fl = new PdfPCell(arm_service);
		 celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
			celle_fl.setPadding(3);
			
			tabledata1.addCell(celle_fl);
		 
		 
	
		
	}	 	 

	Chunk underlinec_read = new Chunk("Read",
			fontTableHeadingMainHead_Ml);

	underlinec_read.setUnderline(0.1f, -2f);

	Phrase phh_r = new Phrase(underlinec_read);

	Paragraph cell_R = new Paragraph(phh_r);
	cell_R.setAlignment(Element.ALIGN_LEFT);
		 
		 PdfPTable table_3 = new PdfPTable(2);
		 table_3.setWidths(new int[] {5,90});
		 table_3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		 table_3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		 table_3.setWidthPercentage(100);
			
			
			Paragraph a_3 = new Paragraph("3. ",fontTableHeadingdataforML2);
			Paragraph b_3 = new Paragraph("    Rest no change.",fontTableHeadingdataforML2);
			
			
			PdfPCell blank_cella_3;
			blank_cella_3 = new PdfPCell(a_3);
			blank_cella_3.setHorizontalAlignment(Element.ALIGN_LEFT);
			blank_cella_3.setBorder(Rectangle.NO_BORDER);
			
			PdfPCell blank_cellb_3;
			blank_cellb_3 = new PdfPCell(b_3);
			blank_cellb_3.setHorizontalAlignment(Element.ALIGN_LEFT);
			blank_cellb_3.setBorder(Rectangle.NO_BORDER);
			
			
			
			
			table_3.addCell(blank_cella_3);
			table_3.addCell(blank_cellb_3);
			
		 
		 
		
		 
			Paragraph footer1 = new Paragraph(
					"*Legend : C:CURRENT AFFAIRS, H:MIL HISTORY, PP:PREVIOUSLY PASSED, NP:NOW PASSED, NA:EXEMPTED", fontTableHeadingSubMainHead);
			
			
			PdfPTable tabledata_C4 = new PdfPTable(1);
			tabledata_C4.setWidths(new int[] { 4 });
			tabledata_C4.setWidthPercentage(100 / 3f);
			tabledata_C4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
			tabledata_C4.setHorizontalAlignment(Element.ALIGN_RIGHT);
			tabledata_C4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			Paragraph head_c44 = new Paragraph("("+director_name+")", fontTableHeadingSubMainHead);
			Paragraph head_c45 = new Paragraph("Col", fontTableHeadingSubMainHead);
			Paragraph head_c46 = new Paragraph("Col GS (Exams)", fontTableHeadingSubMainHead);
			Paragraph head_c47 = new Paragraph("for GoC-in-C ARTRAC", fontTableHeadingSubMainHead);

			tabledata_C4.addCell(head_c44);
			tabledata_C4.addCell(head_c45);
			tabledata_C4.addCell(head_c46);
			tabledata_C4.addCell(head_c47);

			Chunk underlinec2 = new Chunk("Copy to:-", fontTableHeadingSubMainHead);

			underlinec2.setUnderline(0.1f, -2f);

			Phrase phhc212 = new Phrase(underlinec2);
			phhc212.setFont(fontTableHeading2);

			Paragraph cell_c1222 = new Paragraph(phhc212);
			cell_c1222.setAlignment(Element.ALIGN_LEFT);
			
			
			PdfPTable tabledata_C5 = new PdfPTable(1);
			tabledata_C5.setWidths(new int[] { 4 });
			tabledata_C5.setWidthPercentage(100 / 3f);
			tabledata_C5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata_C5.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata_C5.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			Paragraph head_c = new Paragraph("Maj Gangatire Ajinkya", fontTableHeadingSubMainHead);
			Paragraph head_c12 = new Paragraph("52 RPAS FLT", fontTableHeadingSubMainHead);
			Paragraph head_c33 = new Paragraph("PIN-925452        for info", fontTableHeadingSubMainHead);
			Paragraph head_c41 = new Paragraph("C/O 56 APO", fontTableHeadingSubMainHead);
			
			Paragraph head_c42 = new Paragraph("MS-4A & B(Auto), MS-6", fontTableHeadingSubMainHead);

			
			
			tabledata_C5.addCell(head_c);
			tabledata_C5.addCell(head_c12);
			tabledata_C5.addCell(head_c33);
			tabledata_C5.addCell(head_c41);
			PdfPCell cell123_C2;
			cell123_C2 = new PdfPCell();
			cell123_C2.addElement(head_c42);
			cell123_C2.setPaddingBottom(25f);
			cell123_C2.setBorder(0);
			tabledata_C5.addCell(cell123_C2);
			
			
	PdfPCell cell123;
	cell123 = new PdfPCell();
	
	cell123.addElement(tabledata_C12);
	
	cell123.addElement(tabledata_C1);
	cell123.addElement(tabledata_C66);
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(tabledata_C2);
	cell123.addElement(tabledata_C3);
	cell123.addElement(cell_c12);
	cell123.addElement(new Paragraph("\n"));

	cell123.addElement(table_2);
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(cell_c);
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(tabledata);
	
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(cell_R);
	
	cell123.addElement(new Paragraph("\n"));
	if(report_name.equals("partially")) {
		cell123.addElement(tabledata3);
		}
	
	if(report_name.equals("fully")) {
	cell123.addElement(tabledata1);
	}
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(footer1);
	cell123.addElement(table_3);
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(tabledata_C4);
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(cell_c1222);
	cell123.addElement(new Paragraph("\n"));
	cell123.addElement(tabledata_C5);
	
	cell123.setBorder(0);
	table_c2.addCell(cell123);

	document.add(table_c2);
	super.buildPdfMetadata(model, document, request);
}
}
