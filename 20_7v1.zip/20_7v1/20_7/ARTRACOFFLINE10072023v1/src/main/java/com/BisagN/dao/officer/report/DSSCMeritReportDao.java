package com.BisagN.dao.officer.report;

import java.util.ArrayList;

public interface DSSCMeritReportDao {

	
	public ArrayList<ArrayList<String>> getMeritListforDSSC(int es_id,String course_id);
	public ArrayList<ArrayList<String>> getMeritListforALMC_ISC(int es_id,String course_id);
	public ArrayList<ArrayList<String>> getOverallReport(int es_id) ;
	public ArrayList<ArrayList<String>> getCutoffRepoerforDSSC(int es_id,String course_id);
	public ArrayList<ArrayList<String>> getALMC_ISCmeritlistReport(int es_id);
	public ArrayList<ArrayList<String>> getUpgradationRepoerforWITHDRAWALFORNOMINATION(int es_id);
	public ArrayList<ArrayList<String>> getUpgradationRepoerforRESERVETOALMCISC(int es_id);
	public ArrayList<ArrayList<String>> getUpgradationRepoerforDSTSCTODSSC(int es_id);
	public ArrayList<ArrayList<String>> getUpgradationRepoerforRESERVETODSSCDSTSC(int es_id);
	
}
