package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.PartDreports.GeneratePartDBookletController;
import com.BisagN.dao.officer.booklet.GenerateBookletDao;
import com.BisagN.dao.officer.others.ExaminationlockunlockDAO;
import com.BisagN.dao.officer.report.DSSC_DSTSC_REPORTDAO;
import com.BisagN.dao.officer.report.PartB_ReportDAO;
import com.BisagN.dao.officer.report.PartD_ReportDAO;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.DSSC_COURSE_VACANCY_RESERVE;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Generate_bookletController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	CommonController comm = new CommonController();

	@Autowired
	ExaminationlockunlockDAO exmlkunlkDao;

	@Autowired
	GenerateBookletDao genDao;
	
	
	@Autowired
	PartB_ReportDAO partbreportDao;
	
	@Autowired
	PartD_ReportDAO partDreportDao;
	
	
	@Autowired
	private DSSC_DSTSC_REPORTDAO DSSCDao;

	@RequestMapping(value = "/Generate_bookletUrl", method = RequestMethod.GET)
	public ModelAndView Generate_bookletUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		if(ec_exam_id != 0) {
		ArrayList<ArrayList<String>>list2= exmlkunlkDao.getbegindatefrmexmschedule(ec_exam_id);
		System.out.println("kkkkkk=============="+comm.getecexamnameListDDL(sessionFactory));
		Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
	    Mmap.put("msg", msg);
		
	    Mmap.put("PartB_Begindate", list2);
	    
		}
		int es_id = Integer.parseInt(
				session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		if (es_id != 0) {
			
			 Mmap.put("es_id",es_id);
				
		}
		return new ModelAndView("Generate_booklet_tiles");
	}

	@RequestMapping(value = "/getResultStatus", method = RequestMethod.POST)
	@ResponseBody public ArrayList<ArrayList<String>> getResultStatus(String es_id) {
		if(!es_id.equals("")) {
		ArrayList<ArrayList<String>> list2 = genDao.getResultStatusForExamSchedule(es_id);

		return list2;
		}
		return null;
	}

	@RequestMapping(value = "/generate_booklet", method = RequestMethod.POST)
	public ModelAndView generate_booklet(@RequestParam(value = "msg", required = false) String msg,ModelMap Mmap, HttpSession session, HttpServletRequest request,
			String typeReport, String letter_no1, String letter_date1, String director_name1,
			String exam_begin_date_rpt1, String exm_end_date1, String begin_date_id1, String btn_value1) {
		try {

			System.err.println("btn_value1======="+btn_value1);
			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();

			int es_id = Integer
					.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			if(es_id != 0) {
			
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			if(ec_exam_id != 0) {
				
				
				
				
			String es_begindate = session.getAttribute("es_begin_date") == null ? ""
					: session.getAttribute("es_begin_date").toString();

			String es_year1 = es_begindate.split("-")[0];
			String bdrpmon = exam_begin_date_rpt1.split("/")[1];
			String bdrday = exam_begin_date_rpt1.split("/")[0];
			String bedpmon = exm_end_date1.split("/")[1];
			String bedday = exam_begin_date_rpt1.split("/")[0];
			
			 String[] months = {"JAN", "FEB", "MAR", "APR" ,"MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};
			 
			 
			 String[] months2 = {"Jan", "Feb", "Mar", "Apr" ,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
			 
			 
			String pmon = months[Integer.parseInt(bdrpmon)-1];
			String emon = months[Integer.parseInt(bedpmon)-1];
			
			 
			String pmon2 = months2[Integer.parseInt(bdrpmon)-1];
			String emon2 = months2[Integer.parseInt(bedpmon)-1];
			 String letter_month=letter_date1.split("/")[1];
			 String letter_sm = months2[Integer.parseInt(letter_month)-1];
			 String letter_year=letter_date1.split("/")[2];
			 
			 
			 String letter_formate=letter_sm + "  " + letter_year;
			 
			 if(btn_value1.equals("Generate Final Booklet")){
			 String hql1 = "update EXAM_SCHEDULE set es_letter_no=:es_letter_no, es_letter_dated=:es_letter_dated,es_status_id=:es_status_id,es_authority=:es_authority where es_id=:es_id  ";
				Query query1 = sessionHQL.createQuery(hql1).setParameter("es_letter_no", letter_no1)
						.setParameter("es_letter_dated", comm.convertStringToDate(letter_date1))
						.setParameter("es_status_id", 0)
						.setParameter("es_authority", director_name1)
						.setParameter("es_id", es_id);
				query1.executeUpdate();

				tx.commit();
			 }
				
			List<OFFICER_APPLICATION_M> oappIdByEsId = comm.getOappIdbyEsID(sessionFactory, es_id);
			//System.err.println("oappIdByEsId=========="+oappIdByEsId);
			for (int i = 0; i < oappIdByEsId.size(); i++) {

				Session sessionHQL1 = this.sessionFactory.openSession();
				Transaction tx1 = sessionHQL1.beginTransaction();

				int oa_appId = oappIdByEsId.get(i).getOa_application_id();

				String hql = "update ANSWER_BOOK_M set ab_status_id=:ab_status_id  where oa_application_id=:oa_application_id and  ab_status_id=0 ";
				Query query = sessionHQL1.createQuery(hql).setParameter("ab_status_id", 1)
						.setParameter("oa_application_id", oa_appId);
				query.executeUpdate();

				tx1.commit();
				sessionHQL.close();

			}
			

			

			Mmap.put("letter_no1", letter_no1);
			Mmap.put("es_year1", es_year1);
			Mmap.put("letter_date1", letter_formate);
			Mmap.put("director_name1", director_name1);
			Mmap.put("b_month", pmon);
			Mmap.put("e_month", emon);
			
			
			Mmap.put("b_month2", pmon2);
			Mmap.put("e_month2", emon2);
			
			
			Mmap.put("bdrday", bdrday);
			Mmap.put("bedday", bedday);
			
			
			if(ec_exam_id == 1) {

			if (typeReport != null && typeReport.equals("pdfL")) {
				ArrayList<ArrayList<String>> armwiseanalysisresult = partbreportDao.getArmServiceAnalysisResultsPartB(es_id,
						es_year1);
				ArrayList<ArrayList<String>> SubjWiseAnalysis = partbreportDao.getArmsubsummaryresult(es_id);
				ArrayList<ArrayList<String>> commandwiseresult = partbreportDao.getCommandAnalysisResultsPartB(es_id,
						es_year1);

				ArrayList<ArrayList<String>> fullypassed = partbreportDao.getFullyPassedForPartB(es_id,"");
				ArrayList<ArrayList<String>> partially_passed = partbreportDao.getPartPassedandFailures(es_year1,"");

				ArrayList<ArrayList<String>> absentees = partbreportDao.PartAbsentees(es_id);

				
				
				
				Mmap.put("armwiseanalysisresult", armwiseanalysisresult);
				Mmap.put("SubjWiseAnalysis", SubjWiseAnalysis);
				Mmap.put("commandwiseresult", commandwiseresult);
				Mmap.put("fullypassed", fullypassed);
				Mmap.put("partially_passed", partially_passed);
				Mmap.put("absentees", absentees);
				 List<EXAM_CODE_M> getExamName= comm.getExamNamebyExmID( sessionFactory, 1);
				 String Exm_name= getExamName.get(0).getEc_exam_name();
				Mmap.put("Exm_name", Exm_name);
				
				if (armwiseanalysisresult.size() > 0) {
				
						
						
						
					
					List<String> TH = new ArrayList<String>();

					String Heading = "\n";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new GenerateBookletAllReport("PH", TH, Heading, username,
							armwiseanalysisresult, SubjWiseAnalysis, commandwiseresult, fullypassed, 
							partially_passed), "userList", armwiseanalysisresult);

				}
			}
			}	
				if(ec_exam_id == 2) {
					
					 List<EXAM_CODE_M> getExamNamePartD= comm.getExamNamebyExmID( sessionFactory, 2);
					 String Exm_name2= getExamNamePartD.get(0).getEc_exam_name();
					ArrayList<ArrayList<String>> armwiseanalysisresult_d = partDreportDao.getArmServiceAnalysisResultsPartD(es_id, es_year1);
				
					ArrayList<ArrayList<String>> SubjWiseAnalysis_D =partDreportDao.getArmsubsummaryresult(es_id);
					

					ArrayList<ArrayList<String>> fullypassed_D =  partDreportDao.getFullyPassedForPartD(es_id,"");
					ArrayList<ArrayList<String>> partially_passed_D =  partDreportDao.getPartPassedandFailuresForPartD(es_year1,"");

					ArrayList<ArrayList<String>> absentees_D = partDreportDao.PartAbsenteesForPartD(es_id);
					ArrayList<ArrayList<String>> resultwithheld_d = partbreportDao.getdetailsResultWithHeld(es_id,0);

					Mmap.put("armwiseanalysisresult_d", armwiseanalysisresult_d);
					Mmap.put("SubjWiseAnalysis_D", SubjWiseAnalysis_D);
					Mmap.put("fullypassed_D", fullypassed_D);
					Mmap.put("partially_passed_D", partially_passed_D);
					Mmap.put("absentees_D", absentees_D);
					Mmap.put("resultwithheld_d", resultwithheld_d);
					
					Mmap.put("Exm_name", Exm_name2);
					
					List<String> TH = new ArrayList<String>();

					String Heading = "\n";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new GeneratePartDBookletController("PH", TH, Heading, username,
							armwiseanalysisresult_d, SubjWiseAnalysis_D, fullypassed_D, partially_passed_D, 
							absentees_D,resultwithheld_d), "userList", armwiseanalysisresult_d);
				}
				
				if(ec_exam_id == 3) {
					
					int es_id1 = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
					ArrayList<ArrayList<String>> getArmwiseAnalysisReport = DSSCDao.getArmwiseAnalysisReport((es_id1));
					ArrayList<ArrayList<String>> getcompatativemeritlistReport = DSSCDao.getcompatativemeritlistReport((es_id1));
					ArrayList<ArrayList<String>> getnominateddssclistReport = DSSCDao.getnominateddssclistReport((es_id1));
					ArrayList<ArrayList<String>> getnominateddstsclistReport = DSSCDao.getnominateddstsclistReport((es_id1));
					ArrayList<ArrayList<String>> getreserveofficeristReport = DSSCDao.getreserveofficeristReport((es_id1));
					ArrayList<ArrayList<String>> getfailofficeristReport = DSSCDao.getfailofficeristReport((es_id1));
					
					ArrayList<ArrayList<String>> PartAbsenteesForDSSC_DSTSC = DSSCDao.PartAbsenteesForDSSC_DSTSC((es_id1));
					ArrayList<ArrayList<String>> getWithDrawalsDSSC = DSSCDao.getWithDrawalsDSSC((es_id1));
					
					 ArrayList<ArrayList<String>>getALMCList= DSSCDao.getALMC_ISCmeritlistReport( es_id);
					 List<DSSC_COURSE_VACANCY_RESERVE> getdsscCourseVacancyReserveList= comm.getdsscCourseVacancyReserveList( sessionFactory, es_id1);

					 
					System.err.println("PartAbsenteesForDSSC_DSTSC=="+PartAbsenteesForDSSC_DSTSC);
					System.err.println("getWithDrawalsDSSC=="+getWithDrawalsDSSC);
					Mmap.put("getArmwiseAnalysisReport", getArmwiseAnalysisReport);
					Mmap.put("getcompatativemeritlistReport", getcompatativemeritlistReport);
					Mmap.put("getnominateddssclistReport", getnominateddssclistReport);
					Mmap.put("getnominateddstsclistReport", getnominateddstsclistReport);
					Mmap.put("getreserveofficeristReport", getreserveofficeristReport);
					Mmap.put("getfailofficeristReport", getfailofficeristReport);
					Mmap.put("PartAbsenteesForDSSC_DSTSC", PartAbsenteesForDSSC_DSTSC);
					Mmap.put("getWithDrawalsDSSC", getWithDrawalsDSSC);
					
					Mmap.put("getALMCISCList", getALMCList);
					
					Mmap.put("getdsscCourseVacancyReserveListForDSSC", getdsscCourseVacancyReserveList.get(0).getDssc_course_no());
					Mmap.put("getdsscCourseVacancyReserveListForDSTSC", getdsscCourseVacancyReserveList.get(1).getDssc_course_no());
					Mmap.put("getdsscCourseVacancyReserveListForALMC", getdsscCourseVacancyReserveList.get(2).getDssc_course_no());
					Mmap.put("getdsscCourseVacancyReserveListForISC", getdsscCourseVacancyReserveList.get(3).getDssc_course_no());
					
					List<String> TH = new ArrayList<String>();

					String Heading = "\n";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new DSSC_BOOKLET_PDF_CONTROLLER("PH", TH, Heading, username), "userList", getArmwiseAnalysisReport);
				}
				
		
			}
			}
		}
		 catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("redirect:Generate_bookletUrl");
	}
	@RequestMapping(value = "/getexamScheduleDateforGenerateBooklet", method = RequestMethod.POST)
	@ResponseBody public  ArrayList<ArrayList<String>> getBeignDateForGnrtbooklet(String exm) { 
		
		ArrayList<ArrayList<String>>list2= exmlkunlkDao.getBeignDateForGnrtbooklet(exm);
	
		
		
	return list2; 
	}
}
