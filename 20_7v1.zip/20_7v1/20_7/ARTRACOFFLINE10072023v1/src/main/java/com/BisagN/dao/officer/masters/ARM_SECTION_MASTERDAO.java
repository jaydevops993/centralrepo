package com.BisagN.dao.officer.masters;

import java.util.List;
import java.util.Map;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import org.apache.commons.codec.binary.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import org.hibernate.Session;
import java.util.ArrayList;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;


public interface ARM_SECTION_MASTERDAO {

public List<Map<String, Object>> getReportListARM_SECTION_MASTER(int startPage,String pageLength,String Search,String orderColunm,String orderType,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
public long getReportListARM_SECTION_MASTERTotalCount(String Search);
public String DeleteARM_SECTION_MASTER(String deleteid,HttpSession session);
public ArrayList<ArrayList<String>> getExcelARM_SECTION_MASTER(int startPage, String pageLength, String Search,
		String orderColunm, String orderType,String table, HttpSession session)
		throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
		InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException ;
}
