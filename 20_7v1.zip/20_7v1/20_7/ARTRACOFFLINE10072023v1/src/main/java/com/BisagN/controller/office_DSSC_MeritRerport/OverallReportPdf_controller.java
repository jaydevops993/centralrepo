package com.BisagN.controller.office_DSSC_MeritRerport;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

 
import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

public class OverallReportPdf_controller extends AbstractPdfView {

	int totalRecords=0;
	
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	String exam="";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	private static final DecimalFormat decfor = new DecimalFormat("0.00");  

	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public OverallReportPdf_controller(String Type, List<String> TH, String Heading, String username ) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
		this.exam = exam;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4.rotate()); // set document landscape
		}
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();
		
		
		String dsscCourseNo = (String) model.get("getdsscCourseVacancyReserveListForDSSC");
		String dstscCourseNo = (String) model.get("getdsscCourseVacancyReserveListForDSTSC");
		String ALMCCourseNo = (String) model.get("getdsscCourseVacancyReserveListForALMC");
		String ISCCourseNo = (String) model.get("getdsscCourseVacancyReserveListForISC");
		
		

		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false,(float)7.5 , 0);
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 7, 1);
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		
	PdfPTable table6 = new PdfPTable(1);
	table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	table6.setWidthPercentage(100);


	PdfPTable tabledata6 = new PdfPTable(1);
	tabledata6.setWidths(new int[] {5});
	tabledata6.setWidthPercentage(100/ 3.5f);
	tabledata6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata6.setHorizontalAlignment(Element.ALIGN_RIGHT);
	tabledata6.getDefaultCell().setBorder(Rectangle.NO_BORDER);


	 

		Chunk underline6 = new Chunk("Overall LIST  DSSC -  "+dsscCourseNo+" /DSTSC -  "+dstscCourseNo, fontTableHeading1);
		
//		Chunk underline_m7 = new Chunk("(DSSC- " + dsscCourseNo + " & DSTSC- " + dstscCourseNo + " )", fontTableHeading2);


		underline6.setUnderline(0.1f, -2f);

	Phrase phh6 = new Phrase(underline6);

	phh6.add("\n");
	phh6.add("\n");
	phh6.setFont(fontTableHeadingSubMainHead);






	Paragraph cell61 = new Paragraph(phh6);
	cell61.setAlignment(Element.ALIGN_LEFT);


	PdfPTable tableheader6 = new PdfPTable(1);
	tableheader6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	tableheader6.setWidthPercentage(100);
	tableheader6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	tableheader6.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	tableheader6.addCell(cell61);






	 
	 PdfPTable tabledata61 = new PdfPTable(22);
		

//	 tabledata61.setWidths(new int[] {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5});
	 tabledata61.setWidths(new  float[] { 3,5,3,10,4,3,3,3,3,3,3,3,2,3,3,3,2,2,2,2,3,(float)5.5});

	 tabledata61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	 tabledata61.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
	 tabledata61.setWidthPercentage(100);
	 tabledata61.setHeaderRows(1);
 
	 
	 
	 
	 
	 Paragraph a6 = new Paragraph("SER NO",fontTableHeadingSubMainHead);//1
		Paragraph b6 = new Paragraph("PERS NO",fontTableHeadingSubMainHead);//2
		Paragraph c6 = new Paragraph("RANK",fontTableHeadingSubMainHead);//3
		Paragraph d6 = new Paragraph("NAME",fontTableHeadingSubMainHead);//4
		Paragraph e6 = new Paragraph("ARM /  SERVICE",fontTableHeadingSubMainHead);//5
		Paragraph f6 = new Paragraph("TAC A",fontTableHeadingSubMainHead);//6
		Paragraph f7 = new Paragraph("TAC B",fontTableHeadingSubMainHead);//7
		Paragraph f8 = new Paragraph("A & L",fontTableHeadingSubMainHead);	//8
		Paragraph f9 = new Paragraph("CA",fontTableHeadingSubMainHead);//9
		Paragraph f10 = new Paragraph("SMT",fontTableHeadingSubMainHead);//10
		Paragraph f11 = new Paragraph("MH",fontTableHeadingSubMainHead);//11
				
     	Paragraph g66 = new Paragraph("TOTAL",fontTableHeadingSubMainHead);
		
		Paragraph fd_mks = new Paragraph("FD",fontTableHeadingSubMainHead);//12
		Paragraph cpv_mks = new Paragraph("CPV",fontTableHeadingSubMainHead);//13
 
		
		Paragraph h66 = new Paragraph("700",fontTableHeadingSubMainHead);
 
		Paragraph j66 = new Paragraph("1000",fontTableHeadingSubMainHead);

		Paragraph ch1 = new Paragraph("CH 1",fontTableHeadingSubMainHead);//17
		Paragraph ch2 = new Paragraph("CH 2",fontTableHeadingSubMainHead);//18
		Paragraph ch3 = new Paragraph("CH 1",fontTableHeadingSubMainHead);//19
		Paragraph ch4 = new Paragraph("CH 2",fontTableHeadingSubMainHead);//20
		
		
		Paragraph f15 = new Paragraph("MERIT",fontTableHeadingSubMainHead);//21
		
		Paragraph f16 = new Paragraph("NOM FOR",fontTableHeadingSubMainHead);//22
		
		 
//		tabledata61.addCell(a6);
//		tabledata61.addCell(b6);
//		tabledata61.addCell(c6);
//		tabledata61.addCell(d6);
//		tabledata61.addCell(e6);
//		tabledata61.addCell(f6);
//		tabledata61.addCell(f7);
//		tabledata61.addCell(f8);
//		tabledata61.addCell(f9);
//		tabledata61.addCell(f10);
//		tabledata61.addCell(f11);
//		
// 	
//		tabledata61.addCell(g66);
//		tabledata61.addCell(fd_mks);
//		tabledata61.addCell(cpv_mks);
//		
//	
//		
//		tabledata61.addCell(h66);
//		tabledata61.addCell(j66);
//		 
//		tabledata61.addCell(ch1);
//		tabledata61.addCell(ch2);
//		
//		tabledata61.addCell(ch3);
//		tabledata61.addCell(ch4);
//		
//		tabledata61.addCell(f15);
//		tabledata61.addCell(f16);
//	 
		
		PdfPCell blank_cella1_C122 = new PdfPCell(a6);
		//	blank_cella1_C122.setPadding(5);
			blank_cella1_C122.setBorder(Rectangle.BOTTOM);
			blank_cella1_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cella2_C122 = new PdfPCell(b6);
			//blank_cella2_C122.setPadding(5);
			blank_cella2_C122.setBorder(Rectangle.BOTTOM);
			blank_cella2_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cella3_C122 = new PdfPCell(c6);
		//	blank_cella3_C122.setPadding(5);
			blank_cella3_C122.setBorder(Rectangle.BOTTOM);
			blank_cella3_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cella4_C122 = new PdfPCell(d6);
		//	blank_cella4_C122.setPadding(5);
			blank_cella4_C122.setBorder(Rectangle.BOTTOM);
			blank_cella4_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cella5_C122 = new PdfPCell(e6);
		 
			blank_cella5_C122.setBorder(Rectangle.BOTTOM);
			blank_cella5_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			blank_cella5_C122.setVerticalAlignment(Element.ALIGN_MIDDLE);
			
			PdfPCell blank_cella6_C122 = new PdfPCell(f6);
		//	blank_cella6_C122.setPadding(5);
			blank_cella6_C122.setBorder(Rectangle.BOTTOM);
			blank_cella6_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			
			PdfPCell blank_cella7_C122 = new PdfPCell(f7);
		//	blank_cella7_C122.setPadding(5);
			blank_cella7_C122.setBorder(Rectangle.BOTTOM);
			blank_cella7_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cella8_C122 = new PdfPCell(f8);
		//	blank_cella8_C122.setPadding(5);
			blank_cella8_C122.setBorder(Rectangle.BOTTOM);
			blank_cella8_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			
			PdfPCell blank_cella9_C122 = new PdfPCell(f9);
			//blank_cella9_C122.setPadding(5);
			blank_cella9_C122.setBorder(Rectangle.BOTTOM);
			blank_cella9_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cella10_C122 = new PdfPCell(f10);
			//blank_cella10_C122.setPadding(5);
			blank_cella10_C122.setBorder(Rectangle.BOTTOM);
			blank_cella10_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cella11_C122 = new PdfPCell(f11);
		//	blank_cella11_C122.setPadding(5);
			blank_cella11_C122.setBorder(Rectangle.BOTTOM);
			blank_cella11_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cellag66_C122 = new PdfPCell(g66);
			//blank_cellag66_C122.setPadding(5);
			blank_cellag66_C122.setBorder(Rectangle.BOTTOM);
			blank_cellag66_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cellafd_mks_C122 = new PdfPCell(fd_mks);
		//	blank_cellafd_mks_C122.setPadding(5);
			blank_cellafd_mks_C122.setBorder(Rectangle.BOTTOM);
			blank_cellafd_mks_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cellacpv_mks_C122 = new PdfPCell(cpv_mks);
		//	blank_cellacpv_mks_C122.setPadding(5);
			blank_cellacpv_mks_C122.setBorder(Rectangle.BOTTOM);
			blank_cellacpv_mks_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cellh66_C122 = new PdfPCell(h66);
			//blank_cellh66_C122.setPadding(5);
			blank_cellh66_C122.setBorder(Rectangle.BOTTOM);
			blank_cellh66_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			
			PdfPCell blank_cellj66_C122 = new PdfPCell(j66);
		//	blank_cellj66_C122.setPadding(5);
			blank_cellj66_C122.setBorder(Rectangle.BOTTOM);
			blank_cellj66_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cellch2_C122 = new PdfPCell(ch2);
		//	blank_cellch2_C122.setPadding(5);
			blank_cellch2_C122.setBorder(Rectangle.BOTTOM);
			blank_cellch2_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cellch1_C122 = new PdfPCell(ch1);
		//	blank_cellch1_C122.setPadding(5);
			blank_cellch1_C122.setBorder(Rectangle.BOTTOM);
			blank_cellch1_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cellch3_C122 = new PdfPCell(ch3);
		//	blank_cellch3_C122.setPadding(5);
			blank_cellch3_C122.setBorder(Rectangle.BOTTOM);
			blank_cellch3_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cellch4_C122 = new PdfPCell(ch4);
		//	blank_cellch4_C122.setPadding(5);
			blank_cellch4_C122.setBorder(Rectangle.BOTTOM);
			blank_cellch4_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cellf15_C122 = new PdfPCell(f15);
		//	blank_cellf15_C122.setPadding(5);
			blank_cellf15_C122.setBorder(Rectangle.BOTTOM);
			blank_cellf15_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			PdfPCell blank_cellf16_C122 = new PdfPCell(f16);
		//	blank_cellf16_C122.setPadding(5);
			blank_cellf16_C122.setBorder(Rectangle.BOTTOM);
			blank_cellf16_C122.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			
			tabledata61.addCell(blank_cella1_C122);
			tabledata61.addCell(blank_cella2_C122);
			tabledata61.addCell(blank_cella3_C122);
			tabledata61.addCell(blank_cella4_C122);
			tabledata61.addCell(blank_cella5_C122);
			tabledata61.addCell(blank_cella6_C122);
			tabledata61.addCell(blank_cella7_C122);
			tabledata61.addCell(blank_cella8_C122);
			tabledata61.addCell(blank_cella9_C122);
			tabledata61.addCell(blank_cella10_C122);
			tabledata61.addCell(blank_cella11_C122);
			
	 	
			tabledata61.addCell(blank_cellag66_C122);
			tabledata61.addCell(blank_cellafd_mks_C122);
			tabledata61.addCell(blank_cellacpv_mks_C122);
			
		
			
			tabledata61.addCell(blank_cellh66_C122);
			tabledata61.addCell(blank_cellj66_C122);
			 
			tabledata61.addCell(blank_cellch1_C122);
			tabledata61.addCell(blank_cellch2_C122);
			
			tabledata61.addCell(blank_cellch3_C122);
			tabledata61.addCell(blank_cellch4_C122);
			
			tabledata61.addCell(blank_cellf15_C122);
			tabledata61.addCell(blank_cellf16_C122);
		 
			
		
		 
		
	 
	 
	 
	 
	 
			
		ArrayList<List<String>> getfailofficeristReport = (ArrayList<List<String>>) model.get("list");
			 int  index5=1;
			 for(int i5=0;i5<getfailofficeristReport.size();i5++)
			 {
					
				 List<String> l = getfailofficeristReport.get(i5);
				 Paragraph blank1 = new Paragraph(l.get(0),fontTableHeadingdata);
					Paragraph blank2 = new Paragraph(l.get(1),fontTableHeadingdata);
					Paragraph blank3 = new Paragraph(l.get(2),fontTableHeadingdata);
					Paragraph blank4 = new Paragraph(l.get(3),fontTableHeadingdata);
					Paragraph blank5 = new Paragraph(l.get(4),fontTableHeadingdata);
					Paragraph blank6 = new Paragraph(l.get(5),fontTableHeadingdata);
					Paragraph blank7 = new Paragraph(l.get(6),fontTableHeadingdata);
					Paragraph blank8 = new Paragraph(l.get(7),fontTableHeadingdata);
					Paragraph blank9 = new Paragraph(l.get(8),fontTableHeadingdata);
					Paragraph blank10 = new Paragraph(l.get(9),fontTableHeadingdata);
					Paragraph blank11 = new Paragraph(l.get(10),fontTableHeadingdata);
					Paragraph blank12 = new Paragraph(l.get(11),fontTableHeadingdata);
					Paragraph blank13 = new Paragraph(l.get(12),fontTableHeadingdata);
					 Paragraph blank14 = new Paragraph(decfor.format(Double.parseDouble(l.get(13))),fontTableHeadingdata);

				//	Paragraph blank14 = new Paragraph(l.get(13),fontTableHeadingdata);
					//Paragraph blank15 = new Paragraph(l.get(14),fontTableHeadingdata);
					 Paragraph blank15 = new Paragraph(decfor.format(Double.parseDouble(l.get(14))),fontTableHeadingdata);

					Paragraph blank16 = new Paragraph(l.get(15),fontTableHeadingdata);
					 
					
					Paragraph blank17 = new Paragraph(l.get(16),fontTableHeadingdata);
					Paragraph blank18 = new Paragraph(l.get(17),fontTableHeadingdata);
					Paragraph blank19 = new Paragraph(l.get(18),fontTableHeadingdata);
					Paragraph blank20 = new Paragraph(l.get(19),fontTableHeadingdata);
					
					if ( l.get(16)==null) {
						 blank17 = new Paragraph("",fontTableHeadingdata);
					}
					else if ( l.get(16)=="DSSC") {
						 blank17 = new Paragraph("D",fontTableHeadingdata);
					}
					else if ( l.get(16)=="DSTSC") {
						 blank17 = new Paragraph("T",fontTableHeadingdata);
					}
					else if ( l.get(16)=="ALMC") {
						 blank17 = new Paragraph("A",fontTableHeadingdata);
					}
					else if ( l.get(16)=="ISC") {
						 blank17 = new Paragraph("I",fontTableHeadingdata);
					}
					
					
					
					Paragraph blank21 = new Paragraph(l.get(20),fontTableHeadingdata);
					Paragraph blank22 = new Paragraph(l.get(21),fontTableHeadingdata);

					PdfPCell cellar = new PdfPCell();
					
					if (i5 % 2 == 0) {
						cellar.setBackgroundColor(java.awt.Color.lightGray);
					}
					
					
					cellar.setPhrase(blank1);
					cellar.setPadding(3);
					cellar.setBorder(Rectangle.NO_BORDER);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank2);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank3);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank4);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_LEFT );
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank5);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank6);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank7);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank8);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank9);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank10);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank11);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank12);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank13);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank14);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank15);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank16);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank17);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank18);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank19);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank20);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank21);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
					
					cellar.setPhrase(blank22);
					cellar.setPadding(3);
					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
					tabledata61.addCell(cellar);
 
			 }
 			 
				
				

		 
		 
			 PageNumeration event = new PageNumeration(arg2);
				arg2.setPageEvent(event);
				document.setPageCount(1);
//				
//		PdfPCell cell12356;
//		cell12356 = new PdfPCell();
//		cell12356.addElement(tabledata6);
//		cell12356.addElement(tableheader6);
//		cell12356.addElement(tabledata61);
//		
//		cell12356.setBorder(0);
//		table6.addCell(cell12356);
//		document.add(table6);
				
				table6.setSplitLate(false);
				PdfPCell cell12356;
				cell12356 = new PdfPCell();
				cell12356.addElement(tableheader6);
//				cell12356.addElement(tabledata13);
				cell12356.setBorder(Rectangle.NO_BORDER);

				table6.addCell(cell12356);

				PdfPCell cell1235612;
				cell1235612 = new PdfPCell();
//				cell1235612.addElement(tableheader1);
				cell1235612.setBorder(Rectangle.BOX);
				cell1235612.addElement(tabledata61);
		table6.addCell(cell1235612);
		document.add(table6);
		
		
		super.buildPdfMetadata(model, document, request);
	}
	
	class PageNumeration extends PdfPageEventHelper {
		 
		PdfTemplate total;
		PdfTemplate total1;
		PdfTemplate footer1;
		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				footer1 = writer.getDirectContent().createTemplate(30, 16);

				total1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {
			// total = writer.getDirectContent().createTemplate(30, 12);
		}

		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(5);
			String ip = "";
			try {
				
				Font fontfuter = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 0);
				Font fontfuterpagenumb = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false,12, 0);
				
				
				
				table.setWidths(new int[] { 4,19,0,3,2});  
				table.setTotalWidth(document.getPageSize().getWidth() + 40 - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				Date now = new Date();
				String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
				table.addCell(new Paragraph(dateString,fontfuter));  //table.addCell("TOTAL SHEET :");
				Font fontdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 7, 0);
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(new Paragraph("C : COMPETITIVE  D : DSSC  T : DSTSC   A : ALMC I : ISC R : DSSC/DSTSC RES  S : SHORTLISTED  \n UFM : UNFAIR MEANS  ABS : ABSENT  NA : NOT APPLIED   F : FAILED" ,fontdata ));
//						String.format("C : COMPETITIVE || D : DSSC || T : DSTSC || I : ISC || T R : DSTSC RES || A : AMLC || UFM : UNFAIR MEANS || ABS : ABSENT"));
			 
				PdfPCell cell2 = new PdfPCell(Image.getInstance(total));
				cell2.setBorder(Rectangle.NO_BORDER);				
				table.addCell(cell2);
				
				PdfPCell cell1 = new PdfPCell(Image.getInstance(total1));
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			//	table.addCell(cell1);
								
			
				//String watermark = " Generated by "+username+" on "+dateString +" with IP " +ip ;
				
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(new Paragraph(String.format("Pages %d of", writer.getPageNumber()),fontfuterpagenumb));
				//table.addCell("Month :");
			 
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.NO_BORDER);	
 
				table.addCell(cell);
				
				table.writeSelectedRows(0, -1, document.leftMargin(), document.topMargin() + 0, writer.getDirectContent());
			} catch (DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT, new Phrase(String.valueOf(writer.getPageNumber() - 1)), 2, 2, 0);
			ColumnText.showTextAligned(total1, Element.ALIGN_LEFT, new Phrase(String.valueOf(totalRecords)), 2, 2, 0);
		}
		}
	
}
