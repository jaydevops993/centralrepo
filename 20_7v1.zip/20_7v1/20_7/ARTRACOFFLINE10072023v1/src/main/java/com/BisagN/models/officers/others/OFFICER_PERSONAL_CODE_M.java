package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "officer_personal_code", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class OFFICER_PERSONAL_CODE_M {

      private int id;
      private String opc_personal_code;
      private String opc_suffix_code;
      private int opd_personal_id;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date opc_effective_date;
      private int opc_status_id;
      private String opc_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date opc_creation_date;
      private String opc_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date opc_modification_date;

private String auth_letter_no;


      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public String getOpc_personal_code() {
           return opc_personal_code;
      }
      public void setOpc_personal_code(String opc_personal_code) {
	  this.opc_personal_code = opc_personal_code;
      }
      public String getOpc_suffix_code() {
           return opc_suffix_code;
      }
      public void setOpc_suffix_code(String opc_suffix_code) {
	  this.opc_suffix_code = opc_suffix_code;
      }
      public int getOpd_personal_id() {
           return opd_personal_id;
      }
      public void setOpd_personal_id(int opd_personal_id) {
	  this.opd_personal_id = opd_personal_id;
      }
      public Date getOpc_effective_date() {
           return opc_effective_date;
      }
      public void setOpc_effective_date(Date opc_effective_date) {
	  this.opc_effective_date = opc_effective_date;
      }
      public int getOpc_status_id() {
           return opc_status_id;
      }
      public void setOpc_status_id(int opc_status_id) {
	  this.opc_status_id = opc_status_id;
      }
      public String getOpc_created_by() {
           return opc_created_by;
      }
      public void setOpc_created_by(String opc_created_by) {
	  this.opc_created_by = opc_created_by;
      }
      public Date getOpc_creation_date() {
           return opc_creation_date;
      }
      public void setOpc_creation_date(Date opc_creation_date) {
	  this.opc_creation_date = opc_creation_date;
      }
      public String getOpc_modified_by() {
           return opc_modified_by;
      }
      public void setOpc_modified_by(String opc_modified_by) {
	  this.opc_modified_by = opc_modified_by;
      }
      public Date getOpc_modification_date() {
           return opc_modification_date;
      }
      public void setOpc_modification_date(Date opc_modification_date) {
	  this.opc_modification_date = opc_modification_date;
      }
	public String getAuth_letter_no() {
		return auth_letter_no;
	}
	public void setAuth_letter_no(String auth_letter_no) {
		this.auth_letter_no = auth_letter_no;
	}
      
      
      
}
