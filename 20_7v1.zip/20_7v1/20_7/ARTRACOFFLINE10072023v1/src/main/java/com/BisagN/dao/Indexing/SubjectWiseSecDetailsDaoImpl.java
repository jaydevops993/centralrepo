package com.BisagN.dao.Indexing;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;



@Service
public class SubjectWiseSecDetailsDaoImpl implements SubjectWiseSecDetailsDao {
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	public boolean checkIsIntegerValue(String Search) {
		return Search.matches("[0-9]+");
		}
	
	
	public ArrayList<ArrayList<String>> getSubwiseSecDetails(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,int esi_es_id,String subject_id,String subsubject_id,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		
		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search,subject_id);
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		String q1 = "";
		try {
			
			
			System.err.println("subsubject_id==========="+subsubject_id);
			if(!subsubject_id.equals("")) {
				q1="and sw.sub_ssd_subject_id=? ";
			}
			
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

			 q = "select DISTINCT sw.ssd_subject_id, sw.ssd_id,sc.sc_subject_name, sw.ssd_total_sections, sw.ssd_totalmarks,sum(ssw.sqd_markablequestions),sw.sub_ssd_subject_id\n"
			 		+ "from subjectwisesectiondetails sw \n"
			 		+ "left join sectionwisequestiondetails ssw on sw.ssd_id=ssw.sqd_ssd_id\n"
			 		+ "inner join subject_code sc on sw.ssd_subject_id=sc.sc_subject_id\n"
			 		+ "where sw.ssd_es_id=? and sw.ssd_subject_id=?  "+q1+"\n"
			 		+ "group by 1,2,3,4,5,7"+SearchValue+" \n"
					+ "ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage;
			
			
			
			
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, esi_es_id);
			stmt.setInt(2, Integer.parseInt(subject_id));
			if(!subsubject_id.equals("")) {
				stmt.setInt(3, Integer.parseInt(subsubject_id));
			}

			
			System.err.println("subject=============="+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("ssd_total_sections"));//0
			
				list.add(rs.getString("ssd_totalmarks"));//0
				list.add(rs.getString("sum"));//0
//				list.add(rs.getString("sqd_marksperquestion"));//0
				
				list.add(rs.getString("ssd_id"));//0
				

				
				 String enckey ="commonPwdEncKeys";
                 Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
                 String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("ssd_subject_id").toString().getBytes())));
                 String EncryptedPk2 = new String(Base64.encodeBase64( c.doFinal(rs.getString("sub_ssd_subject_id").toString().getBytes())));
                 String EncryptedPk3 = new String(Base64.encodeBase64( c.doFinal(rs.getString("ssd_id").toString().getBytes())));
                 
             	System.err.println("EncryptedPk==========="+EncryptedPk);
            	System.err.println("EncryptedPk==========="+EncryptedPk2);
                 
                 
                 String f = "";
                 String EXPORT = "onclick=\"  if (confirm('Are you sure you want to Export Excel?') ){ExportManualExcel('" + EncryptedPk
 						+ "','"+EncryptedPk2+"')}else{ return false;}\"";
 				String EXPORTButton = "<i class='action_icons action_download' " + EXPORT + " title='Edit Data'></i>";
				
 			    String update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editDataUpdate('" + EncryptedPk
 						+ "','"+EncryptedPk2+"','"+EncryptedPk3+"')}else{ return false;}\"";
 				String updateButton = "<i class='action_icons action_update' " + update + " title='Edit Data'></i>";
				
 				
				list.add(updateButton+EXPORTButton);
				
				System.err.println("list==========="+list);
				
				alist.add(list);
				
				

			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	public long getTotalCountSubwiseSecDetails(String Search,int esi_es_id,String subject_id,String subsubject_id) {

		String SearchValue = GenerateQueryWhereClause_SQL(Search,subject_id);
	int total = 0;
	String q = null;
	String q1 = "";
	Connection conn = null;
	try {
		
		if(!subsubject_id.equals("")) {
			q1="and sw.sub_ssd_subject_id=? ";
		}
		

		conn = dataSource.getConnection();
		q ="select count(*) from (select DISTINCT sw.ssd_id,sc.sc_subject_name, sw.ssd_total_sections, sw.ssd_totalmarks,sum(ssw.sqd_markablequestions)\n"
				+ "from subjectwisesectiondetails sw \n"
				+ "left join sectionwisequestiondetails ssw on sw.ssd_id=ssw.sqd_ssd_id\n"
				+ "inner join subject_code sc on sw.ssd_subject_id=sc.sc_subject_id\n"
				+ "where sw.ssd_es_id=? and sw.ssd_subject_id=? "+q1+" \n"
				+ "group by 1,2,3,4"  +SearchValue +"   ) ab " ;
		
		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereClause_SQL(stmt,Search,subject_id);
		stmt.setInt(1, esi_es_id);
		stmt.setInt(2,Integer.parseInt(subject_id));
		if(!subsubject_id.equals("")) {
			stmt.setInt(3, Integer.parseInt(subsubject_id));
		}
	
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return (long) total;
	}


	public String GenerateQueryWhereClause_SQL(String Search, String subject_id) {
		String SearchValue = "";

		try {
		
			
		

			
		
			
			
			if (!Search.equals("")) {
				Search = Search.toLowerCase();
				SearchValue = " and ( ";
				SearchValue += " lower(opc_personal_code) like ?  or lower(opd_officer_name) like ? or lower(ac_arm_description) like ?)";
						
			}
		} catch (Exception e) {
			
		}

		return SearchValue;

	}

	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,String subject_id) {
		int flag = 1;
		
	try {
		
		
			
			
		

		if(!Search.equals("")) {
			
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				
			
		}
	}catch (Exception e) {
		
	}
	return stmt;
	}

	public ArrayList<ArrayList<String>> GetSubwiseQueDetails(int es_id, int sub_id,String excel) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		String whr = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;

//			q="select DISTINCT ssd_total_sections, ssd_totalquestions, sqd.sqd_sectionno,sqd.sqd_totalquestions from subjectwisesectiondetails  ssd\n"
//					+ "left join sectionwisequestiondetails sqd on sqd.sqd_ssd_id=ssd.ssd_id\n"
//					+ " where ssd_es_id=? and ssd_subject_id=?    ";
//			
			
//			q="select DISTINCT ism.ism_indexno,sqd.sqd_sectionno, ssd.ssd_total_sections, sqd.sqd_totalquestions,ssd.ssd_totalquestions \n"
//					+ "from subjectwisesectiondetails  ssd\n"
//					+ "left join sectionwisequestiondetails sqd on sqd.sqd_ssd_id=ssd.ssd_id\n"
//					+ "left join index_slip_master ism on ism.ism_es_id=ssd.ssd_es_id and ism.ism_es_id=?\n"
//					+ " where ssd_subject_id=?  ";
			q="select ssd.ssd_id, sqd.sqd_sectionno,ssd.ssd_total_sections,sqd.sqd_totalquestions,ssd.ssd_totalquestions,sqd.sqd_marksperquestion,sqd.sqd_markablequestions,ssd.ssd_totalmarks \n" + 
					" from subjectwisesectiondetails ssd\n" + 
					" left join sectionwisequestiondetails sqd on sqd.sqd_ssd_id=ssd.ssd_id\n" + 
					" where ssd_subject_id=? and ssd_es_id=?";
			
			stmt = conn.prepareStatement(q);
			int i=1;
			stmt.setInt(1, sub_id);
			stmt.setInt(2, es_id);
			
			ResultSet rs = stmt.executeQuery();
			System.err.println("subject============"+stmt);
	
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(String.valueOf(i));//0
				list.add("");//1
					list.add(rs.getString("ssd_total_sections"));//2
					list.add(rs.getString("sqd_sectionno"));//3
					list.add(rs.getString("sqd_totalquestions"));//4
					list.add(rs.getString("ssd_totalquestions"));//5
					list.add(rs.getString("sqd_marksperquestion"));//6
					list.add(rs.getString("sqd_markablequestions"));//6
					
					int ssd_totalmarks = (rs.getInt("sqd_marksperquestion") * rs.getInt("sqd_markablequestions"));
					 
					list.add(String.valueOf(ssd_totalmarks));//6
					list.add(rs.getString("ssd_id"));//6
				alist.add(list);
				i++;
			}

			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
	public ArrayList<ArrayList<String>> GetIndexNoForExcel(int es_id, int sub_id,String excel) {

		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		
		String whr = "";

		try {

			conn = dataSource.getConnection();
			PreparedStatement stmt = null;


			q=" select * from index_slip_master  ism\n" + 
					" inner join index_slip_manual isma on ism.ism_id=isma.is_ism_id\n" + 
					" where ism_es_id=? and isma.is_sc_subject_id=?";
			
			
			stmt = conn.prepareStatement(q);
			int i=1;
		
			stmt.setInt(1, es_id);
			stmt.setInt(2, sub_id);
			ResultSet rs = stmt.executeQuery();
			System.err.println("getIndexNoforExcel============"+stmt);
	
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(String.valueOf(i));//0
				list.add(rs.getString("ism_indexno"));//1
				alist.add(list);
				i++;
			}

			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
	
 
	
}
