package com.BisagN.dao.officer.trans;

import java.math.BigInteger;
import java.util.List;

import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.models.officers.trans.Dsscaualified;

@Service
public class Process_Result_DSSC_DaoImpl implements Process_Result_DSSC_Dao {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Override
	public List getSubjectListWithCutOff(int es_id) {

		// Logic For ALl Pass Start
		Session session = this.sessionFactory.openSession();

		Transaction tx = session.beginTransaction();
		Query deletequery = session
				.createSQLQuery("DROP TABLE IF EXISTS public.tempdssc;CREATE TABLE IF NOT EXISTS public.tempdssc\n"
						+ "(\n" + "    oa_application_id integer,\n" + "    clearpassed character varying(1) \n" + ")\n"
						+ "\n" + "TABLESPACE pg_default;\n" + "\n" + "ALTER TABLE IF EXISTS public.tempdssc\n"
						+ "    OWNER to postgres;");
		deletequery.executeUpdate();
		tx.commit();

//		tx = session.beginTransaction();
//		deletequery = session.createSQLQuery("DROP TABLE IF EXISTS public.qualified_officers;\n" + "\n"
//				+ "CREATE TABLE IF NOT EXISTS public.qualified_officers\n" + "(\n" + "    oid serial NOT NULL ,\n"
//				+ "    nominatedfor character varying ,\n" + "    oa_applicant_id integer,\n"
//				+ "    course_id integer,\n" + "    CONSTRAINT qualified_officers_pkey PRIMARY KEY (oid)\n" + ")\n"
//				+ "\n" + "TABLESPACE pg_default;\n" + "\n" + "ALTER TABLE IF EXISTS public.qualified_officers\n"
//				+ "    OWNER to postgres;");
//		deletequery.executeUpdate();
//		tx.commit();

//		tx = session.beginTransaction();
//		deletequery = session.createSQLQuery("DROP TABLE IF EXISTS public.dsscaualified;\n" + "\n"
//				+ "CREATE TABLE IF NOT EXISTS public.dsscaualified\n" + "(\n" + "    did serial NOT NULL ,\n"
//				+ "    oa_applicant_id integer,\n" + "    nominatefor character varying ,\n"
//				+ "    assigned character varying ,\n" + "    grandtotal double precision,\n"
//				+ "    outof700 double precision,\n" + "    CONSTRAINT dsscaualified_pkey PRIMARY KEY (did)\n" + ")\n"
//				+ "\n" + "TABLESPACE pg_default;\n" + "\n" + "ALTER TABLE IF EXISTS public.dsscaualified\n"
//				+ "    OWNER to postgres;");
//		deletequery.executeUpdate();
//		tx.commit();

		Query que = session
				.createSQLQuery("select es.es_id,esd.sc_subject_id,esd.esd_final_cutoff_dssc  from exam_schedule es\n"
						+ "inner join exam_schedule_detail esd ON esd.es_id = es.es_id\n" + "where es.es_id=" + es_id);
		List list = que.list();
		String query = "select ab.oa_application_id,'Y' \n"
				+ " from officer_application ofa inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
				+ "where ofa.es_id=" + es_id + " \n" + "and";
		String append_q = "";
		int count = 1;
		String queryfortemptable1 = "";
		String queryfortemptable2 = "";
		String queryfortemptable3 = "";
		tx = session.beginTransaction();
		Query createtablequery1 = session
				.createSQLQuery("Drop table if exists temp1; CREATE TABLE IF NOT EXISTS public.temp1 " + "(\n"
						+ "    officer_no integer )");
		createtablequery1.executeUpdate();
		tx.commit();

		for (int i = 0; i < list.size(); i++) {
			Object[] obj = (Object[]) list.get(i);
			if (i == 0) {
				query += " case ";
				append_q += " case";
				queryfortemptable1 += "select A" + count + ".oa_application_id,A" + count + ".marks ,";
				queryfortemptable2 += " from sub" + count + " A" + count + ",";
				queryfortemptable3 += " where ";

			}
			query += "  when sc_subject_id =" + obj[1] + " then ab_marks_obtained >= " + obj[2];
			append_q += "  when sc_subject_id =" + obj[1] + " then ab_marks_obtained >= " + obj[2];
			if (i == list.size() - 1) {
				query += " end ";
				append_q += " end ";
			}
			tx = session.beginTransaction();
			Query createtablequery = session.createSQLQuery("DROP TABLE IF EXISTS public.sub" + count
					+ ";CREATE TABLE IF NOT EXISTS public.sub" + count + "\n" + "(\n" + "    sid serial NOT NULL,\n"
					+ "    OA_APPLICATION_ID integer,\n" + "    marks integer,\n" + "    CONSTRAINT sub" + count
					+ "_pkey PRIMARY KEY (sid)\n" + ")");
			createtablequery.executeUpdate();
			tx.commit();

			tx = session.beginTransaction();

			Query inserttablequery = session
					.createSQLQuery("insert into sub" + count + "(marks,OA_APPLICATION_ID)         \n"
							+ " select ab_marks_obtained,ab.OA_APPLICATION_ID from answer_book ab\n"
							+ "inner join officer_application ofa on ofa.oa_application_id = ab.oa_application_id \n"
							+ "where ofa.es_id=" + es_id + " and sc_subject_id=" + obj[1]
							+ "  order by ab_marks_obtained desc");
			System.err.println("inserttablequery.executeUpdate()" + inserttablequery.executeUpdate());
			tx.commit();

			tx = session.beginTransaction();
			Query altertablequery = session.createSQLQuery(
					"ALTER TABLE IF EXISTS public.temp1\n" + "    ADD Column sub" + count + "  integer;");
			altertablequery.executeUpdate();
			tx.commit();

			if (i == list.size() - 1) {

				tx = session.beginTransaction();
				altertablequery = session.createSQLQuery("ALTER TABLE IF EXISTS public.temp1\n"
						+ "    ADD Column assigned  integer;ALTER TABLE IF EXISTS public.temp1 ADD Column es_id  integer;");
				altertablequery.executeUpdate();
				tx.commit();

				queryfortemptable1 += " A" + count + ".marks,0," + es_id + "";
				queryfortemptable2 += "  sub" + count + " A" + count + "";
				queryfortemptable3 += "A1.oa_application_id = A" + count + ".oa_application_id";

			} else {
				if (i != 0) {
					queryfortemptable1 += " A" + count + ".marks ,";
					queryfortemptable2 += "  sub" + count + " A" + count + ",";
					queryfortemptable3 += "A1.oa_application_id = A" + count + ".oa_application_id and ";
				}
			}

			count++;
		}

		query += " group by 1 having count(*) = " + list.size() + "\n" + "order by 1";
		System.out.println("query" + query);

		int dividedby = list.size() * 500;

		tx = session.beginTransaction();
		String query2 = "insert into tempdssc " + query;
		Query querylist = session.createSQLQuery(query2);
		querylist.executeUpdate();
		tx.commit();

		System.err.println("Temp Insert Query =======" + queryfortemptable1 + queryfortemptable2 + queryfortemptable3);
		String querytemp1 = queryfortemptable1 + queryfortemptable2 + queryfortemptable3;

		tx = session.beginTransaction();
		Query insert_temp_query = session.createSQLQuery("insert into temp1 " + querytemp1);
		insert_temp_query.executeUpdate();
		tx.commit();
		tx = session.beginTransaction();

		que = session.createSQLQuery(
				"INSERT INTO dsscaualified(oa_applicant_id,grandtotal,outof700,es_id)  SELECT A.oa_application_id   ,ROUND(A.marks_obtained,2),ROUND(A.outof700,2) ,"
						+ es_id + "  \n" + "FROM    \n" + "(select distinct(ab.oa_application_id),\n"
						+ "cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby
						+ " +coalesce(c.cpv_mks,0)+coalesce(c.fd_service_mks,0) as marks_obtained\n"
						+ ",cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby + " as outof700\n"
						+ "\n"
						+ " from officer_application ofa inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
						+ " inner join cpv c on c.oa_application_id = ab.oa_application_id\n" + " where \n"
						+ "ofa.es_id=" + es_id + "  \n" + "and " + append_q + " \n"
						+ "and ab.oa_application_id in (SELECT oa_application_id FROM tempdssc WHERE clearpassed IS NOT NULL )\n"
						+ "and ab.oa_application_id not in (select oa_applicant_id from dsscaualified)\n"
						+ "group by ab.oa_application_id,c.cpv_mks,c.fd_service_mks having count(*) = " + list.size()
						+ " ) A \n" + "ORDER BY ROUND(A.marks_obtained ,2) DESC, ROUND(A.outof700,2)  desc");

		int inserted = que.executeUpdate();
		tx.commit();

		// Seat Assign

		que = session.createQuery("From Dsscaualified where assigned is null order by did");
		List<Dsscaualified> dsscqual_list = que.list();
		int rankinc = 0;
		int countmerit = 1;
		for (Dsscaualified dsscaualified : dsscqual_list) {

			Query qual_off = session.createSQLQuery("select oa_application_id,course_applied,course_preference \n"
					+ "from dssc_tsoc_application t inner join dssc_choice_tbl c on c.dscc_app_id = t.id\n"
					+ "and t.oa_application_id  = " + dsscaualified.getOaApplicantId() + " order by course_preference");
			List qual_off_list = qual_off.list();

			outerloop: for (int i = 0; i < qual_off_list.size(); i++) {
				Object[] obj = (Object[]) qual_off_list.get(i);

				Query fullvac = session
						.createSQLQuery("select count(*) from qualified_officers where course_id = " + obj[1] + "");
				BigInteger fullvac_count = (BigInteger) fullvac.uniqueResult();

				Query vacant_vac = session.createSQLQuery(
						"select total_vacancy,case when sub_course = 'Res' then concat(name,' ',sub_course) else sub_course end from (select total_vacancy,case when (sub_course is null or sub_course = '')  then c.name else sub_course end,name from dssc_merit_result_gen_tbl d\n"
								+ "inner join course_master c on d.course_id = c.choice_id\n"
								+ "where (division  ='N' or division is null )\n" + "and course_id = " + obj[1]
								+ " order by priority_result)A");

				List obj_vacant = vacant_vac.list();

				for (int j = 0; j < obj_vacant.size(); j++) {
					Object[] obje = (Object[]) obj_vacant.get(j);
					int total_vac = (int) obje[0];
					String course_name = (String) obje[1];

					if (fullvac_count.intValue() < total_vac) {
						tx = session.beginTransaction();
						Query insert_qual = session.createSQLQuery(
								"insert into qualified_officers(nominatedfor,oa_applicant_id,course_id,meritid,es_id,status_id) values('"
										+ course_name + "'," + obj[0] + "," + obj[1] + "," + countmerit + "," + es_id
										+ ",1)");
						insert_qual.executeUpdate();
						tx.commit();
						rankinc = rankinc + 1;
						tx = session.beginTransaction();
						insert_qual = session.createSQLQuery(
								"update temp1 set assigned = " + rankinc + " where officer_no = " + obj[0]);
						insert_qual.executeUpdate();
						tx.commit();

						tx = session.beginTransaction();
						insert_qual = session.createSQLQuery(
								"update dsscaualified set assigned = 'YES' where oa_applicant_id = " + obj[0]);
						insert_qual.executeUpdate();
						tx.commit();

						countmerit++;

						break outerloop;
					}

				}

			}

		}

		// Logic For All PAss End

		// Logic For DSSC ,DSTSC

		que = session.createSQLQuery(
				"select * from (select sum(total_vacancy),priority_merit from dssc_merit_result_gen_tbl where division = 'N' or division is null\n"
						+ "and es_id = " + es_id + " group by priority_merit)A where sum >0");
		List meritlist = que.list();

		int vac = 0;

		for (int i = 0; i < meritlist.size() - 1; i++) {

			Object[] obj = (Object[]) meritlist.get(i);

			int vacancy = Integer.parseInt(obj[0].toString());
			vac = vac + vacancy;

			vacancy = vac;
			que = session.createSQLQuery("select count(oa_applicant_id) from qualified_officers");

			BigInteger ib = (BigInteger) que.uniqueResult();
			int allpassed = ib.intValue();
			int topid = vacancy;
			long candidate = 0;

			System.err.println("==================================================================================");
			System.err.println("Vacancy -->" + vacancy + " All PAss " + allpassed);
			System.err.println("==================================================================================");

			breakloop: while (candidate < vacancy - allpassed) {
				int jcount[] = new int[list.size()];
				int coutforsub = 1;
				for (int j = 0; j < list.size(); j++) {
					Query que2 = session.createSQLQuery("select marks from Sub" + coutforsub + " where sid = " + topid);

					int marks = (int) que2.uniqueResult();
					if (marks > 200) {
						jcount[j] = 200;
					} else {
						jcount[j] = (int) que2.uniqueResult();
					}
					coutforsub++;
				}
				que = session.createSQLQuery(
						"select count(*) from temp1 where assigned != 0 and   \n" + " ES_ID=" + es_id + "");
				BigInteger rowcountbig = (BigInteger) que.uniqueResult();

				if (rowcountbig.intValue() <= 0) {
					break breakloop;
				}

				int subinc = 1;
				String countquery = "select count(*) from temp1 where ";
				for (int k = 0; k < list.size(); k++) {
					if (k == 0) {
						countquery += " sub" + subinc + " >= " + jcount[k] + " ";
					} else {
						countquery += " and  sub" + subinc + " >= " + jcount[k] + " ";
					}
					subinc++;
				}

				que = session.createSQLQuery(countquery + " and assigned = 0 and es_id = " + es_id + "");
				BigInteger caBigInteger = (BigInteger) que.uniqueResult();
				candidate = caBigInteger.intValue();
				topid = topid + 20;

			}

			topid = topid - 40;
			candidate = 0;
			int rank = 1;

			breakloop: while (candidate < vacancy) {
				int coutforsub = 1;
				int jcount[] = new int[list.size()];
				for (int j = 0; j < list.size(); j++) {
					que = session.createSQLQuery("select marks from Sub" + coutforsub + " where sid = " + topid);
					jcount[j] = (int) que.uniqueResult();
					coutforsub++;
				}
				que = session.createSQLQuery(
						"select count(*) from temp1 where assigned != 0 and   \n" + " ES_ID=" + es_id + "");
				BigInteger rowcountbig = (BigInteger) que.uniqueResult();

				if (rowcountbig.intValue() <= 0) {
					break breakloop;
				}
				candidate = rowcountbig.intValue();
				int subinc = 1;
				String countquery = "select distinct officer_no,null from temp1 t inner join dssc_tsoc_application d on t.officer_no = d.oa_application_id\n"
						+ "inner join dssc_choice_tbl dc on dc.dscc_app_id =d.id where ";
				for (int k = 0; k < list.size(); k++) {
					if (k == 0) {
						countquery += " sub" + subinc + " >= " + jcount[k] + " ";
					} else {
						countquery += " and  sub" + subinc + " >= " + jcount[k] + " ";
					}
					subinc++;
				}

				countquery += "and assigned = 0 and t.es_id = " + es_id
						+ "  and dc.course_applied in (select distinct(course_id) from dssc_merit_result_gen_tbl where (division = 'N' or division is null) and  priority_merit = "
						+ obj[1] + ") ";
				Query wu = session.createSQLQuery(countquery);

				List newlist = wu.list();
				if (newlist != null) {
					if (!newlist.isEmpty()) {
						for (int l = 0; l < newlist.size(); l++) {
							Object[] officermerit = (Object[]) newlist.get(l);

							que = session.createSQLQuery("select max(assigned)+1 from temp1");
							int maxrank = (int) que.uniqueResult();

							if (maxrank > vacancy) {
								break breakloop;
							}

							tx = session.beginTransaction();
							Query updatetemp1 = session.createSQLQuery("update temp1 set assigned = " + maxrank
									+ " where officer_no = " + officermerit[0] + "");
							updatetemp1.executeUpdate();
							tx.commit();
							tx = session.beginTransaction();
							Query que1 = session
									.createSQLQuery("insert into tempdssc values (" + officermerit[0] + ")");
							que1.executeUpdate();
							tx.commit();

						}
					}
				}

				topid = topid + 2;
			}

			tx = session.beginTransaction();
			que = session.createSQLQuery(
					"INSERT INTO dsscaualified(oa_applicant_id,grandtotal,outof700,es_id)  SELECT A.oa_application_id   ,ROUND(A.marks_obtained,2),ROUND(A.outof700,2),"+es_id+"   \n"
							+ "FROM    \n" + "(select distinct(ab.oa_application_id),\n"
							+ "cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby
							+ " +coalesce(c.cpv_mks,0)+coalesce(c.fd_service_mks,0) as marks_obtained\n"
							+ ",cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby
							+ " as outof700\n" + "\n"
							+ " from officer_application ofa inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
							+ " inner join cpv c on c.oa_application_id = ab.oa_application_id\n" + " where \n"
							+ "ofa.es_id=" + es_id + "  \n"
							+ "and ab.oa_application_id in (SELECT oa_application_id FROM tempdssc WHERE clearpassed IS NULL )\n"
							+ "and ab.oa_application_id not in (select oa_applicant_id from dsscaualified)\n"
							+ "group by ab.oa_application_id,c.cpv_mks,c.fd_service_mks having count(*) = "
							+ list.size() + " ) A \n"
							+ "ORDER BY ROUND(A.marks_obtained ,2) DESC, ROUND(A.outof700,2)  desc");
			int insertednew = que.executeUpdate();
			tx.commit();

			que = session.createQuery("From Dsscaualified where assigned is null order by did");
			dsscqual_list = que.list();

			for (Dsscaualified dsscaualified : dsscqual_list) {

				Query res = session.createSQLQuery("select *,\n"
						+ "(select count(*) from qualified_officers where course_id = course_applied and nominatedfor = sub_course)  as full_vacancy\n"
						+ "from (select a.oa_application_id,a.course_applied,a.course_preference,d.total_vacancy ,d.priority_result,\n"
						+ "case when (d.sub_course is null or d.sub_course = '') then name else case when sub_course = 'Res' then concat(name,' ',sub_course) else sub_course end end,\n"
						+ "d.priority_merit from \n"
						+ "(select oa_application_id,course_applied,course_preference,name from  dssc_tsoc_application t1 \n"
						+ "inner join dssc_choice_tbl c1 on c1.dscc_app_id = t1.id\n"
						+ "inner join course_master c on c.choice_id = c1.course_applied\n"
						+ "where oa_application_id = " + dsscaualified.getOaApplicantId() + " \n"
						+ "order by course_preference) a\n"
						+ "inner join dssc_merit_result_gen_tbl d on d.course_id = a.course_applied\n"
						+ "where (division is null or division = 'N')\n"
						+ "order by priority_merit,priority_result,course_preference)A");
				List reslist = res.list();
				outerloop1: for (int j = 0; j < reslist.size(); j++) {
					Object[] resobj = (Object[]) reslist.get(j);
					int oa_application_id = (int) resobj[0];
					int course_applied = (int) resobj[1];
					// int course_preference = (int) resobj[2];
					int total_vacancy = (int) resobj[3];
					String sub_course = (String) resobj[5];
					BigInteger full_vacancy = (BigInteger) resobj[7];

					if (full_vacancy.intValue() < total_vacancy) {
						tx = session.beginTransaction();
						Query insert_qual = session.createSQLQuery(
								"insert into qualified_officers(nominatedfor,oa_applicant_id,course_id,meritid,es_id,status_id) values('"
										+ sub_course + "'," + oa_application_id + "," + course_applied + ","+countmerit+","+es_id+",1)");
						insert_qual.executeUpdate();
						tx.commit();

						tx = session.beginTransaction();
						insert_qual = session
								.createSQLQuery("update dsscaualified set assigned = 'YES' where oa_applicant_id = "
										+ oa_application_id);
						insert_qual.executeUpdate();
						tx.commit();
						countmerit++;

						break outerloop1;
					}

				}

			}
//
		}
		////////////////////

		//////////////////// Logic For ALMC/ISC

		que = session.createSQLQuery(
				"select * from (select sum(total_vacancy),priority_merit from dssc_merit_result_gen_tbl where division = 'N' or division is null\n"
						+ "and es_id = " + es_id
						+ " group by priority_merit)A where sum >0 order by priority_merit desc limit 1");
		meritlist = que.list();

		vac = 0;

		for (int i = 0; i < meritlist.size(); i++) {

			Object[] obj = (Object[]) meritlist.get(i);

			que = session.createSQLQuery("select count(oa_applicant_id) from qualified_officers");

			BigInteger ib = (BigInteger) que.uniqueResult();
			int allpassed = ib.intValue();
			vac = allpassed;

			int vacancy = Integer.parseInt(obj[0].toString());
			int vac1 = vacancy;
			vac = vac + vacancy;

			vacancy = vac;

			int topid = vacancy;
			long candidate = 0;

			System.err.println("==================================================================================");
			System.err.println("Vacancy -->" + vacancy + " All PAss " + allpassed);
			System.err.println("==================================================================================");

			breakloop: while (candidate < vacancy - allpassed) {
				int jcount[] = new int[list.size()];
				int coutforsub = 1;
				for (int j = 0; j < list.size(); j++) {
					Query que2 = session.createSQLQuery("select marks from Sub" + coutforsub + " where sid = " + topid);

					int marks = (int) que2.uniqueResult();
					if (marks > 200) {
						jcount[j] = 200;
					} else {
						jcount[j] = (int) que2.uniqueResult();
					}
					coutforsub++;
				}
				que = session.createSQLQuery(
						"select count(*) from temp1 where assigned != 0 and   \n" + " ES_ID=" + es_id + "");
				BigInteger rowcountbig = (BigInteger) que.uniqueResult();

				if (rowcountbig.intValue() <= 0) {
					break breakloop;
				}

				int subinc = 1;
				String countquery = "select count(*) from temp1 where ";
				for (int k = 0; k < list.size(); k++) {
					if (k == 0) {
						countquery += " sub" + subinc + " >= " + jcount[k] + " ";
					} else {
						countquery += " and  sub" + subinc + " >= " + jcount[k] + " ";
					}
					subinc++;
				}

				que = session.createSQLQuery(countquery + " and assigned = 0 and es_id = " + es_id + "");
				BigInteger caBigInteger = (BigInteger) que.uniqueResult();
				candidate = caBigInteger.intValue();
				topid = topid + 20;

			}

			topid = topid - 40;
			candidate = 0;
			int rank = 1;
			int maxrankcount = 0;
			int newcount = 0;
			breakloop: while (maxrankcount < vac1) {
				int coutforsub = 1;
				int jcount[] = new int[list.size()];
				for (int j = 0; j < list.size(); j++) {
					que = session.createSQLQuery("select marks from Sub" + coutforsub + " where sid = " + topid);
					jcount[j] = (int) que.uniqueResult();
					coutforsub++;
				}
				que = session.createSQLQuery(
						"select count(*) from temp1 where assigned != 0 and   \n" + " ES_ID=" + es_id + "");
				BigInteger rowcountbig = (BigInteger) que.uniqueResult();

				if (rowcountbig.intValue() <= 0) {
					break breakloop;
				}
				candidate = rowcountbig.intValue();
				int subinc = 1;
				String countquery = "select distinct officer_no,null from temp1 t inner join dssc_tsoc_application d on t.officer_no = d.oa_application_id\n"
						+ "inner join dssc_choice_tbl dc on dc.dscc_app_id =d.id where ";
				for (int k = 0; k < list.size(); k++) {
					if (k == 0) {
						countquery += " sub" + subinc + " >= " + jcount[k] + " ";
					} else {
						countquery += " and  sub" + subinc + " >= " + jcount[k] + " ";
					}
					subinc++;
				}

				countquery += "and assigned = 0 and t.es_id = " + es_id;
//						+ "  and dc.course_applied in (select distinct(course_id) from dssc_merit_result_gen_tbl where (division = 'N' or division is null) and  priority_merit = "
//						+ obj[1] + ") ";
				Query wu = session.createSQLQuery(countquery);

				List newlist = wu.list();

				int subinc1 = 1;
				String countquery1 = "select distinct officer_no,null from temp1 t inner join dssc_tsoc_application d on t.officer_no = d.oa_application_id\n"
						+ "inner join dssc_choice_tbl dc on dc.dscc_app_id =d.id where ";
				for (int k = 0; k < list.size(); k++) {
					if (k == 0) {
						countquery1 += " sub" + subinc1 + " >= " + jcount[k] + " ";
					} else {
						countquery1 += " and  sub" + subinc1 + " >= " + jcount[k] + " ";
					}
					subinc1++;
				}

				countquery1 += "and assigned = 0 and t.es_id = " + es_id
						+ "  and dc.course_applied in (select distinct(course_id) from dssc_merit_result_gen_tbl where (division = 'N' or division is null) and  priority_merit = "
						+ obj[1] + ") ";
				Query wu1 = session.createSQLQuery(countquery1);
				
				System.out.println("countquery1 --------------->"+countquery1);
				
				maxrankcount += wu1.list().size();
				
				 

				if (newlist != null) {
					if (!newlist.isEmpty()) {
						for (int l = 0; l < newlist.size(); l++) {
							Object[] officermerit = (Object[]) newlist.get(l);

							que = session.createSQLQuery("select max(assigned)+1 from temp1");
							int maxrank = (int) que.uniqueResult();
							tx = session.beginTransaction();
							Query updatetemp1 = session.createSQLQuery("update temp1 set assigned = " + maxrank
									+ " where officer_no = " + officermerit[0] + "");
							updatetemp1.executeUpdate();
							tx.commit();
							tx = session.beginTransaction();
							Query que1 = session
									.createSQLQuery("insert into tempdssc values (" + officermerit[0] + ")");
							que1.executeUpdate();
							tx.commit();
							
							
							Query qued = session.createSQLQuery("select count(*) from temp1 t inner join dssc_tsoc_application d on t.officer_no = d.oa_application_id\n"
									+ "inner join dssc_choice_tbl dc on dc.dscc_app_id =d.id where assigned = 0 and t.es_id = " + es_id+" and dc.course_applied in (select distinct(course_id) from dssc_merit_result_gen_tbl where (division = 'N' or division is null) and  priority_merit = \n"
																+ obj[1] + ") and d.oa_application_id = "+officermerit[0]+"");
							
							BigInteger councheck =  (BigInteger) qued.uniqueResult();
							
							if(councheck.intValue() > 0) {
								newcount = newcount+1;
							}
							
							if (newcount > vac1
									) {
								break breakloop;
							}
							
							
							
							
							
							
							

							

						}
					}
				}

				topid = topid + 2;
			}

			tx = session.beginTransaction();
			que = session.createSQLQuery(
					"INSERT INTO dsscaualified(oa_applicant_id,grandtotal,outof700,es_id)  SELECT A.oa_application_id   ,ROUND(A.marks_obtained,2),ROUND(A.outof700,2),"+es_id+"   \n"
							+ "FROM    \n" + "(select distinct(ab.oa_application_id),\n"
							+ "cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby
							+ " +coalesce(c.cpv_mks,0)+coalesce(c.fd_service_mks,0) as marks_obtained\n"
							+ ",cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby
							+ " as outof700\n" + "\n"
							+ " from officer_application ofa inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
							+ " inner join cpv c on c.oa_application_id = ab.oa_application_id\n" + " where \n"
							+ "ofa.es_id=" + es_id + "  \n"
							+ "and ab.oa_application_id in (SELECT oa_application_id FROM tempdssc WHERE clearpassed IS NULL )\n"
							+ "and ab.oa_application_id not in (select oa_applicant_id from dsscaualified)\n"
							+ "group by ab.oa_application_id,c.cpv_mks,c.fd_service_mks having count(*) = "
							+ list.size() + " ) A \n"
							+ "ORDER BY ROUND(A.marks_obtained ,2) DESC, ROUND(A.outof700,2)  desc");
			int insertednew = que.executeUpdate();
			tx.commit();

			que = session.createQuery("From Dsscaualified where assigned is null order by did");
			dsscqual_list = que.list();

			for (Dsscaualified dsscaualified : dsscqual_list) {

				Query res = session.createSQLQuery("select *,\n"
						+ "(select count(*) from qualified_officers where course_id = course_applied and nominatedfor = sub_course)  as full_vacancy\n"
						+ "from (select a.oa_application_id,a.course_applied,a.course_preference,d.total_vacancy ,d.priority_result,\n"
						+ "case when (d.sub_course is null or d.sub_course = '') then name else case when sub_course = 'Res' then concat(name,' ',sub_course) else sub_course end end,\n"
						+ "d.priority_merit from \n"
						+ "(select oa_application_id,course_applied,course_preference,name from  dssc_tsoc_application t1 \n"
						+ "inner join dssc_choice_tbl c1 on c1.dscc_app_id = t1.id\n"
						+ "inner join course_master c on c.choice_id = c1.course_applied\n"
						+ "where oa_application_id = " + dsscaualified.getOaApplicantId() + " \n"
						+ "order by course_preference) a\n"
						+ "inner join dssc_merit_result_gen_tbl d on d.course_id = a.course_applied\n"
						+ "where (division is null or division = 'N')\n"
						+ "order by priority_merit,priority_result,course_preference)A");
				List reslist = res.list();

				boolean assigned = false;
				int oa_application_id = 0;
				outerloop1: for (int j = 0; j < reslist.size(); j++) {
					Object[] resobj = (Object[]) reslist.get(j);
					oa_application_id = (int) resobj[0];
					int course_applied = (int) resobj[1];
					// int course_preference = (int) resobj[2];
					int total_vacancy = (int) resobj[3];
					String sub_course = (String) resobj[5];
					BigInteger full_vacancy = (BigInteger) resobj[7];

					if (full_vacancy.intValue() < total_vacancy) {
						tx = session.beginTransaction();
						Query insert_qual = session.createSQLQuery(
								"insert into qualified_officers(nominatedfor,oa_applicant_id,course_id,meritid,es_id,status_id) values('"
										+ sub_course + "'," + oa_application_id + "," + course_applied + ","+countmerit+","+es_id+",1)");
						insert_qual.executeUpdate();
						tx.commit();

						tx = session.beginTransaction();
						insert_qual = session
								.createSQLQuery("update dsscaualified set assigned = 'YES' where oa_applicant_id = "
										+ oa_application_id);
						insert_qual.executeUpdate();
						tx.commit();
						assigned = true;
						countmerit++;

						break outerloop1;
					}

				}

				if (assigned == false) {
					
					
					
					Query countque = session.createSQLQuery(
							"select count(*) from qualified_officers where course_id != 0 and es_id = " + es_id);
					BigInteger countq = (BigInteger) countque.uniqueResult();

					Query totalcountque = session.createSQLQuery(
							"select sum(total_vacancy)  from dssc_merit_result_gen_tbl where division = 'N' or division is null \n"
									+ "	and es_id = " + es_id);
					BigInteger totalcountq = (BigInteger) totalcountque.uniqueResult();

					if (countq.intValue() < totalcountq.intValue()) {
					tx = session.beginTransaction();
					Query insert_qual = session.createSQLQuery(
							"insert into qualified_officers(nominatedfor,oa_applicant_id,course_id,meritid,es_id,status_id) values('Fail',"
									+ oa_application_id + ",0,"+countmerit+","+es_id+",1)");
					insert_qual.executeUpdate();
					tx.commit();

					tx = session.beginTransaction();
					insert_qual = session.createSQLQuery(
							"update dsscaualified set assigned = 'YES' where oa_applicant_id = " + oa_application_id);
					insert_qual.executeUpdate();
					tx.commit();
					assigned = true;
					countmerit++;
					}

					// break outerloop1;
				}

			}
			//
		}

		session.close();

		return list;

	}

	@Override
	public void generateMerit(String[] cols) {

		Transaction tx = null;
		Query que = null;
		System.out.println("Coulmn 4= " + cols[0] + " , Column 5=" + cols[11] + ", column 12 " + cols[12]
				+ " ,column 16 " + cols[16] + " , column 17 " + cols[17]);
		Session session = this.sessionFactory.openSession();

		int appid = (int) session
				.createSQLQuery("select id from dssc_tsoc_application where oa_application_id =  " + cols[0])
				.uniqueResult();

		if (cols[11].toString().equalsIgnoreCase("BOTH")) {

			if (cols[12].equalsIgnoreCase("DSSC")) {

				tx = session.beginTransaction();

				que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
						+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
						+ ", 171, 5, 1)");

				que.executeUpdate();
				tx.commit();

				tx = session.beginTransaction();

				que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
						+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
						+ ", 171, 6, 2)");

				que.executeUpdate();
				tx.commit();

			} else {

				tx = session.beginTransaction();

				que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
						+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
						+ ", 171, 6, 1)");

				que.executeUpdate();
				tx.commit();

				tx = session.beginTransaction();

				que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
						+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
						+ ", 171, 5, 2)");

				que.executeUpdate();
				tx.commit();
			}

			if (!cols[16].equalsIgnoreCase("NONE")) {

				if (cols[16].toString().equalsIgnoreCase("ALMC")) {

					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 8, 3)");

					que.executeUpdate();
					tx.commit();

					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 13, 4)");

					que.executeUpdate();
					tx.commit();

				} else {
					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 13, 3)");

					que.executeUpdate();
					tx.commit();

					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 8, 4)");

					que.executeUpdate();
					tx.commit();
				}

			}

		} else if (cols[11].toString().equalsIgnoreCase("DSSC")) {

			tx = session.beginTransaction();

			que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
					+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
					+ ", 171, 5, 1)");

			que.executeUpdate();
			tx.commit();

			if (!cols[16].equalsIgnoreCase("NONE")) {

				if (cols[16].toString().equalsIgnoreCase("ALMC")) {

					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 8, 2)");

					que.executeUpdate();
					tx.commit();

					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 13, 3)");

					que.executeUpdate();
					tx.commit();

				} else {
					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 13, 2)");

					que.executeUpdate();
					tx.commit();

					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 8, 3)");

					que.executeUpdate();
					tx.commit();
				}

			}

		} else if (cols[11].toString().equalsIgnoreCase("DSTSC")) {
			tx = session.beginTransaction();

			que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
					+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
					+ ", 171, 6, 1)");

			que.executeUpdate();
			tx.commit();

			if (!cols[16].equalsIgnoreCase("NONE")) {

				if (cols[16].toString().equalsIgnoreCase("ALMC")) {

					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 8, 2)");

					que.executeUpdate();
					tx.commit();

					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 13, 3)");

					que.executeUpdate();
					tx.commit();

				} else {
					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 13, 2)");

					que.executeUpdate();
					tx.commit();

					tx = session.beginTransaction();

					que = session.createSQLQuery("INSERT INTO public.dssc_choice_tbl(\n"
							+ "	 dscc_app_id, es_id, course_applied, course_preference)\n" + "	VALUES (" + appid
							+ ", 171, 8, 3)");

					que.executeUpdate();
					tx.commit();
				}

			}

		}

	}

//	@Override
//	public List getSubjectListWithCutOffForUpgradation(int es_id) {
//
//		// Logic For ALl Pass Start
//		Session session = this.sessionFactory.openSession();
//
//		Transaction tx = session.beginTransaction();
//		Query deletequery = session.createSQLQuery(
//				"DROP TABLE IF EXISTS public.nontempdssc;CREATE TABLE IF NOT EXISTS public.nontempdssc\n" + "(\n"
//						+ "    oa_application_id integer,\n" + "    clearpassed character varying(1) \n" + ")\n" + "\n"
//						+ "TABLESPACE pg_default;\n" + "\n" + "ALTER TABLE IF EXISTS public.nontempdssc\n"
//						+ "    OWNER to postgres;");
//		deletequery.executeUpdate();
//		tx.commit();
//
//		tx = session.beginTransaction();
//		deletequery = session.createSQLQuery("DROP TABLE IF EXISTS public.non_qualified_officers;\n" + "\n"
//				+ "CREATE TABLE IF NOT EXISTS public.non_qualified_officers\n" + "(\n" + "    oid serial NOT NULL ,\n"
//				+ "    nominatedfor character varying ,\n" + "    oa_applicant_id integer,\n"
//				+ "    course_id integer,\n" + "    CONSTRAINT non_qualified_officers_pkey PRIMARY KEY (oid)\n" + ")\n"
//				+ "\n" + "TABLESPACE pg_default;\n" + "\n" + "ALTER TABLE IF EXISTS public.non_qualified_officers\n"
//				+ "    OWNER to postgres;");
//		deletequery.executeUpdate();
//		tx.commit();
//
//		tx = session.beginTransaction();
//		deletequery = session.createSQLQuery("DROP TABLE IF EXISTS public.nondsscaualified;\n" + "\n"
//				+ "CREATE TABLE IF NOT EXISTS public.nondsscaualified\n" + "(\n" + "    did serial NOT NULL ,\n"
//				+ "    oa_applicant_id integer,\n" + "    nominatefor character varying ,\n"
//				+ "    assigned character varying ,\n" + "    grandtotal double precision,\n"
//				+ "    outof700 double precision,\n" + "    CONSTRAINT nondsscaualified_pkey PRIMARY KEY (did)\n"
//				+ ")\n" + "\n" + "TABLESPACE pg_default;\n" + "\n" + "ALTER TABLE IF EXISTS public.nondsscaualified\n"
//				+ "    OWNER to postgres;");
//		deletequery.executeUpdate();
//		tx.commit();
//
//		Query que = session
//				.createSQLQuery("select es.es_id,esd.sc_subject_id,esd.esd_final_cutoff_dssc  from exam_schedule es\n"
//						+ "inner join exam_schedule_detail esd ON esd.es_id = es.es_id\n" + "where es.es_id=" + es_id);
//		List list = que.list();
//		String query = "select ab.oa_application_id,'Y' \n"
//				+ " from officer_application ofa inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
//				+ "where ofa.es_id=" + es_id + " \n" + "and";
//		String append_q = "";
//		int count = 1;
//		String queryfortemptable1 = "";
//		String queryfortemptable2 = "";
//		String queryfortemptable3 = "";
//		tx = session.beginTransaction();
//		Query createtablequery1 = session
//				.createSQLQuery("Drop table if exists nontemp1; CREATE TABLE IF NOT EXISTS public.nontemp1 " + "(\n"
//						+ "    officer_no integer )");
//		createtablequery1.executeUpdate();
//		tx.commit();
//
//		for (int i = 0; i < list.size(); i++) {
//			Object[] obj = (Object[]) list.get(i);
//			if (i == 0) {
//				query += " case ";
//				append_q += " case";
//				queryfortemptable1 += "select A" + count + ".oa_application_id,A" + count + ".marks ,";
//				queryfortemptable2 += " from sub" + count + " A" + count + ",";
//				queryfortemptable3 += " where ";
//
//			}
//			query += "  when sc_subject_id =" + obj[1] + " then ab_marks_obtained >= " + obj[2];
//			append_q += "  when sc_subject_id =" + obj[1] + " then ab_marks_obtained >= " + obj[2];
//			if (i == list.size() - 1) {
//				query += " end ";
//				append_q += " end ";
//			}
//			tx = session.beginTransaction();
//			Query createtablequery = session.createSQLQuery("DROP TABLE IF EXISTS public.sub" + count
//					+ ";CREATE TABLE IF NOT EXISTS public.sub" + count + "\n" + "(\n" + "    sid serial NOT NULL,\n"
//					+ "    OA_APPLICATION_ID integer,\n" + "    marks integer,\n" + "    CONSTRAINT sub" + count
//					+ "_pkey PRIMARY KEY (sid)\n" + ")");
//			createtablequery.executeUpdate();
//			tx.commit();
//
//			tx = session.beginTransaction();
////			Query inserttablequery = session
////					.createSQLQuery("insert into sub" + count + "(marks,OA_APPLICATION_ID)         \n"
////							+ " select ab_marks_obtained,OA_APPLICATION_ID from Answer_Book_DsscTsoc where es_id="
////							+ es_id + " and sc_subject_id=" + obj[1] + "  order by ab_marks_obtained desc ");
//
//			Query inserttablequery = session
//					.createSQLQuery("insert into sub" + count + "(marks,OA_APPLICATION_ID)         \n"
//							+ " select ab_marks_obtained,ab.OA_APPLICATION_ID from answer_book ab\n"
//							+ "inner join officer_application ofa on ofa.oa_application_id = ab.oa_application_id \n"
//							+ "where ofa.es_id=" + es_id + " and sc_subject_id=" + obj[1]
//							+ "  order by ab_marks_obtained desc");
//			System.err.println("inserttablequery.executeUpdate()" + inserttablequery.executeUpdate());
//			tx.commit();
//
//			tx = session.beginTransaction();
//			Query altertablequery = session.createSQLQuery(
//					"ALTER TABLE IF EXISTS public.temp1\n" + "    ADD Column sub" + count + "  integer;");
//			altertablequery.executeUpdate();
//			tx.commit();
//
//			if (i == list.size() - 1) {
//
//				tx = session.beginTransaction();
//				altertablequery = session.createSQLQuery("ALTER TABLE IF EXISTS public.temp1\n"
//						+ "    ADD Column assigned  integer;ALTER TABLE IF EXISTS public.temp1 ADD Column es_id  integer;");
//				altertablequery.executeUpdate();
//				tx.commit();
//
//				queryfortemptable1 += " A" + count + ".marks,0," + es_id + "";
//				queryfortemptable2 += "  sub" + count + " A" + count + "";
//				queryfortemptable3 += "A1.oa_application_id = A" + count + ".oa_application_id";
//
//			} else {
//				if (i != 0) {
//					queryfortemptable1 += " A" + count + ".marks ,";
//					queryfortemptable2 += "  sub" + count + " A" + count + ",";
//					queryfortemptable3 += "A1.oa_application_id = A" + count + ".oa_application_id and ";
//				}
//			}
//
//			count++;
//		}
//
//		query += " group by 1 having count(*) = " + list.size() + "\n" + "order by 1";
//		System.out.println("query" + query);
//
//		int dividedby = list.size() * 500;
//
//		tx = session.beginTransaction();
//		String query2 = "insert into tempdssc " + query;
//		Query querylist = session.createSQLQuery(query2);
//		querylist.executeUpdate();
//		tx.commit();
//
//		System.err.println("Temp Insert Query =======" + queryfortemptable1 + queryfortemptable2 + queryfortemptable3);
//		String querytemp1 = queryfortemptable1 + queryfortemptable2 + queryfortemptable3;
//
//		tx = session.beginTransaction();
//		Query insert_temp_query = session.createSQLQuery("insert into temp1 " + querytemp1);
//		insert_temp_query.executeUpdate();
//		tx.commit();
//		tx = session.beginTransaction();
////		que = session.createSQLQuery(
////				"INSERT INTO dsscaualified(oa_applicant_id,grandtotal,outof700)  SELECT A.oa_application_id   ,ROUND(A.marks_obtained,2),ROUND(A.outof700,2)   \n"
////						+ "FROM    \n" + "(select distinct(ab.oa_application_id),\n"
////						+ "cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby
////						+ " +coalesce(c.cpv_mks,0)+coalesce(c.fd_service_mks,0) as marks_obtained\n"
////						+ ",cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby + " as outof700\n"
////						+ "\n"
////						+ " from officer_application ofa inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
////						+ " inner join cpv c on c.oa_application_id = ab.oa_application_id\n" + " where \n"
////						+ "ofa.es_id=" + es_id + "  \n" + "and " + append_q + " \n"
////						+ "and ab.oa_application_id in (SELECT oa_application_id FROM tempdssc WHERE clearpassed IS NOT NULL )\n"
////						+ "and ab.oa_application_id not in (select oa_applicant_id from dsscaualified)\n"
////						+ "group by ab.oa_application_id,c.cpv_mks,c.fd_service_mks having count(*) = " + list.size()
////						+ " ) A \n" + "ORDER BY ROUND(A.marks_obtained ,2) DESC, ROUND(A.outof700,2)  desc");
////		
//		que = session.createSQLQuery(
//				"INSERT INTO dsscaualified(oa_applicant_id,grandtotal,outof700)  SELECT A.oa_application_id   ,ROUND(A.marks_obtained,2),ROUND(A.outof700,2)   \n"
//						+ "FROM    \n" + "(select distinct(ab.oa_application_id),\n"
//						+ "cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby
//						+ " +coalesce(c.cpv_mks,0)+coalesce(c.fd_service_mks,0) as marks_obtained\n"
//						+ ",cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby + " as outof700\n"
//						+ "\n"
//						+ " from officer_application ofa inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
//						+ " inner join cpv c on c.oa_application_id = ab.oa_application_id\n" + " where \n"
//						+ "ofa.es_id=" + es_id + "  \n" + "and " + append_q + " \n"
//						+ "and ab.oa_application_id in (SELECT oa_application_id FROM tempdssc WHERE clearpassed IS NOT NULL )\n"
//						+ "and ab.oa_application_id not in (select oa_applicant_id from dsscaualified)\n"
//						+ "group by ab.oa_application_id,c.cpv_mks,c.fd_service_mks having count(*) = " + list.size()
//						+ " ) A \n" + "ORDER BY ROUND(A.marks_obtained ,2) DESC, ROUND(A.outof700,2)  desc");
//
//		int inserted = que.executeUpdate();
//		tx.commit();
//
//		// Seat Assign
//
//		que = session.createQuery("From Dsscaualified where assigned is null order by did");
//		List<Dsscaualified> dsscqual_list = que.list();
//		int rankinc = 0;
//		for (Dsscaualified dsscaualified : dsscqual_list) {
//
//			Query qual_off = session.createSQLQuery("select oa_application_id,course_applied,course_preference \n"
//					+ "from dssc_tsoc_application t inner join dssc_choice_tbl c on c.dscc_app_id = t.id\n"
//					+ "and t.oa_application_id  = " + dsscaualified.getOaApplicantId() + " order by course_preference");
//			List qual_off_list = qual_off.list();
//
//			outerloop: for (int i = 0; i < qual_off_list.size(); i++) {
//				Object[] obj = (Object[]) qual_off_list.get(i);
//
//				Query fullvac = session
//						.createSQLQuery("select count(*) from qualified_officers where course_id = " + obj[1] + "");
//				BigInteger fullvac_count = (BigInteger) fullvac.uniqueResult();
//
//				Query vacant_vac = session.createSQLQuery(
//						"select total_vacancy,case when sub_course = 'Res' then concat(name,' ',sub_course) else sub_course end from (select total_vacancy,case when (sub_course is null or sub_course = '')  then c.name else sub_course end,name from dssc_merit_result_gen_tbl d\n"
//								+ "inner join course_master c on d.course_id = c.choice_id\n"
//								+ "where (division  ='N' or division is null )\n" + "and course_id = " + obj[1]
//								+ " order by priority_result)A");
//
//				List obj_vacant = vacant_vac.list();
//
//				for (int j = 0; j < obj_vacant.size(); j++) {
//					Object[] obje = (Object[]) obj_vacant.get(j);
//					int total_vac = (int) obje[0];
//					String course_name = (String) obje[1];
//
//					if (fullvac_count.intValue() < total_vac) {
//						tx = session.beginTransaction();
//						Query insert_qual = session.createSQLQuery(
//								"insert into qualified_officers(nominatedfor,oa_applicant_id,course_id) values('"
//										+ course_name + "'," + obj[0] + "," + obj[1] + ")");
//						insert_qual.executeUpdate();
//						tx.commit();
//						rankinc = rankinc + 1;
//						tx = session.beginTransaction();
//						insert_qual = session.createSQLQuery(
//								"update temp1 set assigned = " + rankinc + " where officer_no = " + obj[0]);
//						insert_qual.executeUpdate();
//						tx.commit();
//
//						tx = session.beginTransaction();
//						insert_qual = session.createSQLQuery(
//								"update dsscaualified set assigned = 'YES' where oa_applicant_id = " + obj[0]);
//						insert_qual.executeUpdate();
//						tx.commit();
//
//						break outerloop;
//					}
//
//				}
//
//			}
//
//		}
//
////		tx = session.beginTransaction();
////		que = session.createSQLQuery("select sum(total_vacancy),sub_course from dssc_merit_result_gen_tbl where es_id="
////				+ es_id + " and division = 'N'  \n" + "group by priority_result,sub_course order by priority_result");
////		List listda = que.list();
//
////		int counteupdate = 0;
////		breakloop: for (int i = 0; i < listda.size(); i++) {
////			Object[] obj = (Object[]) listda.get(i);
////
////			if (counteupdate == inserted) {
////				break breakloop;
////			} else {
////
////				// ======================================Change=============================================
////				que = session.createSQLQuery(
////						"insert into qualified_officers (oa_applicant_id,nominatedfor)  select oa_applicant_id,'"
////								+ obj[1]
////								+ "' from dsscaualified d,officermerit1 o where d.oa_applicant_id=o.officer_no\n"
////								+ "and (lower(o.choice)  ='dssc' or lower(o.choice)  ='both') and lower(o.priority) != 'dstsc' and oa_applicant_id not in (select oa_applicant_id from qualified_officers)\n"
////								+ "order by did limit " + obj[0]);
////				counteupdate += que.executeUpdate();
////			}
////
////		}
//
//		// Logic For All PAss End
//
//		// Logic For DSSC ,DSTSC and Other Start
//
//		que = session.createSQLQuery(
//				"select sum(total_vacancy),priority_merit from dssc_merit_result_gen_tbl where division = 'N' or division is null\n"
//						+ "group by priority_merit");
//		List meritlist = que.list();
//
//		int vac = 0;
//
//		for (int i = 0; i < meritlist.size(); i++) {
//
//			Object[] obj = (Object[]) meritlist.get(i);
//
////			Query quee = session.createSQLQuery("select distinct(course_id) from dssc_merit_result_gen_tbl where (division = 'N' or division is null) and  priority_merit = "+obj[1]+"");
////			List course_obj = quee.list();
//
//			int vacancy = Integer.parseInt(obj[0].toString());
//			vac = vac + vacancy;
//
//			vacancy = vac;
//			que = session.createSQLQuery("select count(oa_applicant_id) from qualified_officers");
//
//			BigInteger ib = (BigInteger) que.uniqueResult();
//			int allpassed = ib.intValue();
//			int topid = vacancy;
//			long candidate = 0;
//
//			System.err.println("==================================================================================");
//			System.err.println("Vacancy -->" + vacancy + " All PAss " + allpassed);
//			System.err.println("==================================================================================");
//
//			breakloop: while (candidate < vacancy - allpassed) {
//				int jcount[] = new int[list.size()];
//				int coutforsub = 1;
//				for (int j = 0; j < list.size(); j++) {
//					Query que2 = session.createSQLQuery("select marks from Sub" + coutforsub + " where sid = " + topid);
//
//					int marks = (int) que2.uniqueResult();
//					if (marks > 200) {
//						jcount[j] = 200;
//					} else {
//						jcount[j] = (int) que2.uniqueResult();
//					}
//					coutforsub++;
//				}
//				que = session.createSQLQuery(
//						"select count(*) from temp1 where assigned != 0 and   \n" + " ES_ID=" + es_id + "");
//				BigInteger rowcountbig = (BigInteger) que.uniqueResult();
//
//				if (rowcountbig.intValue() <= 0) {
//					break breakloop;
//				}
//
//				// Changes need to be DOne
//				int subinc = 1;
//				String countquery = "select count(*) from temp1 where ";
//				for (int k = 0; k < list.size(); k++) {
//					if (k == 0) {
//						countquery += " sub" + subinc + " >= " + jcount[k] + " ";
//					} else {
//						countquery += " and  sub" + subinc + " >= " + jcount[k] + " ";
//					}
//					subinc++;
//				}
//
//				que = session.createSQLQuery(countquery + " and assigned = 0 and es_id = " + es_id + "");
//				BigInteger caBigInteger = (BigInteger) que.uniqueResult();
//				candidate = caBigInteger.intValue();
//				topid = topid + 20;
//
//			}
//
//			topid = topid - 40;
//			candidate = 0;
//			int rank = 1;
//
//			breakloop: while (candidate < vacancy) {
//				int coutforsub = 1;
//				int jcount[] = new int[list.size()];
//				for (int j = 0; j < list.size(); j++) {
//					que = session.createSQLQuery("select marks from Sub" + coutforsub + " where sid = " + topid);
//					jcount[j] = (int) que.uniqueResult();
//					coutforsub++;
//				}
//				que = session.createSQLQuery(
//						"select count(*) from temp1 where assigned != 0 and   \n" + " ES_ID=" + es_id + "");
//				BigInteger rowcountbig = (BigInteger) que.uniqueResult();
//
//				if (rowcountbig.intValue() <= 0) {
//					break breakloop;
//				}
//				candidate = rowcountbig.intValue();
//				int subinc = 1;
//				String countquery = "select distinct officer_no,null from temp1 t inner join dssc_tsoc_application d on t.officer_no = d.oa_application_id\n"
//						+ "inner join dssc_choice_tbl dc on dc.dscc_app_id =d.id where ";
//				for (int k = 0; k < list.size(); k++) {
//					if (k == 0) {
//						countquery += " sub" + subinc + " >= " + jcount[k] + " ";
//					} else {
//						countquery += " and  sub" + subinc + " >= " + jcount[k] + " ";
//					}
//					subinc++;
//				}
//
//				countquery += "and assigned = 0 and t.es_id = " + es_id
//						+ "  and dc.course_applied in (select distinct(course_id) from dssc_merit_result_gen_tbl where (division = 'N' or division is null) and  priority_merit = "
//						+ obj[1] + ") ";
//				Query wu = session.createSQLQuery(countquery);
//
//				List newlist = wu.list();
//				if (newlist != null) {
//					if (!newlist.isEmpty()) {
//						for (int l = 0; l < newlist.size(); l++) {
//							Object[] officermerit = (Object[]) newlist.get(l);
//
//							que = session.createSQLQuery("select max(assigned)+1 from temp1");
//							int maxrank = (int) que.uniqueResult();
//
//							if (maxrank > vacancy) {
//								break breakloop;
//							}
//
//							tx = session.beginTransaction();
//							Query updatetemp1 = session.createSQLQuery("update temp1 set assigned = " + maxrank
//									+ " where officer_no = " + officermerit[0] + "");
//							updatetemp1.executeUpdate();
//							tx.commit();
//							tx = session.beginTransaction();
//							Query que1 = session
//									.createSQLQuery("insert into tempdssc values (" + officermerit[0] + ")");
//							que1.executeUpdate();
//							tx.commit();
//
//						}
//					}
//				}
//
////				tx = session.beginTransaction();
////
////				que = session.createSQLQuery(
////						"insert into tempdssc  " + countquery + " and assigned = 0 and es_id = " + es_id + " ");
////				que.executeUpdate();
////				tx.commit();
////
////				que = session.createSQLQuery(countquery + " and assigned = 0 and es_id = " + es_id + " ");
////				List countqu = que.list();
//
//				// candidate = countqu.size();
//				topid = topid + 2;
//			}
//
//			tx = session.beginTransaction();
//			que = session.createSQLQuery(
//					"INSERT INTO dsscaualified(oa_applicant_id,grandtotal,outof700)  SELECT A.oa_application_id   ,ROUND(A.marks_obtained,2),ROUND(A.outof700,2)   \n"
//							+ "FROM    \n" + "(select distinct(ab.oa_application_id),\n"
//							+ "cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby
//							+ " +coalesce(c.cpv_mks,0)+coalesce(c.fd_service_mks,0) as marks_obtained\n"
//							+ ",cast (coalesce((sum(ab.ab_marks_obtained)*700),0) as float)/" + dividedby
//							+ " as outof700\n" + "\n"
//							+ " from officer_application ofa inner join answer_book ab on ab.oa_application_id = ofa.oa_application_id\n"
//							+ " inner join cpv c on c.oa_application_id = ab.oa_application_id\n" + " where \n"
//							+ "ofa.es_id=" + es_id + "  \n"
//							+ "and ab.oa_application_id in (SELECT oa_application_id FROM tempdssc WHERE clearpassed IS NULL )\n"
//							+ "and ab.oa_application_id not in (select oa_applicant_id from dsscaualified)\n"
//							+ "group by ab.oa_application_id,c.cpv_mks,c.fd_service_mks having count(*) = "
//							+ list.size() + " ) A \n"
//							+ "ORDER BY ROUND(A.marks_obtained ,2) DESC, ROUND(A.outof700,2)  desc");
//			int insertednew = que.executeUpdate();
//			tx.commit();
//
//			// Seat Assign
//
////			que = session.createQuery("From Dsscaualified where assigned is null order by did");
////			dsscqual_list = que.list();
////
////			for (Dsscaualified dsscaualified : dsscqual_list) {
////				
////				if(dsscaualified.getOaApplicantId().toString().equalsIgnoreCase("348706")) {
////					System.out.println("Please Stop To Check");
////				}
////
////				Query qual_off = session.createSQLQuery("select oa_application_id,course_applied,course_preference \n"
////						+ "from dssc_tsoc_application t inner join dssc_choice_tbl c on c.dscc_app_id = t.id\n"
////						+ "and t.oa_application_id  = " + dsscaualified.getOaApplicantId()
////						+ " order by course_preference");
////				List qual_off_list = qual_off.list();
////
////				outerloop: for (int k = 0; k < qual_off_list.size(); k++) {
////					Object[] obj1 = (Object[]) qual_off_list.get(k);
////
////					Query vacant_vac = session.createSQLQuery(
////							"select total_vacancy,case when sub_course = 'Res' then concat(name,' ',sub_course) else sub_course end from (select total_vacancy,case when (sub_course is null or sub_course = '')  then c.name else sub_course end,name from dssc_merit_result_gen_tbl d\n"
////									+ "inner join course_master c on d.course_id = c.choice_id\n"
////									+ "where (division  ='N' or division is null )\n" + "and course_id = " + obj1[1]
////									+ " order by priority_result)A");
////					
////					
//////					Query vacant_vac = session.createSQLQuery(
//////							"select total_vacancy,case when sub_course = 'Res' then concat(name,' ',sub_course) else sub_course end,course_id from (select total_vacancy,\n"
//////							+ "case when (sub_course is null or sub_course = '')  then c.name else sub_course end,\n"
//////							+ "name,course_id\n"
//////							+ " from dssc_merit_result_gen_tbl d\n"
//////							+ "inner join course_master c on d.course_id = c.choice_id\n"
//////							+ "where (division is null or division = 'N' ) and es_id = "+es_id+" order by 	priority_result	)A					 ");
////					
////					
//////					Query vacant_vac = session.createSQLQuery(
//////							"select total_vacancy,\n"
//////							+ "name,\n"
//////							+ "course_id \n"
//////							+ " from dssc_merit_result_gen_tbl d\n"
//////							+ "inner join course_master c on d.course_id = c.choice_id\n"
//////							+ "where (division is null or division = 'N' ) and es_id = "+es_id+" order by 	priority_result");
////
////					List obj_vacant = vacant_vac.list();
////					//int rankinc = 0;
////					for (int j = 0; j < obj_vacant.size(); j++) {
////						Object[] obje = (Object[]) obj_vacant.get(j);
////						int total_vac = (int) obje[0];
////						String course_name = (String) obje[1];
////					//	int course_id = (int) obje[2];
////
////						Query fullvac = session
////								.createSQLQuery("select count(*) from qualified_officers where course_id = " + obj1[1]
////										+ " and nominatedfor = '" + course_name + "'");
////						BigInteger fullvac_count = (BigInteger) fullvac.uniqueResult();
////
////						if (fullvac_count.intValue() < total_vac) {
////							tx = session.beginTransaction();
////							Query insert_qual = session.createSQLQuery(
////									"insert into qualified_officers(nominatedfor,oa_applicant_id,course_id) values('"
////											+ course_name + "'," + obj1[0] + "," + obj1[1] + ")");
////							insert_qual.executeUpdate();
////							tx.commit();
//////							rankinc = rankinc + 1;
//////							tx = session.beginTransaction();
//////							insert_qual = session.createSQLQuery(
//////									"update temp1 set assigned = " + rankinc + " where officer_no = " + obj1[0]);
//////							insert_qual.executeUpdate();
//////							tx.commit();
////
////							tx = session.beginTransaction();
////							insert_qual = session.createSQLQuery(
////									"update dsscaualified set assigned = 'YES' where oa_applicant_id = " + obj1[0]);
////							insert_qual.executeUpdate();
////							tx.commit();
////
////							break outerloop;
////						}
////
////					}
////
////				}
////
////			}
//
//			//////////////////////////
//
//			que = session.createQuery("From Dsscaualified where assigned is null order by did");
//			dsscqual_list = que.list();
//
//			for (Dsscaualified dsscaualified : dsscqual_list) {
//
//				Query res = session.createSQLQuery("select *,\n"
//						+ "(select count(*) from qualified_officers where course_id = course_applied and nominatedfor = sub_course)  as full_vacancy\n"
//						+ "from (select a.oa_application_id,a.course_applied,a.course_preference,d.total_vacancy ,d.priority_result,\n"
//						+ "case when (d.sub_course is null or d.sub_course = '') then name else case when sub_course = 'Res' then concat(name,' ',sub_course) else sub_course end end,\n"
//						+ "d.priority_merit from \n"
//						+ "(select oa_application_id,course_applied,course_preference,name from  dssc_tsoc_application t1 \n"
//						+ "inner join dssc_choice_tbl c1 on c1.dscc_app_id = t1.id\n"
//						+ "inner join course_master c on c.choice_id = c1.course_applied\n"
//						+ "where oa_application_id = " + dsscaualified.getOaApplicantId() + " \n"
//						+ "order by course_preference) a\n"
//						+ "inner join dssc_merit_result_gen_tbl d on d.course_id = a.course_applied\n"
//						+ "where (division is null or division = 'N')\n"
//						+ "order by priority_merit,priority_result,course_preference)A");
//				List reslist = res.list();
//				outerloop1: for (int j = 0; j < reslist.size(); j++) {
//					Object[] resobj = (Object[]) reslist.get(j);
//					int oa_application_id = (int) resobj[0];
//					int course_applied = (int) resobj[1];
//					// int course_preference = (int) resobj[2];
//					int total_vacancy = (int) resobj[3];
//					String sub_course = (String) resobj[5];
//					BigInteger full_vacancy = (BigInteger) resobj[7];
//
//					if (full_vacancy.intValue() < total_vacancy) {
//						tx = session.beginTransaction();
//						Query insert_qual = session.createSQLQuery(
//								"insert into qualified_officers(nominatedfor,oa_applicant_id,course_id) values('"
//										+ sub_course + "'," + oa_application_id + "," + course_applied + ")");
//						insert_qual.executeUpdate();
//						tx.commit();
//
//						tx = session.beginTransaction();
//						insert_qual = session
//								.createSQLQuery("update dsscaualified set assigned = 'YES' where oa_applicant_id = "
//										+ oa_application_id);
//						insert_qual.executeUpdate();
//						tx.commit();
//
//						break outerloop1;
//					}
//
//				}
//
//			}
//		}
//
//		session.close();
//
//		return list;
//
//	}

}
