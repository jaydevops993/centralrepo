package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "index_slip_scanned", uniqueConstraints = {
@UniqueConstraint(columnNames = "is_scan_id"),})
public class INDEX_SLIP_SCANNED {

	
	private int is_scan_id;
	
	private String is_armyno;
	private String is_es_id;
	private String is_commandcode;
	private String is_abs;
	private String is_sc_subject_id;
	private int is_ic_user_id;
	private Date is_updatedate;
	private String is_ecc_center_code;
	private String is_ac_arm_id;
	private String is_imagepath;
	private String is_mm_year;
	private String is_sflag;
	private String created_by;
	private String modified_by;
	private Date created_date;
	private Date modified_date;
	private int iss_sub_subject_id;
	
	   @Id
	    @GeneratedValue(strategy = IDENTITY)
	    @Column(name = "is_scan_id", unique = true, nullable = false)
	
	
	public int getIs_scan_id() {
		return is_scan_id;
	}
	public void setIs_scan_id(int is_scan_id) {
		this.is_scan_id = is_scan_id;
	}
	public String getIs_armyno() {
		return is_armyno;
	}
	public void setIs_armyno(String is_armyno) {
		this.is_armyno = is_armyno;
	}
	public String getIs_es_id() {
		return is_es_id;
	}
	public void setIs_es_id(String is_es_id) {
		this.is_es_id = is_es_id;
	}
	public String getIs_commandcode() {
		return is_commandcode;
	}
	public void setIs_commandcode(String is_commandcode) {
		this.is_commandcode = is_commandcode;
	}
	public String getIs_abs() {
		return is_abs;
	}
	public void setIs_abs(String is_abs) {
		this.is_abs = is_abs;
	}
	public String getIs_sc_subject_id() {
		return is_sc_subject_id;
	}
	public void setIs_sc_subject_id(String is_sc_subject_id) {
		this.is_sc_subject_id = is_sc_subject_id;
	}
	public int getIs_ic_user_id() {
		return is_ic_user_id;
	}
	public void setIs_ic_user_id(int is_ic_user_id) {
		this.is_ic_user_id = is_ic_user_id;
	}
	public Date getIs_updatedate() {
		return is_updatedate;
	}
	public void setIs_updatedate(Date is_updatedate) {
		this.is_updatedate = is_updatedate;
	}
	public String getIs_ecc_center_code() {
		return is_ecc_center_code;
	}
	public void setIs_ecc_center_code(String is_ecc_center_code) {
		this.is_ecc_center_code = is_ecc_center_code;
	}
	public String getIs_ac_arm_id() {
		return is_ac_arm_id;
	}
	public void setIs_ac_arm_id(String is_ac_arm_id) {
		this.is_ac_arm_id = is_ac_arm_id;
	}
	public String getIs_imagepath() {
		return is_imagepath;
	}
	public void setIs_imagepath(String is_imagepath) {
		this.is_imagepath = is_imagepath;
	}
	public String getIs_mm_year() {
		return is_mm_year;
	}
	public void setIs_mm_year(String is_mm_year) {
		this.is_mm_year = is_mm_year;
	}
	public String getIs_sflag() {
		return is_sflag;
	}
	public void setIs_sflag(String is_sflag) {
		this.is_sflag = is_sflag;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	public int getIss_sub_subject_id() {
		return iss_sub_subject_id;
	}
	public void setIss_sub_subject_id(int iss_sub_subject_id) {
		this.iss_sub_subject_id = iss_sub_subject_id;
	}
	
	
	
}
