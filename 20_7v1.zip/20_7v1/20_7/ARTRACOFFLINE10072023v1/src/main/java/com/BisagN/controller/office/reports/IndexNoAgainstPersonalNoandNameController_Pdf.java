package com.BisagN.controller.office.reports;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.IndexNoAgainstMarksObtainedController_Pdf.PageNumeration;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;


public class IndexNoAgainstPersonalNoandNameController_Pdf extends AbstractPdfView{
	
	
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	int totalRecords=0;
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public IndexNoAgainstPersonalNoandNameController_Pdf(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		
		document.setPageSize(PageSize.A4.rotate());
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		
	response.setContentType("application/pdf");
	response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");

//		Font fontTableHeadingSubMainHead = FontFactory.getFont(FontFactory.TIMES_BOLD, 12);;
//		Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
	
	     Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
         Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 1);
         Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
	
	
	
		String es_year =  (String) model.get("es_year");
//		String letter_no =  (String) model.get("letter_no1");
//		String letter_date1 =  (String) model.get("letter_date1");
		
		
		
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		Chunk underline = new Chunk("INDEX NO AGAINST PERSONAL NO AND NAME" +"\n\n"+  "PART B (ONLINE) - "+es_year+"" , fontTableHeading1);
		underline.setUnderline(0.1f, -2f);
		
		Phrase phh2 = new Phrase(underline);
		phh2.add("\n");
		phh2.add("\n");
		
		phh2.setFont(fontTableHeadingSubMainHead);
		
		Paragraph cell1 = new Paragraph(phh2);
		cell1.setAlignment(Element.ALIGN_CENTER);
		
		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell1);
		
		PdfPTable tabledatman = new PdfPTable(1);
		
		tabledatman.setWidthPercentage(100);
		tabledatman.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledatman.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		tabledatman.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		
		
			
		PdfPTable tabledata = new PdfPTable(5);
		tabledata.setWidths(new int[] {1,2,2,10,2});
		tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata.setWidthPercentage(100);
		tabledata.setHeaderRows(1);
	
		
		
//		ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");
		Paragraph a = new Paragraph("Ser    No",fontTableHeadingSubMainHead);
		Paragraph b = new Paragraph("Index No",fontTableHeadingSubMainHead);
		Paragraph c = new Paragraph("Personal No",fontTableHeadingSubMainHead);
		Paragraph d = new Paragraph("Name",fontTableHeadingSubMainHead);
		Paragraph e = new Paragraph("Arm/Service",fontTableHeadingSubMainHead);
		
		
			
			
			 tabledata.addCell(a);
			 tabledata.addCell(b);
			 tabledata.addCell(c);
			 tabledata.addCell(d);
			 tabledata.addCell(e);
			
			 
			
			 
			 //==========DATA BIND===========//
			 
			 
			 
			
//			 for(int i=0;i<list.size();i++)
//			 {
//			
//				 List<String> l = list.get(i);
//				 Paragraph a1index = new Paragraph(String.valueOf(index),fontTableHeadingdata);
//				 Paragraph indexid = new Paragraph(l.get(0),fontTableHeadingdata);
//				 Paragraph persno = new Paragraph(l.get(1),fontTableHeadingdata);
//				 Paragraph name = new Paragraph(l.get(2),fontTableHeadingdata);
//				 Paragraph armservice = new Paragraph(l.get(3),fontTableHeadingdata);
//				 
//				 
//				 
//				 
//				 
////				 tabledata.addCell(a1index);
////				 tabledata.addCell(indexid);
////				 tabledata.addCell(persno);
////				 tabledata.addCell(name);
////				 tabledata.addCell(armservice);
//				 
//				 PdfPCell cell2 = new PdfPCell();
//					if(i % 2 == 0){
//						cell2.setBackgroundColor(java.awt.Color.lightGray);
//					}
//					cell2.setPhrase(a1index);
//					cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
//					 tabledata.addCell(cell2);
//					 cell2.setPhrase(indexid);
//					 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
//					 tabledata.addCell(cell2);
//					 cell2.setPhrase(persno);
//					 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
//					 tabledata.addCell(cell2);
//					 cell2.setPhrase(name);
//					 cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
//					 tabledata.addCell(cell2);
//					 cell2.setPhrase(armservice);
//					 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
//					 tabledata.addCell(cell2);
//					
//				 
//				 
//				index+=1;
//				 
//			
//			 }
				 
			 int  index=1;
			 ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");
			 
				 int flag_first_page_DSTSC = 22;
				int flag_first_page_fix_DSTSC = 22;
				
			 
				for (int i = 0; i < list.size();i++) {
					//if(i > 45){ flag_first_page_fix = 66;}
						
					List<String> l3 = list.get(i);
//					List<String> l = list.get(i);
					 Paragraph a1index = new Paragraph(String.valueOf(index),fontTableHeadingdata);
					 Paragraph indexid = new Paragraph(l3.get(0),fontTableHeadingdata);
					 Paragraph persno = new Paragraph(l3.get(1),fontTableHeadingdata);
					 Paragraph name = new Paragraph(l3.get(2),fontTableHeadingdata);
					 Paragraph armservice = new Paragraph(l3.get(3),fontTableHeadingdata);
					 
					 
					List<String> l = list.get(i);
					PdfPCell celle_fl = new PdfPCell();
						 
						if(flag_first_page_DSTSC > (flag_first_page_fix_DSTSC-flag_first_page_fix_DSTSC) && flag_first_page_DSTSC <= (flag_first_page_fix_DSTSC)) {
							
						 
							
							Paragraph ser_no = new Paragraph(String.valueOf(index), fontTableHeadingdata);
							 celle_fl = new PdfPCell(ser_no);
//							 celle_fl.setBorder(Rectangle.NO_BORDER);
							 celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//							 celle_fl.setPadding(3);
							 if (i % 2 == 0) {
									celle_fl.setBackgroundColor(java.awt.Color.lightGray);
							}
							 tabledata.addCell(celle_fl);
							Paragraph index_no = new Paragraph(l.get(0), fontTableHeadingdata);
							celle_fl = new PdfPCell(index_no);
//							 celle_fl.setBorder(Rectangle.NO_BORDER);
							celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//							celle_fl.setPadding(3);
							if (i % 2 == 0) {
								celle_fl.setBackgroundColor(java.awt.Color.lightGray);
							}
							tabledata.addCell(celle_fl);
							Paragraph pers_no = new Paragraph(l.get(1), fontTableHeadingdata);
							celle_fl = new PdfPCell(pers_no);
//							 celle_fl.setBorder(Rectangle.NO_BORDER);
							celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//							celle_fl.setPadding(3);
							if (i % 2 == 0) {
								celle_fl.setBackgroundColor(java.awt.Color.lightGray);
							}
							tabledata.addCell(celle_fl);
							Paragraph name1 = new Paragraph(l.get(2), fontTableHeadingdata);
							celle_fl = new PdfPCell(name1);
//							 celle_fl.setBorder(Rectangle.NO_BORDER);
							celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
							celle_fl.setPadding(3);
							if (i % 2 == 0) {
								celle_fl.setBackgroundColor(java.awt.Color.lightGray);
							}
							tabledata.addCell(celle_fl);
							Paragraph arm_service = new Paragraph(l.get(3), fontTableHeadingdata);
							celle_fl = new PdfPCell(arm_service);
//							 celle_fl.setBorder(Rectangle.NO_BORDER);
							celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
//							celle_fl.setPadding(3);
							if (i % 2 == 0) {
								celle_fl.setBackgroundColor(java.awt.Color.lightGray);
							}
							tabledata.addCell(celle_fl);
						
							
						}
					 
					if(flag_first_page_DSTSC==((flag_first_page_fix_DSTSC-flag_first_page_fix_DSTSC)+1)){
						tabledatman.addCell(tabledata);
		 
						tabledata = new PdfPTable(5);
						tabledata.setWidths(new int[] {1,2,2,10,2});
						tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
						tabledata.setWidthPercentage(100);
						tabledata.setHeaderRows(1);
						tabledata.addCell(a);
						tabledata.addCell(b);
						tabledata.addCell(c);
						tabledata.addCell(d);
						tabledata.addCell(e);
					}
					 
					if(list.size() == (i+1) & flag_first_page_DSTSC > (flag_first_page_fix_DSTSC-flag_first_page_fix_DSTSC) & flag_first_page_DSTSC < ((flag_first_page_fix_DSTSC)+1)){
					
						tabledatman.addCell(tabledata);
						tabledata = new PdfPTable(5);
						tabledata.setWidths(new int[] {1,2,2,10,2});
						tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
						tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
						tabledata.setWidthPercentage(100);
						tabledata.setHeaderRows(1);
						tabledata.addCell(a);
						tabledata.addCell(b);
						tabledata.addCell(c);
						tabledata.addCell(d);
						tabledata.addCell(e);
					}		
					index+=1;
					flag_first_page_DSTSC -= 1;
					if(flag_first_page_DSTSC == 0) {
						flag_first_page_fix_DSTSC = 26;
						flag_first_page_DSTSC = flag_first_page_fix_DSTSC;				
					}
				}
			 
				 
				
			
			 PageNumeration event = new PageNumeration(arg2);
				arg2.setPageEvent(event);
				document.setPageCount(1);
		PdfPCell cell123;
		cell123 = new PdfPCell();
		cell123.addElement(tableheader);
		cell123.addElement(tabledatman);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(new Paragraph("\n"));
//		cell123.addElement(tabledatman);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(new Paragraph("\n"));
		cell123.setBorder(0);
		table.addCell(cell123);
		


	
	document.add(table);
	super.buildPdfMetadata(model, document, request);
	}
	class PageNumeration extends PdfPageEventHelper {
		PdfTemplate total;
		PdfTemplate total1;

		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				total1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {
			// total = writer.getDirectContent().createTemplate(30, 12);
		}

		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			String ip = "";
			try {
				table.setWidths(new int[] { 15,6,1});  
				table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				Date now = new Date();
				String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
				table.addCell(dateString);  //table.addCell("TOTAL SHEET :");
				
				
				PdfPCell cell1 = new PdfPCell(Image.getInstance(total1));
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			//	table.addCell(cell1);
								
			
				//String watermark = " Generated by "+username+" on "+dateString +" with IP " +ip ;
				
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Pages %d of", writer.getPageNumber()));
				//table.addCell("Month :");
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.NO_BORDER);				
				table.addCell(cell);
				
				table.writeSelectedRows(0, -1, document.leftMargin(), document.topMargin() + 0, writer.getDirectContent());
			} catch (DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT, new Phrase(String.valueOf(writer.getPageNumber() - 1)), 2, 2, 0);
			ColumnText.showTextAligned(total1, Element.ALIGN_LEFT, new Phrase(String.valueOf(totalRecords)), 2, 2, 0);
		}
	}
}
