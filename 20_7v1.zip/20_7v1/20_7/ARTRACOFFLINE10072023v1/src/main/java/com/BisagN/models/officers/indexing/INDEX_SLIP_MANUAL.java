package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;



@Entity
@Table(name = "index_slip_manual", uniqueConstraints = {
@UniqueConstraint(columnNames = "is_id"),})
public class INDEX_SLIP_MANUAL {
	
	private int is_id;
	private int is_ism_id;
	private int is_abs;
	private int is_commandid;
	private int is_sc_subject_id;
	private int is_status;
	private int is_iu_user_id;
	private Date is_createddate;
	private int is_updatedby;
	private Date is_updatedate;
	private int is_ecc_center_code;
	
	private int is_ac_arm_id;
	private int is_scan_id;
	private int is_ibm_id;
	private int is_sub_subject_id;
	
	
	   @Id
	      @GeneratedValue(strategy = IDENTITY)
	      @Column(name = "is_id", unique = true, nullable = false)
	public int getIs_id() {
		return is_id;
	}
	public void setIs_id(int is_id) {
		this.is_id = is_id;
	}
	public int getIs_ism_id() {
		return is_ism_id;
	}
	public void setIs_ism_id(int is_ism_id) {
		this.is_ism_id = is_ism_id;
	}
	public int getIs_abs() {
		return is_abs;
	}
	public void setIs_abs(int is_abs) {
		this.is_abs = is_abs;
	}
	public int getIs_commandid() {
		return is_commandid;
	}
	public void setIs_commandid(int is_commandid) {
		this.is_commandid = is_commandid;
	}
	public int getIs_sc_subject_id() {
		return is_sc_subject_id;
	}
	public void setIs_sc_subject_id(int is_sc_subject_id) {
		this.is_sc_subject_id = is_sc_subject_id;
	}
	public int getIs_status() {
		return is_status;
	}
	public void setIs_status(int is_status) {
		this.is_status = is_status;
	}
	public int getIs_iu_user_id() {
		return is_iu_user_id;
	}
	public void setIs_iu_user_id(int is_iu_user_id) {
		this.is_iu_user_id = is_iu_user_id;
	}
	public Date getIs_createddate() {
		return is_createddate;
	}
	public void setIs_createddate(Date is_createddate) {
		this.is_createddate = is_createddate;
	}
	public int getIs_updatedby() {
		return is_updatedby;
	}
	public void setIs_updatedby(int is_updatedby) {
		this.is_updatedby = is_updatedby;
	}
	public Date getIs_updatedate() {
		return is_updatedate;
	}
	public void setIs_updatedate(Date is_updatedate) {
		this.is_updatedate = is_updatedate;
	}
	public int getIs_ecc_center_code() {
		return is_ecc_center_code;
	}
	public void setIs_ecc_center_code(int is_ecc_center_code) {
		this.is_ecc_center_code = is_ecc_center_code;
	}
	public int getIs_ac_arm_id() {
		return is_ac_arm_id;
	}
	public void setIs_ac_arm_id(int is_ac_arm_id) {
		this.is_ac_arm_id = is_ac_arm_id;
	}
	public int getIs_scan_id() {
		return is_scan_id;
	}
	public void setIs_scan_id(int is_scan_id) {
		this.is_scan_id = is_scan_id;
	}
	public int getIs_ibm_id() {
		return is_ibm_id;
	}
	public void setIs_ibm_id(int is_ibm_id) {
		this.is_ibm_id = is_ibm_id;
	}
	public int getIs_sub_subject_id() {
		return is_sub_subject_id;
	}
	public void setIs_sub_subject_id(int is_sub_subject_id) {
		this.is_sub_subject_id = is_sub_subject_id;
	}
	
	

}



 
