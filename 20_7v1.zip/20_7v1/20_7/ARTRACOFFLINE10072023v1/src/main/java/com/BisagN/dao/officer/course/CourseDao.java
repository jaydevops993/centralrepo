package com.BisagN.dao.officer.course;

import java.util.ArrayList;

public interface CourseDao {
	
	public ArrayList<ArrayList<String>> getPersDetailForCPSCCourse(int opd_persid);

}
