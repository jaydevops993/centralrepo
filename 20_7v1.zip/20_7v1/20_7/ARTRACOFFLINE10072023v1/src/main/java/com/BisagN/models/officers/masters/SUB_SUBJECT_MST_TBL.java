package com.BisagN.models.officers.masters;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "sub_subject_mst_tbl", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})
public class SUB_SUBJECT_MST_TBL {

	
	private int id; 
	private int exm_id;
	private int sub_id;
	private String created_by;
	private Date created_date;
	private String modified_by;
	private Date modified_date;
	private int sub_subject_status_id;
	 
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getExm_id() {
		return exm_id;
	}
	public void setExm_id(int exm_id) {
		this.exm_id = exm_id;
	}
	public int getSub_id() {
		return sub_id;
	}
	public void setSub_id(int sub_id) {
		this.sub_id = sub_id;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	public int getSub_subject_status_id() {
		return sub_subject_status_id;
	}
	public void setSub_subject_status_id(int sub_subject_status_id) {
		this.sub_subject_status_id = sub_subject_status_id;
	}
	
	
	 
}
