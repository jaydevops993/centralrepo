package com.BisagN.dao.officer.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import java.util.List;
import java.util.Map;


@Service
public class ExaminationschedulepartdImpl implements ExaminationschedulepartdDao {
	
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

public boolean checkIsIntegerValue(String Search) {
return Search.matches("[0-9]+");
}
public List<Map<String, Object>> getdatafromsubmst(String exam_id) {

	List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
	Connection conn = null;
	String q = "";
	
	System.err.println("");

	try {
		
		conn = dataSource.getConnection();
		
		
	
		
		q="select   sc.sc_subject_id,ex.ec_exam_name,sc.sc_subject_name,sc.ec_exam_id, sc.sub_date, \n"
				+ "String_agg(ar.ac_arm_description,',')  as ac_arm_description  from subject_code sc \n"
				+ "inner join subject_code_child_tbl sch on sc.sc_subject_id=sch.sub_id \n"
				+ "inner join exam_code ex on ex.ec_exam_id=sc.ec_exam_id\n"
				+ "inner join arm_codes ar on ar.ac_arm_id = sch.arm_id\n"
				+ "where ex.ec_exam_id=?  group by 1,2,3,4,5";
		
		

		PreparedStatement stmt = conn.prepareStatement(q);
		stmt.setInt(1, Integer.parseInt(exam_id));
		
		System.err.println("us============"+stmt);
		ResultSet rs = stmt.executeQuery();
		ResultSetMetaData metaData = rs.getMetaData();
		int columnCount = metaData.getColumnCount();
		while (rs.next()) {
			Map<String, Object> columns = new LinkedHashMap<String, Object>();
			for (int i = 1; i <= columnCount; i++) {
				columns.put(metaData.getColumnLabel(i), rs.getObject(i));
			}
			list.add(columns);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}

	return list;
}


public List<Map<String, Object>> getExaminationScheduleList(int startPage,String pageLength,String Search,String orderColunm,String orderType,
		String exam,String es_id,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, 
		InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		if(pageLength.equals("-1")){
 			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search);

 		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		String q = "";
		
		System.err.println("exam============="+exam);
		System.err.println("es_id============="+es_id);
		
		
		try {
			conn = dataSource.getConnection();
			q = "select  esd.* ,es.es_id, TO_CHAR(esd.esd_date ,'DD/MM/YYYY') as esd_date ,sc.sc_subject_name from exam_schedule es\n"
					+ "inner join exam_code ec on es.ec_exam_id = ec.ec_exam_id\n"
					+ "inner join exam_schedule_detail esd on es.es_id = esd.es_id \n"
					+ "inner join subject_code sc on sc.sc_subject_id =esd.sc_subject_id "
					+ "where es.ec_exam_id=? and es.es_id=? "+SearchValue+" order by sc.sc_subject_code  "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
			PreparedStatement stmt = conn.prepareStatement(q);
			stmt = setQueryWhereClause_SQL(stmt,Search);
			
			stmt.setInt(1, Integer.parseInt(exam));
			stmt.setInt(2, Integer.parseInt(es_id));
		
			ResultSet rs = stmt.executeQuery();
			System.err.println("stmt====ggggg======="+stmt);
			ResultSetMetaData metaData = rs.getMetaData();
 			int columnCount = metaData.getColumnCount();
 			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
				    columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
                      String enckey ="commonPwdEncKeys";
	                    Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
	                    String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("es_id").toString().getBytes())));
                      String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"+EncryptedPk+"')}else{ return false;}\""; 
                      String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
                      String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('"+EncryptedPk+"')}else{ return false;}\""; 
                      String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>"; 
                      String f = "";

                      f += updateButton;
                      f += deleteButton;
                      
			list.add(columns);
	}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {
	e.printStackTrace();
} finally {
if (conn != null) {
try {
	conn.close();
} catch (SQLException e) {
}
}
}
return list;
}

public long getExaminationScheduleTotalCount(String Search,String exam,String es_id) {
 		String SearchValue = GenerateQueryWhereClause_SQL(Search);
 		int total = 0;
 		String q = null;
 		Connection conn = null;
 		try {
 			conn = dataSource.getConnection();
 			q ="select count(*) from (select  esd.* , es.es_id,sc.sc_subject_name from exam_schedule es\n"
 					+ "inner join exam_code ec on es.ec_exam_id = ec.ec_exam_id\n"
 					+ "inner join exam_schedule_detail esd on es.es_id = esd.es_id \n"
 					+ "inner join subject_code sc on sc.sc_subject_id =esd.sc_subject_id "
 					+ "where es.ec_exam_id=? and es.es_id=? "+SearchValue+" order by sc.sc_subject_code)a" ;
 			PreparedStatement stmt = conn.prepareStatement(q);
 			stmt = setQueryWhereClause_SQL(stmt,Search);
 			
			stmt.setInt(1, Integer.parseInt(exam));
 			stmt.setInt(2, Integer.parseInt(es_id));
 			ResultSet rs = stmt.executeQuery();
 			while (rs.next()) {
 				total = rs.getInt(1);
 			}
  			rs.close();
  			stmt.close();
  			conn.close();
  		} catch (SQLException e) {
  			e.printStackTrace();
  		} finally {
  			if (conn != null) {
  				try {
  					conn.close();
  				} catch (SQLException e) {
  				}
 			}
  		}
  		return (long) total;
  	}	

public String GenerateQueryWhereClause_SQL(String Search) {
		String SearchValue ="";
		if(!Search.equals("")) {
		Search = Search.toLowerCase();
			SearchValue =" and ( ";
			if(checkIsIntegerValue(Search)) {
				SearchValue +=" id=? or ";
			}
			SearchValue +=" lower(sc_subject_name) like ?)";
		}
return SearchValue;
} 
public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search) {
		int flag = 2;
		try {
		if(!Search.equals("")) {
				if(checkIsIntegerValue(Search)) {
					flag += 1;
					stmt.setInt(flag, Integer.parseInt(Search));
				}
				flag += 1;
				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
				
			}
		
		}catch (Exception e) {}
		return stmt;
	}
public List<Map<String, Object>> getexamscheduleDetails(int ew_id, int ec_exam_id) {
	List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
	Connection conn = null;
	try {
		
		System.err.println("ew_id=============="+ew_id);
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
		String q1="";
		
		if(ec_exam_id == 3) {
			
			q1+="date_part('year',AGE(es.es_dssc_check_year,es.es_to_year)) as min_year";
		}else {
			q1+="date_part('year',AGE(es.es_begin_date,es.es_to_year)) as min_year";
		}
		String q = "select es.* , ec.ec_exam_name,"+q1+" from exam_schedule es\n"
				+ "inner join exam_code ec on ec.ec_exam_id = es.ec_exam_id where es_id=? order by es_id asc  ";
		
		
		
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, ew_id);

		ResultSet rs = stmt.executeQuery();
		
		System.err.println("stmt============="+stmt);
		ResultSetMetaData metaData = rs.getMetaData();
		int columnCount = metaData.getColumnCount();
		while (rs.next()) {
			Map<String, Object> columns = new LinkedHashMap<String, Object>();
			for (int i = 1; i <= columnCount; i++) {
				columns.put(metaData.getColumnLabel(i), rs.getObject(i));
			}
			list.add(columns);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return list;
}



public List<Map<String, Object>> getexamscheduledetails2(int ew_id,int subject_id) {
	List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
	Connection conn = null;
	try {
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
		String q = "select *,id from exam_schedule_detail where es_id=? and sc_subject_id=?  order by sc_subject_id asc  ";
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, ew_id);
		stmt.setInt(2, subject_id);

		ResultSet rs = stmt.executeQuery();
		System.err.println("s============"+stmt);
		ResultSetMetaData metaData = rs.getMetaData();
		int columnCount = metaData.getColumnCount();
		while (rs.next()) {
			Map<String, Object> columns = new LinkedHashMap<String, Object>();
			for (int i = 1; i <= columnCount; i++) {
				columns.put(metaData.getColumnLabel(i), rs.getObject(i));
			}
			list.add(columns);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return list;
}







public List<Map<String, Object>> getvacancyReserveDetailsbyExmsch(int es_id) {
	List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
	Connection conn = null;
	try {
		conn = dataSource.getConnection();
		PreparedStatement stmt = null;
		String q = "select id,ch.name,dcvr.vacancy, dcvr.reserve,dcvr.dssc_course_no,TO_CHAR(dcvr.dssc_course_date,'DD/MM/YYYY') as dssc_course_date from dssc_course_vacancy_reserve dcvr\n"
				+ "inner join course_master ch on ch.choice_id=dcvr.course_id\n"
				+ "where es_id=? order by es_id asc  ";
		stmt = conn.prepareStatement(q);
		stmt.setInt(1, es_id);

		ResultSet rs = stmt.executeQuery();
		System.err.println("choice==========="+stmt);
		ResultSetMetaData metaData = rs.getMetaData();
		int columnCount = metaData.getColumnCount();
		while (rs.next()) {
			Map<String, Object> columns = new LinkedHashMap<String, Object>();
			for (int i = 1; i <= columnCount; i++) {
				columns.put(metaData.getColumnLabel(i), rs.getObject(i));
			}
			list.add(columns);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return list;
}



public List<Map<String, Object>> editgetdatafromsubmst(String es_id) {

	List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
	Connection conn = null;
	String q = "";
	
	System.err.println("");

	try {
		
		conn = dataSource.getConnection();
		q="select   String_agg(ar.ac_arm_description,',')  as ac_arm_description,sc.sc_subject_name,esd.esd_cutoff,sc.sc_subject_id,\n"
				+ "ltrim(TO_CHAR(esd.esd_date,'dd/mm/yyyy'),'0') AS esd_date,esd.sc_is_applicable,esd.id,esd.esd_final_cutoff_dssc	from subject_code sc \n"
				+ "			inner join subject_code_child_tbl sch on sc.sc_subject_id=sch.sub_id \n"
				+ "				inner join exam_code ex on ex.ec_exam_id=sc.ec_exam_id\n"
				+ "				inner join arm_codes ar on ar.ac_arm_id = sch.arm_id\n"
				+ "				inner join exam_schedule_detail esd on esd.sc_subject_id=sc.sc_subject_id\n"
				+ "				where  esd.es_id= ?  group by 2,3,4,5,6,7  order by esd.sc_subject_id asc ";
		
		

		PreparedStatement stmt = conn.prepareStatement(q);
		stmt.setInt(1,Integer.parseInt(es_id));
		
		System.err.println("uszxvszdf============"+stmt);
		ResultSet rs = stmt.executeQuery();
		ResultSetMetaData metaData = rs.getMetaData();
		int columnCount = metaData.getColumnCount();
		while (rs.next()) {
			Map<String, Object> columns = new LinkedHashMap<String, Object>();
			for (int i = 1; i <= columnCount; i++) {
				columns.put(metaData.getColumnLabel(i), rs.getObject(i));
			}
			list.add(columns);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}

	return list;
}


public ArrayList<ArrayList<String>> getactivebegindate(String exm_name) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	String whr = "";

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		if(exm_name != "") {
			whr+="and es.ec_exam_id=? ";
		}
		
	
		
		q="select es.es_id as id, TO_CHAR( es.es_begin_date,'DD/MM/YYYY') as  es_begin_date,es.es_status_id,ex.ec_exam_name from exam_schedule es \n"
				+ "inner join exam_code ex on ex.ec_exam_id=es.ec_exam_id where es_status_id=1 "+whr+"  ";
		
		stmt = conn.prepareStatement(q);
		int i=0;
		if(exm_name != "") {
		stmt.setInt(1, Integer.parseInt(exm_name));
		}
		System.out.println("stmt==========="+stmt);
		
		ResultSet rs = stmt.executeQuery();
		
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("es_begin_date"));//1
			list.add(rs.getString("id"));//1
			list.add(rs.getString("ec_exam_name"));//1
			
			
			
			alist.add(list);
			
			
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}
}
