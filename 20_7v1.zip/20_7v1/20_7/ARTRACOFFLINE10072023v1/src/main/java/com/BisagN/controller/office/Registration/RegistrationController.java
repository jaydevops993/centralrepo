package com.BisagN.controller.office.Registration;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.Part_b_examinationController;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_ARM_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.OFFICER_RESULTS_M;
import com.BisagN.models.officers.trans.ANSWER_BOOK_M;



@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class RegistrationController {
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	

	@Autowired
	CommonController comm;
	
	//======================================================OPEN PAGE========================================================//
			@RequestMapping(value = "RegistrationUrl", method = RequestMethod.GET)
			public ModelAndView RegistrationUrl(ModelMap Mmap, HttpSession session,
					@RequestParam(value = "msg", required = false) String msg,HttpServletRequest request)
					throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
					NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

				String es_begindate = session.getAttribute("es_begin_dateshow") == "" ? ""
						: session.getAttribute("es_begin_dateshow").toString();
				
				if (!es_begindate.equals("")) {
					Mmap.put("es_begindate", es_begindate);

				}
				
				
				Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		        if(flashMap != null){
		        	ArrayList<ArrayList<String>> errorList =  (ArrayList<ArrayList<String>>) flashMap.get("errorlist");
		            System.out.println(errorList);
		            //return "home";
		            Mmap.put("errorList",errorList);
		        }
//				 Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
				 Mmap.put("msg", msg);
			      return new ModelAndView("RegistrationTile");
			}
			
			
//		======================================ADD MANUAL REGISTRATION OPNE PAGE==================================================	
			
			
			@RequestMapping(value = "AddManualRegistrationUrl", method = RequestMethod.GET)
			public ModelAndView AddManualRegistrationUrl(ModelMap Mmap, HttpSession session,
					@RequestParam(value = "msg", required = false) String msg) {
			

				String es_begindate = session.getAttribute("es_begin_dateshow") == "" ? ""
						: session.getAttribute("es_begin_dateshow").toString();
				
				if (!es_begindate.equals("")) {
					Mmap.put("es_begindate", es_begindate);

				}
//				 Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
				 Mmap.put("msg", msg);
			      return new ModelAndView("Add_Manual_RegistrationTile");
			}	
			
			
			@RequestMapping(value = "/RegistrationAction", method = RequestMethod.POST)
			public ModelAndView RegistrationAction(HttpServletRequest request, ModelMap model, HttpSession session,RedirectAttributes ra,
					@RequestParam(value = "fileUpload1", required = false) MultipartFile fileUpload) {

				
				ArrayList<ArrayList<String>> listerror=new ArrayList<ArrayList<String>>();
				
				Session sessionHQL = this.sessionFactory.openSession();
				Transaction tx = sessionHQL.beginTransaction();
				
			
	String file= request.getParameter("fileUpload");
					if(file.equals("")) {
						 ra.addAttribute("msg","Please Upload Copy Of File Upload");
							  return new ModelAndView("redirect:UploadIndexingDataUrl");
						  }


				try {

					Date date = new Date();
					int count = Integer.parseInt(request.getParameter("count"));
					int es_id = Integer
							.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
					
					
					for (int i = 0; i < count; i++) {

						
						ArrayList<String> listData = new ArrayList<String>();
						String pers_code = request.getParameter("personal_no" + i);
//						String command = request.getParameter("command" + i);
						String centreid = request.getParameter("centre_code" + i);
						String month_year= request.getParameter("month_year" + i);
						
						 String es_year= month_year.split("-")[1];
						  	
						    String es_begindate = session.getAttribute("es_begin_date") == "" ? "": session.getAttribute("es_begin_date").toString();
					      String es_begindate_year= es_begindate.split("-")[0];
					  	
					  
					  	
					    
						
					OFFICER_APPLICATION_M ofa = new OFFICER_APPLICATION_M();
					  	if(es_begindate_year.equals(es_year)) {
					  		

							Query q0 = sessionHQL.createQuery(
									"select count(*) from OFFICER_APPLICATION_M where es_id=:es_id and oa_status_id=1 and oa_application_id=:oa_application_id");

							q0.setParameter("es_id", es_id);
							q0.setParameter("oa_application_id",Integer.parseInt(pers_code));
								Long c = (Long) q0.uniqueResult();		
								
							if (c == 0) {
					  		
								
								
					  		Query qry = sessionHQL.createQuery("update OFFICER_APPLICATION_M  set oa_status_id=:oa_status_id,oa_center_opted=:oa_center_opted where oa_application_id=:oa_application_id and es_id=:es_id");
							qry.setParameter("oa_status_id",1);
							qry.setParameter("oa_center_opted",Integer.parseInt(centreid));
							qry.setParameter("oa_application_id",Integer.parseInt(pers_code));
							qry.setParameter("es_id",es_id);
							qry.executeUpdate();
							
							
//							Query qry1 = sessionHQL.createQuery("update OFFICER_PERSONAL_DETAILS_M set cc_command_id=:cc_command_id where opd_personal_id=:opd_personal_id");
//							qry1.setParameter("cc_command_id",Integer.parseInt(command));
//							qry1.setParameter("opd_personal_id",opd_pers_id);
//							qry1.executeUpdate();
					  		
					  		
						
						 ra.addAttribute("msg","Register Data Saved Successfully");
							
						
					  			
							}else {
								 ra.addAttribute("msg","Register Data already exist");
								
							}
					  			
					}else {
						
						
						 listData.add(pers_code);
						 listData.add(centreid);
						 listData.add(month_year);
						
						
						 listData.add("Exam Schedule Not Matched with Current Exam Schedule");
					
						model.put("msg", "Exam Schedule Not Matched with Current Exam Schedule.");
					}
						 	
						
				
					  	if(!listData.isEmpty()) {
							listerror.add(listData);
						}
					}
					
						
					model.put("errorlist", listerror);
					model.put("errorlistsize", listerror.size());
					tx.commit();
					sessionHQL.close();
					
				} catch (Exception e) {
					tx.rollback();
					e.printStackTrace();
				} finally {
					if (sessionHQL != null) {
						sessionHQL.close();
					}
				}
				ra.addFlashAttribute("errorlist",listerror);
				ra.addFlashAttribute("errorlistsize",listerror.size());
				return new ModelAndView("redirect:RegistrationUrl");
			}
			
			
			
			@RequestMapping(value = "ManuauRegAction", method = RequestMethod.POST)
			public ModelAndView ManuauRegAction(ModelMap Mmap, HttpSession session,
					@RequestParam(value = "msg", required = false) String msg,  HttpServletRequest request) {

			
				Session sessionHQL = this.sessionFactory.openSession();

				try {

					Transaction tx = sessionHQL.beginTransaction();
					
					String application_no = request.getParameter("application_no");
//					String command = request.getParameter("command" + i);
					String centreid = request.getParameter("centre");
					String month_year= request.getParameter("month_year");
					
					int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
					
					Query q0 = sessionHQL.createQuery(
							"select count(*) from OFFICER_APPLICATION_M where es_id=:es_id and oa_status_id=1 and oa_application_id=:oa_application_id");

					q0.setParameter("es_id", es_id);
					q0.setParameter("oa_application_id",Integer.parseInt(application_no));
						Long c = (Long) q0.uniqueResult();	

					if (c == 0) {
						
						
						Query qry = sessionHQL.createQuery("update OFFICER_APPLICATION_M  set oa_status_id=:oa_status_id,oa_center_opted=:oa_center_opted where oa_application_id=:oa_application_id and es_id=:es_id");
						qry.setParameter("oa_status_id",1);
						qry.setParameter("oa_center_opted",Integer.parseInt(centreid));
						qry.setParameter("oa_application_id",Integer.parseInt(application_no));
						qry.setParameter("es_id",es_id);
						qry.executeUpdate();
						
						Mmap.put("msg","Register Data Saved Successfully");
						
					}

					else {
						Mmap.put("msg", "Data Already Exits.");
					}
					tx.commit();
				}

				catch (Exception e) {
					// tx.rollback();
					e.printStackTrace();
				} finally {
					if (sessionHQL != null) {
						sessionHQL.close();
					}
				}
				return new ModelAndView("redirect:RegistrationUrl");
			}
			
			@RequestMapping(value = "downloadAdmitSlipUrl", method = RequestMethod.GET)
			public ModelAndView downloadAdmitSlipUrl(ModelMap Mmap, HttpSession session,
					@RequestParam(value = "msg", required = false) String msg,HttpServletRequest request)
					throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
					NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

				String es_begindate = session.getAttribute("es_begin_dateshow") == "" ? "": session.getAttribute("es_begin_dateshow").toString();
				
				if (!es_begindate.equals("")) {
					Mmap.put("es_begindate", es_begindate);
				}

			      return new ModelAndView("downloadAdmitSlipTile");
			}
			
			
					  
}			  
		