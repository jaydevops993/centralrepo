package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "partb_d_application", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class PARTB_D_APPLICATION_M {

      private int id;
      private int oa_application_id;
      private int pbda_survey_india;
      private String pbda_survey_details;
      private int pbda_comp;
      private String pbda_comp_details;
      private int pbda_subjects;
      private int pbda_auth_pass_year;
      private String pbda_auth_pass_letterno;
      private int pbda_auth_page;
      private int pbda_auth_serno;
      private String pbda_immediate_super;
      private String pbda_add_corres1;
      private String pbda_add_corres2;
      private String pbda_add_corres3;
      private int pbda_sign_candidate;
      private int pbda_sign_co;
      private int pbda_eligible_subjects;
      private String pbda_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date pbda_creation_date;
      private String pbda_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date pbda_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getOa_application_id() {
           return oa_application_id;
      }
      public void setOa_application_id(int oa_application_id) {
	  this.oa_application_id = oa_application_id;
      }
      public int getPbda_survey_india() {
           return pbda_survey_india;
      }
      public void setPbda_survey_india(int pbda_survey_india) {
	  this.pbda_survey_india = pbda_survey_india;
      }
      public String getPbda_survey_details() {
           return pbda_survey_details;
      }
      public void setPbda_survey_details(String pbda_survey_details) {
	  this.pbda_survey_details = pbda_survey_details;
      }
      public int getPbda_comp() {
           return pbda_comp;
      }
      public void setPbda_comp(int pbda_comp) {
	  this.pbda_comp = pbda_comp;
      }
      public String getPbda_comp_details() {
           return pbda_comp_details;
      }
      public void setPbda_comp_details(String pbda_comp_details) {
	  this.pbda_comp_details = pbda_comp_details;
      }
      public int getPbda_subjects() {
           return pbda_subjects;
      }
      public void setPbda_subjects(int pbda_subjects) {
	  this.pbda_subjects = pbda_subjects;
      }
      public int getPbda_auth_pass_year() {
           return pbda_auth_pass_year;
      }
      public void setPbda_auth_pass_year(int pbda_auth_pass_year) {
	  this.pbda_auth_pass_year = pbda_auth_pass_year;
      }
      public String getPbda_auth_pass_letterno() {
           return pbda_auth_pass_letterno;
      }
      public void setPbda_auth_pass_letterno(String pbda_auth_pass_letterno) {
	  this.pbda_auth_pass_letterno = pbda_auth_pass_letterno;
      }
      public int getPbda_auth_page() {
           return pbda_auth_page;
      }
      public void setPbda_auth_page(int pbda_auth_page) {
	  this.pbda_auth_page = pbda_auth_page;
      }
      public int getPbda_auth_serno() {
           return pbda_auth_serno;
      }
      public void setPbda_auth_serno(int pbda_auth_serno) {
	  this.pbda_auth_serno = pbda_auth_serno;
      }
      public String getPbda_immediate_super() {
           return pbda_immediate_super;
      }
      public void setPbda_immediate_super(String pbda_immediate_super) {
	  this.pbda_immediate_super = pbda_immediate_super;
      }
      public String getPbda_add_corres1() {
           return pbda_add_corres1;
      }
      public void setPbda_add_corres1(String pbda_add_corres1) {
	  this.pbda_add_corres1 = pbda_add_corres1;
      }
      public String getPbda_add_corres2() {
           return pbda_add_corres2;
      }
      public void setPbda_add_corres2(String pbda_add_corres2) {
	  this.pbda_add_corres2 = pbda_add_corres2;
      }
      public String getPbda_add_corres3() {
           return pbda_add_corres3;
      }
      public void setPbda_add_corres3(String pbda_add_corres3) {
	  this.pbda_add_corres3 = pbda_add_corres3;
      }
      public int getPbda_sign_candidate() {
           return pbda_sign_candidate;
      }
      public void setPbda_sign_candidate(int pbda_sign_candidate) {
	  this.pbda_sign_candidate = pbda_sign_candidate;
      }
      public int getPbda_sign_co() {
           return pbda_sign_co;
      }
      public void setPbda_sign_co(int pbda_sign_co) {
	  this.pbda_sign_co = pbda_sign_co;
      }
      public int getPbda_eligible_subjects() {
           return pbda_eligible_subjects;
      }
      public void setPbda_eligible_subjects(int pbda_eligible_subjects) {
	  this.pbda_eligible_subjects = pbda_eligible_subjects;
      }
      public String getPbda_created_by() {
           return pbda_created_by;
      }
      public void setPbda_created_by(String pbda_created_by) {
	  this.pbda_created_by = pbda_created_by;
      }
      public Date getPbda_creation_date() {
           return pbda_creation_date;
      }
      public void setPbda_creation_date(Date pbda_creation_date) {
	  this.pbda_creation_date = pbda_creation_date;
      }
      public String getPbda_modified_by() {
           return pbda_modified_by;
      }
      public void setPbda_modified_by(String pbda_modified_by) {
	  this.pbda_modified_by = pbda_modified_by;
      }
      public Date getPbda_modification_date() {
           return pbda_modification_date;
      }
      public void setPbda_modification_date(Date pbda_modification_date) {
	  this.pbda_modification_date = pbda_modification_date;
      }
}
