package com.BisagN.dao.officer.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Service
public class VerifiedDsscOfficerDataDaoImpl implements VerifiedDsscDataDAO  {

	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();


			public boolean checkIsIntegerValue(String Search) {
				return Search.matches("[0-9]+");
			}
	public List<Map<String, Object>> getReportListGetDsscOfficerDetails(int startPage,String pageLength,String Search,String orderColunm,String orderType,String pers_no,String pers_name,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		if(pageLength.equals("-1")){
 			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search,pers_no,pers_name);
 		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		String q = "";
		String q1 = "";
		String q2 = "";
		
		
		try {
			conn = dataSource.getConnection();
			
			q = "select ROW_NUMBER() OVER(order by arms) as sr_no, arms, rank, ind_name, comd,id as tbl_id from upload_dssc_data_tbl_dum  "+SearchValue+" ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;

			PreparedStatement stmt = conn.prepareStatement(q);
			stmt = setQueryWhereClause_SQL(stmt,Search,pers_no,pers_name);
			
			
			System.out.println("stmt=======ssssss==fff========="+stmt);
			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
 			int columnCount = metaData.getColumnCount();
 			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
				    columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
                      String enckey ="commonPwdEncKeys";
	                    Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
	                    String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("tbl_id").toString().getBytes())));
	                    
//	                    
//                      String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"+EncryptedPk+"')}else{ return false;}\""; 
//                      String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
                      String Update = "onclick=\"  if (confirm('Are you sure you want to View?') ){ViiewData('"+EncryptedPk+"')}else{ return false;}\""; 
                      String updateButton = "<i class='action_icons action_view' " + Update + " title='View Data'></i>"; 
                      String f = "";

                      f += updateButton;
//                      f += deleteButton;
//                      columns.put("action",f);
                     columns.put(metaData.getColumnLabel(1), f);
			list.add(columns);
	}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {
	e.printStackTrace();
} finally {
if (conn != null) {
try {
	conn.close();
} catch (SQLException e) {
}
}
}
return list;
}

public long getGetDsscOfficerDetailsTotalCount(String Search,String pers_no,String pers_name) {
	String SearchValue = GenerateQueryWhereClause_SQL(Search,pers_no,pers_name);
	int total = 0;
	String q = null;
	Connection conn = null;
	String q1 = "";
	String q2 = "";
	
	try {
		conn = dataSource.getConnection();
		
		
			q ="select count(*) from (select  *  from upload_dssc_data_tbl_dum   "+SearchValue +") ab" ;
			
		PreparedStatement stmt = conn.prepareStatement(q);
		
		stmt = setQueryWhereClause_SQL(stmt,Search,pers_no,pers_name);
		
		
		ResultSet rs = stmt.executeQuery();
		
		while (rs.next()) {
			total = rs.getInt(1);
		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return (long) total;
}


public String GenerateQueryWhereClause_SQL(String Search,String pers_no,String pers_name) {
	String SearchValue ="";
	
	
	
	if (!pers_no.equals("") && pers_no != "" && pers_no != null) {
			SearchValue += " and lower(vw.opc_personal_code) like ?"; 
		}
		
		
		
		if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
			System.out.println("name===="+pers_name);
			SearchValue += " and lower(vw.opd_officer_name) like ?"; 
		}
		
		
		
	if(!Search.equals("")) {
	Search = Search.toLowerCase();
		SearchValue =" where ( ";
	if (checkIsIntegerValue(Search)) {
		SearchValue += " id=? or ";
	}
	String ct_comm_id = "";
	if (checkIsIntegerValue(Search)) {
		ct_comm_id += " ct_comm_id= ? ";
	}
		SearchValue +=" "+ct_comm_id+" lower(opd_unit) like ? or lower(opd_unit_address2) like ? or"
			+" to_char(opd_dob,'dd-MM-yyyy') like ? or "
				+ "to_char(opd_date_of_comm,'dd-MM-yyyy') like ? or to_char(opd_date_of_seniority,'dd-MM-yyyy') like ? or  "
				+ " lower(opd_remarks) like ? )";
	}
return SearchValue;
}


public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,String pers_no,String pers_name) {
	int flag = 0;
	try {
		
		

			if (!pers_no.equals("") && pers_no != "" && pers_no != null)  {
				flag += 1;
				stmt.setString(flag, "%" + pers_no + "%");
			}
			
			if (!pers_name.equals("") && pers_name != "" && pers_name != null)  {
				flag += 1;
				stmt.setString(flag, "%" + pers_name + "%");
			}
			
			
			
	if(!Search.equals("")) {
			if(checkIsIntegerValue(Search)) {
				flag += 1;
				stmt.setInt(flag, Integer.parseInt(Search));
			}
			if(checkIsIntegerValue(Search)) {
				flag += 1;
				stmt.setInt(flag, Integer.parseInt(Search));
			}
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			flag += 1;
			stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			
		}
	}catch (Exception e) {}
	return stmt;
}
}
