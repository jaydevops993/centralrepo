package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.Indexing.IndexingDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING;

import com.BisagN.models.officers.masters.EXAM_CODE_M;
@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class LockUnlockIndexingController {

	

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	
	@Autowired
	CommonController comm;
	
	@Autowired
	IndexingDAO indxDao;

	@RequestMapping(value = "Lock_UnlockIndeixngUrl", method = RequestMethod.GET)
	public ModelAndView Lock_UnlockIndeixngUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
  	
		String es_begin_dateshow = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

	
			if (!es_begin_dateshow.equals("")) {
				Mmap.put("partb_begindate", es_begin_dateshow);
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
			if (ec_exam_id != 0) {
				Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
				List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
				Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
				
			}
			
			
	 Mmap.put("msg",msg);
	 return new ModelAndView("Lock/unlockIndexingTiles");
}
	
	
	
	@RequestMapping(value = "/LockunlockIndexing", method = RequestMethod.POST)
	public ModelAndView LockunlockIndexing(ModelMap Mmap, HttpSession session,HttpServletRequest request, String index_mode, String subject_id1) {
		
		
		
	
	

	  Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
		try {
			
			
		Date date = new Date();
		EXAMSCHEDULE_INDEXING exmsch_indx = new EXAMSCHEDULE_INDEXING();
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			 Query q0 = sessionHQL.createQuery("select count(*) from EXAMSCHEDULE_INDEXING  where esi_es_id=:esi_es_id ");
				q0.setParameter("esi_es_id",es_id );
		Long c = (Long) q0.uniqueResult();
		
		
		
		
		System.err.println("index_mode==6====="+index_mode);
			
	if (c == 0  ) {
		System.err.println("c======="+c);
		
		//if(index_mode.equals("1")) {
			
	
		exmsch_indx.setEsi_createdate(date);
		exmsch_indx.setEsi_es_id(es_id);
		
		exmsch_indx.setEsi_islocked(Integer.parseInt(index_mode));
		exmsch_indx.setEsi_dtupdatetime(date);
		
		sessionHQL.save(exmsch_indx);
		if(index_mode.equals("1")){
			Mmap.put("msg", "Indexing Unlock Successfully");
			EXAMSCHEDULE_INDEXING ewid =(EXAMSCHEDULE_INDEXING)sessionHQL.get(EXAMSCHEDULE_INDEXING.class,es_id) ;
			  request.getSession().setAttribute("esi_es_id", ewid.getEsi_es_id());
	
		}else {
			Mmap.put("msg", "Indexing Lock Successfully");
			EXAMSCHEDULE_INDEXING ewid =(EXAMSCHEDULE_INDEXING)sessionHQL.get(EXAMSCHEDULE_INDEXING.class,es_id) ;
			  request.getSession().setAttribute("esi_es_id", 0);
			
		}
		

		//}
		
		
	
			
			
			
			

			   
		}else {
			
			System.err.println("index_mode---------"+index_mode);
			
			
			
			String hq15 = "update EXAMSCHEDULE_INDEXING set esi_islocked=:esi_islocked,esi_updateddate=:esi_updateddate where esi_es_id=:esi_es_id";
			Query query5 = sessionHQL.createQuery(hq15)
					
						.setParameter("esi_islocked",Integer.parseInt(index_mode))	
						.setParameter("esi_updateddate",date)	
						
						.setParameter("esi_es_id", es_id);
		
			if(index_mode.equals("1")){
				Mmap.put("msg", "Indexing Unlock Successfully");
				EXAMSCHEDULE_INDEXING ewid =(EXAMSCHEDULE_INDEXING)sessionHQL.get(EXAMSCHEDULE_INDEXING.class,es_id) ;
				  request.getSession().setAttribute("esi_es_id", ewid.getEsi_es_id());
		
			}else {
				Mmap.put("msg", "Indexing Lock Successfully");
				EXAMSCHEDULE_INDEXING ewid =(EXAMSCHEDULE_INDEXING)sessionHQL.get(EXAMSCHEDULE_INDEXING.class,es_id) ;
				  request.getSession().setAttribute("esi_es_id", 0);
				
			}
			query5.executeUpdate();
		}
	
	

	tx.commit();
	

		}
		
		catch (RuntimeException e) {
			try {
				tx.rollback();
				Mmap.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				Mmap.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return new ModelAndView("redirect:Lock_UnlockIndeixngUrl"); 
		}	
	
}
