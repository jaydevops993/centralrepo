package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "dssc_tsoc_start_date", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class DSSC_TSOC_START_DATE_M {

      private int id;
      private int es_id;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dtsd_dssc;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dtsd_tsoc_tech;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date dtsd_tsoc_nontech;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getEs_id() {
           return es_id;
      }
      public void setEs_id(int es_id) {
	  this.es_id = es_id;
      }
      public Date getDtsd_dssc() {
           return dtsd_dssc;
      }
      public void setDtsd_dssc(Date dtsd_dssc) {
	  this.dtsd_dssc = dtsd_dssc;
      }
      public Date getDtsd_tsoc_tech() {
           return dtsd_tsoc_tech;
      }
      public void setDtsd_tsoc_tech(Date dtsd_tsoc_tech) {
	  this.dtsd_tsoc_tech = dtsd_tsoc_tech;
      }
      public Date getDtsd_tsoc_nontech() {
           return dtsd_tsoc_nontech;
      }
      public void setDtsd_tsoc_nontech(Date dtsd_tsoc_nontech) {
	  this.dtsd_tsoc_nontech = dtsd_tsoc_nontech;
      }
}
