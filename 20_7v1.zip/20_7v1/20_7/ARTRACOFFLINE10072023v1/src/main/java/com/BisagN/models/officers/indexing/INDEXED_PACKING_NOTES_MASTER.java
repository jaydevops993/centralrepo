package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "indexed_packing_notes_master", uniqueConstraints = {
@UniqueConstraint(columnNames = "ipnm_id"),})
public class INDEXED_PACKING_NOTES_MASTER {
	
	private int  ipnm_id;
	private int ipnm_es_id;
	private String ipnm_no;
	private String ipnm_bag_no;
	private int ipnm_iu_user_id;
	private Date ipnm_createddate;
	private int ipnm_status_id;
	private int ipnm_final_status_id;
	
	
	 @Id
     @GeneratedValue(strategy = IDENTITY)
     @Column(name = "ipnm_id", unique = true, nullable = false)
	public int getIpnm_id() {
		return ipnm_id;
	}
	public void setIpnm_id(int ipnm_id) {
		this.ipnm_id = ipnm_id;
	}
	public int getIpnm_es_id() {
		return ipnm_es_id;
	}
	public void setIpnm_es_id(int ipnm_es_id) {
		this.ipnm_es_id = ipnm_es_id;
	}
	public String getIpnm_no() {
		return ipnm_no;
	}
	public void setIpnm_no(String ipnm_no) {
		this.ipnm_no = ipnm_no;
	}
	public String getIpnm_bag_no() {
		return ipnm_bag_no;
	}
	public void setIpnm_bag_no(String ipnm_bag_no) {
		this.ipnm_bag_no = ipnm_bag_no;
	}
	public int getIpnm_iu_user_id() {
		return ipnm_iu_user_id;
	}
	public void setIpnm_iu_user_id(int ipnm_iu_user_id) {
		this.ipnm_iu_user_id = ipnm_iu_user_id;
	}
	public Date getIpnm_createddate() {
		return ipnm_createddate;
	}
	public void setIpnm_createddate(Date ipnm_createddate) {
		this.ipnm_createddate = ipnm_createddate;
	}
	public int getIpnm_status_id() {
		return ipnm_status_id;
	}
	public void setIpnm_status_id(int ipnm_status_id) {
		this.ipnm_status_id = ipnm_status_id;
	}
	public int getIpnm_final_status_id() {
		return ipnm_final_status_id;
	}
	public void setIpnm_final_status_id(int ipnm_final_status_id) {
		this.ipnm_final_status_id = ipnm_final_status_id;
	}
	
	
	

}
 