package com.BisagN.dao.officer.others;

import java.util.ArrayList;

public interface AdmitcardDao {
	public ArrayList<ArrayList<String>> getOfrsAdmitCardDetails(String opd_personal_code) ;
}
