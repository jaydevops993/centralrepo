package com.BisagN.controller.office.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.officer.trans.VerifiedDsscDataDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXING_SETTING;
import com.BisagN.models.officers.trans.UPLOAD_DSSC_DATA_TBL_DUM;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class VerifyDsscDataController {

	
	

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	VerifiedDsscDataDAO vsdao;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	

	@RequestMapping(value = "SearchVerifyDsscDataUrl", method = RequestMethod.GET)
	public ModelAndView SearchVerifyDsscDataUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		 
		 	 
			String es_begindate = session.getAttribute("es_begin_date") == null ? "": session.getAttribute("es_begin_date").toString();		
			int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

			if (ec_exam_id == 3) {
				if (!es_begindate.equals("")) {
					Mmap.put("dssc_begindate", es_begindate.substring(0, 10));
				}
				if (es_id != 0) {
					Mmap.put("es_id", es_id);
				}
				
			}
			 Mmap.put("msg",msg);
		  
		     
		return new ModelAndView("VerifyDsscData_tiles");
	}
	
	
	@RequestMapping(value = "/GetDsscOfficerDetails", method = RequestMethod.POST)
	public @ResponseBody List<Map<String, Object>> GetDsscOfficerDetails(int startPage,
			String pageLength, String Search, String orderColunm, String orderType, String pers_no,String pers_name,
			 HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException,
			IllegalBlockSizeException, BadPaddingException {

		return vsdao.getReportListGetDsscOfficerDetails(startPage, pageLength, Search, orderColunm,
				orderType, pers_no,pers_name, sessionUserId);
	}

	@RequestMapping(value = "/GetDsscOfficerDetailsTotalCount", method = RequestMethod.POST)
	public @ResponseBody long GetDsscOfficerDetailsTotalCount(HttpSession sessionUserId, String Search,
			String pers_no,String pers_name) {
		return vsdao.getGetDsscOfficerDetailsTotalCount(Search,pers_no,pers_name);
	}
	
	
	@RequestMapping(value = "/ViewDsscOfficerDetails", method = RequestMethod.POST)
	public ModelAndView ViewDsscOfficerDetails(ModelMap Mmap, @RequestParam(value = "msg", required = false) String msg,HttpSession session, HttpServletRequest request,
			String updateid) {

		
		
		  Session s1 = this.sessionFactory.openSession();
          Transaction tx = s1.beginTransaction();
          String enckey = "commonPwdEncKeys";  
          String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
          Query q = null;
          q = s1.createQuery("from UPLOAD_DSSC_DATA_TBL_DUM where cast(id as string)=:PK");
          q.setString("PK", DcryptedPk);
          @SuppressWarnings("unchecked")
          List<UPLOAD_DSSC_DATA_TBL_DUM> list = (List<UPLOAD_DSSC_DATA_TBL_DUM>) q.list();
          
          //System.err.println("list============="+list.get(0));

          tx.commit();
          s1.close();
          Mmap.put("viewDsscOffDetails", list.get(0));
          Mmap.put("msg", msg);
       
		
		return new ModelAndView("ViewDsscOffcrDetails_tiles");

	}
}
