package com.BisagN.controller.office_DSSC_MeritRerport;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.controller.office_DSSC_Report.FailedCadidatePDFReportController;
import com.BisagN.controller.office_DSSC_Report.ReserveListDSSC_DSTSCPdfReportController;
import com.BisagN.dao.officer.others.ExaminationlockunlockDAO;
import com.BisagN.dao.officer.report.DSSCMeritReportDao;
import com.BisagN.dao.officer.report.DSSC_DSTSC_REPORTDAO;
import com.BisagN.models.officers.others.DSSC_COURSE_VACANCY_RESERVE;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class merit_list_DSSC_controller {

	@Autowired
	private ExaminationlockunlockDAO exmunlockDao;

	@Autowired
	private DSSCMeritReportDao DSSCDao;
	
	@Autowired
	private DSSC_DSTSC_REPORTDAO DSSCDaoforFail_Reserve;
	
	 
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	CommonController comm = new CommonController();


	// ===========================OPEN PAGE============================//
	@RequestMapping(value = "MeritliatDSSCURL", method = RequestMethod.GET)
	public ModelAndView MeritliatDSSCURL(ModelMap Mmap, HttpSession session, HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		ArrayList<ArrayList<String>> list2 = exmunlockDao.getbegindatefrmexmschedule(3);
		Mmap.put("DSSC_Begindate", list2);
		Mmap.put("msg", msg);
		return new ModelAndView("MeritlistreportTiles");
	}

	@RequestMapping(value = "/getMERIT_DSSC_DSTSC_Report", method = RequestMethod.POST)
	public ModelAndView getDSSC_DSTSC_Report(ModelMap Mmap, HttpSession session, HttpServletRequest request,
			String typeReport, String es_id, String reportname1) {
		try {
		 
			
			int es_id1 = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			
			List<DSSC_COURSE_VACANCY_RESERVE> getdsscCourseVacancyReserveList= comm.getdsscCourseVacancyReserveList( sessionFactory, es_id1);

			

			Mmap.put("getdsscCourseVacancyReserveListForDSSC", getdsscCourseVacancyReserveList.get(0).getDssc_course_no());
			Mmap.put("getdsscCourseVacancyReserveListForDSTSC", getdsscCourseVacancyReserveList.get(1).getDssc_course_no());
			Mmap.put("getdsscCourseVacancyReserveListForALMC", getdsscCourseVacancyReserveList.get(2).getDssc_course_no());
			Mmap.put("getdsscCourseVacancyReserveListForISC", getdsscCourseVacancyReserveList.get(3).getDssc_course_no());

			if (es_id.equals("0")) {
				Mmap.put("msg", "Please Select Subject");
				return new ModelAndView("redirect:MeritliatDSSCURL");
			}

			if (reportname1.equals("0")) {
				Mmap.put("msg", "Please Select Report");
				return new ModelAndView("redirect:MeritliatDSSCURL");
			}
			if (reportname1.equals("8")) {
				ArrayList<ArrayList<String>> list = DSSCDao.getMeritListforALMC_ISC(Integer.parseInt(es_id),
						reportname1);
				Mmap.put("list", list);

				Mmap.put("list.size()", list.size());
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (list.size() > 0) {

						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(
								new MeritALMC_ISCReportPdf_controller("L", TH, Heading, username, "ALMC/ISC"),
								"userList", list);

					}
				}

			} else if (reportname1.equals("5") || reportname1.equals("6")) {

				ArrayList<ArrayList<String>> list = DSSCDao.getMeritListforDSSC(Integer.parseInt(es_id), reportname1);
				System.err.println("list===" + list);
				String coursename = "";
				if (list.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {

					if (reportname1.equals("5")) {
						coursename = "DSSC";
					} else if (reportname1.equals("6")) {
						coursename = "DSTSC";
					} else if (reportname1.equals("8")) {
						coursename = "ALMC/ISC";
					}
					Mmap.put("list", list);

					Mmap.put("list.size()", list.size());
					if (typeReport != null && typeReport.equals("pdfL")) {
						if (list.size() > 0) {

							List<String> TH = new ArrayList<String>();
							String Heading = "";
							String username = session.getAttribute("username").toString();
							return new ModelAndView(
									new MeritDSSCReportPdf_controller("L", TH, Heading, username, coursename),
									"userList", list);

						}
					}
				}
			} else if (reportname1.equals("9") || reportname1.equals("10")) {
				if (reportname1.equals("9")) {
					reportname1 = "5";
				}
				else if(reportname1.equals("10")) {
					reportname1 = "6";
				}
				
				ArrayList<ArrayList<String>> list = DSSCDao.getMeritListforDSSC(Integer.parseInt(es_id), reportname1);
				System.err.println("es_id===" + Integer.parseInt(es_id));
				System.err.println("reportname1===" + reportname1);
				System.err.println("list===" + list);
				System.err.println("list Size===" + list.size());
				String coursename = "";
				if (list.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {

					if (reportname1.equals("5")) {
						coursename = "DSSC";
					} else if (reportname1.equals("6")) {
						coursename = "DSTSC";
					} else if (reportname1.equals("8")) {
						coursename = "ALMC/ISC";
					}
					Mmap.put("list", list);

					Mmap.put("list.size()", list.size());
					if (typeReport != null && typeReport.equals("pdfL")) {
						if (list.size() > 0) {

							List<String> TH = new ArrayList<String>();
							String Heading = "";
							String username = session.getAttribute("username").toString();
							return new ModelAndView(
									new MeritDSSCReportForIndexPdf_controller("L", TH, Heading, username, coursename),
									"userList", list);

						}
					}
				}
			}
			
			else if(reportname1.equals("11")) {
				if(reportname1.equals("11")) {
					reportname1 = "8";
				}
				
				ArrayList<ArrayList<String>> list = DSSCDao.getMeritListforALMC_ISC(Integer.parseInt(es_id),
						reportname1);
				Mmap.put("list", list);
				System.err.println("list===" + list);
				Mmap.put("list.size()", list.size());
				if (typeReport != null && typeReport.equals("pdfL")) {
					if (list.size() > 0) {

						List<String> TH = new ArrayList<String>();
						String Heading = "";
						String username = session.getAttribute("username").toString();
						return new ModelAndView(
								new MeritALMC_ISCReportForIndexNoPdf_controller2("L", TH, Heading, username, "ALMC/ISC"),
								"userList", list);

					}
				}
			}
			else if (reportname1.equals("12")) {

				ArrayList<ArrayList<String>> list1 = DSSCDao.getOverallReport(Integer.parseInt(es_id));

				if (list1.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {

					Mmap.put("list", list1);
					Mmap.put("list.size()", list1.size());

					if (typeReport != null && typeReport.equals("pdfL")) {
						if (list1.size() > 0) {

							List<String> TH = new ArrayList<String>();
							String Heading = "";
							String username = session.getAttribute("username").toString();
						
							
							
							
							return new ModelAndView(new OverallReportPdf_controller("L", TH, Heading, username),"userList",list1);

						}
					}
				}
			}
			

			else if(reportname1.equals("13")) {
				
				
				ArrayList<ArrayList<String>> list = DSSCDaoforFail_Reserve.getfailofficeristReport(Integer.parseInt(es_id));

				if (list.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {

					Mmap.put("list", list);
					Mmap.put("list.size()", list.size());

					if (typeReport != null && typeReport.equals("pdfL")) {
						if (list.size() > 0) {
							List<String> TH = new ArrayList<String>();
							String Heading = "";
							String username = session.getAttribute("username").toString();
							return new ModelAndView(new FailedCadidatePDFReportController("L", TH, Heading, username));

						}
					}
				}
			}
			
			else if(reportname1.equals("14")) {
				
				
				ArrayList<ArrayList<String>> list = DSSCDaoforFail_Reserve.getreserveofficeristReport(Integer.parseInt(es_id));
				
				if (list.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {
					Mmap.put("list", list);
					Mmap.put("list.size()", list.size());
						
						if (typeReport != null && typeReport.equals("pdfL")) {
						if (list.size() > 0) {
								List<String> TH = new ArrayList<String>();
								String Heading = "";
								String username = session.getAttribute("username").toString();
								return new ModelAndView(new ReserveListDSSC_DSTSCPdfReportController("L", TH, Heading, username));


							}
						}
					}
			}
			else if (reportname1.equals("15")) {
				
				ArrayList<ArrayList<String>> list = DSSCDao.getCutoffRepoerforDSSC(Integer.parseInt(es_id), reportname1);
				System.err.println("es_id===" + Integer.parseInt(es_id));
				System.err.println("reportname1===" + reportname1);
				System.err.println("list===" + list);
				System.err.println("list Size===" + list.size());
				String coursename = "";
				if (list.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {

//					if (reportname1.equals("5")) {
//						coursename = "DSSC";
//					} else if (reportname1.equals("6")) {
//						coursename = "DSTSC";
//					} else if (reportname1.equals("8")) {
//						coursename = "ALMC/ISC";
//					}
					Mmap.put("list", list);

					Mmap.put("list.size()", list.size());
					if (typeReport != null && typeReport.equals("pdfL")) {
						if (list.size() > 0) {

							List<String> TH = new ArrayList<String>();
							String Heading = "";
							String username = session.getAttribute("username").toString();
							return new ModelAndView(
									new CutOffReportForDSSC_controller("L", TH, Heading, username, coursename),
									"userList", list);

						}
					}
				}
			}
			
	else if (reportname1.equals("16")) {
		System.err.println("es_id===" + Integer.parseInt(es_id));
		ArrayList<ArrayList<String>> getcompatativemeritlistReport = DSSCDaoforFail_Reserve.getcompatativemeritlistReport((Integer.parseInt(es_id)));
//				ArrayList<ArrayList<String>> list = DSSCDao.getCutoffRepoerforDSSC(Integer.parseInt(es_id), reportname1);
				System.err.println("es_id===" + Integer.parseInt(es_id));
				System.err.println("reportname1===" + reportname1);
//				System.err.println("list===" + list);
//				System.err.println("list Size===" + list.size());
				String coursename = "";
				if (getcompatativemeritlistReport.size() == 0) {

					Mmap.put("msg", "Data Not Available.");
				} else {

//					if (reportname1.equals("5")) {
//						coursename = "DSSC";
//					} else if (reportname1.equals("6")) {
//						coursename = "DSTSC";
//					} else if (reportname1.equals("8")) {
//						coursename = "ALMC/ISC";
//					}
					Mmap.put("list", getcompatativemeritlistReport);

					Mmap.put("list.size()", getcompatativemeritlistReport.size());
					if (typeReport != null && typeReport.equals("pdfL")) {
						if (getcompatativemeritlistReport.size() > 0) {

							List<String> TH = new ArrayList<String>();
							String Heading = "";
							String username = session.getAttribute("username").toString();
							return new ModelAndView(
									new Compititive_Report_controllerPdf("L", TH, Heading, username, coursename),
									"userList", getcompatativemeritlistReport);

						}
					}
				}
			}
			
	else if(reportname1.equals("17")) {
		
		ArrayList<ArrayList<String>> getnominateddssclistReport = DSSCDaoforFail_Reserve.getnominateddssclistReport(Integer.parseInt(es_id));
//		ArrayList<ArrayList<String>> list = DSSCDao.getMeritListforALMC_ISC(Integer.parseInt(es_id),
				
		Mmap.put("list", getnominateddssclistReport);
		System.err.println("list===" + getnominateddssclistReport);
		Mmap.put("list.size()", getnominateddssclistReport.size());
		if (typeReport != null && typeReport.equals("pdfL")) {
			if (getnominateddssclistReport.size() > 0) {

				List<String> TH = new ArrayList<String>();
				String Heading = "";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(
						new MeritDSSCReport_controller("L", TH, Heading, username, "DSSC"),
						"userList", getnominateddssclistReport);

			}
		}
	}
	
else if(reportname1.equals("18")) {
ArrayList<ArrayList<String>> getnominateddstsclistReport = DSSCDaoforFail_Reserve.getnominateddstsclistReport(Integer.parseInt(es_id));
//		ArrayList<ArrayList<String>> list = DSSCDao.getMeritListforALMC_ISC(Integer.parseInt(es_id),
				
		Mmap.put("list", getnominateddstsclistReport);
		System.err.println("list===" + getnominateddstsclistReport);
		Mmap.put("list.size()", getnominateddstsclistReport.size());
		if (typeReport != null && typeReport.equals("pdfL")) {
			if (getnominateddstsclistReport.size() > 0) {

				List<String> TH = new ArrayList<String>();
				String Heading = "";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(
						new MeritDSTSCReport_controller("L", TH, Heading, username, "DSSC"),
						"userList", getnominateddstsclistReport);

			}
		}
	}
	else if (reportname1.equals("19")) {

		ArrayList<ArrayList<String>> list1 = DSSCDaoforFail_Reserve.getALMC_ISCmeritlistReport(Integer.parseInt(es_id));

		if (list1.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {

			Mmap.put("list", list1);
			Mmap.put("list.size()", list1.size());

			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list1.size() > 0) {

					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new ALMCISC_Report_controllerPdf("L", TH, Heading, username, username),"userList",list1);

				}
			}
		}
	}
			
	else if (reportname1.equals("20")) {

		ArrayList<ArrayList<String>> list1 = DSSCDao.getUpgradationRepoerforDSTSCTODSSC(Integer.parseInt(es_id));

		if (list1.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {

			Mmap.put("list", list1);
			Mmap.put("list.size()", list1.size());

			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list1.size() > 0) {

					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new UpgradationDstscToDssc("L", TH, Heading, username, username));

				}
			}
		}
	}
			
			
	else if (reportname1.equals("21")) {

		ArrayList<ArrayList<String>> list1 = DSSCDao.getUpgradationRepoerforRESERVETODSSCDSTSC(Integer.parseInt(es_id));

		if (list1.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {

			Mmap.put("list", list1);
			Mmap.put("list.size()", list1.size());

			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list1.size() > 0) {

					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new UpgradationReserveToDssc("L", TH, Heading, username, username));

				}
			}
		}
	}
			
//	else if (reportname1.equals("22")){
//
//		ArrayList<ArrayList<String>> list1 = DSSCDao.getUpgradationRepoerforDSTSCTODSSC(Integer.parseInt(es_id));
//
//		if (list1.size() == 0) {
//
//			Mmap.put("msg", "Data Not Available.");
//		} else {
//
//			Mmap.put("list", list1);
//			Mmap.put("list.size()", list1.size());
//
//			if (typeReport != null && typeReport.equals("pdfL")) {
//				if (list1.size() > 0) {
//
//					List<String> TH = new ArrayList<String>();
//					String Heading = "";
//					String username = session.getAttribute("username").toString();
//					return new ModelAndView(new UpgradationReserveToDstsc("L", TH, Heading, username, username));
//
//				}
//			}
//		}
//	}
			
	else if (reportname1.equals("23")){

		ArrayList<ArrayList<String>> list1 =  DSSCDao.getUpgradationRepoerforRESERVETOALMCISC(Integer.parseInt(es_id));

		if (list1.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {

			Mmap.put("list", list1);
			Mmap.put("list.size()", list1.size());

			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list1.size() > 0) {

					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new UpgradationReservetoAlmcIsc("L", TH, Heading, username, username));

				}
			}
		}
	}
	else if (reportname1.equals("24")) {

		ArrayList<ArrayList<String>> list1 = DSSCDao.getUpgradationRepoerforWITHDRAWALFORNOMINATION(Integer.parseInt(es_id));
System.err.println("list1=========="+list1);
		if (list1.size() == 0) {

			Mmap.put("msg", "Data Not Available.");
		} else {

			Mmap.put("list", list1);
			Mmap.put("list.size()", list1.size());

			if (typeReport != null && typeReport.equals("pdfL")) {
				if (list1.size() > 0) {

					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new WithdrawalForNomination("L", TH, Heading, username, username),"userList1",list1);

				}
			}
		}
	}	
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("redirect:MeritliatDSSCURL");
	}

	
	@RequestMapping(value = "/getMERIT_ExportExcel", method = RequestMethod.POST)
	public ModelAndView getMERIT_ExportExcel(ModelMap Mmap, HttpSession session,
			HttpServletRequest request, String typeReport1, String es_id1,String reportname2) {
		
		if(es_id1.equals("0")) {
			Mmap.put("msg","Please Select Subject");
			  return new ModelAndView("redirect:MeritliatDSSCURL");
		  }
//			 System.err.println("es_id==="+es_id1);
			 
		else if (reportname2.equals("12")) {	
		ArrayList<ArrayList<String>> exportPartDSSC_DSTSC =  DSSCDao.getOverallReport(Integer.parseInt(es_id1));
		 
			if (exportPartDSSC_DSTSC.size() > 0) {	 

				System.err.println("kxfmgdsgdfsdf");
			ArrayList<ArrayList<String>> listexport=new ArrayList<ArrayList<String>>();
			List<String> TH = new ArrayList<String>();
			 
			TH.add("S NO.");//1
			TH.add("PERSONAL NO");//2
			TH.add("RANK");//3
			TH.add("NAME");//4
			TH.add("ARM / SERVICE");//5
			TH.add("TAC A");//6
			TH.add("TAC B");//7
			TH.add("A & L");	//8
			TH.add("CA");//9
			TH.add("SMT");//10
			TH.add("MH");//11
			TH.add("TOTAL");
			TH.add("FD");//12
			TH.add("CPV");//13
			TH.add("700");
			TH.add("1000");
			TH.add("CH 1");//17
			TH.add("CH 2");//18
			TH.add("CH 1" );//19
			TH.add("CH 2" );//20
			TH.add("MERIT");//21
			TH.add("NOMINATED FOR");//22
				
			String Heading = "\n";
			String username = session.getAttribute("username").toString();
			return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList", exportPartDSSC_DSTSC);
			
			}
		}
		
		else if (reportname2.equals("15")) {
 
			ArrayList<ArrayList<String>> exportPartDSSC_DSTSC =  DSSCDao.getCutoffRepoerforDSSC(Integer.parseInt(es_id1), reportname2);
			if (exportPartDSSC_DSTSC.size() > 0) {	 

				System.err.println("kxfmgdsgdfsdf");
			ArrayList<ArrayList<String>> listexport=new ArrayList<ArrayList<String>>();
			List<String> TH = new ArrayList<String>();
			  
			TH.add("S NO"); 
			TH.add("NOMINATED FOR" ); 
			TH.add("TAC A");  
			TH.add("TAC B");  
			TH.add("A & L");  
			TH.add("CA");  
			TH.add("SMT" ); 
			TH.add("MH"); 
				
			String Heading = "\n";
			String username = session.getAttribute("username").toString();
			return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList", exportPartDSSC_DSTSC);
			
			}
//			return new ModelAndView("redirect:MeritliatDSSCURL");
			return null;
		}
//			return new ModelAndView("redirect:MeritliatDSSCURL");
			return null;
}
 
	
	
}
