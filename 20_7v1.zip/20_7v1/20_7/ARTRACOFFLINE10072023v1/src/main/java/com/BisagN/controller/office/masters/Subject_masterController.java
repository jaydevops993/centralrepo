package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.controller.office.trans.Examination_centreController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.Rank_code_masterDAO;
import com.BisagN.dao.officer.masters.SUBJECT_MASTERDAO;
import com.BisagN.models.officers.masters.ARM_CODES_M;
import com.BisagN.models.officers.masters.RANK_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_CHILD_TBL;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;



@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Subject_masterController {

	@Autowired
	Examination_centreController exmCon = new Examination_centreController();
	
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private SUBJECT_MASTERDAO subDAO;
	
	
	@Autowired
	CommonController comm= new CommonController();
	
	 @Autowired
		private RoleBaseMenuDAO roledao; 
	
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	  @RequestMapping(value = "SearchSubject_master_Url", method = RequestMethod.GET)
      public ModelAndView SearchSubject_master_Url(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{
		  
		  if(request.getHeader("Referer") == null ) { 
 			 session.invalidate();
 			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
 			 return new ModelAndView("redirect:/login");
 		 }

     	 String roleid1 = session.getAttribute("roleid").toString();
 		 Boolean val = roledao.ScreenRedirect("SearchSubject_master_Url", roleid1);		
 			if(val == false) {
 				return new ModelAndView("AccessTiles");
 		}	
		  
		  
		   Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
		   Mmap.put("getctarmcodetypeListDDL",comm.getctarmcodetypeListDDL(sessionFactory));
		   
          Mmap.put("msg", msg);
      return new ModelAndView("SearchSubjectmasterTile");
}
	  
	  
	  @RequestMapping(value = "Subject_master_Url", method = RequestMethod.POST)
	  public ModelAndView Subject_master_Url(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String Subjectid) {
	  
	  
		  Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
		  Mmap.put("getctarmcodetypeListDDL",comm.getctarmcodetypeListDDL(sessionFactory));
		  
		  
		 
		   
          Mmap.put("msg", msg);
      return new ModelAndView("SubjectmasterTile");
}
	  
	  
	  @RequestMapping(value = "/Examination_MasterAction" ,method = RequestMethod.POST) 
	  public ModelAndView Examination_MasterAction(@Valid @ModelAttribute("examination_masterCMD") SUBJECT_CODE_M ln, BindingResult result, 
	  HttpServletRequest request, ModelMap model, HttpSession session){ 

	 

	 int errCount=0;
	 
	 String username = session.getAttribute("username").toString();
		Date date = new Date();
   
		 int id = ln.getSc_subject_id() > 0 ? ln.getSc_subject_id() : 0;
			
			 Session sessionHQL = this.sessionFactory.openSession();
			    Transaction tx = sessionHQL.beginTransaction(); 
			    
			    String sc_subject_name=request.getParameter("sc_subject_name").trim();
				if(sc_subject_name == "" || sc_subject_name.equals("")) {
					model.put("msg", "Please Enter Subject Name");		
				return new ModelAndView("redirect:SearchSubject_master_Url");
				}
			 

				String sc_form_caption=request.getParameter("sc_form_caption").trim();
				 if(sc_form_caption == "" || sc_form_caption.equals("")) {
						model.put("msg", "Please Enter Subject Caption");		
				return new ModelAndView("redirect:SearchSubject_master_Url");
				}	
				
				
					String sub_arm_name=request.getParameter("sub_arm_name_id");
					System.err.println("sub_arm_name--- "+sub_arm_name);
					
					if( sub_arm_name.equals(""))
							
			        {
				    	model.put("msg", "Please Select Arm/Service");
						return new ModelAndView("redirect:SearchSubject_master_Url");
			        }


					
					String sc_max_marks=request.getParameter("sc_max_marks");
					if(sc_max_marks == "" || sc_max_marks.equals("")) {
						model.put("msg", "Please Enter Max Marks");		
						return new ModelAndView("redirect:SearchSubject_master_Url");
					}
			    
			    

			try {
				  String sub_dt=request.getParameter("sub_date");
				Query q0 = sessionHQL.createQuery(
						"select count(id) from SUBJECT_CODE_M where   LOWER(sc_subject_name)=:sc_subject_name and "
						+ "  ec_exam_id=:ec_exam_id and id!=:id");

				q0.setParameter("sc_subject_name", ln.getSc_subject_name().toLowerCase());
				q0.setParameter("ec_exam_id", ln.getEc_exam_id());
				q0.setParameter("id", id);
				Long c = (Long) q0.uniqueResult();

				
				if (id == 0) {
					
					
					if (c == 0) {

						 Query q = null;
			             q = sessionHQL.createQuery("from SUBJECT_CODE_M where  ec_exam_id=:ec_exam_id order by sc_subject_code desc ");
			             q.setParameter("ec_exam_id", ln.getEc_exam_id());
			             @SuppressWarnings("unchecked")
			             List<SUBJECT_CODE_M> list = (List<SUBJECT_CODE_M>) q.list();
						System.err.println("list===="+list.get(0).getSc_subject_code());
						   int sub_code= list.get(0).getSc_subject_code();
						   
						   
						   
						   ln.setSc_created_by(username);
						   ln.setSc_creation_date(date);
							ln.setSc_form_caption(request.getParameter("sc_form_caption"));
						   	ln.setSub_date(sub_dt);
					        ln.setSc_status_id(1);
					        ln.setSc_subject_code(sub_code*2);
							int mid = (int)sessionHQL.save(ln);
							sessionHQL.flush();
							sessionHQL.clear();
							tx.commit();
							
							SUBJECT_CODE_CHILD_TBL sub_ch = new SUBJECT_CODE_CHILD_TBL();
							
							 String arm_id = request.getParameter("sub_arm_name_id");
								String[] arrOfStr = arm_id.split(",");
								 ArrayList<String> strList = new ArrayList<String>(
								            Arrays.asList(arrOfStr));
							for (int i=1;i<=strList.size();i++)
							 {
								
								  Session sessionHQL1 = this.sessionFactory.openSession();
									Transaction tx1 = sessionHQL1.beginTransaction();
							 String ec_exam_id = request.getParameter("ec_exam_id");
							 sub_ch.setArm_id(Integer.parseInt(arrOfStr[i-1]));
							 sub_ch.setExm_id(Integer.parseInt(ec_exam_id));
							 sub_ch.setCreated_date(date);
							 sub_ch.setCreated_by(username);
						
							 sub_ch.setSub_id(mid);
							 sessionHQL1.save(sub_ch);
								tx1.commit();
							
							 }
							 
							model.put("msg", "Data Saved Successfully.");
						 
					} else {
						model.put("msg", "Data already Exist.");
					}
				}

			
			
			} catch (RuntimeException e) {
				try {
					tx.rollback();
					model.put("msg", "roll back transaction");
				} catch (RuntimeException rbe) {
					model.put("msg", "Couldn�t roll back transaction " + rbe);
				}
				throw e;
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}

			return new ModelAndView("redirect:SearchSubject_master_Url");
		}
	
	   
	  @RequestMapping(value = "/getsubject_masterReportDataList", method = RequestMethod.POST)
	  public @ResponseBody List<Map<String, Object>> getReportListSubject_master(int startPage,String pageLength,String Search,String orderColunm,String orderType,
			  String exam ,String ec_exam_id2,HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
		  
		  return subDAO.getReportListSubject_master(startPage,pageLength,Search,orderColunm,orderType,exam, ec_exam_id2,sessionUserId);
	 }

	  @RequestMapping(value = "/getsubject_masterTotalCount", method = RequestMethod.POST)
	 public @ResponseBody long getRank_code_masterTotalCount(String Search,String exam,String ec_exam_id2){
	 	return subDAO.getReportListSubject_masterTotalCount(Search,exam, ec_exam_id2);
	 }
	  
	  
	  @RequestMapping(value = "EditSubject_masterUrl", method = RequestMethod.POST)
      public ModelAndView EditSubject_masterUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String updateid) {


             Session s1 = this.sessionFactory.openSession();
             Transaction tx = s1.beginTransaction();
             String enckey = "commonPwdEncKeys";  
             String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
             Query q = null;
             q = s1.createQuery("from SUBJECT_CODE_M where cast(sc_subject_id as string)=:PK");
             q.setString("PK", DcryptedPk);
             @SuppressWarnings("unchecked")
             List<String> list = (List<String>) q.list();
             
            
             tx.commit();
             s1.close();
             Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
             Mmap.put("getctarmcodetypeListDDL",comm.getctarmcodetypeListDDL(sessionFactory));
             Mmap.put("editexamination_masterCMD1", list.get(0));
             Mmap.put("EditSubchildDetails", subDAO.getarmcodeforsubjectmst(DcryptedPk));
             Mmap.put("msg", msg);
             Mmap.put("EditSubchildDetailssize", subDAO.getarmcodeforsubjectmst(DcryptedPk).size());
      return new ModelAndView("EditSubjectmasterTile","editexamination_masterCMD",new SUBJECT_CODE_M());
}
	  
	  
	  
	  @RequestMapping(value = "/EditExamination_MasterAction" ,method = RequestMethod.POST) 
	  public ModelAndView EditExamination_MasterAction(@Valid @ModelAttribute("editexamination_masterCMD") SUBJECT_CODE_M ln, BindingResult result, 
	  HttpServletRequest request, ModelMap model, HttpSession session){ 


	  int errCount=0;

	  // if(request.getParameter("rc_rank_name").equals("") || request.getParameter("rc_rank_name") == null) 
	  // { 
	  //errCount ++;
	  //model.put("rc_rank_name_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Rank");
	  // } 
	  //if(errCount > 0) {
	  //
	  //  return new ModelAndView("EditRank_code_master_tile");
	  //}
	  
	  
	     String sc_subject_name=request.getParameter("sc_subject_name").trim();
		if(sc_subject_name == "" || sc_subject_name.equals("")) {
			model.put("msg", "Please Enter Subject Name");		
		return new ModelAndView("redirect:SearchSubject_master_Url");
		}
	 


		
			String sub_arm_name=request.getParameter("sub_arm_name_id");
			System.err.println("sub_arm_name--- "+sub_arm_name);
			
			if( sub_arm_name.equals(""))
					
	        {
		    	model.put("msg", "Please Select Arm/Service");
				return new ModelAndView("redirect:SearchSubject_master_Url");
	        }


			
			String sc_max_marks=request.getParameter("sc_max_marks");
			if(sc_max_marks == "" || sc_max_marks.equals("")) {
				model.put("msg", "Please Enter Max Marks");		
				return new ModelAndView("redirect:SearchSubject_master_Url");
			}


			
			

	  Date date = new Date();
	  String username = session.getAttribute("username").toString(); 
	   Session sessionHQL = this.sessionFactory.openSession(); 
	   Transaction tx = sessionHQL.beginTransaction(); 
	   ln.setSc_subject_id(Integer.parseInt(request.getParameter("id")));
	   
	   ln.setSc_status_id(1);
	   sessionHQL.saveOrUpdate(ln); 
	   
	   String ec_exam_id = request.getParameter("ec_exam_id");
	   
	   try {
	  	 
	  	 
	  	 String hql1 = "delete from SUBJECT_CODE_CHILD_TBL where sub_id=:sub_id";
	  		Query query1 = sessionHQL.createQuery(hql1)
	  					.setParameter("sub_id",Integer.parseInt(request.getParameter("id")));
	  		query1.executeUpdate();
	  		
	  		SUBJECT_CODE_CHILD_TBL SUB = new SUBJECT_CODE_CHILD_TBL();
	  		
	  		 String arm_id = request.getParameter("sub_arm_name_id");
				String[] arrOfStr = arm_id.split(",");
				 ArrayList<String> strList = new ArrayList<String>(
				            Arrays.asList(arrOfStr));
				 
				 for (int i=1;i<=strList.size();i++)
				 {
					
					  Session sessionHQL1 = this.sessionFactory.openSession();
						Transaction tx1 = sessionHQL1.beginTransaction();
				 
					SUB.setSub_id(Integer.parseInt(request.getParameter("id")));
			  		SUB.setArm_id(Integer.parseInt(arrOfStr[i-1]));
			  		SUB.setExm_id(Integer.parseInt(ec_exam_id));
			  		SUB.setModified_by(username);
			  		SUB.setModified_date(date);
			  		
				 sessionHQL1.save(SUB);
					tx1.commit();
				
				 }
	  		
	  			tx.commit(); 
	  			 sessionHQL.close(); 

	  		}catch(RuntimeException e){
	  			e.printStackTrace();
	  			tx.rollback();
	  			
	  			model.put("msg","Server side Error");
	  			
	  		}
	   
	   
	   model.put("msg","Data Updated Successfully"); 
	   return new ModelAndView("redirect:SearchSubject_master_Url"); 
	  } 
	  
	  
	  
	  
@RequestMapping(value = "/deletesubject_code_masterUrl", method = RequestMethod.POST) 
public ModelAndView deletesubject_code_masterUrl(String deleteid,HttpSession session,ModelMap model) { 
	List<String> list = new ArrayList<String>(); 
	list.add(subDAO.DeleteSubject_master(deleteid,session)); 
	model.put("msg",list);  
 return new ModelAndView("redirect:SearchSubject_master_Url"); 
	}

    //-----Excel
	@RequestMapping(value = "/Export_Subject_master", method = RequestMethod.POST)
	public ModelAndView Export_Subject_master(HttpServletRequest request, ModelMap model, HttpSession session, String typeReport1,
			String ec_exam_id2)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		
		
		if (ec_exam_id2 != null) {
		ArrayList<ArrayList<String>> exportSubject = subDAO.getExcelSubject_master(0, "-1", "", "1", "ASC",ec_exam_id2,typeReport1,session);
	
	
		
		
		if (exportSubject.size() > 0) {
			List<String> TH = new ArrayList<String>();
			
			TH.add("SER_NO");
			TH.add("ID");
			
			TH.add("SUBJECT");
			
			TH.add("SUBJECT_CODE");
			TH.add("SUBJECT_CAPTION");
			
			
			
			String Heading = "\n";
			String username = session.getAttribute("username").toString();
			return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList",
					exportSubject);
		} 
		else {
			model.put("msg", "Data Not Available.");
			return new ModelAndView("redirect:SearchSubject_master_Url");
		   }
		  }
		
		return new ModelAndView("redirect:SearchSubject_master_Url");
	}


	
	
}
