package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.Indexing.IndexingDAO;
import com.BisagN.dao.Indexing.ManageBundleDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_MASTER;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_MASTER;
import com.BisagN.models.officers.indexing.TB_BARCODE_COUNT;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_ARM_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.OFFICER_RANK_M;
import com.BisagN.models.officers.others.RESULTS_WITHHELD_M;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class IndexingOpeningGroupController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	
	@Autowired
	CommonController comm;
	
	@Autowired
	IndexingDAO IndeDAO;
	
	@Autowired
	ManageBundleDAO MbindxDao;
	
	@RequestMapping(value = "IndexingOpeningGroupUrl", method = RequestMethod.GET)
	public ModelAndView IndexingOpeningGroupUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
		
		
		
		
		int esid_es_id = Integer.parseInt(
				session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		
		if (ec_exam_id != 0) {
		
		List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
		Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
		
		}
		if (esid_es_id != 0) {
			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, esid_es_id);
			Date begin_date = UnlcokExmsch.get(0).getEs_begin_date();
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

			int day = date.getDayOfMonth();
			String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

			String[] shortMonths = new DateFormatSymbols().getShortMonths();
			for (String shortMonth : shortMonths) {

			}
			int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
			
			int ActiveSubjectId=0;
			
			if (esid_sc_subject_id != 0) {
			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
			List<SUBJECT_CODE_M>ActiveSubName= comm.getsubjectIdbysubname( sessionFactory, esid_sc_subject_id, ec_exam_id);
			
			ActiveSubjectId=esid_sc_subject_id;
			 Mmap.put("ActiveSub",ActiveSubName.get(0).getSc_subject_name());			
			
			}
			Month month = date.getMonth();
			int year = date.getYear();
			String begindateShow = day + " " + month + " " + year;
			
			System.err.println("begindateShow========="+begindateShow);

			Mmap.put("begindateShow", begindateShow);
			Mmap.put("esid_es_id", esid_es_id);	
			int totalcount=0;

			ArrayList<ArrayList<String>> alist1 = IndeDAO.GetcountCL(esid_es_id,esid_sc_subject_id);
			if(alist1.size()>0)
				totalcount=Integer.parseInt(alist1.get(0).get(0));
			System.err.println("====totalscannedcount======="+totalcount);
			Mmap.put("totalcount",totalcount);
			if(totalcount>0) {
				Mmap.put("msg","Closing Gp Not Close the All Bundels Plz Check");
				return new ModelAndView("commanDashboardTiles");
			}
			List<INDEXED_PACKING_NOTES_MASTER>bundleprefix=  comm.getBundlePrefixList(sessionFactory,esid_es_id,esid_sc_subject_id) ;
			Mmap.put("bundle_prefix", bundleprefix);

			int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
			if (esid_sub_subject_id != 0) {
				List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
				String sub_subject_name=SubSubject.get(0).getSub_subject();
				Mmap.put("sub_subject_name", sub_subject_name);
				ActiveSubjectId=esid_sub_subject_id;
			}
			
			Mmap.put("Active_subID", ActiveSubjectId);
			 
			}		
			
			Mmap.put("msg",msg);
			return new ModelAndView("Index_OpeningTiles");
}
	
	
	
	@RequestMapping(value = "IndexingClosingGroupUrl", method = RequestMethod.GET)
	public ModelAndView IndexingClosingGroupUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {		
	
		
		int esid_es_id = Integer.parseInt(
				session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		
		String userId = session.getAttribute("userId").toString();
		
		String role = session.getAttribute("role").toString();

		int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());


		if (ec_exam_id != 0) {
		
		List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
		Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
		
		}
		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		if (es_id != 0) {
			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, es_id);
			String index_mode = UnlcokExmsch.get(0).getEs_index_mode();
			Mmap.put("index_mode", index_mode);
			Mmap.put("es_id", es_id);
		}
		if (esid_es_id != 0) {
			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, esid_es_id);
			Date begin_date = UnlcokExmsch.get(0).getEs_begin_date();
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

			int day = date.getDayOfMonth();
			String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

			String[] shortMonths = new DateFormatSymbols().getShortMonths();
			for (String shortMonth : shortMonths) {

			}
//int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
			
			int ActiveSubjectId=0;
			
			if (esid_sc_subject_id != 0) {
			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
			List<SUBJECT_CODE_M>ActiveSubName= comm.getsubjectIdbysubname( sessionFactory, esid_sc_subject_id, ec_exam_id);
			
			ActiveSubjectId=esid_sc_subject_id;
			 Mmap.put("ActiveSub",ActiveSubName.get(0).getSc_subject_name());
			
			
		}
			Month month = date.getMonth();
			int year = date.getYear();
			String begindateShow = day + " " + month + " " + year;
			
			System.err.println("begindateShow========="+begindateShow);

			Mmap.put("begindateShow", begindateShow);
			Mmap.put("esid_es_id", esid_es_id);

			int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
			if (esid_sub_subject_id != 0) {
				List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
				String sub_subject_name=SubSubject.get(0).getSub_subject();
				Mmap.put("sub_subject_name", sub_subject_name);
				ActiveSubjectId=esid_sub_subject_id;
			}
			
			Mmap.put("Active_subID", ActiveSubjectId);
			 
			}
		
		 List<INDEXED_PACKING_NOTES_MASTER>bundleprefix=  comm.getBundlePrefixList(sessionFactory,esid_es_id,esid_sc_subject_id) ;
		 Mmap.put("bundle_prefix", bundleprefix);
		 
			List<INDEXED_BUNDLE_MASTER> getBundleName = comm.getBundleNameList(sessionFactory, esid_es_id,
					Integer.parseInt(userId),esid_sc_subject_id);
			if (!getBundleName.isEmpty()) {
				String Bundle_id = getBundleName.get(0).getIbm_bundle_prefix() + " "
						+ getBundleName.get(0).getIbm_bundle_no();
				Mmap.put("Bundle_id", Bundle_id);
				int ibm_id = getBundleName.get(0).getIbm_id();

				int TotalAbs_count = getBundleName.get(0).getIbm_abcount();

				Mmap.put("TotalAbs_count", TotalAbs_count);
				

			}
			ArrayList<ArrayList<String>> alist1 = IndeDAO.getIndxSlipBundleCountByIbm(esid_sc_subject_id,es_id);
			int totalscannedcount=Integer.parseInt(alist1.get(0).get(0));
			System.err.println("totalscannedcount==========="+totalscannedcount);
			 Mmap.put("totalscannedcount",totalscannedcount);
			
	 Mmap.put("msg",msg);
	 return new ModelAndView("Index_ClosingTiles");
}
	
	
	@RequestMapping(value = "UpdateOpeningGroupStatusUrl", method = RequestMethod.POST)
	@ResponseBody public String UpdateOpeningGroupStatusUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String barcode_no1, HttpServletRequest request,String typeReport) {
		
		
		String role = session.getAttribute("role").toString();
	  Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		String username = session.getAttribute("username").toString();
		Date date = new Date();
		String msg1="";
		List<TB_BARCODE_COUNT> BarcodeDetails=comm.getBarcodeDetails(sessionFactory,barcode_no1);
		if(!BarcodeDetails.isEmpty()) {
		int id= BarcodeDetails.get(0).getId();
		int es_id=BarcodeDetails.get(0).getEs_id();
		
		int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());

		
		
		if(role.equals("Opening Group")) {
		
		Query qry = sessionHQL.createQuery("update TB_BARCODE_COUNT  set opng_status=:opng_status,opng_by=:opng_by,opng_date=:opng_date where barcode_no=:barcode_no and es_id=:es_id and subject_id=:subject_id");
		qry.setParameter("opng_status",1);
		qry.setParameter("opng_by",username);
		qry.setParameter("opng_date",date);
		//qry.setParameter("id",id);
		qry.setParameter("barcode_no", barcode_no1);
		qry.setParameter("es_id",es_id);
		qry.setParameter("subject_id",esid_sc_subject_id);
		int total = qry.executeUpdate();
		Mmap.put("msg", "Barcode scan successfully");
		tx.commit();
		
		if(total>0)
			msg1="Barcode scan successfully";
		else
			msg1="Barcode Not Scanned";
		//return new ModelAndView("redirect:IndexingOpeningGroupUrl");
		
		}
		
		
		}else {
			Mmap.put("msg", "Barcode Not scanned");
			msg1="Barcode Not Found";
		}
		return msg1;
		
//		if(role.equals("Opening Group")) {
		// return new ModelAndView("redirect:IndexingOpeningGroupUrl");

	}
	
	
	
//	====================================================================================
	@SuppressWarnings("deprecation")
	@RequestMapping(value = "UpdateClosingGroupStatusUrl", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<String> UpdateClosingGroupStatusUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, HttpServletRequest request, String typeReport) {

		ArrayList<String> save = new ArrayList<String>();
		String barcode_no1 = request.getParameter("barcode_no");

		String role = session.getAttribute("role").toString();
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		String username = session.getAttribute("username").toString();
		Date date = new Date();
		int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
		
		System.err.println("barcode_no1============" + barcode_no1);
		Query q0 = sessionHQL
				.createQuery("select count(*) from TB_BARCODE_COUNT where barcode_no=:barcode_no and close_status=1 and subject_id=:subject_id");
		q0.setParameter("barcode_no", barcode_no1);
		q0.setParameter("subject_id", esid_sc_subject_id);
		Long c = (Long) q0.uniqueResult();
		if (c == 0) {

			List<TB_BARCODE_COUNT> BarcodeDetails = comm.getBarcodeDetails(sessionFactory, barcode_no1);

			

			
			String barcode_noint = "";
			barcode_noint = barcode_no1.split("-")[0];
			String barcode_no = "";
			
			if (!BarcodeDetails.isEmpty()) {
				int id = BarcodeDetails.get(0).getId();
				int es_id = BarcodeDetails.get(0).getEs_id();
				
				ArrayList<ArrayList<String>> currentbarcode = IndeDAO.GetcurrentBarcode(es_id,esid_sc_subject_id,username);
				System.err.println("barcode_no===========" + barcode_no);
				System.err.println("barcode_no1============" + barcode_no1);
				// if(!barcode_no.equals("")) {
				if(currentbarcode.size()>0) {
					//barcode_noint = currentbarcode.get(0).get(1).split("-")[0];
					barcode_no = currentbarcode.get(0).get(1).split("-")[0];
				}else
				{
					barcode_no = barcode_no1.split("-")[0];
				}

				if (barcode_no.equals(barcode_noint)) {

					if (role.equals("Closing Group")) {

						Query qry = sessionHQL.createQuery(
								"update TB_BARCODE_COUNT  set close_status=:close_status,close_by=:close_by,close_date=:close_date where barcode_no=:barcode_no and es_id=:es_id and subject_id=:subject_id");
						qry.setParameter("close_status", 1);
						qry.setParameter("close_by", username);
						qry.setParameter("close_date", date);
						qry.setParameter("barcode_no", barcode_no1);
						qry.setParameter("es_id", es_id);
						qry.setParameter("subject_id", esid_sc_subject_id);

						qry.executeUpdate();
						save.add("Barcode Scanned successfully");
						tx.commit();
					}
				} else {
					save.add("Another Bundle Barcode Not Scanned Yet");
				}
//		}else {
//			if(role.equals("Closing Group")) {
//				 
//				Query qry = sessionHQL.createQuery("update TB_BARCODE_COUNT  set close_status=:close_status,close_by=:close_by,close_date=:close_date where barcode_no=:barcode_no and es_id=:es_id and subject_id=:subject_id");
//				qry.setParameter("close_status",1);
//				qry.setParameter("close_by",username);
//				qry.setParameter("close_date",date);
//				qry.setParameter("barcode_no",barcode_no1);
//				qry.setParameter("es_id",es_id);
//				qry.setParameter("subject_id",esid_sc_subject_id);
//				
//				qry.executeUpdate();
//				save.add("Barcode scan1 successfully");
////				Mmap.put("msg", "Barcode scan successfully");
//			
//				tx.commit();
//				
//			
//				
//				
////				================================================
//				
//				 Session sessionh2 = sessionFactory.openSession();
//				 Transaction  tx22 = sessionh2.beginTransaction();
//				Query q = sessionh2.createQuery("select oa_app_id from TB_BARCODE_COUNT where barcode_no=:barcode_no and es_id=:es_id and subject_id=:subject_id");
//				q.setParameter("barcode_no",barcode_no1);
//				q.setParameter("es_id",es_id);
//				q.setParameter("subject_id",esid_sc_subject_id);
//				@SuppressWarnings("unchecked")
//
//				
//				int oa_app_id = (int) q.uniqueResult();
//				
//				System.err.println("oa_app_id=========="+oa_app_id);
//				
//
//				
//				
//				tx22.commit();
//				sessionh2.close();
//				
////				ArrayList<ArrayList<String>> alist=IndeDAO.GetBarcodcount(oa_app_id,es_id,esid_sc_subject_id);
////				
////				save.add(alist.get(0).get(0).toString());
////				save.add(alist.get(0).get(1).toString());
//				
//				
//				ArrayList<ArrayList<String>> alist=IndeDAO.GetBarcodcount(oa_app_id,es_id,esid_sc_subject_id);
//				
//				save.add(alist.get(0).get(0).toString());
//				save.add(alist.get(0).get(1).toString());
//				
//				
//				ArrayList<ArrayList<String>> alist1 = IndeDAO.getIndxSlipBundleCountByIbm(esid_sc_subject_id,es_id);
//				int totalscannedcount=Integer.parseInt(alist1.get(0).get(0));
//				System.err.println("totalscannedcount==========="+totalscannedcount);
//				 Mmap.put("totalscannedcount",totalscannedcount);
//
////				if (!getAbsCount.isEmpty()) {
////					String slip_count = getAbsCount.get(0).get(0);
////					Mmap.put("slip_count", slip_count);
////
////				}
//				
//				
//				int scancount=Integer.parseInt( alist.get(0).get(0));
//				
//				
//				
//				
//				
//				if (scancount > 0) {
//					
//					
//				
//					System.err.println("barcode_noint=============+"+barcode_noint);
//					
//					//TB_BARCODE_COUNT Brdcount = (TB_BARCODE_COUNT) sessionHQL.get(TB_BARCODE_COUNT.class, Integer.parseInt(barcode_noint));
////					 request.getSession().setAttribute("barcode_no", Brdcount.getBarcode_no());
//					request.getSession().setAttribute("barcode_no", barcode_noint);
//					 
//					
//				}
//				else {
//					//TB_BARCODE_COUNT Brdcount = (TB_BARCODE_COUNT) sessionHQL.get(TB_BARCODE_COUNT.class,Integer.parseInt(barcode_noint) );
//					 request.getSession().setAttribute("barcode_no", "");
//				}
//			}
				// }
			} else {
				save.add("Barcode Not Found");
			}
		} else {
			save.add("Barcode Already Scanned");
		}
		return save;
	}

	
	
	
	
	
	
//	@RequestMapping(value = "getdatteofClosingGroupStatusUrl", method = RequestMethod.POST)
	public String getdatteofClosingGroupStatusUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String barcode_no2, HttpServletRequest request,String typeReport) {
		
		
		 
		 
		String save = "";
		 String barcode_no1 = request.getParameter("barcode_no");
		
		String role = session.getAttribute("role").toString();
		 
		String username = session.getAttribute("username").toString();
		Date date = new Date();
		List<TB_BARCODE_COUNT> BarcodeDetails=comm.getBarcodeDetails(sessionFactory,barcode_no1);
		if(!BarcodeDetails.isEmpty()) {
		int id= BarcodeDetails.get(0).getId();
		int es_id=BarcodeDetails.get(0).getEs_id();
		
		int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
 
		
		 Session sessionh1 = sessionFactory.openSession();
			Transaction tx = sessionh1.beginTransaction();
			Query q = sessionh1.createQuery("select COUNT(*) from TB_BARCODE_COUNT where id=:id and es_id=:es_id and subject_id=:subject_id");
			q.setParameter("id",id);
			q.setParameter("es_id",es_id);
			q.setParameter("subject_id",esid_sc_subject_id);
			@SuppressWarnings("unchecked")
			List<SUB_SUBJECT_MST>  list = (List<SUB_SUBJECT_MST>) q.list();
			
			Mmap.put("allcount", list.get(0));
			
			tx.commit();
			sessionh1.close();
			
			
			
			 Session sessionh2 = sessionFactory.openSession();
				Transaction tx2 = sessionh2.beginTransaction();
				Query q2 = sessionh2.createQuery("select COUNT(*) from TB_BARCODE_COUNT where id=:id and es_id=:es_id and subject_id=:subject_id and close_status=:close_status");
				q2.setParameter("id",id);
				q2.setParameter("es_id",es_id);
				q2.setParameter("subject_id",esid_sc_subject_id);
				q2.setParameter("close_status",1);
				
				@SuppressWarnings("unchecked")
				List<SUB_SUBJECT_MST>  list2 = (List<SUB_SUBJECT_MST>) q2.list();
				
				Mmap.put("scancount", list2.get(0));
				
				tx2.commit();
				sessionh2.close();
 
	}

		return save;
	}
	
	
	@RequestMapping(value = "/getBundleCount", method = RequestMethod.POST)
	@ResponseBody public ArrayList<ArrayList<String>> getBundleCount(HttpSession session,String objid) {

		int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
		
		int esi_es_id = Integer.parseInt(session.getAttribute("esi_es_id") == null ? "0" : session.getAttribute("esi_es_id").toString());
		ArrayList<ArrayList<String>> list = MbindxDao.getBundleCount(String.valueOf(esi_es_id),objid,String.valueOf(esid_sc_subject_id));
		return list;

	}
	
	@RequestMapping(value = "/getBundleCountForOP", method = RequestMethod.POST)
	@ResponseBody public ArrayList<ArrayList<String>> getBundleCountforOP(HttpSession session,String objid) {

		int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
		
		int esi_es_id = Integer.parseInt(session.getAttribute("esi_es_id") == null ? "0" : session.getAttribute("esi_es_id").toString());
		ArrayList<ArrayList<String>> list = MbindxDao.getBundleCountforOP(String.valueOf(esi_es_id),objid,String.valueOf(esid_sc_subject_id));
		return list;

	}
	
	
	
}
