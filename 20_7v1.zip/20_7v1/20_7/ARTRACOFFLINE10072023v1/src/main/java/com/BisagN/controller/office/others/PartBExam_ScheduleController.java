package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.trans.Examination_centreController;



@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class PartBExam_ScheduleController {
	
	
	@Autowired
	Examination_centreController exmCon = new Examination_centreController();
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	
	@Autowired
	CommonController comm= new CommonController();
	
	
	
	@RequestMapping(value = "/PartB_ExamscheduleURL", method = RequestMethod.GET)
    public ModelAndView PartB_ExamscheduleURL(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) 
   		 throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

		 Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
        Mmap.put("msg", msg);
    return new ModelAndView("exam_schedule_dscc_tile");
}
}
