package com.BisagN.controller.office.trans;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.dao.officer.others.ExportPartBDao;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.trans.Partbd_compens_chanceDAO;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.trans.DSSC_COMPENS_CHANCE_M;
import com.BisagN.models.officers.trans.PARTBD_COMPENS_CHANCE_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Partbd_compens_chanceController {

	@Autowired
	private Partbd_compens_chanceDAO objDAO;
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

	@Autowired
	private ExportPartBDao export;

	CommonController comm = new CommonController();

	@Autowired
	private Officer_personal_detailsDAO opdDAO;

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	private RoleBaseMenuDAO roledao;

	@Autowired
	private PartB_ExaminationDAO partBDao;

	@RequestMapping(value = "Searchpartbd_compens_chanceUrl", method = RequestMethod.GET)
	public ModelAndView Searchpartbd_compens_chanceUrl(ModelMap Mmap, HttpServletRequest request, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? ""
				: session.getAttribute("es_begin_dateshow").toString();

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		if (ec_exam_id == 1) {
			if (!es_begindate.equals("")) {
				Mmap.put("partb_begindate", es_begindate);
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
			if (ec_exam_id != 0) {
				ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
				Mmap.put("getexamcentrelist", examcentrelist);
				Mmap.put("ec_exam_id", ec_exam_id);
			}
		}

		if (request.getHeader("Referer") == null) {
			session.invalidate();
			Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			return new ModelAndView("redirect:/login");
		}

		String roleid1 = session.getAttribute("roleid").toString();
		Boolean val = roledao.ScreenRedirect("Searchpartbd_compens_chanceUrl", roleid1);
		if (val == false) {
			return new ModelAndView("AccessTiles");
		}

		Mmap.put("msg", msg);
		return new ModelAndView("SearchPartbd_compens_chance_tile", "Searchpartbd_compens_chanceCMD",
				new PARTBD_COMPENS_CHANCE_M());
	}

	@RequestMapping(value = "/getPartbd_compens_chanceReportDataList", method = RequestMethod.POST)
	public @ResponseBody List<Map<String, Object>> getPartbd_compens_chanceReportDataList(int startPage,
			String pageLength, String Search, String orderColunm, String orderType, String pers_no,
			String opd_officer_name, HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		int ec_exam_id = sessionUserId.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(sessionUserId.getAttribute("ec_exam_id").toString());
		return objDAO.getReportListPartbd_compens_chance(startPage, pageLength, Search, orderColunm, orderType, pers_no,
				opd_officer_name, ec_exam_id, sessionUserId);
	}

	@RequestMapping(value = "/getPartbd_compens_chanceTotalCount", method = RequestMethod.POST)
	public @ResponseBody long getPartbd_compens_chanceTotalCount(HttpSession sessionUserId, String Search,
			String pers_no, String opd_officer_name) {
		int ec_exam_id = sessionUserId.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(sessionUserId.getAttribute("ec_exam_id").toString());
		return objDAO.getReportListPartbd_compens_chanceTotalCount(Search, pers_no, opd_officer_name, ec_exam_id);
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getexistdatafromicno", method = RequestMethod.POST)
	@ResponseBody
	public List<ArrayList<String>> getexistdatafromicno(String val) {
		List<ArrayList<String>> list = objDAO.getexistfromicnodao(val);

		return list;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getyearlistfromicno", method = RequestMethod.POST)
	@ResponseBody
	public List<ArrayList<String>> getyearlistfromicno(String val) {
		List<ArrayList<String>> list = objDAO.getyearlistfromicnodao(val);

		return list;
	}

	@RequestMapping(value = "/partbd_compens_chanceAction", method = RequestMethod.POST)
	public ModelAndView partbd_compens_chanceAction(
			@Valid @ModelAttribute("partbd_compens_chanceCMD") PARTBD_COMPENS_CHANCE_M PartBd_cs, BindingResult result,
			@RequestParam(value = "partbd_auth_doc", required = false) MultipartFile partbd_auth_doc,
			HttpServletRequest request, ModelMap model, HttpSession session) {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		int errCount = 0;
		String opd_personal_hid = request.getParameter("opd_personal_hid");

		try {
			String opd_personal_id = request.getParameter("opd_personal_id");
			String pcc_area = request.getParameter("pcc_area");
			String pcc_area_entry_date = request.getParameter("pcc_area_entry_date");
			String pcc_area_leave_date = request.getParameter("pcc_area_leave_date");
			String pcc_remarks = request.getParameter("pcc_remarks");
			String pcc_granted_year = request.getParameter("pcc_granted_year");

			if (opd_personal_id == "" || opd_personal_id.equals("")) {
				model.put("msg", " Please Enter Personal No");
				return new ModelAndView("redirect:Searchpartbd_compens_chanceUrl");
			}

			if (pcc_area.equals("")) {
				model.put("msg", " Please Select Qualifying Area/Operation");
				return new ModelAndView("redirect:Searchpartbd_compens_chanceUrl");

			}
			if (pcc_area_entry_date.equals("DD/MM/YYYY") || pcc_area_entry_date.equals("") || pcc_area_entry_date == ""
					|| pcc_area_entry_date == "DD/MM/YYYY") {
				model.put("msg", "Please Select Date of posting into the area");
				return new ModelAndView("redirect:Searchpartbd_compens_chanceUrl");
			}
			if (pcc_area_leave_date.equals("DD/MM/YYYY") || pcc_area_leave_date.equals("") || pcc_area_leave_date == ""
					|| pcc_area_leave_date == "DD/MM/YYYY") {
				model.put("msg", " Please Select Date of posting out");
				return new ModelAndView("redirect:Searchpartbd_compens_chanceUrl");
			}
			
			if (pcc_granted_year == "" || pcc_granted_year.equals("")) {
				model.put("msg", " Please Enter Waiver Granted for the Year");
				return new ModelAndView("redirect:Searchpartbd_compens_chanceUrl");
			}
			
			if (pcc_remarks == "" || pcc_remarks.equals("")) {
				model.put("msg", " Please Enter Authority");
				return new ModelAndView("redirect:Searchpartbd_compens_chanceUrl");
			}
			

			if (partbd_auth_doc.isEmpty()) {
				model.put("msg", "Please Upload Copy Of File Upload");
				return new ModelAndView("redirect:Searchpartbd_compens_chanceUrl");
			}
			
			String username = session.getAttribute("username").toString();
			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			int id = PartBd_cs.getPcc_id() > 0 ? PartBd_cs.getPcc_id() : 0;
			DateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");

			if (id == 0) {
				int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0"
						: session.getAttribute("ec_exam_id").toString());
				int es_id = Integer.parseInt(
						session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

				List<OFFICER_PERSONAL_CODE_M> getopdId = comm.getopdIdbycode(sessionFactory, opd_personal_id);
				int opdid = getopdId.get(0).getOpd_personal_id();

				PartBd_cs.setOpd_personal_id(opdid);
				PartBd_cs.setPcc_created_by(username);
				PartBd_cs.setPcc_creation_date(date);
				PartBd_cs.setEc_exam_id(1);

				if (!partbd_auth_doc.isEmpty()) {
					String name = comm.fileupload2(partbd_auth_doc.getBytes(), partbd_auth_doc.getOriginalFilename(),
							String.valueOf(opdid), "partbd_auth_doc" + PartBd_cs.getPcc_id());
					if (name != "") {
						PartBd_cs.setPcc_auth_doc(name);
					}
				}
				sessionHQL.save(PartBd_cs);

				model.put("msg", "Data Saved Successfully");

				tx.commit();
				sessionHQL.close();
			}

		}

		catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return new ModelAndView("redirect:Searchpartbd_compens_chanceUrl");
	}

	@RequestMapping(value = "EditPartbd_compens_chanceUrl", method = RequestMethod.POST)
	public ModelAndView EditPartbd_compens_chanceUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String updateid) {

		Session s1 = this.sessionFactory.openSession();
		Transaction tx = s1.beginTransaction();
		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);
		Query q = null;
		q = s1.createQuery("from PARTBD_COMPENS_CHANCE_M where cast(pcc_id as string)=:PK");
		q.setString("PK", DcryptedPk);
		@SuppressWarnings("unchecked")
		List<PARTBD_COMPENS_CHANCE_M> list = (List<PARTBD_COMPENS_CHANCE_M>) q.list();
		tx.commit();
		s1.close();
		Mmap.put("Editpartbd_compens_chanceCMD1", list.get(0));

		int opd_id = list.get(0).getOpd_personal_id();
		Mmap.put("Edit_pers_details", opdDAO.getpersdetails(String.valueOf(opd_id)));
		Mmap.put("getAreaListDDL", comm.getAreaListDDL(sessionFactory));
		Mmap.put("msg", msg);
		return new ModelAndView("EditPartbd_compens_chance_tile", "Editpartbd_compens_chanceCMD",
				new PARTBD_COMPENS_CHANCE_M());
	}

	@RequestMapping(value = "/Editpartbd_compens_chanceAction", method = RequestMethod.POST)
	public ModelAndView Editpartbd_compens_chanceAction(
			@Valid @ModelAttribute("Editpartbd_compens_chanceCMD") PARTBD_COMPENS_CHANCE_M ln, BindingResult result,
			@RequestParam(value = "partbd_auth_doc", required = false) MultipartFile partbd_auth_doc,
			HttpServletRequest request, ModelMap model, HttpSession session) throws IOException {

		String opd_personal_id = request.getParameter("opd_personal_id");
		String pcc_area = request.getParameter("pcc_area");
		String pcc_area_entry_date = request.getParameter("pcc_area_entry_date");
		String pcc_area_leave_date = request.getParameter("pcc_area_leave_date");
		String pcc_remarks = request.getParameter("pcc_remarks");

		System.err.println("partbd_auth_doc=========" + partbd_auth_doc);

		if (opd_personal_id == "" || opd_personal_id.equals("")) {
			model.put("msg", " Please Enter Personal No");
			return new ModelAndView("redirect:Comp_chancePartBd_ApplicationURL");
		}

		if (pcc_area.equals("")) {
			model.put("msg", " Please Select Qualifying Area/Operation");
			return new ModelAndView("redirect:Comp_chancePartBd_ApplicationURL");

		}
		if (pcc_area_entry_date.equals("DD/MM/YYYY") || pcc_area_entry_date.equals("") || pcc_area_entry_date == ""
				|| pcc_area_entry_date == "DD/MM/YYYY") {
			model.put("msg", "Please Select Date of posting into the area");
			return new ModelAndView("redirect:Comp_chancePartBd_ApplicationURL");
		}
		if (pcc_area_leave_date.equals("DD/MM/YYYY") || pcc_area_leave_date.equals("") || pcc_area_leave_date == ""
				|| pcc_area_leave_date == "DD/MM/YYYY") {
			model.put("msg", " Please Select Date of posting out");
			return new ModelAndView("redirect:Comp_chancePartBd_ApplicationURL");
		}

		if (pcc_remarks == "" || pcc_remarks.equals("")) {
			model.put("msg", " Please Enter Remark");
			return new ModelAndView("redirect:Comp_chancePartBd_ApplicationURL");
		}

		String username = session.getAttribute("username").toString();
		Date date = new Date();
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		ln.setPcc_id(Integer.parseInt(request.getParameter("id")));
		ln.setPcc_modification_date(date);
		ln.setPcc_modified_by(username);
		String opd_personal_hid = request.getParameter("opd_personal_hid");
		System.err.println("opd_personal_hid============" + opd_personal_hid);
		ln.setOpd_personal_id(Integer.parseInt(opd_personal_hid));
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		if (ec_exam_id == 1) {
			ln.setEc_exam_id(1);
		}
		if (ec_exam_id == 2) {
			ln.setEc_exam_id(2);
		}
		if (!partbd_auth_doc.isEmpty()) {
			String name = comm.fileupload2(partbd_auth_doc.getBytes(), partbd_auth_doc.getOriginalFilename(),
					String.valueOf(opd_personal_hid), "partbd_auth_doc" + ln.getPcc_id());
			if (name != "") {
				ln.setPcc_auth_doc(name);
			}
		}
		sessionHQL.saveOrUpdate(ln);
		tx.commit();
		sessionHQL.close();

		model.put("msg", "Data Updated Successfully");
		if (ec_exam_id == 1) {
			return new ModelAndView("redirect:Searchpartbd_compens_chanceUrl");
		}

		if (ec_exam_id == 2) {
			return new ModelAndView("redirect:SearchpartD_compens_chanceUrl");
		}
		return null;
	}

	@RequestMapping(value = "/deletepartbd_compens_chanceUrl", method = RequestMethod.POST)
	public ModelAndView deletepartbd_compens_chanceUrl(String deleteid, HttpSession session, ModelMap model) {
		List<String> list = new ArrayList<String>();
		list.add(objDAO.Deletepartbd_compens_chance(deleteid, session));
		model.put("msg", list);
		return new ModelAndView("redirect:Searchpartbd_compens_chanceUrl");
	}

	@RequestMapping(value = "Comp_chancePartBd_ApplicationURL", method = RequestMethod.GET)
	public ModelAndView Comp_chancePartBd_ApplicationURL(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String Comp_chancePartBdid) {
		Mmap.put("getAreaListDDL", comm.getAreaListDDL(sessionFactory));
		Mmap.put("msg", msg);
		return new ModelAndView("Partbd_compens_chance_tile", "partbd_compens_chanceCMD",
				new PARTBD_COMPENS_CHANCE_M());
	}

	@RequestMapping(value = "/getPartBCompChance_Report", method = RequestMethod.POST)
	public ModelAndView getPartBCompChance_Report(ModelMap Mmap, HttpSession session, HttpServletRequest request,
			String typeReport, String es_id, String reportname1, String subject_id1, String centre_id1, String chance1,
			String f_percntg1, String t_percntg1, String marks1, String exmsh_date1, String subject_name_hid1) {
		try {

			if (typeReport != null && typeReport.equals("pdfL")) {
				// if (list.size() > 0) {
				List<String> TH = new ArrayList<String>();
				String Heading = "";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(new Partb_CompChance_ReportController("L", TH, Heading, username), "userList",
						"");

				// }
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("redirect:Searchpartbd_compens_chanceUrl");
	}

	@SuppressWarnings("null")
	@RequestMapping(value = "/getdownloadPDF")
	public ModelAndView getdownloadPDF(@RequestParam(value = "msg", required = false) String msg, ModelMap model,
			HttpServletRequest request, HttpSession session, HttpServletResponse response, String pcc_id1)
			throws IOException {

		String EXTERNAL_FILE_PATH = objDAO.getFilePathQueryForDoc(pcc_id1);
		model.put("pcc_id1", pcc_id1);
		model.put("msg", "Sorry ! The file you are looking for does not exist.");

		if (EXTERNAL_FILE_PATH != "") {
			File file = null;
			file = new File(EXTERNAL_FILE_PATH);
			try {
				if (!file.exists()) {

					return new ModelAndView("redirect:Comp_chancePartBd_ApplicationURL");
				}
			} catch (Exception exception) {
			}

			String mimeType = URLConnection.guessContentTypeFromName(file.getName());
			if (mimeType == null) {
				mimeType = "application/octet-stream";
			}
			response.setContentType(mimeType);
			response.setHeader("Content-Disposition", String.format("attachment; filename=\"" + file.getName() + "\""));
			response.setContentLength((int) file.length());
			InputStream inputStream = null;
			try {
				inputStream = new BufferedInputStream(new FileInputStream(file));
				FileCopyUtils.copy(inputStream, response.getOutputStream());
			} catch (FileNotFoundException e) {
				// e.printStackTrace();
			}
		}
		return new ModelAndView("redirect:Comp_chancePartBd_ApplicationURL");
	}

	@RequestMapping(value = "UploadPartBDCompchance", method = RequestMethod.GET)
	public ModelAndView UploadPartBDCompchance(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String Uploadssc_tsoc_Applicationid,
			HttpServletRequest request) {

		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		List<EXAM_CODE_M> getExamName = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
		if (ec_exam_id == 1) {

			Mmap.put("getExamName", getExamName.get(0).getEc_exam_name());
		}

		if (ec_exam_id == 2) {

			Mmap.put("getExamName", getExamName.get(0).getEc_exam_name());

		}

		Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
		if (flashMap != null) {
			ArrayList<ArrayList<String>> errorList = (ArrayList<ArrayList<String>>) flashMap.get("errorlist");
			System.out.println("===================" + errorList);
			// return "home";
			Mmap.put("errorList", errorList);
		}
		Mmap.put("msg", msg);
		return new ModelAndView("ImportPartbdCompChance_tiles");
	}

//UPLOAD CANDIDATE DATA
	@RequestMapping(value = "/UploadWaiverdataAction", method = RequestMethod.POST)
	public ModelAndView UploadWaiverdataAction(HttpServletRequest request, ModelMap model, HttpSession session,
			@RequestParam(value = "fileUpload", required = false) MultipartFile fileUpload,
			@RequestParam(value = "dcc_auth_doc", required = false) MultipartFile dcc_auth_doc, RedirectAttributes ra) {

		ArrayList<ArrayList<String>> listerror = new ArrayList<ArrayList<String>>();
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();

//		if(fileUpload.isEmpty()) {
//			ra.addAttribute("msg","Please Upload Copy Of File Upload");
//			  return new ModelAndView("redirect:Comp_chancePartBd_ApplicationURL");
//		}

		try {

			Date date = new Date();
			String username = session.getAttribute("username").toString();

			int errorcount = 0;
			String errormsg = "";
			File file = new File(
					comm.fileupload2(fileUpload.getBytes(), fileUpload.getOriginalFilename(), "waiver", ""));
			FileInputStream fis = new FileInputStream(file);
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheetAt(0);
			Row row_head = sheet.getRow(0);

			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				System.err.println("sheet.getLastRowNum()===========" + sheet.getLastRowNum());
				ArrayList<String> listData = new ArrayList<String>();
				Row row = sheet.getRow(i);
				String N_personal_no = "";
				String c_year = "";
				String d_year = "";

				if (row.getCell(0) == null) {
					break;
				}

				for (int j = 0; j < 3; j++) {

					Cell cell = row.getCell(j);

					String value = "";
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						value = cell.getStringCellValue();
						break;
					case Cell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							value = String.valueOf(cell.getDateCellValue());
						} else {
							value = String.valueOf((long) cell.getNumericCellValue());
						}
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						value = String.valueOf(cell.getBooleanCellValue());
						break;
					default:
					}

					if (row_head.getCell(j).getStringCellValue().equals("IC_NO")) {
						N_personal_no = value;
					}
					if (row_head.getCell(j).getStringCellValue().equals("Area")) {
						c_year = value;

					}

					if (row_head.getCell(j).getStringCellValue().equals("au")) {
						d_year = value;

					}

				}
				String pers_code2 = N_personal_no.substring(0, N_personal_no.length() - 1);
				List<OFFICER_PERSONAL_CODE_M> opdpers_id = comm.getopdIdbycode(sessionFactory, pers_code2);

				if (opdpers_id.isEmpty()) {

					listData.add(N_personal_no);
					listData.add(c_year);
					listData.add(d_year);
					listData.add("The Personal Number is Wrong");
					errormsg = N_personal_no + "The Personal Number is Wrong";
					model.put("msg", errormsg);
					errorcount++;
				} else {

					DSSC_COMPENS_CHANCE_M ln = new DSSC_COMPENS_CHANCE_M();
					int opd_pers_id = opdpers_id.get(0).getOpd_personal_id();

					// if (c == 0) {

					ln.setDcc_compens_year(Integer.parseInt(c_year));
					ln.setDcc_dispes_year(Integer.parseInt(d_year));
					ln.setOpd_personal_id(opd_pers_id);

					if (!dcc_auth_doc.isEmpty()) {
						String name = comm.fileupload2(dcc_auth_doc.getBytes(), dcc_auth_doc.getOriginalFilename(),
								String.valueOf(opd_pers_id), "dcc_auth_doc" + ln.getDcc_id());
						if (name != "") {
							ln.setDcc_auth_doc(name);
						}
					}

					ln.setDcc_created_by(username);
					ln.setDcc_creation_date(date);
					ln.setDcc_status_id(1);
					ln.setDcc_compens_status(1);

					sessionHQL.save(ln);

					ra.addAttribute("msg", "Data Save Successfully");

					if (!listData.isEmpty()) {
						System.err.println("listData=======" + listData);
						listerror.add(listData);
					}

					model.put("errorlist", listerror);

				}

			}
			tx.commit();
		}

		catch (Exception e) {
			// tx.rollback();
			e.printStackTrace();
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		ra.addFlashAttribute("errorlist", listerror);
		ra.addFlashAttribute("errorlistSize", listerror.size());
		return new ModelAndView("redirect:UploadDssc_compchanceURL");
	}
}
