package com.BisagN.controller.office.others;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Decoder.Text;

import org.apache.poi.hssf.util.HSSFColor.WHITE;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPTableEvent;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

public class DSSC_BOOKLET_PDF_CONTROLLER_old extends AbstractPdfView {
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";

	ArrayList<ArrayList<String>> armwiseanalysisresult;
	ArrayList<ArrayList<String>> SubjWiseAnalysis;
	ArrayList<ArrayList<String>> commandwiseresult;
	ArrayList<ArrayList<String>> fullypassed;
	ArrayList<ArrayList<String>> result_withheld;
	ArrayList<ArrayList<String>> partially_passed;
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";
	int totalRecords = 0;
	int page = 1;
	PdfTemplate total1;

	public DSSC_BOOKLET_PDF_CONTROLLER_old(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH;
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {

		document.open();
//		float fntSize, lineSpacing;
//		fntSize = 6.7f;
//		lineSpacing = 10f;
////		Paragraph p = new Paragraph(new Phrase(lineSpacing, Heading, FontFactory.getFont(FontFactory.COURIER, fntSize)));
////		document.add(p);
////		

		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
//	response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 16, 1);
		Font fontTableHeading2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
		Font fontTableHeadingdataheadfirstpage = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 26, 1);

		Font fontTableHeadingMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingMainHead_Ml = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);

		Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingSubMainHead1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);

		Font fontTableHeadingSubMainHead_2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 1);
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 0);

		Font fontTableHeadingdataforFooter = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 0);

		Font fontTableHeadingdataforML2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 0);

		Font fontTablepara = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 0);

		Font fontTableHeadingSubMainHeadNew_2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingSubMainHeadNew = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 7, 1);

		Rectangle two = new Rectangle(590, 838);
//	Rectangle two = new Rectangle(838, 590);

		String es_year = (String) model.get("es_year1");
		String letter_no = (String) model.get("letter_no1");
		String letter_date1 = (String) model.get("letter_date1");
		String start_end_month = (String) model.get("start_end_month");
		String director_name1 = (String) model.get("director_name1");

		String year2 = (String) model.get("es_year1");
		String b_month = (String) model.get("b_month");
		String e_month = (String) model.get("e_month");

		String b_month2 = (String) model.get("b_month2");
		String e_month2 = (String) model.get("e_month2");

		String bdrday = (String) model.get("bdrday");
		String bedday = (String) model.get("bedday");

		PdfPTable maintable = new PdfPTable(1);
		maintable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		maintable.setWidthPercentage(100);

		PdfPTable table_m1 = new PdfPTable(1);
		table_m1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_m1.setWidthPercentage(100);

		PdfPTable tabledata_m1 = new PdfPTable(1);
		tabledata_m1.setWidths(new int[] { 5 });
		tabledata_m1.setWidthPercentage(100 / 3.5f);
		tabledata_m1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata_m1.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata_m1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Chunk underline_m4 = new Chunk("RESTRICTED \n", fontTableHeading2);
		Chunk underline_m5 = new Chunk("EXAM SECTION ", fontTableHeading2);
		Chunk underline_m6 = new Chunk("DSSC/DSTSC ENTRANCE EXAM", fontTableHeading2);
		Chunk underline_m7 = new Chunk("(DSSC-78 & DSTSC-5)", fontTableHeading2);

		Chunk underline_m8 = new Chunk("SEP 2023", fontTableHeading2);
		Chunk underline_m9 = new Chunk("RESULTS", fontTableHeading2);

		underline_m4.setUnderline(0.1f, -2f);
		Phrase ph_m4 = new Phrase(underline_m4);
		ph_m4.setFont(fontTableHeading2);
		Paragraph cell_Mr = new Paragraph(ph_m4);
		cell_Mr.setAlignment(Element.ALIGN_CENTER);

		underline_m5.setUnderline(0.1f, -2f);
		Phrase ph_m5 = new Phrase(underline_m5);
		ph_m5.setFont(fontTableHeading2);
		Paragraph cell_M5 = new Paragraph(ph_m5);
		cell_M5.setAlignment(Element.ALIGN_CENTER);

		underline_m6.setUnderline(0.1f, -2f);
		Phrase ph_m6 = new Phrase(underline_m6);
		ph_m6.setFont(fontTableHeading2);
		Paragraph cell_M6 = new Paragraph(ph_m6);
		cell_M6.setAlignment(Element.ALIGN_CENTER);

		underline_m7.setUnderline(0.1f, -2f);
		Phrase ph_m7 = new Phrase(underline_m7);
		ph_m6.setFont(fontTableHeading2);
		Paragraph cell_M7 = new Paragraph(ph_m7);
		cell_M7.setAlignment(Element.ALIGN_CENTER);

		underline_m8.setUnderline(0.1f, -2f);
		Phrase ph_m8 = new Phrase(underline_m8);
		ph_m8.setFont(fontTableHeading2);
		Paragraph cell_M8 = new Paragraph(ph_m8);
		cell_M8.setAlignment(Element.ALIGN_CENTER);

		underline_m9.setUnderline(0.1f, -2f);
		Phrase ph_m9 = new Phrase(underline_m9);
		ph_m9.setFont(fontTableHeading2);
		Paragraph cell_M9 = new Paragraph(ph_m9);
		cell_M9.setAlignment(Element.ALIGN_CENTER);

		Image logo = null;
		try {
			@SuppressWarnings("deprecation")
			String dgis_logo = request.getRealPath("/") + "admin" + File.separator + "layout_file" + File.separator
					+ "images" + File.separator + "logo.png";
			logo = Image.getInstance(dgis_logo);
		} catch (BadElementException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		logo.setAlignment(Image.MIDDLE);
		logo.scaleAbsoluteHeight(80);
		logo.scaleAbsoluteWidth(80);
		logo.scalePercent(90);

		Chunk chunk = new Chunk(logo, 0, 100);
		// table_m1.addCell(new Phrase(chunk));

		Phrase ph1 = new Phrase();
		ph1.add(table_m1);

		PdfPCell cell_m1;
		cell_m1 = new PdfPCell();
		cell_m1.addElement(cell_Mr);
		cell_m1.addElement(new Paragraph("\n"));

		cell_m1.addElement(chunk);
		cell_m1.addElement(cell_M5);
		cell_m1.addElement(cell_M6);
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(cell_M7);
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(cell_M8);

		cell_m1.addElement(cell_M9);
		cell_m1.addElement(cell_Mr);
		cell_m1.setBorder(0);
		table_m1.addCell(cell_m1);

//	document.add(table_m1);

//	super.buildPdfMetadata(model, document, request);

//super.buildPdfMetadata(model, document, request);

//==============Covering-letter===============//

		PdfPTable table_c2 = new PdfPTable(1);
		table_c2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_c2.setWidthPercentage(100);

		PdfPTable tabledata_C12 = new PdfPTable(1);
		tabledata_C12.setWidths(new int[] { 4 });
		tabledata_C12.setWidthPercentage(100 / 1f);
		tabledata_C12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C12.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C12.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable tabledata_C1 = new PdfPTable(1);
		tabledata_C1.setWidths(new int[] { 7 });
		tabledata_C1.setWidthPercentage(100 / 3f);
		tabledata_C1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C1.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable tabledata_C2 = new PdfPTable(1);
		tabledata_C2.setWidths(new int[] { 8 });
		tabledata_C2.setWidthPercentage(100 / 7.4f);
		tabledata_C2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C2.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C2.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable tabledata_C3 = new PdfPTable(2);
		tabledata_C3.setWidths(new int[] { 70, 30 });
		tabledata_C3.setWidthPercentage(100);
		tabledata_C3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C3.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C3.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable tabledata_C66 = new PdfPTable(1);
		tabledata_C66.setWidths(new int[] { 4 });
		tabledata_C66.setWidthPercentage(100 / 5.5f);
		tabledata_C66.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C66.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C66.getDefaultCell().setBorder(Rectangle.NO_BORDER);

//	Chunk underline_c12 = new Chunk("REGISTERED \n", fontTableHeading2);
//	underline_c12.setUnderline(0.1f, -2f);
//	Phrase ph_m45 = new Phrase(underline_c12);
//	ph_m45.setFont(fontTableHeading2);
//	Paragraph cell_Cr = new Paragraph(ph_m45);
//	cell_Cr.setAlignment(Element.ALIGN_CENTER);

		Paragraph head_c0 = new Paragraph("Headquarters", fontTableHeadingMainHead_Ml);
		Paragraph head_c1 = new Paragraph("Army Training Command", fontTableHeadingMainHead_Ml);
		Paragraph head_c2 = new Paragraph("Pin - 908548", fontTableHeadingMainHead_Ml);
		Paragraph head_c3 = new Paragraph("C/O 56 APO", fontTableHeadingMainHead_Ml);

//	tabledata_C1.addCell(cell_Cr);
		tabledata_C1.addCell(head_c0);
		tabledata_C1.addCell(head_c1);
		tabledata_C1.addCell(head_c2);
		tabledata_C1.addCell(head_c3);

		Paragraph head_c4 = new Paragraph("Tele : 2822", fontTableHeadingSubMainHead);
		PdfPCell blank_head_c4 = new PdfPCell(head_c4);
		blank_head_c4.setHorizontalAlignment(Element.ALIGN_LEFT);
		blank_head_c4.setPaddingTop(45f);

		blank_head_c4.setBorder(0);
		tabledata_C12.addCell(blank_head_c4);
		Paragraph head_c5 = new Paragraph("A/16014/B/2021/GS/Exam Sec", fontTableHeadingdataforML2);
		blank_head_c4 = new PdfPCell(head_c5);
		blank_head_c4.setHorizontalAlignment(Element.ALIGN_TOP);
		blank_head_c4.setPaddingBottom(15f);
		blank_head_c4.setBorder(0);
		tabledata_C3.addCell(blank_head_c4);
		Paragraph head_c6 = new Paragraph("HQ Southern Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c7 = new Paragraph("HQ Eastern Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c701 = new Paragraph("HQ Western Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c8 = new Paragraph("HQ Central Command (GS/Trg))", fontTableHeadingMainHead_Ml);
		Paragraph head_c9 = new Paragraph("HQ Northern Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c10 = new Paragraph("HQ South Western Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c13 = new Paragraph("HQ ARTRAC (GS Br)", fontTableHeadingMainHead_Ml);
		Paragraph head_c11 = new Paragraph("Andaman & Nicobar Command (Comd Trg Offr)", fontTableHeadingMainHead_Ml);
		Paragraph head_c12 = new Paragraph("DSSC, Wellington ", fontTableHeadingMainHead_Ml);
		Paragraph head_c121 = new Paragraph("MILIT, Girinagar, Pune ", fontTableHeadingMainHead_Ml);
		Paragraph head_c1212 = new Paragraph("CMM, Jabalpur ", fontTableHeadingMainHead_Ml);
		Paragraph head_c1213 = new Paragraph("MINTSD, Pune ", fontTableHeadingMainHead_Ml);

		tabledata_C3.addCell("" + e_month + " " + year2);
		tabledata_C3.addCell(head_c6);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c7);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c701);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c8);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c9);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c10);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c13);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c11);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c12);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c121);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c1213);

		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c1212);
		tabledata_C3.addCell("");

		Chunk underlinec1 = new Chunk("RESULTS: DEFENCE SERVICES STAFFF COURSE - 70" + "\n" + "ENTRANCE EXAM " + b_month
				+ "-" + e_month + "  " + year2 + "", fontTableHeadingMainHead_Ml);

		underlinec1.setUnderline(0.1f, -2f);

		Phrase phhc2 = new Phrase(underlinec1);
		phhc2.setFont(fontTableHeading2);

		Paragraph cell_c12 = new Paragraph(phhc2);
		cell_c12.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableC153 = new PdfPTable(1);
		tableC153.setWidths(new int[] { 100 });
		tableC153.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC153.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		tableC153.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC153.setWidthPercentage(100);
		tableC153.setSpacingBefore(5);

		tableC153.addCell(new Paragraph(
				"1." + "\t \t \t The results of Defence Services Staff Course-70 Entrance Exam held from " + bdrday
						+ "  to " + bedday + " " + e_month2 + " " + year2 + " are appended as follows:-",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph(
				"\t \t \t \t \t(a)      Analysis of Results                                  -   Appendix 'A'   \n ",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph(
				"\t \t \t \t \t(b)      Competitive Merit                                    -   Appendix 'B'   \n ",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph(
				"\t \t \t \t \t(c)      Nominated List: DSSC & DSTSC           -   Appendix 'C'   \n ", fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(
				new Paragraph("\t \t \t \t \t(d)      Reserves List: DSSC & DSTSC             -   Appendix 'D'   \n ",
						fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(
				new Paragraph("\t \t \t \t \t(e)      List of Candidates who did not Qualify   -   Appendix 'E'   \n ",
						fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph(
				"\t \t \t \t \t(f)      List of Absentees                                     -   Appendix 'F'   \n ",
				fontTablepara));

//	tableC153.addCell("");
		tableC153.addCell(new Paragraph(
				"\t \t \t \t \t(g)      List of Withdrawals                                 -   Appendix 'G'   \n ",
				fontTablepara));

		tableC153.addCell("");
//	tableC153.addCell("");

		tableC153.addCell(new Paragraph("2."
				+ "\t \t \t The Course is scheduled from 11 Jun 2022 to 20 Apr 2023. Nominated officers will join the \ncourse on the authority of this letter. NO separate instructions will be"
				+ " issued by DGMT (MT-2). Units of officers who have been nominated or placed in reserve will be informed directly"
				+ "by DGMT (MT-2). Officers earmarked as reserves will atted the course only if subsequently nominated by DGMT (MT-2).\n",
				fontTablepara));
//	tableC153.addCell("The sch of Courses will be promulgated shortly");

		tableC153.addCell("");

		tableC153.addCell(new Paragraph("\n3."
				+ "\t \t \t Joining instructions for the course will be issued to the nominated officers directly by the Defence Services Staff College"
				+ "(DSSC), Wellington. DSSC will ensure that joining instruction to the officers earmarked as reserves specifically state that they will move to DSSC, Wellington only if nominated by the DGMT (MT-2)"
				+ "to attend the Defence Services Staff Course.\n", fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n4"
				+ "\t \t \t Instructions for nomination on Staff Courses abroad, if any, will follow separately.\n",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n5"
				+ "\t \t \t Nominated and reserve officers will be governed by the provisions of SAO 1/S/2013/GS.\n",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n6"
				+ "\t \t \t Qualification on JC course prior to joining DSSC-70 is a mandatory requirement failing"
				+ " which nomination of the affected officer will become null and void.\n", fontTablepara));

		tableC153.addCell("");

		tableC153.addCell(new Paragraph("\n7"
				+ "\t \t \t Discipline.  Officer being nominated for DSSC-70 should be under acceptable discipline criterie (ref Appendix Q of SAO 1/S/2013/GS). Nominated officers should be cleared by the Discipline and Vigilance Directorate, falling which the Nominated of affected officers will stand to be null and void.\n",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n8"
				+ "\t \t \t The units will directly inform DGMT (MT-2) immediately on occurrence of the following in the respect of the officers nominated/earmarked as reserve on the course:- \n",
				fontTablepara));
//	tableC153.addCell("Nomination ofs officers is provisional, subject the meeting QR as per 10/2018/GSA(MT-2) and amdts thereafter prior to joining DSSC/DSTSC as applicable.\n");
		tableC153.addCell(new Paragraph("\n\t\t\t\t\t\t\t\t(a)    Hospitalization. \n", fontTablepara));
		tableC153.addCell(new Paragraph(
				"\n\t\t\t\t\t\t\t\t(b)    Change in permanent/temporary medical category along with details and a copy of the last medical board proceedings. \n",
				fontTablepara));
		tableC153.addCell(new Paragraph(
				"\n\t\t\t\t\t\t\t\t(c)     Involvement  in  a  disciplinary  case where a prime-facie case is  established against the officer, or if the officer has been placed under ban by the DV Dte. \n",
				fontTablepara));
		tableC153.addCell(new Paragraph(
				"\n\t\t\t\t\t\t\t\t(d)     Non-availability of the officer for the course for any other reason. \n",
				fontTablepara));

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n9"
				+ "\t \t \t Movement order  or arrival report of the officers will NOT be endorsed to DGMT (MT-2) by the parent unit.  DSSC, Wellington will submit a consolidated report to DGMT (MT-2) and HQ IDS(TSI).",
				fontTablepara));
//	tableC153.addCell("Instruction for nomination on Staff Course abroad, if any, follow separately.\n");

		tableC153.addCell("");
		tableC153.addCell(new Paragraph("\n10"
				+ "\t \t \t officers on the Competitive and Nominated Lists and those on the Reserves List who are nominated subsequently (on occurrence of any vacancy at the DSSC,Wellington) WILL NOT be\n"
				+ "detailed on any other course/study leave exceeding 26 weeks since it makes them ineligible for attending the Staff Course as per Para 12 (c) of SAO 1/S/2013/GS.",
				fontTablepara));
//	tableC153.addCell("Nominated and reserved officers will be governed by the provision of AO 10/2018/GSA(MT-2) and amdts thereafter.\n");

//	tableC153.addCell("11");
//	tableC153.addCell("Qualification on JC Course prior to joining DSSC-78 & DSTSC-05 is a mandatory requirement failing which nomination of the affected officers will become null and void.\n");
//
//	
//	tableC153.addCell("12");
//	tableC153.addCell("Discipline. Officers being nominated DSSC-78 & DSTSC-05 should be under acceptable discipline criteria(ref Appendix Q of AO 10/2018/GSA(MT-2).Nominated officer(s) should be cleared by the Discipline and Vigilance Directorate failing which the Nomination of,\n"
//			+ "affected officer(s) will become void and null");
//
//	tableC153.addCell("13");
//	tableC153.addCell("The units will directly inform ARTRAC (EXAM SEC) immediately on occurrence of the following in respect of the officers nominated/earmarked  as reserve on the course:~\n");
//
//	tableC153.addCell("");
//	tableC153.addCell("(a) Hospitalization  \n ");
//
//	tableC153.addCell("");
//	tableC153.addCell("(b)Change in permanent/temporary medical category along with details and a copy of the last medical board proceedings.\n ");
//
//	tableC153.addCell("");
//	tableC153.addCell("(c)Involvement in disciplinary case where a prima-facie case is established against the officer, or if the officer has been placed under ban by the DV Dte. \n ");
//
//	tableC153.addCell("");
//	tableC153.addCell("(d)Non-availability of the officer for the course for any other reason.\n ");
//	
//	
//	tableC153.addCell("14");
//	tableC153.addCell("Movement  orders or arrival reports of the officers will not be endorsed  to ARTRAC (EXAM SEC) by the parent unit. DSSC, Wellington & MILIT,Pune will submit a consolidated report to ARTRAC (EXAM SEC) and HQ IDS(TSI.) \n ");
//
//	
//	tableC153.addCell("15");
//	tableC153.addCell("Officers on the Competitive and Nominated lists and those on the Reserve list who are nominated subsequently WILL NOT  be detailed on any other course/study leave exceeding 26 weeks since it makes them ineligible for attending the Staff Course as per Para 12 (c) of AO 10/2018/GSA(MT-2)   \n ");

		PdfPCell cell123_C1;
		cell123_C1 = new PdfPCell();

		cell123_C1.addElement(tabledata_C12);

		cell123_C1.addElement(tabledata_C1);
		cell123_C1.addElement(tabledata_C66);
		cell123_C1.addElement(new Paragraph("\n"));
		cell123_C1.addElement(tabledata_C2);
		cell123_C1.addElement(tabledata_C3);
		cell123_C1.addElement(cell_c12);
		cell123_C1.addElement(new Paragraph("\n"));
		cell123_C1.addElement(tableC153);

		cell123_C1.setBorder(0);
		table_c2.addCell(cell123_C1);

//document.add(table_c2);

//super.buildPdfMetadata(model, document, request);

//==============Covering-letter 2===============//
		PdfPTable table_c3 = new PdfPTable(1);
		table_c3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_c3.setWidthPercentage(100);

		PdfPTable tableC253 = new PdfPTable(2);
		tableC253.setWidths(new int[] { 5, 100 });
		tableC253.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC253.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		tableC253.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC253.setWidthPercentage(100);
		tableC253.setSpacingBefore(5);

		tableC253.addCell("");
		tableC253.addCell("");

		PdfPTable tabledata_C4 = new PdfPTable(2);
		tabledata_C4.setWidths(new int[] { 70, 30 });
		tabledata_C4.setWidthPercentage(100 / 3f);
		tabledata_C4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C4.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head_c44 = new Paragraph("Sd/- " + director_name1 + "", fontTableHeadingSubMainHead);
		Paragraph head_c45 = new Paragraph("(DR Rai)", fontTableHeadingSubMainHead);
		Paragraph head_c48 = new Paragraph("Col", fontTableHeadingSubMainHead);
		Paragraph head_c46 = new Paragraph("Dir MT-2", fontTableHeadingSubMainHead);
		Paragraph head_c47 = new Paragraph("For DCOAS (IS&T)", fontTableHeadingSubMainHead);

		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c44);
		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c45);
		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c48);
		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c46);
		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c47);

		Chunk underlinec2 = new Chunk("Copy to:-", fontTableHeading1);

		underlinec2.setUnderline(0.1f, -2f);

		Phrase phhc212 = new Phrase(underlinec2);
		phhc212.setFont(fontTableHeading2);

		Paragraph cell_c1222 = new Paragraph(phhc212);
		cell_c1222.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableC254 = new PdfPTable(1);
		tableC254.setWidths(new int[] { 100 });
		tableC254.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC254.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableC254.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC254.setWidthPercentage(100);
		tableC254.setSpacingBefore(5);

		tableC254.addCell("");
		tableC254.addCell(new Paragraph(
				"\nAll HQs  Corps , Divs, Areas, Cat A Ests, HQ SFC, HQ IMTRAT, DGAR & CDA (O), Pune (Ink signed copy).",
				fontTablepara));

		tableC254.addCell("");

		Chunk underlinec3 = new Chunk("Internal:-", fontTableHeading1);

		underlinec3.setUnderline(0.1f, -2f);

		Phrase phhc2123 = new Phrase(underlinec3);
		phhc2123.setFont(fontTableHeading2);

		Paragraph cell_c1223 = new Paragraph(phhc2123);
		cell_c1223.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableC255 = new PdfPTable(1);
		tableC255.setWidths(new int[] { 100 });
		tableC255.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC255.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		tableC255.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC255.setWidthPercentage(100);
		tableC255.setSpacingBefore(5);

		tableC255.addCell("");
		tableC255.addCell(new Paragraph(
				"\nMA to COAS, MA to VCOAS,MA to DCOAS (IS&T), MA to DCOAS (P&S), PS to DGMT, S to   MS,   SO to AG,   ALL  Branches at Army Hqs,Duty Room Sena Bhavan, MO Dte  (Ops Room),"
						+ "IG NSG,  DGRR,  DG INF, DGFM,  DG Avn, DGNCC,  DGBR,  IG SFF, Min of Def (R&D and DGI), MISO (PSG), HQ IDS (TSI), SD-1, SD-3, MT-4, MT-9, MT-10, MT-1,MT-2, MT-6, MT-8, MT-9,MT-11, MT-13, MT-14, MT-15, MT-16, MT-17, MT-18, MS Info, MO (Ops Room), DV Dte and file.\n",
				fontTablepara));

		PdfPCell cell123_C2;
		cell123_C2 = new PdfPCell();

		cell123_C2.setPaddingBottom(25f);
		cell123_C2.setBorder(0);
		table_c3.addCell(cell123_C2);
		table_c3.addCell(tableC253);
		cell123_C2.setPaddingBottom(25f);
		cell123_C2.setBorder(0);
		table_c3.addCell(cell123_C2);
		cell123_C2.setPaddingBottom(25f);
		table_c3.addCell(tabledata_C4);

		cell123_C2.setPaddingBottom(15f);
		cell123_C2.setBorder(0);
		table_c3.addCell(cell123_C2);
		table_c3.addCell(cell_c1222);
		table_c3.addCell(tableC254);
		table_c3.addCell(cell_c1223);
		table_c3.addCell(tableC255);

//document.add(table_c3);

//super.buildPdfMetadata(model, document, request);
		// ==============================Arm/Service wise analysis of result
		// ==================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);

		PdfPTable tabledata1 = new PdfPTable(1);
		tabledata1.setWidths(new int[] { 7 });
		tabledata1.setWidthPercentage(100 / 3.5f);
		tabledata1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata1.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head1 = new Paragraph("Appendix 'A'", fontTableHeadingMainHead_l);
		Paragraph head2 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head4 = new Paragraph("Letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head5 = new Paragraph("Dated:" + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata1.addCell(head1);
		tabledata1.addCell(head2);
		tabledata1.addCell(head4);
		tabledata1.addCell(head5);

		Chunk underline1 = new Chunk("ARMY TRAINING COMMAND (EXAM SEC)" + "\n" + "DSSC-78/DSTSC-05 ENTRANCE Exam" + "\n"
				+ "ARM/SERVICES WISE ANALYSIS OF RESULTS", fontTableHeadingSubMainHead);

		Phrase phh2 = new Phrase(underline1);
		underline1.setUnderline(0.1f, -2f);
		Paragraph cell12 = new Paragraph(phh2);
		cell12.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell12);

		PdfPTable tabledata = new PdfPTable(6);
		tabledata.setWidths(new int[] { 3, 3, 3, 3, 3, 3 });
		tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
		tabledata.setWidthPercentage(100);

		Paragraph A1 = new Paragraph("Arm/Service", fontTableHeadingSubMainHead_2);
		Paragraph B1 = new Paragraph("Total Appeared", fontTableHeadingSubMainHead_2);
		Paragraph C1 = new Paragraph("Competitive", fontTableHeadingSubMainHead_2);
		Paragraph D1 = new Paragraph("Nominated for DSSC", fontTableHeadingSubMainHead_2);
		Paragraph E1 = new Paragraph("Nominated for DSTSC", fontTableHeadingSubMainHead_2);
		Paragraph F1 = new Paragraph("Reserve", fontTableHeadingSubMainHead_2);

//	PdfPCell blank_cella;
//	blank_cella = new PdfPCell();
//	blank_cella.addElement(A1);
//	blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
//	blank_cella.setPadding(10);
//	tabledata.addCell(blank_cella);

		PdfPCell blank_cella = new PdfPCell(A1);
		blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella.setPadding(5);
		tabledata.addCell(blank_cella);

		PdfPCell blank_cellb = new PdfPCell(B1);
		blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellb.setPadding(5);
		tabledata.addCell(blank_cellb);

		PdfPCell blank_cellc = new PdfPCell(C1);
		blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellc.setPadding(5);
		tabledata.addCell(blank_cellc);

		PdfPCell blank_celld = new PdfPCell(D1);
		blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_celld.setPadding(5);
		tabledata.addCell(blank_celld);

		PdfPCell blank_celle = new PdfPCell(E1);
//	blank_celle.setRowspan(2);
		blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_celle.setPadding(5);
		tabledata.addCell(blank_celle);

		PdfPCell blank_cellf = new PdfPCell(F1);
		blank_cellf.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf.setPadding(5);

		tabledata.addCell(blank_cellf);

		ArrayList<List<String>> armresult = (ArrayList<List<String>>) model.get("getArmwiseAnalysisReport");

		for (int i = 0; i < armresult.size(); i++) {

			List<String> l = armresult.get(i);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
			Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdata);

			PdfPCell cellar = new PdfPCell();

			cellar.setFixedHeight(20f);
			if (i % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}

			cellar.setPhrase(blank1);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cellar);

			cellar.setPhrase(blank6);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata.addCell(cellar);

//		tabledata.addCell(blank1);
//		tabledata.addCell(blank2);
//		tabledata.addCell(blank3);
//		tabledata.addCell(blank4);
//		tabledata.addCell(blank5);
//		tabledata.addCell(blank6);

		}

		PdfPTable tabledataend = new PdfPTable(1);
		tabledataend.setWidths(new int[] { 5 });
		tabledataend.setWidthPercentage(100);
		tabledataend.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledataend.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
		tabledataend.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell cell123 = new PdfPCell();
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tabledata1);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tableheader);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tabledata);
		// cell123.addElement(tabledataend);
		cell123.setBorder(0);
		table.addCell(cell123);

		PdfPCell cell124 = new PdfPCell();
		cell124.setVerticalAlignment(Element.ALIGN_BOTTOM);
		cell124.setBorder(0);
		cell124.addElement(tabledataend);
		table.getDefaultCell().setBottom(0);
		table.addCell(cell124);

//===========================Competitive Merit List=============//

		PdfPTable table1 = new PdfPTable(1);
		table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table1.setWidthPercentage(100);

		PdfPTable tabledata12 = new PdfPTable(1);
		tabledata12.setWidths(new int[] { 7 });
		tabledata12.setWidthPercentage(100 / 3.5f);
		tabledata12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata12.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata12.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head_B1 = new Paragraph("Appendix 'B'", fontTableHeadingMainHead_l);
		Paragraph head_B2 = new Paragraph("(Refers to Para 1(B) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head_B3 = new Paragraph("Letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head_B4 = new Paragraph("Dated:" + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata12.addCell(head_B1);
		tabledata12.addCell(head_B2);
		tabledata12.addCell(head_B3);
		tabledata12.addCell(head_B4);

		Chunk chunk1 = new Chunk();

		Chunk underline12 = new Chunk("COMPETITIVE MERIT LIST", fontTableHeadingSubMainHead);
		underline12.setUnderline(0.1f, -2f);
		Phrase phh12 = new Phrase(underline12);
		phh12.add("\n");
		phh12.add("\n");

		phh12.setFont(fontTableHeadingSubMainHead);

		Paragraph cell11 = new Paragraph(phh12);
		cell12.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader1 = new PdfPTable(1);
		tableheader1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader1.setWidthPercentage(100);
		tableheader1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader1.addCell(cell11);
		tableheader1.addCell(new Paragraph(
				"THE UNDER MENTIONED OFFICERS LISTED IN THEIR ORDER OF SENIORITY BY ARMS AND \n"
						+ "SERVICES HAVE SECURED THE FIRST 20 COMPETITIVE MERIT VACANCIES IN THE DEFENCE \n"
						+ "SERVICES STAFF COLLEGE ENTRANCE EXAMINATION FOR DSSC-78 COMMENCING IN JUNE 2022\n\n\n   ",
				fontTableHeadingSubMainHeadNew_2));

		PdfPTable tabledata13 = new PdfPTable(5);
		tabledata13.setWidths(new int[] { 2, 3, 4, 7, 8 });
		tabledata13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		tabledata13.setWidthPercentage(100);
		

		Paragraph a = new Paragraph("S NO", fontTableHeadingSubMainHead_2);
		Paragraph f = new Paragraph("PERSONAL NO", fontTableHeadingSubMainHead_2);
		Paragraph b = new Paragraph("RANK", fontTableHeadingSubMainHead_2);
		Paragraph c = new Paragraph("NAME", fontTableHeadingSubMainHead_2);
		Paragraph d = new Paragraph("UNIT", fontTableHeadingSubMainHead_2);
//		Paragraph e = new Paragraph("ARM DESC", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cella1 = new PdfPCell(a);
		blank_cella1.setPadding(5);
		blank_cella1.setHorizontalAlignment(Element.ALIGN_LEFT);
//		table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		
		

		PdfPCell blank_cellb1 = new PdfPCell(b);
		blank_cellb1.setPadding(5);
		blank_cellb1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellc1 = new PdfPCell(c);
		blank_cellc1.setPadding(5);
		blank_cellc1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_celld1 = new PdfPCell(d);
		blank_celld1.setPadding(5);
		blank_celld1.setHorizontalAlignment(Element.ALIGN_CENTER);

//		PdfPCell blank_celle1 = new PdfPCell(e);
//		blank_celle1.setPadding(5);
//		blank_celle1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellF1 = new PdfPCell(f);
		blank_cellF1.setPadding(5);
		blank_cellF1.setHorizontalAlignment(Element.ALIGN_CENTER);

		tabledata13.addCell(blank_cella1);
		tabledata13.addCell(blank_cellF1);
		tabledata13.addCell(blank_cellb1);
		tabledata13.addCell(blank_cellc1);
		tabledata13.addCell(blank_celld1);
//		tabledata13.addCell(blank_celle1);
		String arm="";
		ArrayList<List<String>> getcompatative = (ArrayList<List<String>>) model.get("getcompatativemeritlistReport");
		System.err.println("getcompatative===========" + getcompatative);
		for (int i = 0; i < getcompatative.size(); i++) {

			List<String> l = getcompatative.get(i);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
			Paragraph blank6 = new Paragraph(l.get(5) + "\n", fontTableHeadingMainHead);
			
			
			PdfPCell cellar = new PdfPCell();
			
			

			cellar.setFixedHeight(20f);
			if (i % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}
			
			if(!l.get(5).equals(arm)) {
				arm=l.get(5);
				PdfPCell cellarow = new PdfPCell();
				cellarow.setColspan(6);
				cellarow.setPhrase(blank6);
				cellarow.setBorder(Rectangle.NO_BORDER);
				cellarow.setPadding(2);
				cellarow.setPaddingBottom(8f);
				cellarow.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cellarow);
			}
				
			cellar.setPhrase(blank1);
			cellar.setBorder(Rectangle.NO_BORDER);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata13.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata13.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata13.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata13.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata13.addCell(cellar);

//			cellar.setPhrase(blank6);
//			cellar.setPadding(2);
//			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//			tabledata13.addCell(cellar);
			
//			tabledata13.addCell(blank1);
//			tabledata13.addCell(blank2);
//			tabledata13.addCell(blank3);
//			tabledata13.addCell(blank4);
//			tabledata13.addCell(blank5);

		}

		PdfPTable tabledataend1 = new PdfPTable(1);
		tabledataend1.setWidths(new int[] { 5 });
		tabledataend1.setWidthPercentage(100);
		tabledataend1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledataend1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell cell1231;
		cell1231 = new PdfPCell();
		cell1231.addElement(new Paragraph("\n"));
		cell1231.addElement(tabledata12);
		cell1231.addElement(new Paragraph("\n"));
		cell1231.addElement(tableheader1);
		cell1231.addElement(new Paragraph("\n"));
		cell1231.addElement(tabledata13);

		cell1231.addElement(tabledataend1);
		cell1231.setBorder(0);
		table1.addCell(cell1231);

//==================DSSC====================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table4 = new PdfPTable(1);
		table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table4.setWidthPercentage(100);

		PdfPTable tabledata4 = new PdfPTable(1);
		tabledata4.setWidths(new int[] { 7 });
		tabledata4.setWidthPercentage(100 / 3.5f);
		tabledata4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata4.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head45 = new Paragraph("Appendix 'C'", fontTableHeadingMainHead_l);
		Paragraph head41 = new Paragraph("(Refers to Para 1(C) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head43 = new Paragraph("Letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head44 = new Paragraph("Dated:" + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata4.addCell(head45);
		tabledata4.addCell(head41);
		tabledata4.addCell(head43);
		tabledata4.addCell(head44);

		Chunk army_training_command_heading = new Chunk("LIST OF NOMINATED OFFICERS FOR DSSC-78",
				fontTableHeadingSubMainHead);
		army_training_command_heading.setUnderline(0.1f, -2f);
		Paragraph army_training_command_paragraph = new Paragraph(army_training_command_heading);
		army_training_command_paragraph.setFont(fontTableHeading1);
		army_training_command_paragraph.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader4 = new PdfPTable(1);
		tableheader4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader4.setWidthPercentage(100);
		tableheader4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader4.addCell(army_training_command_paragraph);
		tableheader4.addCell(new Paragraph(
				"THE UNDER MENTIONED OFFICER LISTED IN THEIR ORDER OF SENIORITY BY ARMS AND \n  "
						+ "         SERVICES HAVE BEEN NOMINATED TO ATTEND THE DEFENCE SERVICES STAFF COLLEGE COURSE COMMENCING IN JUNE 2022\n\n\n",
				fontTableHeadingSubMainHeadNew_2));

		PdfPTable tabledata41 = new PdfPTable(5);
//	tabledata41.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tabledata41.setWidths(new int[] { 2, 3, 3, 6, 4 });
		tabledata41.setWidthPercentage(100);
		tabledata41.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata41.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);

		ArrayList<List<String>> fullypassed = (ArrayList<List<String>>) model.get("fullypassed_D");
		Paragraph a_C = new Paragraph("S NO", fontTableHeadingSubMainHead_2);
		Paragraph f_C = new Paragraph("PERSONAL NO", fontTableHeadingSubMainHead_2);

		Paragraph b_C = new Paragraph("RANK", fontTableHeadingSubMainHead_2);
		Paragraph c_C = new Paragraph("NAME", fontTableHeadingSubMainHead_2);
		Paragraph d_C = new Paragraph("UNIT", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cella1_C = new PdfPCell(a_C);
		blank_cella1_C.setPadding(5);
		blank_cella1_C.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell blank_cella2_C = new PdfPCell(f_C);
		blank_cella2_C.setPadding(5);
		blank_cella2_C.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella3_C = new PdfPCell(b_C);
		blank_cella3_C.setPadding(5);
		blank_cella3_C.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella4_C = new PdfPCell(c_C);
		blank_cella4_C.setPadding(5);
		blank_cella4_C.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella5_C = new PdfPCell(d_C);
		blank_cella5_C.setPadding(5);
		blank_cella5_C.setHorizontalAlignment(Element.ALIGN_CENTER);

		tabledata41.addCell(blank_cella1_C);
		tabledata41.addCell(blank_cella2_C);
		tabledata41.addCell(blank_cella3_C);
		tabledata41.addCell(blank_cella4_C);
		tabledata41.addCell(blank_cella5_C);

		ArrayList<List<String>> getnominateddssclistReport = (ArrayList<List<String>>) model.get("getnominateddssclistReport");

		for (int i = 0; i < getnominateddssclistReport.size(); i++) {

			List<String> l = getnominateddssclistReport.get(i);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);

			PdfPCell cellar = new PdfPCell();

			cellar.setFixedHeight(20f);
			if (i % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}

			cellar.setPhrase(blank1);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata41.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41.addCell(cellar);

//			tabledata41.addCell(blank1);
//			tabledata41.addCell(blank2);
//			tabledata41.addCell(blank3);
//			tabledata41.addCell(blank4);
//			tabledata41.addCell(blank5);

		}

		PdfPCell cell1236_f;
		cell1236_f = new PdfPCell();
		cell1236_f.addElement(tabledata4);
		cell1236_f.addElement(new Paragraph("\n"));
		cell1236_f.addElement(tableheader4);
		cell1236_f.addElement(tabledata41);
		cell1236_f.setBorder(0);
		table4.addCell(cell1236_f);
		// writeFooterTable(arg2,document,table4);

		// ==================DSTSC====================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table4_2 = new PdfPTable(1);
		table4_2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table4_2.setWidthPercentage(100);

		PdfPTable tabledata4_2 = new PdfPTable(1);
		tabledata4_2.setWidths(new int[] { 7 });
		tabledata4_2.setWidthPercentage(100 / 3.5f);
		tabledata4_2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata4_2.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata4_2.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head45_2 = new Paragraph("Appendix 'C' Contd.", fontTableHeadingMainHead_l);

		tabledata4_2.addCell(head45_2);

		Chunk DSTSC_heading = new Chunk("LIST OF NOMINATED OFFICERS FOR DSTSC-5", fontTableHeadingSubMainHead);
		DSTSC_heading.setUnderline(0.1f, -2f);
		Paragraph DSTSC_paragraph = new Paragraph(DSTSC_heading);
		DSTSC_paragraph.setFont(fontTableHeading1);
		DSTSC_paragraph.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader4_DSTSC = new PdfPTable(1);
		tableheader4_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader4_DSTSC.setWidthPercentage(100);
		tableheader4_DSTSC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader4_DSTSC.addCell(DSTSC_paragraph);
		tableheader4_DSTSC.addCell(new Paragraph(
				"THE UNDER MENTIONED OFFICER LISTED IN THEIR ORDER OF SENIORITY BY ARMS AND \n  "
						+ "SERVICES HAVE BEEN NOMINATED TO ATTEND THE DEFENCE SERVICES TECHNICAL STAFF COLLEGE COURSE COMMENCING-5\n\n",
				fontTableHeadingSubMainHeadNew_2));

		PdfPTable tabledata41_DSTSC = new PdfPTable(5);
//	tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tabledata41_DSTSC.setWidths(new int[] { 1, 2, 3, 7, 4 });
		tabledata41_DSTSC.setWidthPercentage(100);
		tabledata41_DSTSC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata41_DSTSC.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);

		ArrayList<List<String>> DSTSC = (ArrayList<List<String>>) model.get("fullypassed_D");
		Paragraph a_C2 = new Paragraph("S NO", fontTableHeadingSubMainHead_2);
		Paragraph f_C2 = new Paragraph("PERSONAL NO", fontTableHeadingSubMainHead_2);

		Paragraph b_C2 = new Paragraph("RANK", fontTableHeadingSubMainHead_2);
		Paragraph c_C2 = new Paragraph("NAME", fontTableHeadingSubMainHead_2);
		Paragraph d_C2 = new Paragraph("UNIT", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cella1_C1 = new PdfPCell(a_C2);
		blank_cella1_C1.setPadding(5);
		blank_cella1_C1.setHorizontalAlignment(Element.ALIGN_LEFT);

		PdfPCell blank_cella2_C1 = new PdfPCell(f_C2);
		blank_cella2_C1.setPadding(5);
		blank_cella2_C1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella3_C1 = new PdfPCell(b_C2);
		blank_cella3_C1.setPadding(5);
		blank_cella3_C1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella4_C1 = new PdfPCell(c_C2);
		blank_cella4_C1.setPadding(5);
		blank_cella4_C1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella5_C1 = new PdfPCell(d_C2);
		blank_cella5_C1.setPadding(5);
		blank_cella5_C1.setHorizontalAlignment(Element.ALIGN_CENTER);

		tabledata41_DSTSC.addCell(blank_cella1_C1);
		tabledata41_DSTSC.addCell(blank_cella2_C1);
		tabledata41_DSTSC.addCell(blank_cella3_C1);
		tabledata41_DSTSC.addCell(blank_cella4_C1);
		tabledata41_DSTSC.addCell(blank_cella5_C1);

		ArrayList<List<String>> getnominateddstsclistReport = (ArrayList<List<String>>) model.get("getnominateddstsclistReport");

		for (int i = 0; i < getnominateddstsclistReport.size(); i++) {

			List<String> l = getnominateddstsclistReport.get(i);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);

			PdfPCell cellar = new PdfPCell();

			cellar.setFixedHeight(20f);
			if (i % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}

			cellar.setPhrase(blank1);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_DSTSC.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_DSTSC.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_DSTSC.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata41_DSTSC.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_DSTSC.addCell(cellar);

//			tabledata41_DSTSC.addCell(blank1);
//			tabledata41_DSTSC.addCell(blank2);
//			tabledata41_DSTSC.addCell(blank3);
//			tabledata41_DSTSC.addCell(blank4);
//			tabledata41_DSTSC.addCell(blank5);

		}

		PdfPCell cell1236_C12;
		cell1236_C12 = new PdfPCell();
		cell1236_C12.addElement(tabledata4_2);
		cell1236_C12.addElement(new Paragraph("\n"));
		cell1236_C12.addElement(tableheader4_DSTSC);
		cell1236_C12.addElement(tabledata41_DSTSC);
		cell1236_C12.setBorder(0);
		table4_2.addCell(cell1236_C12);
		// writeFooterTable(arg2,document,table4);

		// =================Reserve====================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table5 = new PdfPTable(1);
		table5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table5.setWidthPercentage(100);

		PdfPTable tabledata5 = new PdfPTable(1);
		tabledata5.setWidths(new int[] { 5 });
		tabledata5.setWidthPercentage(100 / 3.5f);
		tabledata5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata5.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata5.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head55 = new Paragraph("Appendix 'D'", fontTableHeadingMainHead_l);
		Paragraph head51 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head52 = new Paragraph("Letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head53 = new Paragraph("Dated:" + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata5.addCell(head55);
		tabledata5.addCell(head51);
		tabledata5.addCell(head52);
		tabledata5.addCell(head53);

		// Chunk underline = new Chunk("Appendix 'A' " +"\n"+ "Refers to Para 1(a) of
		// IHQ MoD(Army)" +"\n"+ "DGMT(MT-2)" +"\n"+ "Leter No A/18014/B 2011/GS/MT-2"
		// +"\n"+ "Dated 18 Nov 2011)", fontTableHeading1);
		Chunk underline5 = new Chunk("LIST OF RESERVE OFFICERS FOR DSSC-78 / DSTSC-5", fontTableHeadingSubMainHead);
		underline5.setUnderline(0.1f, -2f);
		Phrase phh5 = new Phrase(underline5);

		phh5.add("\n");
		phh5.add("\n");
		phh5.setFont(fontTableHeadingSubMainHead);

		Paragraph cell51 = new Paragraph(phh5);
		cell51.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader5 = new PdfPTable(1);
		tableheader5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader5.setWidthPercentage(100);
		tableheader5.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader5.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader5.addCell(cell51);

		PdfPTable tabledata51 = new PdfPTable(7);

		tabledata51.setWidths(new int[] { 2, 4, 3, 9, 5, 4, 4 });
		tabledata51.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata51.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata51.setWidthPercentage(100);

		ArrayList<List<String>> result_withheld = (ArrayList<List<String>>) model.get("resultwithheld_d");

		Paragraph a5 = new Paragraph("S NO.", fontTableHeadingSubMainHead_2);
		Paragraph b5 = new Paragraph("PERSONAL NO", fontTableHeadingSubMainHead_2);
		Paragraph c5 = new Paragraph("RANK", fontTableHeadingSubMainHead_2);
		Paragraph d5 = new Paragraph("NAME", fontTableHeadingSubMainHead_2);
		Paragraph e5 = new Paragraph("UNIT", fontTableHeadingSubMainHead_2);
		Paragraph f5 = new Paragraph("1STCHOICE", fontTableHeadingSubMainHead_2);
		Paragraph g5 = new Paragraph("2NDCHOICE", fontTableHeadingSubMainHead_2);
//		Paragraph h5 = new Paragraph("ARM DESC", fontTableHeadingSubMainHead_2);

		tabledata51.addCell(a5);
		tabledata51.addCell(b5);
		tabledata51.addCell(c5);
		tabledata51.addCell(d5);
		tabledata51.addCell(e5);
		tabledata51.addCell(f5);
		tabledata51.addCell(g5);
//		tabledata51.addCell(h5);
		String Rarm = "";
		ArrayList<List<String>> getreserveofficeristReport = (ArrayList<List<String>>) model.get("getreserveofficeristReport");

		System.out.println("getreserveofficeristReport=========" + getreserveofficeristReport);
//		ArrayList<String> list = new ArrayList<String>();
//		for (int i = 0; i < getreserveofficeristReport.size(); i++) {
//			List<String> l = getreserveofficeristReport.get(i);
//			list.add(l.get(7));
//		}
//
//		HashSet<String> hset = new HashSet<String>(list);
//		System.out.println("hset++++++++++++++=" +  hset);
//		
//			
//		for( String strCurrentNumber : hset ){
//            System.out.println(" strCurrentNumber ++++++++++++"+ strCurrentNumber );
//            Paragraph blank1 = new Paragraph("");
//			Paragraph blank2 = new Paragraph("");
//			Paragraph blank3 = new Paragraph("");
//			Paragraph blank4 = new Paragraph("");
//			Paragraph blank5 = new Paragraph("");
//			Paragraph blank6 = new Paragraph("");
//			Paragraph blank7 = new Paragraph("");
//            Paragraph blank8 = new Paragraph(strCurrentNumber, fontTableHeadingdata);
//            
//            
//            
//            
//            for (int i = 0; i < getreserveofficeristReport.size(); i++) {
//
//				List<String> l = getreserveofficeristReport.get(i);
//				
//				if (l.get(7) == strCurrentNumber) {
//					Paragraph blank11 = new Paragraph(l.get(0), fontTableHeadingdata);
//					Paragraph blank22 = new Paragraph(l.get(1), fontTableHeadingdata);
//					Paragraph blank33 = new Paragraph(l.get(2), fontTableHeadingdata);
//					Paragraph blank44 = new Paragraph(l.get(3), fontTableHeadingdata);
//					Paragraph blank55 = new Paragraph(l.get(4), fontTableHeadingdata);
//					Paragraph blank66 = new Paragraph(l.get(5), fontTableHeadingdata);
//					Paragraph blank77 = new Paragraph(l.get(6), fontTableHeadingdata);
//					Paragraph blank88 = new Paragraph(l.get(7), fontTableHeadingdata);
//					
//					PdfPCell cellar = new PdfPCell();
//					cellar.setFixedHeight(20f);
//					if (i % 2 == 0) {
//						cellar.setBackgroundColor(java.awt.Color.lightGray);
//					}
//
//					cellar.setPhrase(blank11);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank22);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank33);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank44);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank55);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank66);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank77);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//					
//					cellar.setPhrase(blank8);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//				}
//            
//            }
//        }

			

//			for (int i = 0; i < getreserveofficeristReport.size(); i++) {
//
//				List<String> l = getreserveofficeristReport.get(i);
				
					
					
//					Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
//					Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
//					Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
//					Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
//					Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
//					Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdata);
//					Paragraph blank7 = new Paragraph(l.get(6), fontTableHeadingdata);
//					Paragraph blank8 = new Paragraph(l.get(7), fontTableHeadingdata);

//					PdfPCell cellar = new PdfPCell();
//
//					cellar.setFixedHeight(20f);
//					if (i % 2 == 0) {
//						cellar.setBackgroundColor(java.awt.Color.lightGray);
//					}
//
//					cellar.setPhrase(blank1);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank2);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank3);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank4);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank5);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank6);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank7);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
//
//					cellar.setPhrase(blank8);
//					cellar.setPadding(2);
//					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//					tabledata51.addCell(cellar);
				
				

//				tabledata51.addCell(blank1);
//				tabledata51.addCell(blank2);
//				tabledata51.addCell(blank3);
//				tabledata51.addCell(blank4);
//				tabledata51.addCell(blank5);
//				tabledata51.addCell(blank6);
//				tabledata51.addCell(blank7);

//			}

		

		for (int i = 0; i < getreserveofficeristReport.size(); i++) {

			List<String> l = getreserveofficeristReport.get(i);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
			Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdata);
			Paragraph blank7 = new Paragraph(l.get(6), fontTableHeadingdata);
			Paragraph blank8 = new Paragraph(l.get(7), fontTableHeadingMainHead);

			PdfPCell cellar = new PdfPCell();

			cellar.setFixedHeight(20f);
			if (i % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}
			
			
			if(!l.get(7).equals(Rarm)) {
				Rarm=l.get(7);
				PdfPCell cellarow = new PdfPCell();
				cellarow.setColspan(7);
				cellarow.setPhrase(blank8);
				cellarow.setBorder(Rectangle.NO_BORDER);
				cellarow.setPadding(2);
				cellarow.setPaddingBottom(8f);
				cellarow.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata51.addCell(cellarow);
			}
			

			cellar.setPhrase(blank1);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellar.setBorder(Rectangle.NO_BORDER);
			tabledata51.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata51.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata51.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata51.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata51.addCell(cellar);

			cellar.setPhrase(blank6);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata51.addCell(cellar);

			cellar.setPhrase(blank7);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata51.addCell(cellar);
			
//			cellar.setPhrase(blank8);
//			cellar.setPadding(2);
//			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//			tabledata51.addCell(cellar);

//			tabledata51.addCell(blank1);
//			tabledata51.addCell(blank2);
//			tabledata51.addCell(blank3);
//			tabledata51.addCell(blank4);
//			tabledata51.addCell(blank5);
//			tabledata51.addCell(blank6);
//			tabledata51.addCell(blank7);

		}

		PdfPCell cell1235;
		cell1235 = new PdfPCell();
		cell1235.addElement(tabledata5);
		cell1235.addElement(tableheader5);
		cell1235.addElement(tabledata51);

		cell1235.setBorder(0);
		table5.addCell(cell1235);

		// ==============ALMC

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table4_4 = new PdfPTable(1);
		table4_4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table4_4.setWidthPercentage(100);

		PdfPTable tabledata4_4 = new PdfPTable(1);
		tabledata4_4.setWidths(new int[] { 7 });
		tabledata4_4.setWidthPercentage(100 / 3.5f);
		tabledata4_4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata4_4.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata4_4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head45_21 = new Paragraph("Appendix 'E' Contd.", fontTableHeadingMainHead_l);
		Paragraph head6122 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head632 = new Paragraph("Letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head642 = new Paragraph("Dated:" + letter_date1 + ")", fontTableHeadingMainHead_l);
		tabledata4_4.addCell(head45_21);
		tabledata4_4.addCell(head6122);
		tabledata4_4.addCell(head632);
		tabledata4_4.addCell(head642);

		Chunk ALMC_heading = new Chunk("LIST OF NOMINATED OFFICERS FOR ALMC/ISC", fontTableHeadingSubMainHead);
		ALMC_heading.setUnderline(0.1f, -2f);
		Paragraph ALMC_paragraph = new Paragraph(ALMC_heading);
		ALMC_paragraph.setFont(fontTableHeading1);
		ALMC_paragraph.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader4_ALMC = new PdfPTable(1);
		tableheader4_ALMC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader4_ALMC.setWidthPercentage(100);
		tableheader4_ALMC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader4_ALMC.addCell(ALMC_paragraph);
		tableheader4_ALMC.addCell(new Paragraph(
				"THE UNDER MENTIONED OFFICER LISTED IN THEIR ORDER OF SENIORITY BY ARMS AND \n  "
						+ "         SERVICES HAVE BEEN NOMINATED TO ATTEND THE DEFENCE SERVICES TECHNICAL STAFF COLLEGE COURSE COMMENCING-5 \n\n\n",
				fontTableHeadingSubMainHeadNew_2));

		PdfPTable tabledata41_ALMC = new PdfPTable(5);
//		tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tabledata41_ALMC.setWidths(new int[] { 1, 3, 3, 7, 4 });
		tabledata41_ALMC.setWidthPercentage(100);
		tabledata41_ALMC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata41_ALMC.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);

		Paragraph a_C22 = new Paragraph("S NO", fontTableHeadingSubMainHead_2);
		Paragraph f_C22 = new Paragraph("PERSONAL NO", fontTableHeadingSubMainHead_2);
		Paragraph b_C22 = new Paragraph("RANK", fontTableHeadingSubMainHead_2);
		Paragraph c_C22 = new Paragraph("NAME", fontTableHeadingSubMainHead_2);
		Paragraph d_C22 = new Paragraph("UNIT", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cella1_C122 = new PdfPCell(a_C22);
		blank_cella1_C122.setPadding(5);
		blank_cella1_C122.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella2_C12 = new PdfPCell(f_C22);
		blank_cella2_C12.setPadding(5);
		blank_cella2_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella3_C12 = new PdfPCell(b_C22);
		blank_cella3_C12.setPadding(5);
		blank_cella3_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella4_C12 = new PdfPCell(c_C22);
		blank_cella4_C12.setPadding(5);
		blank_cella4_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cella5_C12 = new PdfPCell(d_C22);
		blank_cella5_C12.setPadding(5);
		blank_cella5_C12.setHorizontalAlignment(Element.ALIGN_CENTER);

		tabledata41_ALMC.addCell(blank_cella1_C122);
		tabledata41_ALMC.addCell(blank_cella2_C12);
		tabledata41_ALMC.addCell(blank_cella3_C12);
		tabledata41_ALMC.addCell(blank_cella4_C12);
		tabledata41_ALMC.addCell(blank_cella5_C12);

		ArrayList<List<String>> getALMCISCList = (ArrayList<List<String>>) model.get("getALMCISCList");

		for (int i = 0; i < getALMCISCList.size(); i++) {

			List<String> l = getALMCISCList.get(i);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);

			PdfPCell cellar = new PdfPCell();

			cellar.setFixedHeight(20f);
			if (i % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}

			cellar.setPhrase(blank1);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_ALMC.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_ALMC.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_ALMC.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata41_ALMC.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_ALMC.addCell(cellar);

//			tabledata41_ALMC.addCell(blank1);
//			tabledata41_ALMC.addCell(blank2);
//			tabledata41_ALMC.addCell(blank3);
//			tabledata41_ALMC.addCell(blank4);
//			tabledata41_ALMC.addCell(blank5);

		}

		PdfPCell cell1236_C122;
		cell1236_C122 = new PdfPCell();
		cell1236_C122.addElement(tabledata4_4);
		cell1236_C122.addElement(new Paragraph("\n"));
		cell1236_C122.addElement(tableheader4_ALMC);
		cell1236_C122.addElement(tabledata41_ALMC);
		cell1236_C122.setBorder(0);
		table4_4.addCell(cell1236_C122);
		// writeFooterTable(arg2,document,table4);

		// =====================================Failed========================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table6 = new PdfPTable(1);
		table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table6.setWidthPercentage(100);

		PdfPTable tabledata6 = new PdfPTable(1);
		tabledata6.setWidths(new int[] { 5 });
		tabledata6.setWidthPercentage(100 / 3.5f);
		tabledata6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata6.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata6.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head61 = new Paragraph("Appendix 'F'", fontTableHeadingMainHead_l);
		Paragraph head612 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head63 = new Paragraph("Letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head64 = new Paragraph("Dated:" + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata6.addCell(head61);
		tabledata6.addCell(head612);
		tabledata6.addCell(head63);
		tabledata6.addCell(head64);

		Chunk underline6 = new Chunk("DIRECTORATE GENERAL OF MILITARY TRAINING (MT-2)" + "\n\n"
				+ "DSSC-78 / DSTSC - 05 ENTRANCE EXAM SEP 2020" + "\n\n" + "MARKS OF OFFICERS WHO DID NOT QUALIFY",
				fontTableHeadingSubMainHead);

		Phrase phh6 = new Phrase(underline6);
		underline6.setUnderline(0.1f, -2f);
		phh6.add("\n");
		phh6.add("\n");
		phh6.setFont(fontTableHeadingSubMainHead);

		Paragraph cell61 = new Paragraph(phh6);
		cell61.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader6 = new PdfPTable(1);
		tableheader6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader6.setWidthPercentage(100);
		tableheader6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader6.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader6.addCell(cell61);

		PdfPTable tabledata61 = new PdfPTable(11);

		tabledata61.setWidths(new int[] { 3, 6, 4, 9, 5, 3, 3, 3, 3, 3, 3 });
		tabledata61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata61.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata61.setWidthPercentage(100);

		Paragraph a6 = new Paragraph("S. NO.", fontTableHeadingSubMainHeadNew);
		Paragraph b6 = new Paragraph("PERSONAL NO.", fontTableHeadingSubMainHeadNew);
		Paragraph c6 = new Paragraph("RANK", fontTableHeadingSubMainHeadNew);
		Paragraph d6 = new Paragraph("NAME", fontTableHeadingSubMainHeadNew);
		Paragraph e6 = new Paragraph("ARM/SERVICE", fontTableHeadingSubMainHeadNew);
		Paragraph f6 = new Paragraph("Marks out of 500 Each", fontTableHeadingSubMainHeadNew);

		PdfPCell blank_cella1_C11 = new PdfPCell(a6);
		blank_cella1_C11.setRowspan(2);
		blank_cella1_C11.setPaddingLeft(5f);
		blank_cella1_C11.setPaddingTop(7f);

		PdfPCell blank_cella1_C12 = new PdfPCell(b6);
		blank_cella1_C12.setRowspan(2);
		blank_cella1_C12.setPaddingLeft(8f);
		blank_cella1_C12.setPaddingTop(7f);

		PdfPCell blank_cella1_C13 = new PdfPCell(c6);
		blank_cella1_C13.setRowspan(2);
		blank_cella1_C13.setPaddingLeft(12f);
		blank_cella1_C13.setPaddingTop(7f);

		PdfPCell blank_cella1_C14 = new PdfPCell(d6);
		blank_cella1_C14.setRowspan(2);
		blank_cella1_C14.setPaddingLeft(40f);
		blank_cella1_C14.setPaddingTop(7f);

		PdfPCell blank_cella1_C15 = new PdfPCell(e6);
		blank_cella1_C15.setRowspan(2);
		blank_cella1_C15.setPaddingLeft(5f);
		blank_cella1_C15.setPaddingTop(7f);

		PdfPCell blank_cella1_C16 = new PdfPCell(f6);
		blank_cella1_C16.setColspan(6);
		blank_cella1_C16.setPaddingLeft(80f);

		tabledata61.addCell(blank_cella1_C11);
		tabledata61.addCell(blank_cella1_C12);
		tabledata61.addCell(blank_cella1_C13);
		tabledata61.addCell(blank_cella1_C14);
		tabledata61.addCell(blank_cella1_C15);
		tabledata61.addCell(blank_cella1_C16);

		Paragraph a66 = new Paragraph("TAC A", fontTableHeadingSubMainHeadNew);
		Paragraph b66 = new Paragraph("TAC B", fontTableHeadingSubMainHeadNew);
		Paragraph c66 = new Paragraph("A & L", fontTableHeadingSubMainHeadNew);
		Paragraph d66 = new Paragraph("CA", fontTableHeadingSubMainHeadNew);
		Paragraph e66 = new Paragraph("SMT", fontTableHeadingSubMainHeadNew);
		Paragraph f66 = new Paragraph("MH", fontTableHeadingSubMainHeadNew);

		tabledata61.addCell(a66);
		tabledata61.addCell(b66);
		tabledata61.addCell(c66);
		tabledata61.addCell(d66);
		tabledata61.addCell(e66);
		tabledata61.addCell(f66);

		ArrayList<List<String>> getfailofficeristReport = (ArrayList<List<String>>) model
				.get("getfailofficeristReport");
		int index5 = 1;
		for (int i5 = 0; i5 < getfailofficeristReport.size(); i5++) {

			List<String> l = getfailofficeristReport.get(i5);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
			Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdata);
			Paragraph blank7 = new Paragraph(l.get(6), fontTableHeadingdata);
			Paragraph blank8 = new Paragraph(l.get(7), fontTableHeadingdata);
			Paragraph blank9 = new Paragraph(l.get(8), fontTableHeadingdata);
			Paragraph blank10 = new Paragraph(l.get(9), fontTableHeadingdata);
			Paragraph blank11 = new Paragraph(l.get(10), fontTableHeadingdata);

			PdfPCell cellar = new PdfPCell();

			cellar.setFixedHeight(20f);
			if (i5 % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}

			cellar.setPhrase(blank1);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata61.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cellar);
			

			cellar.setPhrase(blank6);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			cellar.setBorder(Rectangle.NO_BORDER);
			tabledata61.addCell(cellar);

			cellar.setPhrase(blank7);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cellar);

			cellar.setPhrase(blank8);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cellar);

			cellar.setPhrase(blank9);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cellar);

			cellar.setPhrase(blank10);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cellar);

			cellar.setPhrase(blank11);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
//			cellar.setBorder(Rectangle.RIGHT);
			tabledata61.addCell(cellar);

//			tabledata61.addCell(blank1);
//			tabledata61.addCell(blank2);
//			tabledata61.addCell(blank3);
//			tabledata61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
//			tabledata61.addCell(blank4);
//			tabledata61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//			tabledata61.addCell(blank5);
//			tabledata61.addCell(blank6);
//			tabledata61.addCell(blank7);
//			tabledata61.addCell(blank8);
//			tabledata61.addCell(blank9);
//			tabledata61.addCell(blank10);
//			tabledata61.addCell(blank11);

		}

		PdfPCell cell12356;
		cell12356 = new PdfPCell();
		cell12356.addElement(tabledata6);
		cell12356.addElement(tableheader6);
		cell12356.addElement(tabledata61);

		cell12356.setBorder(0);
		table6.addCell(cell12356);

		// =====================================Absenteess========================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table7 = new PdfPTable(1);
		table7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table7.setWidthPercentage(100);

		PdfPTable tabledata7 = new PdfPTable(1);
		tabledata7.setWidths(new int[] { 5 });
		tabledata7.setWidthPercentage(100 / 3.5f);
		tabledata7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata7.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata7.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head71 = new Paragraph("Appendix 'G'", fontTableHeadingMainHead_l);
		Paragraph head72 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head73 = new Paragraph("Letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head74 = new Paragraph("Dated:" + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata7.addCell(head71);
		tabledata7.addCell(head72);
		tabledata7.addCell(head73);
		tabledata7.addCell(head74);

		Chunk underline7 = new Chunk(
				"LIST OF ABSENTEES - DSSC-78/DSTSC-05 " + "\n" + "ENTRANCE EXAMINATION SEP 2023 \n",
				fontTableHeadingSubMainHead);

		Phrase phh7 = new Phrase(underline7);
		underline7.setUnderline(0.1f, -2f);

		phh7.add("\n");
		phh7.setFont(fontTableHeadingSubMainHead);

		Paragraph cell71 = new Paragraph(phh7);
		cell71.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader7 = new PdfPTable(1);
		tableheader7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader7.setWidthPercentage(100);
		tableheader7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader7.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader7.addCell(cell71);

		PdfPTable tabledata71 = new PdfPTable(7);

		tabledata71.setWidths(new int[] { 3, 5, 4, 8, 5, 5, 5 });
		tabledata71.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata71.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata71.setWidthPercentage(100);

		Paragraph a7 = new Paragraph("S NO.", fontTableHeadingSubMainHead1);
		Paragraph b7 = new Paragraph("PERSONAL NO", fontTableHeadingSubMainHead1);
		Paragraph c7 = new Paragraph("RANK", fontTableHeadingSubMainHead1);
		Paragraph d7 = new Paragraph("NAME", fontTableHeadingSubMainHead1);
		Paragraph e7 = new Paragraph("UNIT", fontTableHeadingSubMainHead1);
		Paragraph f7 = new Paragraph("EXAM CENTRE", fontTableHeadingSubMainHead1);

		Paragraph g7 = new Paragraph("SUBJECTS", fontTableHeadingSubMainHead1);

		tabledata71.addCell(a7);
		tabledata71.addCell(b7);
		tabledata71.addCell(c7);
		tabledata71.addCell(d7);
		tabledata71.addCell(e7);
		tabledata71.addCell(f7);
		tabledata71.addCell(g7);

		ArrayList<List<String>> PartAbsenteesForDSSC_DSTSC = (ArrayList<List<String>>) model
				.get("PartAbsenteesForDSSC_DSTSC");
		for (int i5 = 0; i5 < PartAbsenteesForDSSC_DSTSC.size(); i5++) {

			List<String> l = PartAbsenteesForDSSC_DSTSC.get(i5);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
			Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdata);
			Paragraph blank7 = new Paragraph(l.get(6), fontTableHeadingdata);

			PdfPCell cellar = new PdfPCell();

			cellar.setFixedHeight(20f);
			if (i5 % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}

			cellar.setPhrase(blank1);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank6);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata71.addCell(cellar);

			cellar.setPhrase(blank7);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata71.addCell(cellar);

//			tabledata71.addCell(blank1);
//			tabledata71.addCell(blank2);
//			tabledata71.addCell(blank3);
//			tabledata71.addCell(blank4);
//			tabledata71.addCell(blank5);
//			tabledata71.addCell(blank6);
//			tabledata71.addCell(blank7);

		}

		PdfPCell cell1235_7;
		cell1235_7 = new PdfPCell();
		cell1235_7.addElement(tabledata7);
		cell1235_7.addElement(tableheader7);
		cell1235_7.addElement(tabledata71);

		cell1235_7.setBorder(0);
		table7.addCell(cell1235_7);

		// =====================================Withdrawals========================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table8 = new PdfPTable(1);
		table8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table8.setWidthPercentage(100);

		PdfPTable tabledata8 = new PdfPTable(1);
		tabledata8.setWidths(new int[] { 5 });
		tabledata8.setWidthPercentage(100 / 3.5f);
		tabledata8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata8.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata8.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head811 = new Paragraph("Appendix 'H'", fontTableHeadingMainHead_l);
		Paragraph head82 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head83 = new Paragraph("Letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head84 = new Paragraph("Dated:" + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata8.addCell(head811);
		tabledata8.addCell(head82);
		tabledata8.addCell(head83);
		tabledata8.addCell(head84);

		Chunk underline8 = new Chunk(
				"LIST OF WITHDRAWALS - DSSC-78/DSTSC-05 " + "\n" + "ENTRANCE EXAMINATION SEP 2023 \n",
				fontTableHeadingSubMainHead);

		Phrase phh8 = new Phrase(underline8);
		underline8.setUnderline(0.1f, -2f);

		phh8.add("\n");
		phh8.setFont(fontTableHeadingSubMainHead);

		Paragraph cell81 = new Paragraph(phh8);
		cell81.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader8 = new PdfPTable(1);
		tableheader8.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader8.setWidthPercentage(100);
		tableheader8.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader8.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader8.addCell(cell81);

		PdfPTable tabledata81 = new PdfPTable(6);

		tabledata81.setWidths(new int[] { 3, 5, 3, 9, 4, 5 });
		tabledata81.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata81.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata81.setWidthPercentage(100);

//					ArrayList<List<String>> result_withheld = (ArrayList<List<String>>) model.get("resultwithheld_d");

		Paragraph a8 = new Paragraph("S NO.", fontTableHeadingSubMainHead1);
		Paragraph b8 = new Paragraph("PERSONAL NO", fontTableHeadingSubMainHead1);
		Paragraph c8 = new Paragraph("RANK", fontTableHeadingSubMainHead1);
		Paragraph d8 = new Paragraph("NAME", fontTableHeadingSubMainHead1);
		Paragraph e8 = new Paragraph("ARM/SERVICE", fontTableHeadingSubMainHead1);
		Paragraph f8 = new Paragraph("UNIT", fontTableHeadingSubMainHead1);

		tabledata81.addCell(a8);
		tabledata81.addCell(b8);
		tabledata81.addCell(c8);
		tabledata81.addCell(d8);
		tabledata81.addCell(e8);
		tabledata81.addCell(f8);

		ArrayList<List<String>> getWithDrawalsDSSC = (ArrayList<List<String>>) model.get("getWithDrawalsDSSC");
		for (int i5 = 0; i5 < getWithDrawalsDSSC.size(); i5++) {

			List<String> l = getWithDrawalsDSSC.get(i5);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
			Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdata);

			PdfPCell cellar = new PdfPCell();

			cellar.setFixedHeight(20f);
			if (i5 % 2 == 0) {
				cellar.setBackgroundColor(java.awt.Color.lightGray);
			}

			cellar.setPhrase(blank1);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata81.addCell(cellar);

			cellar.setPhrase(blank2);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata81.addCell(cellar);

			cellar.setPhrase(blank3);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata81.addCell(cellar);

			cellar.setPhrase(blank4);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata81.addCell(cellar);

			cellar.setPhrase(blank5);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata81.addCell(cellar);

			cellar.setPhrase(blank6);
			cellar.setPadding(2);
			cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata81.addCell(cellar);

//			tabledata81.addCell(blank1);
//			tabledata81.addCell(blank2);
//			tabledata81.addCell(blank3);
//			tabledata81.addCell(blank4);
//			tabledata81.addCell(blank5);
//			tabledata81.addCell(blank6);

		}

		PdfPCell cell1235_8;
		cell1235_8 = new PdfPCell();
		cell1235_8.addElement(tabledata8);
		cell1235_8.addElement(tableheader8);
		cell1235_8.addElement(tabledata81);

		cell1235_8.setBorder(0);
		table8.addCell(cell1235_8);

		PageNumeration event = new PageNumeration(arg2);
		arg2.setPageEvent(event);
		document.setPageCount(1);

		document.add(table_m1);

		document.add(table_c2);
		document.add(table_c3);

		table.setTableEvent(new ImageBackgroundEvent("table", ""));
		document.add(table);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table1.setTableEvent(new ImageBackgroundEvent("table1", ""));
		document.add(table1);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table4.setTableEvent(new ImageBackgroundEvent("table4", ""));
		document.add(table4);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table4_2.setTableEvent(new ImageBackgroundEvent("table4_2", ""));
		document.add(table4_2);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table5.setTableEvent(new ImageBackgroundEvent("table5", ""));
		document.add(table5);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table4_4.setTableEvent(new ImageBackgroundEvent("table6", ""));
		document.add(table4_4);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table6.setTableEvent(new ImageBackgroundEvent("table7", ""));
		document.add(table6);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table7.setTableEvent(new ImageBackgroundEvent("table8", ""));
		document.add(table7);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table8.setTableEvent(new ImageBackgroundEvent("table9", ""));
		document.add(table8);

		// ============Index-page1=======================//
		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		PdfPTable table_m2 = new PdfPTable(1);
		table_m2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_m2.setWidthPercentage(100);

		Chunk underline_m11 = new Chunk("INDEX \n", fontTableHeading2);

		underline_m11.setUnderline(0.1f, -2f);
		Phrase ph_m51 = new Phrase(underline_m11);
		ph_m51.setFont(fontTableHeading2);
		Paragraph cell_Mr_I = new Paragraph(ph_m51);
		cell_Mr_I.setAlignment(Element.ALIGN_CENTER);

		PdfPTable table153 = new PdfPTable(4);
		table153.setWidths(new int[] { 20, 80, 20, 20 });
		table153.getDefaultCell().setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
		table153.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		table153.getDefaultCell().setBorder(Rectangle.BOX);
		table153.setWidthPercentage(100);
		table153.setSpacingBefore(5);

		table153.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		table153.addCell("Ser No \n");
		table153.addCell("	");

		table153.getDefaultCell().setColspan(2);
		table153.addCell("Page No");
		table153.getDefaultCell().setColspan(1);

		table153.addCell("");
		table153.addCell("");
		table153.addCell("From");
		table153.addCell("To");

		table153.addCell("1.");
		table153.addCell("General Instruction");
		table153.addCell("1");
		table153.addCell("3");

		table153.addCell("2.");
		table153.addCell("Analysis of Result : Arms/Service wise");
		table153.addCell(String.valueOf(table_from));
		table153.addCell(String.valueOf(table_to));

		table153.addCell("3.");
		table153.addCell("List of Officers in Competitive List");
		table153.addCell(String.valueOf(table_from1));
		table153.addCell(String.valueOf(table_to1));

		table153.addCell("4.");
		table153.addCell("List of Nominated Officers : DSSC");
		table153.addCell(String.valueOf(table_from3));
		table153.addCell(String.valueOf(table_to3));

		table153.addCell("5.");
		table153.addCell("List of Nominated Officers : DSTSC");
		table153.addCell(String.valueOf(table_from6));
		table153.addCell(String.valueOf(table_from6));

		table153.addCell("6.");
		table153.addCell("Officers in Reserve List");
		table153.addCell(String.valueOf(table_from7));
		table153.addCell(String.valueOf(table_from7));

		table153.addCell("7.");
		table153.addCell("Marks of Officers Who did not Qualify");
		table153.addCell(String.valueOf(table_from7));
		table153.addCell(String.valueOf(table_from7));

		table153.addCell("8.");
		table153.addCell("List of Absentees");
		table153.addCell(String.valueOf(table_from7));
		table153.addCell(String.valueOf(table_from7));

		table153.addCell("9.");
		table153.addCell("List of Withdrawals");
		table153.addCell(String.valueOf(table_from7));
		table153.addCell(String.valueOf(table_from7));

		PdfPCell cell_i1;
		cell_i1 = new PdfPCell();
		cell_i1.addElement(cell_Mr_I);
		cell_i1.addElement(new Paragraph("\n"));
		cell_i1.addElement(table153);
		cell_i1.setBorder(0);
		table_m2.addCell(cell_i1);

		document.add(table_m2);

		super.buildPdfMetadata(model, document, request);
	}

	public String getSpace(int no) {
		String space = "";
		if (no == 1) {
			space = " ";
		}
		if (no == 2) {
			space = "  ";
		}
		if (no == 3) {
			space = "   ";
		}
		if (no == 4) {
			space = "    ";
		}
		if (no == 5) {
			space = "     ";
		}
		if (no == 6) {
			space = "      ";
		}
		if (no == 7) {
			space = "       ";
		}
		if (no == 8) {
			space = "        ";
		}
		if (no == 9) {
			space = "          ";
		}
		if (no == 10) {
			space = "           ";
		}
		if (no == 11) {
			space = "           ";
		}
		if (no == 12) {
			space = "            ";
		}
		if (no == 13) {
			space = "             ";
		}
		if (no == 14) {
			space = "              ";
		}
		if (no == 15) {
			space = "               ";
		}
		if (no == 16) {
			space = "                ";
		}
		if (no == 17) {
			space = "                 ";
		}
		if (no == 18) {
			space = "                  ";
		}
		if (no == 19) {
			space = "                   ";
		}
		if (no == 20) {
			space = "                    ";
		}
		return space;
	}

	String pagNum = "";

	class PageNumeration extends PdfPageEventHelper {
		PdfTemplate total;
		PdfTemplate total1;

		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				total1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {

		}

		public void onEndPage(PdfWriter writer, Document document) {

			Font pgNo = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 0);
			PdfPTable table = new PdfPTable(1);
			try {

				table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);

				if ((writer.getPageNumber() - 2) > 0) {
					pagNum = String.valueOf((writer.getPageNumber() - 1));
				}

				PdfPCell cell1 = new PdfPCell(new Paragraph(pagNum, pgNo));
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_TOP);
				table.addCell(cell1);

				table.writeSelectedRows(0, -1, document.leftMargin() + 260, document.topMargin() + 820,
						writer.getDirectContent());
				Font fontTableHeadingdataforFooter = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 0);
				PdfContentByte cb = writer.getDirectContent();

				table.writeSelectedRows(0, -1, document.leftMargin() + 260, document.topMargin() + 820,
						writer.getDirectContent());
//			 if(page >= 4 & page <=5) {
//				 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("Appd : Appeared", writer.getPageNumber()),fontTableHeadingdataforFooter),document.left(),document.bottom(), 0);
//			 }
//
//			 int rtable_from = table_from4+1;
//			 int rtable_to = table_to4;
//			
//			
//			 if(page > rtable_from && table_from4!=0 && rtable_to <= page && table_from6 < rtable_to) {
//			 Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
//			 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("Appendix 'B' Contd. "),fontTableHeadingMainHead_l),document.right()-150,document.top(), 0);
//			 }
//			 int ftable_from=table_from6+1;
//			 int ftable_to = table_to6;
//			 
//			 if(page > ftable_from && table_from6!=0 && ftable_to <= page && table_from5 < ftable_to) {
//				 Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
//				 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("Appendix 'C' Contd. "),fontTableHeadingMainHead_l),document.right()-150,document.top(), 0);
//				 }
//			 
//			 
//			 System.err.println("page==============="+page);
//			 System.err.println("ftable_from  :"+ftable_from   +"ftable_to   :"+ftable_to);
//			 if(page >= ftable_from && table_from6!=0 && ftable_to <= page && table_from5 < ftable_to) {
//				 System.err.println("ftable_from  :"+ftable_from);
//				 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format(" T:TAC  A:ADM    L:LAW    H:MIL HISTORY    C:CURRENT AFFAIRS  S:SPL TO CORPS     NP:NOW PASSED   PP:PREVIOUSLY PASSED    ABS:ABSENT   NA:EXEMPTED" , writer.getPageNumber()),fontTableHeadingdataforFooter),document.left(),document.bottom(), 0);
//			 }

//           if(page >= table_from6 & page <=table_to6 ) {
//				 
//				 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("hiiiiii", writer.getPageNumber()),fontTableHeadingdataforFooter),document.left(),document.bottom(), 0);
//			 }
				page++;
				/*
				 * // * if (Integer.parseInt(String.valueOf(writer.getPageNumber())) > 2) {
				 * page++; } //
				 */
			} catch (Exception de) {
				throw new ExceptionConverter(de);
			}
		}

//	public void onCloseDocument(PdfWriter writer, Document document) {
//		
//	}
	}

	int table_from = 0;
	int table_to = 0;

	int table_from1 = 0;
	int table_to1 = 0;

	int table_from3 = 0;
	int table_to3 = 0;

	int table_from4 = 0;
	int table_to4 = 0;

	int table_from6 = 0;
	int table_to6 = 0;

	int table_from5 = 0;
	int table_to5 = 0;

	int table_from7 = 0;
	int table_to7 = 0;

	int table_from8 = 0;
	int table_to8 = 0;

	int table_from9 = 0;
	int table_to9 = 0;

	class ImageBackgroundEvent implements PdfPTableEvent {
		protected Image image;
		String tableName;
		String val;

		ImageBackgroundEvent(String tableName, String val) {
			this.tableName = tableName;
			this.val = val;
		}

		public void tableLayout(PdfPTable table, float[][] widths, float[] heights, int headerRows, int rowStart,
				PdfContentByte[] canvases) {

			if (tableName.equals("table") && table_from == 0) {
				table_from = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table")) {
				table_to = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table1") && table_from1 == 0) {
				table_from1 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table1")) {
				table_to1 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table3") && table_from3 == 0) {
				table_from3 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table3")) {
				table_to3 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table4") && table_from4 == 0) {
				table_from4 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table4")) {
				table_to4 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table6") && table_from6 == 0) {
				table_from6 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table6")) {
				table_to6 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table5") && table_from5 == 0) {
				table_from5 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table5")) {
				table_from5 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table7") && table_from7 == 0) {
				table_from7 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table7")) {
				table_from7 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table8") && table_from8 == 0) {
				table_from8 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table8")) {
				table_from8 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table9") && table_from9 == 0) {
				table_from9 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table9")) {
				table_from9 = Integer.parseInt(pagNum) + 1;
			}

		}
	}

}
