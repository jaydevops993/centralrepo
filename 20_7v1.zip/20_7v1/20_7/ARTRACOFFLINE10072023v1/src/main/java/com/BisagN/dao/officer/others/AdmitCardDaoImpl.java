package com.BisagN.dao.officer.others;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Service
public class AdmitCardDaoImpl implements AdmitcardDao {
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

public ArrayList<ArrayList<String>> getOfrsAdmitCardDetails(String opd_personal_code) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	String whr = "";

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		
	
		
		q="select DISTINCT admit_card_no,opd_rank,opd_off_name,vpd.opd_unit,vpd.opc_personal_code, ofa.oa_center_granted,ecc. from dssc_admit_card_tbl adm\n"
				+ "inner join vw_personal_details vpd on vpd.opd_personal_id = adm.opd_personal_id\n"
				+ "inner join officer_application ofa on ofa.opd_personal_id=adm.opd_personal_id\n"
				+ "left join exam_center_code ecc on ecc.ecc_name=ofa.oa_center_granted::text\n"
				+ "where vpd.opc_personal_code=? \n"
				+ "  ";
		
		stmt = conn.prepareStatement(q);
		
		stmt.setString(1, opd_personal_code);
		
		System.err.println("stmt========="+stmt);
		ResultSet rs = stmt.executeQuery();
		
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("admit_card_no"));//1
			list.add(rs.getString("opd_rank"));//1
			list.add(rs.getString("opd_off_name"));//1
			list.add(rs.getString("opd_unit"));
			list.add(rs.getString("ecc_name"));
			alist.add(list);
			
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

}
