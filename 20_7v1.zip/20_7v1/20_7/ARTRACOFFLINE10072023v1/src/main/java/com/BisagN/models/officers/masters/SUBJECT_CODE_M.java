package com.BisagN.models.officers.masters;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "subject_code", uniqueConstraints = {
@UniqueConstraint(columnNames = "sc_subject_id"),})
public class SUBJECT_CODE_M {

   private int sc_subject_id;
      
      private String sc_subject_name;
      private String sc_form_caption;
      
      private int sc_subject_code;
      private int ec_exam_id;
      private String sc_subject_def_cut;
      private int sc_max_marks;
      private String sc_tsoc;
      private int sc_subject_order;
      private String sc_is_applicable;
      private String sc_ic_dssc_applicable;
      private String sc_is_tsoc_applicable;
      
      private int sc_status_id;
      private String sc_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date sc_creation_date;
      private String sc_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date sc_modification_date;

  private String sub_date;
  
  
  
  
      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "sc_subject_id", unique = true, nullable = false)
      public int getSc_subject_id() {
  		return sc_subject_id;
  	}
  	public void setSc_subject_id(int sc_subject_id) {
  		this.sc_subject_id = sc_subject_id;
  	}
	
	public String getSc_subject_name() {
		return sc_subject_name;
	}
	
	public void setSc_subject_name(String sc_subject_name) {
		this.sc_subject_name = sc_subject_name;
	}
	public String getSc_form_caption() {
		return sc_form_caption;
	}
	public void setSc_form_caption(String sc_form_caption) {
		this.sc_form_caption = sc_form_caption;
	}
	public int getSc_subject_code() {
		return sc_subject_code;
	}
	public void setSc_subject_code(int sc_subject_code) {
		this.sc_subject_code = sc_subject_code;
	}
	public int getEc_exam_id() {
		return ec_exam_id;
	}
	public void setEc_exam_id(int ec_exam_id) {
		this.ec_exam_id = ec_exam_id;
	}
	public String getSc_subject_def_cut() {
		return sc_subject_def_cut;
	}
	public void setSc_subject_def_cut(String sc_subject_def_cut) {
		this.sc_subject_def_cut = sc_subject_def_cut;
	}
	public int getSc_max_marks() {
		return sc_max_marks;
	}
	public void setSc_max_marks(int sc_max_marks) {
		this.sc_max_marks = sc_max_marks;
	}
	public String getSc_tsoc() {
		return sc_tsoc;
	}
	public void setSc_tsoc(String sc_tsoc) {
		this.sc_tsoc = sc_tsoc;
	}
	public int getSc_subject_order() {
		return sc_subject_order;
	}
	public void setSc_subject_order(int sc_subject_order) {
		this.sc_subject_order = sc_subject_order;
	}
	public String getSc_is_applicable() {
		return sc_is_applicable;
	}
	public void setSc_is_applicable(String sc_is_applicable) {
		this.sc_is_applicable = sc_is_applicable;
	}
	public String getSc_ic_dssc_applicable() {
		return sc_ic_dssc_applicable;
	}
	public void setSc_ic_dssc_applicable(String sc_ic_dssc_applicable) {
		this.sc_ic_dssc_applicable = sc_ic_dssc_applicable;
	}
	public String getSc_is_tsoc_applicable() {
		return sc_is_tsoc_applicable;
	}
	public void setSc_is_tsoc_applicable(String sc_is_tsoc_applicable) {
		this.sc_is_tsoc_applicable = sc_is_tsoc_applicable;
	}
	public int getSc_status_id() {
		return sc_status_id;
	}
	public void setSc_status_id(int sc_status_id) {
		this.sc_status_id = sc_status_id;
	}
	public String getSc_created_by() {
		return sc_created_by;
	}
	public void setSc_created_by(String sc_created_by) {
		this.sc_created_by = sc_created_by;
	}
	public Date getSc_creation_date() {
		return sc_creation_date;
	}
	public void setSc_creation_date(Date sc_creation_date) {
		this.sc_creation_date = sc_creation_date;
	}
	public String getSc_modified_by() {
		return sc_modified_by;
	}
	public void setSc_modified_by(String sc_modified_by) {
		this.sc_modified_by = sc_modified_by;
	}
	public Date getSc_modification_date() {
		return sc_modification_date;
	}
	public void setSc_modification_date(Date sc_modification_date) {
		this.sc_modification_date = sc_modification_date;
	}
	public String getSub_date() {
		return sub_date;
	}
	public void setSub_date(String sub_date) {
		this.sub_date = sub_date;
	}
	
	
}
