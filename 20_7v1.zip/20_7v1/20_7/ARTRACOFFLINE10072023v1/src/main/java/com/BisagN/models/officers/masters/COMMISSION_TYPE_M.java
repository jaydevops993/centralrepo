package com.BisagN.models.officers.masters;


import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "commission_type", uniqueConstraints = {
@UniqueConstraint(columnNames = "ct_comm_id"),})

public class COMMISSION_TYPE_M {

      private int id;
      //private int ct_comm_id;
      private String ct_comm_type;
      private int ct_status_id;
      private String ct_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date ct_creation_date;
      private String ct_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date ct_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "ct_comm_id", unique = true, nullable = false)
      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
     
      public String getCt_comm_type() {
           return ct_comm_type;
      }
      public void setCt_comm_type(String ct_comm_type) {
	  this.ct_comm_type = ct_comm_type;
      }
      public int getCt_status_id() {
           return ct_status_id;
      }
      public void setCt_status_id(int ct_status_id) {
	  this.ct_status_id = ct_status_id;
      }
      public String getCt_created_by() {
           return ct_created_by;
      }
      public void setCt_created_by(String ct_created_by) {
	  this.ct_created_by = ct_created_by;
      }
      public Date getCt_creation_date() {
           return ct_creation_date;
      }
      public void setCt_creation_date(Date ct_creation_date) {
	  this.ct_creation_date = ct_creation_date;
      }
      public String getCt_modified_by() {
           return ct_modified_by;
      }
      public void setCt_modified_by(String ct_modified_by) {
	  this.ct_modified_by = ct_modified_by;
      }
      public Date getCt_modification_date() {
           return ct_modification_date;
      }
      public void setCt_modification_date(Date ct_modification_date) {
	  this.ct_modification_date = ct_modification_date;
      }
}
