package com.BisagN.dao.officer.trans;

public interface ImportPartB_MarksDAO {

}
