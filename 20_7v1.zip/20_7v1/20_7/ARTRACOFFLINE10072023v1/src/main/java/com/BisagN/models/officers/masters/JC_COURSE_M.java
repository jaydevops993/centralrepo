package com.BisagN.models.officers.masters;


import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "jc_course", uniqueConstraints = {
@UniqueConstraint(columnNames = "jcc_id"),})

public class JC_COURSE_M {

	
	
	   @Id
	      @GeneratedValue(strategy = IDENTITY)
	      @Column(name = "jcc_id", unique = true, nullable = false)
     private int jcc_id;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date jcc_beg_date;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date jcc_end_date;
      private int jcc_status_id;
      private String jcc_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date jcc_creation_date;
      private String jcc_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date jcc_modification_date;
      private String jcc_no;



   
    
      public Date getJcc_beg_date() {
           return jcc_beg_date;
      }
      public int getJcc_id() {
		return jcc_id;
	}
	public void setJcc_id(int jcc_id) {
		this.jcc_id = jcc_id;
	}
	public void setJcc_beg_date(Date jcc_beg_date) {
	  this.jcc_beg_date = jcc_beg_date;
      }
      public Date getJcc_end_date() {
           return jcc_end_date;
      }
      public void setJcc_end_date(Date jcc_end_date) {
	  this.jcc_end_date = jcc_end_date;
      }
      public int getJcc_status_id() {
           return jcc_status_id;
      }
      public void setJcc_status_id(int jcc_status_id) {
	  this.jcc_status_id = jcc_status_id;
      }
      public String getJcc_created_by() {
           return jcc_created_by;
      }
      public void setJcc_created_by(String jcc_created_by) {
	  this.jcc_created_by = jcc_created_by;
      }
      public Date getJcc_creation_date() {
           return jcc_creation_date;
      }
      public void setJcc_creation_date(Date jcc_creation_date) {
	  this.jcc_creation_date = jcc_creation_date;
      }
      public String getJcc_modified_by() {
           return jcc_modified_by;
      }
      public void setJcc_modified_by(String jcc_modified_by) {
	  this.jcc_modified_by = jcc_modified_by;
      }
      public Date getJcc_modification_date() {
           return jcc_modification_date;
      }
      public void setJcc_modification_date(Date jcc_modification_date) {
	  this.jcc_modification_date = jcc_modification_date;
      }
      public String getJcc_no() {
           return jcc_no;
      }
      public void setJcc_no(String jcc_no) {
	  this.jcc_no = jcc_no;
      }
}
