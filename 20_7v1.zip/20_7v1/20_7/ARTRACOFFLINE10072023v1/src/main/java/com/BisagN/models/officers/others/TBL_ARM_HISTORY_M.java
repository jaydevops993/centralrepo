package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;



@Entity
@Table(name = "tblarmshistory", uniqueConstraints = {
@UniqueConstraint(columnNames = "hrid"),})

public class TBL_ARM_HISTORY_M {
	
	private int hrid;
	private int opd_personal_id;
private int prvarmscode;
private int curarmscode;
private int applicationno;
private int esid;
private Date updateddate;
private String  updatedby;
private String auth_letter_no;
private Date arm_chnage_date;


@Id
@GeneratedValue(strategy = IDENTITY)
@Column(name = "hrid", unique = true, nullable = false)
public int getHrid() {
	return hrid;
}
public void setHrid(int hrid) {
	this.hrid = hrid;
}
public int getOpd_personal_id() {
	return opd_personal_id;
}
public void setOpd_personal_id(int opd_personal_id) {
	this.opd_personal_id = opd_personal_id;
}
public int getPrvarmscode() {
	return prvarmscode;
}
public void setPrvarmscode(int prvarmscode) {
	this.prvarmscode = prvarmscode;
}
public int getCurarmscode() {
	return curarmscode;
}
public void setCurarmscode(int curarmscode) {
	this.curarmscode = curarmscode;
}
public int getApplicationno() {
	return applicationno;
}
public void setApplicationno(int applicationno) {
	this.applicationno = applicationno;
}
public int getEsid() {
	return esid;
}
public void setEsid(int esid) {
	this.esid = esid;
}
public Date getUpdateddate() {
	return updateddate;
}
public void setUpdateddate(Date updateddate) {
	this.updateddate = updateddate;
}
public String getUpdatedby() {
	return updatedby;
}
public void setUpdatedby(String updatedby) {
	this.updatedby = updatedby;
}
public String getAuth_letter_no() {
	return auth_letter_no;
}
public void setAuth_letter_no(String auth_letter_no) {
	this.auth_letter_no = auth_letter_no;
}
public Date getArm_chnage_date() {
	return arm_chnage_date;
}
public void setArm_chnage_date(Date arm_chnage_date) {
	this.arm_chnage_date = arm_chnage_date;
}




}




