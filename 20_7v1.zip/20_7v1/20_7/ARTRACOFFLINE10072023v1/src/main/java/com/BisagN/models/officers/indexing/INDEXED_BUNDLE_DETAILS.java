package com.BisagN.models.officers.indexing;



import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "indexed_bundle_details", uniqueConstraints = {
@UniqueConstraint(columnNames = "ibd_id"),})
public class INDEXED_BUNDLE_DETAILS {

	private int  ibd_id;
	
	private int ibd_ibm_id;
	private int ibm_is_id;
	private String created_by;
	private String modified_by;
	private Date modified_date;
	private Date created_date;
	
	
	
	
	 @Id
     @GeneratedValue(strategy = IDENTITY)
     @Column(name = "ibd_id", unique = true, nullable = false)
	public int getIbd_id() {
		return ibd_id;
	}
	public void setIbd_id(int ibd_id) {
		this.ibd_id = ibd_id;
	}
	public int getIbd_ibm_id() {
		return ibd_ibm_id;
	}
	public void setIbd_ibm_id(int ibd_ibm_id) {
		this.ibd_ibm_id = ibd_ibm_id;
	}
	public int getIbm_is_id() {
		return ibm_is_id;
	}
	public void setIbm_is_id(int ibm_is_id) {
		this.ibm_is_id = ibm_is_id;
	}
	
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	
	
	
	
	
}
