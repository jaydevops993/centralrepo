package com.BisagN.models.officers.indexing;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "index_slip_master", uniqueConstraints = {
@UniqueConstraint(columnNames = "ism_id"),})
public class INDEX_SLIP_MASTER {
	

    private int ism_id; 
    private int ism_indexno ;
    private String ism_armyno;
    private int ism_es_id;
    private int ism_userid ;
    private Date ism_dtcreateddate;
    private int  ism_updatedby ;
    private Date  ism_dtupdatedate ;
    private int ism_isexport ;
    private int command_id;
    private int center_code;
    
    
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "ism_id", unique = true, nullable = false)
    
	public int getIsm_id() {
		return ism_id;
	}
	public void setIsm_id(int ism_id) {
		this.ism_id = ism_id;
	}
	public int getIsm_indexno() {
		return ism_indexno;
	}
	public void setIsm_indexno(int ism_indexno) {
		this.ism_indexno = ism_indexno;
	}
	public String getIsm_armyno() {
		return ism_armyno;
	}
	public void setIsm_armyno(String ism_armyno) {
		this.ism_armyno = ism_armyno;
	}
	public int getIsm_es_id() {
		return ism_es_id;
	}
	public void setIsm_es_id(int ism_es_id) {
		this.ism_es_id = ism_es_id;
	}
	public int getIsm_userid() {
		return ism_userid;
	}
	public void setIsm_userid(int ism_userid) {
		this.ism_userid = ism_userid;
	}
	public Date getIsm_dtcreateddate() {
		return ism_dtcreateddate;
	}
	public void setIsm_dtcreateddate(Date ism_dtcreateddate) {
		this.ism_dtcreateddate = ism_dtcreateddate;
	}
	public int getIsm_updatedby() {
		return ism_updatedby;
	}
	public void setIsm_updatedby(int ism_updatedby) {
		this.ism_updatedby = ism_updatedby;
	}
	public Date getIsm_dtupdatedate() {
		return ism_dtupdatedate;
	}
	public void setIsm_dtupdatedate(Date ism_dtupdatedate) {
		this.ism_dtupdatedate = ism_dtupdatedate;
	}
	public int getIsm_isexport() {
		return ism_isexport;
	}
	public void setIsm_isexport(int ism_isexport) {
		this.ism_isexport = ism_isexport;
	}
	public int getCommand_id() {
		return command_id;
	}
	public void setCommand_id(int command_id) {
		this.command_id = command_id;
	}
	public int getCenter_code() {
		return center_code;
	}
	public void setCenter_code(int center_code) {
		this.center_code = center_code;
	}
    
    
    

}
