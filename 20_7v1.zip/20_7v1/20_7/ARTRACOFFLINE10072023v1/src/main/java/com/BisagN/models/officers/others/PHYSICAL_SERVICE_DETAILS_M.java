package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "physical_service_details", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class PHYSICAL_SERVICE_DETAILS_M {

      private int id;
      private int psd_id;
      private int oa_application_id;
      private String psd_area;
      private String psd_service_unit;
      private String psd_service_ci_haa;
      private String psd_service_period;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date psd_begin_date;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date psd_end_date;
      private int psd_leave_duration;
      private int psd_status_id;
      private String psd_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date psd_creation_date;
      private String psd_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date psd_modification_date;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getPsd_id() {
           return psd_id;
      }
      public void setPsd_id(int psd_id) {
	  this.psd_id = psd_id;
      }
      public int getOa_application_id() {
           return oa_application_id;
      }
      public void setOa_application_id(int oa_application_id) {
	  this.oa_application_id = oa_application_id;
      }
      public String getPsd_area() {
           return psd_area;
      }
      public void setPsd_area(String psd_area) {
	  this.psd_area = psd_area;
      }
      public String getPsd_service_unit() {
           return psd_service_unit;
      }
      public void setPsd_service_unit(String psd_service_unit) {
	  this.psd_service_unit = psd_service_unit;
      }
      public String getPsd_service_ci_haa() {
           return psd_service_ci_haa;
      }
      public void setPsd_service_ci_haa(String psd_service_ci_haa) {
	  this.psd_service_ci_haa = psd_service_ci_haa;
      }
      public String getPsd_service_period() {
           return psd_service_period;
      }
      public void setPsd_service_period(String psd_service_period) {
	  this.psd_service_period = psd_service_period;
      }
      public Date getPsd_begin_date() {
           return psd_begin_date;
      }
      public void setPsd_begin_date(Date psd_begin_date) {
	  this.psd_begin_date = psd_begin_date;
      }
      public Date getPsd_end_date() {
           return psd_end_date;
      }
      public void setPsd_end_date(Date psd_end_date) {
	  this.psd_end_date = psd_end_date;
      }
      public int getPsd_leave_duration() {
           return psd_leave_duration;
      }
      public void setPsd_leave_duration(int psd_leave_duration) {
	  this.psd_leave_duration = psd_leave_duration;
      }
      public int getPsd_status_id() {
           return psd_status_id;
      }
      public void setPsd_status_id(int psd_status_id) {
	  this.psd_status_id = psd_status_id;
      }
      public String getPsd_created_by() {
           return psd_created_by;
      }
      public void setPsd_created_by(String psd_created_by) {
	  this.psd_created_by = psd_created_by;
      }
      public Date getPsd_creation_date() {
           return psd_creation_date;
      }
      public void setPsd_creation_date(Date psd_creation_date) {
	  this.psd_creation_date = psd_creation_date;
      }
      public String getPsd_modified_by() {
           return psd_modified_by;
      }
      public void setPsd_modified_by(String psd_modified_by) {
	  this.psd_modified_by = psd_modified_by;
      }
      public Date getPsd_modification_date() {
           return psd_modification_date;
      }
      public void setPsd_modification_date(Date psd_modification_date) {
	  this.psd_modification_date = psd_modification_date;
      }
}
