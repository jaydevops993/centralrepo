package com.BisagN.controller.office.masters;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.IAST_CasesDAO;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.TBL_ARM_HISTORY_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Inactive_Offcrs_ExcelController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	CommonController comm = new CommonController();

	@Autowired
	private Officer_personal_detailsDAO ofc_Dao;

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

	@Autowired
	private IAST_CasesDAO iastDao;

	@Autowired
	private Officer_personal_detailsDAO opdDAO;
	
	@Autowired
	private RoleBaseMenuDAO roledao; 

	@RequestMapping(value = "Inactive_Offcrs__detailsUrl", method = RequestMethod.GET)
	public ModelAndView Inactive_Offcrs__detailsUrl(ModelMap Mmap, HttpSession session,HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg, String opd_pers_no1, String opd_name1) {
		
		
		 if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

    	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("Inactive_Offcrs__detailsUrl", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}	
		try {

			Mmap.put("msg", msg);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("Inactive_candiate_Excel_tile");
	}

	// Download DEMO EXCEL
	@RequestMapping(value = "/DemoCandidateExcelFORInactiveOffcrs", method = RequestMethod.POST)
	public ModelAndView DemoCandidateExcelFORInactiveOffcrs(HttpServletRequest request, ModelMap model,
			HttpSession session, String typeReport1) {

//			int abc = comm.getsubjectlist().size();
//			
		ArrayList<ArrayList<String>> listexport = new ArrayList<ArrayList<String>>();
		List<String> TH = new ArrayList<String>();
		TH.add("SER_NO");

		TH.add("PERSONAL_NO");
		TH.add("SUFFIX_CODE");
		TH.add("RANK");
		TH.add("OFFICER_NAME");
		TH.add("DATE_OF_INACTIVATION");
		TH.add("REASON");


		String Heading = "\n";
		String username = session.getAttribute("username").toString();
		return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList", listexport);
	}

	@RequestMapping(value = "EditiNACTIVE_OFFRS_detailsUrl", method = RequestMethod.POST)
	public ModelAndView EditiNACTIVE_OFFRS_detailsUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, String updateid) {

		System.out.println("updateid--------------------------" + updateid);
		Session s1 = this.sessionFactory.openSession();
		Transaction tx = s1.beginTransaction();
		String enckey = "commonPwdEncKeys";
		String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);
		Query q = null;
		q = s1.createQuery("from OFFICER_PERSONAL_DETAILS_M where cast(id as string)=:PK");
		q.setString("PK", DcryptedPk);
		@SuppressWarnings("unchecked")
		List<String> list = (List<String>) q.list();
		tx.commit();
		s1.close();

		Mmap.put("Edit_pers_details", opdDAO.getarmcodeforIASTcase(DcryptedPk));
		Mmap.put("Editofficer_personal_detailsCMD1", list.get(0));
		Mmap.put("Edit_pers_details", opdDAO.getpersdetails(DcryptedPk));
		Mmap.put("getctarmcodetypeListDDL", comm.getctarmcodetypeListDDL(sessionFactory));
		Mmap.put("getctranktypeListDDL", comm.getctranktypeListDDL(sessionFactory));
		Mmap.put("getPersonalType", comm.getPersonalType(sessionFactory));
		Mmap.put("msg", msg);
		Mmap.put("opd_id", DcryptedPk);
		return new ModelAndView("ADD_Inactive_candiate_Excel_tile", "editInactiveOffrsCMD",
				new OFFICER_PERSONAL_DETAILS_M());
	}

	@RequestMapping(value = "UploadInactiveOffrsExcelURL", method = RequestMethod.GET)
	public ModelAndView UploadInactiveOffrsExcelURL(ModelMap Mmap, HttpSession session,HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg, String Subjectid) {

		 Map<String, ?> flashMap = RequestContextUtils.getInputFlashMap(request);
	        if(flashMap != null){
	        	ArrayList<ArrayList<String>> errorList =  (ArrayList<ArrayList<String>>) flashMap.get("errorlist");
	            System.out.println("==================="+errorList);
	            //return "home";
	            Mmap.put("errorList",errorList);
	        }

		Mmap.put("msg", msg);
		return new ModelAndView("UploadInactive_candiate_Exceltile");
	}

	@RequestMapping(value = "/EditInactiveOffrsAction", method = RequestMethod.POST)
	public ModelAndView EditInactiveOffrsAction(
			@Valid @ModelAttribute("editInactiveOffrsCMD") OFFICER_PERSONAL_DETAILS_M opd, BindingResult result,
			HttpServletRequest request, ModelMap model, HttpSession session) throws ParseException {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();

		DateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
		
		
		String inactivation_date1=request.getParameter("inactivation_date");
		if (inactivation_date1.equals("DD/MM/YYYY") || inactivation_date1.equals("") || inactivation_date1 == "" || inactivation_date1 == "DD/MM/YYYY") {
			model.put("msg", "Please Select Date Of Inactivation");
			return new ModelAndView("redirect:Inactive_Offcrs__detailsUrl");
		}
		String remark=request.getParameter("remark");
		if(remark == "" || remark.equals("")) {
			model.put("msg", "Please Enter Reason");		
		return new ModelAndView("redirect:Inactive_Offcrs__detailsUrl");
		}
		String auth_letter_no1=request.getParameter("auth_letter_no");
		if(auth_letter_no1 == "" || auth_letter_no1.equals("")) {
			model.put("msg", "Please Enter Auth (Letter No)");		
		return new ModelAndView("redirect:Inactive_Offcrs__detailsUrl");
		}

		String pers_code = request.getParameter("persnl_no1") + request.getParameter("opd_personal_no");
		String opd_suffix_code = request.getParameter("opd_suffix_code");
		String opd_id = request.getParameter("opd_id");

		String opd_name = request.getParameter("opd_officer_name");

		String opd_remarks = request.getParameter("remark");
		String inactivation_date = request.getParameter("inactivation_date");

		String auth_letter_no = request.getParameter("auth_letter_no");
		Date date = new Date();

		Date inactivation_date_d = null;
		if (!request.getParameter("inactivation_date").equals("")) {
			inactivation_date_d = format.parse(request.getParameter("inactivation_date"));
		} else {
			inactivation_date_d = null;
		}
		String username = session.getAttribute("username").toString();

		try {
			String hql = "update OFFICER_PERSONAL_DETAILS_M set opd_officer_name=:opd_officer_name,"
					+ "opd_remarks=:opd_remarks,inactivation_date=:inactivation_date, auth_letter_no=:auth_letter_no, opd_status_id=:opd_status_id,opd_isactive=:opd_isactive  where opd_personal_id=:opd_personal_id ";
			Query query = sessionHQL.createQuery(hql).setParameter("opd_officer_name", opd_name)

					.setParameter("opd_remarks", opd_remarks).setParameter("auth_letter_no", auth_letter_no)
					.setParameter("opd_status_id", 0).setParameter("inactivation_date", inactivation_date_d)
					.setParameter("opd_isactive", "no")
					.setParameter("opd_personal_id", Integer.parseInt(opd_id));
			query.executeUpdate();
			
			
			String hql1 = "update OFFICER_PERSONAL_CODE_M set opc_status_id=:opc_status_id  where opd_personal_id=:opd_personal_id ";
			Query query1 = sessionHQL.createQuery(hql1)
						.setParameter("opc_status_id", 0)		
						.setParameter("opd_personal_id", Integer.parseInt(opd_id));
			query1.executeUpdate();
			
			String hql2 = "update OFFICER_ARM_M set oa_status_id=:oa_status_id  where opd_personal_id=:opd_personal_id ";
			Query query2 = sessionHQL.createQuery(hql2)
						.setParameter("oa_status_id", 0)			
						.setParameter("opd_personal_id",  Integer.parseInt(opd_id));
			query2.executeUpdate();
			
			
			String hq14 = "update OFFICER_RANK_M set or_status_id=:or_status_id  where opd_personal_id=:opd_personal_id ";
			Query query4 = sessionHQL.createQuery(hq14)
						.setParameter("or_status_id", 0)			
						.setParameter("opd_personal_id",  Integer.parseInt(opd_id));
			query4.executeUpdate();
				

			tx.commit();
			sessionHQL.close();

			model.put("msg", "Data Inactive Successfully");
		} catch (RuntimeException e) {
			e.printStackTrace();
			tx.rollback();

			model.put("msg", "Server side Error");

		}

		return new ModelAndView("redirect:Inactive_Offcrs__detailsUrl");
	}
	
	@RequestMapping(value = "/UploadInactiveofcAction", method = RequestMethod.POST)
	public ModelAndView UploadInactiveofcAction(HttpServletRequest request, ModelMap model, HttpSession session,RedirectAttributes ra,
			@RequestParam(value = "fileUpload", required = false) MultipartFile fileUpload)
	{
		
		ArrayList<ArrayList<String>> listerror=new ArrayList<ArrayList<String>>();
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		
//		if(fileUpload==null) {
//			 model.put("msg","Please Upload Copy Of File Upload");
//			  return new ModelAndView("redirect:Inactive_Offcrs__detailsUrl");
//		  }
		
//		if(fileUpload.isEmpty()) {
//			model.put("msg","Please Upload Copy Of File Upload");
//			  return new ModelAndView("redirect:Inactive_Offcrs__detailsUrl");
//		}
		
		if(fileUpload.isEmpty()) {
			ra.addAttribute("msg","Please Upload Copy Of File Upload");
			  return new ModelAndView("redirect:UploadInactiveOffrsExcelURL");
		}
		
		try {

			
			Date date = new Date();
			String username = session.getAttribute("username").toString();

			int count = Integer.parseInt(request.getParameter("count"));
			DateFormat format = new SimpleDateFormat("dd/MM/yyyy");

			
			File file = new File(comm.fileupload2(fileUpload.getBytes(), fileUpload.getOriginalFilename(), "doc_contract",""));
			FileInputStream fis = new FileInputStream(file);
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheetAt(0);
			Row row_head = sheet.getRow(0);
			
			
			
		
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				ArrayList<String> listData = new ArrayList<String>();
				Row row = sheet.getRow(i);
				String personal_no="";
				String suffixcode="";
				String rank="";
				String inact_date = "";
				String opd_remarks="";
				String officer_name="";
			
				
				
				
				if (row.getCell(0) == null) {
					break;
				}
				
				for (int j = 1; j < 6; j++) {

					Cell cell = row.getCell(j);
					
					

					String value = "";
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						value = cell.getStringCellValue();
						break;
					case Cell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							value = String.valueOf(cell.getDateCellValue());
						} else {
							value = String.valueOf((long) cell.getNumericCellValue());
						}
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						value = String.valueOf(cell.getBooleanCellValue());
						break;
					default:
					}
				
		
					
					if (row_head.getCell(j).getStringCellValue().equals("PERSONAL_NO")) {
						personal_no=value;
					}
					if (row_head.getCell(j).getStringCellValue ().equals("SUFFIX_CODE")) {
						suffixcode=value;
						
					}
					if (row_head.getCell(j).getStringCellValue().equals("RANK")) {
						rank=value;
				     }
					
					if (row_head.getCell(j).getStringCellValue().equals("OFFICER_NAME")) {
						officer_name=value;
					}
					
					if (row_head.getCell(j).getStringCellValue().equals("DATE_OF_INACTIVATION")) {
						inact_date=value;
					}
					if (row_head.getCell(j).getStringCellValue().equals("REASON")) {
						opd_remarks=value;
						
						
					}
								
				}
//			for (int i = 0; i < count; i++) {
			
				
				int count_duplicate=0;
				int errorcount=0;
				int succeesscount=0;
				String errormsg= "";
				List<OFFICER_PERSONAL_CODE_M> opdpers_id= comm.getopdIdbycode( sessionFactory, personal_no);
				System.err.println("opdpers_id============"+opdpers_id);
				String auth_letter_no = request.getParameter("auth_letter_no");
				if(opdpers_id.isEmpty()) {
					
				
					 listData.add(personal_no);
					 listData.add(suffixcode);
					 listData.add(rank);
					 listData.add(officer_name);
					 listData.add(inact_date);
					 listData.add(opd_remarks);
						
						
						listData.add("The Personal Number is Wrong");
					 errormsg= personal_no +"The Personal Number is Wrong";
						model.put("msg",errormsg);
						errorcount++;
				}
				else {
				int opd_pers_id= opdpers_id.get(0).getOpd_personal_id();
				
				
//				Date inactivation_date_d = null;
//				if (!request.getParameter("inactive_date" + i).equals("")) {
//					inactivation_date_d = format.parse(request.getParameter("inactive_date" + i));
//				} else {
//					inactivation_date_d = null;
//				}
//				System.err.println("inactivation_date_d========"+inactivation_date_d);
			
				
				
				String hql = "update OFFICER_PERSONAL_DETAILS_M set opd_officer_name=:opd_officer_name,"
						+ "opd_remarks=:opd_remarks,inactivation_date=:inactivation_date, auth_letter_no=:auth_letter_no, opd_status_id=:opd_status_id,opd_isactive=:opd_isactive   where opd_personal_id=:opd_personal_id ";
				Query query = sessionHQL.createQuery(hql).setParameter("opd_officer_name", officer_name)

						.setParameter("opd_remarks", opd_remarks).setParameter("auth_letter_no", auth_letter_no)
						.setParameter("opd_status_id", 0).setParameter("inactivation_date", comm.convertStringToDate(inact_date))
						.setParameter("opd_isactive", "no")
						.setParameter("opd_personal_id", opd_pers_id);
				query.executeUpdate();
				

				String hql1 = "update OFFICER_PERSONAL_CODE_M set opc_status_id=:opc_status_id  where opd_personal_id=:opd_personal_id ";
				Query query1 = sessionHQL.createQuery(hql1)
							.setParameter("opc_status_id", 0)		
							.setParameter("opd_personal_id", opd_pers_id);
				query1.executeUpdate();
				
				String hql2 = "update OFFICER_ARM_M set oa_status_id=:oa_status_id  where opd_personal_id=:opd_personal_id ";
				Query query2 = sessionHQL.createQuery(hql2)
							.setParameter("oa_status_id", 0)			
							.setParameter("opd_personal_id",  opd_pers_id);
				query2.executeUpdate();
				
				
				String hq14 = "update OFFICER_RANK_M set or_status_id=:or_status_id  where opd_personal_id=:opd_personal_id ";
				Query query4 = sessionHQL.createQuery(hq14)
							.setParameter("or_status_id", 0)			
							.setParameter("opd_personal_id",  opd_pers_id);
				query4.executeUpdate();
				
				
				
				ra.addAttribute("msg", "Data Inactive Successfully");
					
				}
				
				tx.commit();
				sessionHQL.close();

				model.put("msg", "Data Inactive Successfully");
							
				
				if(!listData.isEmpty()) {
					System.err.println("listData======="+listData);
					listerror.add(listData);
				}
									
				} 

			
			model.put("errorlist", listerror);
						
			}
			
		
	
		 catch (Exception e) {
			//tx.rollback();
			e.printStackTrace();
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}
		
		ra.addFlashAttribute("errorlist",listerror);
		return new ModelAndView("redirect:UploadInactiveOffrsExcelURL");
	}		
}
