package com.BisagN.dao.Indexing;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface SubjectWiseSecDetailsDao {
	public ArrayList<ArrayList<String>> getSubwiseSecDetails(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,int esi_es_id,String sc_subject_id,String subsubject_id,HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	public long getTotalCountSubwiseSecDetails(String Search,int es_id,String subject_id,String subsubject_id);
	public ArrayList<ArrayList<String>> GetSubwiseQueDetails(int es_id, int sub_id, String Excel);
	public ArrayList<ArrayList<String>> GetIndexNoForExcel(int es_id, int sub_id, String Excel);
	 	
	
}
