package com.BisagN.dao.officer.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface SUBJECT_MASTERDAO {

	
	public List<Map<String, Object>> getReportListSubject_master(int startPage,String pageLength,String Search,String orderColunm,String orderType,
			String exam,String ec_exam_id2,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	public long getReportListSubject_masterTotalCount(String Search,String exam,String ec_exam_id2);
	public String DeleteSubject_master(String deleteid,HttpSession session);
	 public List<Map<String, Object>> getarmcodeforsubjectmst(String sub_id) ;
	 public ArrayList<ArrayList<String>> getExcelSubject_master(int startPage, String pageLength, String Search,
				String orderColunm, String orderType,String ec_exam_id2,String table, HttpSession session)
				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException ;
}
