package com.BisagN.models.officers.trans;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;


@Entity
@Table(name = "dssc_choice_tbl", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})
public class DSCC_CHOICE_TBL {

	
	private int id;
	private int dscc_app_id;
	private int es_id;
	private int course_applied;
	private int course_preference;
	private String created_by;
	private Date created_Date;
	
	@Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "id", unique = true, nullable = false)


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public int getDscc_app_id() {
		return dscc_app_id;
	}
	public void setDscc_app_id(int dscc_app_id) {
		this.dscc_app_id = dscc_app_id;
	}
	public int getEs_id() {
		return es_id;
	}
	public void setEs_id(int es_id) {
		this.es_id = es_id;
	}
	public int getCourse_applied() {
		return course_applied;
	}
	public void setCourse_applied(int course_applied) {
		this.course_applied = course_applied;
	}
	public int getCourse_preference() {
		return course_preference;
	}
	public void setCourse_preference(int course_preference) {
		this.course_preference = course_preference;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_Date() {
		return created_Date;
	}
	public void setCreated_Date(Date created_Date) {
		this.created_Date = created_Date;
	}
	
	
	
}
 