package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.office.trans.Examination_centreController;
import com.BisagN.dao.officer.others.ExaminationschedulepartdDao;
import com.BisagN.dao.officer.trans.Unfair_meansDAO;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.EXAM_SCHEDULE_DETAIL_M;


import java.text.ParseException;

import java.util.Date;
import java.util.List;
import java.util.Map;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


@Controller
@RequestMapping(value = {"admin","/" ,"user"})

public class Exam_schdule_part_d_Controller {
	
	@Autowired
	private ExaminationschedulepartdDao objDAO;
	
	
	@Autowired
	private Unfair_meansDAO unfdao;
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	Examination_centreController exmCon = new Examination_centreController();
	
	
	@RequestMapping(value = "/exam_schedule_part_dUrl", method = RequestMethod.GET)
    public ModelAndView exam_schedule_part_dUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) 
   		 throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

     
        Mmap.put("msg", msg);
    return new ModelAndView("exam_schedule_part_d_tiles");
}

	
	
	
	@RequestMapping(value = "/Part_d_examinationScheduleAction", method = RequestMethod.POST)
	public ModelAndView Part_d_examinationScheduleAction(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg, HttpServletRequest request)
			throws ParseException {
		
		
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		EXAM_SCHEDULE exmgmt = new EXAM_SCHEDULE();
	
		DateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
		

		int id = exmgmt.getEs_id() > 0 ? exmgmt.getEs_id() : 0;
		 String username = session.getAttribute("username").toString();
		Date date = new Date();
		
		
		
System.out.println("----------------"+request.getParameter("es_index_mode"));
		
			
			exmgmt.setEc_exam_id(2);
			exmgmt.setEs_begin_date(date);
			exmgmt.setEs_index_mode(request.getParameter("es_index_mode"));
			exmgmt.setEs_created_by(username);
			exmgmt.setEs_creation_date(date);
			
		String ec_exam_id = request.getParameter("ec_exam_id");
		
		System.err.println(ec_exam_id);
		
		int mid = (int)sessionHQL.save(exmgmt);
		
			//System.err.println(exmgmtid);
			sessionHQL.save(exmgmt);
			sessionHQL.flush();
			sessionHQL.clear();
			
			
			
			for (int i = 1; i <= Integer.parseInt(ec_exam_id); i++) {

				EXAM_SCHEDULE_DETAIL_M sub_ch = new EXAM_SCHEDULE_DETAIL_M();
				Session sessionHQL1 = this.sessionFactory.openSession();
				Transaction tx1 = sessionHQL1.beginTransaction();
				
				
				
			System.err.println("subid-------------"+request.getParameter("sub_id"));
			
			String sub= request.getParameter("sub_id");
			
			List<Map<String, Object>>list2= objDAO.getdatafromsubmst(sub);
			
			System.err.println("list2-------------"+list2.size());
				
				for (int i2 = 0; i2 < list2.size(); i2++) {
					System.err.println("111111-------------"+list2.size());
				System.err.println("e-----------------------"+list2.get(i2).get("id"));
				
				int Subject_id= (int) list2.get(i2).get("id");
				String sc_app = (String) list2.get(i2).get("sc_is_applicable");
				
				System.err.println("-----------------------"+Subject_id);
				System.err.println("e-----------------------"+sc_app);
				
				
				
				sub_ch.setSc_subject_id(Subject_id);
			sub_ch.setSc_is_applicable(sc_app);
				}
				sub_ch.setEs_id(mid);
				sub_ch.setEsd_date(date);
				sub_ch.setEsd_created_by(username);
				sub_ch.setEsd_creation_date(date);
				
				int esd_marks=Integer.parseInt(request.getParameter("esd_cutoff"));
				sub_ch.setEsd_cutoff(esd_marks);
				//sub_ch.setSc_is_applicable(list2.get(0).get(0))
				sessionHQL1.save(sub_ch);
				sessionHQL.flush();
				sessionHQL.clear();
				tx1.commit();
			
			}
			
			tx.commit();
			msg = "Data Saved Successfully";
		

		Mmap.put("msg", msg);
	
	return new ModelAndView("redirect:exam_schedule_part_dUrl");
}
		
	public int saveFunction(Object obj)
	{
		Session session1 = this.sessionFactory.openSession();
		session1.beginTransaction();
		int id=(Integer)session1.save(obj);
		session1.getTransaction().commit();
		session1.close();
		return id;
	}

	
}