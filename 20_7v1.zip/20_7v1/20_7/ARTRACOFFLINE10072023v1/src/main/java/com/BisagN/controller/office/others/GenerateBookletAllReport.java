package com.BisagN.controller.office.others;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Font.FontFamily;
//import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.HeaderFooter;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPTableEvent;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;

public class GenerateBookletAllReport extends AbstractPdfView {
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";

	ArrayList<ArrayList<String>> armwiseanalysisresult;
	ArrayList<ArrayList<String>> SubjWiseAnalysis;
	ArrayList<ArrayList<String>> commandwiseresult;
	ArrayList<ArrayList<String>> fullypassed;
	ArrayList<ArrayList<String>> result_withheld;
	ArrayList<ArrayList<String>> partially_passed;
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";
	int totalRecords = 0;
	int page = 1;
	PdfTemplate total1;

	public GenerateBookletAllReport(String Type, List<String> TH, String Heading, String username,
			ArrayList<ArrayList<String>> armwiseanalysisresult, ArrayList<ArrayList<String>> SubjWiseAnalysis,
			ArrayList<ArrayList<String>> commandwiseresult, ArrayList<ArrayList<String>> fullypassed,
			ArrayList<ArrayList<String>> partially_passed) {
		this.Type = Type;
		this.TH = TH;
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {

		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}

		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
//		 response.setHeader("Content-Disposition", "attachment; filename=\"" +
//		 file_name + ".pdf\"");

		Font pgNo = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 2, 1);
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 16, 1);
		Font fontTableHeading2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 20, 1);
		Font fontTableHeadingdataheadfirstpage = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 26, 1);

		Font fontTableHeadingMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingMainHead_Ml = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 1);

		Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
		Font fontTableHeadingMainHead_2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);

		Font fontTableHeadingSubMainHead_2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 1);
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 0);

		Font fontTableHeadingdataforFooter = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 0);

		Font fontTableHeadingdataforML2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 0);

		Rectangle two = new Rectangle(838, 590);

		String es_year = (String) model.get("es_year1");
		String letter_no = (String) model.get("letter_no1");
		String letter_date1 = (String) model.get("letter_date1");
		String start_end_month = (String) model.get("start_end_month");
		String director_name1 = (String) model.get("director_name1");

		String year2 = (String) model.get("es_year1");
		String b_month = (String) model.get("b_month");
		String e_month = (String) model.get("e_month");

		String b_month2 = (String) model.get("b_month2");
		String e_month2 = (String) model.get("e_month2");

		String bdrday = (String) model.get("bdrday");
		String bedday = (String) model.get("bedday");

//		PdfPTable maintable = new PdfPTable(1);
//		maintable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
//		maintable.setWidthPercentage(100);

		PdfPTable table_m1 = new PdfPTable(1);
		table_m1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_m1.setWidthPercentage(100);

		PdfPTable tabledata_m1 = new PdfPTable(1);
		tabledata_m1.setWidths(new int[] { 5 });
		tabledata_m1.setWidthPercentage(100 / 3.5f);
		tabledata_m1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata_m1.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata_m1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Chunk underline_m4 = new Chunk("RESTRICTED \n", fontTableHeading2);
		Chunk underline_m5 = new Chunk("PROMOTION EXAM PART B (ONLINE)", fontTableHeading2);
		Chunk underline_m6 = new Chunk("REGULAR OFFICERS: " + b_month + " " + year2 + "", fontTableHeading2);
		Chunk underline_m7 = new Chunk("RESULTS", fontTableHeadingdataheadfirstpage);

		underline_m4.setUnderline(0.1f, -2f);
		Phrase ph_m4 = new Phrase(underline_m4);
		ph_m4.setFont(fontTableHeading2);
		Paragraph cell_Mr = new Paragraph(ph_m4);
		cell_Mr.setAlignment(Element.ALIGN_CENTER);

		underline_m5.setUnderline(0.1f, -2f);
		Phrase ph_m5 = new Phrase(underline_m5);
		ph_m5.setFont(fontTableHeading2);
		Paragraph cell_M5 = new Paragraph(ph_m5);
		cell_M5.setAlignment(Element.ALIGN_CENTER);

		underline_m6.setUnderline(0.1f, -2f);
		Phrase ph_m6 = new Phrase(underline_m6);
		ph_m6.setFont(fontTableHeading2);
		Paragraph cell_M6 = new Paragraph(ph_m6);
		cell_M6.setAlignment(Element.ALIGN_CENTER);

		underline_m7.setUnderline(0.1f, -2f);
		Phrase ph_m7 = new Phrase(underline_m7);
		ph_m6.setFont(fontTableHeading2);
		Paragraph cell_M7 = new Paragraph(ph_m7);
		cell_M7.setAlignment(Element.ALIGN_CENTER);

		Image logo = null;
		try {
			@SuppressWarnings("deprecation")
			String dgis_logo = request.getRealPath("/") + "admin" + File.separator + "layout_file" + File.separator
					+ "images" + File.separator + "logo.png";
			logo = Image.getInstance(dgis_logo);
		} catch (BadElementException e) {
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		logo.setAlignment(Image.MIDDLE);
		logo.scaleAbsoluteHeight(80);
		logo.scaleAbsoluteWidth(80);
		logo.scalePercent(90);

		Chunk chunk = new Chunk(logo, 100, 10);
		// table_m1.addCell(new Phrase(chunk));

		Phrase ph1 = new Phrase();
		ph1.add(table_m1);

		PdfPCell cell_m1;
		cell_m1 = new PdfPCell();
		cell_m1.addElement(cell_Mr);
		cell_m1.addElement(new Paragraph("\n"));

		cell_m1.addElement(chunk);
		cell_m1.addElement(cell_M5);
		cell_m1.addElement(cell_M6);
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(cell_M7);
		cell_m1.addElement(new Paragraph("\n"));
		cell_m1.addElement(cell_Mr);
		cell_m1.setBorder(0);
		table_m1.addCell(cell_m1);

//		document.add(table_m1);

//		super.buildPdfMetadata(model, document, request);

//super.buildPdfMetadata(model, document, request);

//==============Covering-letter===============//

		PdfPTable table_c2 = new PdfPTable(1);
		table_c2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_c2.setWidthPercentage(100);

		PdfPTable tabledata_C12 = new PdfPTable(1);
		tabledata_C12.setWidths(new int[] { 4 });
		tabledata_C12.setWidthPercentage(100 / 1f);
		tabledata_C12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C12.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C12.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable tabledata_C1 = new PdfPTable(1);
		tabledata_C1.setWidths(new int[] { 7 });
		tabledata_C1.setWidthPercentage(100 / 3f);
		tabledata_C1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C1.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable tabledata_C2 = new PdfPTable(1);
		tabledata_C2.setWidths(new int[] { 8 });
		tabledata_C2.setWidthPercentage(100 / 7.4f);
		tabledata_C2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C2.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C2.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPTable tabledata_C3 = new PdfPTable(2);
		tabledata_C3.setWidths(new int[] { 64,36 });
		tabledata_C3.setWidthPercentage(100);
		tabledata_C3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C3.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tabledata_C3.setSpacingBefore(40f);
		tabledata_C3.getDefaultCell().setPaddingLeft(30f);

		PdfPTable tabledata_C66 = new PdfPTable(1);
		tabledata_C66.setWidths(new int[] { 4 });
		tabledata_C66.setWidthPercentage(100 / 5.5f);
		tabledata_C66.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata_C66.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata_C66.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head_c1 = new Paragraph("HQ ARTRAC (Exam Sec)", fontTableHeadingMainHead_Ml);
		Paragraph head_c2 = new Paragraph("Pin - 908548", fontTableHeadingMainHead_Ml);
		Paragraph head_c3 = new Paragraph("ClO 56 APO", fontTableHeadingMainHead_Ml);

		tabledata_C1.addCell(head_c1);
		tabledata_C1.addCell(head_c2);
		tabledata_C1.addCell(head_c3);

		Paragraph head_c4 = new Paragraph("Tele : 2822", fontTableHeadingSubMainHead);
		PdfPCell blank_head_c4 = new PdfPCell(head_c4);
		blank_head_c4.setHorizontalAlignment(Element.ALIGN_LEFT);
//		blank_head_c4.setPaddingTop(5f);
		blank_head_c4.setPaddingLeft(30f);

		blank_head_c4.setBorder(0);
		tabledata_C12.addCell(blank_head_c4);
//		Paragraph head_c5 = new Paragraph("A/16014/B/2021/GS/Exam Sec", fontTableHeadingdataforML2);
//		
//		blank_head_c4 = new PdfPCell(head_c5);
////		blank_head_c4 = new PdfPCell();
//		blank_head_c4.setHorizontalAlignment(Element.ALIGN_TOP);
////		blank_head_c4.setPaddingBottom(15f);
//		blank_head_c4.setBorder(0);
//		blank_head_c4.setPaddingLeft(50f);
//		.addCell(blank_head_c4);
		
		
		Paragraph head_c6 = new Paragraph("HQ Southern Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c7 = new Paragraph("HQ Eastern Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c8 = new Paragraph("HQ Central Command (GS/Trg))", fontTableHeadingMainHead_Ml);
		Paragraph head_c9 = new Paragraph("HQ Northern Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c10 = new Paragraph("HQ South Western Command (GS/Trg)", fontTableHeadingMainHead_Ml);
		Paragraph head_c11 = new Paragraph("HQ Andaman & Nicobar Command (GS/Trg)", fontTableHeadingMainHead_Ml);

		tabledata_C3.addCell("A/16014/B/2021/GS/Exam Sec \n \n");
		tabledata_C3.addCell("" + b_month + " " + year2 + " ");
		tabledata_C3.addCell(head_c6);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c7);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c8);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c9);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c10);
		tabledata_C3.addCell("");
		tabledata_C3.addCell(head_c11);
		tabledata_C3.addCell("\n\n");
//		tabledata_C3.addCell("");

		Chunk underlinec1 = new Chunk(
				"RESULTS OF PROMOTION EXAM PART B (ONLINE) : " + b_month + "  " + year2 + "" + "\n \n",
				fontTableHeading1);

		underlinec1.setUnderline(0.1f, -2f);

		Phrase phhc2 = new Phrase(underlinec1);
		phhc2.setFont(fontTableHeading2);

		Paragraph cell_c12 = new Paragraph(phhc2);
		cell_c12.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableC153 = new PdfPTable(1);
		tableC153.setWidths(new int[] { 100 });
		tableC153.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC153.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		tableC153.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC153.setWidthPercentage(100);
//		tableC153.setSpacingBefore(5);
		tableC153.getDefaultCell().setPaddingLeft(30f);

//		tableC153.addCell(new PdfPCell("1."));

		tableC153.addCell("1.    " + "Results of Promotion Exam Part B (Online) held from " + bdrday + " " + b_month2
				+ " to " + bedday + " " + e_month2 + " " + year2
				+ " are given in the following Appendices to this letter :~ \n");

//		tableC153.addCell("Results of Promotion Exam Part B (Online) held from "+bdrday+" "+b_month2+" to "+bedday+" "+e_month2 +" "+year2+" are given in the following Appendices to this letter :~ \n");

		tableC153.addCell("");
		tableC153.addCell("");
		tableC153.addCell("");
		tableC153.addCell("");
		tableC153.addCell("       (a)      Appx 'A'     -     Analysis of Results. \n \n");

		tableC153.addCell("");
		tableC153.addCell("       (b)      Appx 'B'     -     Passed Complete Examination. \n \n");

		tableC153.addCell("");
		tableC153.addCell("       (c)      Appx 'C'     -     Part Passed and Failures. \n \n");

		tableC153.addCell("");
		tableC153.addCell("       (d)      Appx ‘D’     -     Absentees.\n");

		tableC153.addCell("");

		tableC153.addCell("\n");

		tableC153.addCell("2.   "
				+ "These results are being distr down to Corps and equivalent HQs. Concerned officers must see their results at their respective Fmn "
				+ "HQs. These results will NOT be extracted and forwarded to units and individual offrs by any Formation HQ.");
//		tableC153.addCell(
//				"These results are being distr down to Corps and equivalent HQs. Concerned officers must see their results at their respective Fmn "
//						+ "HQs. These results will NOT be extracted and forwarded to units and individual offrs by any Formation HQ.");

		tableC153.addCell("");

		tableC153.addCell("\n\n");

		tableC153.addCell("\n\n\n3.   "
				+ "The results are also being uploaded on the My Space : MS Branch web site on the Army Intranet to facilitate speedy"
				+ " dissemination. ARTRAC (Exam Sec) is NOT resp for any corruption of data on the electronic media and the results on the Army "
				+ "Intranet will not be quoted as an auth by any candidate. The signed copy available with fmn HQs will be treated as authority."
				+ " Therefore, all candidates are advised to refer signed copy to verify their respective results.");
//		tableC153.addCell(
//				"The results are also being uploaded on the My Space : MS Branch web site on the Army Intranet to facilitate speedy");

//		tableC153.addCell("");
//		tableC153.addCell(
//				"dissemination. ARTRAC (EXAM Sec) is NOT resp for any corruption of data on the electronic media and the results on the Army "
//				+ "Intranet will not be quoted as an auth by any candidate. The signed copy available with fmn HQs will be treated as authority."
//				);

//		tableC153.addCell("");
//		tableC153.addCell(
//				"Intranet will not be quoted as an auth by any candidate. The signed copy available with fmn HQs will be treated as authority.");

//		tableC153.addCell("");
//		tableC153.addCell(
//				"Therefore, all candidates are advised to refer signed copy to verify their respective results.");

		PdfPCell cell123_C1;
		cell123_C1 = new PdfPCell();

		cell123_C1.addElement(tabledata_C12);

		cell123_C1.addElement(tabledata_C1);
		cell123_C1.addElement(tabledata_C66);
//		cell123_C1.addElement(new Paragraph("\n"));
		cell123_C1.addElement(tabledata_C2);
		cell123_C1.addElement(tabledata_C3);
		cell123_C1.addElement(cell_c12);
//		cell123_C1.addElement(new Paragraph("\n"));
		cell123_C1.addElement(tableC153);

		cell123_C1.setBorder(0);
		table_c2.addCell(cell123_C1);

//document.add(table_c2);

//super.buildPdfMetadata(model, document, request);

//==============Covering-letter 2===============//
		PdfPTable table_c3 = new PdfPTable(1);
		table_c3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_c3.setWidthPercentage(100);

		PdfPTable tableC253 = new PdfPTable(1);
		tableC253.setWidths(new int[] { 100 });
		tableC253.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC253.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
		tableC253.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC253.setWidthPercentage(100);
		tableC253.setSpacingBefore(0);
		tableC253.getDefaultCell().setPaddingLeft(30f);

//		tableC153.addCell("");
//
//		tableC153.addCell("\n");

		tableC253.addCell("4.   "
				+ "Marks obtained out of 500 have been indicated against the names of failures at Appendix C. Pass marks are not communicated"
				+ " to indl offrs and NO request / query in this regard will be addsd to this HQ.");
//		tableC253.addCell(
//				"Marks obtained out of 500 have been indicated against the names of failures at Appendix C. Pass marks are not communicated");

//		tableC253.addCell("");
		tableC253.addCell("\n");
//		tableC253.addCell("to indl offrs and NO request / query in this regard will be addsd to this HQ.");

//

		tableC253.addCell("5.   "
				+ "There is no provision for re-evaluation on demand and such requests will not be entertained, as adequate No of "
				+ "checks / counter checks have been put in place to ensure correctness at all stages of evaluation of papers.");
		tableC253.addCell("");
		tableC253.addCell("\n");
		// tableC253.addCell(
//				"There is no provision for re-evaluation on demand and such requests will not be entertained, as adequate No of");
//
//		tableC253.addCell("");
//
//		tableC253.addCell(
//				"checks / counter checks have been put in place to ensure correctness at all stages of evaluation of papers.");

		tableC253.addCell("");

//		tableC253.addCell("\n");

		tableC253.addCell("6.   "
				+ "Consolidated errors, if any, in Personal Number, Name, Arm / Service, non-printing or incorrect printing of results will be intimated"
				+ " by all Formation HQ (up to Brigade / Equivalent HQ) in respect of officers under their command, so as to reach ARTRAC (Exam Sec)"
				+ " directly by 10 Sep " + year2 + ".");
//		tableC253.addCell(
//				"Consolidated errors, if any, in Personal Number, Name, Arm / Service, non-printing or incorrect printing of results will be intimated" + "by all Formation HQ (up to Brigade / Equivalent HQ) in respect of officers under their command, so as to reach ARTRAC (Exam Sec)");
//
//		tableC253.addCell("");
//		tableC253.addCell(
//				"by all Formation HQ (up to Brigade / Equivalent HQ) in respect of officers under their command, so as to reach ARTRAC (Exam Sec)");

//		tableC253.addCell("");
//		tableC253.addCell("directly by 10 Sep "+ year2 + ".");
		tableC253.addCell("");

		tableC253.addCell("\n");

		tableC253.addCell("7.   "
				+ "The abbreviations used are:  NP - Now Passed   PP - Previously Passed   ABS - Absent   UFM - Unfair Means.");
//		tableC253.addCell("The abbreviations used are:  NP - Now Passed   PP - Previously Passed   ABS - Absent  UFM - Unfair Means");

		
//		  PdfPTable tabledata_C4 = new PdfPTable(1); 
//		  tabledata_C4.setWidths(new int[] {4});
//		  tabledata_C4.setWidthPercentage(80 / 5f);
////		  tabledata_C4.setWidthPercentage(100);
//		  tabledata_C4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
//		  tabledata_C4.setHorizontalAlignment(Element.ALIGN_LEFT);
//		  tabledata_C4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
//		  tabledata_C4.getDefaultCell().setPaddingRight(50f);
		  
		  
		  PdfPTable tabledata_C4 = new PdfPTable(2); 
		  tabledata_C4.setWidths(new int[] {75,25});
		  tabledata_C4.setWidthPercentage(80 / 5f);
//		  tabledata_C4.setWidthPercentage(100);
		  tabledata_C4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		  tabledata_C4.setHorizontalAlignment(Element.ALIGN_LEFT);
		  tabledata_C4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		  tabledata_C4.getDefaultCell().setPaddingRight(50f);
		 
		

//		PdfPTable tabledata_C4 = new PdfPTable(1);
//		tabledata_C4.setWidths(new int[] { 7 });
//		tabledata_C4.setWidthPercentage(100 / 3f);
//		tabledata_C4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
//		tabledata_C4.setHorizontalAlignment(Element.ALIGN_RIGHT);
//		tabledata_C4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		

		Paragraph head_c44 = new Paragraph("" + director_name1 + "");
		Paragraph head_c45 = new Paragraph("Col");
		Paragraph head_c46 = new Paragraph("Col GS (Exams)");
		Paragraph head_c47 = new Paragraph("for GoC-in-C ARTRAC");

		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c44);
		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c45);
		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c46);
		tabledata_C4.addCell("");
		tabledata_C4.addCell(head_c47);

//		Chunk underlinec2 = new Chunk("\t \t \t \t \t Copy to:-", fontTableHeading1);

		Chunk underlinec2 = new Chunk("\t \t \t \t \tCopy to:-",fontTableHeadingMainHead_Ml);

//		underlinec2.setUnderline(0.1f, -2f);

		Phrase phhc212 = new Phrase(underlinec2);
		phhc212.setFont(fontTableHeading2);

		Paragraph cell_c1222 = new Paragraph(phhc212);
		cell_c1222.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableC254 = new PdfPTable(1);
		tableC254.setWidths(new int[] { 100 });
		tableC254.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC254.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableC254.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC254.setWidthPercentage(100);
		tableC254.setSpacingBefore(5);
		tableC254.getDefaultCell().setPaddingLeft(30f);

		tableC254.addCell("");
		tableC254.addCell(
				"COAS Sectt, VCOAS Sectt, DCOAS (Strat), DCOAS (IS&C), DCOAS (CD&S), ADG AE, Brig PT, IGSFF, DGBR/EC1, MS4(Auto) "
						+ "MS4(D), MS9 (Policy), MISO (PSG), CIDSS, SFC, All HQ Corps, Cat ‘A’ Ests, HQ IMTRAT, HQ 22 Est, PCDA (O) Pune (AFL Section)"
						+ " (Ink Signed Copy).");
//
//		tableC254.addCell("");
//		tableC254.addCell(
//				"MS4(D), MS9 (Policy), MISO (PSG), CIDSS, SFC, All HQ Corps, Cat ‘A’ Ests, HQ IMTRAT, HQ 22 Est, PCDA (O) Pune (AFL Section)");
//
//		tableC254.addCell("");
//		tableC254.addCell("(Ink Signed Copy).");

		Chunk underlinec3 = new Chunk("\t \t \t \t \tInternal:-",fontTableHeadingMainHead_Ml);

//		underlinec3.setUnderline(0.1f, -2f);

		Phrase phhc2123 = new Phrase(underlinec3);
		phhc2123.setFont(fontTableHeading2);

		Paragraph cell_c1223 = new Paragraph(phhc2123);
		cell_c1223.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableC255 = new PdfPTable(1);
		tableC255.setWidths(new int[] { 100 });
		tableC255.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tableC255.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		tableC255.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableC255.setWidthPercentage(100);
		tableC255.setSpacingBefore(5);
		tableC255.getDefaultCell().setPaddingLeft(30f);

		tableC255.addCell("");
		tableC255.addCell("GoC in C Sectt, CoS Sectt");

		PdfPCell cell123_C2;
		cell123_C2 = new PdfPCell();

		cell123_C2.setPaddingBottom(25f);
		cell123_C2.setBorder(0);
		table_c3.addCell(cell123_C2);
		table_c3.addCell(tableC253);
		cell123_C2.setPaddingBottom(25f);
		cell123_C2.setBorder(0);
		table_c3.addCell(cell123_C2);
		cell123_C2.setPaddingBottom(25f);
		table_c3.addCell(tabledata_C4);

		cell123_C2.setPaddingBottom(15f);
		cell123_C2.setBorder(0);
		table_c3.addCell(cell123_C2);
		table_c3.addCell(cell_c1222);
		table_c3.addCell(tableC254);
		table_c3.addCell(cell_c1223);
		table_c3.addCell(tableC255);

//document.add(table_c3);

//super.buildPdfMetadata(model, document, request);
		// ==============================Arm/Service wise analysis of result
		// ==================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);

		PdfPTable tabledata1 = new PdfPTable(2);
		tabledata1.setWidths(new int[] { 70,30 });
//		tabledata1.setWidthPercentage(100 / 3.5f);
		tabledata1.setWidthPercentage(100);
		tabledata1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata1.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head1 = new Paragraph("Appendix 'A'", fontTableHeadingMainHead_l);
		Paragraph head2 = new Paragraph("(Refers to Para 1(a) of HQ ARTRAC \n Exam Sec " + " letter No:" + letter_no, fontTableHeadingMainHead_l);
//		Paragraph head4 = new Paragraph("Letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head5 = new Paragraph("dated   " + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata1.addCell("");
		tabledata1.addCell(head1);
		tabledata1.addCell("");
		tabledata1.addCell(head2);
//		tabledata1.addCell(head4);
		tabledata1.addCell("");
		tabledata1.addCell(head5);

		Chunk underline1 = new Chunk("ARMY TRAINING COMMAND (EXAM SEC) \n" + "\n" + "PROMOTION EXAMINATION PART B (ONLINE) - "
				+ es_year + "" + "\n\n" + "ARM / SERVICES WISE ANALYSIS OF RESULTS", fontTableHeadingSubMainHead);

		underline1.setUnderline(0.1f, -2f);
		Phrase phh2 = new Phrase(underline1);

		Paragraph cell12 = new Paragraph(phh2);
		cell12.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell12);

		PdfPTable tabledata = new PdfPTable(12);
		tabledata.setWidths(new int[] { 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 });
		tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
//		tabledata.getDefaultCell().setPaddingLeft(50f);
//		tabledata.getDefaultCell().setPadding(25f);
		tabledata.setWidthPercentage(100);
		
//		tabledata.getDefaultCell().setPaddingRight(80f);

		Paragraph A1 = new Paragraph("Arm/\nService", fontTableHeadingSubMainHead_2);
		Paragraph B1 = new Paragraph("Total Offrs Appd", fontTableHeadingSubMainHead_2);
		Paragraph C1 = new Paragraph("Passed Whole Exam", fontTableHeadingSubMainHead_2);
		Paragraph D1 = new Paragraph("Partially Passed in One/More Subjects", fontTableHeadingSubMainHead_2);
		Paragraph E1 = new Paragraph("Failed in All Appd Subject", fontTableHeadingSubMainHead_2);
		Paragraph F1 = new Paragraph("Appd in Whole Exam (All Subjects)", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cella;
		blank_cella = new PdfPCell();
		blank_cella.setRowspan(3);
		blank_cella.addElement(A1);
		blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cella.setPadding(3);
		tabledata.addCell(blank_cella);

		PdfPCell blank_cellb = new PdfPCell(B1);
		blank_cellb.setRowspan(2);
		blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellb.setPadding(3);
		tabledata.addCell(blank_cellb);

		PdfPCell blank_cellc = new PdfPCell(C1);
		blank_cellc.setRowspan(2);
		blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellc.setPadding(3);
		tabledata.addCell(blank_cellc);

		PdfPCell blank_celld = new PdfPCell(D1);
		blank_celld.setRowspan(2);
		blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_celld.setPadding(3);
		tabledata.addCell(blank_celld);

		PdfPCell blank_celle = new PdfPCell(E1);
		blank_celle.setRowspan(2);
		blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_celle.setPadding(3);
		tabledata.addCell(blank_celle);

		PdfPCell blank_cellf = new PdfPCell(F1);
		blank_cellf.setColspan(7);
		blank_cellf.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf.setPadding(3);

		tabledata.addCell(blank_cellf);

		ArrayList<List<String>> armresult = (ArrayList<List<String>>) model.get("armwiseanalysisresult");

		Paragraph F2 = new Paragraph("Total Offrs Appd ", fontTableHeadingSubMainHead_2);
		PdfPCell blank_cellF2 = new PdfPCell(F2);
		blank_cellF2.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellF2.setPadding(3);
		tabledata.addCell(blank_cellF2);

		Paragraph G2 = new Paragraph("Passed in All", fontTableHeadingSubMainHead_2);
		blank_cellF2 = new PdfPCell(G2);
		blank_cellF2.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellF2.setPadding(3);
		tabledata.addCell(blank_cellF2);
		Paragraph H2 = new Paragraph("Passed in Four", fontTableHeadingSubMainHead_2);
		blank_cellF2 = new PdfPCell(H2);
		blank_cellF2.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellF2.setPadding(3);
		tabledata.addCell(blank_cellF2);
		Paragraph I2 = new Paragraph("Passed in Three", fontTableHeadingSubMainHead_2);
		blank_cellF2 = new PdfPCell(I2);
		blank_cellF2.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellF2.setPadding(3);
		tabledata.addCell(blank_cellF2);
		Paragraph J2 = new Paragraph("Passed in Two", fontTableHeadingSubMainHead_2);
		blank_cellF2 = new PdfPCell(J2);
		blank_cellF2.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellF2.setPadding(3);
		tabledata.addCell(blank_cellF2);
		Paragraph K2 = new Paragraph("Passed in One", fontTableHeadingSubMainHead_2);
		blank_cellF2 = new PdfPCell(K2);
		blank_cellF2.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellF2.setPadding(3);
		tabledata.addCell(blank_cellF2);
		Paragraph L2 = new Paragraph("Passed in None", fontTableHeadingSubMainHead_2);
		blank_cellF2 = new PdfPCell(L2);
		blank_cellF2.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellF2.setPadding(3);
		tabledata.addCell(blank_cellF2);

		Paragraph B3 = new Paragraph("Nos", fontTableHeadingSubMainHead_2);
		PdfPCell cellB3 = new PdfPCell(B3);
		cellB3.setHorizontalAlignment(Element.ALIGN_CENTER);

		Paragraph C3 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);

		Paragraph D3 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);

		Paragraph E3 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph F3 = new Paragraph("Nos", fontTableHeadingSubMainHead_2);
		Paragraph G3 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph H3 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph I3 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph J3 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph K3 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph L3 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);

		tabledata.addCell(cellB3);
		tabledata.addCell(C3);
		tabledata.addCell(D3);
		tabledata.addCell(E3);
		tabledata.addCell(F3);
		tabledata.addCell(G3);
		tabledata.addCell(H3);
		tabledata.addCell(I3);
		tabledata.addCell(J3);
		tabledata.addCell(K3);
		tabledata.addCell(L3);

		// data bind

		if (armresult.size() == 0) {
			Paragraph blank_a = new Paragraph("Data Not Available", fontTableHeadingMainHead);

			PdfPCell cell123_a;
			cell123_a = new PdfPCell();
			cell123_a.addElement(blank_a);
			cell123_a.setRowspan(12);
			tabledata.addCell(cell123_a);

		} else {
			int tt = 0;
			for (int i = 0; tt < armresult.size(); i++) {
				if (i == armresult.size()) {
					i = 0;
				}
				tt = tt + 1;

				List<String> l = armresult.get(i);
				Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
				Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);

				Paragraph blank3 = new Paragraph(l.get(2) + getSpace((16 - (l.get(2) + l.get(3)).length())) + l.get(3),
						fontTableHeadingdata);
				Paragraph blank4 = new Paragraph(l.get(4) + getSpace((18 - (l.get(4) + l.get(5)).length())) + l.get(5),
						fontTableHeadingdata);
				Paragraph blank5 = new Paragraph(l.get(6) + getSpace((18 - (l.get(6) + l.get(7)).length())) + l.get(7),
						fontTableHeadingdata);
				Paragraph blank6 = new Paragraph(l.get(8), fontTableHeadingdata);
				Paragraph blank7 = new Paragraph(
						l.get(9) + getSpace((18 - (l.get(9) + l.get(10)).length())) + l.get(10), fontTableHeadingdata);
				Paragraph blank8 = new Paragraph(
						l.get(11) + getSpace((18 - (l.get(11) + l.get(12)).length())) + l.get(12),
						fontTableHeadingdata);
				Paragraph blank9 = new Paragraph(
						l.get(13) + getSpace((18 - (l.get(13) + l.get(14)).length())) + l.get(14),
						fontTableHeadingdata);
				Paragraph blank10 = new Paragraph(
						l.get(15) + getSpace((18 - (l.get(15) + l.get(16)).length())) + l.get(16),
						fontTableHeadingdata);
				Paragraph blank11 = new Paragraph(
						l.get(17) + getSpace((18 - (l.get(17) + l.get(18)).length())) + l.get(18),
						fontTableHeadingdata);
				Paragraph blank12 = new Paragraph(
						l.get(19) + getSpace((18 - (l.get(19) + l.get(20)).length())) + l.get(20),
						fontTableHeadingdata);

				PdfPCell cellar = new PdfPCell();

				cellar.setFixedHeight(20f);
				if (i % 2 == 0) {
					cellar.setBackgroundColor(java.awt.Color.lightGray);
				}
				cellar.setPhrase(blank1);
				cellar.setPadding(2);
				if (i == armresult.size() - 1) {

					cellar.setHorizontalAlignment(Element.ALIGN_CENTER);

				}
				tabledata.addCell(cellar);
				cellar.setPhrase(blank2);
				cellar.setPadding(2);
				cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata.addCell(cellar);

				cellar.setPhrase(blank3);
				cellar.setPadding(2);
				cellar.setHorizontalAlignment(Element.ALIGN_RIGHT);
				tabledata.addCell(cellar);

				cellar.setPhrase(blank4);
				cellar.setPadding(2);
				tabledata.addCell(cellar);

				cellar.setPhrase(blank5);
				cellar.setPadding(2);
				tabledata.addCell(cellar);

				cellar.setPhrase(blank6);
				cellar.setPadding(2);
				cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata.addCell(cellar);

				cellar.setPhrase(blank7);
				cellar.setPadding(2);
				cellar.setHorizontalAlignment(Element.ALIGN_RIGHT);
				tabledata.addCell(cellar);

				cellar.setPhrase(blank8);
				cellar.setPadding(2);
				tabledata.addCell(cellar);

				cellar.setPhrase(blank9);
				cellar.setPadding(2);
				tabledata.addCell(cellar);

				cellar.setPhrase(blank10);
				cellar.setPadding(2);
				tabledata.addCell(cellar);
				cellar.setPhrase(blank11);
				cellar.setPadding(2);
				tabledata.addCell(cellar);

				cellar.setPhrase(blank12);
				cellar.setPadding(2);
				tabledata.addCell(cellar);

			}
		}

		PdfPTable tabledataend = new PdfPTable(1);
		tabledataend.setWidths(new int[] { 5 });
		tabledataend.setWidthPercentage(100);
		tabledataend.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledataend.getDefaultCell().setVerticalAlignment(Element.ALIGN_BOTTOM);
		tabledataend.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell cell123 = new PdfPCell();
		cell123.setPaddingLeft(30f);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tabledata1);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tableheader);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tabledata);
		// cell123.addElement(tabledataend);
		cell123.setBorder(0);
		table.addCell(cell123);

		PdfPCell cell124 = new PdfPCell();
		cell124.setVerticalAlignment(Element.ALIGN_BOTTOM);
		cell124.setBorder(0);
		cell124.addElement(tabledataend);
		table.getDefaultCell().setBottom(0);
		table.addCell(cell124);

//===========================Arm/Service wise SUBJECT WISE SUMMARY OF RESULTS==============//

		PdfPTable table1 = new PdfPTable(1);
		table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table1.setWidthPercentage(100);

		PdfPTable tabledata12 = new PdfPTable(1);
		tabledata12.setWidths(new int[] { 7 });
//		tabledata12.setWidthPercentage(100 / 3.5f);
		tabledata12.setWidthPercentage(100);
		tabledata12.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata12.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata12.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head12 = new Paragraph("Appendix 'A' (Contd)", fontTableHeadingMainHead_l);
		tabledata12.addCell(head12);
		Chunk chunk1 = new Chunk();

		Chunk underline = new Chunk("", fontTableHeading1);
		Chunk underline12 = new Chunk("ARMY TRAINING COMMAND (EXAM SEC)\n" + "\n" + "PROMOTION EXAMINATION PART B (ONLINE) - "
				+ es_year + " " + "\n\n" + "ARM / SERVICE SUBJECT WISE SUMMARY OF RESULTS", fontTableHeadingSubMainHead);

		underline12.setUnderline(0.1f, -2f);
		Phrase ph = new Phrase(underline);
		Phrase phh12 = new Phrase(underline12);
		ph.add("\n");
		phh12.add("\n");
		phh12.add("\n");

		ph.setFont(fontTableHeading1);
		phh12.setFont(fontTableHeadingSubMainHead);

		Paragraph cell1 = new Paragraph(ph);
		cell1.setAlignment(Element.ALIGN_RIGHT);

		Paragraph cell11 = new Paragraph(phh12);
		cell12.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader1 = new PdfPTable(1);
		tableheader1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader1.setWidthPercentage(100);
		tableheader1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader1.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader1.addCell(cell1);
		tableheader1.addCell(cell11);

		PdfPTable tabledata13 = new PdfPTable(16);
		tabledata13.setWidths(new int[] { 5, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 });
		tabledata13.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata13.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
		tabledata13.setWidthPercentage(100);

		Paragraph a = new Paragraph("ARM/\nSERVICE", fontTableHeadingSubMainHead_2);
		Paragraph b = new Paragraph("ADM", fontTableHeadingSubMainHead_2);
		Paragraph c = new Paragraph("LAW", fontTableHeadingSubMainHead_2);
		Paragraph d = new Paragraph("MIL HISTORY", fontTableHeadingSubMainHead_2);
		Paragraph e = new Paragraph("CURRENT AFFAIRS", fontTableHeadingSubMainHead_2);
		Paragraph f = new Paragraph("TACTICS", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cella1 = new PdfPCell(a);
		blank_cella1.setRowspan(2);
		blank_cella1.setPadding(5);
		blank_cella1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellb1 = new PdfPCell(b);
		blank_cellb1.setColspan(3);
		blank_cellb1.setPadding(5);
		blank_cellb1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellc1 = new PdfPCell(c);
		blank_cellc1.setColspan(3);
		blank_cellc1.setPadding(5);
		blank_cellc1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_celld1 = new PdfPCell(d);
		blank_celld1.setColspan(3);
		blank_celld1.setPadding(5);
		blank_celld1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_celle1 = new PdfPCell(e);
		blank_celle1.setColspan(3);
		blank_celle1.setPadding(5);
		blank_celle1.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellf1 = new PdfPCell(f);
		blank_cellf1.setColspan(3);
		blank_cellf1.setPadding(5);
		blank_cellf1.setHorizontalAlignment(Element.ALIGN_CENTER);

		ArrayList<List<String>> subanyls = (ArrayList<List<String>>) model.get("SubjWiseAnalysis");

		tabledata13.addCell(blank_cella1);
		tabledata13.addCell(blank_cellb1);
		tabledata13.addCell(blank_cellc1);
		tabledata13.addCell(blank_celld1);
		tabledata13.addCell(blank_celle1);
		tabledata13.addCell(blank_cellf1);

		Paragraph bb = new Paragraph("APPD", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(bb);
		blank_cellf1.setPadding(5);
		tabledata13.addCell(blank_cellf1);
		Paragraph cc = new Paragraph("PASS", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(cc);
		blank_cellf1.setPadding(5);
		tabledata13.addCell(blank_cellf1);
		Paragraph dd = new Paragraph("%", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(dd);
		blank_cellf1.setPadding(5);
		blank_cellf1.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata13.addCell(blank_cellf1);
		Paragraph ee = new Paragraph("APPD", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(ee);
		blank_cellf1.setPadding(5);
		tabledata13.addCell(blank_cellf1);
		Paragraph ff = new Paragraph("PASS", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(ff);
		blank_cellf1.setPadding(5);
		tabledata13.addCell(blank_cellf1);
		Paragraph gg = new Paragraph("%", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(gg);
		blank_cellf1.setPadding(5);
		blank_cellf1.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata13.addCell(blank_cellf1);
		Paragraph hh = new Paragraph("APPD", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(hh);
		blank_cellf1.setPadding(5);
		tabledata13.addCell(blank_cellf1);
		Paragraph ii = new Paragraph("PASS", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(ii);
		blank_cellf1.setPadding(5);
		tabledata13.addCell(blank_cellf1);
		Paragraph jj = new Paragraph("%", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(jj);
		blank_cellf1.setPadding(5);
		blank_cellf1.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata13.addCell(blank_cellf1);
		Paragraph kk = new Paragraph("APPD", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(kk);
		blank_cellf1.setPadding(5);
		tabledata13.addCell(blank_cellf1);
		Paragraph ll = new Paragraph("PASS", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(ll);
		blank_cellf1.setPadding(5);
		tabledata13.addCell(blank_cellf1);
		Paragraph mm = new Paragraph("%", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(mm);
		blank_cellf1.setPadding(5);
		blank_cellf1.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata13.addCell(blank_cellf1);
		Paragraph nn = new Paragraph("APPD", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(nn);
		blank_cellf1.setPadding(5);
		tabledata13.addCell(blank_cellf1);
		Paragraph oo = new Paragraph("PASS", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(oo);
		blank_cellf1.setPadding(5);
		tabledata13.addCell(blank_cellf1);
		Paragraph pp = new Paragraph("%", fontTableHeadingSubMainHead_2);
		blank_cellf1 = new PdfPCell(pp);
		blank_cellf1.setPadding(5);
		blank_cellf1.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata13.addCell(blank_cellf1);

		if (subanyls.size() == 0) {
			Paragraph blank_a = new Paragraph("Data Not Available", fontTableHeadingdata);

			PdfPCell cell123_sub;
			cell123_sub = new PdfPCell();
			cell123_sub.addElement(blank_a);
			cell123_sub.setRowspan(16);
			tabledata13.addCell(cell123_sub);

		} else {
			for (int i = 0; i < subanyls.size(); i++) {

				List<String> l = subanyls.get(i);
				Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
				Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
				Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingdata);
				Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingdata);
				Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingdata);
				Paragraph blank6 = new Paragraph(l.get(5), fontTableHeadingdata);
				Paragraph blank7 = new Paragraph(l.get(6), fontTableHeadingdata);
				Paragraph blank8 = new Paragraph(l.get(7), fontTableHeadingdata);
				Paragraph blank9 = new Paragraph(l.get(8), fontTableHeadingdata);
				Paragraph blank10 = new Paragraph(l.get(9), fontTableHeadingdata);
				Paragraph blank11 = new Paragraph(l.get(10), fontTableHeadingdata);
				Paragraph blank12 = new Paragraph(l.get(11), fontTableHeadingdata);
				Paragraph blank13 = new Paragraph(l.get(12), fontTableHeadingdata);
				Paragraph blank14 = new Paragraph(l.get(13), fontTableHeadingdata);
				Paragraph blank15 = new Paragraph(l.get(14), fontTableHeadingdata);
				Paragraph blank16 = new Paragraph(l.get(15), fontTableHeadingdata);

				PdfPCell cell_ARM = new PdfPCell();
				if (i % 2 == 0) {
					cell_ARM.setBackgroundColor(java.awt.Color.lightGray);
				}
				cell_ARM.setPhrase(blank1);
				cell_ARM.setPadding(5);
				if (i == subanyls.size() - 1) {
					cell_ARM.setHorizontalAlignment(Element.ALIGN_RIGHT);
				}
				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank2);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank3);
				cell_ARM.setPadding(5);
				tabledata13.addCell(cell_ARM);

				cell_ARM.setPhrase(blank4);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);

				cell_ARM.setPhrase(blank5);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);

				cell_ARM.setPhrase(blank6);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank7);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank8);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);

				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank9);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);

				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank10);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank11);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank12);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank13);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank14);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank15);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);
				cell_ARM.setPhrase(blank16);
				cell_ARM.setPadding(5);
				cell_ARM.setHorizontalAlignment(Element.ALIGN_CENTER);
				tabledata13.addCell(cell_ARM);

			}
		}
		PdfPTable tabledataend1 = new PdfPTable(1);
		tabledataend1.setWidths(new int[] { 5 });
		tabledataend1.setWidthPercentage(100);
		tabledataend1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledataend1.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell cell1231;
		cell1231 = new PdfPCell();
		cell1231.setPaddingLeft(30f);
		cell1231.addElement(new Paragraph("\n"));
		cell1231.addElement(tabledata12);
		cell1231.addElement(new Paragraph("\n"));
		cell1231.addElement(tableheader1);
		cell1231.addElement(new Paragraph("\n"));
		cell1231.addElement(tabledata13);

		cell1231.addElement(tabledataend1);
		cell1231.setBorder(0);
		table1.addCell(cell1231);

//=====================Command wise analysis=========================//

		PdfPTable table3 = new PdfPTable(1);
		table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table3.setWidthPercentage(100);

		PdfPTable tabledata3 = new PdfPTable(1);
		tabledata3.setWidths(new int[] { 7 });
//		tabledata3.setWidthPercentage(100 / 3.5f);
		tabledata3.setWidthPercentage(100);
		tabledata3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata3.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata3.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head31 = new Paragraph("Appendix 'A' (Contd)", fontTableHeadingMainHead_l);
		tabledata3.addCell(head31);

		Chunk underline3 = new Chunk("", fontTableHeading1);
		Chunk underline31 = new Chunk("ARMY TRAINING COMMAND (EXAM SEC)" + "\n\n" + "PROMOTION EXAMINATION PART B (ONLINE) - "
				+ es_year + "" + "\n\n" + " COMMAND WISE ANALYSIS  OF RESULTS", fontTableHeadingSubMainHead);

		underline31.setUnderline(0.1f, -2f);
		Phrase ph3 = new Phrase(underline3);
		Phrase phh3 = new Phrase(underline31);
		phh3.add("\n");
		phh3.add("\n");

		ph3.setFont(fontTableHeading1);
		phh3.setFont(fontTableHeadingSubMainHead);

		Paragraph cell3 = new Paragraph(ph3);
		cell3.setAlignment(Element.ALIGN_LEFT);

		Paragraph cell31 = new Paragraph(phh3);
		cell31.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader3 = new PdfPTable(1);
		tableheader3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader3.setWidthPercentage(100);
		tableheader3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader3.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader3.addCell(cell3);
		tableheader3.addCell(cell31);

		PdfPTable tabledata31 = new PdfPTable(12);
		tabledata31.setWidths(new int[] { 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 });
		tabledata31.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata31.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata31.setWidthPercentage(100);

		Paragraph A31 = new Paragraph("Command", fontTableHeadingSubMainHead_2);
		Paragraph B31 = new Paragraph("Total Offrs Appd ", fontTableHeadingSubMainHead_2);
		Paragraph C31 = new Paragraph("Passed Whole Exam", fontTableHeadingSubMainHead_2);
		Paragraph D31 = new Paragraph("Passed in One/More Subjects", fontTableHeadingSubMainHead_2);
		Paragraph E31 = new Paragraph("Failed in All Appd Subject", fontTableHeadingSubMainHead_2);
		Paragraph F31 = new Paragraph("Appd in Whole Exam (All Subjects)", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cella3 = new PdfPCell(A31);
		blank_cella3.setRowspan(3);
		blank_cella3.setPadding(3);
		blank_cella3.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata31.addCell(blank_cella3);


		
		PdfPCell blank_cellb3 = new PdfPCell(B31);
		blank_cellb3.setRowspan(2);
		blank_cellb3.setPadding(3);
		blank_cellb3.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata31.addCell(blank_cellb3);

		PdfPCell blank_cellc3 = new PdfPCell(C31);
		blank_cellc3.setRowspan(2);
		blank_cellc3.setPadding(3);
		blank_cellc3.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata31.addCell(blank_cellc3);

		PdfPCell blank_celld3 = new PdfPCell(D31);
		blank_celld3.setRowspan(2);
		blank_celld3.setPadding(3);
		blank_celld3.setHorizontalAlignment(Element.ALIGN_CENTER);
		
		tabledata31.addCell(blank_celld3);

		PdfPCell blank_celle3 = new PdfPCell(E31);
		blank_celle3.setRowspan(2);
		blank_celle3.setPadding(3);
		blank_celle3.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata31.addCell(blank_celle3);

		PdfPCell blank_cellf3 = new PdfPCell(F31);
		blank_cellf3.setColspan(7);
		blank_cellf3.setPadding(3);
		blank_cellf3.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata31.addCell(blank_cellf3);

		ArrayList<List<String>> commandwise = (ArrayList<List<String>>) model.get("commandwiseresult");

		Paragraph F331 = new Paragraph("Total Offrs Appd ", fontTableHeadingSubMainHead_2);
		blank_cellf3 = new PdfPCell(F2);
		blank_cellf3.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf3.setPadding(3);
		tabledata31.addCell(blank_cellf3);

		Paragraph G31 = new Paragraph("Passed in All", fontTableHeadingSubMainHead_2);
		blank_cellf3 = new PdfPCell(G2);
		blank_cellf3.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf3.setPadding(3);
		tabledata31.addCell(blank_cellf3);

		Paragraph H31 = new Paragraph("Passed in Four", fontTableHeadingSubMainHead_2);
		blank_cellf3 = new PdfPCell(H2);
		blank_cellf3.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf3.setPadding(3);
		tabledata31.addCell(blank_cellf3);

		Paragraph I31 = new Paragraph("Passed in Three", fontTableHeadingSubMainHead_2);
		blank_cellf3 = new PdfPCell(I2);
		blank_cellf3.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf3.setPadding(3);
		tabledata31.addCell(blank_cellf3);

		Paragraph J31 = new Paragraph("Passed in Two", fontTableHeadingSubMainHead_2);
		blank_cellf3 = new PdfPCell(J2);
		blank_cellf3.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf3.setPadding(3);
		tabledata31.addCell(blank_cellf3);
		Paragraph K31 = new Paragraph("Passed in One", fontTableHeadingSubMainHead_2);
		blank_cellf3 = new PdfPCell(K2);
		blank_cellf3.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf3.setPadding(3);
		tabledata31.addCell(blank_cellf3);
		Paragraph L31 = new Paragraph("Passed in None", fontTableHeadingSubMainHead_2);
		blank_cellf3 = new PdfPCell(L2);
		blank_cellf3.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cellf3.setPadding(3);
		tabledata31.addCell(blank_cellf3);

		Paragraph B312 = new Paragraph("Nos", fontTableHeadingSubMainHead_2);
		PdfPCell cellB312 = new PdfPCell(B3);
//		blank_cellf1.setPadding(5);
		cellB312.setHorizontalAlignment(Element.ALIGN_CENTER);

		Paragraph C312 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		
		Paragraph D312 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);

		Paragraph E312 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph F312 = new Paragraph("Nos", fontTableHeadingSubMainHead_2);
		Paragraph G32 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph H32 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph I32 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph J32 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph K32 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);
		Paragraph L32 = new Paragraph("Nos" + getSpace((16 - ("No %").length())) + "%", fontTableHeadingSubMainHead_2);

		tabledata31.addCell(cellB312);
		tabledata31.addCell(C312);
		tabledata31.addCell(D312);
		tabledata31.addCell(E312);
		tabledata31.addCell(F312);
		tabledata31.addCell(G32);
		tabledata31.addCell(H32);
		tabledata31.addCell(I32);
		tabledata31.addCell(J32);
		tabledata31.addCell(K32);
		tabledata31.addCell(L32);

//data bind

		for (int i = 0; i < commandwise.size(); i++) {

			List<String> l = commandwise.get(i);
			Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph blank3 = new Paragraph(l.get(2) + getSpace((16 - (l.get(2) + l.get(3)).length())) + l.get(3),
					fontTableHeadingdata);
			Paragraph blank4 = new Paragraph(l.get(4) + getSpace((18 - (l.get(4) + l.get(5)).length())) + l.get(5),
					fontTableHeadingdata);
			Paragraph blank5 = new Paragraph(l.get(6) + getSpace((18 - (l.get(6) + l.get(7)).length())) + l.get(7),
					fontTableHeadingdata);
			Paragraph blank6 = new Paragraph(l.get(8), fontTableHeadingdata);

			Paragraph blank7 = new Paragraph(l.get(9) + getSpace((18 - (l.get(9) + l.get(10)).length())) + l.get(10),
					fontTableHeadingdata);
			Paragraph blank8 = new Paragraph(l.get(11) + getSpace((18 - (l.get(11) + l.get(12)).length())) + l.get(12),
					fontTableHeadingdata);
			Paragraph blank9 = new Paragraph(l.get(13) + getSpace((18 - (l.get(13) + l.get(14)).length())) + l.get(14),
					fontTableHeadingdata);
			Paragraph blank10 = new Paragraph(l.get(15) + getSpace((18 - (l.get(15) + l.get(16)).length())) + l.get(16),
					fontTableHeadingdata);
			Paragraph blank11 = new Paragraph(l.get(17) + getSpace((18 - (l.get(17) + l.get(18)).length())) + l.get(18),
					fontTableHeadingdata);
			Paragraph blank12 = new Paragraph(l.get(19) + getSpace((18 - (l.get(19) + l.get(20)).length())) + l.get(20),
					fontTableHeadingdata);

			tabledata31.getDefaultCell().setFixedHeight(20f);
			PdfPCell cell_comnd = new PdfPCell();
			if (i % 2 == 0) {
				cell_comnd.setBackgroundColor(java.awt.Color.lightGray);
			}
			cell_comnd.setPhrase(blank1);
			cell_comnd.setPadding(5);
			cell_comnd.setHorizontalAlignment(Element.ALIGN_CENTER);
			if (i == commandwise.size() - 1) {
				cell_comnd.setHorizontalAlignment(Element.ALIGN_RIGHT);
			}
			tabledata31.addCell(cell_comnd);
			
			
			cell_comnd.setPhrase(blank2);
			cell_comnd.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell_comnd.setPadding(3);
			tabledata31.addCell(cell_comnd);
		
			
			cell_comnd.setPhrase(blank3);
			cell_comnd.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cell_comnd.setPadding(1);
			tabledata31.addCell(cell_comnd);
			
		
			
			cell_comnd.setPhrase(blank4);
			cell_comnd.setPadding(1);
			tabledata31.addCell(cell_comnd);
			cell_comnd.setPhrase(blank5);
			cell_comnd.setPadding(1);
			tabledata31.addCell(cell_comnd);
			cell_comnd.setPhrase(blank6);
			cell_comnd.setPadding(3);
			cell_comnd.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata31.addCell(cell_comnd);
			cell_comnd.setPhrase(blank7);
			cell_comnd.setPadding(1);
			cell_comnd.setHorizontalAlignment(Element.ALIGN_RIGHT);
			tabledata31.addCell(cell_comnd);
			cell_comnd.setPhrase(blank8);
			cell_comnd.setPadding(1);
			tabledata31.addCell(cell_comnd);
			cell_comnd.setPhrase(blank9);
			cell_comnd.setPadding(1);
			tabledata31.addCell(cell_comnd);
			cell_comnd.setPhrase(blank10);
			cell_comnd.setPadding(1);
			tabledata31.addCell(cell_comnd);
			cell_comnd.setPhrase(blank11);
			cell_comnd.setPadding(1);
			tabledata31.addCell(cell_comnd);
			cell_comnd.setPhrase(blank12);
			cell_comnd.setPadding(1);
			tabledata31.addCell(cell_comnd);

		}

		PdfPTable tabledataend3 = new PdfPTable(1);
		tabledataend3.setWidths(new int[] { 5 });
		tabledataend3.setWidthPercentage(100);
		tabledataend3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledataend3.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		PdfPCell cell1233;
		cell1233 = new PdfPCell();
		cell1233.setPaddingLeft(30f);
		cell1233.addElement(new Paragraph("\n"));
		cell1233.addElement(tabledata3);
		cell1233.addElement(new Paragraph("\n"));
		cell1233.addElement(tableheader3);
		cell1233.addElement(tabledata31);
		cell1233.addElement(new Paragraph("\n"));
		cell1233.addElement(new Paragraph("\n"));
		cell1233.addElement(new Paragraph("\n"));
		cell1233.addElement(new Paragraph("\n"));
		cell1233.addElement(tabledataend3);
		cell1233.setBorder(0);

		table3.addCell(cell1233);
		table3.setHeadersInEvent(false);

//===================Fully-Passed====================//

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table4 = new PdfPTable(1);
		table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table4.setWidthPercentage(100);

		PdfPTable tabledata4 = new PdfPTable(1);
		tabledata4.setWidths(new int[] { 7 });
		tabledata4.setWidthPercentage(100 / 3.5f);
		tabledata4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata4.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head45 = new Paragraph("Appendix 'B'", fontTableHeadingMainHead_l);
		Paragraph head41 = new Paragraph("(Refers to Para 1(b) of HQ ARTRAC Exam Sec" + " letter No:" + letter_no, fontTableHeadingMainHead_l);
//		Paragraph head43 = new Paragraph("Letter No:" + letter_no, fontTableHeadingMainHead_2);
		Paragraph head44 = new Paragraph("dated   " + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata4.addCell(head45);
		tabledata4.addCell(head41);
//		tabledata4.addCell(head43);
		tabledata4.addCell(head44);

		Chunk army_training_command_heading = new Chunk("ARMY TRAINING COMMAND (EXAM SEC)",
				fontTableHeadingSubMainHead);
		army_training_command_heading.setUnderline(0.1f, -2f);
		Paragraph army_training_command_paragraph = new Paragraph(army_training_command_heading);
		army_training_command_paragraph.setFont(fontTableHeading1);
		army_training_command_paragraph.setAlignment(Element.ALIGN_CENTER);

		Chunk full_pass_heading = new Chunk("\nPROMOTION EXAMINATION PART B (ONLINE) - " + es_year + "\n\n" + "RESULTS - FULL PASSED\n\n",
				fontTableHeadingSubMainHead);
		full_pass_heading.setUnderline(0.1f, -2f);
		Paragraph full_pass_heading_paragraph = new Paragraph(full_pass_heading);
		full_pass_heading_paragraph.setFont(fontTableHeading1);
		full_pass_heading_paragraph.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader4 = new PdfPTable(1);
		tableheader4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader4.setWidthPercentage(100);
		tableheader4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader4.addCell(army_training_command_paragraph);
		// tabledata4.addCell(tableheader4);

		PdfPTable tabledatamain = new PdfPTable(2);
		tabledatamain.setWidths(new int[] { 50, 50 });
		tabledatamain.setWidthPercentage(100);
		tabledatamain.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledatamain.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPTable tableRdata4 = new PdfPTable(2);
		tableRdata4.setWidthPercentage(100);
		tableRdata4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableRdata4.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);

		
//		PdfPTable tabledata31 = new PdfPTable(12);
//		tabledata31.setWidths(new int[] { 3, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3 });
//		tabledata31.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//		tabledata31.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
//		tabledata31.setWidthPercentage(90);
		
		
		
		PdfPTable tabledata41 = new PdfPTable(5);
		tabledata41.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tabledata41.setWidths(new int[] { 1, 4, 3, 5, 4 });
//		tabledata41.setWidths(new int[] { 10, 10, 10, 10, 10 });
		tabledata41.setWidthPercentage(100);
		tabledata41.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata41.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);


		ArrayList<List<String>> fullypassed = (ArrayList<List<String>>) model.get("fullypassed");

		Paragraph a4 = new Paragraph("Ser No", fontTableHeadingSubMainHead_2);
		PdfPCell cella4 = new PdfPCell(a4);
		cella4.setHorizontalAlignment(Element.ALIGN_CENTER);
		cella4.setPadding(5);
		tabledata41.addCell(cella4);

		Paragraph b4 = new Paragraph("Personal No ", fontTableHeadingSubMainHead_2);
		PdfPCell cellb4 = new PdfPCell(b4);
		cellb4.setHorizontalAlignment(Element.ALIGN_CENTER);
		cella4.setPadding(5);
		tabledata41.addCell(cellb4);

		Paragraph c4 = new Paragraph("Rank", fontTableHeadingSubMainHead_2);
		PdfPCell cellc4 = new PdfPCell(c4);
		cellc4.setHorizontalAlignment(Element.ALIGN_CENTER);
		cella4.setPadding(5);
		tabledata41.addCell(cellc4);

		Paragraph d4 = new Paragraph("Name", fontTableHeadingSubMainHead_2);
		PdfPCell celld4 = new PdfPCell(d4);
		celld4.setHorizontalAlignment(Element.ALIGN_CENTER);
		cella4.setPadding(5);
		tabledata41.addCell(celld4);

		Paragraph e4 = new Paragraph("Arm/Service", fontTableHeadingSubMainHead_2);
		PdfPCell celle4 = new PdfPCell(e4);
		celle4.setHorizontalAlignment(Element.ALIGN_CENTER);
		cella4.setPadding(5);
		tabledata41.addCell(celle4);

		PdfPTable tableMeargeF = new PdfPTable(2);
		tableMeargeF.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableMeargeF.setWidthPercentage(100);
		tableMeargeF.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableMeargeF.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
		tableMeargeF.setHeaderRows(1);

		PdfPTable tableHeaderFLeft = new PdfPTable(5);
		tableHeaderFLeft.setWidths(new int[] { 2, 4, 3, 10, 5 });
		tableHeaderFLeft.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableHeaderFLeft.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableHeaderFLeft.setWidthPercentage(100);

		PdfPTable tableHeaderFRight = new PdfPTable(5);
		tableHeaderFRight.setWidths(new int[] { 2, 4, 3, 10, 5 });
		tableHeaderFRight.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableHeaderFRight.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableHeaderFRight.setWidthPercentage(100);

		tableHeaderFRight.addCell(cella4);
		tableHeaderFRight.addCell(cellb4);
		tableHeaderFRight.addCell(cellc4);
		tableHeaderFRight.addCell(celld4);
		tableHeaderFRight.addCell(celle4);
		tableHeaderFRight.setHeaderRows(1);
		tableHeaderFRight.setSkipFirstHeader(false);

		tableHeaderFLeft.addCell(cella4);
		tableHeaderFLeft.addCell(cellb4);
		tableHeaderFLeft.addCell(cellc4);
		tableHeaderFLeft.addCell(celld4);
		tableHeaderFLeft.addCell(celle4);
		tableHeaderFLeft.setHeaderRows(1);
		tableHeaderFLeft.setSkipFirstHeader(false);

		tableHeaderFRight.getDefaultCell().setFixedHeight(10f);
		tableHeaderFLeft.getDefaultCell().setFixedHeight(10f);

		PdfPCell full_pass_cell = new PdfPCell(full_pass_heading_paragraph);
		full_pass_cell.setColspan(2);
		full_pass_cell.setBorder(0);
		full_pass_cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		tableMeargeF.addCell(full_pass_cell);

		int flag_first_page = 46;
		int flag_first_page_fix = 46;

		for (int i = 0; i < fullypassed.size(); i++) {
			// if(i > 45){ flag_first_page_fix = 66;}

			List<String> l = fullypassed.get(i);
			PdfPCell celle_fl = new PdfPCell();
			if (flag_first_page > (flag_first_page_fix / 2) && flag_first_page <= flag_first_page_fix) {
				Paragraph ser_no = new Paragraph(l.get(0), fontTableHeadingdata);
				celle_fl = new PdfPCell(ser_no);
				celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
				celle_fl.setPadding(3);
				if (i % 2 == 0) {
					celle_fl.setBackgroundColor(java.awt.Color.lightGray);
				}
				tableHeaderFRight.addCell(celle_fl);
				Paragraph ic_number = new Paragraph(l.get(1), fontTableHeadingdata);
				celle_fl = new PdfPCell(ic_number);
				celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
				celle_fl.setPadding(3);
				if (i % 2 == 0) {
					celle_fl.setBackgroundColor(java.awt.Color.lightGray);
				}
				tableHeaderFRight.addCell(celle_fl);
				Paragraph rank = new Paragraph(l.get(2), fontTableHeadingdata);
				celle_fl = new PdfPCell(rank);
				celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
				celle_fl.setPadding(3);
				if (i % 2 == 0) {
					celle_fl.setBackgroundColor(java.awt.Color.lightGray);
				}
				tableHeaderFRight.addCell(celle_fl);
				Paragraph pers_name = new Paragraph(l.get(3), fontTableHeadingdata);
				celle_fl = new PdfPCell(pers_name);
				celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
				celle_fl.setPadding(3);
				if (i % 2 == 0) {
					celle_fl.setBackgroundColor(java.awt.Color.lightGray);
				}
				tableHeaderFRight.addCell(celle_fl);
				Paragraph arm = new Paragraph(l.get(4), fontTableHeadingdata);
				celle_fl = new PdfPCell(arm);
				celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
				celle_fl.setPadding(3);
				if (i % 2 == 0) {
					celle_fl.setBackgroundColor(java.awt.Color.lightGray);
				}
				tableHeaderFRight.addCell(celle_fl);
			}
			if (flag_first_page > (flag_first_page_fix - flag_first_page_fix)
					&& flag_first_page <= (flag_first_page_fix / 2)) {
				Paragraph ser_no = new Paragraph(l.get(0), fontTableHeadingdata);
				celle_fl = new PdfPCell(ser_no);
				celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
				celle_fl.setPadding(3);
				if (i % 2 == 0) {
					celle_fl.setBackgroundColor(java.awt.Color.lightGray);
				}
				tableHeaderFLeft.addCell(celle_fl);
				Paragraph ic_number = new Paragraph(l.get(1), fontTableHeadingdata);
				celle_fl = new PdfPCell(ic_number);
				celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
				celle_fl.setPadding(3);
				if (i % 2 == 0) {
					celle_fl.setBackgroundColor(java.awt.Color.lightGray);
				}
				tableHeaderFLeft.addCell(celle_fl);
				Paragraph rank = new Paragraph(l.get(2), fontTableHeadingdata);
				celle_fl = new PdfPCell(rank);
				celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
				celle_fl.setPadding(3);
				if (i % 2 == 0) {
					celle_fl.setBackgroundColor(java.awt.Color.lightGray);
				}
				tableHeaderFLeft.addCell(celle_fl);
				Paragraph pers_name = new Paragraph(l.get(3), fontTableHeadingdata);
				celle_fl = new PdfPCell(pers_name);
				celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
				celle_fl.setPadding(3);
				if (i % 2 == 0) {
					celle_fl.setBackgroundColor(java.awt.Color.lightGray);
				}
				tableHeaderFLeft.addCell(celle_fl);
				Paragraph arm = new Paragraph(l.get(4), fontTableHeadingdata);
				celle_fl = new PdfPCell(arm);
				celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
				celle_fl.setPadding(3);
				if (i % 2 == 0) {
					celle_fl.setBackgroundColor(java.awt.Color.lightGray);
				}
				tableHeaderFLeft.addCell(celle_fl);

			}
			if (flag_first_page == ((flag_first_page_fix / 2) + 1)) {
				tableMeargeF.addCell(tableHeaderFRight);
				tableHeaderFRight = new PdfPTable(5);
				tableHeaderFRight.setWidths(new int[] { 2, 4, 3, 10, 5 });
				tableHeaderFRight.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				tableHeaderFRight.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
				tableHeaderFRight.setWidthPercentage(100);
				tableHeaderFRight.addCell(cella4);
				tableHeaderFRight.addCell(cellb4);
				tableHeaderFRight.addCell(cellc4);
				tableHeaderFRight.addCell(celld4);
				tableHeaderFRight.addCell(celle4);
				tableHeaderFRight.setHeaderRows(1);
				tableHeaderFRight.setSkipFirstHeader(false);
				tableHeaderFRight.getDefaultCell().setFixedHeight(10f);

			}
			if (flag_first_page == ((flag_first_page_fix - flag_first_page_fix) + 1)) {
				tableMeargeF.addCell(tableHeaderFLeft);
				tableHeaderFLeft = new PdfPTable(5);
				tableHeaderFLeft.setWidths(new int[] { 2, 4, 3, 10, 5 });
				tableHeaderFLeft.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				tableHeaderFLeft.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
				tableHeaderFLeft.setWidthPercentage(100);
				tableHeaderFLeft.addCell(cella4);
				tableHeaderFLeft.addCell(cellb4);
				tableHeaderFLeft.addCell(cellc4);
				tableHeaderFLeft.addCell(celld4);
				tableHeaderFLeft.addCell(celle4);
				tableHeaderFLeft.setHeaderRows(1);
				tableHeaderFLeft.setSkipFirstHeader(false);
				tableHeaderFLeft.getDefaultCell().setFixedHeight(10f);
			}

			if (fullypassed.size() == (i + 1) & flag_first_page > ((flag_first_page_fix / 2) + 1)) {
				tableMeargeF.addCell(tableHeaderFRight);
				tableMeargeF.addCell(tableHeaderFLeft);
				tableHeaderFRight = new PdfPTable(5);
				tableHeaderFRight.setWidths(new int[] { 2, 4, 3, 10, 5 });
				tableHeaderFRight.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				tableHeaderFRight.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
				tableHeaderFRight.setWidthPercentage(100);
				tableHeaderFRight.addCell(cella4);
				tableHeaderFRight.addCell(cellb4);
				tableHeaderFRight.addCell(cellc4);
				tableHeaderFRight.addCell(celld4);
				tableHeaderFRight.addCell(celle4);
				tableHeaderFRight.setHeaderRows(1);
				tableHeaderFRight.setSkipFirstHeader(false);
				tableHeaderFRight.getDefaultCell().setFixedHeight(10f);
			}
			if (fullypassed.size() == (i + 1) & flag_first_page > (flag_first_page_fix - flag_first_page_fix)
					& flag_first_page < ((flag_first_page_fix / 2) + 1)) {
				tableMeargeF.addCell(tableHeaderFLeft);
				tableHeaderFLeft = new PdfPTable(5);
				tableHeaderFLeft.setWidths(new int[] { 2, 4, 3, 10, 5 });
				tableHeaderFLeft.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				tableHeaderFLeft.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
				tableHeaderFLeft.setWidthPercentage(100);
				tableHeaderFLeft.addCell(cella4);
				tableHeaderFLeft.addCell(cellb4);
				tableHeaderFLeft.addCell(cellc4);
				tableHeaderFLeft.addCell(celld4);
				tableHeaderFLeft.addCell(celle4);
				tableHeaderFLeft.setHeaderRows(1);
				tableHeaderFLeft.setSkipFirstHeader(false);
				tableHeaderFLeft.getDefaultCell().setFixedHeight(10f);
			}
			flag_first_page -= 1;
			if (flag_first_page == 0) {
				flag_first_page_fix = 60;
				flag_first_page = flag_first_page_fix;
			}
		}
		/*
		 * if((fullypassed.size()%46) != 0){ tableMeargeF.addCell(tableHeaderFRight);
		 * tableMeargeF.addCell(tableHeaderFLeft); }
		 */

		PdfPCell cell1236_f;
		cell1236_f = new PdfPCell();
		cell1236_f.setPaddingLeft(30f);
		cell1236_f.setPaddingRight(30f);
		cell1236_f.addElement(tabledata4);
		cell1236_f.addElement(new Paragraph("\n"));
		cell1236_f.addElement(tableheader4);
		cell1236_f.addElement(tableMeargeF);
		cell1236_f.setBorder(0);
		table4.addCell(cell1236_f);
//		table4.getDefaultCell().setPaddingRight(50f);
		// writeFooterTable(arg2,document,table4);

//===================Partially-Passed=========================//	
		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();

		PdfPTable table6 = new PdfPTable(1);
		table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table6.setWidthPercentage(100);

		PdfPTable tabledata6 = new PdfPTable(1);
		tabledata6.setWidths(new int[] { 7 });
		tabledata6.setWidthPercentage(100 / 3f);
		tabledata6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata6.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata6.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head6 = new Paragraph("Appendix 'C'", fontTableHeadingMainHead_l);
		Paragraph head61 = new Paragraph("(Refers to Para 1(c) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head63 = new Paragraph("letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head64 = new Paragraph("dated    " + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata6.addCell(head6);
		tabledata6.addCell(head61);
		tabledata6.addCell(head63);
		tabledata6.addCell(head64);

		Chunk army_training_command_heading2 = new Chunk("ARMY TRAINING COMMAND (EXAM SEC)",
				fontTableHeadingSubMainHead);
		army_training_command_heading2.setUnderline(0.1f, -2f);
		Paragraph army_training_command_paragraph2 = new Paragraph(army_training_command_heading2);
		army_training_command_paragraph2.setFont(fontTableHeading1);
		army_training_command_paragraph2.setAlignment(Element.ALIGN_CENTER);
		

		Chunk part_pass_heading2 = new Chunk(
				"\n" +"PROMOTION EXAMINATION PART B (ONLINE) - " + es_year + "\n\n" + "RESULTS - PART PASSED & FAILURES \n\n",
				fontTableHeadingSubMainHead);
		part_pass_heading2.setUnderline(0.1f, -2f);
		Paragraph part_pass_heading_paragraph = new Paragraph(part_pass_heading2);
		part_pass_heading_paragraph.setFont(fontTableHeading1);
		part_pass_heading_paragraph.setAlignment(Element.ALIGN_CENTER);

		PdfPTable tableheader6 = new PdfPTable(1);
		tableheader6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader6.setWidthPercentage(100);
		tableheader6.setHeaderRows(1);
		tableheader6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader6.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader6.addCell(army_training_command_paragraph2);

		PdfPTable tabledata61_h = new PdfPTable(1);
		tabledata61_h.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tabledata61_h.setWidthPercentage(100);
		tabledata61_h.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata61_h.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata61_h.setHeaderRows(1);
		tabledata61_h.getDefaultCell().setFixedHeight(10f);

		PdfPTable tabledata61 = new PdfPTable(12);
		tabledata61.setWidths(new int[] { 2, 3, 2, 12, 4, 3, 3, 3, 3, 3, 3, 3 });
		tabledata61.setWidthPercentage(100);
		tabledata61.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata61.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);

		PdfPCell part_pass_cell = new PdfPCell(part_pass_heading_paragraph);
		part_pass_cell.setBorder(0);
		part_pass_cell.setColspan(12);
		part_pass_cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata61.addCell(part_pass_cell);

		ArrayList<List<String>> partially_passed = (ArrayList<List<String>>) model.get("partially_passed");

		Paragraph a6 = new Paragraph("Ser    No", fontTableHeadingSubMainHead_2);
		Paragraph b6 = new Paragraph("Personal No ", fontTableHeadingSubMainHead_2);
		Paragraph c6 = new Paragraph("Rank", fontTableHeadingSubMainHead_2);
		Paragraph d6 = new Paragraph("Name", fontTableHeadingSubMainHead_2);
		Paragraph e6 = new Paragraph("Arm/Service", fontTableHeadingSubMainHead_2);
		Paragraph f6 = new Paragraph("A", fontTableHeadingSubMainHead_2);
		Paragraph g6 = new Paragraph("L", fontTableHeadingSubMainHead_2);
		Paragraph h6 = new Paragraph("H", fontTableHeadingSubMainHead_2);
		Paragraph i6 = new Paragraph("C", fontTableHeadingSubMainHead_2);
		Paragraph j6 = new Paragraph("T", fontTableHeadingSubMainHead_2);
		Paragraph k6 = new Paragraph("Yet To Pass", fontTableHeadingSubMainHead_2);
		Paragraph l6 = new Paragraph("Personal No ", fontTableHeadingSubMainHead_2);

		tabledata61.addCell(a6);
		tabledata61.addCell(b6);
		tabledata61.addCell(c6);
		tabledata61.addCell(d6);
		tabledata61.addCell(e6);
		tabledata61.addCell(f6);
		tabledata61.addCell(g6);
		tabledata61.addCell(h6);
		tabledata61.addCell(i6);
		tabledata61.addCell(j6);
		tabledata61.addCell(k6);
		tabledata61.addCell(l6);

		// data bind
		int index6 = 1;

		tabledata61.setHeaderRows(2);
		tabledata61.setSkipFirstHeader(false);

		for (int i3 = 0; i3 < partially_passed.size(); i3++) {

			List<String> l3 = partially_passed.get(i3);
			StringBuilder input1 = new StringBuilder();
			input1.append(l3.get(10));
			input1.reverse();
			Paragraph a1index = new Paragraph(String.valueOf(index6), fontTableHeadingdata);
			Paragraph a611 = new Paragraph(l3.get(1), fontTableHeadingdata);
			Paragraph b612 = new Paragraph(l3.get(2), fontTableHeadingdata);
			Paragraph c613 = new Paragraph(l3.get(3), fontTableHeadingdata);
			Paragraph d614 = new Paragraph(l3.get(4), fontTableHeadingdata);
			Paragraph e615 = new Paragraph(l3.get(5), fontTableHeadingdata);
			Paragraph f616 = new Paragraph(l3.get(6), fontTableHeadingdata);
			Paragraph g617 = new Paragraph(l3.get(7), fontTableHeadingdata);
			Paragraph h618 = new Paragraph(l3.get(8), fontTableHeadingdata);
			Paragraph i619 = new Paragraph(l3.get(9), fontTableHeadingdata);
			Paragraph j620 = new Paragraph(input1.toString(), fontTableHeadingdata);
			Paragraph k621 = new Paragraph(l3.get(1), fontTableHeadingdata);

			PdfPCell cell2_pp = new PdfPCell();
			if (i3 % 2 == 0) {
				cell2_pp.setBackgroundColor(java.awt.Color.lightGray);
			}
			cell2_pp.setPhrase(a1index);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cell2_pp);
			cell2_pp.setPhrase(a611);
			tabledata61.addCell(cell2_pp);
			cell2_pp.setPhrase(b612);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cell2_pp);
			cell2_pp.setPhrase(c613);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata61.addCell(cell2_pp);
			cell2_pp.setPhrase(d614);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cell2_pp);
			cell2_pp.setPhrase(e615);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cell2_pp);
			cell2_pp.setPhrase(f616);
			tabledata61.addCell(cell2_pp);
			cell2_pp.setPhrase(g617);

			tabledata61.addCell(cell2_pp);
			cell2_pp.setPhrase(h618);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cell2_pp);
			cell2_pp.setPhrase(i619);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cell2_pp);
			cell2_pp.setPhrase(j620);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cell2_pp);
			cell2_pp.setPhrase(k621);
			cell2_pp.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata61.addCell(cell2_pp);
			tabledata61.getDefaultCell().setFixedHeight(15f);
			tabledata61.getDefaultCell().setPadding(20f);
			index6 += 1;
			// tabledata61_h.addCell(tabledata61);
		}

		PdfPCell cell1236;
		cell1236 = new PdfPCell();
		cell1236.setPaddingLeft(30f);
		cell1236.setPaddingRight(30f);
		cell1236.addElement(tabledata6);
		cell1236.addElement(tableheader6);
		cell1236.addElement(tabledata61);
		cell1236.setBorder(0);
		cell1236.setPaddingBottom(25f);
		table6.addCell(cell1236);

		PdfPCell cell_footer_prt = new PdfPCell();
		cell_footer_prt.setVerticalAlignment(Element.ALIGN_BOTTOM);
		cell_footer_prt.setBorder(0);
		cell_footer_prt.addElement(tabledataend);
//		table6.getDefaultCell().setBottom(0);
		table6.getDefaultCell().setPaddingBottom(25f);
		table6.addCell(cell_footer_prt);
		

		// =================Absentees ===================//

		document.setPageSize(two);
		document.setMargins(20, 60, 20, 20);
		document.newPage();
		

		PdfPTable table_ab = new PdfPTable(1);
		table_ab.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_ab.setWidthPercentage(100);

		PdfPTable tabledata7 = new PdfPTable(1);
		tabledata7.setWidths(new int[] { 7 });
		tabledata7.setWidthPercentage(100 / 3f);
		tabledata7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata7.setHorizontalAlignment(Element.ALIGN_RIGHT);
		tabledata7.getDefaultCell().setBorder(Rectangle.NO_BORDER);

		Paragraph head7 = new Paragraph("Appendix 'D'", fontTableHeadingMainHead_l);
		Paragraph head71 = new Paragraph("(Refers to Para 1(d) of HQ ARTRAC Exam Sec", fontTableHeadingMainHead_l);
		Paragraph head73 = new Paragraph("letter No:" + letter_no, fontTableHeadingMainHead_l);
		Paragraph head74 = new Paragraph("dated    " + letter_date1 + ")", fontTableHeadingMainHead_l);

		tabledata7.addCell(head7);
		tabledata7.addCell(head71);
		tabledata7.addCell(head73);
		tabledata7.addCell(head74);

		Chunk chunk7 = new Chunk();

		Chunk glue7 = new Chunk(new VerticalPositionMark());

		Chunk underline7 = new Chunk("ARMY TRAINING COMMAND (EXAM SEC) \n" + "\n" + "PROMOTION EXAMINATION PART B (ONLINE) - "
				+ es_year + "" + "\n\n" + "ABSENTEE LIST", fontTableHeadingMainHead);

		underline7.setUnderline(0.1f, -2f);
		
		Phrase ph7 = new Phrase(underline7);
		ph7.setFont(fontTableHeading1);
		ph7.add("\n");
		ph7.add("\n");
		Paragraph cell7 = new Paragraph(ph7);
		cell7.setAlignment(Element.ALIGN_LEFT);

		PdfPTable tableheader_ab = new PdfPTable(1);
		tableheader_ab.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader_ab.setWidthPercentage(100);
		tableheader_ab.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader_ab.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader_ab.addCell(cell7);

		PdfPTable tabledata_ab = new PdfPTable(4);
		tabledata_ab.setWidths(new int[] { 1, 1, 5, 1 });
		tabledata_ab.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata_ab.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata_ab.setWidthPercentage(50);

		ArrayList<List<String>> absentees = (ArrayList<List<String>>) model.get("absentees");

		Paragraph a_ab = new Paragraph("Ser No", fontTableHeadingSubMainHead_2);
		Paragraph b_ab = new Paragraph("Candidate Details", fontTableHeadingSubMainHead_2);
		Paragraph f_ab = new Paragraph("Subjects", fontTableHeadingSubMainHead_2);

		PdfPCell blank_cell_ab;
		blank_cell_ab = new PdfPCell(a_ab);
		blank_cell_ab.setRowspan(2);
		blank_cell_ab.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellb_ab;
		blank_cellb_ab = new PdfPCell(b_ab);
		blank_cellb_ab.setColspan(2);
		blank_cellb_ab.setHorizontalAlignment(Element.ALIGN_CENTER);

		PdfPCell blank_cellc_ab;
		blank_cellc_ab = new PdfPCell(f_ab);
		blank_cellc_ab.setRowspan(2);
		blank_cellc_ab.setHorizontalAlignment(Element.ALIGN_CENTER);

		tabledata_ab.addCell(blank_cell_ab);
		tabledata_ab.addCell(blank_cellb_ab);
		tabledata_ab.addCell(blank_cellc_ab);

		Paragraph F2_ab = new Paragraph("Personal No", fontTableHeadingSubMainHead_2);
		Paragraph G2_ab = new Paragraph("Rk & Name", fontTableHeadingSubMainHead_2);

		tabledata_ab.addCell(F2_ab);
//		tabledata_ab.getDefaultCell().setPaddingRight(50f);
		tabledata_ab.addCell(G2_ab);

		// data bind
		int index_ab = 1;
		for (int i7 = 0; i7 < absentees.size(); i7++) {
//			
			List<String> l = absentees.get(i7);
			Paragraph a1index_abs = new Paragraph(String.valueOf(index_ab), fontTableHeadingdata);
			Paragraph pers_code_abs = new Paragraph(l.get(0), fontTableHeadingdata);
			Paragraph rank_abs = new Paragraph(l.get(1), fontTableHeadingdata);
			Paragraph subject_abs = new Paragraph(l.get(2), fontTableHeadingdata);

			PdfPCell cell_abs = new PdfPCell();
			if (index_ab % 2 == 0) {
				cell_abs.setBackgroundColor(java.awt.Color.lightGray);
			}
			cell_abs.setPhrase(a1index_abs);
			cell_abs.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata_ab.addCell(cell_abs);
			cell_abs.setPhrase(pers_code_abs);
			tabledata_ab.addCell(cell_abs);
			cell_abs.setPhrase(rank_abs);
			cell_abs.setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata_ab.addCell(cell_abs);
			cell_abs.setPhrase(subject_abs);
			cell_abs.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata_ab.addCell(cell_abs);

			index_ab += 1;

		}

		PdfPCell cell123_ab;
		cell123_ab = new PdfPCell();
		cell123_ab.setPaddingLeft(30f);
		cell123_ab.setPaddingRight(30f);
		cell123_ab.addElement(new Paragraph("\n"));
		cell123_ab.addElement(new Paragraph("\n"));
		cell123_ab.addElement(tabledata7);

		cell123_ab.addElement(tableheader_ab);
		cell123_ab.addElement(tabledata_ab);
		cell123_ab.addElement(new Paragraph("\n"));
		cell123_ab.setBorder(0);
		table_ab.addCell(cell123_ab);

		PageNumeration event = new PageNumeration(arg2);
		arg2.setPageEvent(event);
		document.setPageCount(1);

		document.add(table_m1);

		document.add(table_c2);
		document.add(table_c3);

		table.setTableEvent(new ImageBackgroundEvent("table", ""));
		document.add(table);

		table1.setTableEvent(new ImageBackgroundEvent("table1", ""));
		document.add(table1);
		table3.setTableEvent(new ImageBackgroundEvent("table3", ""));
		document.add(table3);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table4.setTableEvent(new ImageBackgroundEvent("table4", ""));
		document.add(table4);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table6.setTableEvent(new ImageBackgroundEvent("table6", ""));
		document.add(table6);
		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		table_ab.setTableEvent(new ImageBackgroundEvent("table_ab", ""));
		document.add(table_ab);

		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		// ============Index-page1=======================//
		document.setPageSize(two);
		document.setMargins(20, 20, 20, 20);
		document.newPage();
		
		PdfPTable table_m2 = new PdfPTable(1);
		table_m2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table_m2.setWidthPercentage(100);

		Chunk underline_m11 = new Chunk("INDEX \n", fontTableHeading2);

		underline_m11.setUnderline(0.1f, -2f);
		Phrase ph_m51 = new Phrase(underline_m11);
		ph_m51.setFont(fontTableHeading2);
		Paragraph cell_Mr_I = new Paragraph(ph_m51);
		cell_Mr_I.setAlignment(Element.ALIGN_CENTER);

		PdfPTable table153 = new PdfPTable(4);
		table153.setWidths(new int[] { 20, 80, 20, 20 });
		table153.getDefaultCell().setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
		table153.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		table153.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table153.setWidthPercentage(100);
		table153.setSpacingBefore(5);

		table153.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		table153.addCell("Ser No \n");
		table153.addCell("Result");

		table153.getDefaultCell().setColspan(2);
		table153.addCell("Page No");
		table153.getDefaultCell().setColspan(1);

		table153.addCell("");
		table153.addCell("");
		table153.addCell("From");
		table153.addCell("To");

		table153.addCell("1.");
		table153.addCell("Covering letter Promotion Exam Part B (Online) " + b_month2 + " " + "-" + " " + e_month2 + " "
				+ year2 + "");
		table153.addCell("1");
		table153.addCell("2");

		table153.addCell("2.");
		table153.addCell("Appx ‘A’. Analysis of results.");
		table153.addCell(String.valueOf(table_from));
		table153.addCell(String.valueOf(table_to3));

		table153.addCell("3.");
		table153.addCell("Appx ‘B’. Offrs who have fully passed the exam (listed \n" + "in order of Pers No) \n :-"
				+ "(a) Offrs with IC Nos  \n" + "(b) Offs with SC Nos  \n" + "(c) Offrs with SS Nos \n"
				+ "(d)  Offrs with WS Nos \n");
		table153.addCell(String.valueOf(table_from4));
		table153.addCell(String.valueOf(table_to4));

		table153.addCell("4.");
		table153.addCell("Appx ‘C’. Name of failures and partially passed offrs who.\n"
				+ "have not yet passed the whole exam :-\n" + "\n" + "(a) Offs with IC Nos\n" + "\n"
				+ "(b)  Offrs with SC Nos\n" + "\n" + "(c) Offrs with SS Nos");
		table153.addCell(String.valueOf(table_from6));
		table153.addCell(String.valueOf(table_to6));

		table153.addCell("5.");
		table153.addCell("Appx ’D’. Absentees.");
		table153.addCell(String.valueOf(table_from_ab));
		table153.addCell(String.valueOf(table_from_ab));

		PdfPCell cell_i1;
		cell_i1 = new PdfPCell();
		cell_i1.setPaddingLeft(30f);
		cell_i1.setPaddingRight(30f);
		cell_i1.addElement(cell_Mr_I);
		cell_i1.addElement(new Paragraph("\n"));
		cell_i1.addElement(table153);
		cell_i1.setBorder(0);
		table_m2.addCell(cell_i1);

		document.add(table_m2);

		super.buildPdfMetadata(model, document, request);
	}

	public String getSpace(int no) {
		String space = "";
		if (no == 1) {
			space = " ";
		}
		if (no == 2) {
			space = "  ";
		}
		if (no == 3) {
			space = "   ";
		}
		if (no == 4) {
			space = "    ";
		}
		if (no == 5) {
			space = "     ";
		}
		if (no == 6) {
			space = "      ";
		}
		if (no == 7) {
			space = "       ";
		}
		if (no == 8) {
			space = "        ";
		}
		if (no == 9) {
			space = "          ";
		}
		if (no == 10) {
			space = "           ";
		}
		if (no == 11) {
			space = "           ";
		}
		if (no == 12) {
			space = "            ";
		}
		if (no == 13) {
			space = "             ";
		}
		if (no == 14) {
			space = "              ";
		}
		if (no == 15) {
			space = "               ";
		}
		if (no == 16) {
			space = "                ";
		}
		if (no == 17) {
			space = "                 ";
		}
		if (no == 18) {
			space = "                  ";
		}
		if (no == 19) {
			space = "                   ";
		}
		if (no == 20) {
			space = "                    ";
		}
		return space;
	}

	String pagNum = "";

	class PageNumeration extends PdfPageEventHelper {
		PdfTemplate total;
		PdfTemplate total1;

		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				total1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {

		}

		public void onEndPage(PdfWriter writer, Document document) {
			
			Font pgNo = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 0);
			
			PdfPTable table = new PdfPTable(1);
			try {

				table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
//				table.getDefaultCell().setPaddingLeft(20f);
				
				
				if ((writer.getPageNumber() - 2) > 0) {
					pagNum = String.valueOf((writer.getPageNumber() - 1));
				}

				PdfPCell cell1 = new PdfPCell(new Paragraph(pagNum,pgNo));
				cell1.setPaddingLeft(30f);
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_TOP);
				table.addCell(cell1);

				table.writeSelectedRows(0, -1, document.leftMargin() + 360, document.topMargin() + 565,
						writer.getDirectContent());
				Font fontTableHeadingdataforFooter = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 0);
				PdfContentByte cb = writer.getDirectContent();

				table.writeSelectedRows(0, -1, document.leftMargin() + 360, document.topMargin() + 565,
						writer.getDirectContent());
//				if (page >= 4 & page <= 6) {
//					ColumnText.showTextAligned(cb, Element.ALIGN_LEFT,
//							new Phrase(String.format("Appd : Appeared", writer.getPageNumber()),
//									fontTableHeadingdataforFooter),
//							document.left(), document.bottom(), 0);
//				}
				
				if (page >= 4 & page <= 6) {
					ColumnText.showTextAligned(cb, Element.ALIGN_LEFT,
							new Phrase(String.format("Appd : Appeared", writer.getPageNumber()),
									fontTableHeadingdataforFooter),
							(document.left() +30f), document.bottom(), 0);
				}
				
				
				
//				 table_from6 <= table_to6

//				 if(page >= table_from6 & page <=table_to6 ) {
//					 
//					 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("hiiiiii", writer.getPageNumber()),fontTableHeadingdataforFooter),document.left(),document.bottom(), 0);
//				 }
//				
				int rtable_from = table_from4 + 1;
				int rtable_to = table_to4;

				if (page > rtable_from && table_from4 != 0 && rtable_to <= page && table_from6 < rtable_to) {
					Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
					ColumnText.showTextAligned(cb, Element.ALIGN_LEFT,
							new Phrase(String.format("Appendix 'B' Contd.../- "), fontTableHeadingMainHead_l),
							document.right() - 150, document.top(), 0);
				}
				int ftable_from = table_from6 + 1;
				int ftable_to = table_to6;

				if (page > ftable_from && table_from6 != 0 && ftable_to <= page && table_from_ab < ftable_to) {
					Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
					ColumnText.showTextAligned(cb, Element.ALIGN_LEFT,
							new Phrase(String.format("Appendix 'C' Contd.../- "), fontTableHeadingMainHead_l),
							document.right() - 150, document.top(), 0);
				}

				if (page >= ftable_from && table_from6 != 0 && ftable_to <= page && table_from_ab < ftable_to) {
					ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format(
							"A:ADM      L:LAW      H:MIL HISTORY      C:CURRENT AFFAIRS      T:TACTICS      NP:NOW PASSED      PP:PREVIOUSLY PASSED      ABS:ABSENT    UFM:UNFAIR MEANS",
							writer.getPageNumber()), fontTableHeadingdataforFooter), (document.left()+30f), document.bottom(),
							0);
				}

//               if(page >= table_from6 & page <=table_to6 ) {
//					 
//					 ColumnText.showTextAligned(cb, Element.ALIGN_LEFT, new Phrase(String.format("hiiiiii", writer.getPageNumber()),fontTableHeadingdataforFooter),document.left(),document.bottom(), 0);
//				 }
				page++;
				/*
				 * // * if (Integer.parseInt(String.valueOf(writer.getPageNumber())) > 2) {
				 * page++; } //
				 */
			} catch (Exception de) {
				throw new ExceptionConverter(de);
			}
		}

//		public void onCloseDocument(PdfWriter writer, Document document) {
//			
//		}
	}

	int table_from = 0;
	int table_to = 0;

	int table_from1 = 0;
	int table_to1 = 0;

	int table_from3 = 0;
	int table_to3 = 0;

	int table_from4 = 0;
	int table_to4 = 0;

	int table_from6 = 0;
	int table_to6 = 0;

	int table_from_ab = 0;
	int table_to_ab = 0;

	int table_from5 = 0;
	int table_to5 = 0;

	class ImageBackgroundEvent implements PdfPTableEvent {
		protected Image image;
		String tableName;
		String val;

		ImageBackgroundEvent(String tableName, String val) {
			this.tableName = tableName;
			this.val = val;
		}

		public void tableLayout(PdfPTable table, float[][] widths, float[] heights, int headerRows, int rowStart,
				PdfContentByte[] canvases) {

			if (tableName.equals("table") && table_from == 0) {
				table_from = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table")) {
				table_to = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table1") && table_from1 == 0) {
				table_from1 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table1")) {
				table_to1 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table3") && table_from3 == 0) {
				table_from3 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table3")) {
				table_to3 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table4") && table_from4 == 0) {
				table_from4 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table4")) {
				table_to4 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table6") && table_from6 == 0) {
				table_from6 = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table6")) {
				table_to6 = Integer.parseInt(pagNum) + 1;
			}

			if (tableName.equals("table_ab") && table_from_ab == 0) {
				table_from_ab = Integer.parseInt(pagNum) + 1;
			}
			if (tableName.equals("table_ab")) {
				table_to_ab = Integer.parseInt(pagNum) + 1;
			}

		}
	}

}