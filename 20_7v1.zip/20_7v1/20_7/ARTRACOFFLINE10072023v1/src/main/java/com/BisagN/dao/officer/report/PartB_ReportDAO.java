package com.BisagN.dao.officer.report;

import java.util.ArrayList;

public interface PartB_ReportDAO {

	public ArrayList<ArrayList<String>> getFullyPassedForPartB(int es_id, String oa_application_id);

	public ArrayList<ArrayList<String>> getdetailsResultWithHeld(int es_id, int oapp_id);

	public ArrayList<ArrayList<String>> getArmsubsummaryresult(int es_id);

	public ArrayList<ArrayList<String>> getArmServiceAnalysisResultsPartB(int es_id, String es_year);

	public ArrayList<ArrayList<String>> getCommandAnalysisResultsPartB(int es_id, String es_year);

//	public ArrayList<ArrayList<String>> CandidateZeroMarksDetails(int es_id) ;
	public ArrayList<ArrayList<String>> Candidate25PersmarksDetails(int es_id, String f_percntg1, String t_percntg1,
			String marks1, String subject_id1);

	public ArrayList<ArrayList<String>> IndexagainstPersAndname(int es_id);

	public ArrayList<ArrayList<String>> IndexagainstmarksObtained(int es_id, int subject_id1);

	public ArrayList<ArrayList<String>> getPartPassedandFailures(String es_year,String oa_application_id);

	public ArrayList<ArrayList<String>> IndexagainstPersonNo(int es_id, int centre_id);

	public ArrayList<ArrayList<String>> ChanceWisAnalysisReport(String fr_chnace1, String t_chnace1);

	public ArrayList<ArrayList<String>> PartAbsentees(int es_id);

	public ArrayList<ArrayList<String>> CenterWiseListOfSubject(int es_id, int sub_id, int centre_id);

	public ArrayList<ArrayList<String>> SummaryPartB(int es_id,int exam_id);

	public ArrayList<ArrayList<String>> ResultApprovalSheet(String es_year);

	public ArrayList<ArrayList<String>> getparamountcardlist(int ec_exam_id2);
	
//	public ArrayList<ArrayList<String>> getdetailsResultWithHeld(int es_id, int oapp_id);

}
