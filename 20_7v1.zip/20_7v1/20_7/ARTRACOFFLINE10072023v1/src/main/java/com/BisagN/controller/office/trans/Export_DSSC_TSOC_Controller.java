package com.BisagN.controller.office.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.officer.trans.Dssc_tsoc_applicationDAO;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.PARTB_D_APPLICATION_M;
import com.BisagN.models.officers.trans.DSSC_ADMIT_CARD_TBL;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Export_DSSC_TSOC_Controller {
	
	@Autowired 
	Dssc_tsoc_applicationDAO dsscDao;
	
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	

	@Autowired
	CommonController comm;

	
	@RequestMapping(value = "ExportDssctoscUrl", method = RequestMethod.GET)
	public ModelAndView ExportDssctoscUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		
		String es_begindate = session.getAttribute("es_begin_date") == null ? ""
				: session.getAttribute("es_begin_date").toString();
		
		String es_begin_dateshow = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();
		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		
	
		int ec_exam_id = session.getAttribute("ec_exam_id") ==null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			System.err.println("es_begin_dateshow============="+es_begin_dateshow);
		if (ec_exam_id == 3) {
			if (!es_begin_dateshow.equals("")) {
				Mmap.put("dssc_showbegindate", es_begin_dateshow);
			}
			
			 if(!es_begindate.equals("")) {
					
				 Mmap.put("dssc_begindate", es_begindate.substring(0, 10));
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
				List<EXAM_SCHEDULE>getDsscDate=comm.getUnlockExamSchedule (sessionFactory,es_id);
			
				 Mmap.put("dssc_Checkbegindate", getDsscDate.get(0).getEs_dssc_check_year());
			}
			if (ec_exam_id != 0) {
				Mmap.put("ec_exam_id", ec_exam_id);
			}
		}
	
		Mmap.put("msg", msg);
		return new ModelAndView("ExportDssc_Tsoc_tile");
	}
	
	
	// Download DEMO EXCEL
		@RequestMapping(value = "/ExportDssc", method = RequestMethod.POST)
		public ModelAndView ExportDssc(HttpServletRequest request, ModelMap model, HttpSession session, String typeReport1,
				String exam_schedule_dt2, String min_year2,
				String es_consider_date3,String btn_value,String es_part_b2,String es_part_d2,String dssc_month2,String dssc_chance2)
				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

			int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			String es_begindate = session.getAttribute("es_begin_date") == null ? ""
					: session.getAttribute("es_begin_date").toString();
			
			String es_year=es_begindate.substring(0, 10);
			if (es_id != 0) {
				
				 List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
				 String partb_status2=UnlcokExmsch.get(0).getEs_part_b();
				 String partd_status2=UnlcokExmsch.get(0).getEs_part_d();
			ArrayList<ArrayList<String>> exportPartDSSC_DSTSC = dsscDao.getexportDSSCTSOCexmCandidateReport(0, "-1", "", "1", "ASC",
					exam_schedule_dt2, min_year2, es_consider_date3,es_id,"excelL",typeReport1,partb_status2,partd_status2,dssc_month2,dssc_chance2,es_year,session);
		
			
	
			
			if (exportPartDSSC_DSTSC.size() > 0) {	 

			 
			ArrayList<ArrayList<String>> listexport=new ArrayList<ArrayList<String>>();
			List<String> TH = new ArrayList<String>();
			TH.add("AdmiT_Card");
			TH.add("IC_No");
			TH.add("Rk");
			TH.add("Name");
			TH.add("Arms");
			TH.add("DOB");
			TH.add("DOC");
			TH.add("DOS");
			TH.add("Part_D");
			TH.add("Att_no");
			TH.add("ATT_1");
			TH.add("ATT_2");
			
			String Heading = "\n";
			String username = session.getAttribute("username").toString();
			return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList", exportPartDSSC_DSTSC);
			
			}
		

			}
			return null;
		
			
		}	
		
		
		@RequestMapping(value = "/getExportDSSCTSOCReportDataList", method = RequestMethod.POST)
		public @ResponseBody ArrayList<ArrayList<String>> getExportDSSCTSOCReportDataList(int startPage, String pageLength,
				String Search, String orderColunm, String orderType, String exam_schedule_dt, String min_year2,
				String es_consider_date1,String btn_value,String partb_status,String partd_status,String dssc_month,String dssc_chance, HttpSession sessionUserId)
				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
			int ec_exam_id = Integer.parseInt(sessionUserId.getAttribute("ec_exam_id") == null ? "0": sessionUserId.getAttribute("ec_exam_id").toString());
			String es_begindate = sessionUserId.getAttribute("es_begin_date") == null ? ""
					: sessionUserId.getAttribute("es_begin_date").toString();

			String es_year1 = es_begindate.split("-")[0];
			if(ec_exam_id == 3) {
			int es_id = Integer
					.parseInt(sessionUserId.getAttribute("es_id") == null ? "0" : sessionUserId.getAttribute("es_id").toString());
			if (es_id != 0) {

				 List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
				 String partb_status2=UnlcokExmsch.get(0).getEs_part_b();
				 String partd_status2=UnlcokExmsch.get(0).getEs_part_d();
					System.err.println("partd_status2==========="+partd_status2);
				return dsscDao.getexportDSSCTSOCexmCandidateReport(startPage, pageLength, Search, orderColunm, orderType,
						exam_schedule_dt, min_year2, es_consider_date1,es_id,"table", btn_value,partb_status2,partd_status2,dssc_month,dssc_chance,es_year1,sessionUserId);
			}
			
			}
			return null;

		}

		@RequestMapping(value = "/getExportDSSCTSOCTotalCount", method = RequestMethod.POST)
		public @ResponseBody long getExportDSSCTSOCTotalCount(HttpSession sessionUserId, String Search,
				String exam_schedule_dt, String min_year2, String es_consider_date1,String btn_value,String partb_status,String partd_status,String dssc_month,String dssc_chance) {
			
			int ec_exam_id = Integer.parseInt(sessionUserId.getAttribute("ec_exam_id") == null ? "0": sessionUserId.getAttribute("ec_exam_id").toString());
			String es_begindate = sessionUserId.getAttribute("es_begin_date") == null ? ""
					: sessionUserId.getAttribute("es_begin_date").toString();
			String es_year1 = es_begindate.split("-")[0];
			if(ec_exam_id == 3) {
			int es_id = Integer
					.parseInt(sessionUserId.getAttribute("es_id") == null ? "0" : sessionUserId.getAttribute("es_id").toString());
			if (es_id != 0) {
				List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
				 String partb_status2=UnlcokExmsch.get(0).getEs_part_b();
				 String partd_status2=UnlcokExmsch.get(0).getEs_part_d();
				System.err.println("partd_status2==========="+partd_status2);
				return dsscDao.getexportDSSCTSOCCandidatereportTotalCount(Search, exam_schedule_dt, min_year2,
						es_consider_date1,es_id,btn_value,partb_status2,partd_status2,dssc_month,dssc_chance,es_year1);
			}
			
			}
			return 0;

		}
		
		
		@RequestMapping(value = "/ExportDSSCAction", method = RequestMethod.POST)
		public ModelAndView ExportDSSCAction(@ModelAttribute("ExportDSSCcmd") DSSC_ADMIT_CARD_TBL admitcard,
				BindingResult result, HttpServletRequest request, ModelMap model, HttpSession session)
				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			ArrayList<ArrayList<String>> listerror=new ArrayList<ArrayList<String>>();
			
			try {
				Date date = new Date();
				String username1 = session.getAttribute("username").toString();
				int es_id = Integer
						.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
				String exam_schedule_dt2 = request.getParameter("exam_schedule_dt");

				String min_year2 = request.getParameter("min_year_dssc_dos_hid");
				String es_consider_date1 = request.getParameter("es_consider_date");
				
				

				String dssc_month = request.getParameter("es_dssc_month_hid");
				String dssc_chance = request.getParameter("es_dssc_chance_hid");
				String partb_status = request.getParameter("es_part_b");
				String partd_status = request.getParameter("es_part_d");
				
				String es_begindate = session.getAttribute("es_begin_date") == null ? ""
						: session.getAttribute("es_begin_date").toString();

				String es_year1 = es_begindate.split("-")[0];
				List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
				 String partb_status2=UnlcokExmsch.get(0).getEs_part_b();
				 String partd_status2=UnlcokExmsch.get(0).getEs_part_d();
				
				ArrayList<ArrayList<String>> exportDSSC = dsscDao.getexportDSSCTSOCexmCandidateReport(0, "-1", "", "1", "ASC", exam_schedule_dt2, min_year2,
						es_consider_date1,es_id,"","",partb_status2,partd_status2,dssc_month,dssc_chance,es_year1, session);
				
				for (int i = 0; i < exportDSSC.size(); i++) {

					Session sessionHQL1 = this.sessionFactory.openSession();
					Transaction tx1 = sessionHQL1.beginTransaction();
					
					int id = admitcard.getId() > 0 ? admitcard.getId() : 0;
					
					
					String pers_code2 = exportDSSC.get(i).get(10);
					String arm_code = exportDSSC.get(i).get(4);
					String rank = exportDSSC.get(i).get(2);
					String doc = exportDSSC.get(i).get(5);
					String dos = exportDSSC.get(i).get(6);
					String officer_name = exportDSSC.get(i).get(3);
					
					String partd_pass_year = exportDSSC.get(i).get(7);
					String dssc_attmp = exportDSSC.get(i).get(8);
					System.err.println("pers_code2==========="+pers_code2);
//					pers_code2 = pers_code2.substring(0, pers_code2.length() - 1);
					List<OFFICER_PERSONAL_CODE_M> opdpers_id = comm.getopdIdbycode(sessionFactory, pers_code2);
					
			
					int opd_pers_id = opdpers_id.get(0).getOpd_personal_id();
					
					
					
					Query q0 = sessionHQL.createQuery(
							"select count(*) from DSSC_ADMIT_CARD_TBL where (es_id=:es_id and opd_personal_id=:opd_personal_id) and id!=:id");

					q0.setParameter("es_id", es_id);
					q0.setParameter("opd_personal_id", opd_pers_id);
					q0.setParameter("id", id);
						Long c = (Long) q0.uniqueResult();		
						
					if (c == 0) {
						admitcard.setEs_id(es_id);
						admitcard.setOpd_personal_id(opd_pers_id);
						admitcard.setCreated_by(username1);
						admitcard.setCreated_date(date);
						admitcard.setOpd_partdpass_year(Integer.parseInt(partd_pass_year));
						admitcard.setAtt_no(Integer.parseInt(dssc_attmp));
						admitcard.setOpd_arms(arm_code);
						admitcard.setOpd_doc(comm.convertStringToDate(doc));
						admitcard.setOpd_rank(rank);
						admitcard.setOpd_off_name(officer_name);
						admitcard.setOpd_dos(comm.convertStringToDate(dos));
					
						 String Admitcard_no="";
						int i2=1+i;
						 Admitcard_no =es_year1+""+"0000"+""+i2;
							admitcard.setAdmit_card_no(Admitcard_no);
						sessionHQL1.save(admitcard);
						sessionHQL1.flush();
						sessionHQL1.clear();
						tx1.commit();
						sessionHQL1.close();

						model.put("msg", "Data Saved Successfully.");
                       i2++;
					}

					else {

						model.put("msg", "Data already Exist.");
					}

				}
				tx.commit();
			}
			
			catch (RuntimeException e) {
				try {
					tx.rollback();
					model.put("msg", "roll back transaction");
				} catch (RuntimeException rbe) {
					model.put("msg", "Couldn�t roll back transaction " + rbe);
				}
				throw e;
			} finally {
				if (sessionHQL != null) {
					sessionHQL.close();
				}
			}

			return new ModelAndView("redirect:ExportDssctoscUrl");

		}
		
		
}
