package com.BisagN.dao.officer.trans;


import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class Dssc_compens_chanceDAOImpl implements Dssc_compens_chanceDAO {
	@Autowired
         private DataSource dataSource;
//         public void setDataSource(DataSource dataSource) {
//	       this.dataSource = dataSource;
//         }
 HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
 
 CommonController comm= new CommonController();

 @Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

  public boolean checkIsIntegerValue(String Search) {
	return Search.matches("[0-9]+");
}


  public List<Map<String, Object>> getReportListDssc_compens_chance(int startPage,String pageLength,String Search,String orderColunm,String orderType,String pers_no, String pers_name,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		if (!pers_no.equals("")) {
		pers_no=comm.getSearchIcNumberwithoutZero(pers_no);
		 System.err.println("opc_code==========="+pers_no);
			 
	}
		if(pageLength.equals("-1")){
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search, pers_no, pers_name);
System.err.println("pers_no========="+pers_no);
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			q = "select dcc.dcc_id,vpd.opc_personal_code,vpd.opc_suffix_code, vpd.opd_officer_name, vpd.ac_arm_description from vw_personal_details vpd\n"
					+ "inner join dssc_compens_chance_new dcc on dcc.opd_personal_id = vpd.opd_personal_id\n"
					+ "where dcc.dcc_status_id= 1 "+SearchValue+" ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
			PreparedStatement stmt = conn.prepareStatement(q);
			
			
			stmt = setQueryWhereClause_SQL(stmt,Search, pers_no, pers_name);
			ResultSet rs = stmt.executeQuery();
			System.out.println("stmt-------------"+stmt);
			ResultSetMetaData metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();
			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
				    columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
                    String enckey ="commonPwdEncKeys";
	                    Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
	                    String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("dcc_id").toString().getBytes())));
                    String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"+EncryptedPk+"')}else{ return false;}\""; 
                    String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
                    String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('"+EncryptedPk+"')}else{ return false;}\""; 
                    String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>"; 
                    String f = "";

                    String f1 = "";
                    f += updateButton;
//                  f += deleteButton;

                  String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
         			String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));
        			f1 += opc_code;
                    columns.put("action",f);
                    columns.put("opc_code",f1);
                   columns.put(metaData.getColumnLabel(1), f);
			list.add(columns);                 
	}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {
	e.printStackTrace();
} finally {
if (conn != null) {
try {
	conn.close();
} catch (SQLException e) {
}
}
}
return list;
}


public long getReportListDssc_compens_chanceTotalCount(String Search,String pers_no, String pers_name) {
 		String SearchValue = GenerateQueryWhereClause_SQL(Search, pers_no, pers_name);
 		int total = 0;
 		String q = null;
 		Connection conn = null;
 		try {
 			conn = dataSource.getConnection();
 			q ="select count(*) from(select dcc.dcc_id, vpd.opc_personal_code, vpd.opd_officer_name, vpd.ac_arm_description from vw_personal_details vpd\n"
 					+ "inner join dssc_compens_chance_new dcc on dcc.opd_personal_id = vpd.opd_personal_id\n"
 					+ "where dcc.dcc_status_id= 1 "+SearchValue +") ab"   ;
 			PreparedStatement stmt = conn.prepareStatement(q);
 			stmt = setQueryWhereClause_SQL(stmt,Search, pers_no, pers_name);
 			ResultSet rs = stmt.executeQuery();
 			System.err.println("stmt==="+stmt);
 			while (rs.next()) {
 				total = rs.getInt(1);
 			}
  			rs.close();
  			stmt.close();
  			conn.close();
  		} catch (SQLException e) {
  			e.printStackTrace();
  		} finally {
  			if (conn != null) {
  				try {
  					conn.close();
  				} catch (SQLException e) {
  				}
 			}
  		}
  		return (long) total;
  	}


  	public String GenerateQueryWhereClause_SQL(String Search,String pers_no,String pers_name) {
 		String SearchValue ="";
 		
 		if (!pers_no.equals("") && pers_no != "" && pers_no != null) {
 			SearchValue += " and lower(vpd.opc_personal_code) like ?"; 
 		}
 		
 		
 	
 		if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
 			System.out.println("name===="+pers_name);
 			SearchValue += " and lower(vpd.opd_officer_name) like ?"; 
 		}
  		if(!Search.equals("")) {
			Search = Search.toLowerCase();
  			SearchValue =" and ( ";
//  			if(checkIsIntegerValue(Search)) {
//  				SearchValue +=" id=? or ";
//  			}

 			SearchValue +=" lower(vpd.opc_personal_code) like ? or lower(vpd.opd_officer_name) like ? or lower(vpd.ac_arm_description) like ?  )";
 		}
   return SearchValue;
 }


  	public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,String pers_no,String pers_name) {
 		int flag =0;
 		try {
 			
 			System.err.println("pers_no=========="+pers_no);
 			if (!pers_no.equals("") && pers_no != "" && pers_no != null)  {
 				flag += 1;
 				stmt.setString(flag, "%" + pers_no.toLowerCase() + "%");
 			}
 			
 			if (!pers_name.equals("") && pers_name != "" && pers_name != null)  {
 				flag += 1;
 				stmt.setString(flag, "%" + pers_name.toLowerCase() + "%");
 			}
 			
    		if(!Search.equals("")) {
// 				if(checkIsIntegerValue(Search)) {
// 					flag += 1;
// 					stmt.setInt(flag, Integer.parseInt(Search));
// 				}
// 				if(checkIsIntegerValue(Search)) {
// 					flag += 1;
// 					stmt.setInt(flag, Integer.parseInt(Search));
// 				}
 				flag += 1;
 				Search=comm.getSearchIcNumberwithoutZero(Search);
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 				flag += 1;
// 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 				flag += 1;
// 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
// 				flag += 1;
// 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				
 			}
 		}catch (Exception e) {}
 		return stmt;
 	}

   public String Deletedssc_compens_chance(String deleteid,HttpSession session1) {

      	Session session =this.sessionFactory.openSession();
      	Transaction tx = session.beginTransaction();
      	String enckey = "commonPwdEncKeys";
		    String DcryptedPk = hex_asciiDao.decrypt((String) deleteid,enckey,session1);
	      	String hql = "Delete from DSSC_COMPENS_CHANCE_M  where cast(id as string) = :deleteid";
          Query q = session.createQuery(hql).setString("deleteid",DcryptedPk);
      	int rowCount = q.executeUpdate();
      	tx.commit();
          session.close();
	    if(rowCount > 0) {
 			return "Deleted Successfully";
  		}else {
  		return "Deleted not Successfully";
   	}
  	}
   
   
   
 //------------------------------------------------fetch all data in save page=====================================================
   public ArrayList<ArrayList<String>> getAllData(String adv_detail) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			
			q="select TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob, vw.ct_comm_id, vw.ct_comm_type, vw.opd_officer_name,\n"
					+ "TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm ,TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority,\n"
					+ "vw.opd_unit,vw.opd_unit_address2,vw.opc_personal_code,vw.ac_arm_id,vw.ac_arm_description,vw.rc_rank_name,vw.opd_personal_id,\n"
					+ "vw.opd_type_of_entry,ofa.oa_application_id,vw.opd_partd,vw.opd_date_of_seniority as Seniority_date\n"
					+ "from vw_personal_details vw \n"
					+ "left join officer_application ofa on ofa.opd_personal_id = vw.opd_personal_id \n"
					+ "where vw.opc_personal_code=?";

			stmt = conn.prepareStatement(q);
			stmt.setString(1, adv_detail);

			ResultSet rs = stmt.executeQuery();
			System.out.println("stmt----tttt--------"+stmt);
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("opd_dob"));// 0
				list.add(rs.getString("ct_comm_type"));// 1
				list.add(rs.getString("rc_rank_name"));// 2
				list.add(rs.getString("opd_officer_name"));// 3
				list.add(rs.getString("opd_date_of_comm"));// 4
				list.add(rs.getString("opd_date_of_seniority"));// 5
				list.add(rs.getString("ac_arm_description"));// 6
				list.add(rs.getString("opd_unit"));// 7
				list.add(rs.getString("opd_unit_address2"));// 8
				list.add(rs.getString("ac_arm_id"));// 9
				list.add(rs.getString("opd_personal_id"));// 10
				list.add(rs.getString("opd_type_of_entry"));// 11
				list.add(rs.getString("oa_application_id"));// 12
				list.add(rs.getString("opd_partd"));// 13
				list.add(rs.getString("Seniority_date").substring(0, 10));// 13
			
				
				
				
				
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
 		
   
   
 //------------------------------------------------fetch all data in save page=====================================================
   
   public List<Map<String, Object>> getPersDataForDssc(String perscode,int es_id) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q = "select DISTINCT TO_CHAR(vw.opd_dob,'DD/MM/YYYY') as opd_dob, vw.ct_comm_id, vw.ct_comm_type, vw.opd_officer_name,\n"
					+ "TO_CHAR(vw.opd_date_of_comm,'DD/MM/YYYY') as opd_date_of_comm ,TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority,\n"
					+ "vw.opc_personal_code,vw.ac_arm_id,vw.ac_arm_description,vw.rc_rank_name,vw.opd_personal_id,\n"
					+ "vw.opd_type_of_entry,dssc.oa_application_id,\n"
					+ "dssc.dta_medical_cat, dssc.dta_regiment, \n"
					+ "dssc.dta_sign_candidate, dssc.dta_sign_co,ofa.oa_center_granted,\n"
					+ "vw.opd_partd, count(ofa.opd_personal_id) filter(where ofa.in_index_id != 0 and es.ec_exam_id=3)  as dssc_count,\n"
					+ "DATE_PART('day',(extract(year from es.es_begin_date)||'-03-01 00:00:00')::timestamp- vw.opd_date_of_comm::timestamp)as fsp_days,dssc.id,dssc.dta_creation_date\n"
					+ "from vw_personal_details vw \n"
					+ "left join officer_application ofa on ofa.opd_personal_id = vw.opd_personal_id \n"
					+ "left join dssc_tsoc_application dssc ON dssc.oa_application_id = ofa.oa_application_id and ofa.es_id=?\n"
					+ "inner join exam_schedule es on es.es_id = ofa.es_id\n"
					+ "where vw.opc_personal_code= ? and vw.opd_status_id=1 and ofa.oa_status_id=1 and vw.opd_partd != 0 and vw.opd_partb != 0\n"
					+ "group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,vw.opd_date_of_comm,es.es_begin_date,22,23\n"
					+ "";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1,es_id);
			if(!perscode.equals("")) {
			stmt.setString(2,perscode);
			}
			
			System.out.println("stmt---------getpersdetails------"+stmt);

			ResultSet rs = stmt.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();
			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
					columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
				list.add(columns);
				
				
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return list;
	}
  
   
   public ArrayList<ArrayList<String>> getAllDataforDsscCompChance(String pers_id) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			
			q="select TO_CHAR(vw.opd_date_of_seniority,'DD/MM/YYYY') as opd_date_of_seniority, vw.opd_officer_name,\n"
					+ "vw.rc_rank_name,vw.opd_partd,vw.opd_personal_id,dc.dcc_compens_year,\n"
					+ "count(ofa.opd_personal_id) filter (where ofa.in_index_id != 0 and es.ec_exam_id=3) as dssc_count\n"
					+ "from vw_personal_details vw \n"
					+ "inner join officer_application ofa on ofa.opd_personal_id = vw.opd_personal_id\n"
					+ "inner join exam_schedule es on es.es_id = ofa.es_id\n"
					+ "left join dssc_compens_chance_new dc on dc.opd_personal_id = vw.opd_personal_id\n"
					+ "where vw.opc_personal_code=? group by 1,2,3,4,5,6";

			stmt = conn.prepareStatement(q);
			stmt.setString(1, pers_id);

			ResultSet rs = stmt.executeQuery();
			System.out.println("stmt----tttt--------"+stmt);
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("opd_date_of_seniority"));// 0
				list.add(rs.getString("rc_rank_name"));// 
				list.add(rs.getString("opd_officer_name"));// 
				list.add(rs.getString("opd_partd"));// 
				list.add(rs.getString("dssc_count"));// 
				list.add(rs.getString("opd_personal_id"));// 
				list.add(rs.getString("dcc_compens_year"));// 
			
				
				
				
				
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
   
   
   public ArrayList<ArrayList<String>> getDsscCountDetailsForOfficer(String opd_personal_id) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "";
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			
			
			q="select es.es_begin_date, ofa.oa_center_granted from officer_application ofa \n"
					+ "inner join exam_schedule es on ofa.es_id = es.es_id\n"
					+ "where opd_personal_id=? and es.ec_exam_id=3";

			stmt = conn.prepareStatement(q);
			stmt.setInt(1, Integer.parseInt(opd_personal_id));

			ResultSet rs = stmt.executeQuery();
			System.out.println("stmt----tttt--------"+stmt);
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("es_begin_date").substring(0, 10));// 0
				list.add(rs.getString("oa_center_granted"));
				
				
				
				
				
				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
 		
 		public ArrayList<ArrayList<String>> getjc_courseAllData(String adv_detail) {
 			ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
 			Connection conn = null;
 			String q = "";
 			try {
 				conn = dataSource.getConnection();
 				PreparedStatement stmt = null;
 				
 				q="select TO_CHAR(jcc_beg_date,'DD/MM/YYYY') as jcc_beg_date , TO_CHAR(jcc_end_date,'DD/MM/YYYY') as jcc_end_date  from jc_course where jcc_no=? ";
 	
 				stmt = conn.prepareStatement(q);
 				stmt.setString(1, adv_detail);
 	
 				ResultSet rs = stmt.executeQuery();
 				System.out.println("stmt------------"+stmt);
 				while (rs.next()) {
 					ArrayList<String> list = new ArrayList<String>();
 					list.add(rs.getString("jcc_beg_date"));// 0
 					list.add(rs.getString("jcc_end_date"));// 1
 					
 					
 					
 					
 	
 					alist.add(list);
 				}
 				rs.close();
 				stmt.close();
 				conn.close();
 			} catch (SQLException e) {
 				e.printStackTrace();
 			} finally {
 				if (conn != null) {
 					try {
 						conn.close();
 					} catch (SQLException e) {
 					}
 				}
 			}
 			return alist;
 		}

}
