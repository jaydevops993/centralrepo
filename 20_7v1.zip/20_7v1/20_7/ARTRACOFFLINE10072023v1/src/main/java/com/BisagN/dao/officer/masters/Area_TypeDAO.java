package com.BisagN.dao.officer.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface Area_TypeDAO {
	
	public List<Map<String, Object>> getReportListArea_TypeMaster(int startPage,String pageLength,String Search,String orderColunm,
			String orderType,HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, 
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	
	public long getReportListArea_TypeMasterTotalCount(String Search);
	
	public String DeleteArea_TypeMaster(String deleteid,HttpSession session1);

}
