package com.BisagN.models.officers.trans;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "dssc_admit_card_tbl", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})
public class DSSC_ADMIT_CARD_TBL {
	
	 private int id;
	 private String admit_card_no;
     private int opd_personal_id;
     private String opd_rank;
     private String opd_off_name;
     private Date opd_doc;
     private Date opd_dos;
     private String opd_arms;
     private int opd_partdpass_year;
     private int att_no;
     private int att_1;
     private int att_2;
     private int es_id;
     private Date created_date;
     private String created_by;
     
     

     @Id
     @GeneratedValue(strategy = IDENTITY)
     @Column(name = "id", unique = true, nullable = false)


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAdmit_card_no() {
		return admit_card_no;
	}
	public void setAdmit_card_no(String admit_card_no) {
		this.admit_card_no = admit_card_no;
	}
	public int getOpd_personal_id() {
		return opd_personal_id;
	}
	public void setOpd_personal_id(int opd_personal_id) {
		this.opd_personal_id = opd_personal_id;
	}
	public String getOpd_rank() {
		return opd_rank;
	}
	public void setOpd_rank(String opd_rank) {
		this.opd_rank = opd_rank;
	}
	public String getOpd_off_name() {
		return opd_off_name;
	}
	public void setOpd_off_name(String opd_off_name) {
		this.opd_off_name = opd_off_name;
	}
	public Date getOpd_doc() {
		return opd_doc;
	}
	public void setOpd_doc(Date opd_doc) {
		this.opd_doc = opd_doc;
	}
	public Date getOpd_dos() {
		return opd_dos;
	}
	public void setOpd_dos(Date opd_dos) {
		this.opd_dos = opd_dos;
	}
	public String getOpd_arms() {
		return opd_arms;
	}
	public void setOpd_arms(String opd_arms) {
		this.opd_arms = opd_arms;
	}
	public int getOpd_partdpass_year() {
		return opd_partdpass_year;
	}
	public void setOpd_partdpass_year(int opd_partdpass_year) {
		this.opd_partdpass_year = opd_partdpass_year;
	}
	public int getAtt_no() {
		return att_no;
	}
	public void setAtt_no(int att_no) {
		this.att_no = att_no;
	}
	public int getAtt_1() {
		return att_1;
	}
	public void setAtt_1(int att_1) {
		this.att_1 = att_1;
	}
	public int getAtt_2() {
		return att_2;
	}
	public void setAtt_2(int att_2) {
		this.att_2 = att_2;
	}
	public int getEs_id() {
		return es_id;
	}
	public void setEs_id(int es_id) {
		this.es_id = es_id;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
      
     

}
