package com.BisagN.controller.office.reports;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xwpf.usermodel.TextAlignment;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.ArmServiceWiseAnalysisOfResult.PageNumeration;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;
public class FullyPassed_Controller_Pdf extends AbstractPdfView{

		String Type = "";
		List<String> TH;
		String Heading = "";
		String username = "";
		int totalRecords=0;
		final static String USER_PASSWORD = "user";
		final static String OWNER_PASSWORD = "owner";

		public FullyPassed_Controller_Pdf(String Type, List<String> TH, String Heading, String username) {
			this.Type = Type;
			this.TH = TH; 	
			this.Heading = Heading;
			this.username = username;
		}

		protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
			document.open();
			document.setPageSize(PageSize.A4.rotate());
			super.buildPdfMetadata(model, document, request);
		}

		@Override
		protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
				HttpServletRequest request, HttpServletResponse response) throws Exception {

			DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
			String file_name = datetimestamp.currentDateWithTimeStampString();

			response.setContentType("application/pdf");
			response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
			
			
			String es_year =  (String) model.get("es_year");
			String ExamName =  (String) model.get("ExamName");
			
			System.err.println("================ExamName========"+ExamName);
			
			if (ExamName.equals("Part B")) {
				ExamName="PART B (ONLINE)";
			}


//			String Exm_name =  (String) model.get("Exm_name");

			Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
			Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 1);
//			Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
			Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 0);
			Font fontTableHeadingMainHead_l = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 1);
			Font fontTableHeadingSubMainHead_2 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 8, 1);
			
			
			PdfPTable table4 = new PdfPTable(1);
			table4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			table4.setWidthPercentage(100);

			PdfPTable tabledata4 = new PdfPTable(1);
			tabledata4.setWidths(new int[] { 7 });
			tabledata4.setWidthPercentage(100 / 3.5f);
			tabledata4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata4.setHorizontalAlignment(Element.ALIGN_RIGHT);
			tabledata4.getDefaultCell().setBorder(Rectangle.NO_BORDER);

			


			
			
			Chunk army_training_command_heading = new Chunk("ARMY TRAINING COMMAND (EXAM SEC)\n\n", fontTableHeadingSubMainHead);
			army_training_command_heading.setUnderline(0.1f, -2f);
			Paragraph army_training_command_paragraph = new Paragraph(army_training_command_heading);
			army_training_command_paragraph.setFont(fontTableHeading1);
			army_training_command_paragraph.setAlignment(Element.ALIGN_CENTER);
			
			Chunk full_pass_heading = new Chunk("PROMOTION EXAMINATION "+ExamName+" - "+es_year+"\n\n RESULTS - FULL PASSED"+"\n\n",fontTableHeadingSubMainHead);
			full_pass_heading.setUnderline(0.1f, -2f);
			Paragraph full_pass_heading_paragraph = new Paragraph(full_pass_heading);
			full_pass_heading_paragraph.setFont(fontTableHeading1);
			full_pass_heading_paragraph.setAlignment(Element.ALIGN_CENTER);
			
//			Chunk result = new Chunk("RESULTS - FULL PASSED"+"\n\n",fontTableHeadingSubMainHead);
//			result.setUnderline(0.1f, -2f);
//			Paragraph result_paragraph = new Paragraph(result);
//			result_paragraph.setFont(fontTableHeading1);
//			result_paragraph.setAlignment(Element.ALIGN_CENTER);

			PdfPTable tableheader4 = new PdfPTable(1);
			tableheader4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			tableheader4.setWidthPercentage(100);
			tableheader4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tableheader4.addCell(army_training_command_paragraph);
			//tabledata4.addCell(tableheader4);
			
			
			
			PdfPTable tabledatamain = new PdfPTable(2);
			tabledatamain.setWidths(new int[] { 50, 50 });
			tabledatamain.setWidthPercentage(100);
			tabledatamain.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledatamain.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);

			PdfPTable tableRdata4 = new PdfPTable(2);
			tableRdata4.setWidthPercentage(100);
			tableRdata4.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tableRdata4.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);

			PdfPTable tabledata41 = new PdfPTable(5);
			tabledata41.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			tabledata41.setWidths(new int[] { 1, 4, 2, 7, 3 });
			tabledata41.setWidthPercentage(90);
			tabledata41.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
			tabledata41.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);

			ArrayList<List<String>> fullypassed = (ArrayList<List<String>>) model.get("list");

			Paragraph a4 = new Paragraph("Ser No", fontTableHeadingSubMainHead_2);
			PdfPCell cella4 = new PdfPCell(a4);
			cella4.setHorizontalAlignment(Element.ALIGN_CENTER);
			cella4.setPadding(5);
			tabledata41.addCell(cella4);

			Paragraph b4 = new Paragraph("Personal No ", fontTableHeadingSubMainHead_2);
			PdfPCell cellb4 = new PdfPCell(b4);
			cellb4.setHorizontalAlignment(Element.ALIGN_CENTER);
			cella4.setPadding(5);
			tabledata41.addCell(cellb4);

			Paragraph c4 = new Paragraph("Rank", fontTableHeadingSubMainHead_2);
			PdfPCell cellc4 = new PdfPCell(c4);
			cellc4.setHorizontalAlignment(Element.ALIGN_CENTER);	
			cella4.setPadding(5);
			tabledata41.addCell(cellc4);

			Paragraph d4 = new Paragraph("Name", fontTableHeadingSubMainHead_2);
			PdfPCell celld4 = new PdfPCell(d4);
			celld4.setHorizontalAlignment(Element.ALIGN_CENTER);
			cella4.setPadding(5);
			tabledata41.addCell(celld4);

			Paragraph e4 = new Paragraph("Arm/Service", fontTableHeadingSubMainHead_2);
			PdfPCell celle4 = new PdfPCell(e4);
			celle4.setHorizontalAlignment(Element.ALIGN_CENTER);
			cella4.setPadding(5);
			tabledata41.addCell(celle4);

			PdfPTable tableMeargeF = new PdfPTable(2);
			tableMeargeF.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			tableMeargeF.setWidthPercentage(100);
			tableMeargeF.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tableMeargeF.getDefaultCell().setVerticalAlignment(Element.ALIGN_TOP);
			tableMeargeF.setHeaderRows(1);

			PdfPTable tableHeaderFLeft = new PdfPTable(5);
			tableHeaderFLeft.setWidths(new int[] { 2, 4, 3, 10, 5 });
			tableHeaderFLeft.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tableHeaderFLeft.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tableHeaderFLeft.setWidthPercentage(100);

			PdfPTable tableHeaderFRight = new PdfPTable(5);
			tableHeaderFRight.setWidths(new int[] { 2, 4, 3, 10, 5 });
			tableHeaderFRight.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
			tableHeaderFRight.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
			tableHeaderFRight.setWidthPercentage(100);

			tableHeaderFRight.addCell(cella4);
			tableHeaderFRight.addCell(cellb4);
			tableHeaderFRight.addCell(cellc4);
			tableHeaderFRight.addCell(celld4);
			tableHeaderFRight.addCell(celle4);
			tableHeaderFRight.setHeaderRows(1);
			tableHeaderFRight.setSkipFirstHeader(false);
			
			
			tableHeaderFLeft.addCell(cella4);
			tableHeaderFLeft.addCell(cellb4);
			tableHeaderFLeft.addCell(cellc4);
			tableHeaderFLeft.addCell(celld4);
			tableHeaderFLeft.addCell(celle4);
			tableHeaderFLeft.setHeaderRows(1);
			tableHeaderFLeft.setSkipFirstHeader(false);

			tableHeaderFRight.getDefaultCell().setFixedHeight(10f);
			tableHeaderFLeft.getDefaultCell().setFixedHeight(10f);
			
			
			PdfPCell full_pass_cell = new PdfPCell(full_pass_heading_paragraph);
			full_pass_cell.setColspan(2);
			full_pass_cell.setBorder(0);
			full_pass_cell.setHorizontalAlignment(Element.ALIGN_CENTER);
			tableMeargeF.addCell(full_pass_cell);
			
//			PdfPCell result_full_pass_cell = new PdfPCell(result_paragraph);
//			result_full_pass_cell .setColspan(2);
//			result_full_pass_cell .setBorder(0);
//			result_full_pass_cell .setHorizontalAlignment(Element.ALIGN_CENTER);
//			tableMeargeF.addCell(result_full_pass_cell);
//			
			
			int flag_first_page = 46;
			int flag_first_page_fix = 46;
			
			
			for (int i = 0; i < fullypassed.size();i++) {
				//if(i > 45){ flag_first_page_fix = 66;}
				
				List<String> l = fullypassed.get(i);
				PdfPCell celle_fl = new PdfPCell();
					if(flag_first_page > (flag_first_page_fix/2) && flag_first_page <= flag_first_page_fix) {
						Paragraph ser_no = new Paragraph(l.get(0), fontTableHeadingdata);
						  celle_fl = new PdfPCell(ser_no);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tableHeaderFRight.addCell(celle_fl);
						Paragraph ic_number = new Paragraph(l.get(1), fontTableHeadingdata);
						celle_fl = new PdfPCell(ic_number);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tableHeaderFRight.addCell(celle_fl);
						Paragraph rank = new Paragraph(l.get(2), fontTableHeadingdata);
						celle_fl = new PdfPCell(rank);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
							tableHeaderFRight.addCell(celle_fl);
						Paragraph pers_name = new Paragraph(l.get(3), fontTableHeadingdata);
						celle_fl = new PdfPCell(pers_name);
						celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
							tableHeaderFRight.addCell(celle_fl);
						Paragraph arm = new Paragraph(l.get(4), fontTableHeadingdata);
						celle_fl = new PdfPCell(arm);
						 celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
							celle_fl.setPadding(3);
							if (i % 2 == 0) {
								celle_fl.setBackgroundColor(java.awt.Color.lightGray);
							}
							tableHeaderFRight.addCell(celle_fl);
					}
					if(flag_first_page > (flag_first_page_fix-flag_first_page_fix) && flag_first_page <= (flag_first_page_fix/2)) {
						Paragraph ser_no = new Paragraph(l.get(0), fontTableHeadingdata);
						 celle_fl = new PdfPCell(ser_no);
						 celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						 celle_fl.setPadding(3);
						 if (i % 2 == 0) {
								celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
						tableHeaderFLeft.addCell(celle_fl);
						Paragraph ic_number = new Paragraph(l.get(1), fontTableHeadingdata);
						celle_fl = new PdfPCell(ic_number);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
							tableHeaderFLeft.addCell(celle_fl);
						Paragraph rank = new Paragraph(l.get(2), fontTableHeadingdata);
						celle_fl = new PdfPCell(rank);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
							tableHeaderFLeft.addCell(celle_fl);
						Paragraph pers_name = new Paragraph(l.get(3), fontTableHeadingdata);
						celle_fl = new PdfPCell(pers_name);
						celle_fl.setHorizontalAlignment(Element.ALIGN_LEFT);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
							tableHeaderFLeft.addCell(celle_fl);
						Paragraph arm = new Paragraph(l.get(4), fontTableHeadingdata);
						celle_fl = new PdfPCell(arm);
						celle_fl.setHorizontalAlignment(Element.ALIGN_CENTER);
						celle_fl.setPadding(3);
						if (i % 2 == 0) {
							celle_fl.setBackgroundColor(java.awt.Color.lightGray);
						}
							tableHeaderFLeft.addCell(celle_fl);
							
						
					}
				if(flag_first_page==((flag_first_page_fix/2)+1)){
					tableMeargeF.addCell(tableHeaderFRight);
					tableHeaderFRight  = new PdfPTable(5);
					tableHeaderFRight.setWidths(new int[] { 2, 4, 3, 10, 5 });
					tableHeaderFRight.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					tableHeaderFRight.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
					tableHeaderFRight.setWidthPercentage(100);
					tableHeaderFRight.addCell(cella4);
					tableHeaderFRight.addCell(cellb4);
					tableHeaderFRight.addCell(cellc4);
					tableHeaderFRight.addCell(celld4);
					tableHeaderFRight.addCell(celle4);
					tableHeaderFRight.setHeaderRows(1);
					tableHeaderFRight.setSkipFirstHeader(false);
					tableHeaderFRight.getDefaultCell().setFixedHeight(10f);
				
				}
				if(flag_first_page==((flag_first_page_fix-flag_first_page_fix)+1)){
					tableMeargeF.addCell(tableHeaderFLeft);
					tableHeaderFLeft = new PdfPTable(5);
					tableHeaderFLeft.setWidths(new int[] { 2, 4, 3, 10, 5 });
					tableHeaderFLeft.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					tableHeaderFLeft.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
					tableHeaderFLeft.setWidthPercentage(100);
					tableHeaderFLeft.addCell(cella4);
					tableHeaderFLeft.addCell(cellb4);
					tableHeaderFLeft.addCell(cellc4);
					tableHeaderFLeft.addCell(celld4);
					tableHeaderFLeft.addCell(celle4);
					tableHeaderFLeft.setHeaderRows(1);
					tableHeaderFLeft.setSkipFirstHeader(false);
					tableHeaderFLeft.getDefaultCell().setFixedHeight(10f);

				}
				
				if(fullypassed.size() == (i+1) & flag_first_page > ((flag_first_page_fix/2)+1)){
					tableMeargeF.addCell(tableHeaderFRight);
					tableMeargeF.addCell(tableHeaderFLeft);
					tableHeaderFRight  = new PdfPTable(5);
					tableHeaderFRight.setWidths(new int[] { 2, 4, 3, 10, 5 });
					tableHeaderFRight.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					tableHeaderFRight.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
					tableHeaderFRight.setWidthPercentage(100);
					tableHeaderFRight.addCell(cella4);
					tableHeaderFRight.addCell(cellb4);
					tableHeaderFRight.addCell(cellc4);
					tableHeaderFRight.addCell(celld4);
					tableHeaderFRight.addCell(celle4);
					tableHeaderFRight.setHeaderRows(1);
					tableHeaderFRight.setSkipFirstHeader(false);
					tableHeaderFRight.getDefaultCell().setFixedHeight(10f);
				}
				if(fullypassed.size() == (i+1) & flag_first_page > (flag_first_page_fix-flag_first_page_fix) & flag_first_page < ((flag_first_page_fix/2)+1)){
					tableMeargeF.addCell(tableHeaderFLeft);
					tableHeaderFLeft = new PdfPTable(5);
					tableHeaderFLeft.setWidths(new int[] { 2, 4, 3, 10, 5 });
					tableHeaderFLeft.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					tableHeaderFLeft.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
					tableHeaderFLeft.setWidthPercentage(100);
					tableHeaderFLeft.addCell(cella4);
					tableHeaderFLeft.addCell(cellb4);
					tableHeaderFLeft.addCell(cellc4);
					tableHeaderFLeft.addCell(celld4);
					tableHeaderFLeft.addCell(celle4);
					tableHeaderFLeft.setHeaderRows(1);
					tableHeaderFLeft.setSkipFirstHeader(false);
					tableHeaderFLeft.getDefaultCell().setFixedHeight(10f);
				}			
				flag_first_page -= 1;
				if(flag_first_page == 0) {
					flag_first_page_fix = 60;
					flag_first_page = flag_first_page_fix;
				}
			}
			/*if((fullypassed.size()%46) != 0){
				tableMeargeF.addCell(tableHeaderFRight);
				tableMeargeF.addCell(tableHeaderFLeft);
			}*/
			
			 PageNumeration event = new PageNumeration(arg2);
				arg2.setPageEvent(event);
				document.setPageCount(1);
			
			PdfPCell cell1236_f;
			cell1236_f = new PdfPCell();
			cell1236_f.addElement(tabledata4);
			cell1236_f.addElement(tableheader4);
			cell1236_f.addElement(tableMeargeF);
			cell1236_f.setBorder(0);
			table4.addCell(cell1236_f);
		
		document.add(table4);
		super.buildPdfMetadata(model, document, request);
		}

		class PageNumeration extends PdfPageEventHelper {
			PdfTemplate total;
			PdfTemplate total1;

			public PageNumeration(PdfWriter writer) {
				try {
					total = writer.getDirectContent().createTemplate(30, 16);
					total1 = writer.getDirectContent().createTemplate(30, 16);
				} catch (Exception e) {
					e.getMessage();
				}
			}

			public void onOpenDocument(PdfWriter writer, Document document) {
				// total = writer.getDirectContent().createTemplate(30, 12);
			}

			public void onEndPage(PdfWriter writer, Document document) {
				PdfPTable table = new PdfPTable(3);
			
				try {
				//	table.setWidths(new int[] { 8, 19, 21, 2 });  
					table.setWidths(new int[] {15, 6,1}); 
					table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
					table.setLockedWidth(true);
					table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
					//table.addCell("TOTAL RECORDS:");  //table.addCell("TOTAL SHEET :");
					
					
					PdfPCell cell1 = new PdfPCell(Image.getInstance(total1));
					cell1.setBorder(Rectangle.NO_BORDER);
					cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
					//table.addCell(cell1);
									
					Date now = new Date();
					String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
					
					table.addCell(String.format(dateString)); 
					
					table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
					
					
					table.addCell(String.format("Pages %d of", writer.getPageNumber()));
					//table.addCell("Month :");
					PdfPCell cell = new PdfPCell(Image.getInstance(total));
					cell.setBorder(Rectangle.NO_BORDER);				
					table.addCell(cell);
					
					table.writeSelectedRows(0, -1, document.leftMargin(), document.topMargin() + 0, writer.getDirectContent());
				} catch (DocumentException de) {
					throw new ExceptionConverter(de);
				}
			}

			public void onCloseDocument(PdfWriter writer, Document document) {
				ColumnText.showTextAligned(total, Element.ALIGN_LEFT, new Phrase(String.valueOf(writer.getPageNumber() - 1)), 2, 2, 0);
				ColumnText.showTextAligned(total1, Element.ALIGN_LEFT, new Phrase(String.valueOf(totalRecords)), 2, 2, 0);
			}
		}


}

