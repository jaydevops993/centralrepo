package com.BisagN.models.officers.trans;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "cpv", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})
public class CPV {

	
	private int id;
	private double cpv_mks;
	private double fd_service_mks;
	private String created_by;
	private Date created_date;
	private String modified_by;
	private Date modified_date;
	private int opd_personal_id;
	private int oa_application_id;
	
	
	
	@Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "id", unique = true, nullable = false)

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getCpv_mks() {
		return cpv_mks;
	}
	public void setCpv_mks(double cpv_mks) {
		this.cpv_mks = cpv_mks;
	}
	public double getFd_service_mks() {
		return fd_service_mks;
	}
	public void setFd_service_mks(double fd_service_mks) {
		this.fd_service_mks = fd_service_mks;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	public int getOpd_personal_id() {
		return opd_personal_id;
	}
	public void setOpd_personal_id(int opd_personal_id) {
		this.opd_personal_id = opd_personal_id;
	}
	public int getOa_application_id() {
		return oa_application_id;
	}
	public void setOa_application_id(int oa_application_id) {
		this.oa_application_id = oa_application_id;
	}
	
	
	
	
	
	 
}
