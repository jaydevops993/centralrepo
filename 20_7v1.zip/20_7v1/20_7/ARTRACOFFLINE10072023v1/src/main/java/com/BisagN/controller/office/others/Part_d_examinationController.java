package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.masters.Officer_personal_detailsController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.others.ExportPartBDao;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.dao.officer.trans.Unfair_meansDAO;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.PARTB_D_APPLICATION_M;
import com.BisagN.models.officers.trans.UNFAIR_MEANS_M;



@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class Part_d_examinationController {


@Autowired
private PartB_ExaminationDAO PartBDAo;

HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();


@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;


CommonController comm = new CommonController();

@Autowired
Officer_personal_detailsController ofd= new Officer_personal_detailsController();

@Autowired
private ExportPartBDao export;

@Autowired
	private RoleBaseMenuDAO roledao;  
         
         @RequestMapping(value = "SearchPart_d_examinationUrl", method = RequestMethod.GET)
         public ModelAndView SearchPart_d_examinationUrl(ModelMap Mmap,HttpServletRequest request,HttpSession session,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
  NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

        	 if(request.getHeader("Referer") == null ) { 
    			 session.invalidate();
    			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
    			 return new ModelAndView("redirect:/login");
    		 }

        	 String roleid1 = session.getAttribute("roleid").toString();
    		 Boolean val = roledao.ScreenRedirect("SearchPart_d_examinationUrl", roleid1);		
    			if(val == false) {
    				return new ModelAndView("AccessTiles");
    		}	
        	 
        	 	Mmap.put("msg", msg);
        	
        		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();
        		  int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
        		  
        		  int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0": session.getAttribute("ec_exam_id").toString());
        		System.err.println("es_begindate=============="+es_begindate);
        		
        		if(ec_exam_id ==2) {
        		 if(!es_begindate.equals("")) {
        				
        			 Mmap.put("partd_begindate", es_begindate);
        		}
        		 
        		 
        		 if(es_id != 0) {
        				
        			 Mmap.put("es_id", es_id);
        		}
        		 
        		 
        		 if(ec_exam_id != 0) {
        				
        			 Mmap.put("ec_exam_id", ec_exam_id);
        			  ArrayList<ArrayList<String>>list2= PartBDAo.getdatafromExaminationCentre(ec_exam_id);
        			    Mmap.put("getexamcentrelist",list2);
        		}
        		 
        		} 
     		 
         
         	 
 				
            // Mmap.put("getexamcentrelist",list2);
              
              Mmap.put("getctarmcodetypeListDDL",comm.getctarmcodetypeListDDL(sessionFactory));
         return new ModelAndView("SearchPartDexm_tile");
}
         @RequestMapping(value = "/getPatD_examinationReportDataList", method = RequestMethod.POST)
         public @ResponseBody ArrayList<ArrayList<String>> getPartDexmCandidateReport(int startPage,String pageLength,String Search,String orderColunm,
       		  String orderType,String pers_no, String pers_name,String center, String opd_arm_service,String exam_schedule_dt_id,HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
        	if(!exam_schedule_dt_id.equals("")) {
        	 System.err.println("pers_no=====cccc==="+pers_no);
        	 return PartBDAo.getPartDexmCandidateReport(startPage,pageLength,Search,orderColunm,orderType,pers_no,pers_name,center,opd_arm_service,exam_schedule_dt_id,sessionUserId);
        }
			return null;
         }

         @RequestMapping(value = "/getPartD_examinationTotalCount", method = RequestMethod.POST)
        public @ResponseBody long getPartD_examinationTotalCount(HttpSession sessionUserId,String Search,String pers_no, String pers_name,String center, String opd_arm_service,String exam_schedule_dt_id){
        	
        	 if(!exam_schedule_dt_id.equals("")) {
        	 
        	 return PartBDAo.getPartDexmCandidatereportTotalCount(Search,pers_no,pers_name, center,  opd_arm_service, exam_schedule_dt_id);
        }
			return 0;
        	 
         }
         
         
         
     	@RequestMapping(value = "/Part_d_examinationAction", method = RequestMethod.POST)
    	public @ResponseBody String Part_d_examinationAction(
    			@Valid @ModelAttribute("PartDexmCMD") PARTB_D_APPLICATION_M partbexm, BindingResult result,
    			HttpServletRequest request, ModelMap model, HttpSession session) {
    		Session sessionHQL = this.sessionFactory.openSession();
    		Transaction tx = sessionHQL.beginTransaction();
    		String save = "";
       
       		
       	
       		try {
       			
       			String personal_number = request.getParameter("personal_number");
    			String center = request.getParameter("center_id");
    			String sub_id = request.getParameter("submodulehid");
    			
    			if (personal_number == "" || personal_number.equals("")) {
    				 return   " Please Enter Personal No" ;
    				 
    			}
    			
    			if (center == "" || center.equals("0")) {
   				 return   "Please Select Centre" ;   				 
   			}
    			
    			if (personal_number == "" || personal_number.equals("")) {
    				return " Please Enter Personal No" ;
    			}
    			

    			
    			if(sub_id.equals("")) {
    				
    				return "Please Select Atleast One Subject Appearing For in Written Exam" ;
    			}
       	     String username = session.getAttribute("username").toString();
       	  Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			OFFICER_APPLICATION_M o_app1 = new OFFICER_APPLICATION_M();
			int id = o_app1.getOa_application_id() > 0 ? o_app1.getOa_application_id() : 0;
				String pers_code = request.getParameter("personal_number");
			
			List<OFFICER_PERSONAL_CODE_M>getopdid=comm.getopdIdbycode( sessionFactory, pers_code);
			if(!getopdid.isEmpty()) {
		int opd_pers_id= getopdid.get(0).getOpd_personal_id();
			ArrayList<ArrayList<String>> begindatelist = export.getbegindateforexport("Part B");
			int es_id = Integer
					.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			
			
			String es_begindate = session.getAttribute("es_begin_date") == null ? ""
					: session.getAttribute("es_begin_date").toString();
			 if(!es_begindate.equals("")) {
			String exmsch_dt= es_begindate.substring(0, 10);
			 int ec_exam_id = session.getAttribute("ec_exam_id") ==null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());	
			
			ArrayList<ArrayList<String>> list2 = export.getRulesDetailsFromExmSchedule(exmsch_dt, String.valueOf(ec_exam_id),"");
			System.err.println("list2============="+list2);
			
			String exam_schedule_dt =list2.get(0).get(0);
			String min_year=list2.get(0).get(1);
			String max_year=list2.get(0).get(2);
			System.err.println("list2============="+list2);
			
			ArrayList<ArrayList<String>>getvalidappdata= PartBDAo.getManualPartbRulesappdetails( opd_pers_id, exmsch_dt,  exam_schedule_dt,  min_year,  max_year);
			 if(!getvalidappdata.isEmpty()) {
			Query q0 = sessionHQL.createQuery(
					"select count(*) from OFFICER_APPLICATION_M where (es_id=:es_id and opd_personal_id=:opd_personal_id) and oa_application_id!=:oa_application_id and oa_status_id=:oa_status_id");

			q0.setParameter("es_id", es_id);
			q0.setParameter("opd_personal_id", opd_pers_id);
			q0.setParameter("oa_application_id", id);
			q0.setParameter("oa_status_id", 1);
			Long c = (Long) q0.uniqueResult();

	
	

     		
     	
     		if(id == 0) {
     			
     			if (c == 0  ) {
     			
     				OFFICER_APPLICATION_M o_app = new OFFICER_APPLICATION_M();

					o_app.setEs_id(es_id);
					o_app.setOpd_personal_id(opd_pers_id);
					o_app.setOa_created_by(username);
					o_app.setOa_creation_date(date);
					o_app.setOa_center_granted(Integer.parseInt(center));
					o_app.setOa_status_id(1);
					int mid = (int) sessionHQL.save(o_app);
					sessionHQL.flush();
					sessionHQL.clear();
					tx.commit();


					Session sessionHQL1 = this.sessionFactory.openSession();
					Transaction tx1 = sessionHQL1.beginTransaction();


					partbexm.setPbda_created_by(username);
					partbexm.setPbda_creation_date(date);
					partbexm.setPbda_add_corres1(request.getParameter("pbda_add_corres1"));
					partbexm.setPbda_add_corres2(request.getParameter("pbda_add_corres2"));
					partbexm.setPbda_add_corres3(request.getParameter("pbda_add_corres3"));
					partbexm.setOa_application_id(mid);
					partbexm.setPbda_immediate_super(request.getParameter("pbda_immediate_super"));
					partbexm.setPbda_subjects(Integer.parseInt(sub_id));
					sessionHQL1.save(partbexm);

					sessionHQL1.flush();
					sessionHQL1.clear();
					tx1.commit();

					return "Application Generated Successfully";
         
     			    
           
       			    
     			}
     		}else {
				
     			return "Application already Exist";
			}
     		}else {
     			return "Rules not Matched With Your Application Data";
				
			}
			 }
         } 
       		
       		}
       		catch (RuntimeException e) {
       			try {
       				tx.rollback();
       				model.put("msg", "roll back transaction");
       			} catch (RuntimeException rbe) {
       				model.put("msg", "Couldn�t roll back transaction " + rbe);
       			}
       			throw e;
       		} finally {
       			if (sessionHQL != null) {
       				sessionHQL.close();
       			}
       		}

       		return save;
       		}

         @RequestMapping(value = "EditPartD_Application_detailsUrl", method = RequestMethod.POST)
         public ModelAndView EditPartD_Application_detailsUrl(ModelMap Mmap,HttpServletRequest request,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String updateid) {

        	 if(request.getHeader("Referer") == null ) { 
    			 session.invalidate();
    			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
    			 return new ModelAndView("redirect:/login");
    		 }

        	 String roleid1 = session.getAttribute("roleid").toString();
    		 Boolean val = roledao.ScreenRedirect("SearchPart_d_examinationUrl", roleid1);		
    			if(val == false) {
    				return new ModelAndView("AccessTiles");
    		}
    			
                Session s1 = this.sessionFactory.openSession();
                Transaction tx = s1.beginTransaction();
                String enckey = "commonPwdEncKeys";  
                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
                System.err.println("DcryptedPk==============="+DcryptedPk);
                Query q = null;
                q = s1.createQuery("from PARTB_D_APPLICATION_M where cast(id as string)=:PK");
                q.setString("PK", DcryptedPk);
                @SuppressWarnings("unchecked")
                List<String> sub_total = (List<String>) q.list();
                
                tx.commit();
                s1.close();
               
                int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0": session.getAttribute("ec_exam_id").toString());
       		 if(ec_exam_id != 0) {
       				
       			 Mmap.put("ec_exam_id", ec_exam_id);
       			  ArrayList<ArrayList<String>>list2= PartBDAo.getdatafromExaminationCentre(ec_exam_id);
       			    Mmap.put("getexamcentrelist",list2);
       		}        	
       		 
       		 Mmap.put("Edit_pers_details", PartBDAo.getOPDdetailsforpartb(DcryptedPk));
        		ArrayList<ArrayList<String>> partblist = PartBDAo.getpartbapplicationdtl(DcryptedPk);

        		String subjecttotal = partblist.get(0).get(5);

        		String arm_id = PartBDAo.getOPDdetailsforpartb(DcryptedPk).get(0).get(10);
        		ArrayList<ArrayList<String>> list = PartBDAo.getSubjectList("Part D", arm_id);
System.err.println("======"+list.get(0).get(3));
        		String exam_id = list.get(0).get(3);

        		List<SUBJECT_CODE_M> sublist = comm.getsubjectlist(sessionFactory, Integer.parseInt(exam_id));
        		ArrayList<Integer> subtotallist = getsubjectListFromTotal(Integer.parseInt(subjecttotal), sublist);

        		Mmap.put("subtotallist", subtotallist);
        		Mmap.put("subtotallistSize", subtotallist.size());
        		Mmap.put("Edit_partb_Details", PartBDAo.getpartbapplicationdtl(DcryptedPk));

        		String oapp_id = PartBDAo.getOPDdetailsforpartb(DcryptedPk).get(0).get(11);

        		System.err.println("oapp_id========" + oapp_id);
        		Mmap.put("msg", msg);
        		Mmap.put("subjecttotal", subjecttotal);
        		Mmap.put("oapp_id", oapp_id);
         return new ModelAndView("EditPartD_Application_tile","editPartDCMD",new PARTB_D_APPLICATION_M());
}
         
         
         
       //==========================CODE CALCULATION
     	
     	private static ArrayList<Integer> getsubjectListFromTotal(int temp,List<SUBJECT_CODE_M> subjectcodeList) {
     		ArrayList<Integer> rip = new ArrayList<Integer>();
     		
     		 for(int i=subjectcodeList.size()-1;i>=0;i--) {
     		 if((temp-(subjectcodeList.get(i).getSc_subject_code()))>=0) { 
     			 rip.add(subjectcodeList.get(i).getSc_subject_code());
     			 temp = temp - (subjectcodeList.get(i).getSc_subject_code());
     			 System.err.println(subjectcodeList.get(i).getSc_subject_code()); 
     		 }
     	 }
     		return rip;
     	}
 
  
  
	@RequestMapping(value = "/EditPart_d_examinationAction" ,method = RequestMethod.POST) 
 	  public ModelAndView EditPart_d_examinationAction(@Valid @ModelAttribute("EditPartDCMD") PARTB_D_APPLICATION_M ln, BindingResult result,
 	  HttpServletRequest request, ModelMap model, HttpSession session){ 

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		String updateid = request.getParameter("oapp_id");
		Date date = new Date();
		String username = session.getAttribute("username").toString();
		String sub_total = request.getParameter("submodulehid");
		
		String center_id = request.getParameter("center_id");
	
		if (center_id.equals("0")) {
			model.put("msg","Please Select Centre");
			 return new ModelAndView("redirect:SearchPart_d_examinationUrl"); 
		}
		
		if(sub_total.equals("0")) {
			
			model.put("msg", "Please Select Atleast One Subject Appearing For in Written Exam" );
			  return new ModelAndView("redirect:Searchpart_b_examinationUrl");
		}
		
		
		// ln.setId(Integer.parseInt(request.getParameter("id")));

		String pbda_immediate_super = request.getParameter("pbda_immediate_super");
		String pbda_add_corres1 = request.getParameter("pbda_add_corres1");
		String pbda_add_corres2 = request.getParameter("pbda_add_corres2");
		String pbda_add_corres3 = request.getParameter("pbda_add_corres3");
		String pbda_survey_details = request.getParameter("pbda_survey_details");
		String pbda_comp_details = request.getParameter("pbda_comp_details");

		

		System.err.println("updateid========" + updateid);

		System.err.println("sub_total========" + sub_total);

		System.err.println("pbda_add_corres1========" + pbda_add_corres1);

	
			String hql = "update PARTB_D_APPLICATION_M set pbda_immediate_super=:pbda_immediate_super ,pbda_add_corres1=:pbda_add_corres1,pbda_add_corres2=:pbda_add_corres2,"
					+ "pbda_add_corres3=:pbda_add_corres3,pbda_eligible_subjects=:pbda_eligible_subjects where  oa_application_id=:oa_application_id";

			Query query = sessionHQL.createQuery(hql).setString("pbda_immediate_super", pbda_immediate_super)
					.setParameter("pbda_add_corres1", pbda_add_corres1)
					.setParameter("pbda_add_corres2", pbda_add_corres2)
					.setParameter("pbda_add_corres3", pbda_add_corres3)
					.setParameter("pbda_eligible_subjects", Integer.parseInt(sub_total))
					.setInteger("oa_application_id", Integer.parseInt(updateid));
			
			query.executeUpdate();

			String oa_center_opted = request.getParameter("center_id");
			System.out.println("oa_center_opted=====" + oa_center_opted);
			String hql1 = "update OFFICER_APPLICATION_M set oa_center_granted=:oa_center_granted where oa_application_id=:oa_application_id ";
			Query query1 = sessionHQL.createQuery(hql1)
					.setParameter("oa_center_granted", Integer.parseInt(oa_center_opted))
					.setParameter("oa_application_id", Integer.parseInt(updateid));
			query1.executeUpdate();
		

 			 
 	    tx.commit(); 
 	   model.put("msg","Data Updated Successfully"); 
 	    sessionHQL.close(); 

 	 
 	  
 	    
 			
 	    return new ModelAndView("redirect:SearchPart_d_examinationUrl"); 
 	  } 

  
  @RequestMapping(value = "PartD_ApplicationURL", method = RequestMethod.POST)
  public ModelAndView PartD_ApplicationURL(ModelMap Mmap,HttpServletRequest request,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String deleteid) {

	  if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

 	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("SearchPart_d_examinationUrl", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}	
			
		String es_begindate = session.getAttribute("es_begin_date") == "" ? "": session.getAttribute("es_begin_date").toString();
		  int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
		  
		  int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0": session.getAttribute("ec_exam_id").toString());
		System.err.println("es_begindate=============="+es_begindate);
		
		if(ec_exam_id ==2) {
		 if(!es_begindate.equals("")) {
				
			 Mmap.put("partd_begindate", es_begindate.substring(0, 10));
		}
		 
		 
		 if(es_id != 0) {
				
			 Mmap.put("es_id", es_id);
		}
		 
		 
		 if(ec_exam_id != 0) {
				
			 Mmap.put("ec_exam_id", ec_exam_id);
			  ArrayList<ArrayList<String>>list2= PartBDAo.getdatafromExaminationCentre(ec_exam_id);
			  Mmap.put("getexamcentrelist",list2);
		}
		 
		} 
			
    
      Mmap.put("msg", msg);
  return new ModelAndView("Part_d_examination_tile","PartBCMD",new PARTB_D_APPLICATION_M());
}
  
  
  
  @RequestMapping(value = "/getPartDSubjectlist", method = RequestMethod.POST)
 	@ResponseBody public ArrayList<ArrayList<String>> getSubjectlist(String exm_name, String arm_id) {

 		ArrayList<ArrayList<String>> list = PartBDAo.getSubjectList("Part D",arm_id);
 		return list;

 	}
  
  
  @RequestMapping(value = "/deletePartD_Application_detailsUrl", method = RequestMethod.POST) 
  public ModelAndView deletePartD_Application_detailsUrl(String deleteid3,HttpSession session,ModelMap model) { 
	  
	  System.err.println("deleteid==========="+deleteid3);
		String	msg="";
		Session sessionHQL =  this.sessionFactory.openSession(); 
		Transaction	tx = sessionHQL.beginTransaction();
		
		  String enckey = "commonPwdEncKeys";  
          String DcryptedPk = hex_asciiDao.decrypt((String) deleteid3,enckey,session); 
          System.out.println(DcryptedPk+"==========DcryptedPk");
		try {
			String hql = "update OFFICER_APPLICATION_M set oa_status_id=:oa_status_id where oa_application_id=:oa_application_id";
			Query query = sessionHQL.createQuery(hql)
						.setParameter("oa_status_id", 0)		
						.setParameter("oa_application_id", Integer.parseInt(DcryptedPk));
				query.executeUpdate();
				
//				
//				String hq1l = "update PARTB_D_APPLICATION_M set oa_status_id=:oa_status_id  where oa_application_id=:oa_application_id ";
//				Query query1 = sessionHQL.createQuery(hq1l)
//							.setParameter("oa_status_id", 0)			
//							.setParameter("oa_application_id",  Integer.parseInt(DcryptedPk));
//				query1.executeUpdate();
				
				
				
			
				 model.put("msg",msg);
			     model.put("msg", "Delete Successfully");	
		      
		       tx.commit();
			}catch(RuntimeException e){
				e.printStackTrace();
				tx.rollback();
				
				model.put("msg","Server side Error");
				
			}
			        
		        return new ModelAndView("redirect:SearchPart_d_examinationUrl");
		}

} 
