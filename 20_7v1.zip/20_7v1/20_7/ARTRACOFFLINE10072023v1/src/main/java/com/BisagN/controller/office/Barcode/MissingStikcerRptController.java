package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.Indexing.MissingStickerRptDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_MASTER;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;


@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class MissingStikcerRptController {
	@Autowired
	CommonController comm;
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	MissingStickerRptDAO misDao;
	
	@RequestMapping(value = "MissingStikcerRptUrl", method = RequestMethod.GET)
	public ModelAndView MissingStikcerRptUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? ""
				: session.getAttribute("es_begin_dateshow").toString();
		System.err.println("es_begindate===========" + es_begindate);
		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		 Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
		
		 
			if(es_id != 0) {
				 List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
				 Mmap.put("es_id", es_id);
				 String index_mode= UnlcokExmsch.get(0).getEs_index_mode();
				 Mmap.put("index_mode", index_mode);
			}
			
			
			int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
			if(esi_es_id != 0) {
			List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esi_es_id);
			Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			
			  int day = date.getDayOfMonth();
			  String[] months = {"Jan", "Feb", "Mar", "Apr" ,"May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
			  
			  String[] shortMonths = new DateFormatSymbols().getShortMonths();
		        for (String shortMonth : shortMonths) {
		            
		      	 
		        }
			  
			  Month month = date.getMonth();
			  int year = date.getYear();
			String begindateShow= day +" "+ month + " "+ year;
			 
			 Mmap.put("begindateShow",begindateShow);
			 Mmap.put("esid_es_id",esi_es_id);
			
			
			List<EXAMSCHEDULE_INDEXING_DETAIL>ActiveSubject = comm.getActiveIndxSubject(sessionFactory,esi_es_id);
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
			if (esid_sc_subject_id != 0) {
			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
			List<SUBJECT_CODE_M>ActiveSubName= comm.getsubjectIdbysubname( sessionFactory, esid_sc_subject_id, ec_exam_id);
			
			  
		 
			 Mmap.put("ActiveSub",ActiveSubName.get(0).getSc_subject_name());
			 List<INDEXED_PACKING_NOTES_MASTER>bundleprefix=  comm.getBundlePrefixList(sessionFactory,esi_es_id,esid_sc_subject_id) ;
			 Mmap.put("bundle_prefix", bundleprefix);
			
		}
//			 Mmap.put("ActiveSub",esid_sc_subject_id);
			 
			}
			
			
			
		 
		Mmap.put("msg", msg);
		return new ModelAndView("MissingStcikerRptTiles");
	}


	
	
	@RequestMapping(value = "/getMissingSticker_reportPDF", method = RequestMethod.POST)
	public ModelAndView getMissingSticker_reportPDF(ModelMap Mmap, HttpSession session,  HttpServletRequest request, String typeReport, String reportname1, 
		String exam_schedule_dt1, 	String ec_exam_id2, String ic_number2) {
		try {

			List<OFFICER_PERSONAL_CODE_M> opdpers_id = comm.getopdIdbycode(sessionFactory, ic_number2);
			int opd_pers_id=opdpers_id.get(0).getOpd_personal_id();
			ArrayList<ArrayList<String>>getMisSticker=misDao.getMissingStickerRptDetails(exam_schedule_dt1,  opd_pers_id) ;
				
			if (getMisSticker.size() == 0) {

				Mmap.put("msg", "Data Not Available.");
			} else {
				Mmap.put("list", getMisSticker);
				Mmap.put("list.size()", getMisSticker.size());
			if (typeReport != null && typeReport.equals("pdfL")) {
				if (getMisSticker.size() > 0) {

					List<String> TH = new ArrayList<String>();
					String Heading = "";
					String username = session.getAttribute("username").toString();
					return new ModelAndView(new MissingStickerPdfController("L", TH, Heading, username),"userList",getMisSticker);

				}
			
			
			}
}
		
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new ModelAndView("MissingStcikerRptTiles");
	}
}
	