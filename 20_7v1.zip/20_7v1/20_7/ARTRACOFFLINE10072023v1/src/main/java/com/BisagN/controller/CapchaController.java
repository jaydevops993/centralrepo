package com.BisagN.controller;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Cipher;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Controller
@RequestMapping(value = {"admin","/" ,"user"}) 
public class CapchaController {

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	@RequestMapping(value = "/capchaCode", method = RequestMethod.POST)
	public @ResponseBody List<String> capchaCode(HttpServletRequest request) {
			List<String> capchaList = new ArrayList<String>();
			capchaList.add(getRandomInteger(10, 1));
			capchaList.add(getRandomInteger(10, 1));
			capchaList.add(getRandomInteger(10, 1));
			capchaList.add(getRandomInteger(10, 1));
			capchaList.add(getRandomCharacter());
			String capcha = "";
			for (int i = 0; i < capchaList.size(); i++) {
				capcha += capchaList.get(i);
			}
			HttpSession session = request.getSession();
			session.setAttribute("capcha", capcha);
			return capchaList;
		}
		public static String getRandomInteger(int maximum, int minimum) {
			return String.valueOf(((int) (Math.random() * (maximum - minimum))) + minimum);
		}
		public static String getRandomCharacter() {
			String AlphaNumericString = "ABCDEFGHJKMNOPQRSTUVWXYZabcdefghjkmnopqrstuvxyz";
			int index = (int) (AlphaNumericString.length() * Math.random());
			return String.valueOf(AlphaNumericString.charAt(index));
		}
		@RequestMapping(value = "/genCapchaCode")
		public @ResponseBody byte[] genCapchaCode(HttpServletRequest request) {
			byte[] image = createQRImage(request);
			//String token = UUID.randomUUID().toString();
			//request.getSession().setAttribute("newtoken", token);
			if(!image.equals("")) {
				return image;//+","+token;
			}else {
				return null;
			}
		}
		@RequestMapping(value = "/checkCapchaCode", method = RequestMethod.POST)
		public @ResponseBody boolean checkCapchaCode(HttpServletRequest request,String iCapcha) {
			String txtInput = iCapcha.replaceAll("\\s","").toString();
			String capcha = request.getSession().getAttribute("capcha").toString();
			if(txtInput.equals(capcha)){
				 return true;
			}else {
				return false;
			}
		}
		/*String captchaString = "";
		public String createQRImage(HttpServletRequest request) {
			try {
	            Color backgroundColor = Color.white;
	            Color borderColor = Color.black;
	            Color textColor = Color.black;
	            Color circleColor = new Color(190, 160, 150);
	            Font textFont = new Font("Verdana", Font.BOLD, 30);
	            int charsToPrint = 5;
	            int width = 150;
	            int height = 50;
	            int circlesToDraw = 25;
	            float horizMargin = 10.0f;
	            double rotationRange = 0.7; 
	            BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
	            Graphics2D g = (Graphics2D) bufferedImage.getGraphics();
	            g.setColor(backgroundColor);
	            g.fillRect(0, 0, width, height);
	            g.setColor(circleColor);
	            for (int i = 0; i < circlesToDraw; i++) {
	                int L = (int) (Math.random() * height / 2.0);
	                int X = (int) (Math.random() * width - L);
	                int Y = (int) (Math.random() * height - L);
	                g.draw3DRect(X, Y, L * 2, L * 2, true);
	            }
	            g.setColor(textColor);
	            g.setFont(textFont);
	            FontMetrics fontMetrics = g.getFontMetrics();
	            int maxAdvance = fontMetrics.getMaxAdvance();
	            int fontHeight = fontMetrics.getHeight();
	            String elegibleChars = "ABCDEFGHJKLMNPQRSTUVWXYabcdefhjkmnpqrstuvwxy2345678";
	            char[] chars = elegibleChars.toCharArray();
	            float spaceForLetters = -horizMargin * 3 + width;
	            float spacePerChar = spaceForLetters / (charsToPrint - 1.0f);
	            StringBuffer finalString = new StringBuffer();
	            for (int i = 0; i < charsToPrint; i++) {
	                double randomValue = Math.random();
	                int randomIndex = (int) Math.round(randomValue * (chars.length - 1));
	                char characterToShow = chars[randomIndex];
	                finalString.append(characterToShow);
	                int charWidth = fontMetrics.charWidth(characterToShow);
	                int charDim = Math.max(maxAdvance, fontHeight);
	                int halfCharDim = (int) (charDim / 2);
	                BufferedImage charImage = new BufferedImage(charDim, charDim, BufferedImage.TYPE_INT_ARGB);
	                Graphics2D charGraphics = charImage.createGraphics();
	                charGraphics.translate(halfCharDim, halfCharDim);
	                double angle = (Math.random() - 0.5) * rotationRange;
	                charGraphics.transform(AffineTransform.getRotateInstance(angle));
	                charGraphics.translate(-halfCharDim, -halfCharDim);
	                charGraphics.setColor(textColor);
	                charGraphics.setFont(textFont);
	                int charX = (int) (0.5 * charDim - 0.5 * charWidth);
	                charGraphics.drawString("" + characterToShow, charX, (int) ((charDim - fontMetrics.getAscent()) / 2 + fontMetrics.getAscent()));
	                float x = horizMargin + spacePerChar * (i) - charDim / 2.0f;
	                int y = (int) ((height - charDim) / 2);
	                g.drawImage(charImage, (int) x, y, charDim, charDim, null, null);
	                charGraphics.dispose();
	            }
	            g.setColor(borderColor);
	            g.drawRect(0, 0, width - 1, height - 1);
	            g.dispose();
	            captchaString = finalString.toString();
	            ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
	            try {
	    			ImageIO.write(bufferedImage, "jpg", baos1);
	    			baos1.flush();
	    			baos1.close();
	    		} catch (IOException e) {
	    			e.getMessage();
	    		}
	            byte[] imageInByteArray = baos1.toByteArray();
	    		String b64 = javax.xml.bind.DatatypeConverter.printBase64Binary(imageInByteArray);
	    		HttpSession session = request.getSession();
	    		session.setAttribute("capcha", captchaString);
	    		return b64;
	    		
	        } catch (Exception ioe) {
	        	System.out.println("Unable to build image : "+ ioe);
	            return "Unable to build image";
	        }
		}		*/
		String captchaString = "";
		public  byte[] createQRImage(HttpServletRequest request) {
			try {
	            Color backgroundColor = Color.white;
	            Color borderColor = Color.black;
	            Color textColor = Color.black;
	            Color circleColor = new Color(190, 160, 150);
	            Font textFont = new Font("Verdana", Font.BOLD, 30);
	            int charsToPrint = 5;
	            int width = 150;
	            int height = 50;
	            int circlesToDraw = 25;
	            float horizMargin = 10.0f;
	            double rotationRange = 0.7; 
	            BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
	            Graphics2D g = (Graphics2D) bufferedImage.getGraphics();
	            g.setColor(backgroundColor);
	            g.fillRect(0, 0, width, height);

	            // lets make some noisey circles
	            g.setColor(circleColor);
	            for (int i = 0; i < circlesToDraw; i++) {
	                int L = (int) (Math.random() * height / 2.0);
	                int X = (int) (Math.random() * width - L);
	                int Y = (int) (Math.random() * height - L);
	                g.draw3DRect(X, Y, L * 2, L * 2, true);
	            }
	            g.setColor(textColor);
	            g.setFont(textFont);
	            FontMetrics fontMetrics = g.getFontMetrics();
	            int maxAdvance = fontMetrics.getMaxAdvance();
	            int fontHeight = fontMetrics.getHeight();

	            // i removed 1 and l and i because there are confusing to users...
	            // Z, z, and N also get confusing when rotated
	            // this should ideally be done for every language...
	            // 0, O and o removed because there are confusing to users...
	            // i like controlling the characters though because it helps prevent confusion
	            String elegibleChars = "ABCDEFGHJKLMNPQRSTUVWXYabcdefghjkmnpqrstuvwxy23456789";
	            char[] chars = elegibleChars.toCharArray();
	            float spaceForLetters = -horizMargin * 3 + width;
	            float spacePerChar = spaceForLetters / (charsToPrint - 1.0f);
	            StringBuffer finalString = new StringBuffer();
	            for (int i = 0; i < charsToPrint; i++) {
	                double randomValue = Math.random();
	                int randomIndex = (int) Math.round(randomValue * (chars.length - 1));
	                char characterToShow = chars[randomIndex];
	                finalString.append(characterToShow);

	                // this is a separate canvas used for the character so that
	                // we can rotate it independently
	                int charWidth = fontMetrics.charWidth(characterToShow);
	                int charDim = Math.max(maxAdvance, fontHeight);
	                int halfCharDim = (int) (charDim / 2);
	                BufferedImage charImage = new BufferedImage(charDim, charDim, BufferedImage.TYPE_INT_ARGB);
	                Graphics2D charGraphics = charImage.createGraphics();
	                charGraphics.translate(halfCharDim, halfCharDim);
	                double angle = (Math.random() - 0.5) * rotationRange;
	                charGraphics.transform(AffineTransform.getRotateInstance(angle));
	                charGraphics.translate(-halfCharDim, -halfCharDim);
	                charGraphics.setColor(textColor);
	                charGraphics.setFont(textFont);
	                int charX = (int) (0.5 * charDim - 0.5 * charWidth);
	                charGraphics.drawString("" + characterToShow, charX, (int) ((charDim - fontMetrics.getAscent()) / 2 + fontMetrics.getAscent()));
	                float x = horizMargin + spacePerChar * (i) - charDim / 2.0f;
	                int y = (int) ((height - charDim) / 2);
	                g.drawImage(charImage, (int) x, y, charDim, charDim, null, null);
	                charGraphics.dispose();
	            }
	            g.setColor(borderColor);
	            g.drawRect(0, 0, width - 1, height - 1);
	            g.dispose();
	            captchaString = finalString.toString();
	            captchaString = "12345".toString();
	           // return bufferedImage;
	            ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
	            try {
	    			ImageIO.write(bufferedImage, "jpg", baos1);
	    			baos1.flush();
	    			baos1.close();
	    		} catch (IOException e) {
	    			e.printStackTrace();
	    		}
	            byte[] imageInByteArray = baos1.toByteArray();
	            HttpSession session = request.getSession();
	    		session.setAttribute("capcha", captchaString);
	    		return imageInByteArray;
	    	} catch (Exception ioe) {
	        	byte[] imageInByteArray = null;
	            return imageInByteArray;
	        }
		}
		
		@RequestMapping(value={"/gencap","/admin/gencap"},method=RequestMethod.POST)
		@ResponseBody
		public  String CaptchaGenerate(HttpServletRequest request) {
			try {
	            
	            int charsToPrint = 5;
	            // i removed 1 and l and i because there are confusing to users...
	            // Z, z, and N also get confusing when rotated
	            // this should ideally be done for every language...
	            // 0, O and o removed because there are confusing to users...
	            // i like controlling the characters though because it helps prevent confusion
	            String elegibleChars = "ABCDEFGHJKLMNPQRSTUVWXYabcdefghjkmnpqrstuvwxy23456789";
	            char[] chars = elegibleChars.toCharArray();
	            
	            StringBuffer finalString = new StringBuffer();
	            for (int i = 0; i < charsToPrint; i++) {
	                double randomValue = Math.random();
	                int randomIndex = (int) Math.round(randomValue * (chars.length - 1));
	                char characterToShow = chars[randomIndex];
	                finalString.append(characterToShow);
	            }
	            String  captchaString = finalString.toString();
	            String enckey = "commonPwdEncKeys";
				String encrypted = "";
				try {
					Cipher c = hex_asciiDao.EncryptionSHA256Algo(request.getSession(), enckey);
					encrypted = new String(Base64.encodeBase64(c.doFinal(captchaString.getBytes())));
				} catch (Exception e) {
					e.printStackTrace();
				}
	            System.err.println("captchaString : "+encrypted);
	            HttpSession session = request.getSession();
	    		session.setAttribute("capchatest", encrypted);
	    		return encrypted;
	    	} catch (Exception ioe) {
	            return "";
	        }
		}
}