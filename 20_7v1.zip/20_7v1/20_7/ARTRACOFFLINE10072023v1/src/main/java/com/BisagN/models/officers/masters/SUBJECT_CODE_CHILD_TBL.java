package com.BisagN.models.officers.masters;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "subject_code_child_tbl", uniqueConstraints = {
@UniqueConstraint(columnNames = "sub_ch_id"),})
public class SUBJECT_CODE_CHILD_TBL {
	
	private int sub_ch_id;
	
	private int arm_id;
	private int exm_id;
	private int sub_id;
	private  String created_by;
	private  String modified_by;
	private Date created_date;
	
	private Date modified_date;
	
	
	
	
	
    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "sub_ch_id", unique = true, nullable = false)

	public int getSub_ch_id() {
		return sub_ch_id;
	}

	public void setSub_ch_id(int sub_ch_id) {
		this.sub_ch_id = sub_ch_id;
	}

	public int getArm_id() {
		return arm_id;
	}

	public void setArm_id(int arm_id) {
		this.arm_id = arm_id;
	}

	public int getExm_id() {
		return exm_id;
	}

	public void setExm_id(int exm_id) {
		this.exm_id = exm_id;
	}

	public int getSub_id() {
		return sub_id;
	}

	public void setSub_id(int sub_id) {
		this.sub_id = sub_id;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public Date getModified_date() {
		return modified_date;
	}

	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
	

    
    
    
    
    
    
	
}
 