 package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.officer.others.ExportPartBDao;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.PARTB_D_APPLICATION_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Export_PartBController {

	@Autowired
	private ExportPartBDao export;

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	CommonController comm = new CommonController();

	@RequestMapping(value = "ExportPartBUrl", method = RequestMethod.GET)
	public ModelAndView ExportPartBUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg) {

		String es_begindate = session.getAttribute("es_begin_date") == null ? ""
				: session.getAttribute("es_begin_date").toString();
		
		String es_begin_dateshow = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();
		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		
	
		int ec_exam_id = session.getAttribute("ec_exam_id") ==null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		if (ec_exam_id == 1) {
			if (!es_begin_dateshow.equals("")) {
				Mmap.put("partb_showbegindate", es_begin_dateshow);
			}
			
			 if(!es_begindate.equals("")) {
					
				 Mmap.put("partb_begindate", es_begindate.substring(0, 10));
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
			if (ec_exam_id != 0) {
				Mmap.put("ec_exam_id", ec_exam_id);
			}
		}
		Mmap.put("list", getsubjectlist());
		Mmap.put("list_size", getsubjectlist().size());
		Mmap.put("msg", msg);
		return new ModelAndView("ExportPartB_tile");
	}

	// Download DEMO EXCEL
	@RequestMapping(value = "/ExportPartB", method = RequestMethod.POST)
	public ModelAndView ExportPartB(HttpServletRequest request, ModelMap model, HttpSession session, String typeReport1,
			String exam_schedule_dt2, String min_year2, String es_consider_date3, String exam_schedule_dthid2,String max_year2)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		
		if (es_id != 0) {
//		ArrayList<ArrayList<String>> exportPartB = export.getexportPartBexmCandidateReport(0, "-1", "", "1", "ASC",
//				exam_schedule_dt2, min_year2, es_consider_date3,es_id,"excelL",typeReport1,max_year2,session);
	
			ArrayList<ArrayList<String>>exportPartB= export.getExportPartBForExcel(es_id);
		
		if (exportPartB.size() > 0) {
			List<String> TH = new ArrayList<String>();
			TH.add("SER_NO");
		
			TH.add("ARMY_NO");
			TH.add("OFFICER_NAME");
			TH.add("ARM_SERVICE");
			TH.add("DATE_OF_BIRTH");
			TH.add("COMM_DATE");
			TH.add("COMM_TYPE");
			TH.add("RANK");
			TH.add("DATE_SENIORITY");
			TH.add("SUBJECT");
			TH.add("APPLICATION_NO");
			String Heading = "\n";
			String username = session.getAttribute("username").toString();
			return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList",
					exportPartB);
		} else {
			model.put("msg", "Data Not Available.");
			return new ModelAndView("redirect:ExportPartBUrl");
		}
	}
		return null;
	}

	public @ResponseBody List<SUBJECT_CODE_M> getsubjectlist() {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query q = session.createQuery(" select sc_subject_name from SUBJECT_CODE_M where ec_exam_id='1' ");
		@SuppressWarnings("unchecked")
		List<SUBJECT_CODE_M> list = (List<SUBJECT_CODE_M>) q.list();
		tx.commit();
		session.close();
		return list;
	}

	@RequestMapping(value = "/getExportPartBReportDataList", method = RequestMethod.POST)
	public @ResponseBody ArrayList<ArrayList<String>> getexportPartBexmCandidateReport(int startPage, String pageLength,
			String Search, String orderColunm, String orderType, String exam_schedule_dt, String min_year2,
			String es_consider_date1,String btn_value,String max_year2,HttpSession sessionUserId)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		int ec_exam_id = Integer.parseInt(sessionUserId.getAttribute("ec_exam_id") == null ? "0": sessionUserId.getAttribute("ec_exam_id").toString());
		if(ec_exam_id == 1) {
		int es_id = Integer
				.parseInt(sessionUserId.getAttribute("es_id") == null ? "0" : sessionUserId.getAttribute("es_id").toString());
		if (es_id != 0) {


			return export.getexportPartBexmCandidateReport(startPage, pageLength, Search, orderColunm, orderType,
					exam_schedule_dt, min_year2, es_consider_date1,es_id,"table", btn_value,max_year2,sessionUserId);
		}
		
		}
		return null;

	}

	@RequestMapping(value = "/getExportPartBTotalCount", method = RequestMethod.POST)
	public @ResponseBody long getExportPartBTotalCount(HttpSession sessionUserId, String Search,
			String exam_schedule_dt, String min_year2, String es_consider_date1,String btn_value,String max_year2) {
		
		int ec_exam_id = Integer.parseInt(sessionUserId.getAttribute("ec_exam_id") == null ? "0": sessionUserId.getAttribute("ec_exam_id").toString());
		if(ec_exam_id == 1) {
		int es_id = Integer
				.parseInt(sessionUserId.getAttribute("es_id") == null ? "0" : sessionUserId.getAttribute("es_id").toString());
		if (es_id != 0) {
			return export.getexportPartbexmCandidatereportTotalCount(Search, exam_schedule_dt, min_year2,
					es_consider_date1,es_id,btn_value,max_year2);
		}
		
		}
		return 0;

	}

	@RequestMapping(value = "/getRuleDetailsFromExmSchedule", method = RequestMethod.POST)
	public @ResponseBody ArrayList<ArrayList<String>> getRulesDetailsFromExmSchedule(String exmsch_dt, String exm_id, String dssc_date) {

		if (!exmsch_dt.equals("")) {
			ArrayList<ArrayList<String>> list2 = export.getRulesDetailsFromExmSchedule(exmsch_dt, exm_id,dssc_date);
			System.err.println("list2------------"+list2);
			return list2;
		}
		return null;

	}

	@RequestMapping(value = "/ExportPartBAction", method = RequestMethod.POST)
	public ModelAndView ExportPartBAction(@ModelAttribute("exportBcmd") PARTB_D_APPLICATION_M partbexm1,
			BindingResult result, HttpServletRequest request, ModelMap model, HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		ArrayList<ArrayList<String>> listerror=new ArrayList<ArrayList<String>>();
		
		try {
			Date date = new Date();
			String username1 = session.getAttribute("username").toString();

			String exam_schedule_dt2 = request.getParameter("exam_schedule_dt");

			String min_year2 = request.getParameter("min_year_act");
			
			String max_year2 = request.getParameter("max_year_act");
			

			String es_consider_date1 = request.getParameter("es_consider_date");

			String exam_schedule_dthid2 = request.getParameter("exam_schedule_dthid");

			ArrayList<ArrayList<String>> exportPartB = export.getexportPartBexmCandidateReport(0, "-1", "", "1", "ASC",
					exam_schedule_dt2, min_year2, es_consider_date1,0,"","",max_year2, session);
			
			
			for (int i = 0; i < exportPartB.size(); i++) {

				Session sessionHQL1 = this.sessionFactory.openSession();
				Transaction tx1 = sessionHQL1.beginTransaction();
				
				ArrayList<String> listData = new ArrayList<String>();
				OFFICER_APPLICATION_M o_app = new OFFICER_APPLICATION_M();
				int id = o_app.getOa_application_id() > 0 ? o_app.getOa_application_id() : 0;
				
				
				System.err.println("exportPartB"+exportPartB.get(i).get(10));
				String pers_code2 = exportPartB.get(i).get(11);
//				String pers_code2 = exportPartB.get(i).get(1);
//				pers_code2 = pers_code2.substring(0, pers_code2.length() - 1);
				List<OFFICER_PERSONAL_CODE_M> opdpers_id = comm.getopdIdbycode(sessionFactory, pers_code2);
				System.err.println("pers_code2=========="+pers_code2);
		
				int opd_pers_id = opdpers_id.get(0).getOpd_personal_id();
			
				int es_id = Integer.parseInt(
						session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

				Query q0 = sessionHQL.createQuery(
						"select count(*) from OFFICER_APPLICATION_M where (es_id=:es_id and opd_personal_id=:opd_personal_id) and oa_application_id!=:oa_application_id");

				q0.setParameter("es_id", es_id);
				q0.setParameter("opd_personal_id", opd_pers_id);
				q0.setParameter("oa_application_id", id);
					Long c = (Long) q0.uniqueResult();		
					
					System.err.println("c=========="+c);
				if (c == 0) {
					o_app.setEs_id(es_id);
					o_app.setOpd_personal_id(opd_pers_id);
					o_app.setOa_created_by(username1);
					o_app.setOa_creation_date(date);
					o_app.setOa_status_id(1);
					int mid = (int) sessionHQL1.save(o_app);
					sessionHQL1.flush();
					sessionHQL1.clear();
					tx1.commit();
					sessionHQL1.close();

					PARTB_D_APPLICATION_M partbd = new PARTB_D_APPLICATION_M();

					Session sessionHQL2 = this.sessionFactory.openSession();
					Transaction tx2 = sessionHQL2.beginTransaction();

					String total_sub = exportPartB.get(i).get(10);
					partbd.setOa_application_id(mid);
					partbd.setPbda_subjects(Integer.parseInt(total_sub));
					partbd.setPbda_created_by(username1);
					partbd.setPbda_creation_date(date);
					sessionHQL2.save(partbd);
					tx2.commit();
					sessionHQL2.close();
					model.put("msg", "Data Saved Successfully.");

				}

				else {

					model.put("msg", "Data already Exist.");
				}

			}

		}

		catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return new ModelAndView("redirect:ExportPartBUrl");

	}

}
