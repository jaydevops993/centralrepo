package com.BisagN.controller.office.masters;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.Area_TypeDAO;
import com.BisagN.dao.officer.masters.SubSubjectDAO;
import com.BisagN.models.officers.masters.ARM_CODES_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST_TBL;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class SubSubjectMasterController {
	
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Autowired
	private Area_TypeDAO objDAO;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	CommonController comm= new CommonController();
	
	@Autowired
	SubSubjectDAO subsubjectDAO;
	
	  @Autowired
		private RoleBaseMenuDAO roledao; 
	
	
	@RequestMapping(value = "SearchSubSubject_master_Url", method = RequestMethod.GET)
    public ModelAndView SearchSubSubject_master_Url(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{
		
		if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

   	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("SearchSubSubject_master_Url", roleid1);		
			if(val == false) {
				return new ModelAndView("AccessTiles");
		}	
		
		  
		  
		   Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
		   Mmap.put("getctarmcodetypeListDDL",comm.getctarmcodetypeListDDL(sessionFactory));
		   
        Mmap.put("msg", msg);
    return new ModelAndView("SearchSubSubjectMstmasterTile");
}
	
	
	
	//===========================OPEN PAGE============================//
	
	
	  
	  @RequestMapping(value = "SubSubjectMasterUrl", method = RequestMethod.GET)
	  public ModelAndView SubSubjectMasterUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String Subjectid) {
	  
	  
		  Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
		   Mmap.put("getctarmcodetypeListDDL",comm.getctarmcodetypeListDDL(sessionFactory));
		   int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
		   if(ec_exam_id != 0) {
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
		   }
		Mmap.put("msg", msg);
		 
		   
        Mmap.put("msg", msg);
        
        
    return new ModelAndView("SubSubjectMstmasterTile");
}
	
		
		  @RequestMapping(value = "/getSubsubject_masterReportDataList", method = RequestMethod.POST)
		  public @ResponseBody List<Map<String, Object>> getSubsubject_masterReportDataList(int startPage,String pageLength,String Search,String orderColunm,String orderType,
				  String exam ,String ec_exam_id2,HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
			  System.err.println("exam============"+exam);
			  return subsubjectDAO.getReportListSub_Subject_master(startPage,pageLength,Search,orderColunm,orderType,exam, ec_exam_id2,sessionUserId);
		 }

		  @RequestMapping(value = "/getSubsubject_masterTotalCount", method = RequestMethod.POST)
		 public @ResponseBody long getSubsubject_masterTotalCount(String Search,String exam,String ec_exam_id2){
		 	return subsubjectDAO.getReportListSubSubject_masterTotalCount(Search,exam, ec_exam_id2);
		 }
		  
		  
		  
		  
		 @SuppressWarnings("unlikely-arg-type")
		@RequestMapping(value = "/SubSubject_MasterAction" ,method = RequestMethod.POST) 
		  public ModelAndView SubSubject_MasterAction(@Valid @ModelAttribute("SubSubject_masterCMD") SUB_SUBJECT_MST ln, BindingResult result, 
		  HttpServletRequest request, ModelMap model, HttpSession session){ 

		 

		 int errCount=0;
		 
		 String username = session.getAttribute("username").toString();
			Date date = new Date();
	   
			 int id = ln.getId() > 0 ? ln.getId() : 0;
				
				 Session sessionHQL = this.sessionFactory.openSession();
				    Transaction tx = sessionHQL.beginTransaction(); 
				    
//				    if(request.getParameter("exm_id").equals("0") || request.getParameter("exm_id")==null ||
//							request.getParameter("exm_id")=="null" || request.getParameter("exm_id").equals(null))
//					{
//						model.put("msg", "Please Select Exam Name");
//						return new ModelAndView("redirect:SubSubjectMasterUrl");
//					}
//				    
//				    
//				    if(request.getParameter("sub_id").equals("0") || request.getParameter("sub_id")==null ||
//							request.getParameter("sub_id")=="null" || request.getParameter("sub_id").equals(null))
//					{
//						model.put("msg", "Please Select Subject Name");
//						return new ModelAndView("redirect:SubSubjectMasterUrl");
//					}
//				    
//				    if(request.getParameter("sub_subject").equals("") || request.getParameter("sub_subject")==null ||
//							request.getParameter("sub_subject")=="null" || request.getParameter("sub_subject").equals(null))
//					{
//						model.put("msg", "Please Enter Sub Subject ");
//						return new ModelAndView("redirect:SubSubjectMasterUrl");
//					}
			
				    
					   
					   String exm_id= request.getParameter("exm_id");
					   String subject_id= request.getParameter("sub_id");
					   String arm_id = request.getParameter("sub_arm_name_id");

				try {
					
					if(!arm_id.equals("")) {
						
						 
						 System.err.println("arm_id==========="+arm_id);
						String[] arrOfStr = arm_id.split(",");

						 ArrayList<String> strList = new ArrayList<String>(
						            Arrays.asList(arrOfStr));
						 
						 
						for (int i=1;i<=strList.size();i++)
						 {
					Query q0 = sessionHQL.createQuery(
							"select count(id) from SUB_SUBJECT_MST where   LOWER(sub_subject)=:sub_subject and sub_spl_arm=:sub_spl_arm and"
							+ "  sc_subject_id=:sc_subject_id");

					q0.setParameter("sub_subject", request.getParameter("sub_subject"));
					q0.setParameter("sub_spl_arm", Integer.parseInt(arrOfStr[i-1]));
					q0.setParameter("sc_subject_id", Integer.parseInt(subject_id));
					Long c = (Long) q0.uniqueResult();

					
					if (id == 0) {
						
						
						if (c == 0) {
					
										
												Session sessionHQL2 = this.sessionFactory.openSession();
												Transaction tx2 = sessionHQL2.beginTransaction();
											
												ln.setSub_spl_arm(Integer.parseInt(arrOfStr[i-1]));
										
												List<ARM_CODES_M>arm_name=comm.getarmNameByArmID(sessionFactory, Integer.parseInt(arrOfStr[i-1]));
												String Arm_name= arm_name.get(0).getAc_arm_description();
												ln.setSub_subject(Arm_name);
												ln.setCreated_date(date);
												ln.setCreated_by(username);
												ln.setSub_subject(request.getParameter("sub_subject"));
												ln.setSc_subject_id(Integer.parseInt(subject_id));
												ln.setSubsubject_status(1);
								 sessionHQL2.save(ln);
									tx2.commit();
									model.put("msg", "Data Saved Successfully.");
							
						 }	
						
						else if (c>0) {
							Query q1 = sessionHQL.createQuery(
									"select id from SUB_SUBJECT_MST where   LOWER(sub_subject)=:sub_subject and sub_spl_arm=:sub_spl_arm and"
									+ "  sc_subject_id=:sc_subject_id and subsubject_status=:subsubject_status");

							q1.setParameter("sub_subject", request.getParameter("sub_subject"));
							q1.setParameter("sub_spl_arm", Integer.parseInt(arrOfStr[i-1]));
							q1.setParameter("sc_subject_id", Integer.parseInt(subject_id));
							q1.setParameter("subsubject_status", 0);
							
							int c2 = (int) q1.uniqueResult();
							
							System.err.println("c2========="+c2);
							
							if (c2  != 0) {
								Session sessionHQL2 = this.sessionFactory.openSession();
								Transaction tx2 = sessionHQL2.beginTransaction();

								ln.setSub_spl_arm(Integer.parseInt(arrOfStr[i - 1]));
								ln.setSc_subject_id(Integer.parseInt(request.getParameter("sub_id")));
								ln.setSub_subject(request.getParameter("sub_subject"));
								ln.setSubsubject_status(1);
								ln.setModified_by(username);
								ln.setModified_date(date);
								ln.setId(c2);
								sessionHQL2.saveOrUpdate(ln);
								tx2.commit();
								
								model.put("msg", "Data Saved Successfully.");
							} 
						}
						
						else {
							model.put("msg", "Data already Exist.");
						}
										}	
					
					}
								
							 
						} 
					

				

				
				
				} catch (RuntimeException e) {
					try {
						tx.rollback();
						model.put("msg", "roll back transaction");
					} catch (RuntimeException rbe) {
						model.put("msg", "Couldn�t roll back transaction " + rbe);
					}
					throw e;
				} finally {
					if (sessionHQL != null) {
						sessionHQL.close();
					}
				}

				return new ModelAndView("redirect:SearchSubSubject_master_Url");
			}
		
		 @RequestMapping(value = "EditSubSubject_masterUrl", method = RequestMethod.POST)
	      public ModelAndView EditSubSubject_masterUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String updateid) {


	             Session s1 = this.sessionFactory.openSession();
	             Transaction tx = s1.beginTransaction();
	             String enckey = "commonPwdEncKeys";  
	             String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
	             
	             System.err.println("DcryptedPk================"+DcryptedPk);
	             Query q = null;
	             q = s1.createQuery("from SUB_SUBJECT_MST where cast(id as string)=:PK");
	             q.setString("PK", DcryptedPk);
	             @SuppressWarnings("unchecked")
	             List<SUB_SUBJECT_MST> list = (List<SUB_SUBJECT_MST>) q.list();
	             
	            
	             tx.commit();
	             s1.close();
	             Mmap.put("getecexamnameListDDL2", comm.getecexamnameListDDL(sessionFactory));
	             Mmap.put("getctarmcodetypeListDDL",comm.getctarmcodetypeListDDL(sessionFactory));
	             
	             
	             Mmap.put("editexamination_masterCMD1", list.get(0));
	             int subSubjectId= list.get(0).getSc_subject_id();
	             int subjectid=list.get(0).getSc_subject_id();
	             Mmap.put("subSubjectId", subSubjectId);
	             List<SUBJECT_CODE_M>getsubjectid=comm.getSubjectIdBySubName(sessionFactory, subjectid);
	             Mmap.put("getExamID", getsubjectid.get(0).getEc_exam_id());
	             int ec_exam_id=getsubjectid.get(0).getEc_exam_id();
	             Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
	             Mmap.put("EditSubchildDetails", subsubjectDAO.getarmcodeforSubsubjectmst(subSubjectId, Integer.parseInt(DcryptedPk)));
	             Mmap.put("msg", msg);
	             Mmap.put("subSubjectId", subSubjectId);
	             Mmap.put("EditSubchildDetailssize", subsubjectDAO.getarmcodeforSubsubjectmst(subSubjectId,Integer.parseInt(DcryptedPk)).size());
	             
	             
	      return new ModelAndView("EditSubSubjectmasterTile");
	}
		 @RequestMapping(value = "/EditSubSubject_MasterAction" ,method = RequestMethod.POST) 
		  public ModelAndView EditSubSubject_MasterAction(@Valid @ModelAttribute("EditSubSubject_masterCMD") SUB_SUBJECT_MST ln, BindingResult result, 
		  HttpServletRequest request, ModelMap model, HttpSession session){ 


		  int errCount=0;

		
				

		  Date date = new Date();
		  String username = session.getAttribute("username").toString(); 
		 
		   String ec_exam_id = request.getParameter("ec_exam_id");
			Session sessionHQL = this.sessionFactory.openSession();
			Transaction tx = sessionHQL.beginTransaction();
			
//			 if(request.getParameter("ec_exm_id").equals("0") || request.getParameter("ec_exm_id")==null ||
//						request.getParameter("ec_exm_id")=="null" || request.getParameter("ec_exm_id").equals(null))
//				{
//					model.put("msg", "Please Select Exam Name");
//					return new ModelAndView("redirect:SubSubjectMasterUrl");
//				}
//			    
//			    
//			    if(request.getParameter("sub_id").equals("0") || request.getParameter("sub_id")==null ||
//						request.getParameter("sub_id")=="null" || request.getParameter("sub_id").equals(null))
//				{
//					model.put("msg", "Please Select Subject Name");
//					return new ModelAndView("redirect:SubSubjectMasterUrl");
//				}
//			    
//			    if(request.getParameter("sub_subject").equals("") || request.getParameter("sub_subject")==null ||
//						request.getParameter("sub_subject")=="null" || request.getParameter("sub_subject").equals(null))
//				{
//					model.put("msg", "Please Enter Sub Subject ");
//					return new ModelAndView("redirect:SubSubjectMasterUrl");
//				}
		   try {
		  	 
		  	 
//		  	 String hql1 = "delete from SUB_SUBJECT_CHILD_tbl where sc_subject_id=:sc_subject_id";
//		  		Query query1 = sessionHQL.createQuery(hql1)
//		  					.setParameter("sc_subject_id",Integer.parseInt(request.getParameter("sub_id")));
//		  		query1.executeUpdate();
		  		
//		  		Session sessionHQL1 = this.sessionFactory.openSession();
//				Transaction tx1 = sessionHQL1.beginTransaction();
//		  		 String sub_tb_id=request.getParameter("id");
//		  		 
//		  		 System.err.println("subject============"+request.getParameter("sub_id"));
//		  		ln.setSc_subject_id(Integer.parseInt(request.getParameter("sub_id")));
//		  		ln.setSub_subject(request.getParameter("sub_subject"));
//		  		ln.setSubsubject_status(1);
//		  		ln.setModified_by(username);
//		  		ln.setModified_date(date);
//		  		sessionHQL1.saveOrUpdate(ln); 
//		  		tx1.commit(); 
		  		 String arm_id = request.getParameter("sub_arm_name_id");
					String[] arrOfStr = arm_id.split(",");
					 ArrayList<String> strList = new ArrayList<String>(
					            Arrays.asList(arrOfStr));
						if(!arm_id.equals("")) {
							
							 
							
							
					 for (int i=1;i<=strList.size();i++)
					 {
						 
						 Query q0 = sessionHQL.createQuery(
									"select count(id) from SUB_SUBJECT_MST where   LOWER(sub_subject)=:sub_subject and sub_spl_arm=:sub_spl_arm and"
									+ "  sc_subject_id=:sc_subject_id and subsubject_status=:subsubject_status");

							q0.setParameter("sub_subject", request.getParameter("sub_subject").toLowerCase());
							q0.setParameter("sub_spl_arm", Integer.parseInt(arrOfStr[i-1]));
							q0.setParameter("sc_subject_id", Integer.parseInt(request.getParameter("sub_id")));
							q0.setParameter("subsubject_status", 1);
							
							Long c = (Long) q0.uniqueResult();
							
							System.err.println("c==========="+c);
							
							if (c == 0) {

								Session sessionHQL2 = this.sessionFactory.openSession();
								Transaction tx2 = sessionHQL2.beginTransaction();

								ln.setSub_spl_arm(Integer.parseInt(arrOfStr[i - 1]));
								ln.setSc_subject_id(Integer.parseInt(request.getParameter("sub_id")));
								ln.setSub_subject(request.getParameter("sub_subject"));
								ln.setSubsubject_status(1);
								ln.setModified_by(username);
								ln.setModified_date(date);

								sessionHQL2.save(ln);
								tx2.commit();
							}
					
					 }
						}
		  		

		  		}catch(RuntimeException e){
		  			e.printStackTrace();
		  			tx.rollback();
		  			
		  			model.put("msg","Server side Error");
		  			
		  		}
		   
		   
		   model.put("msg","Data Updated Successfully"); 
		   return new ModelAndView("redirect:SearchSubSubject_master_Url"); 
		  } 
		  
		  
		  
		  
	@RequestMapping(value = "/deleteSubsubject_code_masterUrl", method = RequestMethod.POST) 
	public ModelAndView deleteSubsubject_code_masterUrl(String deleteid,HttpSession session,ModelMap model) { 
		List<String> list = new ArrayList<String>(); 
		list.add(subsubjectDAO.DeleteSubSubject_master(deleteid,session)); 
		model.put("msg",list);  
	 return new ModelAndView("redirect:SearchSubSubject_master_Url"); 
		}

}

