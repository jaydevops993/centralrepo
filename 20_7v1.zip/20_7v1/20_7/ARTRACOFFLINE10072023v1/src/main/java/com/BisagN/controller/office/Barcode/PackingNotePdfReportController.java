package com.BisagN.controller.office.Barcode;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Date; 

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.Barcode.MasterABPdfController.ImageBackgroundEvent;
import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPTableEvent;
import com.lowagie.text.pdf.PdfWriter;

public class PackingNotePdfReportController  extends AbstractPdfView{
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public PackingNotePdfReportController(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		document.setPageSize(PageSize.A4.rotate());
		
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
//		response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		String es_year1 =  (String) model.get("es_year1");
		String exam_name =  (String) model.get("exam_name");
		String packing_note_name_hid1 =  (String) model.get("packing_note_name_hid1");
		String ActiveSubName =  (String) model.get("ActiveSubName");
		String Bundle =  (String) model.get("Bundle");
//		int begindateShow =  (int) model.get("begindateShow");
		
		
		
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
//		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 1);
		Font fontTableHeadingSubMainHead1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 0);
//		Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		
		
		Chunk underline1 = new Chunk("PACKING NOTE", fontTableHeading1);
		underline1.setUnderline(0.1f, -2f);
		
		Phrase ph = new Phrase(underline1);
		ph.add("\n");
		ph.add("\n");
		ph.add("\n");
		ph.setFont(fontTableHeading1);

		
		Paragraph cell = new Paragraph(ph);
		cell.setAlignment(Element.ALIGN_LEFT);
		
		cell.setAlignment(Element.ALIGN_LEFT);
		
		
		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(100);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell);
		
		
		
		PdfPTable table1 = new PdfPTable(6);
		table1.setWidths(new int[] {3,3,3,3,3,3});
		table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
		table1.getDefaultCell().setVerticalAlignment(Element.ALIGN_RIGHT);
		table1.setWidthPercentage(100);
		
		Paragraph a_1 = new Paragraph("Exam:",fontTableHeadingSubMainHead);
		Paragraph b_1 = new Paragraph(exam_name + " - " + es_year1,fontTableHeadingSubMainHead1);
		Paragraph c_1 = new Paragraph("Packing Note:",fontTableHeadingSubMainHead);
		Paragraph d_1 = new Paragraph(packing_note_name_hid1,fontTableHeadingSubMainHead1);
		

		
		Paragraph i_1 = new Paragraph("Subject:",fontTableHeadingSubMainHead);
		Paragraph j_1 = new Paragraph(ActiveSubName,fontTableHeadingSubMainHead1);
		
		
		 PdfPCell cella_1;
		 cella_1 = new PdfPCell(a_1);
		 cella_1.setHorizontalAlignment(Element.ALIGN_RIGHT);
		 cella_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell cellb_1;
		 cellb_1 = new PdfPCell(b_1);
		 cellb_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 cellb_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell cellc_1;
		 cellc_1 = new PdfPCell(c_1);
		 cellc_1.setHorizontalAlignment(Element.ALIGN_RIGHT);
		 cellc_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell celld_1;
		 celld_1 = new PdfPCell(d_1);
		 celld_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 celld_1.setBorder(Rectangle.NO_BORDER);
//		 
		 
		
		 
		 
		 PdfPCell celli_1;
		 celli_1 = new PdfPCell(i_1);
		 celli_1.setHorizontalAlignment(Element.ALIGN_RIGHT);
		 celli_1.setBorder(Rectangle.NO_BORDER);
		 PdfPCell cellj_1;
		 cellj_1 = new PdfPCell(j_1);
		 cellj_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 cellj_1.setBorder(Rectangle.NO_BORDER);
		
		 
		
		 
		 
		 
		 
		
		
		
		 table1.addCell(cella_1);
		 table1.addCell(cellb_1);
		 table1.addCell(cellc_1);
		 table1.addCell(celld_1);
		 table1.addCell(celli_1);
		 table1.addCell(cellj_1);
		 

		
		
		
		
		PdfPTable tabledata = new PdfPTable(5);
		tabledata.setWidths(new int[] {2,5,5,5,5});
		tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata.setWidthPercentage(80);
		
		ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");
		
		Paragraph a = new Paragraph("Ser No",fontTableHeadingSubMainHead);
		Paragraph b = new Paragraph("Bundle No",fontTableHeadingSubMainHead);
		Paragraph c = new Paragraph("No of Candidates",fontTableHeadingSubMainHead);
		Paragraph d = new Paragraph("No of ABs",fontTableHeadingSubMainHead);
		Paragraph e= new Paragraph("Remarks",fontTableHeadingSubMainHead);
		
		
		 PdfPCell blank_cella;
		 blank_cella = new PdfPCell(a);
//		 blank_cella.addElement(a);
		 blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella.setPadding(8);
		 
		 PdfPCell blank_cellb;
		 blank_cellb = new PdfPCell(b);
//		 blank_cellb.addElement(b);
		 blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cellb.setPadding(8);
		 
		 PdfPCell blank_cellc;
		 blank_cellc = new PdfPCell(c);
//		 blank_cellc.addElement(c);
		 blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cellc.setPadding(8);
		 
		 PdfPCell blank_celld;
		 blank_celld = new PdfPCell(d);
//		 blank_celld.addElement(d);
		 blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_celld.setPadding(8);
		 
		 
		 PdfPCell blank_celle;
		 blank_celle = new PdfPCell(e);
//		 blank_celld.addElement(d);
		 blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_celle.setPadding(8);
		 
		 
		 
		 
		 
			 tabledata.addCell(blank_cella);
			 tabledata.addCell(blank_cellb);
			 tabledata.addCell(blank_cellc);
			 tabledata.addCell(blank_celld);
			 tabledata.addCell(blank_celle);
			 
		 int  index=1;
		 
		 System.err.println("list==========="+list.size());
		 for(int i=0;i<list.size();i++)
		 { 
			 
			 List<String> l = list.get(i);
		 Paragraph a1index = new Paragraph(String.valueOf(index),fontTableHeadingdata);
		 Paragraph packing_name = new Paragraph(l.get(2),fontTableHeadingdata);
		 Paragraph no_candidates = new Paragraph(l.get(3),fontTableHeadingdata);
		 Paragraph no_abs = new Paragraph(l.get(4),fontTableHeadingdata);
		 Paragraph remarks = new Paragraph("",fontTableHeadingdata);
		 
		 
		 
		 PdfPCell cell2 = new PdfPCell();
		 
			 tabledata.addCell(a1index);
			 cell2.setPhrase(packing_name);
			 //cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
			 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			 tabledata.addCell(cell2);
			 cell2.setPhrase(no_candidates);
			 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			 tabledata.addCell(cell2);
			 cell2.setPhrase(no_abs); 
			 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			 tabledata.addCell(cell2);
			 
			 cell2.setPhrase(remarks);
			 tabledata.addCell(cell2);
			 
			 index+=1;
			 
			 
		
		 }
		
		   int sum = 0; 
		   for (int i = 0; i < list.size(); i++) {  
			   
			   String total_cand =list.get(i).get(3);
	           sum = sum + Integer.parseInt(total_cand);  
	        } 
		   
		   int sum2 = 0; 
		   for (int i = 0; i < list.size(); i++) {  
			   
			   String total_abs =list.get(i).get(4);
			   System.err.println("total_abs========="+total_abs);
	           sum2 = sum2 + Integer.parseInt(total_abs);  
	           System.err.println("sum2========="+sum2);
	        } 
		   
		
		 Paragraph blank1 = new Paragraph("\t \t \t \t \t \t \t \t \t \t \t \t \t Total Bundles: "+list.size()+"" + "\t \t \t \t \t \t \t "+  "Total Candidates:  "+sum+" "  + "\t \t \t \t \t \t \t \t"+ "Total ABs: "+sum2+""   , fontTableHeadingSubMainHead);
		 
		 PdfPCell blank_cella1;
		 blank_cella1 = new PdfPCell();
		 blank_cella1.setColspan(8);
		 blank_cella1.addElement(blank1);
		 blank_cella1.setHorizontalAlignment(Element.ALIGN_CENTER);
		 
		 tabledata.addCell(blank_cella1); 
			 
		 
		 
	
		 
		 PdfPTable table_3 = new PdfPTable(4);
		 table_3.setWidths(new int[] {5,5,5,5});
		 table_3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		 table_3.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		 table_3.setWidthPercentage(80);
		 
		 
		 
		 Paragraph a3_1 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_2 = new Paragraph("",fontTableHeadingSubMainHead);
		 Paragraph a3_3= new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_4 = new Paragraph("",fontTableHeadingSubMainHead1);
		
		 Paragraph a3_5 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_6 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_7= new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_8 = new Paragraph("",fontTableHeadingSubMainHead1);
		 
//		 LocalDate Todays_date = java.time.LocalDate.now();
//		 String newDate = new SimpleDateFormat("dd-MM-yyyy").format(Todays_date);
		 
		 SimpleDateFormat formDate = new SimpleDateFormat("dd-MM-yyyy");
	     String strDate = formDate.format(new Date()); 
		 Paragraph a3_9 = new Paragraph("Date : "+ strDate,fontTableHeadingSubMainHead1);
		 Paragraph a3_10 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_11= new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_12 = new Paragraph("\n\n..............................",fontTableHeadingSubMainHead1);
		 
		 Paragraph a3_13 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_14 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_15= new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_16 = new Paragraph("Signature of Presiding Officer (Indexing Group)",fontTableHeadingSubMainHead1);
		 
		 Paragraph a3_17 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_18 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_19= new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_20 = new Paragraph("",fontTableHeadingSubMainHead1);
		 
		 
		 Paragraph a3_21 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_22 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_23= new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_24 = new Paragraph("",fontTableHeadingSubMainHead1);
		 
		 
		 
		 
		 
		 PdfPCell blank_cella3_1;
		 blank_cella3_1 = new PdfPCell(a3_1);
		 blank_cella3_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_1.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_2;
		 blank_cella3_2 = new PdfPCell(a3_2);
		 blank_cella3_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_3;
		 blank_cella3_3 = new PdfPCell(a3_3);
		 blank_cella3_3.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_3.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_4;
		 blank_cella3_4 = new PdfPCell(a3_4);
		 blank_cella3_4.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_4.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 PdfPCell blank_cella3_5;
		 blank_cella3_5 = new PdfPCell(a3_5);
		 blank_cella3_5.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_5.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_6;
		 blank_cella3_6 = new PdfPCell(a3_6);
		 blank_cella3_6.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_6.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_7;
		 blank_cella3_7 = new PdfPCell(a3_7);
		 blank_cella3_7.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_7.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_8;
		 blank_cella3_8 = new PdfPCell(a3_8);
		 blank_cella3_8.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_8.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 PdfPCell blank_cella3_9;
		 blank_cella3_9 = new PdfPCell(a3_9);
		 blank_cella3_9.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_9.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_10;
		 blank_cella3_10 = new PdfPCell(a3_10);
		 blank_cella3_10.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_10.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_11;
		 blank_cella3_11 = new PdfPCell(a3_11);
		 blank_cella3_11.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_11.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_12;
		 blank_cella3_12 = new PdfPCell(a3_12);
		 blank_cella3_12.setHorizontalAlignment(Element.ALIGN_CENTER);
//		 blank_cella3_12.setPaddingBottom(100);
		 blank_cella3_12.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 
		 PdfPCell blank_cella3_13;
		 blank_cella3_13 = new PdfPCell(a3_13);
		 blank_cella3_13.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_13.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_14;
		 blank_cella3_14 = new PdfPCell(a3_14);
		 blank_cella3_14.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_14.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_15;
		 blank_cella3_15 = new PdfPCell(a3_15);
		 blank_cella3_15.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_15.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_16;
		 blank_cella3_16 = new PdfPCell(a3_16);
		 blank_cella3_16.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_16.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 
		 
		 PdfPCell blank_cella3_17;
		 blank_cella3_17 = new PdfPCell(a3_17);
		 blank_cella3_17.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_17.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_18;
		 blank_cella3_18 = new PdfPCell(a3_18);
		 blank_cella3_18.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_18.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_19;
		 blank_cella3_19 = new PdfPCell(a3_19);
		 blank_cella3_19.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_19.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_20;
		 blank_cella3_20 = new PdfPCell(a3_20);
		 blank_cella3_20.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_20.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 
		 PdfPCell blank_cella3_21;
		 blank_cella3_21 = new PdfPCell(a3_21);
		 blank_cella3_21.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_21.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_22;
		 blank_cella3_22 = new PdfPCell(a3_22);
		 blank_cella3_22.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_22.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_23;
		 blank_cella3_23 = new PdfPCell(a3_23);
		 blank_cella3_23.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_23.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_24;
		 blank_cella3_24 = new PdfPCell(a3_24);
		 blank_cella3_24.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_24.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 table_3.addCell(blank_cella3_1);
		 table_3.addCell(blank_cella3_2);
		 table_3.addCell(blank_cella3_3);
		 table_3.addCell(blank_cella3_4);
		 table_3.addCell(blank_cella3_5);
		 table_3.addCell(blank_cella3_6);
		 table_3.addCell(blank_cella3_7);
		 table_3.addCell(blank_cella3_8);
		 
		 table_3.addCell(blank_cella3_17);
		 table_3.addCell(blank_cella3_18);
		 table_3.addCell(blank_cella3_19);
		 table_3.addCell(blank_cella3_20);
		 table_3.addCell(blank_cella3_21);
		 table_3.addCell(blank_cella3_22);
		 table_3.addCell(blank_cella3_23);
		 table_3.addCell(blank_cella3_24);
		 table_3.addCell(blank_cella3_9);
		 table_3.addCell(blank_cella3_10);
		 table_3.addCell(blank_cella3_11);
		 table_3.addCell(blank_cella3_12);
		 table_3.addCell(blank_cella3_13);
		 table_3.addCell(blank_cella3_14);
		 table_3.addCell(blank_cella3_15);
		 table_3.addCell(blank_cella3_16);
			 

		PdfPCell cell123;
		cell123 = new PdfPCell();
		
		cell123.addElement(tableheader);
		cell123.addElement(table1);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tabledata);
		
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(table_3);
		cell123.setBorder(0);
		table.addCell(cell123);
//		table.setTableEvent(new ImageBackgroundEvent(request,list.get(0).get(5),list.get(0).get(5) ));  // use for watermark
		document.add(table);
		super.buildPdfMetadata(model, document, request);
	}
	int page = 1;
	class ImageBackgroundEvent implements PdfPTableEvent {
		protected Image image;
		HttpServletRequest request;
		String created_by;
		String ce_created_date;
		
		ImageBackgroundEvent(HttpServletRequest request,String created_by,String ce_created_date){
			this.request = request;
			this.created_by = created_by;
			this.ce_created_date = ce_created_date;
		}
		
		public void tableLayout(PdfPTable table, float[][] widths, float[] heights, int headerRows, int rowStart,PdfContentByte[] canvases) {
			String ip = "";
			if (request != null) {
		        ip = request.getHeader("X-FORWARDED-FOR");
		        if (ip == null || "".equals(ip)) {
		            ip = request.getRemoteAddr();
		        }
		    }
			
			Date now = new Date();
			String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
			String watermark = " Generated by "+created_by +" on   " +dateString ; //by "+username+"
			
			Image img = null;
			BufferedImage bufferedImage = new BufferedImage((int) table.getTotalWidth(), 30,BufferedImage.TYPE_INT_ARGB);
			Graphics graphics = bufferedImage.getGraphics();
			//graphics.setColor(Color.lightGray);
			graphics.setColor(Color.decode("#f2f2f2")); //#e6e6e6
			//graphics.setFont(new java.awt.Font("Arial Black", Font.NORMAL, 12));
			//graphics.drawString(watermark+watermark,0, 20);
			graphics.setFont(new java.awt.Font("Arial Black", Font.NORMAL, 20));
			graphics.drawString(watermark,0, 20);
			try {
				try {
					img = Image.getInstance(bufferedImage, null);
				} catch (IOException e) {
					e.getMessage();
				}
			} catch (BadElementException e) {
				e.getMessage();
			}
			this.image = img;
			
			try {
				PdfContentByte cb = canvases[PdfPTable.BACKGROUNDCANVAS];

				/*int tableWidth = (int) table.getTotalWidth();
				int first = 0;
				if (tableWidth == 523) {
					first = 750;
				}
				if (tableWidth == 770) {
					first = 440;
				}

				int last = first - (int) table.getRowHeight(0);
		        while (first > last) {
					image.setAbsolutePosition(40, first);
					cb.addImage(image, false);
					first -= 30;
				}*/
		        
		        // Portrait Page size 700 * 523
				// Landscape page size 453 * 770
				int tableWidth = (int) table.getTotalWidth();
				if (tableWidth == 523) {  // Portrait page
					image.setAbsolutePosition(60, 300);  // image.setAbsolutePosition(left-right, up-down);
					image.setRotationDegrees(0-50);      // image.setRotationDegrees(0-degree rotate);
					cb.addImage(image, false);
				}
				if (tableWidth == 770) { // landscape page
					image.setAbsolutePosition(40, 50);
					image.setRotationDegrees(30);
					cb.addImage(image, false);
				}
			} catch (DocumentException e) {
				throw new ExceptionConverter(e);
			}
		}
	}
}
