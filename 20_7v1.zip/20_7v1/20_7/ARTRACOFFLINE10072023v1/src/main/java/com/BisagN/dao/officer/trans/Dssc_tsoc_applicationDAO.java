package com.BisagN.dao.officer.trans;

import java.util.List;
import java.util.Map;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import org.apache.commons.codec.binary.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import org.hibernate.Session;
import java.util.ArrayList;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;


public interface Dssc_tsoc_applicationDAO {

	  public ArrayList<ArrayList<String>> getexportDSSCTSOCexmCandidateReport(int startPage, String pageLength, String Search,
				String orderColunm, String orderType, String exam_schedule_dt2, String min_year2,String es_consider_date1,int es_id,String table,String btn_value, 
				String partb_status,String partd_status,String dssc_month,String dssc_chance,String es_year,HttpSession session)
				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	
	public long getexportDSSCTSOCCandidatereportTotalCount(String Search, String exam_schedule_dt2,String min_year2,String es_consider_date1,int es_id,String btn_value,String partb_status,String partd_status,String dssc_month,
			String dssc_chance,String es_year);
	
	
	 public List<Map<String, Object>> getCourseDetails(String course_id);
	  public ArrayList<ArrayList<String>> getManualDSSCRulesappdetails(int opd_personal_id, String exmsch_dt,String exam_schedule_dt, String min_year, String dscc_schedule_dt);
	   public ArrayList<ArrayList<String>> getDSSCDSTSCexmApplicationReport(int startPage, String pageLength, String Search,
				String orderColunm, String orderType,String pers_no, String pers_name, String center, String opd_arm_service,int es_id,HttpSession session)
				throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
				InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	   public long getDSSCDSTSCexmApplicationReportTotalCount(String Search,String pers_no, String pers_name,String center, String opd_arm_service,int es_id);
}
