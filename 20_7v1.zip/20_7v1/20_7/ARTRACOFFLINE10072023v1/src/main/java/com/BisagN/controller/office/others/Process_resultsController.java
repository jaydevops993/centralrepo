package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.trans.Examination_centreController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.officer.others.ExaminationlockunlockDAO;
import com.BisagN.dao.officer.others.ProcessResultDao;
import com.BisagN.dao.officer.report.PartB_ReportDAO;
import com.BisagN.dao.officer.report.PartD_ReportDAO;
import com.BisagN.dao.officer.trans.Unfair_meansDAO;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.trans.TB_PARTPASS_FULLPASS_DTL;
import com.BisagN.models.officers.trans.UNFAIR_MEANS_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class Process_resultsController {

	@Autowired
	private Unfair_meansDAO objDAO;

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	CommonController comm = new CommonController();

	@Autowired
	ExaminationlockunlockDAO exmlkunlkDao;

	@Autowired
	PartB_ReportDAO partbreportDao;
	
	@Autowired
	ProcessResultDao prsDao;
	
	@Autowired
	PartD_ReportDAO partDreportDao;

	@RequestMapping(value = "Process_results_Url_PartB", method = RequestMethod.GET)
	public ModelAndView Process_results_Url_PartB(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
		
		
		
		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();	
		System.err.println("es_begindate==========="+es_begindate);
	
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		if (ec_exam_id == 1) {
			Mmap.put("ec_exam_id", ec_exam_id);
			
			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
			if (!es_begindate.equals("")) {
				Mmap.put("partb_begindate", es_begindate);
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
			
		}
		
		Mmap.put("msg", msg);
		return new ModelAndView("Process_results_tile");
	}
	
	
	@RequestMapping(value = "Process_results_Url_PartD", method = RequestMethod.GET)
	public ModelAndView Process_results_Url_PartD(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {
		
		
		
		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();	
		System.err.println("es_begindate==========="+es_begindate);
	
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		if (ec_exam_id == 2) {
			
			Mmap.put("ec_exam_id", ec_exam_id);
			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
			if (!es_begindate.equals("")) {
				Mmap.put("partd_begindate", es_begindate);
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
			
		}
		
		Mmap.put("msg", msg);
		return new ModelAndView("Process_results_tile");
	}

	@RequestMapping(value = "/Process_resultsAction", method = RequestMethod.POST)
	public ModelAndView Process_resultsAction(@ModelAttribute("Process_resultCMD") TB_PARTPASS_FULLPASS_DTL pfd,
			BindingResult result, HttpServletRequest request, ModelMap model, HttpSession session) {
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();

		
		int id = pfd.getId() > 0 ? pfd.getId() : 0;
		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());

		String es_begindate = session.getAttribute("es_begin_date") == null ? ""
				: session.getAttribute("es_begin_date").toString();
		String es_year = es_begindate.split("-")[0];
		int ec_exam_id = Integer.parseInt(session.getAttribute("ec_exam_id") == null ? "0" : session.getAttribute("ec_exam_id").toString());
		
		try {
			
			Query q0 = sessionHQL.createQuery("select count(*) from TB_PARTPASS_FULLPASS_DTL where es_id=:es_id ");

			q0.setParameter("es_id", es_id);
			Long c = (Long) q0.uniqueResult();

				if (c == 0) {
//					
					
					
				
					ArrayList<ArrayList<String>> Fully_list = prsDao.getFullyPassedForProcessResult(es_id, "", ec_exam_id);
					//System.err.println("Fully_list============="+Fully_list.size());
					for(int i=0;i<Fully_list.size();i++) {
						Session sessionHQL1 = this.sessionFactory.openSession();
						Transaction tx1 = sessionHQL1.beginTransaction();
						
						String ser_no= Fully_list.get(i).get(0);
						String opd_id= Fully_list.get(i).get(5);
						String oapp_id= Fully_list.get(i).get(6);
						
						
						pfd.setEs_id(es_id);
						pfd.setOpd_personal_id(Integer.parseInt(opd_id));
						pfd.setResult(1);
						pfd.setSer_no(Integer.parseInt(ser_no));
						pfd.setOa_app_id(Integer.parseInt(oapp_id));
						sessionHQL1.save(pfd);
						sessionHQL1.flush();
						sessionHQL1.clear();
						tx1.commit();
						model.put("msg", "Data Saved Successfully");
				
					
						
					}
					
					
					if(ec_exam_id == 1) {
						
						ArrayList<ArrayList<String>> b_Part_list = partbreportDao.getPartPassedandFailures(es_year,"");
						for(int i=0;i<b_Part_list.size();i++) {
							Session sessionHQL1 = this.sessionFactory.openSession();
							Transaction tx1 = sessionHQL1.beginTransaction();
							
							String ser_no= b_Part_list.get(i).get(0);
							String opd_id= b_Part_list.get(i).get(11);
							String pbda_code= b_Part_list.get(i).get(12);
							String oapp_id= b_Part_list.get(i).get(13);
							
							pfd.setEs_id(es_id);
							pfd.setOpd_personal_id(Integer.parseInt(opd_id));
							pfd.setResult(0);
							pfd.setSer_no(Integer.parseInt(ser_no));
							pfd.setPbda_code(Integer.parseInt(pbda_code));
							pfd.setOa_app_id(Integer.parseInt(oapp_id));
							sessionHQL1.save(pfd);
							sessionHQL1.flush();
							sessionHQL1.clear();
							tx1.commit();
							model.put("msg", "Data Saved Successfully");
					
						
							
						}
						
					}
					if(ec_exam_id == 2) {
					ArrayList<ArrayList<String>>D_Part_list=partDreportDao.getPartPassedandFailuresForPartD( es_year, "");
					for(int i=0;i<D_Part_list.size();i++) {
						Session sessionHQL1 = this.sessionFactory.openSession();
						Transaction tx1 = sessionHQL1.beginTransaction();
						
						String ser_no= D_Part_list.get(i).get(0);
						String opd_id= D_Part_list.get(i).get(12);
						String pbda_code= D_Part_list.get(i).get(13);
						String oapp_id= D_Part_list.get(i).get(14);
						
						pfd.setEs_id(es_id);
						pfd.setOpd_personal_id(Integer.parseInt(opd_id));
						pfd.setResult(0);
						pfd.setSer_no(Integer.parseInt(ser_no));
						pfd.setPbda_code(Integer.parseInt(pbda_code));
						pfd.setOa_app_id(Integer.parseInt(oapp_id));
						sessionHQL1.save(pfd);
						sessionHQL1.flush();
						sessionHQL1.clear();
						tx1.commit();
						model.put("msg", "Data Saved Successfully");
				
					
						
					}
						
					}
					
					
					

				} else {
					String hql1 = "delete from TB_PARTPASS_FULLPASS_DTL where es_id=:es_id";
			  		Query query1 = sessionHQL.createQuery(hql1)
			  					.setParameter("es_id",es_id);
			  		query1.executeUpdate();
			  		tx.commit();
			  		ArrayList<ArrayList<String>> Fully_list = prsDao.getFullyPassedForProcessResult(es_id, "", ec_exam_id);
					//System.err.println("Fully_list============="+Fully_list.size());
					for(int i=0;i<Fully_list.size();i++) {
						Session sessionHQL1 = this.sessionFactory.openSession();
						Transaction tx1 = sessionHQL1.beginTransaction();
						
						String ser_no= Fully_list.get(i).get(0);
						String opd_id= Fully_list.get(i).get(5);
						String oapp_id= Fully_list.get(i).get(6);
						
						
						pfd.setEs_id(es_id);
						pfd.setOpd_personal_id(Integer.parseInt(opd_id));
						pfd.setResult(1);
						pfd.setSer_no(Integer.parseInt(ser_no));
						pfd.setOa_app_id(Integer.parseInt(oapp_id));
						sessionHQL1.save(pfd);
						sessionHQL1.flush();
						sessionHQL1.clear();
						tx1.commit();
						model.put("msg", "Data Saved Successfully");
				
					
						
					}
					
					
					if(ec_exam_id == 1) {
						
						ArrayList<ArrayList<String>> b_Part_list = partbreportDao.getPartPassedandFailures(es_year,"");
						for(int i=0;i<b_Part_list.size();i++) {
							Session sessionHQL1 = this.sessionFactory.openSession();
							Transaction tx1 = sessionHQL1.beginTransaction();
							
							String ser_no= b_Part_list.get(i).get(0);
							String opd_id= b_Part_list.get(i).get(11);
							String pbda_code= b_Part_list.get(i).get(12);
							String oapp_id= b_Part_list.get(i).get(13);
							
							pfd.setEs_id(es_id);
							pfd.setOpd_personal_id(Integer.parseInt(opd_id));
							pfd.setResult(0);
							pfd.setSer_no(Integer.parseInt(ser_no));
							pfd.setPbda_code(Integer.parseInt(pbda_code));
							pfd.setOa_app_id(Integer.parseInt(oapp_id));
							sessionHQL1.save(pfd);
							sessionHQL1.flush();
							sessionHQL1.clear();
							tx1.commit();
							model.put("msg", "Data Saved Successfully");
					
						
							
						}
						
					}
					if(ec_exam_id == 2) {
					ArrayList<ArrayList<String>>D_Part_list=partDreportDao.getPartPassedandFailuresForPartD( es_year, "");
					for(int i=0;i<D_Part_list.size();i++) {
						Session sessionHQL1 = this.sessionFactory.openSession();
						Transaction tx1 = sessionHQL1.beginTransaction();
						
						String ser_no= D_Part_list.get(i).get(0);
						String opd_id= D_Part_list.get(i).get(12);
						String pbda_code= D_Part_list.get(i).get(13);
						String oapp_id= D_Part_list.get(i).get(14);
						pfd.setEs_id(es_id);
						pfd.setOpd_personal_id(Integer.parseInt(opd_id));
						pfd.setResult(0);
						pfd.setSer_no(Integer.parseInt(ser_no));
						pfd.setPbda_code(Integer.parseInt(pbda_code));
						pfd.setOa_app_id(Integer.parseInt(oapp_id));
						sessionHQL1.save(pfd);
						sessionHQL1.flush();
						sessionHQL1.clear();
						tx1.commit();
						model.put("msg", "Data Saved Successfully");
				
					
						
					}
						
					}
				}

			
			
		}

		catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}
		if(ec_exam_id == 1) {
		return new ModelAndView("redirect:Process_results_Url_PartB");
	}
		if(ec_exam_id == 2) {
			return new ModelAndView("redirect:Process_results_Url_PartD");
			
		}
		return null;
}
}
