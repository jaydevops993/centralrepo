package com.BisagN.models.officers.masters;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "officer_personal_details", uniqueConstraints = {
@UniqueConstraint(columnNames = "opd_personal_id"),})

public class OFFICER_PERSONAL_DETAILS_M {

   
      
      
     
   
      
      
      private int opd_personal_id;
      private int ct_comm_id;
      private int cc_command_id;
      private String opd_officer_name;
      private String opd_unit;
      private String opd_unit_address1;
      private String opd_unit_address2;
      private String opd_unit_address3;
      @DateTimeFormat(pattern = "dd/MM/yyyy")
          private Date opd_dob;

      @DateTimeFormat(pattern = "dd/MM/yyyy")
          private Date opd_date_of_comm;
      

      @DateTimeFormat(pattern = "dd/MM/yyyy")
          private Date opd_date_of_seniority;
      
      private String opd_permanent_address1;
 
      private String opd_permanent_address2;
      private String opd_permanent_address3;
      private int opd_partb;
      private int opd_partd;
      private int opd_partd_dssc;
      private String opd_isactive;
      private String opd_remarks;
      private int opd_status_id;
      private String auth_letter_no;
		private Date inactivation_date;
		private int pbda_sub_code;
		private String course_no;
		private int opd_gender;
		private String mobile_no;
		private String opd_type_of_entry;
		
		
		private String opd_cpsc_on_off ;
		private String   opd_cpsc_course ;
		private String   opd_jc_course_no ;
		private String  opd_jc_course_grading;
		private String opd_jc_number;
		private String opd_created_by;
		private String opd_modified_by;
		private Date opd_creation_date;
		private Date opd_modification_date;
		
		 
		    
		    
      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "opd_personal_id", unique = true, nullable = false)


    
      public int getOpd_personal_id() {
           return opd_personal_id;
      }
      public void setOpd_personal_id(int opd_personal_id) {
	  this.opd_personal_id = opd_personal_id;
      }
      public int getCt_comm_id() {
           return ct_comm_id;
      }
      public void setCt_comm_id(int ct_comm_id) {
	  this.ct_comm_id = ct_comm_id;
      }
      public int getCc_command_id() {
           return cc_command_id;
      }
      public void setCc_command_id(int cc_command_id) {
	  this.cc_command_id = cc_command_id;
      }
      public String getOpd_officer_name() {
           return opd_officer_name;
      }
      public void setOpd_officer_name(String opd_officer_name) {
	  this.opd_officer_name = opd_officer_name;
      }
      public String getOpd_permanent_address1() {
           return opd_permanent_address1;
      }
      public void setOpd_permanent_address1(String opd_permanent_address1) {
	  this.opd_permanent_address1 = opd_permanent_address1;
      }
      public String getOpd_unit() {
           return opd_unit;
      }
      public void setOpd_unit(String opd_unit) {
	  this.opd_unit = opd_unit;
      }
      public String getOpd_permanent_address2() {
           return opd_permanent_address2;
      }
      public void setOpd_permanent_address2(String opd_permanent_address2) {
	  this.opd_permanent_address2 = opd_permanent_address2;
      }
      public String getOpd_permanent_address3() {
           return opd_permanent_address3;
      }
      public void setOpd_permanent_address3(String opd_permanent_address3) {
	  this.opd_permanent_address3 = opd_permanent_address3;
      }
      public String getOpd_unit_address1() {
           return opd_unit_address1;
      }
      public void setOpd_unit_address1(String opd_unit_address1) {
	  this.opd_unit_address1 = opd_unit_address1;
      }
      public String getOpd_unit_address2() {
           return opd_unit_address2;
      }
      public void setOpd_unit_address2(String opd_unit_address2) {
	  this.opd_unit_address2 = opd_unit_address2;
      }
      public String getOpd_unit_address3() {
           return opd_unit_address3;
      }
      public void setOpd_unit_address3(String opd_unit_address3) {
	  this.opd_unit_address3 = opd_unit_address3;
      }
      public Date getOpd_dob() {
           return opd_dob;
      }
      public void setOpd_dob(Date opd_dob) {
	  this.opd_dob = opd_dob;
      }
      public Date getOpd_date_of_comm() {
           return opd_date_of_comm;
      }
      public void setOpd_date_of_comm(Date opd_date_of_comm) {
	  this.opd_date_of_comm = opd_date_of_comm;
      }
      public Date getOpd_date_of_seniority() {
           return opd_date_of_seniority;
      }
      public void setOpd_date_of_seniority(Date opd_date_of_seniority) {
	  this.opd_date_of_seniority = opd_date_of_seniority;
      }
      public int getOpd_partb() {
           return opd_partb;
      }
      public void setOpd_partb(int opd_partb) {
	  this.opd_partb = opd_partb;
      }
      public int getOpd_partd() {
           return opd_partd;
      }
      public void setOpd_partd(int opd_partd) {
	  this.opd_partd = opd_partd;
      }
      public int getOpd_partd_dssc() {
           return opd_partd_dssc;
      }
      public void setOpd_partd_dssc(int opd_partd_dssc) {
	  this.opd_partd_dssc = opd_partd_dssc;
      }
      public String getOpd_isactive() {
           return opd_isactive;
      }
      public void setOpd_isactive(String opd_isactive) {
	  this.opd_isactive = opd_isactive;
      }
      public String getOpd_remarks() {
           return opd_remarks;
      }
      public void setOpd_remarks(String opd_remarks) {
	  this.opd_remarks = opd_remarks;
      }
      public int getOpd_status_id() {
           return opd_status_id;
      }
      public void setOpd_status_id(int opd_status_id) {
	  this.opd_status_id = opd_status_id;
      }
	public String getAuth_letter_no() {
		return auth_letter_no;
	}
	public void setAuth_letter_no(String auth_letter_no) {
		this.auth_letter_no = auth_letter_no;
	}
	public Date getInactivation_date() {
		return inactivation_date;
	}
	public void setInactivation_date(Date inactivation_date) {
		this.inactivation_date = inactivation_date;
	}
	public int getPbda_sub_code() {
		return pbda_sub_code;
	}
	public void setPbda_sub_code(int pbda_sub_code) {
		this.pbda_sub_code = pbda_sub_code;
	}
	public String getCourse_no() {
		return course_no;
	}
	public void setCourse_no(String course_no) {
		this.course_no = course_no;
	}
	public int getOpd_gender() {
		return opd_gender;
	}
	public void setOpd_gender(int opd_gender) {
		this.opd_gender = opd_gender;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getOpd_type_of_entry() {
		return opd_type_of_entry;
	}
	public void setOpd_type_of_entry(String opd_type_of_entry) {
		this.opd_type_of_entry = opd_type_of_entry;
	}
	public String getOpd_cpsc_on_off() {
		return opd_cpsc_on_off;
	}
	public void setOpd_cpsc_on_off(String opd_cpsc_on_off) {
		this.opd_cpsc_on_off = opd_cpsc_on_off;
	}
	public String getOpd_cpsc_course() {
		return opd_cpsc_course;
	}
	public void setOpd_cpsc_course(String opd_cpsc_course) {
		this.opd_cpsc_course = opd_cpsc_course;
	}
	
	public String getOpd_jc_course_grading() {
		return opd_jc_course_grading;
	}
	public void setOpd_jc_course_grading(String opd_jc_course_grading) {
		this.opd_jc_course_grading = opd_jc_course_grading;
	}
	public String getOpd_jc_number() {
		return opd_jc_number;
	}
	public void setOpd_jc_number(String opd_jc_number) {
		this.opd_jc_number = opd_jc_number;
	}
	public String getOpd_jc_course_no() {
		return opd_jc_course_no;
	}
	public void setOpd_jc_course_no(String opd_jc_course_no) {
		this.opd_jc_course_no = opd_jc_course_no;
	}
	public String getOpd_created_by() {
		return opd_created_by;
	}
	public void setOpd_created_by(String opd_created_by) {
		this.opd_created_by = opd_created_by;
	}
	public String getOpd_modified_by() {
		return opd_modified_by;
	}
	public void setOpd_modified_by(String opd_modified_by) {
		this.opd_modified_by = opd_modified_by;
	}
	public Date getOpd_creation_date() {
		return opd_creation_date;
	}
	public void setOpd_creation_date(Date opd_creation_date) {
		this.opd_creation_date = opd_creation_date;
	}
	public Date getOpd_modification_date() {
		return opd_modification_date;
	}
	public void setOpd_modification_date(Date opd_modification_date) {
		this.opd_modification_date = opd_modification_date;
	}
	
	
      
      
      
}
