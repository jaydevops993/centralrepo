package com.BisagN.controller.office.Barcode;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.Indexing.IndexingDAO;
import com.BisagN.dao.Indexing.ManageBundleDAO;
import com.BisagN.dao.officer.masters.Officer_personal_detailsDAO;
import com.BisagN.dao.officer.others.PartB_ExaminationDAO;
import com.BisagN.models.officers.indexing.EXAMSCHEDULE_INDEXING_DETAIL;
import com.BisagN.models.officers.indexing.INDEXED_BUNDLE_MASTER;
import com.BisagN.models.officers.indexing.INDEXED_PACKING_NOTES_MASTER;
import com.BisagN.models.officers.indexing.INDEXING_SETTING;
import com.BisagN.models.officers.indexing.INDEX_NO;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MANUAL;
import com.BisagN.models.officers.indexing.INDEX_SLIP_MASTER;
import com.BisagN.models.officers.indexing.INDEX_SLIP_SCANNED;
import com.BisagN.models.officers.indexing.TB_BARCODE_COUNT;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.masters.OFFICER_PERSONAL_DETAILS_M;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.masters.SUB_SUBJECT_MST;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class IndexABEntryController {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	private IndexingDAO indedxdao;

	@Autowired
	Officer_personal_detailsDAO ofcDao;

	@Autowired
	CommonController comm;

	@Autowired
	PartB_ExaminationDAO partBDao;

	@Autowired
	ManageBundleDAO MbindxDao;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

	@RequestMapping(value = "IndexABEntryUrl", method = RequestMethod.GET)
	public ModelAndView IndexABEntryUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? ""
				: session.getAttribute("es_begin_dateshow").toString();
		System.err.println("es_begindate===========" + es_begindate);
		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		if (es_id != 0) {
			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, es_id);
			String index_mode = UnlcokExmsch.get(0).getEs_index_mode();
			Mmap.put("index_mode", index_mode);
			Mmap.put("es_id", es_id);
		}
		int esid_es_id = Integer.parseInt(
				session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		System.err.println("esid_es_id==============" + esid_es_id);
		if (esid_es_id != 0) {
			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, esid_es_id);
			Date begin_date = UnlcokExmsch.get(0).getEs_begin_date();
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

			int day = date.getDayOfMonth();
			String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

			String[] shortMonths = new DateFormatSymbols().getShortMonths();
			for (String shortMonth : shortMonths) {

			}

			Month month = date.getMonth();
			int year = date.getYear();
			System.err.println(day + "" + month + "" + year);
			System.err.println("o=====" + month + ' ' + day + ' ' + year);
			String begindateShow = day + " " + month + " " + year;

			Mmap.put("begindateShow", begindateShow);
			Mmap.put("esid_es_id", esid_es_id);

			int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());


			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
					: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			String userId = session.getAttribute("userId").toString();
			String role = session.getAttribute("role").toString();
			
			if (ec_exam_id != 0) {
				List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
				Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
				ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
				Mmap.put("getexamcentrelist", examcentrelist);
				Mmap.put("ec_exam_id", ec_exam_id);
			}
			
			if (esid_sc_subject_id != 0) {
				List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
				Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
				Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());

				List<SUBJECT_CODE_M> ActiveSubName = comm.getsubjectIdbysubname(sessionFactory, esid_sc_subject_id,
						ec_exam_id);

				Mmap.put("ActiveSub", ActiveSubName.get(0).getSc_subject_name());

			}
			
			int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
			
			if (esid_sub_subject_id != 0) {
				List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
				String sub_subject_name=SubSubject.get(0).getSub_subject();
				Mmap.put("sub_subject_name", sub_subject_name);
			}
			List<INDEXED_BUNDLE_MASTER> getBundleName = comm.getBundleNameList(sessionFactory, esid_es_id,
					Integer.parseInt(userId),esid_sc_subject_id);
			if (!getBundleName.isEmpty()) {
				String Bundle_id = getBundleName.get(0).getIbm_bundle_prefix() + " "
						+ getBundleName.get(0).getIbm_bundle_no();
				Mmap.put("Bundle_id", Bundle_id);
				int ibm_id = getBundleName.get(0).getIbm_id();

				int TotalAbs_count = getBundleName.get(0).getIbm_abcount();

				Mmap.put("TotalAbs_count", TotalAbs_count);
				ArrayList<ArrayList<String>> getAbsCount = MbindxDao.getIndxSlipCountByIbm(es_id, ibm_id,
						Integer.parseInt(userId), role);

				if (!getAbsCount.isEmpty()) {
					String slip_count = getAbsCount.get(0).get(0);
					Mmap.put("slip_count", slip_count);

				}

			}
		}
		Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
		Mmap.put("msg", msg);
		return new ModelAndView("Indexing_abEntryTiles");
	}
	
	@RequestMapping(value = "/getCandidateDetails", method = RequestMethod.POST)
	@ResponseBody
	public List<Map<String, Object>> getpersdetails(String application_no, HttpSession session) {
		int esid_es_id = Integer.parseInt(
				session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
		List<Map<String, Object>> list = indedxdao.GetCandidateDetailsforIndexing(application_no, esid_es_id, esid_sc_subject_id);
		return list;

	}

	@RequestMapping(value = "/IndexingabEntryACtion", method = RequestMethod.POST)
	public @ResponseBody String IndexingabEntryACtion(
			@ModelAttribute("IndexingabEntryCMD") INDEX_SLIP_SCANNED index_slip_m, BindingResult result,
			HttpServletRequest request, ModelMap model, HttpSession session, String msg) {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		try {

			String username = session.getAttribute("username").toString();
			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			int id = index_slip_m.getIs_scan_id() > 0 ? index_slip_m.getIs_scan_id() : 0;
			String application_no = request.getParameter("application_no");
			int esid_es_id = Integer.parseInt(
					session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
			
			List<OFFICER_APPLICATION_M> opdpers_id = comm.getOpdIdbyOappId(sessionFactory,
					Integer.parseInt(application_no), esid_es_id);
			if (!opdpers_id.isEmpty()) {
				int opd_pers_id = opdpers_id.get(0).getOpd_personal_id();
				int center_code = opdpers_id.get(0).getOa_center_opted();
				List<OFFICER_PERSONAL_CODE_M> perscode = comm.getPersCodebyOpdID(sessionFactory, opd_pers_id);
				List<OFFICER_PERSONAL_DETAILS_M> opdDetails = comm.getpbdasumbyopdid(sessionFactory, opd_pers_id);
				int command_id = opdDetails.get(0).getCc_command_id();
				String pers_code = perscode.get(0).getOpc_personal_code();
				int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
						: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
				
				int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
						: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());


				Query q0 = sessionHQL.createQuery(
						"select count(id) from INDEX_SLIP_SCANNED  where is_armyno=:is_armyno and  is_es_id=:is_es_id and is_sc_subject_id=:is_sc_subject_id");
				q0.setParameter("is_armyno", pers_code);
				q0.setParameter("is_es_id", String.valueOf(esid_es_id));
				q0.setParameter("is_sc_subject_id", String.valueOf(esid_sc_subject_id));
				Long c = (Long) q0.uniqueResult();

				if (id == 0) {

					if (c == 0) {

						List<Map<String, Object>> persDetails = ofcDao.getpersdetails(String.valueOf(opd_pers_id));
						int pers_arm_id = (int) persDetails.get(0).get("ac_arm_id");

						INDEX_SLIP_SCANNED iss = new INDEX_SLIP_SCANNED();
						iss.setIs_armyno(pers_code);
						iss.setIs_ac_arm_id(String.valueOf(pers_arm_id));
						iss.setIs_commandcode(String.valueOf(command_id));
						iss.setIs_ecc_center_code(String.valueOf(center_code));
						iss.setIs_es_id(String.valueOf(esid_es_id));
						iss.setIs_sc_subject_id(String.valueOf(esid_sc_subject_id));
						if(esid_sub_subject_id != 0) {
						iss.setIss_sub_subject_id(esid_sub_subject_id);
						}
						int issID = (int) sessionHQL.save(iss);

						model.put("msg", "Data Saved Successfully");

						tx.commit();

					}

				}
			}
		} catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return msg;
	}

	@RequestMapping(value = "/getIndexDetailsForBarocde", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<ArrayList<String>> GetIndexDetailsforBarcoding(String ic_number, int es_id) {

		ArrayList<ArrayList<String>> list = indedxdao.GetIndexDetailsforBarcoding(ic_number, es_id);
		return list;

	}

	@RequestMapping(value = "/IndexingbarcodeACtion", method = RequestMethod.POST)
	public @ResponseBody String IndexingbarcodeACtion(
			@ModelAttribute("IndexingabEntryCMD") INDEX_SLIP_MASTER index_slip_m, BindingResult result,
			HttpServletRequest request, ModelMap model, HttpSession session, String msg) {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		try {

			String username = session.getAttribute("username").toString();
			String userId = session.getAttribute("userId").toString();
			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			int id = index_slip_m.getIsm_id() > 0 ? index_slip_m.getIsm_id() : 0;
			String application_no = request.getParameter("application_no");
			String command_id = request.getParameter("command_id");
			String center_id = request.getParameter("center");
			String ab_used = request.getParameter("ab_used");
			int esid_es_id = Integer.parseInt(
					session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
			int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
			
			int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());


			List<OFFICER_APPLICATION_M> opdpers_id = comm.getOpdIdbyOappId(sessionFactory,
					Integer.parseInt(application_no), esid_es_id);
			int opd_pers_id = opdpers_id.get(0).getOpd_personal_id();

			List<OFFICER_PERSONAL_CODE_M> perscode = comm.getPersCodebyOpdID(sessionFactory, opd_pers_id);
			String pers_code = perscode.get(0).getOpc_personal_code();
			List<INDEXED_BUNDLE_MASTER> getBundleName = comm.getBundleNameList(sessionFactory, esid_es_id,
					Integer.parseInt(userId),esid_sc_subject_id);
			int Bundle_id = getBundleName.get(0).getIbm_id();

			Query q0 = sessionHQL.createQuery(
					"select count(*) from INDEX_SLIP_MASTER  where ism_armyno=:ism_armyno and ism_es_id=:ism_es_id");
			q0.setParameter("ism_armyno", pers_code);
			q0.setParameter("ism_es_id", esid_es_id);
			Long c = (Long) q0.uniqueResult();

			if (id == 0) {

				if (c == 0) {

					List<Map<String, Object>> persDetails = ofcDao.getpersdetails(String.valueOf(opd_pers_id));
					int pers_arm_id = (int) persDetails.get(0).get("ac_arm_id");

					List<INDEXING_SETTING> bundledetails = comm.getbundledetailsforindexing(sessionFactory, esid_es_id);

					int bundlepacking_size = bundledetails.get(0).getIst_maxab_bundle();
					int answerbookbundleSize = bundledetails.get(0).getIst_maxbundle_package();
					int bundleminno = bundledetails.get(0).getIst_min_indexno();
					int bundlemaxno = bundledetails.get(0).getIst_max_indexno();

					INDEX_NO in = new INDEX_NO();

					if (c != 0) {
						in = comm.getIndexNoByEsid(sessionFactory, esid_es_id).get(0);

					} else {
						List<INDEX_NO> indexno = comm.getIndexNoByEsid(sessionFactory, esid_es_id);
						if (indexno.isEmpty()) {
							in.setEs_id(esid_es_id);
							in.setIndex_no(bundleminno);
							int inid = (int) sessionHQL.save(in);
							in.setId(inid);
						}
					}
					String role = session.getAttribute("role").toString();
					ArrayList<ArrayList<String>> countslipscan = MbindxDao.getIndxSlipCountByIbm(esid_es_id, Bundle_id,
							Integer.parseInt(userId), role);

					if (!countslipscan.isEmpty()) {
						String slip_count = countslipscan.get(0).get(0);
						String ab_count = countslipscan.get(0).get(1);
						if (Integer.parseInt(slip_count) == Integer.parseInt(ab_count)) {
							msg = "The Bundle is Packed. Please create New Bundle";

						} else {

							int r_index_no = (int) (Math.random() * (bundlemaxno - bundleminno + 1) + bundleminno);
							index_slip_m.setIsm_armyno(pers_code);
							index_slip_m.setIsm_dtcreateddate(date);
							index_slip_m.setCenter_code(Integer.parseInt(center_id));
							index_slip_m.setIsm_es_id(esid_es_id);
							index_slip_m.setIsm_indexno(r_index_no);
							index_slip_m.setCommand_id(Integer.parseInt(command_id));
							int index_slip_id = (int) sessionHQL.save(index_slip_m);

							INDEX_SLIP_MANUAL ism = new INDEX_SLIP_MANUAL();
							ism.setIs_abs(Integer.parseInt(ab_used));
							ism.setIs_ac_arm_id(pers_arm_id);
							ism.setIs_commandid(Integer.parseInt(command_id));
							ism.setIs_ecc_center_code(Integer.parseInt(center_id));
							ism.setIs_sc_subject_id(esid_sc_subject_id);
							if(esid_sub_subject_id != 0) {
							ism.setIs_sub_subject_id(esid_sub_subject_id);
							}
							ism.setIs_status(1);
							ism.setIs_ibm_id(Bundle_id);
							ism.setIs_ism_id(index_slip_id);
							ism.setIs_iu_user_id(Integer.parseInt(userId));
							int ismaid = (int) sessionHQL.save(ism);
							
							
							
							TB_BARCODE_COUNT barcode_count2= new TB_BARCODE_COUNT();
							Session sessionHQL3 = this.sessionFactory.openSession();
							Transaction tx3 = sessionHQL3.beginTransaction();
							barcode_count2.setCreated_by(username);
							barcode_count2.setCreated_date(date);
							barcode_count2.setOa_app_id(Integer.parseInt(application_no));
							barcode_count2.setOpd_pers_id(opd_pers_id);
							barcode_count2.setBarcode_no(String.valueOf(r_index_no) + "-" +"M");
							barcode_count2.setBrcd_status(1);
							barcode_count2.setIs_id(ismaid);
							barcode_count2.setClose_status(1);
							barcode_count2.setOpng_status(1);
							barcode_count2.setSubject_id(esid_sc_subject_id);
							if(esid_sub_subject_id != 0) {
								barcode_count2.setSub_subject_id(esid_sub_subject_id);
								}
							barcode_count2.setEs_id(esid_es_id);
							sessionHQL3.save(barcode_count2);
							sessionHQL3.flush();
							sessionHQL3.clear();
							tx3.commit();
							sessionHQL3.close();
							
							TB_BARCODE_COUNT barcode_count23= new TB_BARCODE_COUNT();
							Session sessionHQL32 = this.sessionFactory.openSession();
							Transaction tx32 = sessionHQL32.beginTransaction();
							barcode_count23.setCreated_by(username);
							barcode_count23.setCreated_date(date);
							barcode_count23.setOa_app_id(Integer.parseInt(application_no));
							barcode_count23.setOpd_pers_id(opd_pers_id);
							barcode_count23.setBarcode_no(String.valueOf(r_index_no) + "-" +"E");
							barcode_count23.setBrcd_status(1);
							barcode_count23.setSubject_id(esid_sc_subject_id);
							if(esid_sub_subject_id != 0) {
								barcode_count23.setSub_subject_id(esid_sub_subject_id);
								}
							barcode_count23.setIs_id(ismaid);
							barcode_count23.setEs_id(esid_es_id);
							sessionHQL32.save(barcode_count23);
							sessionHQL32.flush();
							sessionHQL32.clear();
							tx32.commit();
							sessionHQL32.close();
							
							
						
							for(int i=1;i<=Integer.parseInt(ab_used);i++){
								
								TB_BARCODE_COUNT barcode_count= new TB_BARCODE_COUNT();
								Session sessionHQL2 = this.sessionFactory.openSession();
								Transaction tx2 = sessionHQL2.beginTransaction();
								barcode_count.setCreated_by(username);
								barcode_count.setCreated_date(date);
								barcode_count.setEs_id(esid_es_id);
								barcode_count.setOa_app_id(Integer.parseInt(application_no));
								barcode_count.setOpd_pers_id(opd_pers_id);
								barcode_count.setBarcode_no(String.valueOf(r_index_no)+ "-" +i);
								barcode_count.setBrcd_status(1);
								barcode_count.setSubject_id(esid_sc_subject_id);
								if(esid_sub_subject_id != 0) {
									barcode_count.setSub_subject_id(esid_sub_subject_id);
									}
								barcode_count.setIs_id(ismaid);
								sessionHQL2.save(barcode_count);
								sessionHQL2.flush();
								sessionHQL2.clear();
								tx2.commit();
								sessionHQL2.close();
							}

							String hq15 = "update OFFICER_APPLICATION_M set in_index_id=:in_index_id,oa_center_granted=:oa_center_granted  where opd_personal_id=:opd_personal_id and es_id=:es_id ";
							Query query5 = sessionHQL.createQuery(hq15).setParameter("in_index_id", r_index_no)
									.setParameter("oa_center_granted", Integer.parseInt(center_id))

									.setParameter("opd_personal_id", opd_pers_id).setParameter("es_id", esid_es_id);
							query5.executeUpdate();

							Query qry1 = sessionHQL.createQuery(
									"update OFFICER_PERSONAL_DETAILS_M set cc_command_id=:cc_command_id where opd_personal_id=:opd_personal_id");
							qry1.setParameter("cc_command_id", Integer.parseInt(command_id));
							qry1.setParameter("opd_personal_id", opd_pers_id);
							qry1.executeUpdate();

							msg = "Data Saved Successfully";

							tx.commit();
						}

					} else {

						int r_index_no = (int) (Math.random() * (bundlemaxno - bundleminno + 1) + bundleminno);
						index_slip_m.setIsm_armyno(pers_code);
						index_slip_m.setIsm_dtcreateddate(date);
						index_slip_m.setCenter_code(Integer.parseInt(center_id));
						index_slip_m.setIsm_es_id(esid_es_id);
						index_slip_m.setIsm_indexno(r_index_no);
						
						index_slip_m.setCommand_id(Integer.parseInt(command_id));
						int index_slip_id = (int) sessionHQL.save(index_slip_m);

						INDEX_SLIP_MANUAL ism = new INDEX_SLIP_MANUAL();
						ism.setIs_abs(Integer.parseInt(ab_used));
						ism.setIs_ac_arm_id(pers_arm_id);
						ism.setIs_commandid(Integer.parseInt(command_id));
						ism.setIs_ecc_center_code(Integer.parseInt(center_id));
						ism.setIs_sc_subject_id(esid_sc_subject_id);
						ism.setIs_status(1);
						ism.setIs_ibm_id(Bundle_id);
						if(esid_sub_subject_id != 0) {
							ism.setIs_sub_subject_id(esid_sub_subject_id);
							}
						ism.setIs_ism_id(index_slip_id);
						ism.setIs_iu_user_id(Integer.parseInt(userId));
						int ismaid = (int) sessionHQL.save(ism);

						
						TB_BARCODE_COUNT barcode_count2= new TB_BARCODE_COUNT();
						Session sessionHQL3 = this.sessionFactory.openSession();
						Transaction tx3 = sessionHQL3.beginTransaction();
						barcode_count2.setCreated_by(username);
						barcode_count2.setCreated_date(date);
						barcode_count2.setOa_app_id(Integer.parseInt(application_no));
						barcode_count2.setOpd_pers_id(opd_pers_id);
						barcode_count2.setBarcode_no(String.valueOf(r_index_no) + "-" +"M");
						barcode_count2.setBrcd_status(1);
						barcode_count2.setIs_id(ismaid);
						barcode_count2.setClose_status(1);
						barcode_count2.setOpng_status(1);
						if(esid_sub_subject_id != 0) {
							barcode_count2.setSub_subject_id(esid_sub_subject_id);
							}
						barcode_count2.setEs_id(esid_es_id);
						barcode_count2.setSubject_id(esid_sc_subject_id);
						sessionHQL3.save(barcode_count2);
						sessionHQL3.flush();
						sessionHQL3.clear();
						tx3.commit();
						sessionHQL3.close();
						
						
						TB_BARCODE_COUNT barcode_count23= new TB_BARCODE_COUNT();
						Session sessionHQL32 = this.sessionFactory.openSession();
						Transaction tx32 = sessionHQL32.beginTransaction();
						barcode_count23.setCreated_by(username);
						barcode_count23.setCreated_date(date);
						barcode_count23.setOa_app_id(Integer.parseInt(application_no));
						barcode_count23.setOpd_pers_id(opd_pers_id);
						barcode_count23.setBarcode_no(String.valueOf(r_index_no) + "-" +"E");
						barcode_count23.setBrcd_status(1);
						barcode_count23.setEs_id(esid_es_id);
						if(esid_sub_subject_id != 0) {
							barcode_count23.setSub_subject_id(esid_sub_subject_id);
							}
						barcode_count23.setIs_id(ismaid);
						barcode_count23.setSubject_id(esid_sc_subject_id);
						sessionHQL32.save(barcode_count23);
						sessionHQL32.flush();
						sessionHQL32.clear();
						tx32.commit();
						sessionHQL32.close();
						for(int i=1;i<=Integer.parseInt(ab_used);i++){
							
							TB_BARCODE_COUNT barcode_count= new TB_BARCODE_COUNT();
							Session sessionHQL2 = this.sessionFactory.openSession();
							Transaction tx2 = sessionHQL2.beginTransaction();
							barcode_count.setCreated_by(username);
							barcode_count.setCreated_date(date);
							barcode_count.setEs_id(esid_es_id);
							barcode_count.setOa_app_id(Integer.parseInt(application_no));
							barcode_count.setOpd_pers_id(opd_pers_id);
							barcode_count.setBarcode_no(String.valueOf(r_index_no)+ "-" +i);
							barcode_count.setBrcd_status(1);
							barcode_count.setIs_id(ismaid);
							barcode_count.setSubject_id(esid_sc_subject_id);
							if(esid_sub_subject_id != 0) {
								barcode_count.setSub_subject_id(esid_sub_subject_id);
								}
							sessionHQL2.save(barcode_count);
							sessionHQL2.flush();
							sessionHQL2.clear();
							tx2.commit();
							sessionHQL2.close();
						}
						String hq15 = "update OFFICER_APPLICATION_M set in_index_id=:in_index_id,oa_center_granted=:oa_center_granted  where opd_personal_id=:opd_personal_id and es_id=:es_id ";
						Query query5 = sessionHQL.createQuery(hq15).setParameter("in_index_id", r_index_no)
								.setParameter("oa_center_granted", Integer.parseInt(center_id))

								.setParameter("opd_personal_id", opd_pers_id).setParameter("es_id", esid_es_id);
						query5.executeUpdate();

						Query qry1 = sessionHQL.createQuery(
								"update OFFICER_PERSONAL_DETAILS_M set cc_command_id=:cc_command_id where opd_personal_id=:opd_personal_id");
						qry1.setParameter("cc_command_id", Integer.parseInt(command_id));
						qry1.setParameter("opd_personal_id", opd_pers_id);
						qry1.executeUpdate();

						msg = "Data Saved Successfully";

						tx.commit();

					}

				} else {
					List<Map<String, Object>> persDetails = ofcDao.getpersdetails(String.valueOf(opd_pers_id));
					int pers_arm_id = (int) persDetails.get(0).get("ac_arm_id");
					List<INDEX_SLIP_MASTER>getINdexNo=comm.getIndexNoByICnumber( sessionFactory, pers_code, String.valueOf(esid_es_id));
					int index_no=getINdexNo.get(0).getIsm_indexno();
					 int indxSlipId=getINdexNo.get(0).getIsm_id();
					String role = session.getAttribute("role").toString();
					ArrayList<ArrayList<String>> countslipscan = MbindxDao.getIndxSlipCountByIbm(esid_es_id, Bundle_id,
							Integer.parseInt(userId), role);

					if (!countslipscan.isEmpty()) {
						String slip_count = countslipscan.get(0).get(0);
						String ab_count = countslipscan.get(0).get(1);
						if (Integer.parseInt(slip_count) == Integer.parseInt(ab_count)) {
							msg = "The Bundle is Packed. Please create New Bundle";

						} else {

							

								Query q02 = sessionHQL
										.createQuery("select count(*) from INDEX_SLIP_MANUAL  where is_ism_id=:is_ism_id and is_sc_subject_id=:is_sc_subject_id");
								q02.setParameter("is_ism_id", indxSlipId);
								q02.setParameter("is_sc_subject_id", esid_sc_subject_id);
								Long c2 = (Long) q02.uniqueResult();
							 
							 if(c2 == 0) {

							INDEX_SLIP_MANUAL ism = new INDEX_SLIP_MANUAL();
							ism.setIs_abs(Integer.parseInt(ab_used));
							ism.setIs_ac_arm_id(pers_arm_id);
							ism.setIs_commandid(Integer.parseInt(command_id));
							ism.setIs_ecc_center_code(Integer.parseInt(center_id));
							ism.setIs_sc_subject_id(esid_sc_subject_id);
							if(esid_sub_subject_id != 0) {
								ism.setIs_sub_subject_id(esid_sub_subject_id);
								}
							ism.setIs_status(1);
							ism.setIs_ibm_id(Bundle_id);
							ism.setIs_ism_id(indxSlipId);
							ism.setIs_iu_user_id(Integer.parseInt(userId));
							int ismaid = (int) sessionHQL.save(ism);
							
							
							
							TB_BARCODE_COUNT barcode_count2= new TB_BARCODE_COUNT();
							Session sessionHQL3 = this.sessionFactory.openSession();
							Transaction tx3 = sessionHQL3.beginTransaction();
							barcode_count2.setCreated_by(username);
							barcode_count2.setCreated_date(date);
							barcode_count2.setOa_app_id(Integer.parseInt(application_no));
							barcode_count2.setOpd_pers_id(opd_pers_id);
							barcode_count2.setBarcode_no(String.valueOf(index_no) + "-" +"M");
							barcode_count2.setBrcd_status(1);
							barcode_count2.setIs_id(ismaid);
							barcode_count2.setClose_status(1);
							barcode_count2.setOpng_status(1);
							barcode_count2.setSubject_id(esid_sc_subject_id);
							if(esid_sub_subject_id != 0) {
								barcode_count2.setSub_subject_id(esid_sub_subject_id);
								}
							barcode_count2.setEs_id(esid_es_id);
							sessionHQL3.save(barcode_count2);
							sessionHQL3.flush();
							sessionHQL3.clear();
							tx3.commit();
							sessionHQL3.close();
							
							TB_BARCODE_COUNT barcode_count23= new TB_BARCODE_COUNT();
							Session sessionHQL32 = this.sessionFactory.openSession();
							Transaction tx32 = sessionHQL32.beginTransaction();
							barcode_count23.setCreated_by(username);
							barcode_count23.setCreated_date(date);
							barcode_count23.setOa_app_id(Integer.parseInt(application_no));
							barcode_count23.setOpd_pers_id(opd_pers_id);
							barcode_count23.setBarcode_no(String.valueOf(index_no) + "-" +"E");
							barcode_count23.setBrcd_status(1);
							barcode_count23.setSubject_id(esid_sc_subject_id);
							if(esid_sub_subject_id != 0) {
								barcode_count23.setSub_subject_id(esid_sub_subject_id);
								}
							barcode_count23.setIs_id(ismaid);
							barcode_count23.setEs_id(esid_es_id);
							sessionHQL32.save(barcode_count23);
							sessionHQL32.flush();
							sessionHQL32.clear();
							tx32.commit();
							sessionHQL32.close();
							
							
						
							for(int i=1;i<=Integer.parseInt(ab_used);i++){
								
								TB_BARCODE_COUNT barcode_count= new TB_BARCODE_COUNT();
								Session sessionHQL2 = this.sessionFactory.openSession();
								Transaction tx2 = sessionHQL2.beginTransaction();
								barcode_count.setCreated_by(username);
								barcode_count.setCreated_date(date);
								barcode_count.setEs_id(esid_es_id);
								barcode_count.setOa_app_id(Integer.parseInt(application_no));
								barcode_count.setOpd_pers_id(opd_pers_id);
								barcode_count.setBarcode_no(String.valueOf(index_no)+ "-" +i);
								barcode_count.setBrcd_status(1);
								barcode_count.setSubject_id(esid_sc_subject_id);
								if(esid_sub_subject_id != 0) {
									barcode_count.setSub_subject_id(esid_sub_subject_id);
									}
								barcode_count.setIs_id(ismaid);
								barcode_count.setEs_id(esid_es_id);
								sessionHQL2.save(barcode_count);
								sessionHQL2.flush();
								sessionHQL2.clear();
								tx2.commit();
								sessionHQL2.close();
							}

							

							msg = "Data Saved Successfully";

							tx.commit();
						
						}else {
							msg = "Data already exist";	
						}
						}
					}else {
						 
							Query q02 = sessionHQL
									.createQuery("select count(*) from INDEX_SLIP_MANUAL  where is_ism_id=:is_ism_id and is_sc_subject_id=:is_sc_subject_id");
							q02.setParameter("is_ism_id", indxSlipId);
							q02.setParameter("is_sc_subject_id", esid_sc_subject_id);
							Long c2 = (Long) q02.uniqueResult();
						 
						 if(c2 == 0) {
						INDEX_SLIP_MANUAL ism = new INDEX_SLIP_MANUAL();
						ism.setIs_abs(Integer.parseInt(ab_used));
						ism.setIs_ac_arm_id(pers_arm_id);
						ism.setIs_commandid(Integer.parseInt(command_id));
						ism.setIs_ecc_center_code(Integer.parseInt(center_id));
						ism.setIs_sc_subject_id(esid_sc_subject_id);
						if(esid_sub_subject_id != 0) {
						ism.setIs_sub_subject_id(esid_sub_subject_id);
						}
						ism.setIs_status(1);
						ism.setIs_ibm_id(Bundle_id);
						ism.setIs_ism_id(indxSlipId);
						ism.setIs_iu_user_id(Integer.parseInt(userId));
						int ismaid = (int) sessionHQL.save(ism);
						
						
						
						TB_BARCODE_COUNT barcode_count2= new TB_BARCODE_COUNT();
						Session sessionHQL3 = this.sessionFactory.openSession();
						Transaction tx3 = sessionHQL3.beginTransaction();
						barcode_count2.setCreated_by(username);
						barcode_count2.setCreated_date(date);
						barcode_count2.setOa_app_id(Integer.parseInt(application_no));
						barcode_count2.setOpd_pers_id(opd_pers_id);
						barcode_count2.setBarcode_no(String.valueOf(index_no) + "-" +"M");
						barcode_count2.setBrcd_status(1);
						barcode_count2.setClose_status(1);
						barcode_count2.setOpng_status(1);
						barcode_count2.setIs_id(ismaid);
						barcode_count2.setSubject_id(esid_sc_subject_id);
						if(esid_sub_subject_id != 0) {
							barcode_count2.setSub_subject_id(esid_sub_subject_id);
							}
						barcode_count2.setEs_id(esid_es_id);
						sessionHQL3.save(barcode_count2);
						sessionHQL3.flush();
						sessionHQL3.clear();
						tx3.commit();
						sessionHQL3.close();
						
						TB_BARCODE_COUNT barcode_count23= new TB_BARCODE_COUNT();
						Session sessionHQL32 = this.sessionFactory.openSession();
						Transaction tx32 = sessionHQL32.beginTransaction();
						barcode_count23.setCreated_by(username);
						barcode_count23.setCreated_date(date);
						barcode_count23.setOa_app_id(Integer.parseInt(application_no));
						barcode_count23.setOpd_pers_id(opd_pers_id);
						barcode_count23.setBarcode_no(String.valueOf(index_no) + "-" +"E");
						barcode_count23.setBrcd_status(1);
						barcode_count23.setSubject_id(esid_sc_subject_id);
						if(esid_sub_subject_id != 0) {
							barcode_count23.setSub_subject_id(esid_sub_subject_id);
							}
						barcode_count23.setIs_id(ismaid);
						barcode_count23.setEs_id(esid_es_id);
						sessionHQL32.save(barcode_count23);
						sessionHQL32.flush();
						sessionHQL32.clear();
						tx32.commit();
						sessionHQL32.close();
						
						
					
						for(int i=1;i<=Integer.parseInt(ab_used);i++){
							
							TB_BARCODE_COUNT barcode_count= new TB_BARCODE_COUNT();
							Session sessionHQL2 = this.sessionFactory.openSession();
							Transaction tx2 = sessionHQL2.beginTransaction();
							barcode_count.setCreated_by(username);
							barcode_count.setCreated_date(date);
							barcode_count.setEs_id(esid_es_id);
							barcode_count.setOa_app_id(Integer.parseInt(application_no));
							barcode_count.setOpd_pers_id(opd_pers_id);
							barcode_count.setBarcode_no(String.valueOf(index_no)+ "-" +i);
							barcode_count.setBrcd_status(1);
							barcode_count.setSubject_id(esid_sc_subject_id);
							if(esid_sub_subject_id != 0) {
								barcode_count.setSub_subject_id(esid_sub_subject_id);
								}
							barcode_count.setIs_id(ismaid);
							barcode_count.setEs_id(esid_es_id);
							sessionHQL2.save(barcode_count);
							sessionHQL2.flush();
							sessionHQL2.clear();
							tx2.commit();
							sessionHQL2.close();
						}

						

						msg = "Data Saved Successfully";

						tx.commit();
						
						 
					
					}else {
						msg = "Data already exist";
					}

			}
			}
		}
		}
		catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return msg;
	}
	
	//Ripal
	@RequestMapping(value = "UpdateIndexABEntryUrl", method = RequestMethod.POST)
	public ModelAndView UpdateIndexABEntryUrl(ModelMap Mmap, HttpSession session,String EPk,String EncryptedPk,String Euser_id,String EOff_id,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		String enckey = "commonPwdEncKeys";  
		String Is_id=hex_asciiDao.decrypt((String) EPk,enckey,session); //index_slip_manual_id
		String Ism_id =hex_asciiDao.decrypt((String) EncryptedPk,enckey,session); //index_slip_master_id
		String user_id =hex_asciiDao.decrypt((String) Euser_id,enckey,session);
		String Off_id =hex_asciiDao.decrypt((String) EOff_id,enckey,session); 
		Mmap.put("Off_id", Off_id);
		INDEX_SLIP_MANUAL ism = comm.getIndexSlipManual(sessionFactory,Integer.parseInt(Is_id));
		Mmap.put("command",ism.getIs_commandid());
		Mmap.put("centre",ism.getIs_ecc_center_code());
		Mmap.put("ab_used",ism.getIs_abs());
		Mmap.put("h_is_id",ism.getIs_id());
		INDEX_SLIP_MASTER ismm = comm.getIndexSlipMaster(sessionFactory,Integer.parseInt(Ism_id));
		Mmap.put("indexno",ismm.getIsm_indexno());
		Mmap.put("h_ism_id",ismm.getIsm_id());
		
		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();
		System.err.println("es_begindate===========" + es_begindate);
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		if (es_id != 0) {
			List<EXAM_SCHEDULE> UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory, es_id);
			String index_mode = UnlcokExmsch.get(0).getEs_index_mode();
			Mmap.put("index_mode", index_mode);
			Mmap.put("es_id", es_id);
			Mmap.put("begindateShow", es_begindate);
			int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
			Mmap.put("esid_es_id", esid_es_id);
			List<EXAMSCHEDULE_INDEXING_DETAIL> ActiveSubject = comm.getActiveIndxSubject(sessionFactory, es_id);
			int Active_sub = ActiveSubject.get(0).getEsid_sc_subject_id();
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0	: Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			if (ec_exam_id != 0) {
				List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
				Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
				ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
				Mmap.put("getexamcentrelist", examcentrelist);
				Mmap.put("ec_exam_id", ec_exam_id);
			}
			List<SUBJECT_CODE_M> ActiveSubName = comm.getsubjectIdbysubname(sessionFactory, Active_sub, ec_exam_id);
			String role = session.getAttribute("role").toString();
			Mmap.put("ActiveSub", ActiveSubName.get(0).getSc_subject_name());
			INDEXED_BUNDLE_MASTER getBundleName = comm.getIndexedBundleMster(sessionFactory,ism.getIs_ibm_id());
			int TotalAbs_count =0;
			String slip_count = "0";
			if (getBundleName != null) {
				String Bundle_id = getBundleName.getIbm_bundle_prefix() + " " + getBundleName.getIbm_bundle_no();
				Mmap.put("Bundle_id", Bundle_id);
				int ibm_id = getBundleName.getIbm_id();
				TotalAbs_count = getBundleName.getIbm_abcount();
				ArrayList<ArrayList<String>> getAbsCount = MbindxDao.getIndxSlipCountByIbm(es_id, ibm_id,Integer.parseInt(user_id), role);
				if (!getAbsCount.isEmpty()) {
					slip_count = getAbsCount.get(0).get(0);
				}
			}
			Mmap.put("TotalAbs_count", TotalAbs_count);
			Mmap.put("slip_count", slip_count);
		}
		Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
		Mmap.put("msg", msg);
		return new ModelAndView("UpdateIndexing_abEntryTiles");
	}
	@RequestMapping(value = "/UpdateIndexingbarcodeACtion", method = RequestMethod.POST)
	public @ResponseBody String UpdateIndexingbarcodeACtion(
			@ModelAttribute("IndexingabEntryCMD") INDEX_SLIP_MASTER index_slip_m, BindingResult result,
			HttpServletRequest request, ModelMap model, HttpSession session, String msg) {

		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		try {
			String userId = session.getAttribute("userId").toString();
			Date date = new Date();
			int id = index_slip_m.getIsm_id() > 0 ? index_slip_m.getIsm_id() : 0;
			String application_no = request.getParameter("application_no");
			String command_id = request.getParameter("command_id");
			String center_id = request.getParameter("center");
			String ab_used = request.getParameter("ab_used");
			String h_is_id = request.getParameter("h_is_id");
			String h_ism_id = request.getParameter("h_ism_id");
			String indexno = request.getParameter("indexno");
			
			String username = session.getAttribute("username").toString();
			
			int esid_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
	
			List<OFFICER_APPLICATION_M> opdpers_id = comm.getOpdIdbyOappId(sessionFactory,Integer.parseInt(application_no), esid_es_id);
			int opd_pers_id = opdpers_id.get(0).getOpd_personal_id();

			List<OFFICER_PERSONAL_CODE_M> perscode = comm.getPersCodebyOpdID(sessionFactory, opd_pers_id);
			String pers_code = perscode.get(0).getOpc_personal_code();

			Query q0 = sessionHQL.createQuery(
					"select count(*) from INDEX_SLIP_MASTER  where ism_armyno=:ism_armyno and ism_es_id=:ism_es_id");
			q0.setParameter("ism_armyno", pers_code);
			q0.setParameter("ism_es_id", esid_es_id);
			Long c = (Long) q0.uniqueResult();

			if (id == 0) {

				if (c != 0) {

					Query qry01 = sessionHQL.createQuery("update INDEX_SLIP_MASTER set command_id=:command_id,center_code=:center_code "
							+ "where ism_id=:h_ism_id");
					qry01.setParameter("command_id", Integer.parseInt(command_id));
					qry01.setParameter("center_code", Integer.parseInt(center_id));
					qry01.setParameter("h_ism_id", Integer.parseInt(h_ism_id));
					qry01.executeUpdate();
					
					Query qry02 = sessionHQL.createQuery("update INDEX_SLIP_MANUAL set is_commandid=:is_commandid,is_abs=:is_abs,"
							+ "is_ecc_center_code=:is_ecc_center_code "
							+ " where is_id=:is_id");
					qry02.setParameter("is_commandid", Integer.parseInt(command_id));
					qry02.setParameter("is_abs", Integer.parseInt(ab_used));
					qry02.setParameter("is_ecc_center_code", Integer.parseInt(center_id));
					qry02.setParameter("is_id", Integer.parseInt(h_is_id));
					qry02.executeUpdate();
							String hq15 = "update OFFICER_APPLICATION_M set oa_center_granted=:oa_center_granted  where opd_personal_id=:opd_personal_id and es_id=:es_id ";
							Query query5 = sessionHQL.createQuery(hq15)
									.setParameter("oa_center_granted", Integer.parseInt(center_id))
									.setParameter("opd_personal_id", opd_pers_id).setParameter("es_id", esid_es_id);
							query5.executeUpdate();
							Query qry1 = sessionHQL.createQuery("update OFFICER_PERSONAL_DETAILS_M set cc_command_id=:cc_command_id where opd_personal_id=:opd_personal_id");
							qry1.setParameter("cc_command_id", Integer.parseInt(command_id));
							qry1.setParameter("opd_personal_id", opd_pers_id);
							qry1.executeUpdate();
							msg = "Data Updated Successfully";
							
							
							String hql1 = "delete from TB_BARCODE_COUNT where oa_app_id=:oa_app_id and es_id=:es_id";
					  		Query query1 = sessionHQL.createQuery(hql1)
					  				.setParameter("oa_app_id",Integer.parseInt(application_no))
					  					.setParameter("es_id",esid_es_id);
					  		query1.executeUpdate();
							tx.commit();
							
							TB_BARCODE_COUNT barcode_count2= new TB_BARCODE_COUNT();
							Session sessionHQL3 = this.sessionFactory.openSession();
							Transaction tx3 = sessionHQL3.beginTransaction();
							barcode_count2.setCreated_by(username);
							barcode_count2.setCreated_date(date);
							barcode_count2.setOa_app_id(Integer.parseInt(application_no));
							barcode_count2.setOpd_pers_id(opd_pers_id);
							barcode_count2.setBarcode_no(indexno + "-" +"M");
							barcode_count2.setBrcd_status(1);
							barcode_count2.setClose_status(1);
							barcode_count2.setOpng_status(1);
							barcode_count2.setEs_id(esid_es_id);
							sessionHQL3.save(barcode_count2);
							sessionHQL3.flush();
							sessionHQL3.clear();
							tx3.commit();
							sessionHQL3.close();
							
							
							TB_BARCODE_COUNT barcode_count23= new TB_BARCODE_COUNT();
							Session sessionHQL32 = this.sessionFactory.openSession();
							Transaction tx32 = sessionHQL32.beginTransaction();
							barcode_count23.setCreated_by(username);
							barcode_count23.setCreated_date(date);
							barcode_count23.setOa_app_id(Integer.parseInt(application_no));
							barcode_count23.setOpd_pers_id(opd_pers_id);
							barcode_count23.setBarcode_no(indexno + "-" +"E");
							barcode_count23.setBrcd_status(1);
							barcode_count23.setEs_id(esid_es_id);
							sessionHQL32.save(barcode_count23);
							sessionHQL32.flush();
							sessionHQL32.clear();
							tx32.commit();
							sessionHQL32.close();
							for(int i=1;i<=Integer.parseInt(ab_used);i++){
								
								TB_BARCODE_COUNT barcode_count= new TB_BARCODE_COUNT();
								Session sessionHQL2 = this.sessionFactory.openSession();
								Transaction tx2 = sessionHQL2.beginTransaction();
								barcode_count.setCreated_by(username);
								barcode_count.setCreated_date(date);
								barcode_count.setEs_id(esid_es_id);
								barcode_count.setOa_app_id(Integer.parseInt(application_no));
								barcode_count.setOpd_pers_id(opd_pers_id);
								barcode_count.setBarcode_no(indexno+ "-" +i);
								barcode_count.setBrcd_status(1);
								sessionHQL2.save(barcode_count);
								sessionHQL2.flush();
								sessionHQL2.clear();
								tx2.commit();
								sessionHQL2.close();
							}
							
							
											
				} else {
					msg = "Data Not Exits";
				}
			}
		}

		catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn�t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return msg;
	}
	
	@RequestMapping(value = "IndexSlipExportUrl", method = RequestMethod.GET)
	public ModelAndView IndexSlipExportUrl(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
		
		
		int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
		
		if (esid_sub_subject_id != 0) {
			List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
			String sub_subject_name=SubSubject.get(0).getSub_subject();
			Mmap.put("sub_subject_name", sub_subject_name);
		}
		
		int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		if(esi_es_id != 0) {
		List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esi_es_id);
		Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
		LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		
		  int day = date.getDayOfMonth();
		  
		  
		  Month month = date.getMonth();
		  int year = date.getYear();
		String begindateShow= day +" "+ month + " "+ year;
		 
		 Mmap.put("begindateShow",begindateShow);
		 Mmap.put("esid_es_id",esi_es_id);
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
		if (esid_sc_subject_id != 0) {
		List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
		Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
		Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
		List<SUBJECT_CODE_M>ActiveSubName= comm.getsubjectIdbysubname( sessionFactory, esid_sc_subject_id, ec_exam_id);
		ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
		Mmap.put("getexamcentrelist", examcentrelist);
		 Mmap.put("ActiveSub",ActiveSubName.get(0).getSc_subject_name());
		 List<INDEXED_PACKING_NOTES_MASTER>bundleprefix=  comm.getBundlePrefixList(sessionFactory,esi_es_id,esid_sc_subject_id) ;
		 Mmap.put("bundle_prefix", bundleprefix);
			}
		}
		Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
		Mmap.put("msg", msg);
		
		return new ModelAndView("IndexSlipExporttiles");
	}
	
	//=========================================IndexSlipExportUrlPartb  start
		@RequestMapping(value = "IndexSlipExportUrlPartb", method = RequestMethod.GET)
		public ModelAndView IndexSlipExportUrlPartb(ModelMap Mmap, HttpSession session,
				@RequestParam(value = "msg", required = false) String msg)
				throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
				NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

			int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
			
			
			int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
					: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
			
			if (esid_sub_subject_id != 0) {
				List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
				String sub_subject_name=SubSubject.get(0).getSub_subject();
				Mmap.put("sub_subject_name", sub_subject_name);
			}
			
			int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
			if(esi_es_id != 0) {
			List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esi_es_id);
			Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
			LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			
			  int day = date.getDayOfMonth();
			  
			  
			  Month month = date.getMonth();
			  int year = date.getYear();
			String begindateShow= day +" "+ month + " "+ year;
			 
			 Mmap.put("begindateShow",begindateShow);
			 Mmap.put("esid_es_id",esi_es_id);
			int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
			int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
			if (esid_sc_subject_id != 0) {
			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
			List<SUBJECT_CODE_M>ActiveSubName= comm.getsubjectIdbysubname( sessionFactory, esid_sc_subject_id, ec_exam_id);
			ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
			Mmap.put("getexamcentrelist", examcentrelist);
			 Mmap.put("ActiveSub",ActiveSubName.get(0).getSc_subject_name());
				}
			}
			Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
			Mmap.put("msg", msg);
			
			return new ModelAndView("IndexSlipExporttiles");
		}
		
	//	
				//=================================IndexSlipExportUrlPartd 
			@RequestMapping(value = "IndexSlipExportUrlPartd", method = RequestMethod.GET)
			public ModelAndView IndexSlipExportUrlPartd(ModelMap Mmap, HttpSession session,
					@RequestParam(value = "msg", required = false) String msg)
					throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
					NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

				int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
				
				
				int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
						: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
				
				if (esid_sub_subject_id != 0) {
					List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
					String sub_subject_name=SubSubject.get(0).getSub_subject();
					Mmap.put("sub_subject_name", sub_subject_name);
				}
				
				int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
				if(esi_es_id != 0) {
				List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esi_es_id);
				Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
				LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
				
				  int day = date.getDayOfMonth();
				  
				  
				  Month month = date.getMonth();
				  int year = date.getYear();
				String begindateShow= day +" "+ month + " "+ year;
				 
				 Mmap.put("begindateShow",begindateShow);
				 Mmap.put("esid_es_id",esi_es_id);
				int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
				int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
				if (esid_sc_subject_id != 0) {
				List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
				Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
				Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
				List<SUBJECT_CODE_M>ActiveSubName= comm.getsubjectIdbysubname( sessionFactory, esid_sc_subject_id, ec_exam_id);
				ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
				Mmap.put("getexamcentrelist", examcentrelist);
				 Mmap.put("ActiveSub",ActiveSubName.get(0).getSc_subject_name());
					}
				}
				Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
				Mmap.put("msg", msg);
				
				return new ModelAndView("IndexSlipExporttiles");
			}
			
	@RequestMapping(value = "IndexSlipExportUrlDSSC", method = RequestMethod.GET)
	public ModelAndView IndexSlipExportUrlDSSC(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0": session.getAttribute("es_id").toString());
		
		
		int esid_sub_subject_id = session.getAttribute("esid_sub_subject_id") == null ? 0
				: Integer.parseInt(session.getAttribute("esid_sub_subject_id").toString());
		
		if (esid_sub_subject_id != 0) {
			List<SUB_SUBJECT_MST>SubSubject=comm.getSubSubjectBySubId(sessionFactory, esid_sub_subject_id);
			String sub_subject_name=SubSubject.get(0).getSub_subject();
			Mmap.put("sub_subject_name", sub_subject_name);
		}
		
		int esi_es_id = Integer.parseInt(session.getAttribute("esid_es_id") == null ? "0" : session.getAttribute("esid_es_id").toString());
		if(esi_es_id != 0) {
		List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,esi_es_id);
		Date begin_date=UnlcokExmsch.get(0).getEs_begin_date();
		LocalDate date = begin_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		
		  int day = date.getDayOfMonth();
		  
		  
		  Month month = date.getMonth();
		  int year = date.getYear();
		String begindateShow= day +" "+ month + " "+ year;
		 
		 Mmap.put("begindateShow",begindateShow);
		 Mmap.put("esid_es_id",esi_es_id);
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
		int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
		if (esid_sc_subject_id != 0) {
		List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
		Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
		Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
		List<SUBJECT_CODE_M>ActiveSubName= comm.getsubjectIdbysubname( sessionFactory, esid_sc_subject_id, ec_exam_id);
		ArrayList<ArrayList<String>> examcentrelist = partBDao.getdatafromExaminationCentre(ec_exam_id);
		Mmap.put("getexamcentrelist", examcentrelist);
		 Mmap.put("ActiveSub",ActiveSubName.get(0).getSc_subject_name());
			}
		}
		Mmap.put("getcccommandnameListDDL", comm.getcccommandnameListDDL(sessionFactory));
		Mmap.put("msg", msg);
		
		return new ModelAndView("IndexSlipExporttiles");
	}
	
//	
	
	@RequestMapping(value = "/getRegisteredPartDIndexData", method = RequestMethod.POST)
	@ResponseBody public ArrayList<ArrayList<String>> getRegisteredPartDIndexData(HttpSession session,String bundle_name,
			String personal_code, String command ,String center) { 
		
		
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		System.err.println("personal_code=========="+personal_code);
		int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
		System.err.println("esid_sc_subject_id=========="+esid_sc_subject_id);
		ArrayList<ArrayList<String>> list = indedxdao.getRegisteredPartDData(es_id,esid_sc_subject_id,command,personal_code,center);
		return list;

	}
	
	@RequestMapping(value = "/Updatepsintingstatus", method = RequestMethod.POST)
	public @ResponseBody String Updatepsintingstatus(
			@ModelAttribute("IndexingabEntryCMD") INDEX_SLIP_MASTER index_slip_m, BindingResult result,
			HttpServletRequest request, ModelMap model, HttpSession session, String msg) {
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		try {
			int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
			 
			int esid_sc_subject_id = session.getAttribute("esid_sc_subject_id") == null ? 0 : Integer.parseInt(session.getAttribute("esid_sc_subject_id").toString());
			System.err.println("esid_sc_subject_id=========="+esid_sc_subject_id);
			 
			
			String application_no = request.getParameter("application_no");
			
			Query q0 = sessionHQL.createQuery(
					"select count(*) from TB_BARCODE_COUNT  where oa_app_id=:oa_app_id and print_status=:print_status and es_id=:es_id and subject_id=:subject_id");
			q0.setParameter("oa_app_id",Integer.parseInt(application_no) );
			q0.setParameter("print_status", 1);
			q0.setParameter("es_id", es_id);
			q0.setParameter("subject_id", esid_sc_subject_id);
			Long c = (Long) q0.uniqueResult();

			System.err.println("c=========="+c);

				if (c == 0) {

					
					Query qry01 = sessionHQL.createQuery("update TB_BARCODE_COUNT set print_status=:print_status "
							+ "where oa_app_id=:oa_app_id and es_id=:es_id and subject_id=:subject_id");
					qry01.setParameter("oa_app_id",Integer.parseInt(application_no) );
					qry01.setParameter("print_status", 1);
					qry01.setParameter("es_id", es_id);
					qry01.setParameter("subject_id", esid_sc_subject_id);
					qry01.executeUpdate();
					tx.commit();
				} else {
					msg = "Data Not Exits";
				}
			
		}

		catch (RuntimeException e) {
			try {
				tx.rollback();
				model.put("msg", "roll back transaction");
			} catch (RuntimeException rbe) {
				model.put("msg", "Couldn?t roll back transaction " + rbe);
			}
			throw e;
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}

		return msg;
	}
	
	
}