package com.BisagN.models.officers.trans;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "partbd_compens_chance", uniqueConstraints = {
@UniqueConstraint(columnNames = "pcc_id"),})

public class PARTBD_COMPENS_CHANCE_M {

      private int pcc_id;
      private int opd_personal_id;
      private String pcc_area;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date pcc_area_entry_date;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date pcc_area_leave_date;
      private String pcc_granted_year;
      private String pcc_remarks;
      private String pcc_exam;
      private int ec_exam_id;
      private String pcc_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date pcc_creation_date;
      private String pcc_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date pcc_modification_date;
  private String pcc_auth_doc;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "pcc_id", unique = true, nullable = false)


   
      public int getPcc_id() {
           return pcc_id;
      }
      public void setPcc_id(int pcc_id) {
	  this.pcc_id = pcc_id;
      }
      public int getOpd_personal_id() {
           return opd_personal_id;
      }
      public void setOpd_personal_id(int opd_personal_id) {
	  this.opd_personal_id = opd_personal_id;
      }
     
      public String getPcc_area() {
           return pcc_area;
      }
      public void setPcc_area(String pcc_area) {
	  this.pcc_area = pcc_area;
      }
     
     
      public Date getPcc_area_entry_date() {
           return pcc_area_entry_date;
      }
      public void setPcc_area_entry_date(Date pcc_area_entry_date) {
	  this.pcc_area_entry_date = pcc_area_entry_date;
      }
      public Date getPcc_area_leave_date() {
           return pcc_area_leave_date;
      }
      public void setPcc_area_leave_date(Date pcc_area_leave_date) {
	  this.pcc_area_leave_date = pcc_area_leave_date;
      }
      
      
      public String getPcc_remarks() {
           return pcc_remarks;
      }
      public void setPcc_remarks(String pcc_remarks) {
	  this.pcc_remarks = pcc_remarks;
      }
      
      public String getPcc_exam() {
           return pcc_exam;
      }
      public void setPcc_exam(String pcc_exam) {
	  this.pcc_exam = pcc_exam;
      }
      public int getEc_exam_id() {
           return ec_exam_id;
      }
      public void setEc_exam_id(int ec_exam_id) {
	  this.ec_exam_id = ec_exam_id;
      }
      
      public String getPcc_created_by() {
           return pcc_created_by;
      }
      public void setPcc_created_by(String pcc_created_by) {
	  this.pcc_created_by = pcc_created_by;
      }
      public Date getPcc_creation_date() {
           return pcc_creation_date;
      }
      public void setPcc_creation_date(Date pcc_creation_date) {
	  this.pcc_creation_date = pcc_creation_date;
      }
      public String getPcc_modified_by() {
           return pcc_modified_by;
      }
      public void setPcc_modified_by(String pcc_modified_by) {
	  this.pcc_modified_by = pcc_modified_by;
      }
      public Date getPcc_modification_date() {
           return pcc_modification_date;
      }
      public void setPcc_modification_date(Date pcc_modification_date) {
	  this.pcc_modification_date = pcc_modification_date;
      }
	public String getPcc_granted_year() {
		return pcc_granted_year;
	}
	public void setPcc_granted_year(String pcc_granted_year) {
		this.pcc_granted_year = pcc_granted_year;
	}
	public String getPcc_auth_doc() {
		return pcc_auth_doc;
	}
	public void setPcc_auth_doc(String pcc_auth_doc) {
		this.pcc_auth_doc = pcc_auth_doc;
	}
      
      
      
}
