package com.BisagN.controller.office.masters;


import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.masters.EXAMINATION_NAME_MASTERDAO;
import com.BisagN.models.officers.masters.EXAM_CODE_M;




@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class EXAMINATION_NAME_MASTERController {


@Autowired
private EXAMINATION_NAME_MASTERDAO objDAO;

@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

@Autowired
	private RoleBaseMenuDAO roledao; 

HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();


         @RequestMapping(value = "EXAMINATION_NAME_MASTER_Url", method = RequestMethod.GET)
         public ModelAndView EXAMINATION_NAME_MASTER_Url(ModelMap Mmap,HttpSession session,HttpServletRequest request,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
  NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

        	 
        	 if(request.getHeader("Referer") == null ) { 
    			 session.invalidate();
    			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
    			 return new ModelAndView("redirect:/login");
    		 }

        	 String roleid1 = session.getAttribute("roleid").toString();
    		 Boolean val = roledao.ScreenRedirect("EXAMINATION_NAME_MASTER_Url", roleid1);		
    			if(val == false) {
    				return new ModelAndView("AccessTiles");
    		}	
    		
    		
        	 
             Mmap.put("msg", msg);
         return new ModelAndView("EXAMINATION_NAME_MASTER_tile","EXAMINATION_NAME_MASTERCMD",new EXAM_CODE_M());
}
 @RequestMapping(value = "/getEXAMINATION_NAME_MASTERReportDataList", method = RequestMethod.POST)
 public @ResponseBody List<Map<String, Object>> getEXAMINATION_NAME_MASTERReportDataList(int startPage,String pageLength,String Search,String orderColunm,String orderType,HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
	return objDAO.getReportListEXAMINATION_NAME_MASTER(startPage,pageLength,Search,orderColunm,orderType,sessionUserId);
}

 @RequestMapping(value = "/getEXAMINATION_NAME_MASTERTotalCount", method = RequestMethod.POST)
public @ResponseBody long getEXAMINATION_NAME_MASTERTotalCount(HttpSession sessionUserId,String Search,String name){
	return objDAO.getReportListEXAMINATION_NAME_MASTERTotalCount(Search);
}
  @RequestMapping(value = "/EXAMINATION_NAME_MASTERAction" ,method = RequestMethod.POST) 
  public ModelAndView EXAMINATION_NAME_MASTERAction(@Valid @ModelAttribute("EXAMINATION_NAME_MASTERCMD") EXAM_CODE_M ln, BindingResult result, 
  HttpServletRequest request, ModelMap model, HttpSession session){ 

 
	  if(request.getParameter("ec_exam_name").equals("") || request.getParameter("ec_exam_name")==null ||
				request.getParameter("ec_exam_name")=="null" || request.getParameter("ec_exam_name").equals(null))
		{
			model.put("msg", "Please Enter Exam Name");
			return new ModelAndView("redirect:EXAMINATION_NAME_MASTER_Url");
		}
// int errCount=0;
//
//    if(request.getParameter("ec_exam_name").equals("") || request.getParameter("ec_exam_name") == null) 
//    { 
// errCount ++;
// model.put("ec_exam_name_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Examination Name");
//    } 
// if(errCount > 0) {
//
//     return new ModelAndView("EXAMINATION_NAME_MASTER_tile");
//  }
 int id = ln.getId() > 0 ? ln.getId() : 0;
	Date date = new Date();
	String username = session.getAttribute("username").toString();
	 Session sessionHQL = this.sessionFactory.openSession();
	    Transaction tx = sessionHQL.beginTransaction(); 

	try {

		Query q0 = sessionHQL.createQuery(
				"select count(id) from EXAM_CODE_M where   LOWER(ec_exam_name)=:ec_exam_name and id!=:id");

		q0.setParameter("ec_exam_name", ln.getEc_exam_name().toLowerCase());
		q0.setParameter("id", id);
		Long c = (Long) q0.uniqueResult();

		
		if (id == 0) {
			ln.setEc_created_by(username);
			ln.setEc_creation_date(date);
			ln.setEc_status_id(1);
			if (c == 0) {

				sessionHQL.save(ln);
				sessionHQL.flush();
				sessionHQL.clear();
				model.put("msg", "Data Saved Successfully.");

			} else {
				model.put("msg", "Data already Exist.");
			}
		}

	
		tx.commit();
	} catch (RuntimeException e) {
		try {
			tx.rollback();
			model.put("msg", "roll back transaction");
		} catch (RuntimeException rbe) {
			model.put("msg", "Couldn�t roll back transaction " + rbe);
		}
		throw e;
	} finally {
		if (sessionHQL != null) {
			sessionHQL.close();
		}
	}

	return new ModelAndView("redirect:EXAMINATION_NAME_MASTER_Url");
}
 
    
   
         @RequestMapping(value = "EditEXAMINATION_NAME_MASTERUrl", method = RequestMethod.POST)
         public ModelAndView EditEXAMINATION_NAME_MASTERUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String updateid) {


                Session s1 = this.sessionFactory.openSession();
                Transaction tx = s1.beginTransaction();
                String enckey = "commonPwdEncKeys";  
                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
                Query q = null;
                q = s1.createQuery("from EXAM_CODE_M where cast(id as string)=:PK");
                q.setString("PK", DcryptedPk);
                @SuppressWarnings("unchecked")
                List<String> list = (List<String>) q.list();
                tx.commit();
                s1.close();
                Mmap.put("EditEXAMINATION_NAME_MASTERCMD1", list.get(0));
                Mmap.put("msg", msg);
         return new ModelAndView("EditEXAMINATION_NAME_MASTER_tile","EditEXAMINATION_NAME_MASTERCMD",new EXAM_CODE_M());
}
  @RequestMapping(value = "/EditEXAMINATION_NAME_MASTERAction" ,method = RequestMethod.POST) 
  public ModelAndView EditEXAMINATION_NAME_MASTERAction(@Valid @ModelAttribute("EditEXAMINATION_NAME_MASTERCMD") EXAM_CODE_M ln, BindingResult result, 
  HttpServletRequest request, ModelMap model, HttpSession session){ 

 
// int errCount=0;
//
//    if(request.getParameter("ec_exam_name").equals("") || request.getParameter("ec_exam_name") == null) 
//    { 
// errCount ++;
// model.put("ec_exam_name_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Examination Name");
//    } 
// if(errCount > 0) {
//
//     return new ModelAndView("EditEXAMINATION_NAME_MASTER_tile");
//  }
	  if(request.getParameter("ec_exam_name").equals("") || request.getParameter("ec_exam_name")==null ||
				request.getParameter("ec_exam_name")=="null" || request.getParameter("ec_exam_name").equals(null))
		{
			model.put("msg", "Please Enter Exam Name");
			return new ModelAndView("redirect:EXAMINATION_NAME_MASTER_Url");
		}
 
    Session sessionHQL = this.sessionFactory.openSession(); 
    Transaction tx = sessionHQL.beginTransaction(); 
    ln.setId(Integer.parseInt(request.getParameter("id")));
	ln.setEc_status_id(1);
    sessionHQL.saveOrUpdate(ln); 
    tx.commit(); 
    sessionHQL.close(); 

 
    model.put("msg","Data Updated Successfully"); 
    return new ModelAndView("redirect:EXAMINATION_NAME_MASTER_Url"); 
  } 
  @RequestMapping(value = "/deleteEXAMINATION_NAME_MASTERUrl", method = RequestMethod.POST) 
  public ModelAndView deleteEXAMINATION_NAME_MASTERUrl(String deleteid,HttpSession session,ModelMap model) { 
  	List<String> list = new ArrayList<String>(); 
  	list.add(objDAO.DeleteEXAMINATION_NAME_MASTER(deleteid,session)); 
  	model.put("msg",list);  
    return new ModelAndView("redirect:EXAMINATION_NAME_MASTER_Url"); 
  	}
} 
