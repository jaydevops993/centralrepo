package com.BisagN.dao.officer.trans;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface SupplymentryDAO {
	
	public ArrayList<ArrayList<String>> getSupplymntryDetails(int startPage,String pageLength,String Search,String orderColunm,
			String orderType,int es_id,String opd_personal_id, HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, 
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	public long getSupplymntryDetailsCount(String Search,int es_id,String opd_personal_id);
	public ArrayList<ArrayList<String>> getPartPassedandFailuresForSulymntryRpt(String es_year,String oa_application_id);
	public ArrayList<ArrayList<String>> getoldSerno(int es_id,int repo_no,int oapp_id);

}
