package com.BisagN.dao.Indexing;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;


@Service
public class StickerGenerationDAOImpl implements StickerGenerationDAO  {

	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	 CommonController comm= new CommonController();
	
	public ArrayList<ArrayList<String>> getIndexNoByPackingBundle(int es_id, int user_id, String bundle_packing_id,
			String role) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q1 = "";
			String q2 = "";

//			if (role.equals("Index Group")) {
//				q2 += "and ibm.ibm_iu_user_id=?";
//
//			}

			System.err.println("bundle_packing_id======" + bundle_packing_id);

//			String q = "select DISTINCT tbc.oa_app_id from indexed_bundle_master as ibm inner join\n"
//					+ "index_slip_manual as ism on ibm.ibm_id = ism.is_ibm_id inner join \n"
//					+ "index_slip_master as ismt on ism.is_ism_id = ismt.ism_id inner join\n"
//					+ "tb_barcode_count as tbc on tbc.is_id = ism.is_id\n"
//					+ "where ibm_id = ?";
			
			String q = "select DISTINCT ismt.ism_indexno,tbc.oa_app_id from indexed_bundle_master as ibm inner join\n"
					+ "index_slip_manual as ism on ibm.ibm_id = ism.is_ibm_id inner join\n"
					+ "index_slip_master as ismt on ism.is_ism_id = ismt.ism_id inner join\n"
					+ "tb_barcode_count as tbc on tbc.is_id = ism.is_id\n"
					+ "where ibm_id = ?";
			
			
			stmt = conn.prepareStatement(q);
//			stmt.setInt(1, es_id);

			stmt.setInt(1, Integer.parseInt(bundle_packing_id));

//			if (role.equals("Index Group")) {
//				stmt.setInt(3, user_id);
//			}
			System.out.println("stmt=========++++++++"+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("oa_app_id"));
				list.add(rs.getString("ism_indexno"));
//				list.add(rs.getString("ibm_bundle_prefix") + (rs.getString("ibm_bundle_no")));// 0

				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}

	@Override
	public ArrayList<ArrayList<String>> getApplicationNoByPackingBundle(int es_id, int user_id, String application_no,int subjectID,
			String role) {
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		System.err.println("application_no======" + es_id);
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement stmt = null;
			String q1 = "";
			String q2 = "";

//			if (role.equals("Index Group")) {
//				q2 += "and ibm.ibm_iu_user_id=?";
//
//			}

			

			String q = "select barcode_no from tb_barcode_count where oa_app_id = ? and subject_id = ?";
			stmt = conn.prepareStatement(q);
			stmt.setInt(1, Integer.parseInt(application_no));

			stmt.setInt(2, subjectID);

//			if (role.equals("Index Group")) {
//				stmt.setInt(3, user_id);
//			}
			System.out.println("stmt=========++++++++"+stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				list.add(rs.getString("barcode_no"));
//				list.add(rs.getString("ibm_bundle_prefix") + (rs.getString("ibm_bundle_no")));// 0

				alist.add(list);
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
		
	}

}
