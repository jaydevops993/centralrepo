package com.BisagN.controller.office.trans;

import java.io.BufferedReader;
import java.io.FileReader;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.officer.others.ExaminationlockunlockDAO;
import com.BisagN.dao.officer.others.ProcessResultDao;
import com.BisagN.dao.officer.report.PartB_ReportDAO;
import com.BisagN.dao.officer.report.PartD_ReportDAO;
import com.BisagN.dao.officer.trans.Process_Result_DSSC_Dao;
import com.BisagN.dao.officer.trans.Unfair_meansDAO;
import com.BisagN.models.officers.masters.EXAM_CODE_M;

@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class ProcessResultDsscController {

	@Autowired
	private Unfair_meansDAO objDAO;

	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@Autowired
	CommonController comm = new CommonController();

	@Autowired
	ExaminationlockunlockDAO exmlkunlkDao;

	@Autowired
	PartB_ReportDAO partbreportDao;

	@Autowired
	ProcessResultDao prsDao;

	@Autowired
	PartD_ReportDAO partDreportDao;

	@Autowired
	Process_Result_DSSC_Dao process_Result_DSSC_Dao;

	@RequestMapping(value = "Process_results_Url_DSSC", method = RequestMethod.GET)
	public ModelAndView Process_results_Url_DSSC(ModelMap Mmap, HttpSession session,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? ""
				: session.getAttribute("es_begin_dateshow").toString();
		System.err.println("es_begindate===========" + es_begindate);

		int es_id = Integer
				.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0
				: Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		if (ec_exam_id == 3) {
			Mmap.put("ec_exam_id", ec_exam_id);

			List<EXAM_CODE_M> Exam_name = comm.getExamNamebyExmID(sessionFactory, ec_exam_id);
			Mmap.put("getsubjectbyexmid", comm.getsubjectlist(sessionFactory, ec_exam_id));
			Mmap.put("exam_name", Exam_name.get(0).getEc_exam_name());
			if (!es_begindate.equals("")) {
				Mmap.put("DSSC_begindate", es_begindate);
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}

		}

		Mmap.put("msg", msg);
		return new ModelAndView("ProcessResultDssc_tiles");
	}

	@ResponseBody
	@RequestMapping(value = "/admin/GenerateMerit", method = RequestMethod.POST, produces = { "application/json" })
	public String GenerateMerit(HttpServletRequest request) {
		JSONObject object = new JSONObject();

		try {
			System.out.println("Method Called");

			int es_id = Integer.parseInt(request.getSession().getAttribute("es_id").toString());
			System.err.println("es_id " + es_id);
			// es_id =160;
			List subject_with_cutoff_list = process_Result_DSSC_Dao.getSubjectListWithCutOff(es_id);
			System.err.println("subject_with_cutoff_list" + subject_with_cutoff_list.size());
			object = new JSONObject();
			object.put("Status", "1");
			object.put("Message", "Merit Generated Successfully");

		} catch (Exception e) {
			e.printStackTrace();
			object = new JSONObject();
			object.put("Status", "0");
			object.put("Message", "Something went wrong");
		}
		return object.toJSONString();
	}

	@ResponseBody
	@RequestMapping(value = "/admin/GenerateMeritExcel", method = RequestMethod.GET, produces = { "application/json" })
	public String GenerateMeritExcel(HttpServletRequest request) {
//		JSONArray jSONArray = new JSONArray();
		JSONObject object = new JSONObject();

		try {
			System.out.println("Method Called");

			String line = "";
			// csv file containing data
			BufferedReader br = new BufferedReader(
					new FileReader("/home/user/Desktop/cpvtbl.csv"));
			while ((line = br.readLine()) != null) {
				// use comma as separator
				String[] cols = line.split(",");

				process_Result_DSSC_Dao.generateMerit(cols);

			}

		} catch (Exception e) {
			e.printStackTrace();
			object = new JSONObject();
			object.put("Status", "0");
			object.put("Message", "Something went wrong");
		}
		return object.toJSONString();
	}

}
