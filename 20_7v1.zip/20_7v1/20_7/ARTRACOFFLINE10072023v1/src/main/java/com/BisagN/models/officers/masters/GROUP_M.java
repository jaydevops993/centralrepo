package com.BisagN.models.officers.masters;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "group_master", uniqueConstraints = {
@UniqueConstraint(columnNames = "gm_ngroupid"),})
public class GROUP_M {
	
	
	private int gm_ngroupid;
	private String gm_groupname;
	private String gm_role_flag;
	private String created_by;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date created_date;
	private String modified_by;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date modified_date;
	
	@Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "gm_ngroupid", unique = true, nullable = false)
	
	public int getGm_ngroupid() {
		return gm_ngroupid;
	}
	public void setGm_ngroupid(int gm_ngroupid) {
		this.gm_ngroupid = gm_ngroupid;
	}
	public String getGm_groupname() {
		return gm_groupname;
	}
	public void setGm_groupname(String gm_groupname) {
		this.gm_groupname = gm_groupname;
	}
	public String getGm_role_flag() {
		return gm_role_flag;
	}
	public void setGm_role_flag(String gm_role_flag) {
		this.gm_role_flag = gm_role_flag;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public Date getModified_date() {
		return modified_date;
	}
	public void setModified_date(Date modified_date) {
		this.modified_date = modified_date;
	}
}
