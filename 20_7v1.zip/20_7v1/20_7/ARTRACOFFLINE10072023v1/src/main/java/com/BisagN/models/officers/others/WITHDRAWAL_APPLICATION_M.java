package com.BisagN.models.officers.others;


import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "withdrawal_application", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class WITHDRAWAL_APPLICATION_M {

      private int id;
      private int oa_application_id;
      private int wa_chance;
      private String wa_remarks;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getOa_application_id() {
           return oa_application_id;
      }
      public void setOa_application_id(int oa_application_id) {
	  this.oa_application_id = oa_application_id;
      }
      public int getWa_chance() {
           return wa_chance;
      }
      public void setWa_chance(int wa_chance) {
	  this.wa_chance = wa_chance;
      }
	public String getWa_remarks() {
		return wa_remarks;
	}
	public void setWa_remarks(String wa_remarks) {
		this.wa_remarks = wa_remarks;
	}
     
}
