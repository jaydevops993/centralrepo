package com.BisagN.models.officers.trans;


import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "exam_center_code", uniqueConstraints = {
@UniqueConstraint(columnNames = "ecc_center_code"),})

public class EXAM_CENTER_CODE_M {

    
      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "ecc_center_code", unique = true, nullable = false)
      private int ecc_center_code;
      private int cc_command_id;
      private int ec_exam_id;
      private String ecc_name;
      private String ecc_cond_formation;
      private String center_code;
      private int ecc_status_id;
      private String ecc_created_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date ecc_creation_date;
      private String ecc_modified_by;
  @DateTimeFormat(pattern = "dd/MM/yyyy")
      private Date ecc_modification_date;

    
      public int getEcc_center_code() {
           return ecc_center_code;
      }
      public void setEcc_center_code(int ecc_center_code) {
	  this.ecc_center_code = ecc_center_code;
      }
      public int getCc_command_id() {
           return cc_command_id;
      }
      public void setCc_command_id(int cc_command_id) {
	  this.cc_command_id = cc_command_id;
      }
      public int getEc_exam_id() {
           return ec_exam_id;
      }
      public void setEc_exam_id(int ec_exam_id) {
	  this.ec_exam_id = ec_exam_id;
      }
      public String getEcc_name() {
           return ecc_name;
      }
      public void setEcc_name(String ecc_name) {
	  this.ecc_name = ecc_name;
      }
      public String getEcc_cond_formation() {
           return ecc_cond_formation;
      }
      public void setEcc_cond_formation(String ecc_cond_formation) {
	  this.ecc_cond_formation = ecc_cond_formation;
      }
      public String getCenter_code() {
           return center_code;
      }
      public void setCenter_code(String center_code) {
	  this.center_code = center_code;
      }
      public int getEcc_status_id() {
           return ecc_status_id;
      }
      public void setEcc_status_id(int ecc_status_id) {
	  this.ecc_status_id = ecc_status_id;
      }
      public String getEcc_created_by() {
           return ecc_created_by;
      }
      public void setEcc_created_by(String ecc_created_by) {
	  this.ecc_created_by = ecc_created_by;
      }
      public Date getEcc_creation_date() {
           return ecc_creation_date;
      }
      public void setEcc_creation_date(Date ecc_creation_date) {
	  this.ecc_creation_date = ecc_creation_date;
      }
      public String getEcc_modified_by() {
           return ecc_modified_by;
      }
      public void setEcc_modified_by(String ecc_modified_by) {
	  this.ecc_modified_by = ecc_modified_by;
      }
      public Date getEcc_modification_date() {
           return ecc_modification_date;
      }
      public void setEcc_modification_date(Date ecc_modification_date) {
	  this.ecc_modification_date = ecc_modification_date;
      }
}
