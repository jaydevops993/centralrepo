package com.BisagN.controller.office.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.officer.trans.Unfair_meansDAO;
import com.BisagN.models.officers.trans.UNFAIR_MEANS_M;



@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class ACR_marksController {


@Autowired
private Unfair_meansDAO objDAO;

HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();


@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;


         @RequestMapping(value = "ACR_marks_Url", method = RequestMethod.GET)
         public ModelAndView ACR_marks_Url(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) 
        		 throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
  NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

            // Mmap.put("getscsubjectnameListDDL", getscsubjectnameListDDL(session));
             Mmap.put("msg", msg);
         return new ModelAndView("ACR_marks_tile");
}
// public List<SUBJECT_CODE_M> getscsubjectnameListDDL(HttpSession sessionU) {
//   	Session session = this.sessionFactory.openSession();
//		Transaction tx = session.beginTransaction();
//		Query q = session.createQuery("from SUBJECT_CODE_M order by sc_subject_id");
//		@SuppressWarnings("unchecked")
//		List<SUBJECT_CODE_M>  list = (List<SUBJECT_CODE_M>) q.list();
//		tx.commit();
//		session.close();
//		return list;
//	}
         @RequestMapping(value = "SearchACR_marksUrl", method = RequestMethod.GET)
         public ModelAndView SearchACR_marksUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
  NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

               Mmap.put("msg", msg);
         return new ModelAndView("SearchUnfair_means_tile","Searchunfair_meansCMD",new UNFAIR_MEANS_M());
}
// @RequestMapping(value = "/getACR_marksReportDataList", method = RequestMethod.POST)
// public @ResponseBody List<Map<String, Object>> getACR_marksReportDataList(int startPage,String pageLength,String Search,String orderColunm,String orderType,HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
//	return objDAO.getReportListUnfair_means(startPage,pageLength,Search,orderColunm,orderType,sessionUserId);
//}
//
// @RequestMapping(value = "/getACR_marksTotalCount", method = RequestMethod.POST)
//public @ResponseBody long getACR_marksTotalCount(HttpSession sessionUserId,String Search,String name){
//	return objDAO.getReportListUnfair_meansTotalCount(Search);
//}
 
 
 
  @RequestMapping(value = "/ACR_marksAction" ,method = RequestMethod.POST) 
  public ModelAndView ACR_marksAction(   BindingResult result, 
  HttpServletRequest request, ModelMap model, HttpSession session){
	  
	  
	
//		Date date = new Date();
//		String username = session.getAttribute("username").toString();
//		Session sessionHQL = this.sessionFactory.openSession();
//		Transaction tx = sessionHQL.beginTransaction();
//
//		try {

			//Query qry = sessionHQL.createQuery("update DSSC_TSOC_APPLICATION_M  set dta_acr_marks=:dta_acr_marks where pers_adv_details=:pers_adv_details and pers_trade_id=:pers_trade_id and id=:pers_id");
//			qry.setParameter("confirm_status","3");
//			qry.setParameter("pers_adv_details",adv_details);
//			qry.setParameter("pers_trade_id",post_id);
//			qry.setParameter("pers_id",Integer.parseInt(pers_id));
//			qry.executeUpdate();
//			tx_i.commit();
//			session2.close();
//			
//			Long c = (Long) q0.uniqueResult();
//
//			if (id == 0) {
//
//				acr.setCreated_by(username);
//			acr.setCreated_date(date);
//				if (c == 0) {
//
//					sessionHQL.save(acr);
//					sessionHQL.flush();
//					sessionHQL.clear();
//					model.put("msg", "Data Saved Successfully.");
//
//				} else {
//					model.put("msg", "Data already Exist.");
//				}
//			}
//			else {
//
//				acr.setModified_by(username);
//				acr.setModified_date(date);
//				if (c == 0) {
//					String msg = dis.updateDistrict(DS);
//					model.put("msg", msg);
//				} else {
//					model.put("msg", "Data already Exist.");
//				}
//			}
//
//			tx.commit();
//		} catch (RuntimeException e) {
//			try {
//				tx.rollback();
//				model.put("msg", "roll back transaction");
//			} catch (RuntimeException rbe) {
//				model.put("msg", "Couldn�t roll back transaction " + rbe);
//			}
//			throw e;
//		} 
	  return new ModelAndView("redirect:ACR_marks_Url");
}





         @RequestMapping(value = "EditACR_marksUrl", method = RequestMethod.POST)
         public ModelAndView EditACR_marksUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String updateid) {


                Session s1 = this.sessionFactory.openSession();
                Transaction tx = s1.beginTransaction();
                String enckey = "commonPwdEncKeys";  
                String DcryptedPk = hex_asciiDao.decrypt((String) updateid,enckey,session); 
                Query q = null;
                q = s1.createQuery("from UNFAIR_MEANS_M where cast(id as string)=:PK");
                q.setString("PK", DcryptedPk);
                @SuppressWarnings("unchecked")
                List<String> list = (List<String>) q.list();
                tx.commit();
                s1.close();
                Mmap.put("Editunfair_meansCMD1", list.get(0));
             //Mmap.put("getscsubjectnameListDDL", getscsubjectnameListDDL(session));
                Mmap.put("msg", msg);
         return new ModelAndView("EditUnfair_means_tile","Editunfair_meansCMD",new UNFAIR_MEANS_M());
}
  @RequestMapping(value = "/EditACR_marksAction" ,method = RequestMethod.POST) 
  public ModelAndView EditACR_marksAction( @ModelAttribute("Editunfair_meansCMD") UNFAIR_MEANS_M ln, BindingResult result, 
  HttpServletRequest request, ModelMap model, HttpSession session){ 

 
 int errCount=0;

    if(request.getParameter("opd_personal_id").equals("") || request.getParameter("opd_personal_id") == null) 
    { 
 errCount ++;
 model.put("opd_personal_id_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Personal Number");
    } 
    if(request.getParameter("es_id") == "undefined") 
    { 
 errCount ++;
 model.put("es_id_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Select Examination");
    } 
    if(request.getParameter("sc_subject_id").equals("0") || request.getParameter("sc_subject_id").equals("")) 
    { 
 errCount ++;
 model.put("sc_subject_id_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Subject");
    } 
    if(request.getParameter("um_remarks").equals("") || request.getParameter("um_remarks") == null) 
    { 
 errCount ++;
 model.put("um_remarks_lbl","<i class='fa fa-exclamation'></i>&nbsp;Please Enter Remarks");
    } 
 if(errCount > 0) {

     return new ModelAndView("EditUnfair_means_tile");
  }

 
    Session sessionHQL = this.sessionFactory.openSession(); 
    Transaction tx = sessionHQL.beginTransaction(); 
    ln.setId(Integer.parseInt(request.getParameter("id")));
    sessionHQL.saveOrUpdate(ln); 
    tx.commit(); 
    sessionHQL.close(); 

 
    model.put("msg","Data Updated Successfully"); 
    return new ModelAndView("redirect:Searchunfair_meansUrl"); 
  } 
  @RequestMapping(value = "/deleteACR_marksUrl", method = RequestMethod.POST) 
  public ModelAndView deleteACR_marksUrl(String deleteid,HttpSession session,ModelMap model) { 
  	List<String> list = new ArrayList<String>(); 
  	list.add(objDAO.Deleteunfair_means(deleteid,session)); 
  	model.put("msg",list);  
    return new ModelAndView("redirect:Searchunfair_meansUrl"); 
  	}
} 
