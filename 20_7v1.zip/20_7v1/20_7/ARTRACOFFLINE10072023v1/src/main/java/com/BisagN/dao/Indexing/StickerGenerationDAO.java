package com.BisagN.dao.Indexing;

import java.util.ArrayList;

public interface StickerGenerationDAO {

	
	public ArrayList<ArrayList<String>> getIndexNoByPackingBundle(int es_id, int user_id,String bundle_no_id, String role);
	
	public ArrayList<ArrayList<String>>getApplicationNoByPackingBundle(int es_id, int user_id,String application_no,int subjectID, String role);
}
