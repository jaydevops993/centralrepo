package com.BisagN.controller.office_DSSC_MeritRerport;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.BisagN.controller.office_DSSC_MeritRerport.MeritDSSCReportPdf_controller.PageNumeration;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

public class MeritDSTSCReport_controller extends AbstractPdfView {

	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	String exam="";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	int totalRecords=0;
	private static final DecimalFormat decfor = new DecimalFormat("0.00");  

	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public MeritDSTSCReport_controller(String Type, List<String> TH, String Heading, String username,String exam) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
		this.exam = exam;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		
		document.setPageSize(PageSize.LEGAL.rotate()); 
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		String dstscCourseNo = (String) model.get("getdsscCourseVacancyReserveListForDSTSC");
		
		
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeadingdata = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 12, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 9, 0);
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		
	PdfPTable table6 = new PdfPTable(1);
	table6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	table6.setWidthPercentage(100);

//
//	document.setPageSize(two);
//	document.setMargins(20, 20, 20, 20);
//	document.newPage();

	PdfPTable table4_2 = new PdfPTable(1);
	table4_2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	table4_2.setWidthPercentage(100);

	PdfPTable tabledata4_2 = new PdfPTable(1);
	tabledata4_2.setWidths(new int[] { 7 });
	tabledata4_2.setWidthPercentage(100 / 3.5f);
	tabledata4_2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata4_2.setHorizontalAlignment(Element.ALIGN_RIGHT);
	tabledata4_2.getDefaultCell().setBorder(Rectangle.NO_BORDER);

	
	Chunk DSTSC_heading = new Chunk("LIST OF NOMINATED OFFICERS FOR DSTSC - " + dstscCourseNo + " \n \n \n", fontTableHeading1);
	DSTSC_heading.setUnderline(0.1f, -2f);
	Paragraph DSTSC_paragraph = new Paragraph(DSTSC_heading);
	DSTSC_paragraph.setFont(fontTableHeading1);
	DSTSC_paragraph.setAlignment(Element.ALIGN_CENTER);

	PdfPTable tableheader4_DSTSC = new PdfPTable(1);
	tableheader4_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	tableheader4_DSTSC.setWidthPercentage(100);
	tableheader4_DSTSC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
	tableheader4_DSTSC.addCell(DSTSC_paragraph);
//	tableheader4_DSTSC.addCell(new Paragraph(
//			"THE UNDER MENTIONED OFFICER LISTED IN THEIR ORDER OF SENIORITY BY ARMS AND \n  "
//					+ "SERVICES HAVE BEEN NOMINATED TO ATTEND THE DEFENCE SERVICES TECHNICAL STAFF COLLEGE COURSE COMMENCING-5\n\n",
//			fontTableHeadingSubMainHeadNew_2));

	PdfPTable tabledata41_DSTSC = new PdfPTable(5);
//tabledata41_DSTSC.getDefaultCell().setBorder(Rectangle.NO_BORDER);
	tabledata41_DSTSC.setWidths(new int[] { 2, 2, 3, 7, 4 });
	tabledata41_DSTSC.setWidthPercentage(100);
	tabledata41_DSTSC.getDefaultCell().setHorizontalAlignment(Element.ALIGN_LEFT);
	tabledata41_DSTSC.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
	tabledata41_DSTSC.setHeaderRows(1);

	ArrayList<List<String>> DSTSC = (ArrayList<List<String>>) model.get("fullypassed_D");
	Paragraph a_C2 = new Paragraph("SER NO", fontTableHeadingdata);
	Paragraph f_C2 = new Paragraph("PERS NO", fontTableHeadingdata);

	Paragraph b_C2 = new Paragraph("RANK", fontTableHeadingdata);
	Paragraph c_C2 = new Paragraph("NAME", fontTableHeadingdata);
	Paragraph d_C2 = new Paragraph("UNIT", fontTableHeadingdata);

	PdfPCell blank_cella1_C1 = new PdfPCell(a_C2);
	blank_cella1_C1.setPadding(5f);
	blank_cella1_C1.setPaddingLeft(35f);
	blank_cella1_C1.setBorder(Rectangle.BOTTOM);
	blank_cella1_C1.setHorizontalAlignment(Element.ALIGN_LEFT);

	PdfPCell blank_cella2_C1 = new PdfPCell(f_C2);
	blank_cella2_C1.setPadding(5);
	blank_cella2_C1.setBorder(Rectangle.BOTTOM);
	blank_cella2_C1.setHorizontalAlignment(Element.ALIGN_CENTER);

	PdfPCell blank_cella3_C1 = new PdfPCell(b_C2);
	blank_cella3_C1.setPadding(5);
	blank_cella3_C1.setBorder(Rectangle.BOTTOM);
	blank_cella3_C1.setHorizontalAlignment(Element.ALIGN_CENTER);

	PdfPCell blank_cella4_C1 = new PdfPCell(c_C2);
	blank_cella4_C1.setPadding(5);
	blank_cella4_C1.setBorder(Rectangle.BOTTOM);
	blank_cella4_C1.setHorizontalAlignment(Element.ALIGN_CENTER);

	PdfPCell blank_cella5_C1 = new PdfPCell(d_C2);
	blank_cella5_C1.setPadding(5);
	blank_cella5_C1.setBorder(Rectangle.BOTTOM);
	blank_cella5_C1.setHorizontalAlignment(Element.ALIGN_CENTER);

	tabledata41_DSTSC.addCell(blank_cella1_C1);
	tabledata41_DSTSC.addCell(blank_cella2_C1);
	tabledata41_DSTSC.addCell(blank_cella3_C1);
	tabledata41_DSTSC.addCell(blank_cella4_C1);
	tabledata41_DSTSC.addCell(blank_cella5_C1);

	String arm = "";
	ArrayList<List<String>> getnominateddstsclistReport = (ArrayList<List<String>>) model
			.get("userList");

	for (int i = 0; i < getnominateddstsclistReport.size(); i++) {

		List<String> l = getnominateddstsclistReport.get(i);
		Paragraph blank1 = new Paragraph(l.get(0), fontTableHeadingSubMainHead);
		Paragraph blank2 = new Paragraph(l.get(1), fontTableHeadingSubMainHead);
		Paragraph blank3 = new Paragraph(l.get(2), fontTableHeadingSubMainHead);
		Paragraph blank4 = new Paragraph(l.get(3), fontTableHeadingSubMainHead);
		Paragraph blank5 = new Paragraph(l.get(4), fontTableHeadingSubMainHead);
		Paragraph blank6 = new Paragraph(l.get(5) +"\n", fontTableHeadingdata);

		PdfPCell cellar = new PdfPCell();

		cellar.setFixedHeight(20f);
		if (i % 2 == 0) {
			cellar.setBackgroundColor(java.awt.Color.lightGray);
		}

		if (!l.get(5).equals(arm)) {
			arm = l.get(5);
			PdfPCell cellarow = new PdfPCell();
			cellarow.setColspan(5);
			cellarow.setPhrase(blank6);
			cellarow.setBorder(Rectangle.NO_BORDER);
			cellarow.setPadding(2);
			cellarow.setPaddingBottom(8f);
			cellarow.setHorizontalAlignment(Element.ALIGN_CENTER);
			tabledata41_DSTSC.addCell(cellarow);
		}
		
		cellar.setPhrase(blank1);
		cellar.setPadding(2);
		cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
		cellar.setBorder(Rectangle.NO_BORDER);
		tabledata41_DSTSC.addCell(cellar);

		cellar.setPhrase(blank2);
		cellar.setPadding(2);
		cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata41_DSTSC.addCell(cellar);

		cellar.setPhrase(blank3);
		cellar.setPadding(2);
		cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata41_DSTSC.addCell(cellar);

		cellar.setPhrase(blank4);
		cellar.setPadding(2);
		cellar.setHorizontalAlignment(Element.ALIGN_LEFT);
		tabledata41_DSTSC.addCell(cellar);

		cellar.setPhrase(blank5);
		cellar.setPadding(2);
		cellar.setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata41_DSTSC.addCell(cellar);

//		tabledata41_DSTSC.addCell(blank1);
//		tabledata41_DSTSC.addCell(blank2);
//		tabledata41_DSTSC.addCell(blank3);
//		tabledata41_DSTSC.addCell(blank4);
//		tabledata41_DSTSC.addCell(blank5);

	}
	
	 PageNumeration event = new PageNumeration(arg2);
		arg2.setPageEvent(event);
		document.setPageCount(1);	

//	PdfPCell cell1236_C12;
//	cell1236_C12 = new PdfPCell();
//	cell1236_C12.addElement(tabledata4_2);
//	cell1236_C12.addElement(new Paragraph("\n"));
//	cell1236_C12.addElement(tableheader4_DSTSC);
//	cell1236_C12.addElement(tabledata41_DSTSC);
//	cell1236_C12.setBorder(0);
		
		
		table6.setSplitLate(false);
		PdfPCell cell12356;
		cell12356 = new PdfPCell();
		cell12356.addElement(tableheader4_DSTSC);
//		cell12356.addElement(tabledata13);
		cell12356.setBorder(Rectangle.NO_BORDER);

		table6.addCell(cell12356);

		PdfPCell cell1235612;
		cell1235612 = new PdfPCell();
//		cell1235612.addElement(tableheader1);
		cell1235612.setBorder(Rectangle.BOX);
		cell1235612.addElement(tabledata41_DSTSC);

	
		table6.addCell(cell1235612);
		document.add(table6);
		super.buildPdfMetadata(model, document, request);
	}
	
	class PageNumeration extends PdfPageEventHelper {
		PdfTemplate total;
		PdfTemplate total1;

		public PageNumeration(PdfWriter writer) {
			try {
				total = writer.getDirectContent().createTemplate(30, 16);
				total1 = writer.getDirectContent().createTemplate(30, 16);
			} catch (Exception e) {
				e.getMessage();
			}
		}

		public void onOpenDocument(PdfWriter writer, Document document) {
			// total = writer.getDirectContent().createTemplate(30, 12);
		}

		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			String ip = "";
			try {
				table.setWidths(new int[] { 15,6,1});  
				table.setTotalWidth(document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin());
				table.setLockedWidth(true);
				table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
				Date now = new Date();
				String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
				table.addCell(dateString);  //table.addCell("TOTAL SHEET :");
				
				
				PdfPCell cell1 = new PdfPCell(Image.getInstance(total1));
				cell1.setBorder(Rectangle.NO_BORDER);
				cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			//	table.addCell(cell1);
								
			
				//String watermark = " Generated by "+username+" on "+dateString +" with IP " +ip ;
				
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				table.addCell(String.format("Pages %d of", writer.getPageNumber()));
				//table.addCell("Month :");
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.NO_BORDER);				
				table.addCell(cell);
				
				table.writeSelectedRows(0, -1, document.leftMargin(), document.topMargin() + 0, writer.getDirectContent());
			} catch (DocumentException de) {
				throw new ExceptionConverter(de);
			}
		}

		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT, new Phrase(String.valueOf(writer.getPageNumber() - 1)), 2, 2, 0);
			ColumnText.showTextAligned(total1, Element.ALIGN_LEFT, new Phrase(String.valueOf(totalRecords)), 2, 2, 0);
		}
	}
	

}
