package com.BisagN.controller.office.trans;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController;
import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.RoleBaseMenuDAO;
import com.BisagN.dao.officer.trans.CPVMarksDao;
import com.BisagN.models.officers.masters.SUBJECT_CODE_M;
import com.BisagN.models.officers.others.OFFICER_APPLICATION_M;
import com.BisagN.models.officers.others.OFFICER_PERSONAL_CODE_M;
import com.BisagN.models.officers.others.PARTB_D_APPLICATION_M;
import com.BisagN.models.officers.trans.CPV;

//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
@Controller
@RequestMapping(value = { "admin", "/", "user" })
public class ImportCPVMarksController {
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	
	@Autowired
	CommonController comm= new CommonController();
	
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	
	@Autowired
	CPVMarksDao cpv;
	
	  @Autowired
		private RoleBaseMenuDAO roledao;  
	
	@RequestMapping(value = "SearchCPV_MarksUrl", method = RequestMethod.GET)
	public ModelAndView SearchCPV_MarksUrl(ModelMap Mmap, HttpSession session,HttpServletRequest request,
			@RequestParam(value = "msg", required = false) String msg)
			throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

		
		 if(request.getHeader("Referer") == null ) { 
			 session.invalidate();
			 Mmap.put("msg", "Suspicious Activity Detected,You have been logged out by Administrator");
			 return new ModelAndView("redirect:/login");
		 }

    	 String roleid1 = session.getAttribute("roleid").toString();
		 Boolean val = roledao.ScreenRedirect("Command_code_master_Url", roleid1);		
			if(val == false) {
				return new ModelAndView("SearchCPV_MarksUrl");
		}	
		
		
		
		String es_begindate = session.getAttribute("es_begin_dateshow") == null ? "": session.getAttribute("es_begin_dateshow").toString();	
	
		int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
		int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());

		if (ec_exam_id ==3) {
			if (!es_begindate.equals("")) {
				Mmap.put("DSSC_begindate", es_begindate);
			}
			if (es_id != 0) {
				Mmap.put("es_id", es_id);
			}
			
		}
		Mmap.put("msg", msg);
		return new ModelAndView("CPV_tiles");
	}
	
	@RequestMapping(value = "ImportCPVMarks_Url", method = RequestMethod.GET)
    public ModelAndView ImportCPVMarks_Url(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, 
NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException{

        Mmap.put("msg", msg);
    return new ModelAndView("ImportCPV_tiles");
}
	//UPLOAD CANDIDATE DATA
	@RequestMapping(value = "/UploadCPVMarksAction", method = RequestMethod.POST)
	public ModelAndView UploadCPVMarksAction(HttpServletRequest request, ModelMap model, HttpSession session,RedirectAttributes ra,
			@RequestParam(value = "fileUpload", required = false) MultipartFile fileUpload)
	{
		ArrayList<ArrayList<String>> listerror=new ArrayList<ArrayList<String>>();
		Session sessionHQL = this.sessionFactory.openSession();
		Transaction tx = sessionHQL.beginTransaction();
		
		if(fileUpload==null) {
			 model.put("msg","Please Upload Copy Of File Upload");
			  return new ModelAndView("redirect:SearchCPV_MarksUrl");
		  }
		
		if(fileUpload.isEmpty()) {
			model.put("msg","Please Upload Copy Of File Upload");
			  return new ModelAndView("redirect:SearchCPV_MarksUrl");
		}
		
		try {

			int errorcount=0;
			String errormsg= "";
			File file = new File(comm.fileupload2(fileUpload.getBytes(), fileUpload.getOriginalFilename(), "cpv",""));
			FileInputStream fis = new FileInputStream(file);
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheetAt(0);
			Row row_head = sheet.getRow(0);
			Date date = new Date();
			String username = session.getAttribute("username").toString();
			String cpsc_status= request.getParameter("opd_cpsc_on_off");
			
		
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				ArrayList<String> listData = new ArrayList<String>();
				Row row = sheet.getRow(i);
				String N_personal_no="";
				String marks="";
				
				
				
				
				if (row.getCell(0) == null) {
					break;
				}
				
				for (int j = 0; j < 2; j++) {

					Cell cell = row.getCell(j);
					
					

					String value = "";
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						value = cell.getStringCellValue();
						break;
					case Cell.CELL_TYPE_NUMERIC:
						if (HSSFDateUtil.isCellDateFormatted(cell)) {
							value = String.valueOf(cell.getDateCellValue());
						} else {
							value = String.valueOf((double) cell.getNumericCellValue());
						}
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						value = String.valueOf(cell.getBooleanCellValue());
						break;
					default:
					}
				
		
					
					if (row_head.getCell(j).getStringCellValue().equals("IC_NO")) {
						N_personal_no=value;
					}
					if (row_head.getCell(j).getStringCellValue ().equals("MARKS")) {
						marks=value;
						
					}
					
					
					
					
					
				}
				
				List<OFFICER_PERSONAL_CODE_M> opdpers_id= comm.getopdIdbycode( sessionFactory, N_personal_no);
				
				if(opdpers_id.isEmpty()) {
					System.out.println("empty=========");
					 listData.add(N_personal_no);
					 listData.add(marks);
				     listData.add("The Personal Number is Wrong");
					 errormsg= N_personal_no +" The Personal Number is Wrong";
						model.put("msg",errormsg);
						errorcount++;
				}
				else {
				
					System.out.println("Not empty=========");
				int opd_pers_id= opdpers_id.get(0).getOpd_personal_id();
				int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
				List<OFFICER_APPLICATION_M>Oa_appId=comm.getOappIdbyopdId( sessionFactory, opd_pers_id, es_id);
				if(!Oa_appId.isEmpty()) {
				int oa_application_id=Oa_appId.get(0).getOa_application_id();
				System.out.println("oa_application_id================"+oa_application_id);
				System.out.println("marks================"+marks);
//				CPV cpv = new CPV();
//				cpv.setCpv_mks(Double.valueOf(marks));
//				cpv.setCreated_date(date);
//				cpv.setCreated_by(username);
//				cpv.setOpd_personal_id(opd_pers_id);
//				cpv.setOa_application_id(oa_application_id);
//				sessionHQL.save(cpv);
				
				
				 ArrayList<ArrayList<String>>PartDAttmpList=cpv.getPartDAttmptCountForCPV(opd_pers_id); 
				 
				 String PartDAttmptCount=PartDAttmpList.get(0).get(0);
				 
				
				 Session sessionHQL8 = this.sessionFactory.openSession();
					Transaction tx8 = sessionHQL8.beginTransaction();
				 String CPVquery = "update DSSC_TSOC_APPLICATION_M set dta_acr_marks=:dta_acr_marks where oa_application_id=:oa_application_id";
				 Query query8 = sessionHQL8.createQuery(CPVquery)
				 .setParameter("dta_acr_marks",marks)
				 .setParameter("oa_application_id",oa_application_id);
				 System.out.println("UPDATE QUERY================"+ query8);
				 query8.executeUpdate();
				 tx8.commit();
				 
				 if(PartDAttmptCount.equals("1")) {
					 Session sessionHQL1 = this.sessionFactory.openSession();
						Transaction tx1 = sessionHQL1.beginTransaction();
				String hq15 = "update CPV set cpv_mks=:cpv_mks where oa_application_id=:oa_application_id  ";
				Query query5 = sessionHQL1.createQuery(hq15)
						.setParameter("cpv_mks",Double.valueOf(marks)+15)
						.setParameter("oa_application_id",oa_application_id);
				query5.executeUpdate();
				tx1.commit(); 	
				 }
				 else if(PartDAttmptCount.equals("2")) {
					 Session sessionHQL2 = this.sessionFactory.openSession();
						Transaction tx2 = sessionHQL2.beginTransaction();
						String hq15 = "update CPV set cpv_mks=:cpv_mks where oa_application_id=:oa_application_id  ";
						Query query5 = sessionHQL2.createQuery(hq15)
								.setParameter("cpv_mks", Double.valueOf(marks)+12)
								.setParameter("oa_application_id",oa_application_id);
						query5.executeUpdate();
						tx2.commit(); 	
						 }
				 else  if(PartDAttmptCount.equals("3")) {
					 Session sessionHQL3 = this.sessionFactory.openSession();
						Transaction tx3 = sessionHQL3.beginTransaction();
						String hq15 = "update CPV set cpv_mks=:cpv_mks where oa_application_id=:oa_application_id  ";
						Query query5 = sessionHQL3.createQuery(hq15)
								.setParameter("cpv_mks", Double.valueOf(marks)+9)
								.setParameter("oa_application_id",oa_application_id);
						query5.executeUpdate();
						tx3.commit(); 	
				 }
				 else {
					 Session sessionHQL4 = this.sessionFactory.openSession();
						Transaction tx4 = sessionHQL4.beginTransaction();
					 String hq15 = "update CPV set cpv_mks=:cpv_mks where oa_application_id=:oa_application_id  ";
						Query query5 = sessionHQL4.createQuery(hq15)
								.setParameter("cpv_mks", Double.valueOf(marks))
								.setParameter("oa_application_id",oa_application_id);
						query5.executeUpdate();
						tx4.commit(); 	
				 }
				 
						
				ra.addAttribute("msg","Data saved successfully");
			
				}else {
					ra.addAttribute("msg",""+N_personal_no+" the application not generate");
					
				}
				
				

				if(!listData.isEmpty()) {
					listerror.add(listData);
				}
					
				
					
				model.put("errorlist", listerror);
	
					
					
				} 

			}
			tx.commit();	
		}
	
		 catch (Exception e) {
			//tx.rollback();
			e.printStackTrace();
		} finally {
			if (sessionHQL != null) {
				sessionHQL.close();
			}
		}
		
		ra.addFlashAttribute("errorlist",listerror);
		ra.addFlashAttribute("errorlistSize",listerror.size());
		return new ModelAndView("redirect:SearchCPV_MarksUrl");
	}	
	
	
	//Download DEMO EXCEL
			@RequestMapping(value = "/DemoCandidateExcelFORCPV", method = RequestMethod.POST)
			public ModelAndView DemoCandidateExcelFORCPV(HttpServletRequest request,ModelMap model,HttpSession session,String typeReport1) {
				
//				
			ArrayList<ArrayList<String>> listexport=new ArrayList<ArrayList<String>>();
			List<String> TH = new ArrayList<String>();
		    	
			    TH.add("IC_NO");
			    TH.add("MARKS");
			
				

				String Heading = "\n";
				String username = session.getAttribute("username").toString();
				return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList", listexport);
			}
	
			
			
			
			
			@RequestMapping(value = "/getCpvMarksDataList", method = RequestMethod.POST)
			 public @ResponseBody List<Map<String, Object>> getCpvMarksDataList(int startPage,String pageLength,String Search,String orderColunm,
					 String orderType,String pers_no,String opd_officer_name, HttpSession sessionUserId) 
							 throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
							 InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
				 
				 return cpv.getCPVmarksDetails(startPage,pageLength,Search,orderColunm,orderType,pers_no,opd_officer_name,sessionUserId);
			}

			 @RequestMapping(value = "/getCpvMarksCount", method = RequestMethod.POST)
			public @ResponseBody long getCpvMarksCount(HttpSession sessionUserId,String Search,String pers_no,String opd_officer_name){
				 return cpv.getgetCPVmarksDetailsTotalCount(Search,pers_no,opd_officer_name);
			}
			 
			 @RequestMapping(value = "EditCPVUrl", method = RequestMethod.POST)
				public ModelAndView EditCPVUrl(ModelMap Mmap, HttpSession session,
						@RequestParam(value = "msg", required = false) String msg, HttpServletRequest request) {

				 String updateid= request.getParameter("updateid");
					Session s1 = this.sessionFactory.openSession();
					Transaction tx = s1.beginTransaction();
					String enckey = "commonPwdEncKeys";
					String DcryptedPk = hex_asciiDao.decrypt((String) updateid, enckey, session);
					Query q = null;
					q = s1.createQuery("from CPV where cast(id as string)=:PK");
					q.setString("PK", DcryptedPk);
					@SuppressWarnings("unchecked")
					List<CPV> cpvlist = (List<CPV>) q.list();
					int opd_perid=cpvlist.get(0).getOpd_personal_id();
					
					List<OFFICER_PERSONAL_CODE_M> list=comm.getPersCodebyOpdID(sessionFactory,(opd_perid));
					
					Mmap.put("personal_code", list.get(0).getOpc_personal_code());
					Mmap.put("opd_perid", opd_perid);
					Mmap.put("cpvlist", cpvlist.get(0).getCpv_mks());
					Mmap.put("openpageurl", "editurl");
					tx.commit();
					s1.close();
					Mmap.put("msg", msg);
					return new ModelAndView("EditCPV_tiles");
				}
			 
			 
			 
				@RequestMapping(value = "/EditCPVAction", method = RequestMethod.POST)
				public ModelAndView EditCPVAction(ModelMap Mmap, HttpSession session, HttpServletRequest request) {

					Session sessionHQL = this.sessionFactory.openSession();
					Transaction tx = sessionHQL.beginTransaction();

					
					if(request.getParameter("opd_personal_id") =="") {
						Mmap.put("msg","Please Enter Personal Number");
						  return new ModelAndView("redirect:SearchCPV_MarksUrl");
					  }

					if(request.getParameter("marks").isEmpty() ) {
						Mmap.put("msg","Please Enter Marks");
						  return new ModelAndView("redirect:SearchCPV_MarksUrl");
					  }
					
					String opd_personal_id=request.getParameter("opd_personal_id");
					String opdid=request.getParameter("opd_id_hidden");
					double marks=Double.valueOf(request.getParameter("marks"));
					
					
					List<OFFICER_PERSONAL_CODE_M> opdpers_id= comm.getopdIdbycode( sessionFactory, opd_personal_id);
					
					if(opdpers_id.isEmpty()) {
						
						Mmap.put("msg","The Personal Number is Wrong");
					}
					
					else
					{
						int opd_pers_id= opdpers_id.get(0).getOpd_personal_id();
						int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
						 ArrayList<ArrayList<String>>PartDAttmpList=cpv.getPartDAttmptCountForCPV(opd_pers_id); 
						 
						 String PartDAttmptCount=PartDAttmpList.get(0).get(0);
						List<OFFICER_APPLICATION_M>Oa_appId=comm.getOappIdbyopdId( sessionFactory, opd_pers_id, es_id);
						int oa_application_id=Oa_appId.get(0).getOa_application_id();
						
						
						 if(PartDAttmptCount.equals("1")) {
								String hq15 = "update CPV set cpv_mks=:cpv_mks where oa_application_id=:oa_application_id  ";
								Query query5 = sessionHQL.createQuery(hq15)
										.setParameter("cpv_mks", marks+15)
										.setParameter("oa_application_id",(oa_application_id));
								query5.executeUpdate();
								tx.commit();
						 }
						 else if(PartDAttmptCount.equals("2")) {
								String hq15 = "update CPV set cpv_mks=:cpv_mks where oa_application_id=:oa_application_id  ";
								Query query5 = sessionHQL.createQuery(hq15)
										.setParameter("cpv_mks", marks+12)
										.setParameter("oa_application_id",(oa_application_id));
								query5.executeUpdate();
								tx.commit();
						 }
						 else if(PartDAttmptCount.equals("3")) {
								String hq15 = "update CPV set cpv_mks=:cpv_mks where oa_application_id=:oa_application_id  ";
								Query query5 = sessionHQL.createQuery(hq15)
										.setParameter("cpv_mks", marks+9)
										.setParameter("oa_application_id",(oa_application_id));
								query5.executeUpdate();
								tx.commit();
						 }
						 else {
								String hq15 = "update CPV set cpv_mks=:cpv_mks where oa_application_id=:oa_application_id  ";
								Query query5 = sessionHQL.createQuery(hq15)
										.setParameter("cpv_mks", marks)
										.setParameter("oa_application_id",(oa_application_id));
								query5.executeUpdate();
								tx.commit();
						 }
						 
								Mmap.put("msg", "Data Updated Successfully");
					}
					

					return new ModelAndView("redirect:SearchCPV_MarksUrl");

				}
				
				
				
				
				@RequestMapping(value = "Add_cpv_marks_Url", method = RequestMethod.POST)
				public ModelAndView Add_cpv_marks_Url(ModelMap Mmap, HttpSession session,
						@RequestParam(value = "msg", required = false) String msg)
						throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
						NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

					Mmap.put("openpageurl", "Addurl");
					Mmap.put("msg", msg);
					return new ModelAndView("EditCPV_tiles");
				}
				
				
				@ResponseBody
				@RequestMapping(value = "/admin/GenerateMeritExcel", method = RequestMethod.GET)
				public String GenerateMeritExcel(HttpServletRequest request) {
//					JSONArray jSONArray = new JSONArray();
//					JSONObject object = new JSONObject();

					try {
						System.out.println("Method Called");

						String line = "";
						// csv file containing data
						BufferedReader br = new BufferedReader(new FileReader("/home/user/Desktop/TAC_A.csv"));
						while ((line = br.readLine()) != null) {
							// use comma as separator
							String[] cols = line.split(",");
							
						
							cpv.generateMerit(cols);

						}

					} catch (Exception e) {
						e.printStackTrace();
//						object = new JSONObject();
//						object.put("Status", "0");
					}
					return "Success";
				}			
}
