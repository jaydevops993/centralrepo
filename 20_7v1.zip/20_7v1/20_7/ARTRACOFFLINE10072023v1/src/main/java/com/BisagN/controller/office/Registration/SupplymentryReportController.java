package com.BisagN.controller.office.Registration;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.BisagN.controller.CommonController;
import com.BisagN.controller.office.others.PartiallyPassPDFController;
import com.BisagN.controller.office.others.ResultReleasePDFController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;
import com.BisagN.dao.officer.others.SearchResultswithheldDAO;
import com.BisagN.dao.officer.report.PartB_ReportDAO;
import com.BisagN.dao.officer.trans.SupplymentryDAO;
import com.BisagN.models.officers.masters.EXAM_CODE_M;
import com.BisagN.models.officers.others.EXAM_SCHEDULE;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class SupplymentryReportController {
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();
	

	@Autowired
	CommonController comm;
	
	
	@Autowired
	SupplymentryDAO supDao;
	
	@Autowired
	 SearchResultswithheldDAO resDao;
	
	@Autowired
	PartB_ReportDAO partbreportDao;
	
	//======================================================OPEN PAGE========================================================//
			@RequestMapping(value = "SupplymentryReportUrl", method = RequestMethod.GET)
			public ModelAndView SupplymentryReportUrl(ModelMap Mmap, HttpSession session,
					@RequestParam(value = "msg", required = false) String msg,HttpServletRequest request)
					throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException,
					NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException {

				String es_begindate = session.getAttribute("es_begin_dateshow") == "" ? ""
						: session.getAttribute("es_begin_dateshow").toString();
				
				if (!es_begindate.equals("")) {
					Mmap.put("partb_begindate", es_begindate);
				}
				
				
				int es_id = Integer.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
				
				if (es_id != 0) {
					 Mmap.put("es_id", es_id);
				}
				 Mmap.put("msg", msg);
			      return new ModelAndView("SupplymntryTile");
			}

			 @RequestMapping(value = "/getSupplymntryreportDetails", method = RequestMethod.POST)
			  public @ResponseBody  ArrayList<ArrayList<String>> getSupplymntryreportDetails(int startPage,String pageLength,String Search,String orderColunm,String orderType,
					  String opd_personal_id,	 HttpSession sessionUserId) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, 
			  InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException{
				 
				 int es_id = Integer.parseInt(sessionUserId.getAttribute("es_id") == null ? "0": sessionUserId.getAttribute("es_id").toString());
				 if(es_id != 0) {
			 		 return supDao.getSupplymntryDetails(startPage,pageLength,Search,orderColunm,orderType,es_id,opd_personal_id,sessionUserId);
			 	}
				return null;
				 
				
			 }
			 

			  @RequestMapping(value = "/getSupplymntryreportDetailsCount", method = RequestMethod.POST)
			 public @ResponseBody long getSupplymntryreportDetailsCount(HttpSession sessionUserId,String Search, String opd_personal_id) {
					 int es_id = Integer.parseInt(sessionUserId.getAttribute("es_id") == null ? "0": sessionUserId.getAttribute("es_id").toString());
					 if(es_id != 0) {
					  return supDao.getSupplymntryDetailsCount(Search,es_id,opd_personal_id);
					 }
					return es_id;
						
			 	
			 }
			  
			  
			  @RequestMapping(value = "/getSupplymentryReport", method = RequestMethod.POST)
			  public ModelAndView getSupplymentryReport(ModelMap Mmap, HttpSession session,HttpServletRequest request, String typeReport, String es_id1, 
			  		String reportname1, String oapp_id) {
			  	try {

					  Session sessionHQL = this.sessionFactory.openSession();
						Transaction tx = sessionHQL.beginTransaction();
						String enckey = "commonPwdEncKeys";
						String oa_application_id = hex_asciiDao.decrypt((String) oapp_id, enckey, session);
						oa_application_id = oa_application_id.replace(" ", "+");
						int es_id = Integer
								.parseInt(session.getAttribute("es_id") == null ? "0" : session.getAttribute("es_id").toString());
						if(es_id != 0) {
							List<EXAM_SCHEDULE>UnlcokExmsch = comm.getUnlockExamSchedule(sessionFactory,es_id);
							String director_name= UnlcokExmsch.get(0).getEs_authority();
							String letter_no= UnlcokExmsch.get(0).getEs_letter_no();
						int ec_exam_id = session.getAttribute("ec_exam_id") == null ? 0 : Integer.parseInt(session.getAttribute("ec_exam_id").toString());
						List<EXAM_CODE_M>exam_name=comm.getExamNamebyExmID( sessionFactory, ec_exam_id);
						
						String exam_name1= exam_name.get(0).getEc_exam_name();
						String es_begindate = session.getAttribute("es_begin_date") == null ? ""
								: session.getAttribute("es_begin_date").toString();

						String es_year = es_begindate.split("-")[0];
						String bdrpmon = es_begindate.split("-")[1];
						 String[] months = {"JAN", "FEB", "MAR", "APR" ,"MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};
							String pmon = months[Integer.parseInt(bdrpmon)-1];
					ArrayList<ArrayList<String>> partially_passed = supDao.getPartPassedandFailuresForSulymntryRpt(es_year,oa_application_id);
				
					if (partially_passed.size() == 0) {

						Mmap.put("msg", "Data Not Available.");
					} else {
						
						ArrayList<ArrayList<String>> getSerno = supDao.getoldSerno(es_id,0,Integer.parseInt(oa_application_id));
						String ser_no= getSerno.get(0).get(0);
						
						
						ArrayList<ArrayList<String>> fullylist = partbreportDao.getFullyPassedForPartB(es_id,oa_application_id);
						ArrayList<ArrayList<String>> getLatestSerno = resDao.getLatestSerno(es_id,1);
						String latest_ser_no= getLatestSerno.get(0).get(0);
						int latest_Serno= Integer.parseInt(latest_ser_no);
						Mmap.put("latest_Serno", latest_Serno);
						Mmap.put("old_Serno", ser_no);
						Mmap.put("es_year", es_year);
						Mmap.put("partially_passed", partially_passed);
						Mmap.put("fullylist", fullylist);
						Mmap.put("director_name", director_name);
						Mmap.put("letter_no", letter_no);
						
						Mmap.put("list.size()", partially_passed.size());
						
						Mmap.put("b_month", pmon);
						Mmap.put("exam_name1", exam_name1);
					if (typeReport != null && typeReport.equals("pdfL")) {
						if (partially_passed.size() > 0) {
							
							
							if(fullylist.size() >0) {
								
								String fully="fully";
								Mmap.put("report_name",fully);
								
							List<String> TH = new ArrayList<String>();
							String Heading = "";
							String username = session.getAttribute("username").toString();
							return new ModelAndView(new SupplymntryPdfReportController("L", TH, Heading, username),"userList",partially_passed);
							}else {
								String partially="partially";
								Mmap.put("report_name", partially);
								ArrayList<ArrayList<String>> Latest_partially_passed = partbreportDao.getPartPassedandFailures(es_year,oa_application_id);
								Mmap.put("Latest_partially_passed", Latest_partially_passed);
								List<String> TH = new ArrayList<String>();
								String Heading = "";
								String username = session.getAttribute("username").toString();
								return new ModelAndView(new SupplymntryPdfReportController("L", TH, Heading, username),"userList",partially_passed);
							}
						}
					}
					
					}
					
					

						}
					
			  	} catch (Exception e) {
			  		e.printStackTrace();
			  	}

			  	return new ModelAndView("redirect:SupplymentryReportUrl");
			  }
}
