package com.BisagN.controller.office.masters;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.BisagN.controller.office.others.ExportExcel_genExcelController_normal;

@Controller
@RequestMapping(value = {"admin","/" ,"user"})
public class NTR_NTS_OFFRS_AMC_Controller {
	
	
	 @RequestMapping(value = "NTR_NTS_offrs_AMcdetailsUrl", method = RequestMethod.GET)
     public ModelAndView NTR_NTS_offrs_AMcdetailsUrl(ModelMap Mmap,HttpSession session,@RequestParam(value = "msg", required = false) String msg,String opd_pers_no1,String opd_name1){
    	 try {
          
    		 Mmap.put("msg", msg);
           
           
    	 } catch (Exception e) {
 			e.printStackTrace();
 		}
     return new ModelAndView("NTR_NTS_offrs_AMc_tile");
}
		//Download DEMO EXCEL
		@RequestMapping(value = "/DemoCandidateExcelFORNTR_NTS_OFFRS_amc", method = RequestMethod.POST)
		public ModelAndView DemoCandidateExcelFORNTR_NTS_OFFRS_amc(HttpServletRequest request,ModelMap model,HttpSession session,String typeReport1) {
			
//			int abc = comm.getsubjectlist().size();
//			
		ArrayList<ArrayList<String>> listexport=new ArrayList<ArrayList<String>>();
		List<String> TH = new ArrayList<String>();
	    	TH.add("SER_NO");
	    	
		    TH.add("PERSONAL_NO");
		    TH.add("SUFFIX_CODE");
			TH.add("RANK");
			TH.add("OFFICER_NAME");
			TH.add("OLD_SC_SS_WS_IC_SL_NO");
			TH.add("DOB");
			TH.add("DOC");
			TH.add("DOS");
			TH.add("TYPE_OF_COMMISSION");
			
			TH.add("AUTH_LETTER_NO");
			

			String Heading = "\n";
			String username = session.getAttribute("username").toString();
			return new ModelAndView(new ExportExcel_genExcelController_normal("L", TH, Heading, username), "userList", listexport);
		}
}
