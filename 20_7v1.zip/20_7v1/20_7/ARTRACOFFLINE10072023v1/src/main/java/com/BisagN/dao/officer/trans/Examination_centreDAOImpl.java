package com.BisagN.dao.officer.trans;


import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class Examination_centreDAOImpl implements Examination_centreDAO {
	@Autowired
         private DataSource dataSource;
//         public void setDataSource(DataSource dataSource) {
//	       this.dataSource = dataSource;
//         }
 HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

 @Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

  public boolean checkIsIntegerValue(String Search) {
	return Search.matches("[0-9]+");
}


public List<Map<String, Object>> getReportListExamination_centre(int startPage,String pageLength,String Search,String orderColunm,String orderType,String command, String exam, HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		if(pageLength.equals("-1")){
 			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search);

 		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		String q = "";
		
		System.err.println("command=============="+command);
		try {
			conn = dataSource.getConnection();
			q = "select distinct exm.ecc_center_code, exm.ecc_name,exm.ecc_cond_formation,exm.center_code,exm.ecc_name, cm.cc_command_name,ec.ec_exam_name from exam_center_code exm\n" + 
					"inner join command_code cm on cm.cc_command_id = exm.cc_command_id "
					+ "inner join exam_code ec on ec.ec_exam_id= exm.ec_exam_id where cm.cc_command_id=? \n"
					+ "and ec.ec_exam_name =? and exm.ecc_status_id=1   "+SearchValue+" ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
			PreparedStatement stmt = conn.prepareStatement(q);
			stmt = setQueryWhereClause_SQL(stmt,Search);
			stmt.setInt(1, Integer.parseInt(command));
			stmt.setString(2, exam);
			ResultSet rs = stmt.executeQuery();
			
			System.out.println("stmt---------------"+stmt);
			ResultSetMetaData metaData = rs.getMetaData();
 			int columnCount = metaData.getColumnCount();
 			while (rs.next()) {
				Map<String, Object> columns = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= columnCount; i++) {
				    columns.put(metaData.getColumnLabel(i), rs.getObject(i));
				}
                      String enckey ="commonPwdEncKeys";
	                    Cipher c = hex_asciiDao.EncryptionSHA256Algo(session,enckey);
	                    String EncryptedPk = new String(Base64.encodeBase64( c.doFinal(rs.getString("ecc_center_code").toString().getBytes())));
                      String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deleteData('"+EncryptedPk+"')}else{ return false;}\""; 
                      String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>"; 
                      String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('"+EncryptedPk+"')}else{ return false;}\""; 
                      String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>"; 
                      String f = "";

                      f += updateButton;
                      f += deleteButton;
                      
                      columns.put("action", f);
                     columns.put(metaData.getColumnLabel(1),f);
                    
			list.add(columns);
			//System.out.println("list============="+list);
	}
rs.close();
stmt.close();
conn.close();
} catch (SQLException e) {
	e.printStackTrace();
} finally {
if (conn != null) {
try {
	conn.close();
} catch (SQLException e) {
}
}
}
return list;
}

public long getReportListExamination_centreTotalCount(String Search,String command, String exam) {
 		String SearchValue = GenerateQueryWhereClause_SQL(Search);
 		int total = 0;
 		String q = null;
 		Connection conn = null;
 		try {
 			conn = dataSource.getConnection();
 			q ="select count(*) from (select distinct exm.ecc_center_code, exm.ecc_name,exm.ecc_cond_formation,exm.center_code,exm.ecc_name, cm.cc_command_name,ec.ec_exam_name \n"
 					+ "from exam_center_code exm\n"
 					+ "inner join command_code cm on cm.cc_command_id = exm.cc_command_id\n"
 					+ "inner join exam_code ec on ec.ec_exam_id= exm.ec_exam_id where exm.ecc_status_id=1  and cm.cc_command_id=? \n"
 					+ "and ec.ec_exam_name =? "+SearchValue+")a";
 			PreparedStatement stmt = conn.prepareStatement(q);
 			stmt = setQueryWhereClause_SQL(stmt,Search);
 			stmt.setInt(1, Integer.parseInt(command));
			stmt.setString(2, exam);
 			ResultSet rs = stmt.executeQuery();
 			while (rs.next()) {
 				total = rs.getInt(1);
 			}
  			rs.close();
  			stmt.close();
  			conn.close();
  		} catch (SQLException e) {
  			e.printStackTrace();
  		} finally {
  			if (conn != null) {
  				try {
  					conn.close();
  				} catch (SQLException e) {
  				}
 			}
  		}
  		return (long) total;
  	}


  	public String GenerateQueryWhereClause_SQL(String Search) {
 		String SearchValue ="";
  		if(!Search.equals("")) {
			Search = Search.toLowerCase();
  			SearchValue =" and ( ";
  			if(checkIsIntegerValue(Search)) {
  				SearchValue +=" id=? or ";
  			}
String cc_command_id = "";  			if(checkIsIntegerValue(Search)) {
  				cc_command_id +=" cc_command_id= ? or ";
  			}
String ec_exam_id = "";  			if(checkIsIntegerValue(Search)) {
  				ec_exam_id +=" ec_exam_id= ? or ";
  			}
 			SearchValue +=" "+cc_command_id+""+ec_exam_id+"lower(ecc_name) like ? or lower(cm.cc_command_name) like ?  )";
 		}
   return SearchValue;
 }


  public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search) {
 		int flag = 0;
 		try {
 			
 
 			
 			
 			
 			
    		if(!Search.equals("")) {
 				
 					
 			
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				
 				
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 				
 				flag += 1;
 				stmt.setString(flag, "%"+Search.toLowerCase()+"%");
 			}
 		}catch (Exception e) {}
 		return stmt;
 	}
  public String Deleteexamination_centre(String deleteid,HttpSession session1) {

    	Session session = this.sessionFactory.openSession();
    	Transaction tx = session.beginTransaction();
    	String enckey = "commonPwdEncKeys";
		    String DcryptedPk = hex_asciiDao.decrypt((String) deleteid,enckey,session1);
String hql = "update EXAM_CENTER_CODE_M set ecc_status_id=:ecc_status_id where cast(ecc_center_code as string) = :deleteid";
		    
	        Query q = session.createQuery(hql)
	        		.setString("deleteid",DcryptedPk)
	        		.setInteger("ecc_status_id", 0);
	        int rowCount = q.executeUpdate();
    	tx.commit();
        session.close();
	    if(rowCount > 0) {
			return "Deleted Successfully";
		}else {
		return "Deleted not Successfully";
 	}
	}
   
   public ArrayList<ArrayList<String>> getExcelexamination_centre(int startPage, String pageLength, String Search,
			String orderColunm, String orderType,String cc_command_id2,String ec_exam_id2, String table, HttpSession session)
			throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		if (pageLength.equals("-1")) {
			pageLength = "ALL";
		}
		String SearchValue = GenerateQueryWhereClause_SQL(Search);
		ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
		Connection conn = null;
		String q = "",whr="";
		String q1 = "";
		String q2 = "";
		
		System.err.println("cc_command_id2--------------"+cc_command_id2);

		try {
			conn = dataSource.getConnection();
			
			if(!cc_command_id2.equals("")) {
				whr += " and cm.cc_command_id = ? ";
			}
			if(!ec_exam_id2.equals("")) {
				whr += " and ec.ec_exam_name = ? ";
			}
			

			q="select distinct  ROW_NUMBER() OVER(order by exm.ecc_center_code) as serno ,exm.ecc_center_code,exm.ecc_name\n"
					+ "from exam_center_code exm\n"
					+ "inner join command_code cm on cm.cc_command_id = exm.cc_command_id \n"
					+ "inner join exam_code ec on ec.ec_exam_id= exm.ec_exam_id \n"
					+ whr +"exm.ecc_status_id=1 "+SearchValue+" \n"+ "		ORDER BY "+ orderColunm +""+orderType +" limit " +pageLength+" OFFSET "+startPage;



			PreparedStatement stmt = conn.prepareStatement(q);

			stmt = setQueryWhereClause_SQL(stmt, Search);

		
			int j = 1;
			
			if (!cc_command_id2.equals("")) {

				stmt.setInt(j, Integer.parseInt(cc_command_id2));

				j += 1;

			}
			
			if (!ec_exam_id2.equals("")) {

				stmt.setString(j, ec_exam_id2);

				j += 1;

			}
			
			ResultSet rs = stmt.executeQuery();
			
			System.err.println("stmt========bbbb======"+stmt);
			while (rs.next()) {
				ArrayList<String> list = new ArrayList<String>();
				
				list.add(rs.getString("serno"));
				list.add(rs.getString("ecc_center_code"));
				
				list.add(rs.getString("ecc_name"));

				
				
					
					
				
				alist.add(list);
//				System.err.println("list---------"+list);
				
				
			}
			rs.close();
			stmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
		return alist;
	}
   
   


}
