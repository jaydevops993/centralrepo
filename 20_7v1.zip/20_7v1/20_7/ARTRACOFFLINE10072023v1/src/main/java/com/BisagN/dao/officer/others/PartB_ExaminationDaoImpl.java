package com.BisagN.dao.officer.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.BisagN.controller.CommonController;
import com.BisagN.dao.HexatoAsciiDAO;
import com.BisagN.dao.HexatoAsciiDAOImpl;

@Service
public class PartB_ExaminationDaoImpl implements PartB_ExaminationDAO  {
	@Autowired
    private DataSource dataSource;
//    public void setDataSource(DataSource dataSource) {
//      this.dataSource = dataSource;
//    }
HexatoAsciiDAO hex_asciiDao = new HexatoAsciiDAOImpl();

CommonController comm= new CommonController();



@Autowired
@Qualifier("sessionFactory")
private SessionFactory sessionFactory;

public boolean checkIsIntegerValue(String Search) {
return Search.matches("[0-9]+");
}
public ArrayList<ArrayList<String>> getdatafromExaminationCentre(int exm_id) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	String whr = "";

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		
	
		
		q="select ecc_center_code, ec.ecc_name from exam_center_code  ec\n"
				+ "inner join exam_code ex on ex.ec_exam_id = ec.ec_exam_id\n"
				+ "where ex.ec_exam_id=?";
		
		stmt = conn.prepareStatement(q);
		int i=0;
	
		stmt.setInt(1, exm_id);
		System.err.println("center=============="+stmt);
		
		ResultSet rs = stmt.executeQuery();
		
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("ecc_name"));//1
			list.add(rs.getString("ecc_center_code"));//1
			
			
			
			alist.add(list);
			
			
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}


public ArrayList<ArrayList<String>> getSubjectList(String Exm_name, String arm_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();

	Connection conn = null;
	String q = "";
	String qry = "";

	try {
		
		System.err.println("arm_id========="+arm_id);
if(!arm_id.equals("null")) {
	
	q="and sub_ch.arm_id=?";
}

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

//		q = "select sc_subject_id as id, sc_subject_name, sc_subject_code,ec.ec_exam_id from subject_code sc\n"
//				+ "inner join exam_code ec on sc.ec_exam_id = ec.ec_exam_id where ec.ec_exam_name=? ";
		
		q="select sc_subject_id as id, sc_subject_name, sc_subject_code,ec.ec_exam_id from subject_code sc\n"
				+ "inner join exam_code ec on sc.ec_exam_id = ec.ec_exam_id\n"
				+ "inner join subject_code_child_tbl sub_ch on sub_ch.sub_id=sc.sc_subject_id\n"
				+ "where ec.ec_exam_name=? "+q+" ";

		stmt = conn.prepareStatement(q);
		stmt.setString(1, Exm_name);
		if(!arm_id.equals("")) {
		stmt.setInt(2, Integer.parseInt(arm_id));
		
		}
System.err.println("s---------"+stmt);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();

			list.add(rs.getString("id"));// 0
			list.add(rs.getString("sc_subject_name"));// 1
			
			list.add(rs.getString("sc_subject_code"));// 2
			
			list.add(rs.getString("ec_exam_id"));// 2

			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;

}


public ArrayList<ArrayList<String>> getPartBexmCandidateReport(int startPage, String pageLength, String Search,
		String orderColunm, String orderType,String pers_no, String pers_name, String center, String opd_arm_service,String exam_schedule_dt_id,HttpSession session)
		throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
		InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	
	if (!pers_no.equals("")) {
		
		pers_no=comm.getSearchIcNumberwithoutZero(pers_no);
		 System.err.println("opc_code==========="+pers_no);
	}
	
	if (pageLength.equals("-1")) {
		pageLength = "ALL";
	}
	String SearchValue = GenerateQueryWhereClause_SQL(Search,pers_no,pers_name,center,opd_arm_service,exam_schedule_dt_id);
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	

	try {
		
		conn = dataSource.getConnection();

		q = "select ROW_NUMBER() OVER(order by vpd.opd_personal_id) as sr_no,vpd.opc_suffix_code, vpd.opc_personal_code,vpd.opd_officer_name, vpd.ac_arm_description,ofa.oa_application_id, ofa.oa_center_granted from officer_application ofa\n"
				+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
				+ "where ofa.es_id=? and ofa.oa_status_id=1  " + SearchValue + " "
						+ "ORDER BY "+ orderColunm +" "+orderType +" limit " +pageLength+" OFFSET "+startPage ;
		

		PreparedStatement stmt = conn.prepareStatement(q);
		stmt.setInt(1, Integer.parseInt(exam_schedule_dt_id));
		
		stmt = setQueryWhereClause_SQL(stmt, Search,pers_no,pers_name,center,opd_arm_service,exam_schedule_dt_id);
		
		
		System.err.println("k  0108============"+stmt);
		ResultSet rs = stmt.executeQuery();
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("sr_no"));//0
			
			String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
     		String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));			
			list.add(opc_code);//1
			
			list.add(rs.getString("opd_officer_name"));//2
			list.add(rs.getString("ac_arm_description"));//3
			
			
			String enckey = "commonPwdEncKeys";
			Cipher c = hex_asciiDao.EncryptionSHA256Algo(session, enckey);
			String EncryptedPk = new String(
					Base64.encodeBase64(c.doFinal(rs.getString("oa_application_id").toString().getBytes())));
			
			String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('" + EncryptedPk
					+ "')}else{ return false;}\"";
			String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>";

//			String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deletePartBData('"
//					+ EncryptedPk + "')}else{ return false;}\"";
//			String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>";
//			
			
			list.add(updateButton);
			alist.add(list);
			

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}

public long getPartbexmCandidatereportTotalCount(String Search,String pers_no, String pers_name,String center, String opd_arm_service,String exam_schedule_dt_id) {

	String SearchValue = GenerateQueryWhereClause_SQL(Search,pers_no,pers_name,center,opd_arm_service,exam_schedule_dt_id);
int total = 0;
String q = null;
Connection conn = null;
try {
	
	

	conn = dataSource.getConnection();
	q ="select count(*) from (select ROW_NUMBER() OVER(order by vpd.opd_personal_id) as sr_no, vpd.opc_personal_code, vpd.opd_officer_name,vpd.ac_arm_description,ofa.oa_center_granted  from officer_application ofa\n"
			+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
			+ "where ofa.es_id=? and ofa.oa_status_id=1   " +SearchValue +"   ) ab " ;
	
	PreparedStatement stmt = conn.prepareStatement(q);
	stmt = setQueryWhereClause_SQL(stmt,Search,pers_no,pers_name,center,opd_arm_service,exam_schedule_dt_id);

	stmt.setInt(1,Integer.parseInt(exam_schedule_dt_id));
	ResultSet rs = stmt.executeQuery();
	while (rs.next()) {
		total = rs.getInt(1);
	}
	rs.close();
	stmt.close();
	conn.close();
} catch (SQLException e) {
	e.printStackTrace();
} finally {
	if (conn != null) {
		try {
			conn.close();
		} catch (SQLException e) {
		}
	}
}
return (long) total;
}


public String GenerateQueryWhereClause_SQL(String Search, String pers_no, String pers_name, String center,
		String opd_arm_service,String exam_schedule_dt_id) {
	String SearchValue = "";

	try {
	
		
	if (!pers_no.equals("") && pers_no != "" && pers_no != null) {
		SearchValue += "and lower(vpd.opc_personal_code::text) like ?";
	}

	if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
		SearchValue += "and lower(vpd.opd_officer_name) like ? ";
	}

		if (!opd_arm_service.equals("0") && opd_arm_service != "0") {
			SearchValue += "and vpd.ac_arm_id=?";
		}
	
		if (!center.equals("0") && center != "0") {
			SearchValue += "and ofa.oa_center_granted=?";
		}
		
		if (!Search.equals("")) {
			Search = Search.toLowerCase();
			SearchValue += " and ( ";
			SearchValue += " lower(opc_personal_code) like ?  or lower(opd_officer_name) like ? or lower(ac_arm_description) like ?)";
					
		}
	} catch (Exception e) {
		
	}

	return SearchValue;

}

public PreparedStatement setQueryWhereClause_SQL(PreparedStatement stmt,String Search,String pers_no, String pers_name,String center, 
		String opd_arm_service,String exam_schedule_dt_id) {
	int flag = 1;
	
try {
	
	if (!pers_no.equals("") && pers_no != "" && pers_no != null) {
		flag += 1;
//		stmt.setInt(flag, Integer.parseInt(pers_no));
		stmt.setString(flag,"%"+ pers_no.toLowerCase() + "%");
	}
	
	if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
		flag += 1;
		stmt.setString(flag,"%"+ pers_name.toLowerCase() + "%");
	}
		
		if (!opd_arm_service.equals("0") && opd_arm_service != "0") {
			flag += 1;
			stmt.setInt(flag,Integer.parseInt(opd_arm_service) );
		}
		
		if (!center.equals("0") && center != "0") {
			flag += 1;
			stmt.setInt(flag, Integer.parseInt(center));
		}

	if(!Search.equals("")) {
		
		flag += 1;
		Search=comm.getSearchIcNumberwithoutZero(Search);
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		flag += 1;
		stmt.setString(flag, "%"+Search.toLowerCase()+"%");
			
		
	}
}catch (Exception e) {
	
}
return stmt;
}

public ArrayList<ArrayList<String>> getOPDdetailsforpartb(String opd_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();

	Connection conn = null;
	String q = "";
	String qry = "";

	try {

		

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q = "SELECT  vpd.opc_personal_code, vpd.opd_officer_name, vpd.ac_arm_description,vpd.opd_dob,vpd.opd_date_of_comm, vpd.ct_comm_type,vpd.rc_rank_name,\n"
				+ "vpd.opd_date_of_seniority,vpd.opd_unit,vpd.opd_unit_address1,vpd.opd_unit_address2,oapp.oa_center_granted,vpd.ac_arm_id, oapp.oa_application_id,vpd.opd_partd\n"
				+ "from vw_personal_details vpd 	\n"
				+ "					inner join officer_application oapp on oapp.opd_personal_id = vpd.opd_personal_id  \n"
				+ "					inner join partb_d_application pbd ON pbd.oa_application_id = oapp.oa_application_id\n"
				+ "					where  oapp.oa_application_id=?  ";

		stmt = conn.prepareStatement(q);
		stmt.setInt(1,Integer.parseInt( opd_id));
System.err.println("k============="+stmt);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();

			list.add(rs.getString("opc_personal_code"));//1
			list.add(rs.getString("opd_officer_name"));//2
			list.add(rs.getString("ac_arm_description"));//3
			list.add(rs.getString("opd_dob"));//4	
			list.add(rs.getString("opd_date_of_comm"));//5	
			list.add(rs.getString("ct_comm_type"));//6
			list.add(rs.getString("rc_rank_name"));//7		
			
			list.add(rs.getString("opd_date_of_seniority"));//8
			list.add(rs.getString("opd_unit"));//8
			
//			
			
			list.add(rs.getString("oa_center_granted"));//8
			
			
			list.add(rs.getString("ac_arm_id"));//8
			

			list.add(rs.getString("oa_application_id"));//8
			list.add(rs.getString("opd_partd"));//8
			
			
			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;

}


public ArrayList<ArrayList<String>> getpartbapplicationdtl(String opd_id) {
	
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();

	Connection conn = null;
	String q = "";
	String qry = "";

	try {

		

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		q = "select partbd.pbda_add_corres1,partbd.pbda_add_corres2,partbd.pbda_add_corres3,partbd.pbda_comp,partbd.pbda_comp_details,partbd.pbda_survey_details,pbda_survey_india,pbda_immediate_super,\n"
				+ "partbd.pbda_subjects\n"
				+ "from officer_application oapp\n"
				+ "inner join partb_d_application partbd on oapp.oa_application_id = partbd.oa_application_id\n"
				+ "where oapp.oa_application_id=? ";

		stmt = conn.prepareStatement(q);
		stmt.setInt(1,Integer.parseInt( opd_id));
System.err.println("partb============"+stmt);
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();

			list.add(rs.getString("pbda_add_corres1"));//1
			list.add(rs.getString("pbda_add_corres2"));//2
			list.add(rs.getString("pbda_add_corres3"));//3
			list.add(rs.getString("pbda_comp"));//4	
			list.add(rs.getString("pbda_comp_details"));//5	
			list.add(rs.getString("pbda_subjects"));//6
			list.add(rs.getString("pbda_immediate_super"));//7		
			list.add(rs.getString("pbda_survey_india"));//7		
			list.add(rs.getString("pbda_survey_details"));//7	
			
		
			

			alist.add(list);

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;

}
public ArrayList<ArrayList<String>> getManualPartbRulesappdetails(int opd_personal_id, String exmsch_dt,String exam_schedule_dt, String min_year, String max_year) {

	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	
	String whr = "";

	try {

		conn = dataSource.getConnection();
		PreparedStatement stmt = null;

		
	
		
		q="select opc_personal_code,opc_suffix_code, opd_officer_name,ac_arm_description from vw_personal_details where opd_personal_id=?\n"
				+ "and date_part('year',age('"+exmsch_dt+"',"+exam_schedule_dt+")) >= "+min_year+"\n"
				+ "and   date_part('year',age('"+exmsch_dt+"',"+exam_schedule_dt+")) <= "+max_year+"\n";
		
		stmt = conn.prepareStatement(q);
		int i=0;
	
		stmt.setInt(1, opd_personal_id);
		System.err.println("center=============="+stmt);
		
		ResultSet rs = stmt.executeQuery();
		
	
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("opc_personal_code"));//1
			list.add(rs.getString("opd_officer_name"));//1
			
			
			
			alist.add(list);
			
			
		}

		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {

		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}
public ArrayList<ArrayList<String>> getPartDexmCandidateReport(int startPage, String pageLength, String Search,
		String orderColunm, String orderType,String pers_no, String pers_name, String center, String opd_arm_service,String exam_schedule_dt_id,HttpSession session)
		throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
		InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	
		if (!pers_no.equals("")) {
			
		pers_no=comm.getSearchIcNumberwithoutZero(pers_no);
		 System.err.println("opc_code==========="+pers_no);
			 
	}
	if (pageLength.equals("-1")) {
		pageLength = "ALL";
	}
	String SearchValue = GenerateQueryWhereClause_SQL1(Search,pers_no,pers_name,center,opd_arm_service,exam_schedule_dt_id);
	ArrayList<ArrayList<String>> alist = new ArrayList<ArrayList<String>>();
	Connection conn = null;
	String q = "";
	System.err.println("pers_no=========="+pers_no);
	
	try {
		conn = dataSource.getConnection();

		q = "select ROW_NUMBER() OVER(order by vpd.opd_personal_id) as sr_no, vpd.opc_personal_code,vpd.opc_suffix_code,vpd.opd_officer_name, vpd.ac_arm_description,ofa.oa_application_id  from officer_application ofa\n"
				+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
				+ "where ofa.es_id=? and ofa.oa_status_id=1   " + SearchValue + " ORDER BY "
				+ orderColunm + " " + orderType + " limit " + pageLength + " OFFSET " + startPage;

		PreparedStatement stmt = conn.prepareStatement(q);
		stmt = setQueryWhereClause_SQL1(stmt,Search,pers_no,pers_name,center,opd_arm_service,exam_schedule_dt_id);
		stmt.setInt(1,Integer.parseInt(exam_schedule_dt_id));
	
System.out.println("Part D============"+stmt);

		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			ArrayList<String> list = new ArrayList<String>();
			list.add(rs.getString("sr_no"));//0
			String  opc_personal_code=comm.getIcNumberwithoutZero(rs.getString("opc_personal_code")).toString();
     		String opc_code= opc_personal_code+(rs.getString("opc_suffix_code"));			
			list.add(opc_code);//1
//			list.add(rs.getString("opc_personal_code"));//1
			list.add(rs.getString("opd_officer_name"));//2
			list.add(rs.getString("ac_arm_description"));//3
			
			
		
			
			String enckey = "commonPwdEncKeys";
			Cipher c = hex_asciiDao.EncryptionSHA256Algo(session, enckey);
			String EncryptedPk = new String(
					Base64.encodeBase64(c.doFinal(rs.getString("oa_application_id").toString().getBytes())));

			String Update = "onclick=\"  if (confirm('Are you sure you want to Update?') ){editData('" + EncryptedPk
					+ "')}else{ return false;}\"";
			String updateButton = "<i class='action_icons action_update' " + Update + " title='Edit Data'></i>";

			String Delete = "onclick=\"  if (confirm('Are you sure you want to Delete?') ){deletePartDAppData('"
					+ EncryptedPk + "')}else{ return false;}\"";
			String deleteButton = "<i class='action_icons action_delete' " + Delete + " title='Delete Data'></i>";
			
			
			list.add(updateButton);
			alist.add(list);
			

		}
		rs.close();
		stmt.close();
		conn.close();
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}
	return alist;
}



public long getPartDexmCandidatereportTotalCount(String Search,String pers_no, String pers_name,String center, String opd_arm_service, String exam_schedule_dt_id) {
String SearchValue = GenerateQueryWhereClause_SQL1(Search,pers_no,pers_name,center,opd_arm_service,exam_schedule_dt_id);
int total = 0;
String q = null;
Connection conn = null;
try {
	String q1 = "";
	String q2 = "";
	String q3 = "";
	String q4 = "";
	
	
	System.err.println("pers_no=========="+pers_no);
	conn = dataSource.getConnection();
	q ="select count(*) from (select ROW_NUMBER() OVER(order by vpd.opd_personal_id) as sr_no, vpd.opc_personal_code,vpd.opd_officer_name, vpd.ac_arm_description,ofa.oa_application_id  from officer_application ofa\n"
			+ "inner join vw_personal_details vpd on vpd.opd_personal_id = ofa.opd_personal_id\n"
			+ "where ofa.es_id=? and ofa.oa_status_id=1  " +SearchValue +" ) ab " ;
	PreparedStatement stmt = conn.prepareStatement(q);
	stmt = setQueryWhereClause_SQL1(stmt,Search,pers_no,pers_name,center,opd_arm_service,exam_schedule_dt_id);
	stmt.setInt(1,Integer.parseInt(exam_schedule_dt_id));

	ResultSet rs = stmt.executeQuery();
	
	System.err.println("koooo==========="+stmt);
	while (rs.next()) {
		total = rs.getInt(1);
	}
	rs.close();
	stmt.close();
	conn.close();
} catch (SQLException e) {
	e.printStackTrace();
} finally {
	if (conn != null) {
		try {
			conn.close();
		} catch (SQLException e) {
		}
	}
}
return (long) total;
}


public String GenerateQueryWhereClause_SQL1(String Search, String pers_no, String pers_name, String center,
		String opd_arm_service,String exam_schedule_dt_id) {
String SearchValue ="";

System.err.println("pers_no==========="+pers_no);
if (!pers_no.equals("") && pers_no != "" && pers_no != null) {
	SearchValue += "and lower(vpd.opc_personal_code) like ?";
}

if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
	SearchValue += "and lower(vpd.opd_officer_name) like ? ";
}

	if (!opd_arm_service.equals("0") && opd_arm_service != "0") {
		SearchValue += "and vpd.ac_arm_id=?";
	}

	if (!center.equals("0") && center != "0") {
		SearchValue += "and ofa.oa_center_granted=?";
	}
	
	if (!Search.equals("")) {
		Search = Search.toLowerCase();
		SearchValue = " and ( ";
		SearchValue += " lower(opc_personal_code) like ?  or lower(opd_officer_name) like ? or lower(ac_arm_description) like ?)";
				
	}
return SearchValue;

}


public PreparedStatement setQueryWhereClause_SQL1(PreparedStatement stmt,String Search,String pers_no, String pers_name,String center, 
		String opd_arm_service,String exam_schedule_dt_id) {  String SearchValue = "";
int flag = 1;
try {
	
	if (!pers_no.equals("") && pers_no != "" && pers_no != null) {
		flag += 1;
		stmt.setString(flag,"%"+ pers_no.toLowerCase() + "%");
		SearchValue += " and (lower(pers_name) like ?  or lower(opd_arm_service) like ?  or lower(center) like ? or  ";
	}
	
	if (!pers_name.equals("") && pers_name != "" && pers_name != null) {
		flag += 1;
		stmt.setString(flag,"%"+ pers_name.toLowerCase() + "%");
	}
		
		if (!opd_arm_service.equals("0") && opd_arm_service != "0") {
			flag += 1;
			stmt.setInt(flag,Integer.parseInt(opd_arm_service) );
		}
		
		if (!center.equals("0") && center != "0") {
			flag += 1;
			stmt.setInt(flag, Integer.parseInt(center));
		}
if(!Search.equals("")) {
	flag += 1;
	Search=comm.getSearchIcNumberwithoutZero(Search);
	stmt.setString(flag, "%"+Search.toLowerCase()+"%");
	flag += 1;
	stmt.setString(flag, "%"+Search.toLowerCase()+"%");
	flag += 1;
	stmt.setString(flag, "%"+Search.toLowerCase()+"%");
		
	}
}catch (Exception e) {}
return stmt;
}
}
