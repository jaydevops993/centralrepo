package com.BisagN.controller.office.others;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPTable;

import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfWriter;



public class AdmitCardPDFController extends AbstractPdfView{
	

	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public AdmitCardPDFController(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}
	
	
	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		
		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
//		response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 1);
		Font fontTableHeadingSubMainHead1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 0);
		Font fontTableHeadingMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 16, 1);
	
		
		Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
		
		
		String admitcardno = (String) model.get("admitcardno");
		String rank = (String) model.get("rank");	
		String opdname = (String) model.get("opdname");
		String unit = (String) model.get("unit");
		String exmcentre = (String) model.get("exmcentre");
		
		PdfPTable table_1 = new PdfPTable(1);
		table_1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		Chunk underline1 = new Chunk("DSSC/DSTSC EXAMINATION 2023:",fontTableHeadingSubMainHead );
        underline1.setUnderline(0.1f, 0f);
		
		Phrase ph = new Phrase(underline1);
		ph.setFont(fontTableHeading1);
		
		PdfPCell blank_cell;
		blank_cell = new PdfPCell(ph);
		blank_cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		blank_cell.setBorder(Rectangle.NO_BORDER);
		 

		 table_1.addCell(blank_cell);
		
		Chunk underline2 = new Chunk("05 SEP - 10 SEP 2023",fontTableHeadingSubMainHead );
        underline2.setUnderline(0.1f, 0f);
		
		Phrase ph2 = new Phrase(underline2);

        PdfPCell blank_cella_2_h_a;
		 blank_cella_2_h_a = new PdfPCell(ph2);
		 blank_cella_2_h_a.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella_2_h_a.setBorder(Rectangle.NO_BORDER);
		 

		 table_1.addCell(blank_cella_2_h_a);
		table_1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		
		ph2.add("\n");
		ph2.add("\n");
		ph2.add("\n");
		
		PdfPTable table_2 = new PdfPTable(2);
		table_2.setWidthPercentage(100);

		
		Paragraph a_2 = new Paragraph("",fontTableHeadingSubMainHead);
		Paragraph b_2 = new Paragraph("																			"
				+ "															"
				+ "								Exam Sec:",fontTableHeadingSubMainHead);
		
		Paragraph e_2 = new Paragraph("Admit Card No:"+admitcardno+"",fontTableHeadingSubMainHead);
		Paragraph f_2 = new Paragraph("																			"
				+ "															"
				+ "								HQ ARTRAC:",fontTableHeadingSubMainHead);
		
		Paragraph i_2 = new Paragraph("",fontTableHeadingSubMainHead);
		Paragraph j_2 = new Paragraph("																			"
				+ "															"
				+ "								C/O 56 APO",fontTableHeadingSubMainHead);
		
		Paragraph m_2 = new Paragraph("",fontTableHeadingSubMainHead);
		Paragraph n_2 = new Paragraph("																			"
				+ "															"
				+ "								PIN-908548",fontTableHeadingSubMainHead);

		
		  n_2.add("\n"); 
		  n_2.add("\n"); 
		  n_2.add("\n");
		 PdfPCell blank_cella_2;
		 blank_cella_2 = new PdfPCell(a_2);
		 blank_cella_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellb_2;
		 blank_cellb_2 = new PdfPCell(b_2);
		 blank_cellb_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cellb_2.setBorder(Rectangle.NO_BORDER);
		 
		 
		 PdfPCell blank_celle_2;
		 blank_celle_2 = new PdfPCell(e_2);
		 blank_celle_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_celle_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellf_2;
		 blank_cellf_2 = new PdfPCell(f_2);
		 blank_cellf_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cellf_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_celli_2;
		 blank_celli_2 = new PdfPCell(i_2);
		 blank_celli_2.setHorizontalAlignment(Element.ALIGN_RIGHT);
		 blank_celli_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellj_2;
		 blank_cellj_2 = new PdfPCell(j_2);
		 blank_cellj_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cellj_2.setBorder(Rectangle.NO_BORDER);
		 
		 
		 PdfPCell blank_cellm_2;
		 blank_cellm_2 = new PdfPCell(m_2);
		 blank_cellm_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cellm_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_celln_2;
		 blank_celln_2 = new PdfPCell(n_2);
		 blank_celln_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_celln_2.setBorder(Rectangle.NO_BORDER);
		
		
		 table_2.addCell(blank_cella_2);
		 table_2.addCell(blank_cellb_2);
		 table_2.addCell(blank_celle_2);
		 table_2.addCell(blank_cellf_2);
		 table_2.addCell(blank_celli_2);
		 table_2.addCell(blank_cellj_2);
		 table_2.addCell(blank_cellm_2);
		 table_2.addCell(blank_celln_2);
		 
		 document.add(table_1);
		document.add(table_2);
		
		
		PdfPTable table_3 = new PdfPTable(1);
		table_3.setWidthPercentage(100);
		table_3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		table_3.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		table_3.setWidthPercentage(100);
		
		Paragraph a_a = new Paragraph("IC86385K Lt Col PRATYANSHI",fontTableHeadingSubMainHead);
		 PdfPCell blank_cell3_a;
		 blank_cell3_a = new PdfPCell(a_a);
		 blank_cell3_a.setBorder(Rectangle.NO_BORDER);
		 
		 table_3.addCell(blank_cell3_a);
		 
		 Paragraph a_b = new Paragraph("PRIYADARSHI MOHANTY",fontTableHeadingSubMainHead);
		 PdfPCell blank_cell3_b;
		 blank_cell3_b = new PdfPCell(a_b);
		 blank_cell3_b.setBorder(Rectangle.NO_BORDER);
		 
		 table_3.addCell(blank_cell3_b);
		 
		 Paragraph a_c = new Paragraph("12 GUARDS",fontTableHeadingSubMainHead);
		 PdfPCell blank_cell3_c;
		 blank_cell3_c = new PdfPCell(a_c);
		 blank_cell3_c.setBorder(Rectangle.NO_BORDER);
		 
		 table_3.addCell(blank_cell3_c);
		 
		 Paragraph a_d = new Paragraph("c/o 56 APO",fontTableHeadingSubMainHead);
		 PdfPCell blank_cell3_d;
		 blank_cell3_d = new PdfPCell(a_d);
		 blank_cell3_d.setBorder(Rectangle.NO_BORDER);
		 
		 table_3.addCell(blank_cell3_d);
		 a_d.add("\n");
		 a_d.add("\n");
		 a_d.add("\n");
		 
		 String ic="IC86358K";
		 String nm="PRATYANSHI PRIYADARSHI MOHANTY";
		 String rnk=" LT Col";
		 String grd=" 12 GUARDS";
		 String mnt="Sep 2023";
		 String cntr="MHOW";
		 
		 Paragraph a_e = new Paragraph("1.    The Candidature of "+ic+" Rank "+rnk+" Name "+nm+" of unit "
		 							+ " "+grd+" for DSCC / DSTSC Examination, "+mnt+" has been provisionally accepted and the officer is permitted to appear for the examination\"\n"
		 						+ "at "+cntr+" Examination Centre.");
		 PdfPCell blank_cell3_e;
		 blank_cell3_e = new PdfPCell(a_e);
		 blank_cell3_e.setBorder(Rectangle.NO_BORDER);
		 a_e.add("\n");
		 a_e.add("\n");
		 table_3.addCell(blank_cell3_e);
		 
		 
		 Paragraph a_f = new Paragraph("2.    The Candidate will bring Admit Card in Original to Examination Centre and hand over\"\n"
		 						+ " the same to the Presiding Officer on the first day of the examination.");
		PdfPCell blank_cell3_f;
		blank_cell3_f = new PdfPCell(a_f);
		blank_cell3_f.setBorder(Rectangle.NO_BORDER);
		
		table_3.addCell(blank_cell3_f);
		a_f.add("\n");
		a_f.add("\n");
		a_f.add("\n");
		a_f.add("\n");a_f.add("\n");a_f.add("\n");a_f.add("\n");a_f.add("\n");a_f.add("\n");a_f.add("\n");a_f.add("\n");
		 document.add(table_3);
		 
			 
			 
		 PdfPTable table_5 = new PdfPTable(2);
		 table_5.setWidthPercentage(100);

			
			Paragraph a_sign = new Paragraph("",fontTableHeadingSubMainHead);
			Paragraph b_sign = new Paragraph("																			"
					+ "															"
					+ "								(SP SINGH)",fontTableHeadingSubMainHead);
			
			Paragraph e_sign = new Paragraph("",fontTableHeadingSubMainHead);
			Paragraph f_sign = new Paragraph("																			"
					+ "															"
					+ "								Lt Col",fontTableHeadingSubMainHead);
			
			Paragraph i_sign = new Paragraph("",fontTableHeadingSubMainHead);
			Paragraph j_sign = new Paragraph("																			"
					+ "															"
					+ "								GSO-1 EXAM",fontTableHeadingSubMainHead);
			
			Paragraph m_sign = new Paragraph("",fontTableHeadingSubMainHead);
			Paragraph n_sign = new Paragraph("																			"
					+ "															"
					+ "								Ph No-410006 2824",fontTableHeadingSubMainHead);

			
			n_sign.add("\n"); 
			n_sign.add("\n"); 
			n_sign.add("\n");
			 PdfPCell blank_cella_2_sign;
			 blank_cella_2_sign = new PdfPCell(a_sign);
			 blank_cella_2_sign.setHorizontalAlignment(Element.ALIGN_LEFT);
			 blank_cella_2_sign.setBorder(Rectangle.NO_BORDER);
			 
			 PdfPCell blank_cellb_2_sign;
			 blank_cellb_2_sign = new PdfPCell(b_sign);
			 blank_cellb_2_sign.setHorizontalAlignment(Element.ALIGN_LEFT);
			 blank_cellb_2_sign.setBorder(Rectangle.NO_BORDER);
			 
			 
			 PdfPCell blank_celle_2_sign;
			 blank_celle_2_sign = new PdfPCell(e_sign);
			 blank_celle_2_sign.setHorizontalAlignment(Element.ALIGN_LEFT);
			 blank_celle_2_sign.setBorder(Rectangle.NO_BORDER);
			 
			 PdfPCell blank_cellf_2_sign;
			 blank_cellf_2_sign = new PdfPCell(f_sign);
			 blank_cellf_2_sign.setHorizontalAlignment(Element.ALIGN_LEFT);
			 blank_cellf_2_sign.setBorder(Rectangle.NO_BORDER);
			 
			 PdfPCell blank_celli_2_sign;
			 blank_celli_2_sign = new PdfPCell(i_sign);
			 blank_celli_2_sign.setHorizontalAlignment(Element.ALIGN_RIGHT);
			 blank_celli_2_sign.setBorder(Rectangle.NO_BORDER);
			 
			 PdfPCell blank_cellj_2_sign;
			 blank_cellj_2_sign = new PdfPCell(j_sign);
			 blank_cellj_2_sign.setHorizontalAlignment(Element.ALIGN_LEFT);
			 blank_cellj_2_sign.setBorder(Rectangle.NO_BORDER);
			 
			 
			 PdfPCell blank_cellm_2_sign;
			 blank_cellm_2_sign = new PdfPCell(m_sign);
			 blank_cellm_2_sign.setHorizontalAlignment(Element.ALIGN_LEFT);
			 blank_cellm_2_sign.setBorder(Rectangle.NO_BORDER);
			 
			 PdfPCell blank_celln_2_sign;
			 blank_celln_2_sign = new PdfPCell(n_sign);
			 blank_celln_2_sign.setHorizontalAlignment(Element.ALIGN_LEFT);
			 blank_celln_2_sign.setBorder(Rectangle.NO_BORDER);
			
			
			 table_5.addCell(blank_cella_2_sign);
			 table_5.addCell(blank_cellb_2_sign);
			 table_5.addCell(blank_celle_2_sign);
			 table_5.addCell(blank_cellf_2_sign);
			 table_5.addCell(blank_celli_2_sign);
			 table_5.addCell(blank_cellj_2_sign);
			 table_5.addCell(blank_cellm_2_sign);
			 table_5.addCell(blank_celln_2_sign);
			 
			
			document.add(table_5);
				 
				 
				 
				 PdfPTable table_6 = new PdfPTable(1);
				 table_6.setWidthPercentage(100);
				 table_6.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
				 table_6.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
				 table_6.setWidthPercentage(100);
					
					Paragraph q_sign = new Paragraph("Date: 04 Mar 2023",fontTableHeadingSubMainHead);
					 PdfPCell blank_cellq_2sign;
					 blank_cellq_2sign = new PdfPCell(q_sign);
					 blank_cellq_2sign.setHorizontalAlignment(Element.ALIGN_LEFT);
					 blank_cellq_2sign.setBorder(Rectangle.NO_BORDER);
					 table_6.addCell(blank_cellq_2sign);
					 q_sign.add("\n");
					 q_sign.add("\n");
					 q_sign.add("\n");
					 document.add(table_6);
					 
					 PdfPTable table_7 = new PdfPTable(1);
					 table_7.setWidthPercentage(100);
					 table_7.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
					 table_7.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
					 table_7.setWidthPercentage(100);
						
						Paragraph note = new Paragraph("Note:-",fontTableHeadingSubMainHead);
						 PdfPCell nt;
						 nt = new PdfPCell(note);
						 nt.setHorizontalAlignment(Element.ALIGN_LEFT);
						 nt.setBorder(Rectangle.NO_BORDER);
						 table_7.addCell(nt);
						 
						 
						 Paragraph note1 = new Paragraph("1. Intimate errors in particulars of officers,if any.",fontTableHeadingSubMainHead);
						 PdfPCell nt1;
						 nt1 = new PdfPCell(note1);
						 nt1.setHorizontalAlignment(Element.ALIGN_LEFT);
						 nt1.setBorder(Rectangle.NO_BORDER);
						 table_7.addCell(nt1);
						 Paragraph note2 = new Paragraph("2. Officer,if nominated ,to undergo JC Course prior to commencement of DSSC/DSTSC Course,if not already done.",fontTableHeadingSubMainHead);
						 PdfPCell nt2;
						 nt2 = new PdfPCell(note2);
						 nt2.setHorizontalAlignment(Element.ALIGN_LEFT);
						 nt2.setBorder(Rectangle.NO_BORDER);
						 table_7.addCell(nt2);
						 Paragraph note3 = new Paragraph("3. Attention of LMC officers is drawn to SAO 4/S/2014 & amdts",fontTableHeadingSubMainHead);
						 PdfPCell nt3;
						 nt3 = new PdfPCell(note3);
						 nt3.setHorizontalAlignment(Element.ALIGN_LEFT);
						 nt3.setBorder(Rectangle.NO_BORDER);
						 table_7.addCell(nt3);
						 Paragraph note4 = new Paragraph("4. Attention of officers is drawn to Para 31 & 32 of AO 10/2018/GS(MT-2)",fontTableHeadingSubMainHead);
						 PdfPCell nt4;
						 nt4 = new PdfPCell(note4);
						 nt4.setHorizontalAlignment(Element.ALIGN_LEFT);
						 nt4.setBorder(Rectangle.NO_BORDER);
						 table_7.addCell(nt4);
						 document.add(table_7);
				
		PdfPCell cell123;
		cell123 = new PdfPCell();
		cell123.addElement(table_1);
		cell123.addElement(table_2);
		cell123.addElement(table_3);
	
		cell123.addElement(table_5);
		cell123.addElement(table_6);
		cell123.addElement(table_7);
		
		super.buildPdfMetadata(model, document, request);
	}
	
}
