package com.BisagN.controller.office.Barcode;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.BisagN.controller.office.Barcode.MasterABPdfController.ImageBackgroundEvent;
import com.BisagN.controller.office.reports.DateWithTimeStampController;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.ExceptionConverter;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPTableEvent;
import com.lowagie.text.pdf.PdfWriter;

public class ExaminersSheetPdfController extends AbstractPdfView {
	String Type = "";
	List<String> TH;
	String Heading = "";
	String username = "";
	final static String USER_PASSWORD = "user";
	final static String OWNER_PASSWORD = "owner";
	public static final String ENCRYPTED_PDF = "C:\\Users\\BISAG\\Desktop\\Beehive Screen\\beehive_reset_pwd_form.pdf";

	public ExaminersSheetPdfController(String Type, List<String> TH, String Heading, String username) {
		this.Type = Type;
		this.TH = TH; 	
		this.Heading = Heading;
		this.username = username;
	}

	protected void buildPdfMetadata(Map<String, Object> model, Document document, HttpServletRequest request) {
		
		document.open();
		if (Type.equals("L")) {
			document.setPageSize(PageSize.A4); // set document landscape
		}
		document.setPageSize(PageSize.A4);
		super.buildPdfMetadata(model, document, request);
	}

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter arg2,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		DateWithTimeStampController datetimestamp = new DateWithTimeStampController();
		String file_name = datetimestamp.currentDateWithTimeStampString();

		response.setContentType("application/pdf");
	//	response.setHeader("Content-Disposition", "attachment; filename=\"" + file_name + ".pdf\"");
		Font fontTableHeading1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 14, 1);
//		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 10, 1);
		Font fontTableHeadingSubMainHead = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 1);
		Font fontTableHeadingSubMainHead1 = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, false, 11, 0);
		
	
		
		Font  fontTableHeadingdata = FontFactory.getFont(FontFactory.TIMES, 9);
		PdfPTable table = new PdfPTable(1);
		table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		table.setWidthPercentage(100);
		
		
		String es_year1 =  (String) model.get("es_year1");
		String exam_name =  (String) model.get("exam_name");
		String begin_month =  (String) model.get("begin_month");
		String sc_subject_id1 =  (String) model.get("ActiveSubName");
		String Bundle =  (String) model.get("Bundle");
		
		
		Chunk underline1 = new Chunk("EXAMINER'S SHEET - SUMMARY OF MARKS OBTAINED" , fontTableHeading1);
//		Chunk underline1 = new Chunk("1" +"\n"+ "LIST OF ABSENTEES" +"\n"+ "PART B:"+es_year+"" , fontTableHeadingSubMainHead);	 
		underline1.setUnderline(0.1f, -2f);
		
		Phrase ph = new Phrase(underline1);
		ph.add("\n");
		ph.add("\n");
		ph.add("\n");
		ph.setFont(fontTableHeading1);

		
		Paragraph cell = new Paragraph(ph);
		cell.setAlignment(Element.ALIGN_LEFT);
		
		cell.setAlignment(Element.ALIGN_LEFT);
		
		
		PdfPTable tableheader = new PdfPTable(1);
		tableheader.getDefaultCell().setBorder(Rectangle.NO_BORDER);
		tableheader.setWidthPercentage(80);
		tableheader.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tableheader.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tableheader.addCell(cell);
		
		ArrayList<List<String>> list = (ArrayList<List<String>>) model.get("list");
		
		PdfPTable table_2 = new PdfPTable(4);
		table_2.setWidths(new int[] {2,5,3,5});
		table_2.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		table_2.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		table_2.setWidthPercentage(80);
		
		
		Paragraph a_2 = new Paragraph("Exam",fontTableHeadingSubMainHead);
		Paragraph b_2 = new Paragraph(": "+exam_name,fontTableHeadingSubMainHead1);
		Paragraph c_2 = new Paragraph("Type",fontTableHeadingSubMainHead);
		Paragraph d_2 = new Paragraph(": "+"Promotion Examination",fontTableHeadingSubMainHead1);
		
		
		Paragraph e_2 = new Paragraph("Month",fontTableHeadingSubMainHead);
		Paragraph f_2 = new Paragraph(": "+begin_month,fontTableHeadingSubMainHead1);
		Paragraph g_2 = new Paragraph("Year",fontTableHeadingSubMainHead);
		Paragraph h_2 = new Paragraph(": "+es_year1,fontTableHeadingSubMainHead1);
		
		Paragraph i_2 = new Paragraph("Subject",fontTableHeadingSubMainHead);
		Paragraph j_2 = new Paragraph(": "+sc_subject_id1,fontTableHeadingSubMainHead1);
		Paragraph k_2 = new Paragraph("Bundle No",fontTableHeadingSubMainHead);
		Paragraph l_2 = new Paragraph(": "+Bundle,fontTableHeadingSubMainHead1);
		
		
		

		 PdfPCell blank_cella_2;
		 blank_cella_2 = new PdfPCell(a_2);
		 blank_cella_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellb_2;
		 blank_cellb_2 = new PdfPCell(b_2);
		 blank_cellb_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cellb_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellc_2;
		 blank_cellc_2 = new PdfPCell(c_2);
		 blank_cellc_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cellc_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_celld_2;
		 blank_celld_2 = new PdfPCell(d_2);
		 blank_celld_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_celld_2.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 PdfPCell blank_celle_2;
		 blank_celle_2 = new PdfPCell(e_2);
		 blank_celle_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_celle_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellf_2;
		 blank_cellf_2 = new PdfPCell(f_2);
		 blank_cellf_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cellf_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellg_2;
		 blank_cellg_2 = new PdfPCell(g_2);
		 blank_cellg_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cellg_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellh_2;
		 blank_cellh_2 = new PdfPCell(h_2);
		 blank_cellh_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cellh_2.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 PdfPCell blank_celli_2;
		 blank_celli_2 = new PdfPCell(i_2);
		 blank_celli_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_celli_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellj_2;
		 blank_cellj_2 = new PdfPCell(j_2);
		 blank_cellj_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cellj_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellk_2;
		 blank_cellk_2 = new PdfPCell(k_2);
		 blank_cellk_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cellk_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_celll_2;
		 blank_celll_2 = new PdfPCell(l_2);
		 blank_celll_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_celll_2.setBorder(Rectangle.NO_BORDER);
		 
		 
		
		
		 table_2.addCell(blank_cella_2);
		 table_2.addCell(blank_cellb_2);
		 table_2.addCell(blank_cellc_2);
		 table_2.addCell(blank_celld_2);
		 table_2.addCell(blank_celle_2);
		 table_2.addCell(blank_cellf_2);
		 table_2.addCell(blank_cellg_2);
		 table_2.addCell(blank_cellh_2);
		 table_2.addCell(blank_celli_2);
		 table_2.addCell(blank_cellj_2);
		 table_2.addCell(blank_cellk_2);
		 table_2.addCell(blank_celll_2);
		
		
		
		
		
		PdfPTable tabledata = new PdfPTable(5);
		tabledata.setWidths(new int[] {2,5,5,4,4});
		tabledata.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		tabledata.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		tabledata.setWidthPercentage(80);
		
		
		
		Paragraph a = new Paragraph("Ser No",fontTableHeadingSubMainHead);
//		Paragraph b = new Paragraph("DGMT (MT-2)",fontTableHeadingSubMainHead);
		Paragraph c = new Paragraph("Marks Scored",fontTableHeadingSubMainHead);
		Paragraph d = new Paragraph("Remarks",fontTableHeadingSubMainHead);
		Paragraph e = new Paragraph("Index No",fontTableHeadingSubMainHead);
		Paragraph f = new Paragraph("No. of ABs",fontTableHeadingSubMainHead);
		
		
		
		
		Paragraph q = new Paragraph("",fontTableHeadingSubMainHead1);
		Paragraph r = new Paragraph("Total",fontTableHeadingSubMainHead);
		Paragraph s = new Paragraph("62",fontTableHeadingSubMainHead1);
		Paragraph t = new Paragraph("",fontTableHeadingSubMainHead1);
		Paragraph u = new Paragraph("",fontTableHeadingSubMainHead1);
		
		
		
		
		
		 PdfPCell blank_cella;
		 blank_cella = new PdfPCell(a);
//		 blank_cella.setRowspan(2);
		 blank_cella.setHorizontalAlignment(Element.ALIGN_CENTER);
		 
//		 PdfPCell blank_cellb;
//		 blank_cellb = new PdfPCell(b);
//		 blank_cellb.setColspan(2);
//		 blank_cellb.setHorizontalAlignment(Element.ALIGN_CENTER);
		 
		 PdfPCell blank_cellc;
		 blank_cellc = new PdfPCell(c);
//		 blank_cellc.setRowspan(2);
		 blank_cellc.setHorizontalAlignment(Element.ALIGN_CENTER);
		 
		 PdfPCell blank_celld;
		 blank_celld = new PdfPCell(d);
//		 blank_celld.setRowspan(2);
		 blank_celld.setHorizontalAlignment(Element.ALIGN_CENTER);
		 
		 
		 PdfPCell blank_celle;
		 blank_celle = new PdfPCell(e);
		 blank_celle.setHorizontalAlignment(Element.ALIGN_CENTER);
		 
		 PdfPCell blank_cellf;
		 blank_cellf = new PdfPCell(f);
		 blank_cellf.setHorizontalAlignment(Element.ALIGN_CENTER);
		 
		 
		 
		
		 
		 PdfPCell blank_cellq;
		 blank_cellq = new PdfPCell(q);
		 blank_cellq.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cellq.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellr;
		 blank_cellr = new PdfPCell(r);
		 blank_cellr.setHorizontalAlignment(Element.ALIGN_CENTER);
		 
		 PdfPCell blank_cells;
		 blank_cells = new PdfPCell(s);
		 blank_cells.setHorizontalAlignment(Element.ALIGN_CENTER);
		 
		 PdfPCell blank_cellt;
		 blank_cellt = new PdfPCell(t);
		 blank_cellt.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cellt.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cellu;
		 blank_cellu = new PdfPCell(u);
		 blank_cellu.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cellu.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 tabledata.addCell(blank_cella);
//		 tabledata.addCell(blank_cellb);
		 tabledata.addCell(blank_celle);
		 tabledata.addCell(blank_cellf);
		 tabledata.addCell(blank_cellc);
		 tabledata.addCell(blank_celld);
		 	 
		 int  index=1;
		 int Total_count= list.size();
		 for(int i=0;i<list.size();i++)
		 { 
			 
			 List<String> l = list.get(i);
		 Paragraph a1index = new Paragraph(String.valueOf(index),fontTableHeadingdata);
		 Paragraph index_no = new Paragraph(l.get(2),fontTableHeadingdata);
		 Paragraph no_abs = new Paragraph(l.get(3),fontTableHeadingdata);
		 Paragraph j = new Paragraph("",fontTableHeadingSubMainHead1);
			Paragraph k = new Paragraph("",fontTableHeadingSubMainHead1);
		 
		 
		 
		 PdfPCell cell2 = new PdfPCell();
		 
			 tabledata.addCell(a1index);
			 cell2.setPhrase(index_no);
			 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			 tabledata.addCell(cell2);
			 cell2.setPhrase(no_abs);
			 cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			 tabledata.addCell(cell2);
			 
			 cell2.setPhrase(j);
			 tabledata.addCell(cell2);
			 
			 
			 cell2.setPhrase(k);
			 tabledata.addCell(cell2);
			 
			 index+=1;
			 
			 
			
		
		 }
		 
		 
		 PdfPTable table_3 = new PdfPTable(4);
		 table_3.setWidths(new int[] {5,5,5,5});
		 table_3.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
		 table_3.getDefaultCell().setVerticalAlignment(Element.ALIGN_MIDDLE);
		 table_3.setWidthPercentage(80);
		 
		 
		 
		 Paragraph a3_1 = new Paragraph("No of Candidates :",fontTableHeadingSubMainHead1);
		 Paragraph a3_2 = new Paragraph(String.valueOf(Total_count),fontTableHeadingSubMainHead);
		 Paragraph a3_3= new Paragraph("...............................",fontTableHeadingSubMainHead1);
		 Paragraph a3_4 = new Paragraph("..............................",fontTableHeadingSubMainHead1);
		
		 Paragraph a3_5 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_6 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_7= new Paragraph("OIC Indexing Group",fontTableHeadingSubMainHead1);
		 Paragraph a3_8 = new Paragraph("(Assistant Examiner)",fontTableHeadingSubMainHead1);
		 
		 Paragraph a3_9 = new Paragraph("Date :",fontTableHeadingSubMainHead1);
		 Paragraph a3_10 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_11= new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_12 = new Paragraph("..............................",fontTableHeadingSubMainHead1);
		 
		 Paragraph a3_13 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_14 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_15= new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_16 = new Paragraph("(Chief Examiner)",fontTableHeadingSubMainHead1);
		 
		 Paragraph a3_17 = new Paragraph("Passed :",fontTableHeadingSubMainHead1);
		 Paragraph a3_18 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_19= new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_20 = new Paragraph("",fontTableHeadingSubMainHead1);
		 
		 
		 Paragraph a3_21 = new Paragraph("Failed :",fontTableHeadingSubMainHead1);
		 Paragraph a3_22 = new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_23= new Paragraph("",fontTableHeadingSubMainHead1);
		 Paragraph a3_24 = new Paragraph("",fontTableHeadingSubMainHead1);
		 
		 
		 
		 
		 
		 PdfPCell blank_cella3_1;
		 blank_cella3_1 = new PdfPCell(a3_1);
		 blank_cella3_1.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_1.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_2;
		 blank_cella3_2 = new PdfPCell(a3_2);
		 blank_cella3_2.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_2.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_3;
		 blank_cella3_3 = new PdfPCell(a3_3);
		 blank_cella3_3.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_3.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_4;
		 blank_cella3_4 = new PdfPCell(a3_4);
		 blank_cella3_4.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_4.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 PdfPCell blank_cella3_5;
		 blank_cella3_5 = new PdfPCell(a3_5);
		 blank_cella3_5.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_5.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_6;
		 blank_cella3_6 = new PdfPCell(a3_6);
		 blank_cella3_6.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_6.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_7;
		 blank_cella3_7 = new PdfPCell(a3_7);
		 blank_cella3_7.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_7.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_8;
		 blank_cella3_8 = new PdfPCell(a3_8);
		 blank_cella3_8.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_8.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 PdfPCell blank_cella3_9;
		 blank_cella3_9 = new PdfPCell(a3_9);
		 blank_cella3_9.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_9.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_10;
		 blank_cella3_10 = new PdfPCell(a3_10);
		 blank_cella3_10.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_10.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_11;
		 blank_cella3_11 = new PdfPCell(a3_11);
		 blank_cella3_11.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_11.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_12;
		 blank_cella3_12 = new PdfPCell(a3_12);
		 blank_cella3_12.setHorizontalAlignment(Element.ALIGN_CENTER);
//		 blank_cella3_12.setPaddingBottom(100);
		 blank_cella3_12.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 
		 PdfPCell blank_cella3_13;
		 blank_cella3_13 = new PdfPCell(a3_13);
		 blank_cella3_13.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_13.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_14;
		 blank_cella3_14 = new PdfPCell(a3_14);
		 blank_cella3_14.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_14.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_15;
		 blank_cella3_15 = new PdfPCell(a3_15);
		 blank_cella3_15.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_15.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_16;
		 blank_cella3_16 = new PdfPCell(a3_16);
		 blank_cella3_16.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_16.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 
		 
		 PdfPCell blank_cella3_17;
		 blank_cella3_17 = new PdfPCell(a3_17);
		 blank_cella3_17.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_17.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_18;
		 blank_cella3_18 = new PdfPCell(a3_18);
		 blank_cella3_18.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_18.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_19;
		 blank_cella3_19 = new PdfPCell(a3_19);
		 blank_cella3_19.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_19.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_20;
		 blank_cella3_20 = new PdfPCell(a3_20);
		 blank_cella3_20.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_20.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 
		 PdfPCell blank_cella3_21;
		 blank_cella3_21 = new PdfPCell(a3_21);
		 blank_cella3_21.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_21.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_22;
		 blank_cella3_22 = new PdfPCell(a3_22);
		 blank_cella3_22.setHorizontalAlignment(Element.ALIGN_LEFT);
		 blank_cella3_22.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_23;
		 blank_cella3_23 = new PdfPCell(a3_23);
		 blank_cella3_23.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_23.setBorder(Rectangle.NO_BORDER);
		 
		 PdfPCell blank_cella3_24;
		 blank_cella3_24 = new PdfPCell(a3_24);
		 blank_cella3_24.setHorizontalAlignment(Element.ALIGN_CENTER);
		 blank_cella3_24.setBorder(Rectangle.NO_BORDER);
		 
		 
		 
		 
		 table_3.addCell(blank_cella3_1);
		 table_3.addCell(blank_cella3_2);
		 table_3.addCell(blank_cella3_3);
		 table_3.addCell(blank_cella3_4);
		 table_3.addCell(blank_cella3_5);
		 table_3.addCell(blank_cella3_6);
		 table_3.addCell(blank_cella3_7);
		 table_3.addCell(blank_cella3_8);
		 
		 table_3.addCell(blank_cella3_17);
		 table_3.addCell(blank_cella3_18);
		 table_3.addCell(blank_cella3_19);
		 table_3.addCell(blank_cella3_20);
		 table_3.addCell(blank_cella3_21);
		 table_3.addCell(blank_cella3_22);
		 table_3.addCell(blank_cella3_23);
		 table_3.addCell(blank_cella3_24);
		 table_3.addCell(blank_cella3_9);
		 table_3.addCell(blank_cella3_10);
		 table_3.addCell(blank_cella3_11);
		 table_3.addCell(blank_cella3_12);
		 table_3.addCell(blank_cella3_13);
		 table_3.addCell(blank_cella3_14);
		 table_3.addCell(blank_cella3_15);
		 table_3.addCell(blank_cella3_16);
		 
		 
		 
	
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
//			// data bind
//			 int  index=1;
//			 for(int i=0;i<list.size();i++)
//			 {
//			
//				 List<String> l = list.get(i);
//			 Paragraph a1index = new Paragraph(String.valueOf(index),fontTableHeadingdata);
//			 Paragraph pers_code = new Paragraph(l.get(0),fontTableHeadingdata);
//			 Paragraph rank = new Paragraph(l.get(1),fontTableHeadingdata);
//			 Paragraph subject = new Paragraph(l.get(2),fontTableHeadingdata);
//			
//				 tabledata.addCell(a1index);
//				 tabledata.addCell(pers_code);
//				 tabledata.addCell(rank);
//				 tabledata.addCell(subject);
//				 
//				 index+=1;
//				
//			 }
//		 
		PdfPCell cell123;
		cell123 = new PdfPCell();
		
		cell123.addElement(tableheader);
		cell123.addElement(table_2);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(tabledata);
		cell123.addElement(new Paragraph("\n"));
		cell123.addElement(table_3);
		cell123.setBorder(0);
		table.addCell(cell123);
		table.setTableEvent(new ImageBackgroundEvent(request,list.get(0).get(5),list.get(0).get(5) ));  // use for watermark
		document.add(table);
		super.buildPdfMetadata(model, document, request);
	}
	
	int page = 1;
	class ImageBackgroundEvent implements PdfPTableEvent {
		protected Image image;
		HttpServletRequest request;
		String created_by;
		String ce_created_date;
		
		ImageBackgroundEvent(HttpServletRequest request,String created_by,String ce_created_date){
			this.request = request;
			this.created_by = created_by;
			this.ce_created_date = ce_created_date;
		}
		
		public void tableLayout(PdfPTable table, float[][] widths, float[] heights, int headerRows, int rowStart,PdfContentByte[] canvases) {
			String ip = "";
			if (request != null) {
		        ip = request.getHeader("X-FORWARDED-FOR");
		        if (ip == null || "".equals(ip)) {
		            ip = request.getRemoteAddr();
		        }
		    }
			
			Date now = new Date();
			String dateString = new SimpleDateFormat("dd-MM-yyyy' 'HH:mm:ss", Locale.ENGLISH).format(now);
			String watermark = " Generated by "+created_by +" on   " +dateString  +"\n"+ " For Evaluation Centre"; //by "+username+"
			
			Image img = null;
			BufferedImage bufferedImage = new BufferedImage((int) table.getTotalWidth(), 30,BufferedImage.TYPE_INT_ARGB);
			Graphics graphics = bufferedImage.getGraphics();
			//graphics.setColor(Color.lightGray);
			graphics.setColor(Color.decode("#f2f2f2")); //#e6e6e6
			//graphics.setFont(new java.awt.Font("Arial Black", Font.NORMAL, 12));
			//graphics.drawString(watermark+watermark,0, 20);
			graphics.setFont(new java.awt.Font("Arial Black", Font.NORMAL, 16));
			graphics.drawString(watermark,0, 20);
			try {
				try {
					img = Image.getInstance(bufferedImage, null);
				} catch (IOException e) {
					e.getMessage();
				}
			} catch (BadElementException e) {
				e.getMessage();
			}
			this.image = img;
			
			try {
				PdfContentByte cb = canvases[PdfPTable.BACKGROUNDCANVAS];

				/*int tableWidth = (int) table.getTotalWidth();
				int first = 0;
				if (tableWidth == 523) {
					first = 750;
				}
				if (tableWidth == 770) {
					first = 440;
				}

				int last = first - (int) table.getRowHeight(0);
		        while (first > last) {
					image.setAbsolutePosition(40, first);
					cb.addImage(image, false);
					first -= 30;
				}*/
		        
		        // Portrait Page size 700 * 523
				// Landscape page size 453 * 770
				int tableWidth = (int) table.getTotalWidth();
				if (tableWidth == 523) {  // Portrait page
					image.setAbsolutePosition(60, 300);  // image.setAbsolutePosition(left-right, up-down);
					image.setRotationDegrees(0-50);      // image.setRotationDegrees(0-degree rotate);
					cb.addImage(image, false);
				}
				if (tableWidth == 770) { // landscape page
					image.setAbsolutePosition(40, 50);
					image.setRotationDegrees(30);
					cb.addImage(image, false);
				}
			} catch (DocumentException e) {
				throw new ExceptionConverter(e);
			}
		}
	}

}
