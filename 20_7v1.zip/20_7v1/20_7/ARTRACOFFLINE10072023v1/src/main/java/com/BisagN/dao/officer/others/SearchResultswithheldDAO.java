package com.BisagN.dao.officer.others;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpSession;

public interface SearchResultswithheldDAO {
	
	
	
	public ArrayList<ArrayList<String>> getReportListResultwithheld(int startPage,String pageLength,String Search,String orderColunm,
			String orderType,int es_id,String opd_personal_id, HttpSession session) throws InvalidKeyException, NoSuchAlgorithmException, 
			NoSuchPaddingException, InvalidKeySpecException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException;
	
	public long getReportListResultwithheldCount(String Search,int es_id,String opd_personal_id);

	public ArrayList<ArrayList<String>> getLatestSerno(int es_id,int repo_no);
	
}
