package com.BisagN.models.officers.others;

import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "exam_reports", uniqueConstraints = {
@UniqueConstraint(columnNames = "id"),})

public class EXAM_REPORTS_M {

      private int id;
      private int er_id;
      private int ec_exam_id;
      private String er_filename;
      private String er_name;
      private String er_sp;
      private int er_order;
      private String er_group;
      private int er_status_id;



      @Id
      @GeneratedValue(strategy = IDENTITY)
      @Column(name = "id", unique = true, nullable = false)


      public int getId() {
           return id;
      }
      public void setId(int id) {
	  this.id = id;
      }
      public int getEr_id() {
           return er_id;
      }
      public void setEr_id(int er_id) {
	  this.er_id = er_id;
      }
      public int getEc_exam_id() {
           return ec_exam_id;
      }
      public void setEc_exam_id(int ec_exam_id) {
	  this.ec_exam_id = ec_exam_id;
      }
      public String getEr_filename() {
           return er_filename;
      }
      public void setEr_filename(String er_filename) {
	  this.er_filename = er_filename;
      }
      public String getEr_name() {
           return er_name;
      }
      public void setEr_name(String er_name) {
	  this.er_name = er_name;
      }
      public String getEr_sp() {
           return er_sp;
      }
      public void setEr_sp(String er_sp) {
	  this.er_sp = er_sp;
      }
      public int getEr_order() {
           return er_order;
      }
      public void setEr_order(int er_order) {
	  this.er_order = er_order;
      }
      public String getEr_group() {
           return er_group;
      }
      public void setEr_group(String er_group) {
	  this.er_group = er_group;
      }
      public int getEr_status_id() {
           return er_status_id;
      }
      public void setEr_status_id(int er_status_id) {
	  this.er_status_id = er_status_id;
      }
}
